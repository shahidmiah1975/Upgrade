﻿Imports System.Runtime.CompilerServices

Module modExtensions

    <Extension()>
    Public Function Punctuate(Value As String) As String
        Return Value.Replace("'", "''")
    End Function

End Module
