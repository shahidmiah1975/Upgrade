﻿Imports System.ComponentModel
Imports System.IO
Imports System.Net.Mail

Module modOnline

    Public WithEvents bgwEmailErrorLog As New BackgroundWorker

    Const intSecond As Short = 1000

    Public Sub EmailErrorLog()

        Try
            Dim conn As New EZService.ConnectivityService

            If GetAppSettingCS("OLEnableErrEmail", True) AndAlso conn.IsInternetAvailable() Then
                Dim strLogFile As String = "ezerrorlog.txt"
                Dim datLastDate = GetAppSettingCS("EmailLastSent", "")
                Dim blnSendEmail As Boolean = False
                Dim valFreq As Short = GetAppSettingCS("OLEmailFrequency", 14)

                If Not IsANumber(valFreq) Then valFreq = 14
                valFreq = -valFreq

                If IsDate(datLastDate) Then
                    blnSendEmail = Now.AddDays(valFreq) > CDate(datLastDate)
                Else
                    blnSendEmail = True
                End If

                If blnSendEmail = True AndAlso File.Exists(strLogFile) Then
                    Dim MyFile As New FileInfo(strLogFile)
                    If (MyFile.Length > 0) AndAlso (Format(Now.Date.AddDays(valFreq), "dd/MMM/yyyy") > Format(MyFile.LastWriteTime.Date, "dd/MMM/yyyy")) Then
                        bgwEmailErrorLog.RunWorkerAsync()
                    End If
                End If
            End If

        Catch ex As Exception
            If objSecurity.IsMySystem() Then MsgBox("Emailing Error Log error - " & vbCrLf & ex.Message & " - REMOVE FROM CODE")
        End Try

    End Sub

    Public Sub bgwEmailErrorLog_DoWork(sender As Object, e As DoWorkEventArgs) Handles bgwEmailErrorLog.DoWork

        Try
            Dim attachment As New Attachment("ezerrorlog.txt")

            Dim Recipients As New List(Of String) From {
                objSecurity.AES_Decrypt("mLtzrcOCZKum0n94NS+bME32otv78dV7FV8XrGU6Rw0=")
            }
            Dim FromEmailAddress As String = Recipients(0)
            Dim Subject As String = "EZ-Menu Error Log From " & GetAppSettingCS("BizName", "<bizname missing>")
            Dim Body As String = "EZ-Menu log file recevied from " & GetAppSettingCS("BizName", "<bizname missing>") &
                                        "(" & objSecurity.AES_Decrypt(objDB.EZSettingRead("SystemID")) & ")"
            Dim UserName As String = objSecurity.AES_Decrypt("KDnYGS3wV6RwSsN9yuMjGw==")
            Dim Password As String = objSecurity.AES_Decrypt("OeS0A7hveEPdqb3s3nztKA==")
            Dim Email As New MailMessage()
            Dim SMTPServer As New SmtpClient("smtp.gmail.com", 587)

            Email.Attachments.Add(attachment)
            Email.From = New MailAddress(FromEmailAddress)
            For Each Recipient As String In Recipients
                Email.To.Add(Recipient)
            Next
            Email.Subject = Subject : Email.Body = Body
            SMTPServer.Credentials = New Net.NetworkCredential(UserName, Password)
            SMTPServer.EnableSsl = True
            SMTPServer.Send(Email)
            Email.Dispose()

        Catch ex As Exception

        End Try

    End Sub

    Private Sub bgwEmailErrorLog_RunWorkerCompleted(sender As Object, e As RunWorkerCompletedEventArgs) Handles bgwEmailErrorLog.RunWorkerCompleted

        SaveAppSetting("EmailLastSent", GetDateNow)

    End Sub



End Module