﻿Imports System.Configuration

Module modSettings

    Public Function GetAppSettingCS(ByVal strRegKey As String, ByVal strDefaultVal As Object) As Object

        Dim strRegVal As String = ConfigurationManager.AppSettings(strRegKey)

        If strRegVal Is Nothing Then
            Return strDefaultVal
        ElseIf strRegVal.ToUpper = "TRUE" Or strRegVal.ToUpper = "FALSE" Then
            Return Boolean.Parse(strRegVal)
        ElseIf IsANumber(strRegVal) Then
            If Left(strRegVal, 1) = "0" Then
                Return strRegVal.ToString
            Else
                Return Val(strRegVal)
            End If
        Else
            Return strRegVal.ToString
        End If

    End Function

    Public Sub SaveAppSetting(strName As String, strValue As String)

        Try

            ' Open the config file in Read-Write mode.
            Dim config As Configuration = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None)

            ' Check if the setting already exists
            If config.AppSettings.Settings(strName) Is Nothing Then
                config.AppSettings.Settings.Add(strName, strValue)
            Else
                config.AppSettings.Settings(strName).Value = strValue
            End If

            config.Save(ConfigurationSaveMode.Modified)
            ConfigurationManager.RefreshSection("appSettings")

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    'Public Function GetAppSettingCS(ByVal strRegKeyVar As String)

    '    Return (GetAppSettingCS(strRegKeyVar, 0) <> 0)

    'End Function

    Public Sub GetSavedRegSettings()
        'Get settings from Registry

        Try
            'delivery charges and collection discounts
            GlobalDiscounts.CheckEnabled = GetAppSettingCS("AllDiscountsCheck", 1)
            GlobalDiscounts.Value = GetAppSettingCS("AllDiscountsAmount", 10)
            GlobalDiscounts.AorP = GetAppSettingCS("AllDiscountsAorP", "P")
            GlobalDiscounts.AmtChkEnabled = GetAppSettingCS("AllDiscountsAmtExcChk", 1)
            GlobalDiscounts.AmtValue = GetAppSettingCS("AllDiscountsAmtExcVal", 10)

            GlobalCharges.CheckEnabled = GetAppSettingCS("AllChargesCheck", 1)
            GlobalCharges.Value = GetAppSettingCS("AllChargesAmount", 2)
            GlobalCharges.AorP = GetAppSettingCS("AllChargesAorP", "A")
            GlobalCharges.AmtChkEnabled = GetAppSettingCS("AllChargesAmtExcChk", 1)
            GlobalCharges.AmtValue = GetAppSettingCS("AllChargesAmtExcVal", 12)

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

End Module
