﻿Imports Infragistics.Win
Imports Infragistics.Win.Misc
Imports Infragistics.Win.UltraWinEditors

Module modControlsHandler

    Public Sub SelectText(ByRef ObjName As Object)
        'selects text in the specified text box

        Try
            With ObjName
                .SelStart = 0
                .SelLength = Len(.Text)
                .SetFocus()
            End With

        Catch ex As Exception
        End Try

    End Sub

    Public Sub ButtonToggle(ubtnButton As UltraButton, intState As Short)

        intState = Abs(intState)

        If intState = cstButTogYes Then
            With ubtnButton
                .Appearance.Image = My.Resources.ezresource.tick
                .Tag = cstButTogYes
            End With
        ElseIf intState = cstButTogNo Then
            With ubtnButton
                .Appearance.Image = My.Resources.ezresource.cross
                .Tag = cstButTogNo
            End With
        Else
            With ubtnButton
                .Appearance.Image = Nothing
                .Tag = cstButTogClr
            End With
        End If

    End Sub

    Public Function IsInListbox(strString2Find As String, lstListBox As UltraWinListView.UltraListView) As Boolean

        For iCntrX As Integer = 0 To lstListBox.Items.Count - 1
            If lstListBox.Items(iCntrX).Text.ToUpper = strString2Find.ToUpper Then
                Return True
            End If
        Next

        Return False

    End Function

    Public Sub FillCuisineDropDown(ByRef ctrlComboBox As UltraComboEditor)

        Dim blnVisibility As Boolean = False

        drcDatarowCollection = objDB.GetDataRows("SELECT CuisineName FROM Cuisine WHERE CuisineName <> '' ORDER BY ID")

        If drcDatarowCollection IsNot Nothing AndAlso drcDatarowCollection.Count > 0 Then
            For Each myRow As DataRow In drcDatarowCollection
                ctrlComboBox.Items.Add(myRow!CuisineName)
            Next
            blnVisibility = True
        End If
        ctrlComboBox.Visible = blnVisibility

    End Sub

    Public Sub HiLitBox(ctrlName As UltraTextEditor)

        ctrlName.Appearance.BackColor = clrTextBoxesHilit
        ctrlName.Appearance.BackColor2 = clrTextBoxesHilit
        ctrlName.Appearance.BorderColor = clrTextBoxesHilitBorder
        ctrlName.Appearance.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop37

    End Sub

    Public Sub HiLitOffBox(ctrlName As UltraTextEditor)

        ctrlName.AlwaysInEditMode = False
        ctrlName.Appearance.BackColor = clrTextBoxes
        ctrlName.Appearance.BackColor2 = clrTextBoxes
        ctrlName.Appearance.BorderColor = clrTextBoxesBorder
        ctrlName.Appearance.BackGradientStyle = Infragistics.Win.GradientStyle.None

    End Sub

End Module