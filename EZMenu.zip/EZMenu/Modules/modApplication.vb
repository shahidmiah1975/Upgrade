﻿Imports Infragistics.Win

Module modApplication

    Public Sub ShowHomeScreen()

        Try

            'unload all forms other than Opener
            Dim colnForms As New List(Of Form)

            For Each objForm As Form In Application.OpenForms
                If TypeOf objForm IsNot frmOpener Then
                    colnForms.Add(objForm)
                End If
            Next

            For Each objForm As Form In colnForms
                objForm = Nothing
            Next

            DisposeObject(objDelivColn)
            DisposeObject(objOrderEntry)
            DisposeObject(objPayment)

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Public Sub ShowRegisterForm()

        Dim tmNowTime = Date.Now.AddSeconds(1)
        Do Until Date.Now > tmNowTime
            Application.DoEvents()
        Loop

        frmRegister.ShowDialog()

        Dim tmrNowTime = Date.Now.AddSeconds(1)
        Do Until Date.Now > tmrNowTime
            Application.DoEvents()
        Loop

    End Sub

    Private Sub DisposeObject(ByRef objDispose As Object)

        Try
            If objDispose IsNot Nothing Then
                objDispose.Dispose()
                objDispose = Nothing
            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Public Function GetButtonAppearances(intState As Short)

        Dim appnButtonY = New Appearance()

        If intState = 0 Then    'normal

            appnButtonY.BackColor = Color.FromArgb(16, 101, 132)
            appnButtonY.BackColor2 = Color.FromArgb(66, 135, 165)
            appnButtonY.BackGradientStyle = GradientStyle.VerticalBump
            appnButtonY.BorderAlpha = Alpha.Default
            appnButtonY.BorderColor = Color.FromArgb(99, 146, 206)
            appnButtonY.BorderColor2 = Color.FromArgb(99, 146, 206)
            appnButtonY.BorderColor3DBase = Color.FromArgb(99, 146, 206)
            appnButtonY.ForeColor = Color.White
            appnButtonY.ImageHAlign = HAlign.Center
            appnButtonY.ImageVAlign = VAlign.Middle
            appnButtonY.TextVAlignAsString = "Middle"

        ElseIf intState = 1 Then    'hot track

            appnButtonY.BackColor = Color.DarkOrange
            appnButtonY.BackColor2 = Color.FromArgb(250, 200, 150)
            appnButtonY.BackGradientStyle = GradientStyle.GlassTop50
            appnButtonY.ForeColor = Color.Yellow

        ElseIf intState = 2 Then    'group buttons

            appnButtonY.BackColor = Color.FromArgb(66, 120, 35)
            appnButtonY.BackColor2 = Color.FromArgb(80, 150, 30)
            appnButtonY.BackGradientStyle = GradientStyle.VerticalBump
            appnButtonY.BorderAlpha = Alpha.Default
            appnButtonY.BorderColor = Color.FromArgb(166, 181, 0)
            appnButtonY.BorderColor2 = Color.FromArgb(166, 181, 0)
            appnButtonY.BorderColor3DBase = Color.FromArgb(0, 192, 0)
            appnButtonY.ForeColor = Color.White
            appnButtonY.ImageHAlign = HAlign.Center
            appnButtonY.ImageVAlign = VAlign.Middle
            appnButtonY.TextVAlignAsString = "Middle"

        ElseIf intState = 3 Then    'drinks buttons 

            appnButtonY.BorderColor = Color.FromArgb(190, 190, 190)
            appnButtonY.ForeColor = Color.FromArgb(60, 60, 60)

        ElseIf intState = 4 Then    'group buttons dk green 0, 180, 70

            appnButtonY.BackColor = Color.FromArgb(0, 120, 70)
            appnButtonY.BackColor2 = Color.FromArgb(0, 160, 70)
            appnButtonY.BackGradientStyle = GradientStyle.VerticalBump
            appnButtonY.BorderColor = Color.FromArgb(0, 180, 70)
            appnButtonY.ForeColor = Color.White

        ElseIf intState = 5 Then    'pressed

            appnButtonY.BackColor = Color.OrangeRed
            appnButtonY.BackColor2 = Color.Tomato
            appnButtonY.BackGradientStyle = GradientStyle.GlassTop50
            appnButtonY.ForeColor = Color.Yellow

        ElseIf intState = 6 Then    'drinks button group

            appnButtonY.ImageBackground = My.Resources.ezresource.dkbutton_group
            appnButtonY.ForeColor = Color.Wheat

        ElseIf intState = 7 Then    'group up/down

            appnButtonY.BackColor = Color.DarkSlateBlue
            appnButtonY.BackColor2 = Color.SlateBlue
            appnButtonY.BorderColor = Color.MediumPurple
            appnButtonY.BackGradientStyle = GradientStyle.VerticalBump
            appnButtonY.ForeColor = Color.FromArgb(220, 220, 220)

        ElseIf intState = 8 Then    'postal addresses

            appnButtonY.ImageBackground = My.Resources.ezresource.dkbutton
            appnButtonY.BorderColor = Color.Transparent
            appnButtonY.ForeColor = Color.FromArgb(90, 90, 90)

        ElseIf intState = 9 Then    'postal addresses hilit

            appnButtonY.ImageBackground = My.Resources.ezresource.dkbutton_hilit
            appnButtonY.ForeColor = Color.Wheat

        ElseIf intState = 10 Then    'postal addresses pressed

            appnButtonY.ImageBackground = My.Resources.ezresource.dkbutton_press
            appnButtonY.ForeColor = Color.FromArgb(90, 90, 90)

        End If

        Return appnButtonY

    End Function


End Module
