﻿Imports System.IO
Imports EZMenu.Core.Enums
Imports EZMenu.Core.Models
Imports EZService.Repository
Imports Infragistics.Win

Module modOrder

    Private objNumberFountain As clsNumberFountain
    Private Const strIsModRow As String = "ismodrow"
    Private gridRowIndex As Integer

    Public Structure TableInfoType
        Dim Id As Short
        Dim Status As TStatusEnum
    End Structure

    Public TableInfo(36) As TableInfoType

    Public Structure GlobalDCType
        Dim CheckEnabled As Short
        Dim Value As Decimal
        Dim AorP As String
        Dim AmtChkEnabled As Short
        Dim AmtValue As Decimal
    End Structure

    Public GlobalCharges As GlobalDCType, GlobalDiscounts As GlobalDCType

    Public Sub StartNewOrder()

        Try
            CustID = 0
            OrderID = 0

            TurnCapsOff()

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Public Function CalcDelivery(mySumDishes As Decimal) As Decimal

        Dim decDelCharge As Decimal = 0

        Try

            If GlobalCharges.CheckEnabled <> 0 Then 'add deliv charge

                If GlobalCharges.AorP = "A" Then 'charge an amount
                    If GlobalCharges.AmtChkEnabled <> 0 Then
                        If mySumDishes < (GlobalCharges.AmtValue - GlobalCharges.Value) Then
                            decDelCharge = GlobalCharges.Value
                        ElseIf (mySumDishes >= (GlobalCharges.AmtValue - GlobalCharges.Value) And mySumDishes < GlobalCharges.AmtValue) Then
                            decDelCharge = GlobalCharges.AmtValue - mySumDishes   'make up to free delivery amount
                        Else
                            decDelCharge = 0
                        End If
                    Else
                        decDelCharge = GlobalCharges.Value
                    End If

                Else 'charge a percentage

                    Dim decPercentage As Decimal = Math.Round(mySumDishes * (GlobalCharges.Value / 100), 2)
                    If GlobalCharges.AmtChkEnabled = 1 Then
                        If (mySumDishes + decPercentage) <= GlobalCharges.AmtValue Then
                            decDelCharge = decPercentage
                        ElseIf (mySumDishes < GlobalCharges.AmtValue) And (mySumDishes + decPercentage) > GlobalCharges.AmtValue Then
                            decDelCharge = GlobalCharges.AmtValue - mySumDishes
                        Else
                            decDelCharge = 0
                        End If
                    Else
                        decDelCharge = decPercentage
                    End If
                End If
                decDelCharge = Val(decDelCharge)

            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

        Return decDelCharge

    End Function

    Public Function CalcGlobalDiscount(mysumDishes As Decimal) As Decimal

        Dim decDiscount As Decimal = 0

        Try
            If GlobalDiscounts.CheckEnabled <> 0 Then 'give discount
                If GlobalDiscounts.AorP = "A" Then   'deduct an amount
                    If GlobalDiscounts.AmtChkEnabled <> 0 Then 'only on amts over that is set
                        If mysumDishes >= GlobalDiscounts.AmtValue Then   'sum qualifies for a discount
                            decDiscount = GlobalDiscounts.Value
                        Else 'not enough for a discount
                            decDiscount = 0
                        End If
                    Else 'on all amounts
                        decDiscount = GlobalDiscounts.Value
                    End If
                Else 'deduct a percentage
                    If GlobalDiscounts.AmtChkEnabled <> 0 Then 'only on amts over that is set
                        If mysumDishes >= GlobalDiscounts.AmtValue Then   'sum qualifies for a discount
                            decDiscount = fixCur(SumOfDishes("Y") * (GlobalDiscounts.Value / 100))
                        Else 'not enough for a discount
                            decDiscount = 0
                        End If
                    Else 'on all amounts
                        decDiscount = fixCur(SumOfDishes("Y") * (GlobalDiscounts.Value / 100))
                    End If
                End If

            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

        Return decDiscount

    End Function

    Public Function SumOfDishes(strIsDiscountable As String) As Decimal

        Dim DiscountableYes As Decimal = 0
        Dim DiscountableNo As Decimal = 0

        Try
            With objOrderEntry.ugdOrderGrid
                For Each mrow In .Rows
                    gridRowIndex = mrow.Index
                    If .Rows(gridRowIndex).Cells("Mods").Value <> strIsModRow Then
                        If CShort(.Rows(gridRowIndex).Cells("Discountable").Value) = 0 Then
                            DiscountableNo += .Rows(gridRowIndex).Cells("Total").Value
                        Else
                            DiscountableYes += .Rows(gridRowIndex).Cells("Total").Value
                        End If
                    Else
                        DiscountableYes += .Rows(gridRowIndex).Cells("Total").Value
                    End If
                Next
            End With

            Select Case strIsDiscountable.ToUpper
                Case "Y"
                    Return DiscountableYes
                Case "N"
                    Return DiscountableNo
                Case Else
                    Return (DiscountableYes + DiscountableNo)
            End Select

        Catch ex As Exception
            DisplayError(ex)
            Return 0
        End Try

    End Function

    Public Function GetSetItemsInGrid(intRowIndex As Integer) As String

        Dim strSetString As String = String.Empty
        Dim tmpStr As String
        Dim blnCheckForMore As Boolean
        Dim decCost As Decimal
        Dim intQty As Short

        Try
            Do
                blnCheckForMore = False
                If intRowIndex + 1 < objOrderEntry.ugdOrderGrid.Rows.Count Then
                    Dim xRow As UltraWinGrid.UltraGridRow = objOrderEntry.ugdOrderGrid.Rows(intRowIndex + 1)
                    If xRow.Cells("Mods").Value = strIsModRow Then
                        'ignore mod row
                        intRowIndex += 1
                        blnCheckForMore = True
                    ElseIf xRow.Cells("Mods").Value = strIsSetItem Then
                        If (IsDBNull(xRow.Cells("DQty").Value) Or (xRow.Cells("DQty").Value <> String.Empty)) Then
                            intQty = xRow.Cells("DQty").Value
                        Else
                            intQty = 1
                        End If
                        'intQty = xRow.Cells("DQty").Value
                        tmpStr = xRow.Cells("DName").Value.ToString().Trim
                        decCost = CDec(xRow.Cells("Total").Value.ToString().Trim)
                        If tmpStr.StartsWith("- ") Then tmpStr = tmpStr.Substring(2)
                        strSetString &= intQty.ToString().Trim & "#" & tmpStr.Trim & "#" & decCost & "^^"
                        intRowIndex += 1
                        blnCheckForMore = True
                    End If
                End If
            Loop While blnCheckForMore

            If strSetString.EndsWith("^^") Then strSetString = strSetString.Substring(0, strSetString.Length - 2)

        Catch ex As Exception
            DisplayError(ex)
        End Try

        Return strSetString

    End Function

    Public Function CalculateSelectedDC(returnValue As PriceAdjustmentsModel, subTotal As String) As Decimal

        Dim discount As Decimal = 0

        If returnValue.DiscountOrCharge IsNot Nothing Then
            Dim ret
            If returnValue.AmountOrPercentage = AmountOrPercentageEnum.Percentage Then
                ret = subTotal * (returnValue.Value / 100)
            ElseIf returnValue.AmountOrPercentage = AmountOrPercentageEnum.Amount Then
                ret = returnValue.Value
            Else
                ret = 0
            End If
            discount = fixCurFive(ret)
        End If

        Return discount

    End Function

    Public Sub CollateOrderInformation(orderType As OrderTypeEnum, printDestination As PrintDestinationEnum, tableUniqueID As Short)

        Dim oInfo As New OrderInfoModel
        Dim oCustomer As New CustomerModel
        Dim orderRepo As New OrderRepository()
        Dim tableRepo As New TableRepository()

        Try

            If orderType = OrderTypeEnum.Table Then
                oInfo.OrderType = OrderTypeEnum.Table
                oInfo.TableUniqueID = tableUniqueID

            Else
                oCustomer.Name = objDelivColn.txtName.Text
                oCustomer.Phone = objDelivColn.txtTelephone.Text
                oCustomer.Email = objDelivColn.txtEmail.Text

                If objDelivColn.txtAddress1.Visible = True Then     'delivery order
                    oInfo.OrderType = OrderTypeEnum.Delivery
                    oCustomer.Address1 = objDelivColn.txtAddress1.Text
                    oCustomer.Address2 = objDelivColn.txtAddress2.Text
                    oCustomer.Address3 = objDelivColn.txtAddress3.Text
                    oCustomer.CustomerId = objDelivColn.CurrentCustomer.CustomerId
                Else
                    'Collection tab is selected
                    oInfo.OrderType = OrderTypeEnum.Collection
                    oInfo.CustomerIsWaiting = (objPayment.cmdWaiting.Tag = cstButTogYes)
                End If
                oInfo.Customer = oCustomer

            End If

            'whether order is paid or not
            oInfo.IsPaid = objPayment.cmdPaid.Tag = cstButTogYes

            'kitchen note 
            oInfo.KitchenNote = objPayment.txtKitchenNote.Text

            'save drink to db
            If objOrderEntry.lblDrinksOE.Visible = True Then
                oInfo.DrinksTotal = objOrderEntry.lblDrinksOE.Text
            End If

            'save discount and charges labels text
            Dim oDC As New DiscountsAndChargesModel With {
                .DiscountAmount = Abs(objOrderEntry.lblPriceAdjDiscounts.Text),
                .DiscountLabelText = objOrderEntry.lblPriceAdjDiscountsLbl.Text.Replace(":", ""),
                .ChargeAmount = objOrderEntry.lblPriceAdjCharges.Text,
                .ChargeLabelText = objOrderEntry.lblPriceAdjChargesLbl.Text.Replace(":", ""),
                .GlobalDiscountAmount = Abs(objOrderEntry.lblGDiscounts.Text),
                .GlobalDiscountLabelText = objOrderEntry.lblGDiscountsLbl.Text.Replace(":", ""),
                .GlobalChargeAmount = objOrderEntry.lblGCharges.Text,
                .GlobalChargeLabelText = objOrderEntry.lblGChargesLbl.Text.Replace(":", "")
            }

            oInfo.DiscountsAndCharges = oDC

            oInfo.SubTotal = CDec(objOrderEntry.lblSubtotal.Text)
            oInfo.BillTotal = objOrderEntry.lblToPay.Text

            If objPayment.FixTime() <> "ASAP" Then
                oInfo.CollectionOrDeliveryTime = objPayment.FixTime("H") & ":" & objPayment.FixTime("M")
            End If

            'payment method 
            oInfo.PaymentMethod = PaymentMethodEnum.Unspecified
            If Abs(objPayment.cmdTenderCard.Tag) = 1 Then
                oInfo.PaymentMethod = PaymentMethodEnum.Card
            ElseIf Abs(objPayment.cmdTenderCash.Tag) = 1 Then
                oInfo.PaymentMethod = PaymentMethodEnum.Cash
            ElseIf Abs(objPayment.cmdTenderOther.Tag) = 1 Then
                oInfo.PaymentMethod = PaymentMethodEnum.Other
            End If

            oInfo.BizId = GetRandomNum(40, 60)

            'cuisine name
            oInfo.CuisineName = objOrderEntry.cmdCuisine.Text

            'save any drinks ordered to the db
            If orderType <> OrderTypeEnum.Table Then
                If (objTables IsNot Nothing) AndAlso (objTables.Tag = "DrinkAway" Or objTables.Tag = "DrinkAwayEdit") Then

                    'first delete existing drinks from the order
                    SQLQuery = "DELETE FROM CollectionDrinks WHERE OrderID = " & OrderID
                    objDB.ExeNonQuery(SQLQuery)

                    'now insert the drinks in the DB table
                    Dim oDrinks As New List(Of CollectionDrinksModel)
                    With objTables.ugdDrinksGrid
                        For Each mrow In .Rows
                            Dim dkItem = New CollectionDrinksModel
                            gridRowIndex = mrow.Index
                            dkItem.Name = .Rows(gridRowIndex).Cells("DkName").Value().ToString.Punctuate
                            dkItem.Qty = .Rows(gridRowIndex).Cells("DkQty").Value()
                            dkItem.Price = .Rows(gridRowIndex).Cells("DkPrice").Value()
                            oDrinks.Add(dkItem)
                        Next
                    End With
                    oInfo.DrinksList = oDrinks
                End If
            End If

            'put all the order information in the OrderItems table
            Dim oDetails As New List(Of DishModel)
            With objOrderEntry.ugdOrderGrid
                For Each mrow In .Rows
                    gridRowIndex = mrow.Index
                    If RowIsNotModOrSet(gridRowIndex) Then
                        Dim oItem = New DishModel
                        oItem.Code = .Rows(gridRowIndex).Cells("DCode").Value
                        oItem.DishName = .Rows(gridRowIndex).Cells("DName").Value.ToString.Punctuate
                        oItem.Qty = CShort(.Rows(gridRowIndex).Cells("DQty").Value)
                        oItem.UnitPrice = CDec(.Rows(gridRowIndex).Cells("DPrice").Value)
                        'save any modifiers
                        oItem.ModifiersList = GetAnyModifiersNew(gridRowIndex)
                        'check if set meal
                        If GetSetItemsInGrid(gridRowIndex).Punctuate = String.Empty Then ModsSet &= "0" Else ModsSet &= "1"
                        oItem.Discountable = CShort(.Rows(gridRowIndex).Cells("Discountable").Value)
                        oItem.GroupIndex = CShort(.Rows(gridRowIndex).Cells("GroupIndex").Value)
                        oItem.Mods = ModsSet
                        oDetails.Add(oItem)
                    End If
                Next
            End With

            oInfo.OrderedItems = oDetails

            'print order
            If orderType = OrderTypeEnum.Table Then
                'pass order onto the service to be processed
                tableRepo.ProcessOrder(oInfo)

            Else
                'pass order onto the service to be processed
                orderRepo.ProcessOrder(oInfo)

                PrintOrder(oInfo.OrderID, printDestination)
            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Public Function GetAnyModifiersNew(intRowIndex As Integer) As List(Of OrderModsModel)

        Dim tmpStr As String
        Dim blnCheckForMore As Boolean
        Dim decCost As Decimal
        Dim mods As New List(Of OrderModsModel)

        Try
            Do
                blnCheckForMore = False
                If intRowIndex + 1 < objOrderEntry.ugdOrderGrid.Rows.Count Then
                    Dim xrow As UltraWinGrid.UltraGridRow = objOrderEntry.ugdOrderGrid.Rows(intRowIndex + 1)
                    If xrow.Cells("Mods").Value = strIsSetItem Then
                        'ignore set row
                        intRowIndex += 1
                        blnCheckForMore = True
                    ElseIf xrow.Cells("Mods").Value = strIsModRow Then
                        tmpStr = xrow.Cells("DName").Value.ToString().Trim
                        decCost = CDec(xrow.Cells("DPrice").Value.ToString().Trim)
                        If tmpStr.StartsWith("- ") Then tmpStr = tmpStr.Substring(2)
                        mods.Add(New OrderModsModel With {.ModName = tmpStr, .ModCost = decCost})
                        intRowIndex += 1
                        blnCheckForMore = True
                    End If
                End If
            Loop While blnCheckForMore

        Catch ex As Exception
            DisplayError(ex)
        End Try

        Return mods

    End Function

    Public Sub CollateOrderInformation(orderType As OrderTypeEnum, printDestination As PrintDestinationEnum)

        Dim oInfo As New OrderInfoModel
        Dim oCustomer As New CustomerModel
        Dim orderRepo As New OrderRepository()

        Try

            oInfo.OrderType = orderType

            If orderType = OrderTypeEnum.Table Then

            Else
                oCustomer.Name = objDelivColn.txtName.Text
                oCustomer.Phone = objDelivColn.txtTelephone.Text
                oCustomer.Email = objDelivColn.txtEmail.Text

                If orderType = OrderTypeEnum.Delivery Then
                    'delivery order
                    oCustomer.Address1 = objDelivColn.txtAddress1.Text
                    oCustomer.Address2 = objDelivColn.txtAddress2.Text
                    oCustomer.Address3 = objDelivColn.txtAddress3.Text
                    oCustomer.CustomerId = objDelivColn.CurrentCustomer.CustomerId

                ElseIf orderType = OrderTypeEnum.Collection Then
                    'collection order
                    oInfo.CustomerIsWaiting = (objPayment.cmdWaiting.Tag = cstButTogYes)
                End If

                oInfo.Customer = oCustomer

            End If

            'whether order is paid or not
            oInfo.IsPaid = objPayment.cmdPaid.Tag = cstButTogYes

            'kitchen note 
            oInfo.KitchenNote = objPayment.txtKitchenNote.Text

            'save drink to db
            If objOrderEntry.lblDrinksOE.Visible = True Then
                oInfo.DrinksTotal = objOrderEntry.lblDrinksOE.Text
            End If

            'save discount and charges labels text
            Dim oDC As New DiscountsAndChargesModel With {
                .DiscountAmount = Abs(objOrderEntry.lblPriceAdjDiscounts.Text),
                .DiscountLabelText = objOrderEntry.lblPriceAdjDiscountsLbl.Text.Replace(":", ""),
                .ChargeAmount = objOrderEntry.lblPriceAdjCharges.Text,
                .ChargeLabelText = objOrderEntry.lblPriceAdjChargesLbl.Text.Replace(":", ""),
                .GlobalDiscountAmount = Abs(objOrderEntry.lblGDiscounts.Text),
                .GlobalDiscountLabelText = objOrderEntry.lblGDiscountsLbl.Text.Replace(":", ""),
                .GlobalChargeAmount = objOrderEntry.lblGCharges.Text,
                .GlobalChargeLabelText = objOrderEntry.lblGChargesLbl.Text.Replace(":", "")
            }

            oInfo.DiscountsAndCharges = oDC

            oInfo.SubTotal = CDec(objOrderEntry.lblSubtotal.Text)
            oInfo.BillTotal = objOrderEntry.lblToPay.Text

            If objPayment.FixTime() <> "ASAP" Then
                oInfo.CollectionOrDeliveryTime = objPayment.FixTime("H") & ":" & objPayment.FixTime("M")
            End If

            'payment method 
            oInfo.PaymentMethod = PaymentMethodEnum.Unspecified
            If Abs(objPayment.cmdTenderCard.Tag) = 1 Then
                oInfo.PaymentMethod = PaymentMethodEnum.Card
            ElseIf Abs(objPayment.cmdTenderCash.Tag) = 1 Then
                oInfo.PaymentMethod = PaymentMethodEnum.Cash
            ElseIf Abs(objPayment.cmdTenderOther.Tag) = 1 Then
                oInfo.PaymentMethod = PaymentMethodEnum.Other
            End If

            oInfo.BizId = GetRandomNum(40, 60)

            'cuisine name
            oInfo.CuisineName = objOrderEntry.cmdCuisine.Text

            'save any drinks ordered to the db
            If orderType = OrderTypeEnum.Delivery Or orderType = OrderTypeEnum.Collection Then
                If (objTables IsNot Nothing) AndAlso (objTables.Tag = "DrinkAway" Or objTables.Tag = "DrinkAwayEdit") Then

                    'first delete existing drinks from the order
                    SQLQuery = "DELETE FROM CollectionDrinks WHERE OrderID = " & OrderID
                    objDB.ExeNonQuery(SQLQuery)

                    'now insert the drinks in the DB table
                    Dim oDrinks As New List(Of CollectionDrinksModel)
                    With objTables.ugdDrinksGrid
                        For Each mrow In .Rows
                            Dim dkItem = New CollectionDrinksModel
                            gridRowIndex = mrow.Index
                            dkItem.Name = .Rows(gridRowIndex).Cells("DkName").Value().ToString.Punctuate
                            dkItem.Qty = .Rows(gridRowIndex).Cells("DkQty").Value()
                            dkItem.Price = .Rows(gridRowIndex).Cells("DkPrice").Value()
                            oDrinks.Add(dkItem)
                        Next
                    End With
                    oInfo.DrinksList = oDrinks
                End If
            End If

            'put all the order information in the OrderItems table
            Dim oDetails As New List(Of DishModel)
            For Each row As UltraWinGrid.UltraGridRow In objOrderEntry.ugdOrderGrid.Rows
                Dim idx As Integer = row.Index
                If RowIsNotModOrSet(idx) Then
                    Dim isSetMeal As Boolean = GetSetItemsInGrid(idx).Punctuate <> String.Empty
                    Dim modsValue As String = If(isSetMeal, "1", "0")
                    Dim oItem As New DishModel With
                    {
                        .Code = row.Cells("DCode").Value,
                        .DishName = row.Cells("DName").Value.ToString.Punctuate,
                        .Qty = row.Cells("DQty").Value,
                        .UnitPrice = row.Cells("DPrice").Value,
                        .ModifiersList = GetAnyModifiersNew(idx),
                        .Discountable = row.Cells("Discountable").Value,
                        .GroupIndex = row.Cells("GroupIndex").Value,
                        .IsStarter = row.Cells("IsStarter").Value,
                        .Mods = modsValue
                    }
                    oDetails.Add(oItem)
                End If
            Next

            oInfo.OrderedItems = oDetails

            If orderType = OrderTypeEnum.Delivery Or orderType = OrderTypeEnum.Collection Then
                'pass order onto the service to be processed
                orderRepo.ProcessOrder(oInfo)

                'print order
                If printDestination <> PrintDestinationEnum.SaveOnly Then
                    PrintOrder(oInfo.OrderID, PrintDestinationEnum.Both)
                End If

            ElseIf orderType = OrderTypeEnum.Table Then

            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Public Function GetAnyModifiers(intRowIndex As Integer) As String

        Dim strMyModifier As String = String.Empty
        Dim tmpStr As String
        Dim blnCheckForMore As Boolean
        Dim decCost As Decimal

        Try
            Do
                blnCheckForMore = False
                If intRowIndex + 1 < objOrderEntry.ugdOrderGrid.Rows.Count Then
                    Dim xrow As UltraWinGrid.UltraGridRow = objOrderEntry.ugdOrderGrid.Rows(intRowIndex + 1)
                    If xrow.Cells("Mods").Value = strIsSetItem Then
                        'ignore set row
                        intRowIndex += 1
                        blnCheckForMore = True
                    ElseIf xrow.Cells("Mods").Value = strIsModRow Then
                        tmpStr = xrow.Cells("DName").Value.ToString().Trim
                        decCost = CDec(xrow.Cells("Total").Value.ToString().Trim)
                        If tmpStr.StartsWith("- ") Then tmpStr = tmpStr.Substring(2)
                        strMyModifier &= tmpStr.Trim & "#" & decCost & "^^"
                        intRowIndex += 1
                        blnCheckForMore = True
                    End If
                End If
            Loop While blnCheckForMore

            If strMyModifier.EndsWith("^^") Then strMyModifier = strMyModifier.Substring(0, strMyModifier.Length - 2)

        Catch ex As Exception
            DisplayError(ex)
        End Try

        Return strMyModifier

    End Function

    Public Function MainOrSubSystem() As String

        Dim strSubORMain As String = "MAIN"

        If GetAppSettingCS("IsPartOfMultiSystem", True) = True Then    'is part of MS
            If GetAppSettingCS("MultiSystemIsMain", True) = True Then  'this is the main system of MS
                strSubORMain = "MULTIMAIN"
            Else
                strSubORMain = "MULTISUB"   'this is sub of MS
            End If
        Else
            'strSubORMain = "NOTMULTI"       'not part of MS
        End If

        Return strSubORMain.ToUpper

    End Function

    Public Function NumberOfItems()

        Dim nItems As Short = 0

        For Each mrow In objOrderEntry.ugdOrderGrid.Rows
            If RowIsNotModOrSet(mrow.Index) Then nItems += 1
        Next

        Return nItems

    End Function

    Public Sub OnlineOrderHandler(strFileName As String)

        Dim decTotal, decSubtotal, decCharges, decDiscount As Decimal
        Dim sFields, sValues As String
        Dim blnSaveToCustomer As Boolean
        Dim orderType As OrderTypeEnum
        Dim CustIDOnline, OrderIDOnline As Short
        Dim arrFileContent As String() = File.ReadAllLines(strFileName)

        arrFilex = arrFileContent

        Try
            orderType = GFS("CorDorT")
            decTotal = GFS("BillTotal")
            decSubtotal = 0
            decCharges = 0
            decDiscount = 0
            CustIDOnline = IIf(orderType = OrderTypeEnum.Delivery, 0, 31000)
            OrderIDOnline = 0

            PhoneQuery = FormatPhone(GFS("Telephone"))

            'create query
            SQLQuery = "SELECT * FROM Customer WHERE Phone = '" & PhoneQuery & "';"
            drcDatarowCollection = objDB.GetDataRows(SQLQuery)
            If drcDatarowCollection.Count = 0 Then
                'new, so add customer to DB
                SQLQuery = String.Format("INSERT INTO Customer (Name, Address1, Address2, Address3, Postcode, Phone) 
                                          VALUES ('{0}','{1}','{2}','{3}','{4}','{5}')",
                                        GFS("DeliveryName").Punctuate,
                                        GFS("DeliveryAddress1").Punctuate,
                                        GFS("DeliveryAddress2").Punctuate,
                                        GFS("DeliveryAddress3").Punctuate,
                                        GFS("DeliveryPostcode").Punctuate,
                                        PhoneQuery)
                objDB.ExeNonQuery(SQLQuery)
                CustIDOnline = idIdentity
            End If

            If CustIDOnline = 0 Then CustIDOnline = CType(drcDatarowCollection(0)("CustomerID").ToString, Integer)

            If GetAppSettingCS("SaveCustomerHistory", True) = True Then
                'delete existing customer order
                objDB.ExeNonQuery("DELETE FROM CustOrders WHERE CustomerID = " & CustIDOnline)
                objDB.ExeNonQuery("DELETE FROM CustOrderItems WHERE CustomerID = " & CustIDOnline)
                blnSaveToCustomer = True
            End If

            sFields = "CustomerID, OrderTime, OrderDate, ToPay, Subtotal, ChargeAmount, DiscountAmount"
            sValues = CustIDOnline & ", '" & GetTimeNow() & "', '" & GetDateNow() & "', " & decTotal & ", " & decSubtotal & ", " & decCharges & ", " & decDiscount

            If orderType = OrderTypeEnum.Collection Then
                If GFS("CollectionName") <> "" Then
                    sFields &= ", CustomerName"
                    sValues &= ", '" & GFS("CollectionName").Punctuate & "'"
                End If
                If GFS("CollectionOrDeliveryTime") <> "" Then
                    sFields &= ", CollectionOrDeliveryTime"
                    sValues &= ", '" & GFS("CollectionOrDeliveryTime").Punctuate & "'"
                End If

            Else
                tempStr = ", '" & GFS("DeliveryName").Punctuate & "'"
                tempStr &= ", '" & GFS("DeliveryAddress1").Punctuate & "'"
                tempStr &= ", '" & GFS("DeliveryAddress2").Punctuate & "'"
                tempStr &= ", '" & GFS("DeliveryAddress3").Punctuate & "'"
                tempStr &= ", '" & GFS("DeliveryPostcode").Punctuate & "'"

                sFields &= ", CustomerName, DeliveryAddress1, DeliveryAddress2, DeliveryAddress3, DeliveryPostcode"
                sValues &= tempStr

                If GFS("CollectionOrDeliveryTime") <> "" Then
                    sFields &= ", CollectionOrDeliveryTime"
                    sValues &= ", '" & GFS("CollectionOrDeliveryTime").Punctuate & "'"
                End If
            End If

            If GFS("Telephone") <> "" Then
                sFields &= ", Telephone"
                sValues &= ", '" & PhoneQuery & "'"
            End If

            sFields &= ", KitchenNote, OrderIsPaid, UserName, BizId"
            sValues &= ", '" & GFS("KitchenNote").Punctuate & "', 0, 'Online', " & GetRandomNum(40, 60)

            SQLQuery = String.Format("INSERT INTO Orders ({0}) VALUES ({1});", sFields, sValues)
            objDB.ExeNonQuery(SQLQuery)

            OrderIDOnline = idIdentity
            OrderID = OrderIDOnline

            'save customer order history
            If blnSaveToCustomer = True Then
                Try
                    SQLQuery = Replace(SQLQuery, "INSERT INTO Orders ", "INSERT INTO CustOrders ")
                    objDB.ExeNonQuery(SQLQuery)
                Catch ex As Exception
                    DisplayError(ex)
                End Try
            End If

            'put all the order information in the OrderItems table
            PutDishesInOrderItems(CustIDOnline, OrderIDOnline, arrFileContent)

            PrintOrder(OrderIDOnline, "Both")

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Public Sub TabletOrderHandler(strFileName As String)

        Dim decTotal, decSubtotal, decCharges, decDiscount As Decimal
        Dim sFields, sValues As String
        Dim blnSaveToCustomer As Boolean
        Dim orderType As OrderTypeEnum
        Dim CustIDTablet, OrderIDTablet As Short

        Dim arrFileContent As String() = File.ReadAllLines(strFileName)

        arrFilex = arrFileContent

        Try

            Dim ot As String = GFS("CorDorT")
            If ot = "C" Then
                orderType = OrderTypeEnum.Collection
            ElseIf ot = "D" Then
                orderType = OrderTypeEnum.Delivery
            ElseIf ot = "T" Then
                orderType = OrderTypeEnum.Table
            End If

            decTotal = GFS("BillTotal")
            decSubtotal = GFS("Subtotal")
            decCharges = GFS("Charges")
            decDiscount = GFS("Discounts")
            CustIDTablet = IIf(orderType = OrderTypeEnum.Delivery, 0, 31000)
            OrderIDTablet = 0

            PhoneQuery = FormatPhone(GFS("Telephone"))

            If PhoneQuery <> "" Then
                'create query
                SQLQuery = "SELECT * FROM Customer WHERE Phone = '" & PhoneQuery & "';"
                drcDatarowCollection = objDB.GetDataRows(SQLQuery)
                If drcDatarowCollection.Count = 0 Then
                    'new, so add customer to DB
                    SQLQuery = String.Format("INSERT INTO Customer (Name, Address1, Address2, Address3, Postcode, Phone) 
                                                VALUES ('{0}','{1}','{2}','{3}','{4}','{5}')",
                                                GFS("DeliveryName").Punctuate,
                                                GFS("DeliveryAddress1").Punctuate,
                                                GFS("DeliveryAddress2").Punctuate,
                                                GFS("DeliveryAddress3").Punctuate,
                                                GFS("DeliveryPostcode").Punctuate,
                                                PhoneQuery)
                    objDB.ExeNonQuery(SQLQuery)
                    CustIDTablet = idIdentity
                End If
            End If

            If CustIDTablet = 0 Then CustIDTablet = CType(drcDatarowCollection(0)("CustomerID").ToString, Integer)

            If CustIDTablet < 31000 AndAlso GetAppSettingCS("SaveCustomerHistory", True) = True Then
                'delete existing customer order
                objDB.ExeNonQuery("DELETE FROM CustOrders WHERE CustomerID = " & CustIDTablet)
                objDB.ExeNonQuery("DELETE FROM CustOrderItems WHERE CustomerID = " & CustIDTablet)
                blnSaveToCustomer = True
            End If

            sFields = "CustomerID, OrderTime, OrderDate, ToPay, Subtotal, ChargeAmount, DiscountAmount"
            sValues = CustIDTablet & ", '" & GetTimeNow() & "', '" & GetDateNow() & "', " & decTotal & ", " & decSubtotal & ", " & decCharges & ", " & decDiscount

            If orderType = OrderTypeEnum.Collection Then
                If GFS("CollectionName") <> "" Then
                    sFields &= ", CustomerName"
                    sValues &= ", '" & GFS("CollectionName").Punctuate & "'"
                End If
                If GFS("CollectionOrDeliveryTime") <> "" Then
                    sFields &= ", CollectionOrDeliveryTime"
                    sValues &= ", '" & GFS("CollectionOrDeliveryTime").Punctuate & "'"
                End If
                If GFS("CustomerIsWaiting") <> "" Then
                    sFields &= ", CustomerIsWaiting"
                    sValues &= ", '" & IIf(GFS("CustomerIsWaiting") = "True", 1, 0).ToString.Punctuate & "'"
                End If

            Else
                tempStr = ", '" & GFS("DeliveryName").Punctuate & "'"
                tempStr &= ", '" & GFS("DeliveryAddress1").Punctuate & "'"
                tempStr &= ", '" & GFS("DeliveryAddress2").Punctuate & "'"
                tempStr &= ", '" & GFS("DeliveryAddress3").Punctuate & "'"
                tempStr &= ", '" & GFS("DeliveryPostcode").Punctuate & "'"

                sFields &= ", CustomerName, DeliveryAddress1, DeliveryAddress2, DeliveryAddress3, DeliveryPostcode"
                sValues &= tempStr

                If GFS("CollectionOrDeliveryTime") <> "" Then
                    sFields &= ", CollectionOrDeliveryTime"
                    sValues &= ", '" & GFS("CollectionOrDeliveryTime").Punctuate & "'"
                End If
            End If

            If GFS("Telephone") <> "" Then
                sFields &= ", Telephone"
                sValues &= ", '" & PhoneQuery & "'"
            End If

            sFields &= ", KitchenNote, OrderIsPaid, UserName, BizId"
            sValues &= ", '" & GFS("KitchenNote").Punctuate & "', 0, NULL, " & GetRandomNum(40, 60)

            SQLQuery = String.Format("INSERT INTO Orders ({0}) VALUES ({1});", sFields, sValues)
            objDB.ExeNonQuery(SQLQuery)

            OrderIDTablet = idIdentity
            OrderID = OrderIDTablet

            'save customer order history
            If blnSaveToCustomer = True Then
                Try
                    SQLQuery = Replace(SQLQuery, "INSERT INTO Orders ", "INSERT INTO CustOrders ")
                    objDB.ExeNonQuery(SQLQuery)
                Catch ex As Exception
                    DisplayError(ex)
                End Try
            End If

            'put all the order information in the OrderItems table
            PutDishesInOrderItems(CustIDTablet, OrderIDTablet, arrFileContent)

            PrintOrder(OrderIDTablet, "Both")

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub PutDishesInOrderItems(CustIDOL, OrderIDOL, arrFile)

        Dim dCode, dQty, dPrice, dStarter, dGroupIndex, dMods, arrItems()
        Dim dName As String

        Try

            For Each strArrLine As String In arrFile

                If (strArrLine IsNot Nothing) Then

                    If strArrLine = "" Then

                    ElseIf InStr(strArrLine, "#SetMeal =") > 0 Then

                    ElseIf strArrLine.IndexOf("#") = 0 Then

                    Else

                        If strArrLine.StartsWith("!") Then strArrLine = strArrLine.Substring(0, 2)

                        arrItems = strArrLine.Split(",")
                        dCode = arrItems(0)
                        dQty = arrItems(1)
                        dName = arrItems(2).ToString.Punctuate
                        dPrice = arrItems(3)
                        dGroupIndex = objDB.GetGroupIndex(dName)
                        dStarter = 0    'arrItems(5)
                        dMods = "NULL"    'arrItems(6)

                        SQLQuery = String.Format("INSERT INTO OrderItems (OrderID, Code, Dish, Qty, Mods, UnitPrice, Discountable, GroupIndex) " &
                                                 "VALUES ({0}, {1}, '{2}', {3}, '{4}', {5}, {6}, {7})",
                                                 OrderIDOL, dCode, dName, dQty, dMods, dPrice, 0, dGroupIndex)
                        objDB.ExeNonQuery(SQLQuery)

                        Dim blnSaveToCustomer As Boolean = True
                        If blnSaveToCustomer = True Then
                            SQLQuery = String.Format("INSERT INTO CustOrderItems (CustomerID, Code, Dish, Qty, Mods, UnitPrice, Discountable, GroupIndex) " &
                                                     "VALUES ({0}, {1}, '{2}', {3}, '{4}', {5}, {6}, {7})",
                                                     CustIDOL, dCode, dName, dQty, dMods, dPrice, 0, dGroupIndex)
                            objDB.ExeNonQuery(SQLQuery)
                        End If

                    End If
                End If
            Next

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Public Sub AssignUniqueID(intCurrentTable As Short)

        Try
            If objNumberFountain Is Nothing Then
                objNumberFountain = New clsNumberFountain
            End If

            TableInfo(intCurrentTable).Id = objNumberFountain.NextId

            'insert this into the table
            SQLQuery = "INSERT INTO Table_Bill (TableNumber, TabUniqueId, EntryTime, BizId) " &
                       "VALUES (" & intCurrentTable & ", " & TableInfo(intCurrentTable).Id & ", '" & Format(Now, "HH:mm:ss") & "', " & GetRandomNum(40, 60) & ")"
            objDB.ExeNonQuery(SQLQuery)

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Public Function RowIsNotModOrSet(rowNumber As Integer) As Boolean

        Dim r = objOrderEntry.ugdOrderGrid.Rows(rowNumber).Cells("Mods").Value
        Return (r <> strIsModRow And r <> strIsSetItem)

    End Function

    Public Function RowIsNotModifier() As Boolean

        Return objOrderEntry.ugdOrderGrid.ActiveRow.Cells("Mods").Value <> strIsModRow

    End Function

    Public Function RowIsNotSet() As Boolean

        Return objOrderEntry.ugdOrderGrid.ActiveRow.Cells("Mods").Value <> strIsSetItem

    End Function

    Public Function FromOrdersDB(strFieldName As String)

        SQLQuery = "SELECT " & strFieldName & " FROM Orders WHERE OrderID = " & OrderID & " And (BizId BETWEEN 40 And 60)"
        drDataRow = objDB.GetSingleRow(SQLQuery)
        If drDataRow Is Nothing Then
            Return Nothing
        ElseIf IsDBNull(drDataRow(0)) Then
            Return String.Empty
        ElseIf drDataRow(0).ToString = "True" Or drDataRow(0).ToString = "False" Then
            Return Boolean.Parse(drDataRow(0))
        ElseIf IsANumber(drDataRow(0)) Then
            Return drDataRow(0)
        Else
            Return drDataRow(0).ToString
        End If

    End Function

    'Public Function FromTablesDB(strFieldName As String)

    '    SQLQuery = "SELECT " & strFieldName & " FROM Table_Bill WHERE TabUniqueID = " & sngTabUniqueID
    '    drDataRow = objDB.GetSingleRow(SQLQuery)
    '    If drDataRow Is Nothing Then
    '        Return Nothing
    '    ElseIf IsDBNull(drDataRow(0)) Then
    '        Return String.Empty
    '    ElseIf drDataRow(0).ToString = "True" Or drDataRow(0).ToString = "False" Then
    '        Return Boolean.Parse(drDataRow(0))
    '    ElseIf IsANumber(drDataRow(0)) Then
    '        Return Val(drDataRow(0))
    '    Else
    '        Return drDataRow(0).ToString
    '    End If

    'End Function

    Public Sub SaveWirelessOrder(strFileName As String)

        Dim dCode, dQty, dPrice, dStarter, dGroupIndex, dMods
        Dim dName As String
        Dim tmpCurTable As Short
        Dim arrWirelessFile As String() = File.ReadAllLines(strFileName)

        Try

            tmpCurTable = GFS("TableNum")

            'see if this table is in use or new
            If TableInfo(tmpCurTable).Id = 0 Then
                AssignUniqueID(tmpCurTable)
                SetTableStatus(CurTable, TStatusEnum.InUse)
            End If

            For Each strArrLine As String In arrWirelessFile

                If (strArrLine IsNot Nothing) Then

                    If strArrLine = "" Then

                    ElseIf InStr(strArrLine, "#SetMeal =") > 0 Then

                    ElseIf strArrLine.IndexOf("#") = 0 Then

                    Else

                        If strArrLine.StartsWith("!") Then strArrLine = strArrLine.Substring(0, 2)

                        Dim arrItems = strArrLine.Split(",")
                        Dim dMods2 As String

                        dCode = arrItems(0).Trim
                        dQty = arrItems(1).Trim
                        dName = arrItems(2).Trim
                        dPrice = arrItems(3).Trim
                        dGroupIndex = arrItems(4).Trim
                        dStarter = arrItems(5).Trim
                        dMods = arrItems(6).Trim
                        If dMods <> "" AndAlso dMods <> "x" Then
                            dMods2 = "10"
                        Else
                            dMods2 = "00"
                        End If

                        'update if in db already
                        SQLQuery = String.Format("SELECT * FROM Table_Meal WHERE TabUniqueID = {0} AND DishName = '{1}'", TableInfo(tmpCurTable).Id, dName)
                        drcDatarowCollection = objDB.GetDataRows(SQLQuery)
                        If drcDatarowCollection IsNot Nothing AndAlso drcDatarowCollection.Count > 0 Then
                            SQLQuery = String.Format("UPDATE Table_Meal SET DishQty = DishQty + {2} WHERE TabUniqueID = {0} AND DishName = '{1}'",
                                TableInfo(tmpCurTable).Id, dName, dQty)
                            objDB.ExeNonQuery(SQLQuery)
                        Else
                            SQLQuery = "INSERT INTO Table_Meal (TabUniqueID, Code, DishName, DishPrice, DishQty, IsStarter, GroupIndex, Mods, Discountable) VALUES (" &
                                      TableInfo(tmpCurTable).Id & ", " & dCode & ", '" & dName & "', " & dPrice & ", " & dQty & ", " & dStarter & ", " & dGroupIndex & ",'" & dMods2 & "', 1);"
                            objDB.ExeNonQuery(SQLQuery)
                        End If

                        'insert any mod
                        If dMods2 = "10" Then
                            Dim arrMods = dMods.Split("^^")
                            For aCnt = arrMods.GetLowerBound(0) To arrMods.GetUpperBound(0)
                                If arrMods(aCnt) <> String.Empty Then
                                    tempStr = arrMods(aCnt)
                                    Dim h As Short = tempStr.IndexOf("#")
                                    Dim mDesc = tempStr.Substring(0, h - 1)
                                    Dim mPrice = tempStr.Substring(h + 1)
                                    SQLQuery = String.Format("INSERT INTO Table_Mods (TabUniqueID, DishName, ModDesc, Cost) " &
                                                             "VALUES ({0}, '{1}', '{2}', {3})", TableInfo(tmpCurTable).Id, dName, mDesc, mPrice)
                                    objDB.ExeNonQuery(SQLQuery)
                                End If
                            Next
                        End If

                    End If
                End If
            Next

            'insert covers into database
            Dim blnUpdateValue As Boolean = False

            'no need to update if its already set
            SQLQuery = "SELECT NumCust FROM Table_Bill WHERE TabUniqueID = " & TableInfo(tmpCurTable).Id
            drDataRow = objDB.GetSingleRow(SQLQuery)
            If drDataRow IsNot Nothing AndAlso CInt(drDataRow!NumCust) = 0 Then
                blnUpdateValue = True
            Else
                blnUpdateValue = True
            End If

            If blnUpdateValue = True Then
                'update the number of customers into the DB
                SQLQuery = String.Format("UPDATE Table_Bill SET NumCust = {0}, CAPValue = {0} " &
                                         "WHERE TabUniqueID = {1}", GFS("Covers"), TableInfo(tmpCurTable).Id)
                objDB.ExeNonQuery(SQLQuery)
            End If

            'update or insert printed date/time
            blnUpdateValue = False

            'no need to update if it is there already
            SQLQuery = "SELECT PrintedTime FROM Table_Bill WHERE TabUniqueID = " & TableInfo(tmpCurTable).Id
            drDataRow = objDB.GetSingleRow(SQLQuery)
            If drDataRow IsNot Nothing AndAlso IsDBNull(drDataRow!PrintedTime) = True Then
                blnUpdateValue = True
            Else
                blnUpdateValue = True
            End If

            If blnUpdateValue = True Then
                'update the number of customers into the DB
                tempStr = "Time: " & Format(Now, "h:mm") & "    Date: " & Format(Now, "dd/MM/yy")
                SQLQuery = "UPDATE Table_Bill SET PrintedTime = '" & tempStr & "' WHERE TabUniqueID = " & TableInfo(tmpCurTable).Id
                objDB.ExeNonQuery(SQLQuery)
            End If

            PrintTable(TableInfo(tmpCurTable).Id, "Kitchen")

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Public Sub SetTableStatus(currentTable As Short, tbStatus As Integer)
        'records status of table in the DB
        ' 0 = no items inserted
        ' 1 = table in use
        ' 2 = printed but not cleared
        ' 3 = saved

        Try

            SQLQuery = $"UPDATE Table_Bill SET TableStatus = { tbStatus }
                         WHERE TabUniqueID = { TableInfo(currentTable).Id }"

            objDB.ExeNonQuery(SQLQuery)

            TableInfo(currentTable).Status = tbStatus

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Public Function GFS(strWordToFind As String) As String

        Dim strArrReturn = String.Empty

        Try
            strWordToFind = "#" & strWordToFind.Trim & " ="
            For Each strArr As String In arrFilex
                If strArr.ToUpper.StartsWith(strWordToFind.ToUpper) AndAlso Not strArr.Trim.EndsWith("=") Then
                    strArrReturn = strArr.Substring(strArr.IndexOf("=") + 2).Trim
                    Exit For
                End If
            Next

        Catch ex As Exception
            DisplayError(ex)
            strArrReturn = String.Empty
        End Try

        Return strArrReturn

    End Function

End Module