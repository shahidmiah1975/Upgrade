﻿Module modEZMenu

    Private Declare Sub keybd_event Lib "user32" (bVk As Byte, bScan As Byte, dwFlags As Integer, dwExtraInfo As Integer)

    Public intSQLRowsAffected As Short
    Public drDataRow As DataRow
    Public drcDatarowCollection As DataRowCollection

    Public objDelivColn As frmDelivColn
    Public objOrders As frmOrders
    Public objOrderEntry As frmOrderEntry
    Public objPayment As frmPayment
    Public objTables As frmTables2
    Public objOnlineOrders As frmOnlineOrders
    Public objDB As clsDatabase
    Public objSecurity As clsSecurity

    Public blnSQLSuccess, blnPrintDone As Boolean

    Public CustID, OrderID, CurTable, intResponseBox, intRowsAffected, intCurrentCuisine As Short

    Public SQLQuery, tempStr, msg, PhoneQuery, ModsSet, TruncPhNum(3) As String
    Public strKBInput, idIdentity, strMsgBox As String
    Public arrFilex() As String

    Public intMsgBoxResult As MsgBoxResult

    Public Const cstButTogYes As Short = 1
    Public Const cstButTogNo As Short = 0
    Public Const cstButTogClr As Short = 2
    Public Const EZKBEscape As String = "^Esc"
    Public Const strChutney As String = " + chutneys"
    Public Const strPapadom As String = "PAPA*"
    Public Const strIsSetItem As String = "issetitem"
    Public Const strBlankDrinkField As String = "<blank>"
    Public Const intMaxCustomerID As Integer = 30000
    Public Const strCustomListBoxCancelString As String = "^Cancel"

    Public clrTextBoxes As Color = Color.WhiteSmoke
    Public clrTextBoxesBorder As Color = Color.LightGray
    Public clrTextBoxesHilit As Color = Color.Beige
    Public clrTextBoxesHilitBorder As Color = Color.DarkKhaki

End Module