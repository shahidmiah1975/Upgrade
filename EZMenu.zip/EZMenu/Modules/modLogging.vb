﻿Imports EZControls
Imports log4net

Module modLogging

    Private m_objLog As ILog = LogManager.GetLogger("log4net")

    Enum log4netType As Short
        Debug
        [Error]
        Warning
        Info
        None
    End Enum

    Public Sub Alert(strMessage As String, Optional mIcon As MessageBoxIcon = MessageBoxIcon.Information)

        'this is for frmOpener - loop open forms and close frmSplash
        For Each objForm As Form In Application.OpenForms
            If TypeOf (objForm) Is frmSplash Then
                objForm.Dispose()
                Application.DoEvents()
                Exit For
            End If
        Next

        Dim blnIsWaitCursor As Boolean = (Cursor.Current = Cursors.WaitCursor)
        If blnIsWaitCursor Then HideHourGlass()

        EZMsgBox.Show(strMessage, MessageBoxButtons.OK, mIcon)

        If blnIsWaitCursor Then ShowHourGlass()

    End Sub

    Public Sub DisplayError(exc As Exception,
                            Optional strExtraInfo As String = Nothing,
                            Optional lType As log4netType = log4netType.Error,
                            Optional blnWriteToLog As Boolean = True)

        Dim strErrString As String = exc.Message
        Dim st As New StackTrace()

        'this is for frmOpener - loop open forms and close frmSplash
        For Each objForm As Form In Application.OpenForms
            If TypeOf (objForm) Is frmSplash Then
                objForm.Dispose()
                Application.DoEvents()
                Exit For
            End If
        Next

        If strErrString IsNot Nothing Then
            strErrString &= vbCrLf & strExtraInfo
        End If

        EZMsgBox.Show(strErrString, MessageBoxButtons.OK, MessageBoxIcon.Error)

        'log the error message
        If blnWriteToLog = True Then
            strErrString = st.GetFrame(1).GetMethod().Name & ": " & strErrString
            WriteToLog(strErrString, lType)
        End If

    End Sub

    Public Sub DisplayError(strError As String,
                            Optional strExtraInfo As String = Nothing,
                            Optional lType As log4netType = log4netType.Error,
                            Optional blnWriteToLog As Boolean = True)

        Dim strErrString As String = strError
        Dim st As New StackTrace()

        'this is for frmOpener - loop open forms and close frmSplash
        For Each objForm As Form In Application.OpenForms
            If TypeOf (objForm) Is frmSplash Then
                objForm.Dispose()
                Application.DoEvents()
                Exit For
            End If
        Next

        If strErrString IsNot Nothing Then
            strErrString &= vbCrLf & strExtraInfo
        End If

        EZMsgBox.Show(strErrString, MessageBoxButtons.OK, lType)

        'log the error message
        If blnWriteToLog = True Then
            strErrString = st.GetFrame(1).GetMethod().Name & ": " & strErrString
            WriteToLog(strErrString, lType)
        End If

    End Sub

    <DebuggerStepThrough>
    Public Sub WriteToLog(exException As Exception,
                          Optional strExtraInfo As String = "",
                          Optional lType As log4netType = log4netType.Error)

        Dim st As New StackTrace()
        Dim strErrString As String

        If strExtraInfo <> "" Then
            strExtraInfo &= vbCrLf
        End If

        strErrString = st.GetFrame(1).GetMethod().Name & ": " & strExtraInfo & exException.Message

        'log the error message
        If lType = log4netType.Debug Then
            m_objLog.Debug(strErrString)
        ElseIf lType = log4netType.Error Then
            m_objLog.Error(strErrString)
        ElseIf lType = log4netType.Warning Then
            m_objLog.Warn(strErrString)
        End If

    End Sub

    '<DebuggerStepThrough>
    Public Sub WriteToLog(strMessage As String,
                          Optional lType As log4netType = log4netType.Debug)

        Dim st As New StackTrace()
        Dim strErrString As String = st.GetFrame(1).GetMethod().Name & ": " & strMessage

        Try
            'log the error message
            If lType = log4netType.Debug Then
                m_objLog.Debug(strErrString)
            ElseIf lType = log4netType.Error Then
                m_objLog.Error(strErrString)
            ElseIf lType = log4netType.Warning Then
                m_objLog.Warn(strErrString)
            ElseIf lType = log4netType.Info Then
                m_objLog.Info(strErrString)
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

End Module
