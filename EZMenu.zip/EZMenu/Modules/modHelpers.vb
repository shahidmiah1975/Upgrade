﻿Imports System.IO

Module modHelpers

    Private Declare Sub keybd_event Lib "user32" (bVk As Byte, bScan As Byte, dwFlags As Integer, dwExtraInfo As Integer)

    Public Function GetTimeNow()
        Return Date.Now.ToLongTimeString
    End Function

    Public Function GetDateNow()
        Return Format(Now, "dd/MMM/yyyy")
    End Function

    Public Function GetSystemIDFromConfig() As String

        Dim strUserID As String = objSecurity.AES_Decrypt(GetAppSettingCS(objSecurity.AES_Encrypt("SystemID"), ""))
        Return strUserID

    End Function

    Public Function Abs(value) As Double
        Return Math.Abs(Val(value))
    End Function

    Public Sub AppendNum(ctrlControlName As Control, theNum As Integer, intMaxLength As Short)

        Try
            If ctrlControlName.Text.Length = intMaxLength Then Exit Sub

            Dim theText As String = String.Empty
            Dim numSep As String = "."

            ctrlControlName.Text &= theNum

            If ctrlControlName.Text.Length >= 2 Then
                If ctrlControlName.Text.Length = 2 Then ' Apply the seperator
                    ctrlControlName.Text = numSep & ctrlControlName.Text
                Else
                    Dim d = ctrlControlName.Text.IndexOf(numSep)
                    theText = Left(ctrlControlName.Text, d) & ctrlControlName.Text.Substring(d + 1, 1) & numSep & ctrlControlName.Text.Substring(d + 2, 1) & theNum
                    If Left(theText, 1) = "0" Then
                        'Remove leading '0' if going from .01 to .12 - don't want 0.12
                        theText = theText.Remove(0, 1)
                    End If
                    ctrlControlName.Text = theText
                End If
            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Public Function fixCur(ByRef CurToFix) As String

        If IsDBNull(CurToFix) Then CurToFix = 0
        If String.IsNullOrEmpty(CurToFix) Then CurToFix = 0

        If Decimal.TryParse(CurToFix, 0) = True Then
            CurToFix = Decimal.Parse(CurToFix)
        End If

        Return Format(CurToFix, "#0.00")

    End Function

    Public Function fixCurFive(CurToFix)

        If Decimal.TryParse(CurToFix, 0) = True Then
            CurToFix = Decimal.Parse(CurToFix)
        End If

        If IsDBNull(CurToFix) Then CurToFix = 0

        If GetAppSettingCS("RoundingMethod", True) Then
            Return Format(CurToFix, "#0.00")
        Else
            Return Format((Int(20 * CurToFix)) / 20, "#0.00")
        End If

    End Function

    Public Function fixCurTen(CurToFix)

        If Decimal.TryParse(CurToFix, 0) = True Then
            CurToFix = Decimal.Parse(CurToFix)
        End If

        If IsDBNull(CurToFix) Then CurToFix = 0

        Return Format((Int(10 * CurToFix)) / 10, "#0.00")

    End Function

    Public Function FormatPhone(pnum As String) As String
        'Formats the given phone number, removing all characters
        'other than digits

        If pnum.Trim = String.Empty Then Return String.Empty

        Dim strFone, strChar, nmsg1, nmsg2 As String
        Dim TruncPhLen(3) As Short

        Try
            For iCnt = 1 To pnum.Length
                strChar = Mid$(pnum, iCnt, 1)
                If strChar < "0" Or strChar > "9" Then
                    pnum = Replace(pnum, strChar, "*")
                End If
            Next
            strFone = Replace(pnum, "*", "")

            For iCnt = 1 To 3
                TruncPhNum(iCnt) = ""
                TruncPhLen(iCnt) = -1
            Next

            For iCnt = 1 To 3
                nmsg1 = GetAppSettingCS("TruncPhLen" & Mid$(Str$(iCnt), 2), "")
                nmsg2 = GetAppSettingCS("TruncPhNum" & Mid$(Str$(iCnt), 2), "")

                If ((nmsg1.Trim <> "" And nmsg2.Trim <> "") And (IsANumber(nmsg1) And IsANumber(nmsg2))) Then
                    TruncPhLen(iCnt) = nmsg1
                    TruncPhNum(iCnt) = nmsg2
                End If
            Next

            For iCnt = 1 To 3
                If strFone.Length = TruncPhLen(iCnt) Then
                    If (TruncPhLen(iCnt) > -1) And (Left$(strFone, Len(TruncPhNum(iCnt))) = TruncPhNum(iCnt)) Then
                        strFone = Mid(strFone, Len(TruncPhNum(iCnt)) + 1)
                    End If
                End If
            Next

            'strIncomingNumber = strFone
            Return strFone

        Catch ex As Exception
            DisplayError(ex)
            Return pnum
        End Try

    End Function

    Public Function IsANumber(inputStr As String) As Boolean
        Return IsNumeric(inputStr)
    End Function

    Public Function AppPath() As String
        'returns the path of the application

        Dim myAppPath As String

        myAppPath = My.Application.Info.DirectoryPath
        If Right$(myAppPath, 1) <> "\" Then myAppPath &= "\"
        Return myAppPath

    End Function

    Public Function GetEZPDAPath() As String

        'Return GetAppSettingCS("EZPDAPath", AppPath() & "EZPDA\")
        Dim strPath As String = GetAppSettingCS("EZPDAPath", "D:\EZPDA\")
        Return strPath

    End Function

    Public Sub Sleep(intTimeToSleep)

        Threading.Thread.Sleep(intTimeToSleep)
        Application.DoEvents()

    End Sub

    <DebuggerStepThrough()>
    Public Function GetRandomNum(intFirst As Integer, intLast As Integer)

        Dim myRandom As New Random(Now.TimeOfDay.TotalMilliseconds)
        Return myRandom.Next(intFirst, intLast + 1)

    End Function

    Public Function FormatEZDate(strDateToFormat As String) As Date

        If IsDate(strDateToFormat) Then
            Return Format(CDate(strDateToFormat), "dd/MM/yyyy")
        Else
            Return Nothing
        End If

    End Function

    Public Function EZImages(strTitle As String) As String

        Try
            For Each strFile In Directory.GetFiles(AppPath() & "\graphics\")
                If Path.GetFileNameWithoutExtension(strFile) = strTitle Then
                    Return strFile
                End If
            Next

        Catch ex As Exception
            WriteToLog(ex)
        End Try

        Return Nothing

    End Function

    Public Sub ShowHourGlass()
        Cursor.Current = Cursors.WaitCursor
    End Sub

    Public Sub HideHourGlass()
        Cursor.Current = Cursors.Default
    End Sub

    Public Function StringContainsNumber(strInput As String) As Boolean

        For Each x As String In strInput
            If IsANumber(x) Then
                Return True
            End If
        Next

        Return False

    End Function

    Public Function StringAllNumbers(strInput As String) As Boolean

        For Each x As String In strInput
            If Not IsANumber(x) Then
                Return False
            End If
        Next

        Return True

    End Function

    Public Sub TurnCapsOff()

        If My.Computer.Keyboard.CapsLock = True Then
            ' Simulate the Key Press
            keybd_event(&H14, &H45, &H1 Or 0, 0)

            ' Simulate the Key Release
            keybd_event(&H14, &H45, &H1 Or &H2, 0)
        End If

    End Sub

    Public Sub DeleteFile(strFileToDelete As String)

        Try
            If File.Exists(strFileToDelete) Then
                File.Delete(strFileToDelete)
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

End Module
