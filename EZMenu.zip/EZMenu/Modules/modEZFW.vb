﻿Imports System.IO
Imports System.Drawing.Printing
Imports Infragistics.Win.UltraWinDataSource

Module modEZFW

    Private strFilePath, strFileNameFull As String
    Private CurrentYPOS, CurrentYPOSLast As Single
    Private strLastFileName As String
    Private evPtPgEvArg As PrintPageEventArgs
    Private watchfolder As FileSystemWatcher
    Private myPapersize As PaperSize
    Private fonCurPrintFont As Font
    Private myDate As Date
    Private udsSummaryDatasource As UltraDataSource
    Private sngTabUniqueID As Single

    Public Sub StartService()

        Try

            'set paper size
            myPapersize = New PaperSize("EZPaperSize", GetAppSettingCS("PaperWidth", 280), 5000)

            myDate = Date.Now
            strLastFileName = ""

            'verify if EZ-Menu is registered
            'If objSecurity.AppIsActivated() = True Then
            watchfolder = New FileSystemWatcher With {
                    .Path = GetEZPDAPath(),
                    .Filter = "*.dat",
                    .NotifyFilter = NotifyFilters.LastWrite Or NotifyFilters.FileName Or NotifyFilters.DirectoryName,
                    .EnableRaisingEvents = True
                }

                AddHandler watchfolder.Created, AddressOf FSWatcher

            'End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub FSWatcher(source As Object, e As FileSystemEventArgs)

        Try

            If e.ChangeType = IO.WatcherChangeTypes.Created Then

                Dim blnTimeCheck As Boolean = (Date.Now.Subtract(myDate).TotalSeconds > 1)

                If (e.Name = strLastFileName And blnTimeCheck = True) Or (e.Name <> strLastFileName) Then

                    strFileNameFull = e.FullPath
                    strFilePath = Replace(e.FullPath, e.Name, "")

                    Wait4FileReady(strFileNameFull)

                    If e.Name.ToUpper = "ONLINEORDER.DAT" Then
                        OnlineOrderHandler(strFileNameFull)

                    ElseIf e.Name.ToUpper = "ONLINE_NEW.DAT" Then
                        NewOnlineOrder()

                    ElseIf e.Name.ToUpper = "BANKING.DAT" Then
                        PrintBanking()

                    ElseIf e.Name.ToUpper = "SUMMARY.DAT" Then
                        PrintSummary(strFileNameFull)

                    ElseIf e.Name.ToUpper = "REPORT.DAT" Then
                        PrintReport()

                    ElseIf e.Name.ToUpper Like "WIRELESS*.DAT" Then
                        SaveWirelessOrder(strFileNameFull)
                        'put print order proc here
                        Application.DoEvents()
                        objTables.UpdateUsedButtons()

                    ElseIf e.Name.ToUpper = "LINKTEST.DAT" Then
                        'ListBox1.Items.Add("TEST OK - " & Now.ToLongTimeString)

                    ElseIf e.Name.ToUpper = "PRTTABLE.DAT" Then
                        'StartBGWorkers(4)

                    ElseIf e.Name.ToUpper Like "TABLETORDER*.DAT" Then
                        TabletOrderHandler(strFileNameFull)

                    Else
                        strMsgBox = "Error in proc FSWatcher:" & vbCrLf & "Unknown e.name parameter - " & e.Name
                    End If

                End If

            End If

            myDate = Date.Now
            strLastFileName = e.Name

            Application.DoEvents()

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Function CentrePOS(strMessage As String)

        Dim sizStringSize, sngMyVal As Single

        sizStringSize = evPtPgEvArg.Graphics.MeasureString(strMessage, fonCurPrintFont).Width
        sngMyVal = (evPtPgEvArg.PageSettings.PaperSize.Width - sizStringSize) / 2

        Return sngMyVal

    End Function

    Private Function FromRightPOS(strMessage As String, intRightPos As Integer)

        Dim sizStringSize, sngMyVal As Single

        sizStringSize = evPtPgEvArg.Graphics.MeasureString(strMessage, fonCurPrintFont).Width
        sngMyVal = (evPtPgEvArg.PageSettings.PaperSize.Width - sizStringSize - intRightPos)

        Return sngMyVal

    End Function

    Private Function RightSidePOS(strMessage As String)

        Dim sngMyVal As Single
        Dim sizStringSize As Single

        sizStringSize = evPtPgEvArg.Graphics.MeasureString(strMessage, fonCurPrintFont).Width
        sngMyVal = evPtPgEvArg.PageSettings.PaperSize.Width - sizStringSize

        Return sngMyVal

    End Function

    Private Function FixedPOS(strMessage As String, intPosition As Short)

        Dim sngMyVal As Single
        Dim sizStringSize As Single

        sizStringSize = evPtPgEvArg.Graphics.MeasureString(strMessage, fonCurPrintFont).Width
        sngMyVal = intPosition - sizStringSize

        Return sngMyVal

    End Function

    Private Sub PrintAt(strMessage As String, xPos As Single, yPos As Single)

        CurrentYPOSLast = CurrentYPOS
        evPtPgEvArg.Graphics.DrawString(strMessage, fonCurPrintFont, Brushes.Black, xPos, yPos)
        CurrentYPOS = yPos + evPtPgEvArg.Graphics.MeasureString(strMessage, fonCurPrintFont).Height

    End Sub

    Private Function TextHeight() As Single
        Return evPtPgEvArg.Graphics.MeasureString("A", fonCurPrintFont).Height
    End Function

    Private Sub PrintSummary(strFileName As String)

        Sleep(2000)
        Application.DoEvents()

        arrFilex = File.ReadAllLines(strFileName)

        Try

            Dim pdSummary As New PrintDocument()
            AddHandler pdSummary.PrintPage, AddressOf PrintSummaryDocument
            pdSummary.PrinterSettings.DefaultPageSettings.PaperSize = myPapersize
            pdSummary.PrinterSettings.PrinterName = GetAppSettingCS("PrinterShop1", "")
            pdSummary.Print()

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub PrintSummaryDocument(sender As Object, ev As PrintPageEventArgs)

        Dim intRPOS As Integer = GetAppSettingCS("SummaryRPOS", 80)
        Dim blnCDTTotals As Boolean = IIf(GetAppSettingCS("SummaryCDTTotals", 0) <> 0, True, False)
        Dim blnPrintDateTime As Boolean = IIf(GetAppSettingCS("SummaryPrintDate", 0) <> 0, True, False)

        Try

            evPtPgEvArg = ev

            fonCurPrintFont = New Font("Arial", 13, FontStyle.Bold)
            tempStr = GetAppSettingCS("BizName", "Your Business Summary")
            PrintAt(tempStr, CentrePOS(tempStr), 10)
            fonCurPrintFont = New Font("Arial", 11, FontStyle.Bold)
            tempStr = GFS("DateString")
            If tempStr.IndexOf(" - ") <> -1 Then
                PrintAt("Summary Report", CentrePOS("Summary Report"), CurrentYPOS)
                PrintAt(tempStr, CentrePOS(tempStr), CurrentYPOS)
            Else
                tempStr = "Summary Report - " & tempStr
                PrintAt(tempStr, CentrePOS(tempStr), CurrentYPOS)
            End If

            PrintAt(vbCrLf, 0, CurrentYPOS)

            fonCurPrintFont = New Font("Arial", 11, FontStyle.Regular)

            tempStr = "Total number of orders: " & Val(GFS("NumOrders")) : PrintAt(tempStr, 20, CurrentYPOS)
            PrintAt(vbCrLf, 0, CurrentYPOS)

            tempStr = "Collections: " & IIf(blnCDTTotals, Val(GFS("NumCollections")), "") : PrintAt(tempStr, 20, CurrentYPOS)
            tempStr = vbTab & "Cash = " & GFS("CCash") : PrintAt(tempStr, FromRightPOS(tempStr, intRPOS), CurrentYPOS)
            tempStr = vbTab & "Cards = " & GFS("CCard") : PrintAt(tempStr, FromRightPOS(tempStr, intRPOS), CurrentYPOS)
            tempStr = vbTab & "Other = " & GFS("COther") : PrintAt(tempStr, FromRightPOS(tempStr, intRPOS), CurrentYPOS)
            tempStr = vbTab & "Total = " & GFS("CTotal") : PrintAt(tempStr, FromRightPOS(tempStr, intRPOS), CurrentYPOS)
            PrintAt(vbCrLf, 0, CurrentYPOS)

            tempStr = "Deliveries: " & IIf(blnCDTTotals, Val(GFS("NumDeliveries")), "") : PrintAt(tempStr, 20, CurrentYPOS)
            tempStr = vbTab & "Cash = " & GFS("DCash") : PrintAt(tempStr, FromRightPOS(tempStr, intRPOS), CurrentYPOS)
            tempStr = vbTab & "Cards = " & GFS("DCard") : PrintAt(tempStr, FromRightPOS(tempStr, intRPOS), CurrentYPOS)
            tempStr = vbTab & "Other = " & GFS("DOther") : PrintAt(tempStr, FromRightPOS(tempStr, intRPOS), CurrentYPOS)
            tempStr = vbTab & "Total = " & GFS("DTotal") : PrintAt(tempStr, FromRightPOS(tempStr, intRPOS), CurrentYPOS)
            PrintAt(vbCrLf, 0, CurrentYPOS)

            tempStr = "Tables: " & IIf(blnCDTTotals, Val(GFS("NumTables")) & "  Covers: " & Val(GFS("TableCusts")), "") : PrintAt(tempStr, 20, CurrentYPOS)
            tempStr = vbTab & "Cash = " & GFS("TCash") : PrintAt(tempStr, FromRightPOS(tempStr, intRPOS), CurrentYPOS)
            tempStr = vbTab & "Cards = " & GFS("TCard") : PrintAt(tempStr, FromRightPOS(tempStr, intRPOS), CurrentYPOS)
            tempStr = vbTab & "Other = " & GFS("TOther") : PrintAt(tempStr, FromRightPOS(tempStr, intRPOS), CurrentYPOS)
            tempStr = vbTab & "Total = " & GFS("TTotal") : PrintAt(tempStr, FromRightPOS(tempStr, intRPOS), CurrentYPOS)
            PrintAt(vbCrLf, 0, CurrentYPOS)

            tempStr = "Total Cash = " & GFS("TotalCash") : PrintAt(tempStr, FromRightPOS(tempStr, intRPOS), CurrentYPOS)
            tempStr = "Total Cards = " & GFS("TotalCard") : PrintAt(tempStr, FromRightPOS(tempStr, intRPOS), CurrentYPOS)
            tempStr = "Total Other = " & GFS("TotalOther") : PrintAt(tempStr, FromRightPOS(tempStr, intRPOS), CurrentYPOS)
            tempStr = "All Totals = " & GFS("GrandTotal") : PrintAt(tempStr, FromRightPOS(tempStr, intRPOS), CurrentYPOS)
            PrintAt(vbCrLf, 0, CurrentYPOS)

            For jC = 1 To 6
                tempStr = GFS("OL" & jC)
                If tempStr <> "" And tempStr.IndexOf(":0.00") = -1 Then
                    tempStr = tempStr.Substring(0, tempStr.IndexOf(":")).Trim & " = " & tempStr.Substring(tempStr.IndexOf(":") + 1).Trim
                    PrintAt(tempStr, FromRightPOS(tempStr, intRPOS), CurrentYPOS)
                End If
            Next

            tempStr = GFS("OLTotals")
            If tempStr <> "" And tempStr <> "0.00" Then
                tempStr = "Total = " & GFS("OLTotals") : PrintAt(tempStr, FromRightPOS(tempStr, intRPOS), CurrentYPOS)
                tempStr = GFS("GrandCash")
                If tempStr <> "" Then
                    PrintAt(vbCrLf, 0, CurrentYPOS)
                    tempStr = "GT Cash = " & tempStr : PrintAt(tempStr, FromRightPOS(tempStr, intRPOS), CurrentYPOS)
                    tempStr = "GT Cards = " & GFS("GrandCards") : PrintAt(tempStr, FromRightPOS(tempStr, intRPOS), CurrentYPOS)
                    tempStr = "GT Other = " & GFS("GrandOther") : PrintAt(tempStr, FromRightPOS(tempStr, intRPOS), CurrentYPOS)
                    tempStr = "GT Total = " & GFS("GrandTotalTotal") : PrintAt(tempStr, FromRightPOS(tempStr, intRPOS), CurrentYPOS)
                End If
            End If

            If GFS("Tips") <> "0.00" Or GFS("Expenses") <> "0.00" Then PrintAt(vbCrLf, 0, CurrentYPOS)

            If GFS("Tips") <> "0.00" Then
                tempStr = "Tips = " & GFS("Tips") : PrintAt(tempStr, FromRightPOS(tempStr, intRPOS), CurrentYPOS)
            End If
            If GFS("Expenses") <> "0.00" Then
                tempStr = "Expenses = " & GFS("Expenses") : PrintAt(tempStr, FromRightPOS(tempStr, intRPOS), CurrentYPOS)
            End If

            PrintAt(vbCrLf, 0, CurrentYPOS)

            If blnPrintDateTime Then
                fonCurPrintFont = New Font("Arial", 10, FontStyle.Regular)
                tempStr = "Report generated:  " & Now.ToLongTimeString & " " & Now.ToShortDateString
                PrintAt(tempStr, CentrePOS(tempStr), CurrentYPOS)
            End If

            ev.HasMorePages = False

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub PrintBanking()

        Sleep(2000)
        Application.DoEvents()

        Try

            Dim pdBanking As New PrintDocument()
            AddHandler pdBanking.PrintPage, AddressOf PrintBankingDocument
            pdBanking.PrinterSettings.DefaultPageSettings.PaperSize = myPapersize
            pdBanking.PrinterSettings.PrinterName = GetAppSettingCS("PrinterShop1", "")
            pdBanking.Print()

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub PrintBankingDocument(sender As Object, ev As PrintPageEventArgs)

        Dim intRPOS As Integer = GetAppSettingCS("SummaryRPOS", 80)
        Dim blnPrintAllTots As Boolean = False

        evPtPgEvArg = ev

        Try
            fonCurPrintFont = New Font("Arial", 13, FontStyle.Bold)
            tempStr = GetAppSettingCS("BizName", "Daily Banking Report")
            PrintAt(tempStr, CentrePOS(tempStr), 10)
            fonCurPrintFont = New Font("Arial", 11, FontStyle.Regular)
            tempStr = "Daily Banking - " & Format(CDate(GFS("Date")), "ddd d MMM yyyy")
            PrintAt(tempStr, CentrePOS(tempStr), CurrentYPOS)
            PrintAt(vbCrLf, 0, CurrentYPOS)

            tempStr = "Cash: " & GFS("Cash")
            PrintAt(tempStr, FromRightPOS(tempStr, intRPOS), CurrentYPOS)
            tempStr = "Cards: " & GFS("Cards")
            PrintAt(tempStr, FromRightPOS(tempStr, intRPOS), CurrentYPOS)
            tempStr = "Other: " & GFS("Other")
            PrintAt(tempStr, FromRightPOS(tempStr, intRPOS), CurrentYPOS)
            tempStr = "Tips: " & GFS("Tips")
            PrintAt(tempStr, FromRightPOS(tempStr, intRPOS), CurrentYPOS)
            tempStr = "Total: " & GFS("Total")
            PrintAt(tempStr, FromRightPOS(tempStr, intRPOS), CurrentYPOS)

            If blnPrintAllTots = True AndAlso GFS("AllTotals") <> "0.00" Then
                tempStr = "All Totals: " & GFS("AllTotals")
                PrintAt(tempStr, FromRightPOS(tempStr, intRPOS), CurrentYPOS)
            End If

            PrintAt(vbCrLf, 0, CurrentYPOS)

            fonCurPrintFont = New Font("Arial", 10, FontStyle.Regular)
            tempStr = "Report generated:  " & Now.ToLongTimeString & " " & Now.ToShortDateString
            PrintAt(tempStr, CentrePOS(tempStr), CurrentYPOS)

            ev.HasMorePages = False

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub PrintReport()

        Sleep(2000)
        Application.DoEvents()

        Try
            Dim pdReport As New PrintDocument()
            AddHandler pdReport.PrintPage, AddressOf PrintReportDocument
            pdReport.PrinterSettings.DefaultPageSettings.PaperSize = myPapersize
            pdReport.PrinterSettings.PrinterName = GetAppSettingCS("PrinterShop1", "")
            pdReport.Print()

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub PrintReportDocument(sender As Object, ev As PrintPageEventArgs)

        Dim wLine As String
        Dim astrSplitItems() As String

        Dim pos1 = 115
        Dim int1 = 60

        evPtPgEvArg = ev

        Try
            fonCurPrintFont = New Font("Arial", 12, FontStyle.Bold)
            tempStr = GetAppSettingCS("BizName", "Banking Report")
            PrintAt(tempStr, CentrePOS(tempStr), 10)
            fonCurPrintFont = New Font("Arial", 11, FontStyle.Bold)
            tempStr = "Banking Report"
            PrintAt(tempStr, CentrePOS(tempStr), CurrentYPOS)
            tempStr = "Period: " & GFS("StartDate") & " - " & GFS("EndDate")
            PrintAt(tempStr, CentrePOS(tempStr), CurrentYPOS)
            PrintAt(vbCrLf, 0, CurrentYPOS)

            fonCurPrintFont = New Font("Arial", 10, FontStyle.Regular)
            PrintAt("Date", 28, CurrentYPOS)
            PrintAt("Cash", FixedPOS("Cash", pos1), CurrentYPOS - TextHeight())
            PrintAt("Card", FixedPOS("Card", pos1 + (1 * int1)), CurrentYPOS - TextHeight())
            PrintAt("Other", FixedPOS("Other", pos1 + (1.9 * int1)), CurrentYPOS - TextHeight())
            PrintAt("Total", FixedPOS("Total", pos1 + (2.8 * int1)), CurrentYPOS - TextHeight())

            Dim srdFile = New StreamReader(strFileNameFull)

            Do
                wLine = srdFile.ReadLine
                If (wLine IsNot Nothing And Left(wLine, 1) <> "#") Then
                    astrSplitItems = Split(wLine, ",")
                    tempStr = astrSplitItems(0)
                    PrintAt(tempStr, 0, CurrentYPOS) : CurrentYPOS = CurrentYPOSLast
                    tempStr = astrSplitItems(1)
                    PrintAt(tempStr, FixedPOS(tempStr, pos1), CurrentYPOS) : CurrentYPOS = CurrentYPOSLast
                    tempStr = astrSplitItems(2)
                    PrintAt(tempStr, FixedPOS(tempStr, pos1 + (1 * int1)), CurrentYPOS) : CurrentYPOS = CurrentYPOSLast
                    tempStr = astrSplitItems(3)
                    PrintAt(tempStr, FixedPOS(tempStr, pos1 + (1.9 * int1)), CurrentYPOS) : CurrentYPOS = CurrentYPOSLast
                    tempStr = astrSplitItems(5)
                    PrintAt(tempStr, FixedPOS(tempStr, pos1 + (2.8 * int1)), CurrentYPOS) ': CurrentYPOS = CurrentYPOSLast
                End If
            Loop Until (wLine Is Nothing)
            srdFile.Close()

            PrintAt(vbCrLf, 0, CurrentYPOS)

            fonCurPrintFont = New Font("Arial", 10, FontStyle.Regular)
            tempStr = "Report generated:  " & Now.ToLongTimeString & " " & Now.ToShortDateString
            PrintAt(tempStr, CentrePOS(tempStr), CurrentYPOS)

            ev.HasMorePages = False

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Function FileIsGood(sFile As String) As Boolean

        If File.Exists(sFile) Then
            Try
                Using f As New FileStream(sFile, FileMode.Open, FileAccess.ReadWrite, FileShare.None)
                    f.Close()
                    Return True
                End Using
            Catch ex As Exception
                Return False
            End Try
        Else
            Return False
        End If

    End Function

    Public Sub Wait4FileReady(strFName As String)

        Try
            'let this try for 5 secs before giving up
            Dim tmNowTime As Date = Date.Now.AddSeconds(5)
            Dim blnTimeOver As Boolean = False

            Do
                Application.DoEvents()
                Sleep(100)
                blnTimeOver = Date.Now > tmNowTime
            Loop Until FileIsGood(strFileNameFull) Or (blnTimeOver = True)

            If blnTimeOver = True Then
                Alert("Run out of time waiting for file to get ready:" & vbCrLf & strFName)
            End If

            'If objSecurity.IsMySystem() Then MsgBox("Wait4FileReady = " & xx)

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub NewOnlineOrder()

        Try

            Dim pdSummary As New PrintDocument()
            AddHandler pdSummary.PrintPage, AddressOf PrintNewOnlineOrder
            pdSummary.PrinterSettings.DefaultPageSettings.PaperSize = myPapersize
            pdSummary.PrinterSettings.PrinterName = GetAppSettingCS("PrinterShop1", "")
            pdSummary.Print()

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub PrintNewOnlineOrder(sender As Object, ev As PrintPageEventArgs)

        Try

            evPtPgEvArg = ev

            fonCurPrintFont = New Font("Arial", 12, FontStyle.Bold)
            tempStr = "* * * * * * * * * * * * * * * * * * *"
            PrintAt(tempStr, CentrePOS(tempStr), 0)
            tempStr = "* * * NEW ONLINE ORDER RECEIVED * * *"
            PrintAt(tempStr, CentrePOS(tempStr), CurrentYPOS)
            tempStr = "* * * * * * * * * * * * * * * * * * *"
            PrintAt(tempStr, CentrePOS(tempStr), CurrentYPOS)
            PrintAt(" " & vbCrLf, 0, CurrentYPOS)

            ev.HasMorePages = False

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Public Sub PrintDrinks(id As Short)

        Try
            sngTabUniqueID = id

            Dim pdSummary As New PrintDocument()
            AddHandler pdSummary.PrintPage, AddressOf PrintDrinksDocument
            pdSummary.PrinterSettings.DefaultPageSettings.PaperSize = myPapersize
            pdSummary.PrinterSettings.PrinterName = GetAppSettingCS("PrinterShop1", "")
            pdSummary.Print()

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Public Sub PrintDrinksDocument(sender As Object, ev As PrintPageEventArgs)

        Try
            evPtPgEvArg = ev
            CurrentYPOS = 10
            fonCurPrintFont = New Font("Arial", 11, FontStyle.Regular)
            tempStr = "Drinks for table " & CurTable & ":"
            PrintAt(tempStr, 0, CurrentYPOS)
            tempStr = ""    '"- - - - - - - - - - - - - - - - -"
            PrintAt(tempStr & vbCrLf, 0, CurrentYPOS)

            SQLQuery = "SELECT * FROM Table_Drinks WHERE TabUniqueID = " & sngTabUniqueID
            drcDatarowCollection = objDB.GetDataRows(SQLQuery)
            If (drcDatarowCollection IsNot Nothing) AndAlso (drcDatarowCollection.Count > 0) Then
                fonCurPrintFont = New Font("Arial", 11, FontStyle.Regular)
                For Each mrow In drcDatarowCollection
                    PrintAt(mrow!DkQty & " " & mrow!DkName, 10, CurrentYPOS)
                Next
            End If

            ev.HasMorePages = False

        Catch ex As Exception

        End Try

    End Sub

    Public Sub PrintSummaryGroups(udsDataSource As UltraDataSource)

        Try
            Dim pdSummary As New PrintDocument()

            udsSummaryDatasource = udsDataSource

            AddHandler pdSummary.PrintPage, AddressOf PrintSummaryGroupsDocument
            pdSummary.PrinterSettings.DefaultPageSettings.PaperSize = myPapersize
            pdSummary.PrinterSettings.PrinterName = GetAppSettingCS("PrinterShop1", "")
            pdSummary.Print()

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub PrintSummaryGroupsDocument(sender As Object, ev As PrintPageEventArgs)

        Try

            Dim dblTotal As Double = 0

            evPtPgEvArg = ev
            CurrentYPOS = 12
            fonCurPrintFont = New Font("Arial", 12, FontStyle.Regular)
            tempStr = "Summary for " & Now.ToShortDateString()
            PrintAt(tempStr, 0, CurrentYPOS)
            tempStr = ""    '"- - - - - - - - - - - - - - - - -"
            PrintAt(tempStr & vbCrLf, 0, CurrentYPOS)

            If (udsSummaryDatasource IsNot Nothing) AndAlso (udsSummaryDatasource.Rows.Count > 0) Then
                For Each mrow In udsSummaryDatasource.Rows
                    'tempStr = mrow!Sold & " x " & mrow!Group
                    tempStr = mrow!Group
                    PrintAt(tempStr, 10, CurrentYPOS)
                    tempStr = fixCur(mrow!Total)
                    PrintAt(tempStr, RightSidePOS(tempStr), CurrentYPOSLast)
                    dblTotal += CDbl(mrow!Total)
                Next
            End If

            'print total 
            tempStr = "- - - - - - -"
            PrintAt(tempStr, RightSidePOS(tempStr), CurrentYPOS)
            tempStr = dblTotal.ToString("#,0.00")
            PrintAt(tempStr, RightSidePOS(tempStr), CurrentYPOS + 0.2)

            ev.HasMorePages = False

        Catch ex As Exception

        End Try

    End Sub

End Module