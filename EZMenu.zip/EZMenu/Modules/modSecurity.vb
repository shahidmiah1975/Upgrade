﻿Imports System.Management

Module modSecurity

    Public Function ChallengeCode() As String

        Return objSecurity.MD5Hash(GetWMIValue()).ToUpper

    End Function

    Public Function GetWMIValue() As String

        Dim strWMIString As String = Now.Ticks.ToString

        Try
            strWMIString = GetWMI("Processor", "ProcessorId")
            If strWMIString = Nothing Then
                strWMIString = GetWMI("DiskDrive", "Model")
                If strWMIString = Nothing Then
                    strWMIString = GetWMI("BaseBoard", "Product")
                    If strWMIString = Nothing Then
                        strWMIString = Now.Ticks.ToString
                    End If
                End If
            End If
        Catch ex As Exception
        End Try

        Return strWMIString

    End Function

    Public Function GetWMI(strWin32, strPropertyName)

        Dim tmpStr2 As String = Nothing
        Dim blnExitLoops As Boolean = False

        Try
            Dim myScop As New ManagementScope("\\" & Environment.MachineName & "\root\cimv2")
            Dim oQuer As New SelectQuery("SELECT " & strPropertyName & " FROM WIN32_" & strWin32)
            Dim oResult As New ManagementObjectSearcher(myScop, oQuer)

            For Each oIte As ManagementObject In oResult.Get()
                For Each oPropert As PropertyData In oIte.Properties
                    If blnExitLoops = False Then
                        tmpStr2 = oIte(strPropertyName)
                        blnExitLoops = True
                    End If
                Next
            Next

        Catch ex As Exception
            DisplayError(ex)
        End Try

        Return tmpStr2

    End Function

    Public Function GetSuperFromDB() As Boolean

        Dim objLogin As New frmLogin("Manager")
        objLogin.ShowDialog()

        Return objLogin.AccessGranted

    End Function

End Module