﻿Imports EZMenu.Core.Enums

Module modPrint

    Private OrderA(10) As clsPrintOrderClass
    Private intOrderClass As Short
    Private gridRowIndex As Integer

    Public Sub PrintOrder(xOrderNumber As Short, printDestEnum As PrintDestinationEnum)

        OrderA(intOrderClass) = New clsPrintOrderClass

        If printDestEnum = PrintDestinationEnum.Shop Then
            OrderA(intOrderClass).Print(xOrderNumber, clsOrderPrintHandler.CopyType.ShopCopy, clsOrderPrintHandler.PLocation.PrinterShop)

        ElseIf printDestEnum = PrintDestinationEnum.Kitchen Then
            OrderA(intOrderClass).Print(xOrderNumber, clsOrderPrintHandler.CopyType.KitchenCopy, clsOrderPrintHandler.PLocation.PrinterKitchen)

        Else
            OrderA(intOrderClass).Print(xOrderNumber)

        End If

        OrderA(intOrderClass) = Nothing

        If intOrderClass >= 9 Then intOrderClass = 0 Else intOrderClass += 1

    End Sub

    Public Sub PrintTable(sTableUniqueID As Single, printDestEnum As PrintDestinationEnum)

        OrderA(intOrderClass) = New clsPrintOrderClass

        If printDestEnum = PrintDestinationEnum.Shop Then
            OrderA(intOrderClass).Print(sTableUniqueID, clsOrderPrintHandler.CopyType.ShopCopy, clsOrderPrintHandler.PLocation.PrinterShop)

        ElseIf printDestEnum = PrintDestinationEnum.Kitchen Then
            OrderA(intOrderClass).Print(sTableUniqueID, clsOrderPrintHandler.CopyType.KitchenCopy, clsOrderPrintHandler.PLocation.PrinterKitchen)

        Else
            OrderA(intOrderClass).Print(sTableUniqueID)

        End If

        OrderA(intOrderClass) = Nothing

        If intOrderClass >= 9 Then intOrderClass = 0 Else intOrderClass += 1

    End Sub

    Public Sub PrintLabels()
        'print dish name labels

        Dim ODish As String
        Dim arrDishLabels As New ArrayList

        Try
            Dim _strLabelPrinter As String = GetAppSettingCS("PrinterLabels" & intCurrentCuisine.ToString, "")
            If _strLabelPrinter = "" Then
                strMsgBox = "Label printer has not been set for this cuisine."
                Alert(strMsgBox)
                Exit Sub
            End If

            arrDishLabels.Clear()

            With objOrderEntry.ugdOrderGrid
                For Each mRow In .Rows
                    gridRowIndex = mRow.Index
                    If RowIsNotModOrSet(gridRowIndex) Then
                        ODish = .Rows(gridRowIndex).Cells("DName").Value.ToString.Punctuate

                        SQLQuery = $"SELECT d1.DishName, ds1.ShortName, d1.PrintLabel 				   
                                     FROM Dish d1 LEFT JOIN DishShortName ds1 ON d1.UniqueID = ds1.UniqueID
				                     WHERE d1.DishName = '{ ODish }'				                     
                                     UNION 
                                     SELECT d2.DishName, ds2.ShortName, d2.PrintLabel 
				                     FROM Dish d2 LEFT JOIN DishShortName ds2 ON d2.UniqueID = ds2.UniqueID 
				                     WHERE ds2.ShortName = '{ ODish }';"

                        drDataRow = objDB.GetSingleRow(SQLQuery)
                        If drDataRow IsNot Nothing Then
                            If Not IsDBNull(drDataRow!PrintLabel) AndAlso CShort(drDataRow!PrintLabel) <> 0 Then
                                For iLoop As Short = 1 To .Rows(gridRowIndex).Cells("DQty").Value
                                    arrDishLabels.Add(drDataRow!DishName)
                                Next
                            End If
                        Else
                            If GetAppSettingCS("LabelsPrintAny", True) Then
                                For iLoop As Short = 1 To .Rows(gridRowIndex).Cells("DQty").Value
                                    arrDishLabels.Add(ODish)
                                Next
                            End If
                        End If

                        'print any set (multi) labels
                        SQLQuery = $"SELECT s.LabelName, d.DishName 
                                     FROM Dish d INNER JOIN SetLabels s ON d.UniqueID = s.UniqueID 
                                     WHERE PrintLabelOnOff <> 0 AND d.DishName = '{ ODish }'"

                        Dim drcSetLabels As DataRowCollection = objDB.GetDataRows(SQLQuery)
                        If drcSetLabels IsNot Nothing Then
                            For Each myLabelRow As DataRow In drcSetLabels
                                For iLabel As Short = 1 To CInt(.Rows(gridRowIndex).Cells("DQty").Value)
                                    arrDishLabels.Add(myLabelRow!LabelName)
                                Next
                            Next
                        End If

                    End If
                Next
            End With

            If arrDishLabels.Count > 0 Then
                Dim cPrintLabels As New clsPrintLabels(arrDishLabels, intCurrentCuisine)
                cPrintLabels.PrintLabels()
                cPrintLabels = Nothing
            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

End Module
