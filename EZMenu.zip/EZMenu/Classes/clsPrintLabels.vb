﻿Imports System.Drawing.Printing
Imports System.ComponentModel

Public Class clsPrintLabels

    Private _arrLabels As ArrayList
    Private strLabelText, _strLabelPrinter As String
    Private _intPosition As Short = 0
    Private _intCurCuisine As Short = 1
    Private WithEvents bgwPrintLabels As BackgroundWorker

    Public Sub New(arrDishLabels As ArrayList, intCurrentCuisine As Short)
        _arrLabels = arrDishLabels
        _intCurCuisine = intCurrentCuisine
    End Sub

    Public Sub PrintLabels()

        Try
            _strLabelPrinter = GetAppSettingCS("PrinterLabels" & _intCurCuisine.ToString, "")

            bgwPrintLabels = New BackgroundWorker
            bgwPrintLabels.RunWorkerAsync()

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub bgwPrintLabels_DoWork(sender As Object, e As DoWorkEventArgs) Handles bgwPrintLabels.DoWork

        Try
            Dim pdReport As New PrintDocument()
            AddHandler pdReport.PrintPage, AddressOf PrintLabelsDoc
            pdReport.PrinterSettings.PrinterName = _strLabelPrinter
            pdReport.PrinterSettings.DefaultPageSettings.PaperSize = New PaperSize("EZLabel", mmTOhundrethsinch(GetAppSettingCS("LabelWidth", 19)), mmTOhundrethsinch(GetAppSettingCS("LabelHeight", 45)))  '19 x 51mm multi paper
            pdReport.PrinterSettings.DefaultPageSettings.Landscape = True
            pdReport.DefaultPageSettings.Margins.Left = mmTOhundrethsinch(GetAppSettingCS("LabelLeftMargin", 0))
            pdReport.DefaultPageSettings.Margins.Right = mmTOhundrethsinch(GetAppSettingCS("LabelLeftMargin", 0))
            pdReport.DefaultPageSettings.Margins.Top = mmTOhundrethsinch(GetAppSettingCS("LabelTopMargin", 0))
            pdReport.DefaultPageSettings.Margins.Bottom = mmTOhundrethsinch(GetAppSettingCS("LabelTopMargin", 0))
            pdReport.DefaultPageSettings.Landscape = True
            If GetAppSettingCS("HidePrintDialog" & _intCurCuisine.ToString, True) Then pdReport.PrintController = New StandardPrintController
            pdReport.Print()

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub PrintLabelsDoc(sender As Object, ev As PrintPageEventArgs)

        Dim sngStringWidth, sngStringHeight As Single
        Dim intPaperHeight, intPaperWidth As Integer
        Dim fonLabels = New Font("Arial", Single.Parse(GetAppSettingCS("LabelFontSize", 14)), FontStyle.Regular)

        Try
            strLabelText = _arrLabels(_intPosition).ToString.Trim
            If strLabelText.Length > 0 Then

                sngStringHeight = ev.Graphics.MeasureString(strLabelText, fonLabels).Height
                sngStringWidth = ev.Graphics.MeasureString(strLabelText, fonLabels).Width
                intPaperHeight = ev.PageSettings.PaperSize.Height
                intPaperWidth = ev.PageSettings.PaperSize.Width

                Dim layout_rect As New RectangleF(ev.MarginBounds.X, ev.MarginBounds.Y, ev.MarginBounds.Width -
                                                  GetAppSettingCS("LabelLeftOffset", 50), ev.MarginBounds.Height -
                                                  GetAppSettingCS("LabelTopOffset", 10))

                Dim string_format As New StringFormat With {
                    .Alignment = StringAlignment.Center,
                    .LineAlignment = StringAlignment.Center
                }
                ev.Graphics.DrawString(strLabelText, fonLabels, Brushes.Black, layout_rect, string_format)

                ev.HasMorePages = (_intPosition < _arrLabels.Count - 1)
                _intPosition += 1

            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Function mmTOhundrethsinch(var_mm)
        Return var_mm / 0.254
    End Function

End Class