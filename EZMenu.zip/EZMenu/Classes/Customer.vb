﻿Imports EZControls

Public Class Customer

    Public LastOrder As Date?
    Public FirstOrdered As Date?
    Public NumberOfOrders As Short
    Public HasValue As Boolean = False
    Private SQLQueryCust As String

    Public Property CustomerId
    Public Property Name
    Public Property Address1
    Public Property Address2
    Public Property Address3
    Public Property Postcode
    Public Property Telephone
    Public Property Mobile
    Public Property Email

    Public Sub New()
    End Sub

    Public Sub New(_CustomerID As Short)

        SQLQueryCust = $"SELECT * FROM Customer WHERE CustomerID = '{ _CustomerID }';"
        Dim drCustomerx As DataRow = objDB.GetSingleRow(SQLQueryCust)
        If drCustomerx IsNot Nothing Then
            CustomerId = _CustomerID
            Name = drCustomerx("Name").ToString()
            Address1 = drCustomerx("Address1").ToString
            Address2 = drCustomerx("Address2").ToString
            Address3 = drCustomerx("Address3").ToString
            Postcode = drCustomerx("Postcode").ToString
            Telephone = drCustomerx("Phone").ToString
            Mobile = drCustomerx("Mobile").ToString
            Email = drCustomerx("Email").ToString
            If IsDate(drCustomerx("LastOrder")) Then LastOrder = CDate(drCustomerx("LastOrder"))
            If IsDate(drCustomerx("FirstOrdered")) Then FirstOrdered = CDate(drCustomerx("FirstOrdered"))
            If Not IsDBNull(drCustomerx("NumOrders")) Then NumberOfOrders = CInt(drCustomerx("NumOrders").ToString)
            HasValue = True
        End If


    End Sub

    Public Sub Delete(IDCustomer As Short)
        'Delete a customer from the database

        Try

            If IDCustomer = 0 Then
                strMsgBox = "Customer details have not been retrieved from the database and therefore cannot be deleted."
                EZMsgBox.Show(strMsgBox, MessageBoxButtons.OK, MessageBoxIcon.Error)

            Else
                'form query to delete info in Orders and Order Details tables...
                SQLQueryCust = $"SELECT * FROM Orders WHERE CustomerID = { IDCustomer } AND (BizId BETWEEN 40 AND 60)"
                drcDatarowCollection = objDB.GetDataRows(SQLQueryCust)
                If drcDatarowCollection.Count > 0 Then
                    '...now delete everything in Order Details
                    For Each drow As DataRow In drcDatarowCollection
                        SQLQueryCust = "DELETE FROM OrderDetails WHERE OrderID = " & drow("OrderID")
                        objDB.ExeNonQuery(SQLQueryCust)
                    Next
                    SQLQueryCust = $"DELETE FROM Orders WHERE CustomerID = { IDCustomer } AND (BizId BETWEEN 40 AND 60)"
                    objDB.ExeNonQuery(SQLQueryCust)
                End If

                'delete customer's previous order
                objDB.ExeNonQuery($"DELETE FROM CustOrders WHERE CustomerID = { IDCustomer }")
                objDB.ExeNonQuery($"DELETE FROM CustOrderDetails WHERE CustomerID = { IDCustomer }")

                'delete all alternative phone numbers that match this number
                SQLQueryCust = $"SELECT Phone FROM Customer WHERE CustomerID = { IDCustomer }"
                drDataRow = objDB.GetSingleRow(SQLQueryCust)
                If drDataRow IsNot Nothing Then
                    If drDataRow!Phone <> "" Then
                        SQLQueryCust = $"DELETE FROM [Alternative Phone] WHERE Phone = '{ drDataRow!Phone }';"
                        objDB.ExeNonQuery(SQLQueryCust)
                    End If
                End If

                objDB.ExeNonQuery($"DELETE FROM NotesDB WHERE CustomerID = { IDCustomer }")
                objDB.ExeNonQuery($"DELETE FROM Directions WHERE CustomerID = { IDCustomer }")
                objDB.ExeNonQuery($"DELETE FROM Customer WHERE CustomerID = { IDCustomer }")

            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Public Sub Update(name As String,
                      address1 As String,
                      address2 As String,
                      address3 As String,
                      postcode As String,
                      telephone As String,
                      mobile As String,
                      email As String)

        Try
            SQLQueryCust = $"UPDATE Customer 
                             SET Name = '{ name.Trim.Punctuate }', 
                                 Address1 = '{ address1.Trim.Punctuate }', 
                                 Address2 = '{ address2.Trim.Punctuate }',
                                 Address3 = '{ address3.Trim.Punctuate }', 
                                 Postcode = '{ postcode.Trim }', 
                                 Phone = '{ telephone.Trim }', 
                                 Mobile = '{ mobile.Trim }', 
                                 Email = '{ email.Trim }' 
                             WHERE CustomerID = { CustomerId }"

            objDB.ExeNonQuery(SQLQueryCust)

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Public Sub Insert()

        Try
            SQLQueryCust = $"INSERT INTO Customer (Name, Address1, Address2, Address3, Postcode, Phone, Mobile, Email, FirstOrdered, LastOrder) 
                             VALUES ('{Name}', '{Address1}', '{Address2}', '{Address3}', '{Postcode}', '{Telephone}', '{Mobile}', '{Email}', '{GetDateNow()}', NULL)"

            objDB.ExeNonQuery(SQLQueryCust)

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Public Sub AddCollector()

        SQLQueryCust = $"DELETE FROM Collector WHERE Phone = '{Telephone}';"
        objDB.ExeNonQuery(SQLQueryCust)

        SQLQueryCust = $"INSERT INTO Collector (Name, Phone, Email) VALUES ('{Name}', '{Telephone}', '{Email}');"
        objDB.ExeNonQuery(SQLQueryCust)

    End Sub

    Friend Shared Sub InsertAltPhone(phoneNumber As String, altNumber As String, Optional prompt As Boolean = False)

        Dim strSQL As String = $"DELETE FROM [Alternative Phone] 
                                 WHERE Phone = '{phoneNumber}'"
        objDB.ExeNonQuery(strSQL)

        strSQL = $"INSERT INTO [Alternative Phone] (Phone, AltPhone) 
                   VALUES ('{phoneNumber}', '{altNumber}')"
        objDB.ExeNonQuery(strSQL)

        If prompt = True Then
            strMsgBox = "Phone number has been saved"
            EZMsgBox.Show(strMsgBox, MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If

    End Sub

    Public Sub GetCustomer(phoneNumber As String)

        SQLQueryCust = $"SELECT * 
                         FROM Customer 
                         WHERE Phone = ' {phoneNumber}';"

        Dim drCustomerx As DataRow = objDB.GetSingleRow(SQLQueryCust)
        If drCustomerx IsNot Nothing Then
            CustomerId = CShort(drCustomerx("CustomerID"))
            Name = drCustomerx("Name").ToString()
            Address1 = drCustomerx("Address1").ToString
            Address2 = drCustomerx("Address2").ToString
            Address3 = drCustomerx("Address3").ToString
            Postcode = drCustomerx("Postcode").ToString
            Telephone = phoneNumber
            Mobile = drCustomerx("Mobile").ToString
            Email = drCustomerx("Email").ToString
            If IsDate(drCustomerx("LastOrder")) Then LastOrder = CDate(drCustomerx("LastOrder"))
            If IsDate(drCustomerx("FirstOrdered")) Then FirstOrdered = CDate(drCustomerx("FirstOrdered"))
            If Not IsDBNull(drCustomerx("NumOrders")) Then NumberOfOrders = CInt(drCustomerx("NumOrders").ToString)
            HasValue = True
        End If

    End Sub

    Public Function GetCustomerNote() As String

        SQLQuery = $"SELECT * 
                     FROM NotesDB 
                     WHERE CustomerID = { CustomerId }"

        drDataRow = objDB.GetSingleRow(SQLQuery)
        If drDataRow IsNot Nothing Then
            Return drDataRow!Message.ToString.Trim
        Else
            Return String.Empty
        End If

    End Function

    Public Function GetCustomerDirections() As String

        SQLQuery = $"SELECT * 
                     FROM Directions 
                     WHERE CustomerID = { CustomerId }"

        drDataRow = objDB.GetSingleRow(SQLQuery)
        If drDataRow IsNot Nothing Then
            Return drDataRow!Directions.ToString.Trim
        Else
            Return String.Empty
        End If

    End Function

    Friend Sub DeleteDirections()
        objDB.ExeNonQuery("DELETE FROM Directions WHERE CustomerID = " & CustomerId)
    End Sub

    Friend Sub AddDirections(directions As String)
        objDB.ExeNonQuery($"INSERT INTO Directions (CustomerID, Directions) VALUES ({CustomerId}, '{directions.Punctuate}')")
    End Sub

    Friend Sub DeleteNotes()
        objDB.ExeNonQuery($"DELETE FROM NotesDB WHERE CustomerID = { CustomerId}")
    End Sub

    Friend Sub AddNotes(notes As String)
        objDB.ExeNonQuery("INSERT INTO NotesDB (CustomerID, Message) VALUES (" & CustomerId & ", '" & notes.Punctuate & "')")
    End Sub

    Friend Shared Sub MergeGroup()

        SQLQuery = $"WITH cte AS 
                    (SELECT ROW_NUMBER() OVER (PARTITION BY [Name], [Address1], [Address2], [Address3], [Postcode] 
                    ORDER BY [CustomerID] ASC) RN 
                    FROM  [Customer]) 
                    DELETE FROM cte WHERE RN > 1"
        objDB.ExeNonQuery(SQLQuery)
        objDB.ReseedTable("Customer", "Max")

    End Sub

End Class