﻿Imports System.Configuration
Imports System.Data.SqlClient
Imports EZMenu.Core
Imports EZMenu.Core.Enums

Public Class clsDatabase

    Private orderNumberDB As Short
    Private currentOrderTypeDB As OrderTypeEnum
    Private tableUniqueIDDB As Short
    Private gridRowIndex As Integer

    Public Sub New()

    End Sub

    Public Sub New(currentOrderType As OrderTypeEnum, orderOrTableNumber As Short)

        currentOrderTypeDB = currentOrderType

        If currentOrderTypeDB = OrderTypeEnum.Table Then
            tableUniqueIDDB = orderOrTableNumber
        Else
            orderNumberDB = orderOrTableNumber
        End If

    End Sub

    Public Function GetConnectionString(strQueryString As String) As String

        If strQueryString.Contains(" Postcodes ") Then
            Return ConfigurationManager.ConnectionStrings(EZConstants.AFDConnectionString).ConnectionString
        Else
            Return ConfigurationManager.ConnectionStrings(EZConstants.EZDatabaseConnectionString).ConnectionString
        End If

    End Function

    Protected Overrides Sub Finalize()
        MyBase.Finalize()
    End Sub

    <DebuggerStepThrough()>
    Public Function GetSingleRow(queryString As String) As DataRow

        Try
            Dim tmpDataset As New DataSet

            Using connection As New SqlConnection(GetConnectionString(queryString))
                Using adapter As New SqlDataAdapter With {.SelectCommand = New SqlCommand(queryString, connection)}
                    adapter.Fill(tmpDataset)
                    If tmpDataset.Tables(0).Rows.Count > 0 Then
                        Return tmpDataset.Tables(0).Rows(0)
                    Else
                        Return Nothing
                    End If
                End Using
            End Using

        Catch ex As Exception
            DisplayError(ex, queryString)
            Return Nothing

        End Try

    End Function

    <DebuggerStepThrough()>
    Public Function GetDataTable(queryString As String) As DataTable

        Dim strConnString As String = GetConnectionString(queryString)
        Dim tmpDataset As New DataSet

        Try
            Using connection As New SqlConnection(strConnString)
                Using cmd As New SqlCommand(queryString, connection)
                    Using da As New SqlDataAdapter(cmd)
                        da.Fill(tmpDataset)
                    End Using
                End Using
            End Using

            Return tmpDataset.Tables(0)

        Catch ex As Exception
            DisplayError(ex, queryString)
            Return Nothing
        End Try

    End Function

    <DebuggerStepThrough()>
    Public Function GetDataSet(queryString As String) As DataSet

        Dim strConnString As String = GetConnectionString(queryString)
        Dim tmpDataset As New DataSet

        Try
            Using connection As New SqlConnection(strConnString)
                Using cmd As New SqlCommand(queryString, connection)
                    Using da As New SqlDataAdapter(cmd)
                        da.Fill(tmpDataset)
                    End Using
                End Using
            End Using

            Return tmpDataset

        Catch ex As Exception
            DisplayError(ex, queryString)
            Return Nothing
        End Try

    End Function

    <DebuggerStepThrough()>
    Public Function GetDataRows(queryString As String) As DataRowCollection

        Try
            Return GetDataTable(queryString).Rows

        Catch ex As Exception
            DisplayError(ex, queryString)
            Return Nothing
        End Try

    End Function

    Public Sub SaveOrderModsToDB(dishrownum As Integer, intOrderID As Short, strDishName As String)

        Dim modString As String = GetAnyModifiers(dishrownum)
        If modString <> String.Empty Then
            Dim arrMods() = modString.Split("^^")
            For aCnt = arrMods.GetLowerBound(0) To arrMods.GetUpperBound(0)
                If arrMods(aCnt) <> String.Empty Then
                    modString = arrMods(aCnt)
                    Dim h As Short = InStr(modString, "#")
                    Dim mDesc = Left(modString, h - 1).Trim
                    Dim mPrice = Mid(modString, h + 1).Trim
                    SQLQuery = String.Format("INSERT INTO OrderMods (OrderID, DishName, ModDesc, Cost) " &
                                             "VALUES ({0}, '{1}', '{2}', {3})", intOrderID, strDishName.Punctuate, mDesc.Punctuate, mPrice)
                    objDB.ExeNonQuery(SQLQuery)
                End If
            Next
        End If

    End Sub

    Public Function GetOrderModsFromDB(intOrderID As Short, strDishName As String)

        SQLQuery = $"SELECT * FROM OrderMods 
                     WHERE OrderID = {intOrderID } AND DishName = '{strDishName.Punctuate }'"
        drcDatarowCollection = objDB.GetDataRows(SQLQuery)
        If drcDatarowCollection IsNot Nothing Then
            Dim strModString As String = String.Empty
            For Each drRow As DataRow In drcDatarowCollection
                strModString &= drRow("ModDesc") & "#" & drRow("Cost") & "^^"
            Next
            If strModString.EndsWith("^^") Then strModString = strModString.Substring(0, strModString.Length - 2)
            Return strModString
        End If

        Return String.Empty

    End Function

    Public Sub SaveSetItemsToDB(dishrownum As Integer, intOrderID As Short, strDishName As String)

        Dim strSetItems As String = GetSetItemsInGrid(dishrownum)
        If strSetItems <> String.Empty Then
            Dim arrEachString() = strSetItems.Split("^^")
            For aCnt = arrEachString.GetLowerBound(0) To arrEachString.GetUpperBound(0)
                If arrEachString(aCnt) <> String.Empty Then
                    Dim arrSetItems() = arrEachString(aCnt).Split("#")
                    SQLQuery = $"INSERT INTO SetItems (OrderID, Qty, DishName, SetDesc, SetPrice) 
                                 VALUES ({intOrderID}, {arrSetItems(0)}, '{strDishName}', '{arrSetItems(1).Punctuate}', {arrSetItems(2).Punctuate})"
                    objDB.ExeNonQuery(SQLQuery)
                End If
            Next
        End If

    End Sub

    Public Sub SaveTableSetItemsToDB(dishrownum As Integer, sngTabUID As Single, strDishName As String)

        Dim strSetItems As String = GetSetItemsInGrid(dishrownum)
        If strSetItems <> String.Empty Then
            Dim arrEachString() = strSetItems.Split("^^")
            For aCnt = arrEachString.GetLowerBound(0) To arrEachString.GetUpperBound(0)
                If arrEachString(aCnt) <> String.Empty Then
                    Dim arrSetItems() = arrEachString(aCnt).Split("#")
                    SQLQuery = String.Format("INSERT INTO SetItems (OrderID, Qty, DishName, SetDesc, SetPrice) " &
                                             "VALUES ({0}, {1}, '{2}', '{3}', {4})",
                                             sngTabUID, arrSetItems(0), strDishName, arrSetItems(1).Punctuate, arrSetItems(2).Punctuate)
                    objDB.ExeNonQuery(SQLQuery)
                End If
            Next
        End If

    End Sub

    Public Function GetSetItemsFromDB(intOrderID As Short, strDishName As String) As String

        SQLQuery = $"SELECT * FROM SetItems WHERE OrderID = {intOrderID } AND DishName = '{strDishName.Punctuate }'"
        drcDatarowCollection = objDB.GetDataRows(SQLQuery)
        If drcDatarowCollection IsNot Nothing Then
            Dim strSetString As String = String.Empty
            For Each drRow As DataRow In drcDatarowCollection
                strSetString &= drRow("Qty") & "#" & drRow("SetDesc") & "#" & drRow("SetPrice") & "^^"
            Next
            If strSetString.EndsWith("^^") Then strSetString = strSetString.Substring(0, strSetString.Length - 2)
            Return strSetString
        End If

        Return String.Empty

    End Function

    Public Sub CleanupDB()

        Try
            'need to delete all orders and their details from the database
            objDB.ExeNonQuery("TRUNCATE TABLE OrderMods")
            objDB.ExeNonQuery("TRUNCATE TABLE OrderItems")
            objDB.ExeNonQuery("TRUNCATE TABLE Orders")
            objDB.ExeNonQuery("TRUNCATE TABLE OrdersCardDetails")
            objDB.ExeNonQuery("TRUNCATE TABLE OrdersDiscCharges")
            objDB.ExeNonQuery("TRUNCATE TABLE SetItems")
            objDB.ExeNonQuery("TRUNCATE TABLE CollectionDrinks")
            'ReseedTable("Orders", "0")

            'delete tables
            objDB.ExeNonQuery("TRUNCATE TABLE Table_Meal")
            objDB.ExeNonQuery("TRUNCATE TABLE Table_Drinks")
            objDB.ExeNonQuery("TRUNCATE TABLE Table_Bill")
            objDB.ExeNonQuery("TRUNCATE TABLE Table_Mods")

            'delete caller ID log
            objDB.ExeNonQuery("TRUNCATE TABLE CallerIDLog")

            'reset tables unique IDs
            For iCntr = 1 To UBound(TableInfo)
                TableInfo(iCntr).Id = 0
                TableInfo(iCntr).Status = TStatusEnum.Clean
            Next

            For Each foundFile As String In My.Computer.FileSystem.GetFiles(Application.StartupPath & "\call_logs", FileIO.SearchOption.SearchTopLevelOnly, "*.*")
                My.Computer.FileSystem.DeleteFile(foundFile, FileIO.UIOption.OnlyErrorDialogs, FileIO.RecycleOption.DeletePermanently)
            Next

            objDB.ExeNonQuery("DBCC SHRINKFILE('EZMENU_LOG', 1)")

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Public Sub ReseedTable(strTableName As String, strZeroOrMax As String)

        Dim intReseed As Integer = 0

        Try
            If strZeroOrMax <> "0" Then
                SQLQuery = "SELECT MAX(CustomerID) AS MaxID FROM Customer"
                drDataRow = objDB.GetSingleRow(SQLQuery)
                If drDataRow IsNot Nothing Then
                    intReseed = CInt(Val(drDataRow.Item(0).ToString))
                Else
                    intReseed = 0
                End If
            End If

            SQLQuery = $"DBCC CHECKIDENT ('{strTableName }', RESEED, {intReseed })"
            objDB.ExeNonQuery(SQLQuery)

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Public Sub ReseedTableNew(strTableName As String, strColumnName As String)

        Dim intReseed As Short

        Try
            SQLQuery = $"SELECT MAX({strColumnName }) AS MaxID FROM {strTableName }"
            drDataRow = objDB.GetSingleRow(SQLQuery)
            If drDataRow IsNot Nothing Then
                intReseed = Val(drDataRow.Item(0).ToString)
            Else
                intReseed = 0
            End If

            SQLQuery = $"DBCC CHECKIDENT ('{strTableName }', RESEED, {intReseed })"
            objDB.ExeNonQuery(SQLQuery)

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    '<DebuggerStepThrough()>
    Public Function EZSettingRead(strSetting As String) As String

        Dim strConnString As String = GetAppSettingCS("EZConnectionString", My.Settings.EZConnectionString.ToString)
        Dim queryString As String = $"SELECT EZValue FROM Settings WHERE SystemID = '{GetSystemIDFromConfig()}' AND EZHash = '{objSecurity.MD5Hash_ThenSplitAndSwap(strSetting)}'"
        Dim tmpDataset As New DataSet
        Dim adapter As New SqlDataAdapter

        Try
            Using connection As New SqlConnection(strConnString)
                adapter.SelectCommand = New SqlCommand(queryString, connection)
                adapter.Fill(tmpDataset)
                If tmpDataset.Tables(0).Rows.Count > 0 Then
                    If strSetting = "SystemID" AndAlso objSecurity.IsMySystem() Then
                        Return objSecurity.AES_Encrypt("EZTANDOORI")
                    Else
                        Return tmpDataset.Tables(0).Rows(0)(0)
                    End If
                Else
                    Return Nothing
                End If
            End Using
        Catch ex As Exception
            DisplayError(ex)
            Return Nothing
        End Try

    End Function

    '<DebuggerStepThrough()>
    Public Sub EZSettingWrite(strEZHash As String, strValue As String)

        SQLQuery = $"UPDATE Settings 
                     SET EZValue = '{strValue}' 
                     WHERE SystemID = '{GetSystemIDFromConfig()}'
                        AND EZHash = '{objSecurity.MD5Hash_ThenSplitAndSwap(strEZHash)}'"

        objDB.ExeNonQuery(SQLQuery)

    End Sub

    <DebuggerStepThrough()>
    Public Sub ExeNonQuery(queryString As String)

        Dim strConnString As String = objDB.GetConnectionString(queryString)

        intRowsAffected = 0
        blnSQLSuccess = False

        Using connection As New SqlConnection(strConnString)

            Try
                Using command As New SqlCommand(queryString, connection)

                    command.CommandTimeout = 120

                    connection.Open()
                    intRowsAffected = command.ExecuteNonQuery()
                    Application.DoEvents()

                    Try
                        idIdentity = Nothing
                        If queryString.Contains("INSERT INTO") Then
                            command.CommandText = "SELECT SCOPE_IDENTITY()"
                            idIdentity = command.ExecuteScalar().ToString
                        End If

                    Catch ex As Exception
                        'nothing to do here
                    End Try

                    connection.Close()
                    blnSQLSuccess = True
                End Using

            Catch ex As Exception
                DisplayError(ex, queryString)
            End Try

        End Using

    End Sub

    Friend Function GetGroupIndex(dName As String) As Object

        Dim SQLString As String = $"SELECT GroupIndex
                                    FROM Dish d
	                                LEFT JOIN Groups g
                                        On d.GroupName = g.GroupName
                                    WHERE DishName = '{dName}'"

        drDataRow = GetSingleRow(SQLString)
        If drDataRow IsNot Nothing Then
            Return CInt(Val(drDataRow.Item(0).ToString))
        Else
            Return 0
        End If

    End Function

    Public Sub SaveCallLog(varID, varTime, varPhone)

        If varPhone <> String.Empty Then varPhone = FormatPhone(varPhone)
        SQLQuery = $"INSERT INTO CallerIDLog (ID, CallTime, Phone) VALUES ({varID}, '{varTime}', '{varPhone}')"
        objDB.ExeNonQuery(SQLQuery)

    End Sub

    Public Function ReadDB(strFieldToGet As String) As String

        If currentOrderTypeDB = OrderTypeEnum.Collection Or currentOrderTypeDB = OrderTypeEnum.Delivery Then
            Return ReadOrdersDB(strFieldToGet)
        ElseIf currentOrderTypeDB = OrderTypeEnum.Table Then
            Return ReadTablesDB(strFieldToGet)
        End If

        Return Nothing

    End Function

    Public Function ReadOrdersDB(strFieldName As String)

        Try
            Dim drOrdersDB As DataRow
            Dim query As String = "SELECT " & strFieldName & " FROM Orders WHERE OrderID = " & orderNumberDB
            drOrdersDB = objDB.GetSingleRow(query)
            If drOrdersDB Is Nothing Then
                Return Nothing
            ElseIf IsDBNull(drOrdersDB(0)) Then
                Return String.Empty
            ElseIf drOrdersDB(0).ToString = "True" Or drOrdersDB(0).ToString = "False" Then
                Return Boolean.Parse(drOrdersDB(0))
            ElseIf IsANumber(drOrdersDB(0).ToString) Then
                Return drOrdersDB(0)
            Else
                Return drOrdersDB(0).ToString
            End If

        Catch ex As Exception
            DisplayError(ex)
            Return Nothing
        End Try

    End Function

    Public Function ReadOrdersDiscChargesDB(strFieldName As String)

        Try
            Dim drOrdersDB As DataRow
            Dim query As String = "SELECT " & strFieldName & " FROM OrdersDiscCharges WHERE OrderID = " & orderNumberDB
            drOrdersDB = objDB.GetSingleRow(query)
            If drOrdersDB Is Nothing Then
                Return "0.00"
            ElseIf IsDBNull(drOrdersDB(0)) Then
                Return String.Empty
            ElseIf drOrdersDB(0).ToString = "True" Or drOrdersDB(0).ToString = "False" Then
                Return Boolean.Parse(drOrdersDB(0))
            ElseIf IsANumber(drOrdersDB(0).ToString) Then
                Return drOrdersDB(0)
            Else
                Return drOrdersDB(0).ToString
            End If

        Catch ex As Exception
            DisplayError(ex)
            Return Nothing
        End Try

    End Function

    Public Function ReadTablesDB(strFieldName As String)

        Dim query As String = $"SELECT {strFieldName} FROM Table_Bill WHERE TabUniqueID = {tableUniqueIDDB}"
        drDataRow = objDB.GetSingleRow(query)
        If drDataRow Is Nothing Then
            Return Nothing
        ElseIf IsDBNull(drDataRow(0)) Then
            Return String.Empty
        ElseIf drDataRow(0).ToString = "True" Or drDataRow(0).ToString = "False" Then
            Return Boolean.Parse(drDataRow(0))
        ElseIf IsANumber(drDataRow(0)) Then
            Return Val(drDataRow(0))
        Else
            Return drDataRow(0).ToString
        End If

    End Function

End Class
