﻿Imports EZControls

Public Class clsCustomer

    'Public CustomerId As Short
    Public LastOrder As Date?
    Public FirstOrdered As Date?
    Public NumberOfOrders As Short
    Public HasValue As Boolean = False

    Private _CustID As Short
    Private SQLQueryCust As String
    Private _cName As String
    Private _cAddress1 As String
    Private _cAddress2 As String
    Private _cAddress3 As String
    Private _cPostcode As String
    Private _cTelephone As String
    Private _cMobile As String
    Private _cEmail As String

    Public Property CustomerId
        Get
            Return _CustID
        End Get
        Set(value)
            _CustID = value
        End Set
    End Property
    Public Property Name
        Get
            Return _cName
        End Get
        Set(value)
            _cName = value
        End Set
    End Property
    Public Property Address1
        Get
            Return _cAddress1
        End Get
        Set(value)
            _cAddress1 = value
        End Set
    End Property
    Public Property Address2
        Get
            Return _cAddress2
        End Get
        Set(value)
            _cAddress2 = value
        End Set
    End Property
    Public Property Address3
        Get
            Return _cAddress3
        End Get
        Set(value)
            _cAddress3 = value
        End Set
    End Property
    Public Property Postcode
        Get
            Return _cPostcode
        End Get
        Set(value)
            _cPostcode = value
        End Set
    End Property
    Public Property Telephone
        Get
            Return _cTelephone
        End Get
        Set(value)
            _cTelephone = value
        End Set
    End Property
    Public Property Mobile
        Get
            Return _cMobile
        End Get
        Set(value)
            _cMobile = value
        End Set
    End Property
    Public Property Email
        Get
            Return _cEmail
        End Get
        Set(value)
            _cEmail = value
        End Set
    End Property

    Public Sub New()
    End Sub

    Public Sub New(_CustomerID As Short)

        SQLQueryCust = $"SELECT * FROM Customer WHERE CustomerID = '{ _CustomerID }';"
        Dim drCustomerx As DataRow = objDB.GetSingleRow(SQLQueryCust)
        If drCustomerx IsNot Nothing Then
            CustomerId = _CustomerID
            _CustID = CustomerId
            Name = drCustomerx("Name").ToString()
            Address1 = drCustomerx("Address1").ToString
            Address2 = drCustomerx("Address2").ToString
            Address3 = drCustomerx("Address3").ToString
            Postcode = drCustomerx("Postcode").ToString
            Telephone = drCustomerx("Phone").ToString
            Mobile = drCustomerx("Mobile").ToString
            Email = drCustomerx("Email").ToString
            If IsDate(drCustomerx("LastOrder")) Then LastOrder = CDate(drCustomerx("LastOrder"))
            If IsDate(drCustomerx("FirstOrdered")) Then FirstOrdered = CDate(drCustomerx("FirstOrdered"))
            If Not IsDBNull(drCustomerx("NumOrders")) Then NumberOfOrders = CInt(drCustomerx("NumOrders").ToString)
            HasValue = True
        End If

    End Sub

    Public Sub Update(strName As String,
                      strAddress1 As String,
                      strAddress2 As String,
                      strAddress3 As String,
                      strPostcode As String,
                      strTelephone As String,
                      strMobile As String,
                      strEmail As String)

        Try
            SQLQueryCust = $"UPDATE Customer 
                             SET Name = '{strName.Trim.Punctuate }', 
                                 Address1 = '{strAddress1.Trim.Punctuate }', 
                                 Address2 = '{strAddress2.Trim.Punctuate }', 
                                 Address3 = '{strAddress3.Trim.Punctuate }', 
                                 Postcode = '{strPostcode.Trim }', 
                                 Phone = '{strTelephone.Trim }', 
                                 Mobile = '{strMobile.Trim }', 
                                 Email = '{strEmail.Trim }' 
                             WHERE CustomerID = {_CustID }"

            objDB.ExeNonQuery(SQLQueryCust)

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Public Sub Insert()

        Try
            SQLQueryCust = String.Format("INSERT INTO Customer (Name, Address1, Address2, Address3, Postcode, Phone, Mobile, Email, FirstOrdered, LastOrder) " &
                                     "VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', NULL)",
                                     _cName, _cAddress1, _cAddress2, _cAddress3, _cPostcode, _cTelephone, _cMobile, _cEmail, GetDateNow)

            objDB.ExeNonQuery(SQLQueryCust)

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Public Sub AddCollector()

        SQLQueryCust = $"DELETE FROM Collector WHERE Phone='{_cTelephone}';"
        objDB.ExeNonQuery(SQLQueryCust)

        SQLQueryCust = $"INSERT INTO Collector (Name, Phone, Email) VALUES ('{_cName}', '{_cTelephone}', '{_cEmail}');"
        objDB.ExeNonQuery(SQLQueryCust)

    End Sub

    Friend Shared Sub InsertAltPhone(PhoneNumberx As String, AltPhonex As String, Optional blnPrompt As Boolean = False)

        Dim strSQL As String = $"DELETE FROM AlternativePhone WHERE Phone = '{PhoneNumberx}'"
        objDB.ExeNonQuery(strSQL)

        strSQL = $"INSERT INTO AlternativePhone (Phone, AltPhone) VALUES ('{PhoneNumberx}', '{AltPhonex}')"
        objDB.ExeNonQuery(strSQL)

        If blnPrompt = True Then
            strMsgBox = "Phone number has been saved"
            EZMsgBox.Show(strMsgBox, MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If

    End Sub

    Public Sub GetCustomer(PhoneNumberx As String)

        SQLQueryCust = "SELECT * FROM Customer WHERE Phone = '" & PhoneNumberx & "';"
        Dim drCustomerx As DataRow = objDB.GetSingleRow(SQLQueryCust)
        If drCustomerx IsNot Nothing Then
            CustomerId = CShort(drCustomerx("CustomerID"))
            _CustID = CustomerId
            Name = drCustomerx("Name").ToString()
            Address1 = drCustomerx("Address1").ToString
            Address2 = drCustomerx("Address2").ToString
            Address3 = drCustomerx("Address3").ToString
            Postcode = drCustomerx("Postcode").ToString
            Telephone = PhoneNumberx
            Mobile = drCustomerx("Mobile").ToString
            Email = drCustomerx("Email").ToString
            If IsDate(drCustomerx("LastOrder")) Then LastOrder = CDate(drCustomerx("LastOrder"))
            If IsDate(drCustomerx("FirstOrdered")) Then FirstOrdered = CDate(drCustomerx("FirstOrdered"))
            If Not IsDBNull(drCustomerx("NumOrders")) Then NumberOfOrders = CInt(drCustomerx("NumOrders").ToString)
            HasValue = True
        End If

    End Sub

    Public Function GetCustomerNote() As String

        SQLQuery = "SELECT * FROM NotesDB WHERE CustomerID = " & _CustID

        drDataRow = objDB.GetSingleRow(SQLQuery)
        If drDataRow IsNot Nothing Then
            Return drDataRow!Message.ToString.Trim
        Else
            Return String.Empty
        End If

    End Function

    Public Function GetCustomerDirections() As String

        SQLQuery = "SELECT * FROM Directions WHERE CustomerID = " & _CustID

        drDataRow = objDB.GetSingleRow(SQLQuery)
        If drDataRow IsNot Nothing Then
            Return drDataRow!Directions.ToString.Trim
        Else
            Return String.Empty
        End If

    End Function

    Friend Sub DeleteDirections()
        objDB.ExeNonQuery("DELETE FROM Directions WHERE CustomerID = " & _CustID)
    End Sub

    Friend Sub AddDirections(strDirections As String)
        objDB.ExeNonQuery($"INSERT INTO Directions (CustomerID, Directions) VALUES ({_CustID}, '{strDirections.Punctuate}')")
    End Sub

    Friend Sub DeleteNotes()
        objDB.ExeNonQuery($"DELETE FROM NotesDB WHERE CustomerID = { _CustID}")
    End Sub

    Friend Sub AddNotes(strNotes As String)
        objDB.ExeNonQuery("INSERT INTO NotesDB (CustomerID, Message) VALUES (" & _CustID & ", '" & strNotes.Punctuate & "')")
    End Sub

    Friend Shared Sub MergeGroup()

        SQLQuery = $"WITH cte AS 
                    (SELECT ROW_NUMBER() OVER (PARTITION BY [Name], [Address1], [Address2], [Address3], [Postcode] 
                    ORDER BY [CustomerID] ASC) RN 
                    FROM  [Customer]) 
                    DELETE FROM cte WHERE RN > 1"
        objDB.ExeNonQuery(SQLQuery)
        objDB.ReseedTable("Customer", "Max")

    End Sub

End Class