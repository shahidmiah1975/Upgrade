﻿Imports System.Drawing.Printing
Imports System.ComponentModel
Imports System.IO
Imports EZMenu.Core.Enums
Imports EZMenu.Core.Models
Imports EZService.Repository

Public Class clsOrderPrintHandler

    Private curPrintFont As Font
    Private CurYPOS, CurYPOSLast, tempValx As Single
    Private Lines30, Lines40, SQLQueryx, tempStrx, starterLine As String
    Private evPtPgEvArg As PrintPageEventArgs
    Private liGroupGaps As New List(Of Integer)
    Private myDate As Date
    Private prevGroup As Short = -1
    Private noMoreGapsNeeded As Boolean
    Private intCurGroupCounter As Short = -1
    Private myPapersize As PaperSize
    Private LFont As Short = 14
    Private currentCopy, numCopies As Short
    Private penLine As Pen = New Pen(Brushes.Black, 1.2)
    Private CurrentOrderType As OrderTypeEnum
    Private TableRepo As New TableRepository()
    Private OrderRepo As New OrderRepository()
    Private objDatabase As clsDatabase

    Private WithEvents bgwPrintOrder As BackgroundWorker = New BackgroundWorker
    Private WithEvents bgwPrintLabels As BackgroundWorker
    Private WithEvents bgwPrintWireless As BackgroundWorker

    Public Enum PLocation
        PrinterKitchen
        PrinterShop
    End Enum

    Public Enum CopyType
        KitchenCopy
        ShopCopy
    End Enum

    Public Property OrderNumber() As Short
    Public Property TableUniqueID() As Single
    Public Property PrinterLocation() As PLocation
    Public Property ShopOrKitchenCopy() As CopyType
    Public Property DirectCopy() As Boolean

    Public Sub Print()

        'set paper size
        myPapersize = New PaperSize("EZPaperSize", GetAppSettingCS("PaperWidth", 280), 5000)

        'get C or D from Orders table
        SQLQueryx = "SELECT CustomerID FROM Orders WHERE OrderID = " & OrderNumber
        drDataRow = objDB.GetSingleRow(SQLQueryx)
        If drDataRow IsNot Nothing Then
            CurrentOrderType = IIf(drDataRow!CustomerID < intMaxCustomerID, OrderTypeEnum.Delivery, OrderTypeEnum.Collection)
        End If

        objDatabase = New clsDatabase(CurrentOrderType, OrderNumber)

        Try
            bgwPrintOrder = New BackgroundWorker
            bgwPrintOrder.RunWorkerAsync()

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Public Sub PrintTable()

        'set paper size
        myPapersize = New PaperSize("EZPaperSize", GetAppSettingCS("PaperWidth", 280), 5000)
        CurrentOrderType = OrderTypeEnum.Table
        objDatabase = New clsDatabase(CurrentOrderType, TableUniqueID)

        Try
            bgwPrintOrder = New BackgroundWorker
            bgwPrintOrder.RunWorkerAsync()

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub bgwPrintOrder_DoWork(sender As Object, e As DoWorkEventArgs) Handles bgwPrintOrder.DoWork

        Try

            If DirectCopy = False Then

                Dim xVal As Short
                Dim CDTArray() As String = {OrderTypeEnum.Collection, OrderTypeEnum.Delivery, OrderTypeEnum.Table}
                Dim KitchenCopies() As String = {"prtcopC_KC_Shop", "prtcopD_KC_Shop", "prtcopT_KC_Shop",
                                                 "prtcopC_KC_Kitchen", "prtcopD_KC_Kitchen", "prtcopT_KC_Kitchen"}
                Dim ShopCopies() As String = {"prtcopC_SC_Shop", "prtcopD_SC_Shop", "prtcopT_SC_Shop",
                                                 "prtcopC_SC_Kitchen", "prtcopD_SC_Kitchen", "prtcopT_SC_Kitchen"}

                ShopOrKitchenCopy = CopyType.KitchenCopy 'first print kitchen cop
                For iWhichCopy As Short = 1 To 2
                    If PrinterLocation = PLocation.PrinterShop Then xVal = 0 Else xVal = 3
                    For ctr As Short = 0 To 2
                        numCopies = 0
                        currentCopy = 1
                        If CurrentOrderType = CDTArray(ctr) Then
                            If ShopOrKitchenCopy = CopyType.ShopCopy Then
                                numCopies = GetAppSettingCS(ShopCopies(ctr + xVal) & intCurrentCuisine.ToString, 0)
                            Else
                                numCopies = GetAppSettingCS(KitchenCopies(ctr + xVal) & intCurrentCuisine.ToString, 0)
                            End If

                            If numCopies > 0 Then
                                Dim pdDelivery As New PrintDocument()
                                AddHandler pdDelivery.PrintPage, AddressOf PrintingPage
                                pdDelivery.PrinterSettings.DefaultPageSettings.PaperSize = myPapersize
                                pdDelivery.PrinterSettings.PrinterName = GetAppSettingCS(PrinterLocation.ToString & intCurrentCuisine.ToString, "")
                                If GetAppSettingCS("HidePrintDialog" & intCurrentCuisine.ToString, True) Then pdDelivery.PrintController = New StandardPrintController
                                pdDelivery.Print()
                                pdDelivery = Nothing
                            End If
                        End If
                    Next
                    ShopOrKitchenCopy = CopyType.ShopCopy    'then repeat proc for shop copy
                Next

            Else

                Dim pdDelivery As New PrintDocument()
                AddHandler pdDelivery.PrintPage, AddressOf PrintingPage
                pdDelivery.PrinterSettings.DefaultPageSettings.PaperSize = myPapersize
                pdDelivery.PrinterSettings.PrinterName = GetAppSettingCS(PrinterLocation.ToString & intCurrentCuisine.ToString, "")
                If GetAppSettingCS("HidePrintDialog" & intCurrentCuisine.ToString, True) Then pdDelivery.PrintController = New StandardPrintController
                pdDelivery.Print()
                pdDelivery = Nothing

            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub PrintingPage(sender As Object, ev As PrintPageEventArgs)

        evPtPgEvArg = ev

        myDate = Date.Now
        LFont = 14
        Lines30 = StrDup(30, "_")
        Lines40 = StrDup(40, "_")

        'is it a shop or kitchen copy
        If ShopOrKitchenCopy = CopyType.ShopCopy Then

            PrintShopHeader()

            PrintSubHeader()

        Else    'kitchen copy

            PrintKitchenHeader()

        End If

        Application.DoEvents()

        PrintDishes()

        PrintDrinks()

        PrintTotals()

        DoBottom()

        PrintDateTime()

        PrintFooterImage()

        Application.DoEvents()

        evPtPgEvArg.HasMorePages = currentCopy < numCopies
        currentCopy += 1

        blnPrintDone = True

    End Sub

    Private Sub PrintShopHeader()

        Try
            Dim font_style As FontStyle = FontStyle.Regular
            If GetAppSettingCS("LogoFontBold", True) Then font_style = font_style Or FontStyle.Bold
            If GetAppSettingCS("LogoFontItalic", True) Then font_style = font_style Or FontStyle.Italic

            curPrintFont = New Font(GetAppSettingCS("LogoFontName", "Brush Script MT Italic").ToString,
                                    Single.Parse(GetAppSettingCS("LogoFontSize", 23)), font_style)

            If File.Exists(AppPath() & "ezlogo.jpg") = True Then

                Dim img As Image = Image.FromFile(AppPath() & "ezlogo.jpg")
                'image size in 1/100 inch measurement
                Dim sz As New SizeF(100 * img.Width / img.HorizontalResolution, 100 * img.Height / img.VerticalResolution)
                Dim p As New PointF((myPapersize.Width - sz.Width) / 2, 0)
                evPtPgEvArg.Graphics.DrawImage(img, p)
                img.Dispose()

                CurYPOS = sz.Height

            Else

                Dim intTopOffset As Short = GetAppSettingCS("ShopCopyTopOffset", 10)
                Dim msg1, msg2, msg3, msg4, msg5, msg6 As String

                msg1 = GetAppSettingCS("PrintHead1", "biz name")
                msg2 = GetAppSettingCS("PrintHead2", "biz desc")
                msg3 = GetAppSettingCS("PrintHead3", "address1")
                msg4 = GetAppSettingCS("PrintHead4", "address2")
                msg5 = GetAppSettingCS("PrintHead5", "address3")
                msg6 = GetAppSettingCS("PrintHead6", "telephone")

                PrintAt(msg1, CentrePOS(msg1), intTopOffset)

                curPrintFont = New Font("Times New Roman", 12)
                PrintAt(msg2, CentrePOS(msg2), 38 + intTopOffset)

                curPrintFont = New Font(GetAppSettingCS("HeaderFontName", "Times New Roman").ToString,
                                           Single.Parse(GetAppSettingCS("HeaderFontSize", 10)),
                                           FontStyle.Regular)
                CurYPOS = 58 + intTopOffset
                PrintAt(msg3, CentrePOS(msg3), CurYPOS)
                PrintAt(msg4, CentrePOS(msg4), CurYPOS)
                PrintAt(msg5, CentrePOS(msg5), CurYPOS)
                PrintAt(msg6, CentrePOS(msg6), CurYPOS)
                PrintAt(Lines40, CentrePOS(Lines40), CurYPOS - 10)

            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub PrintAt(strMessage As String, xPos As Single, yPos As Single)

        CurYPOSLast = CurYPOS
        evPtPgEvArg.Graphics.DrawString(strMessage, curPrintFont, Brushes.Black, xPos, yPos)
        CurYPOS = yPos + evPtPgEvArg.Graphics.MeasureString(strMessage, curPrintFont).Height

    End Sub

    Private Function CentrePOS(strMessage As String) As Single

        Dim sizStringSize As Single = evPtPgEvArg.Graphics.MeasureString(strMessage, curPrintFont).Width
        Dim sngMyVal As Single = (evPtPgEvArg.PageSettings.PaperSize.Width - sizStringSize) / 2
        Dim centreOffset = GetAppSettingCS("CentreOffset", 90) / 100

        Return sngMyVal * centreOffset

    End Function

    Private Function RightSidePOS(strMessage As String) As Single

        Dim sizStringSize As Single = evPtPgEvArg.Graphics.MeasureString(strMessage, curPrintFont).Width
        Dim sngMyVal As Single = evPtPgEvArg.PageSettings.PaperSize.Width - sizStringSize
        Dim rightOffset = GetAppSettingCS("RightOffset", 90) / 100

        Return sngMyVal * rightOffset

    End Function

    Private Function TextHeight() As Single
        Return evPtPgEvArg.Graphics.MeasureString("A", curPrintFont).Height
    End Function

    Private Function TextWidth(strMyString As String) As Single
        Return evPtPgEvArg.Graphics.MeasureString(strMyString, curPrintFont).Width
    End Function

    Private Sub PrintSubHeader()
        'prints common info for delivs, colns, and tables

        If CurrentOrderType = OrderTypeEnum.Collection Then      'print info only for collection
            If objDatabase.ReadOrdersDB("CustomerName") = "" Then   'collection name
                tempStrx = "Collection Order"
            Else
                tempStrx = "Name: " & objDatabase.ReadOrdersDB("CustomerName")
            End If

            If objDatabase.ReadOrdersDB("Telephone") <> "" Then   'telephone
                tempStrx &= vbCrLf & "Tel: " & objDatabase.ReadOrdersDB("Telephone")
            End If

            'print card details
            'CardDetails = ""
            'If objDatabase.ReadOrdersDB("CardNumber") <> String.Empty Then
            '    If GetAppSettingCS("PrintShopCard", True) Then
            '        tempStrx &= vbCrLf & Space(8) & "Card: " & objDatabase.ReadOrdersDB("CardNumber") & vbCrLf _
            '         & Space(20) & objDatabase.ReadOrdersDB("CardExpiry") & "  [" & objDatabase.ReadOrdersDB("CardSecurity") & "]"
            '    End If
            'End If

            If objDatabase.ReadOrdersDB("CustomerIsWaiting") = "True" Then    'waiting collection
                tempStrx &= vbCrLf & "* WAITING *"
            ElseIf objDatabase.ReadOrdersDB("CollectionOrDeliveryTime") <> String.Empty Then
                tempStr = Format(CDate(objDatabase.ReadOrdersDB("CollectionOrDeliveryTime")), "h:mm")
                'add 10 minutes to online time print
                If objDatabase.ReadOrdersDB("OrderMethod") = "Online" Then
                    tempStr &= " - " & Format(CDate(tempStr).AddMinutes(10), "h:mm")
                End If
                tempStrx &= vbCrLf & vbCrLf & "Pickup @ " & tempStr
            End If

            curPrintFont = New Font("Arial", 11)
            CurYPOS += TextHeight()
            PrintAt(tempStrx, 10, CurYPOS)
            evPtPgEvArg.Graphics.DrawLine(penLine, New Point(10, CurYPOS + 0.2 * TextHeight()),
                                          New Point(evPtPgEvArg.PageBounds.Width / 2, CurYPOS + 0.2 * TextHeight()))

            'print customer note if online order
            PrintCustomerNote()

        ElseIf CurrentOrderType = OrderTypeEnum.Delivery Then      'print info only for delivery

            'delivery time
            tempValx = CurYPOS
            tempStrx = objDatabase.ReadOrdersDB("CollectionOrDeliveryTime")
            If tempStrx <> String.Empty Then
                curPrintFont = New Font("Arial", 12, FontStyle.Bold)
                tempStrx = Format(CDate(tempStrx), "h:mm")
                'add 10 minutes to online time print
                If objDatabase.ReadOrdersDB("OrderMethod") = "Online" Then
                    tempStrx &= " - " & Format(CDate(tempStrx).AddMinutes(10), "h:mm")
                End If
                tempStrx = IIf(objDatabase.ReadOrdersDB("OrderMethod") = "Online", "", vbCrLf) & Space(3) & "DELIVER @ " & tempStrx & vbCrLf & vbCrLf
                PrintAt(tempStrx, 0, CurYPOS)
            End If

            curPrintFont = New Font("Arial", 11, FontStyle.Regular)

            'print delivery address
            'CurYPOS = tempValx
            Dim strTem = Space(3) & objDatabase.ReadOrdersDB("CustomerName")
            tempStrx = objDatabase.ReadOrdersDB("DeliveryAddress1")
            If tempStrx <> String.Empty Then strTem &= vbCrLf & Space(3) & tempStrx
            tempStrx = objDatabase.ReadOrdersDB("DeliveryAddress2")
            If tempStrx <> String.Empty Then strTem &= vbCrLf & Space(3) & tempStrx
            tempStrx = objDatabase.ReadOrdersDB("DeliveryAddress3")
            If tempStrx <> String.Empty Then strTem &= vbCrLf & Space(3) & tempStrx
            tempStrx = objDatabase.ReadOrdersDB("DeliveryPostcode")
            If tempStrx <> String.Empty Then strTem &= vbCrLf & Space(3) & tempStrx
            strTem &= vbCrLf & Space(3) & objDatabase.ReadOrdersDB("Telephone")
            PrintAt(vbCrLf & strTem, 0, CurYPOS)

            'print any directions
            tempStrx = GetCustomerDirections()
            If tempStrx <> String.Empty Then
                PrintAt(WordWrap(tempStrx, curPrintFont, 3), 0, CurYPOS)
            End If

            'print card details
            'CardDetails = ""
            'If objDatabase.ReadOrdersDB("CardNumber") <> String.Empty Then
            '    If GetAppSettingCS("PrintShopCard", True) Then
            '        CardDetails = vbCrLf & Space(8) & "Card: " & objDatabase.ReadOrdersDB("CardNumber") &
            '            vbCrLf & Space(20) & objDatabase.ReadOrdersDB("CardExpiry") & "  [" & objDatabase.ReadOrdersDB("CardSecurity") & "]"
            '        PrintAt(CardDetails, 0, CurYPOS)
            '    End If
            'End If

            evPtPgEvArg.Graphics.DrawLine(penLine, New Point(10, CurYPOS + 0.2 * TextHeight()),
                                          New Point(evPtPgEvArg.PageBounds.Width / 2, CurYPOS + 0.2 * TextHeight()))

            'print customer note if online order
            PrintCustomerNote()

        ElseIf CurrentOrderType = OrderTypeEnum.Table Then      'print info only for table
            'print table & customer numbers
            curPrintFont = New Font("Arial", 11)
            tempStrx = vbCrLf & "Table: " & objDatabase.ReadTablesDB("TableNumber") & " / " & objDatabase.ReadTablesDB("NumCust")
            PrintAt(tempStrx, 10, CurYPOS)

        End If

    End Sub

    Private Sub PrintKitchenHeader()
        'creates the printed layout (header, address, and lines)

        Dim msg1, msg2 As String
        Dim intTopOffset As Short = GetAppSettingCS("KitchenCopyTopOffset", 40)
        Dim intPickWait As Short = 0
        Dim blnSameAsShopHeader As Boolean = GetAppSettingCS("SameSKHeader", False)

        msg1 = GetAppSettingCS("KitchenHeaderText", "KITCHEN ORDER")
        msg2 = ""

        If blnSameAsShopHeader = True Then
            PrintShopHeader()
        End If

        If CurrentOrderType = OrderTypeEnum.Collection Then
            'waiting order
            tempStrx = objDatabase.ReadOrdersDB("CustomerIsWaiting").ToString
            If tempStrx = "True" Then
                tempStrx = "* WAITING *"
            Else
                'pickup time
                tempStrx = objDatabase.ReadOrdersDB("CollectionOrDeliveryTime")
                If tempStrx <> String.Empty Then
                    tempStrx = Format(CDate(tempStrx), "h:mm")
                    'add 10 minutes to online time print
                    If objDatabase.ReadOrdersDB("OrderMethod") = "Online" Then
                        tempStrx &= " - " & Format(CDate(tempStrx).AddMinutes(10), "h:mm")
                    End If
                    tempStrx = "PICKUP @ " & tempStrx
                End If
            End If

            If tempStrx <> String.Empty Then
                curPrintFont = New Font("Arial", 13, FontStyle.Bold)
                PrintAt(tempStrx, 10, IIf(blnSameAsShopHeader, 40, 0) + 65 + intTopOffset)
                If blnSameAsShopHeader = False Then intPickWait = 1.2 * TextHeight()
            End If

            If objDatabase.ReadOrdersDB("CustomerName") = "" Then
                msg2 = "Collection Order"
            Else
                msg2 = "Name: " & objDatabase.ReadOrdersDB("CustomerName")
            End If

            If objDatabase.ReadOrdersDB("Telephone") <> "" Then   'telephone
                msg2 &= vbCrLf & "Tel: " & objDatabase.ReadOrdersDB("Telephone")
            End If

        ElseIf CurrentOrderType = OrderTypeEnum.Delivery Then
            'delivery time
            tempStrx = objDatabase.ReadOrdersDB("CollectionOrDeliveryTime")
            If tempStrx <> String.Empty Then
                curPrintFont = New Font("Arial", 13, FontStyle.Bold)
                tempStrx = Format(CDate(tempStrx), "h:mm")
                'add 10 minutes to online time print
                If objDatabase.ReadOrdersDB("OrderMethod") = "Online" Then
                    tempStrx &= " - " & Format(CDate(tempStrx).AddMinutes(10), "h:mm")
                End If
                tempStrx = "DELIVER @ " & tempStrx
                PrintAt(tempStrx, 10, IIf(blnSameAsShopHeader, 40, 0) + 65 + intTopOffset)
                intPickWait = 1.2 * TextHeight()
            End If

            tempStrx = objDatabase.ReadOrdersDB("DeliveryAddress1")
            If tempStrx <> String.Empty Then msg2 = Space(3) & tempStrx
            tempStrx = objDatabase.ReadOrdersDB("DeliveryAddress2")
            If tempStrx <> String.Empty Then msg2 &= vbCrLf & Space(3) & tempStrx
            tempStrx = objDatabase.ReadOrdersDB("DeliveryAddress3")
            If tempStrx <> String.Empty Then msg2 &= vbCrLf & Space(3) & tempStrx
            tempStrx = objDatabase.ReadOrdersDB("DeliveryPostcode")
            If tempStrx <> String.Empty Then msg2 &= vbCrLf & Space(3) & tempStrx
            tempStrx = GetCustomerDirections()
            If tempStrx <> String.Empty Then msg2 &= vbCrLf & Space(3) & "(" & WordWrap(tempStrx, New Font("Arial", 10, FontStyle.Regular), 3).Trim & ")"

            msg2 = vbCrLf & Space(3) & objDatabase.ReadOrdersDB("CustomerName") & vbCrLf &
                msg2 & vbCrLf & Space(3) & objDatabase.ReadOrdersDB("Telephone")

        Else
            msg2 = "Table: " & objDatabase.ReadTablesDB("TableNumber") & " / " & objDatabase.ReadTablesDB("NumCust")

        End If

        If blnSameAsShopHeader = False Then
            curPrintFont = New Font("Arial", 14, FontStyle.Bold)
            PrintAt(msg1, CentrePOS(msg1), intTopOffset)        'kitchen order
            PrintAt(Lines40, CentrePOS(Lines40), CurYPOS)       'dashes/line
        End If

        If CurrentOrderType = OrderTypeEnum.Collection Then
            curPrintFont = New Font("Arial", 12, FontStyle.Regular)
            CurYPOS = CurYPOS + (0.8 * TextHeight()) + intPickWait + IIf(blnSameAsShopHeader, 0, 0)
            PrintAt(msg2, 10, CurYPOS)

        ElseIf CurrentOrderType = OrderTypeEnum.Table Then
            curPrintFont = New Font("Arial", 12, FontStyle.Regular)
            PrintAt(msg2, CentrePOS(msg2), CurYPOS + (0.3 * TextHeight()))
            CurYPOS = CurYPOSLast + (0.5 * TextHeight())

        Else
            Dim fontSize As Single = Val(GetAppSettingCS("FontSizeKitchenAddress", 12))
            curPrintFont = New Font("Arial", fontSize, FontStyle.Regular)
            PrintAt(msg2, 0, CurYPOS + intPickWait)
        End If

        curPrintFont = New Font("Arial", 14, FontStyle.Bold)
        PrintAt(Lines40, CentrePOS(Lines40), CurYPOS)       'dashes/line

        'print kitchen note
        If CurrentOrderType = OrderTypeEnum.Table Then
            tempStrx = objDatabase.ReadTablesDB("TableNote").ToString.Trim
        Else
            tempStrx = objDatabase.ReadOrdersDB("KitchenNote").ToString.Trim
        End If

        If tempStrx <> String.Empty Then
            tempStrx = Replace(tempStrx, "^", vbCrLf).Trim
            tempStrx = Replace(tempStrx, "@", vbCrLf).Trim

            Dim h As Short = tempStrx.IndexOf("PayPal status")
            If h <> -1 Then
                Dim tmpStr As String = tempStrx.Substring(0, h)
                h = tempStrx.IndexOf(" GBP")
                tmpStr &= tempStrx.Substring(h + 4)
                tempStrx = tmpStr.Trim
            End If
            If tempStrx <> String.Empty Then
                Dim ftSize As Short = Val(GetAppSettingCS("FontSizeKitchen", 14))
                curPrintFont = New Font("Arial", ftSize, FontStyle.Regular)
                PrintAt(vbCrLf, 0, CurYPOS)
                PrintAt(WordWrap("NOTE: " & tempStrx, curPrintFont), 10, CurYPOS)
            End If
        End If

    End Sub

    Private Sub PrintDishes()

        Dim blnHasStarter, blnDonePapa, blnDonePapaAdjustment As Boolean
        Dim dCode, dQty, dPrice, dStarter, dGroupIndex
        Dim dName, dNameOri As String
        Dim arrMods()

        ' Print each line of the file.
        Try
            liGroupGaps = GetGroupGapsFromDB()
            CurYPOS += 20
            noMoreGapsNeeded = False
            prevGroup = -1

            If CurrentOrderType = OrderTypeEnum.Table Then
                SQLQueryx = $"SELECT Code, DishName, DishPrice, DishQty, IsStarter, GroupIndex, Discountable 
                              FROM Table_Meal WHERE TabUniqueID = { TableUniqueID } ORDER BY GroupIndex, Code"
            Else
                SQLQueryx = $"SELECT Code, DishName, Qty AS DishQty, IsStarter = 0, UnitPrice AS DishPrice, Discountable, GroupIndex
                              FROM OrderItems WHERE OrderID = { OrderNumber } ORDER BY GroupIndex, Code"
            End If

            drcDatarowCollection = objDB.GetDataRows(SQLQueryx)
            If drcDatarowCollection IsNot Nothing Then
                'print a space on shop copy
                If CurrentOrderType <> OrderTypeEnum.Table AndAlso ShopOrKitchenCopy = CopyType.ShopCopy Then PrintAt(" ", 10, CurYPOS)
                For Each mrow In drcDatarowCollection
                    dCode = mrow!Code
                    dQty = mrow!DishQty
                    dName = mrow!DishName
                    dNameOri = dName
                    dPrice = mrow!DishPrice
                    dGroupIndex = mrow!GroupIndex
                    dStarter = mrow!IsStarter

                    If CurrentOrderType = OrderTypeEnum.Table Then
                        If ShopOrKitchenCopy = CopyType.KitchenCopy AndAlso dCode = 800 Then
                            'ignore drinks thing on kitchen copy
                            Continue For

                        ElseIf dName = "gap-here" Then  'drinks label and gap
                            tempStrx = " "
                            If GetAppSettingCS("DrinksAndFoodGap", True) Then
                                If GetAppSettingCS("DrinksHeader", True) Then
                                    tempStrx = vbCrLf & GetAppSettingCS("DrinksLabelOnReceipt", "Drinks") & ":"
                                End If
                                PrintAt(tempStrx, 10, CurYPOS)
                            End If
                            Continue For
                        End If

                        'add chutneys to papadam name
                        If dName.ToUpper Like strPapadom AndAlso GetAppSettingCS("CAPStatus", True) AndAlso blnDonePapa = False Then
                            dName &= strChutney
                            blnDonePapa = True
                        End If
                    End If

                    'set the correct font size and format dish name
                    If ShopOrKitchenCopy = CopyType.ShopCopy Then
                        tempValx = Val(GetAppSettingCS("FontSizeShop", 12))
                        dName = LNSNConvert(dName, "LNSNCustomer")
                    Else
                        tempValx = Val(GetAppSettingCS("FontSizeKitchen", 14))
                        dName = LNSNConvert(dName, "LNSNKitchen")
                    End If
                    If tempValx < 8 Or tempValx > 20 Then tempValx = 14
                    curPrintFont = New Font("Arial", tempValx)

                    'do starter line on kitchen copy
                    If blnHasStarter = True AndAlso dStarter = 0 AndAlso CurrentOrderType = OrderTypeEnum.Table AndAlso ShopOrKitchenCopy = CopyType.KitchenCopy Then
                        starterLine = "  -  -  -  -  -  -  -  -  -  -  -  -  -  -"
                        If GetAppSettingCS("ExtraStarterSpace", True) Then
                            If GetAppSettingCS("DishesGapKitchen", True) Then
                                starterLine = vbCrLf & starterLine & vbCrLf
                            Else
                                starterLine = vbCrLf & starterLine & vbCrLf & vbCrLf
                            End If
                        End If
                        PrintAt(starterLine, 0, CurYPOS)
                        blnHasStarter = False
                    End If

                    'put gap between dishes on kitchen copy
                    If liGroupGaps IsNot Nothing AndAlso liGroupGaps.Count > 0 Then
                        If GetAppSettingCS("DishesGapKitchen", True) And ShopOrKitchenCopy = CopyType.KitchenCopy AndAlso dName.ToUpper Like strPapadom = False Then
                            If noMoreGapsNeeded = False Then PutDishesGap(dGroupIndex)
                        End If
                    End If

                    'print dish name
                    'PrintAt(dQty & "  " & dName, 10, CurYPOS)
                    PrintAt(WordWrap(dQty & "  " & dName, curPrintFont), 10, CurYPOS)

                    'print price
                    Dim blnDoPrice As Boolean = False
                    If ShopOrKitchenCopy = CopyType.ShopCopy And GetAppSettingCS("PrintShopItem", True) Then
                        blnDoPrice = True
                    ElseIf ShopOrKitchenCopy = CopyType.KitchenCopy And GetAppSettingCS("PrintKitchenItem", True) And CurrentOrderType <> OrderTypeEnum.Table Then
                        blnDoPrice = True
                    End If

                    If blnDoPrice = True Then
                        If CurrentOrderType = OrderTypeEnum.Table AndAlso dName.ToUpper Like strPapadom AndAlso blnDonePapaAdjustment = False Then
                            tempStrx = fixCur(AdjustPapaPrice(dQty, dPrice))
                            blnDonePapaAdjustment = True
                        Else
                            tempStrx = fixCur(dQty * dPrice)
                        End If

                        PrintAt(tempStrx, RightSidePOS(tempStrx), CurYPOSLast)
                    End If

                    'print any modifiers
                    Dim orderMods As IEnumerable(Of OrderModsModel) = Nothing
                    If CurrentOrderType = OrderTypeEnum.Table Then
                        orderMods = TableRepo.GetTableModsFromDB(TableUniqueID, dNameOri)
                    Else
                        orderMods = OrderRepo.GetOrderModsFromDB(OrderNumber, dNameOri)
                    End If

                    If orderMods.Any Then
                        For Each om In orderMods
                            tempStrx = "- " & om.ModName
                            PrintAt(WordWrap(tempStrx, curPrintFont, 8), 10, CurYPOS)
                            If blnDoPrice = True Then
                                Dim strCost As String = fixCur(dQty * om.ModCost)
                                If Not (Decimal.Parse(strCost) = 0 AndAlso GetAppSettingCS("PrintZeroCost", True)) Then
                                    PrintAt(strCost, RightSidePOS(strCost), CurYPOSLast)
                                End If
                            End If
                        Next
                    End If

                    'print any set items
                    'Dim setItemVar = "TODO - fix this"
                    'If setItemVar = "1" Then
                    '    Dim dSetItems As String
                    '    If CurrentOrderType = OrderTypeEnum.Table Then
                    '        dSetItems = objDB.GetSetItemsFromDB(TableUniqueID, dNameOri)
                    '    Else
                    '        dSetItems = objDB.GetSetItemsFromDB(OrderNumber, dNameOri)
                    '    End If
                    '    If (dSetItems.ToString.Trim <> String.Empty) Then
                    '        Dim strFullString, strCost As String
                    '        Dim arrSets() = dSetItems.ToString.Trim.Split("^^")
                    '        For aCnt = arrSets.GetLowerBound(0) To arrSets.GetUpperBound(0)
                    '            strFullString = arrSets(aCnt)
                    '            If strFullString <> String.Empty Then
                    '                Dim arrSetItems() = strFullString.Split("#")
                    '                tempStrx = Space(8) & "- " & IIf(GetAppSettingCS("SetPutQty", True) = True, arrSetItems(0) & " ", "") & arrSetItems(1)
                    '                PrintAt(tempStrx, 10, CurYPOS)
                    '                If blnDoPrice = True Then
                    '                    strCost = fixCur(arrSetItems(2))
                    '                    If Decimal.Parse(strCost) = 0 AndAlso GetAppSettingCS("PrintZeroCost", True) Then blnDoPrice = False
                    '                    If blnDoPrice = True Then PrintAt(strCost, RightSidePOS(strCost), CurYPOSLast)
                    '                End If
                    '            End If
                    '        Next
                    '    End If
                    'End If

                    blnHasStarter = dStarter <> 0

                Next
            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Function LNSNConvert(strDishName As String, strDest As String) As String

        Try
            If GetAppSettingCS("LNSNOnscreen", "LN") = "LN" And GetAppSettingCS(strDest, "LN") = "SN" Then
                'get short name from long name
                SQLQueryx = $"SELECT DishShortName.ShortName
                              FROM Dish INNER JOIN DishShortName ON Dish.UniqueID = DishShortName.UniqueID 
                              WHERE (Dish.DishName = '{strDishName.Punctuate}')"
                drDataRow = objDB.GetSingleRow(SQLQueryx)
                If drDataRow IsNot Nothing Then
                    Return drDataRow!ShortName.ToString
                Else
                    'see if its in DishCascade table
                    SQLQueryx = $"SELECT ShortName
                                  FROM DishCascade
                                  WHERE DishName = '{strDishName.Punctuate}'"
                    drDataRow = objDB.GetSingleRow(SQLQueryx)
                    If drDataRow IsNot Nothing AndAlso drDataRow!ShortName.ToString <> String.Empty Then
                        Return drDataRow!ShortName.ToString
                    Else
                        Return strDishName
                    End If
                End If

            ElseIf GetAppSettingCS("LNSNOnscreen", "LN") = "SN" And GetAppSettingCS(strDest, "LN") = "LN" Then
                'get long name from short name
                SQLQueryx = "SELECT Dish.DishName " &
                           "FROM Dish INNER JOIN DishShortName ON Dish.UniqueID = DishShortName.UniqueID " &
                           "WHERE (DishShortName.ShortName = '" & strDishName.Punctuate & "')"
                drDataRow = objDB.GetSingleRow(SQLQueryx)
                If drDataRow IsNot Nothing Then
                    Return drDataRow!DishName.ToString
                Else
                    'see if its in DishCascade table
                    SQLQueryx = "SELECT DishCascade.DishName " &
                                "FROM DishCascade " &
                                "WHERE (DishCascade.ShortName = '" & strDishName.Punctuate & "')"
                    drDataRow = objDB.GetSingleRow(SQLQueryx)
                    If drDataRow IsNot Nothing AndAlso drDataRow!DishName.ToString <> String.Empty Then
                        Return drDataRow!DishName.ToString
                    Else
                        Return strDishName
                    End If
                End If

            Else
                Return strDishName
            End If

        Catch ex As Exception
            Return strDishName
        End Try

    End Function

    Private Sub PutDishesGap(myGroupValue As Short)

        Dim blnPrintGap As Boolean = False
        intCurGroupCounter = GetRange(myGroupValue)
        If intCurGroupCounter = -1 Then 'match not in list
            PrintAt(" ", 0, CurYPOS)
            noMoreGapsNeeded = True
        Else
            If prevGroup = -1 Then
                blnPrintGap = False
            Else
                If intCurGroupCounter = prevGroup Then
                    blnPrintGap = False
                Else
                    blnPrintGap = True
                End If
            End If
        End If
        If blnPrintGap = True Then PrintAt(" ", 0, CurYPOS)
        prevGroup = intCurGroupCounter

    End Sub

    Private Function GetRange(intNumber As Short) As Short

        For xCnt = 0 To liGroupGaps.Count - 1 Step 2
            If intNumber >= liGroupGaps.Item(xCnt) And intNumber <= liGroupGaps.Item(xCnt + 1) Then
                Return xCnt
            End If
        Next

        'no match found so return -1
        Return -1

    End Function

    Private Function GetGroupGapsFromDB() As List(Of Integer)

        Dim lstTempList As New List(Of Integer)

        SQLQueryx = "SELECT * FROM GroupGaps ORDER BY GroupNumber ASC"
        drcDatarowCollection = objDB.GetDataRows(SQLQueryx)
        If drcDatarowCollection IsNot Nothing Then
            For Each myRow As DataRow In drcDatarowCollection
                lstTempList.Add(myRow!GroupNumber)
            Next
            Return lstTempList
        Else
            Return Nothing
        End If

    End Function

    Private Function AdjustPapaPrice(xQty As Short, xPrice As Decimal) As Decimal

        tempValx = xQty * xPrice
        tempValx += objDatabase.ReadTablesDB("CAPValue") * (CDec(GetAppSettingCS("CAPValue", 0)) / 100)

        Return tempValx

    End Function

    Private Sub PrintDrinks()

        'print itemised table drinks
        If CurrentOrderType = OrderTypeEnum.Table AndAlso ShopOrKitchenCopy = CopyType.ShopCopy Then

            If GetAppSettingCS("DrinksItemise", True) Then
                SQLQueryx = $"SELECT * FROM Table_Drinks WHERE TabUniqueID = { TableUniqueID }"
                drcDatarowCollection = objDB.GetDataRows(SQLQueryx)
                If (drcDatarowCollection IsNot Nothing) AndAlso (drcDatarowCollection.Count > 0) Then

                    If GetAppSettingCS("DrinksAndFoodGap", True) Then
                        tempStrx = " "
                        If GetAppSettingCS("DrinksHeader", True) Then
                            tempStrx = vbCrLf & GetAppSettingCS("DrinksLabelOnReceipt", "Drinks") & ":"
                        End If
                        PrintAt(tempStrx, 10, CurYPOS)
                    End If

                    For Each mrow In drcDatarowCollection
                        PrintAt(mrow!DkQty & " " & mrow!DkName, 10, CurYPOS)
                        tempValx = CDec(mrow!DkPrice)
                        PrintAt(fixCur(tempValx), RightSidePOS(fixCur(tempValx)), CurYPOSLast)
                    Next
                End If
            End If

        End If

    End Sub

    Private Sub PrintTotals()

        Dim strSubTotal, strDiscountAmount, strChargesAmount, strBillTotal As String
        Dim strDrinksTotal, strDiscountLabel, strChargeLabel As String
        Dim strGDiscountAmount, strGChargeAmount, strGDiscountLabel, strGChargeLabel As String
        Dim strSubTotalLabel As String = "Subtotal: "
        Dim blnPrintSubtotal As Boolean = True

        Try

            'read data from the DB
            If CurrentOrderType = OrderTypeEnum.Collection Or CurrentOrderType = OrderTypeEnum.Delivery Then
                strSubTotal = fixCur(objDatabase.ReadOrdersDB("Subtotal"))
                strDiscountAmount = fixCur(objDatabase.ReadOrdersDiscChargesDB("DiscountAmount"))
                strDiscountLabel = objDatabase.ReadOrdersDiscChargesDB("DiscountLabelText")
                strChargesAmount = fixCur(objDatabase.ReadOrdersDiscChargesDB("ChargeAmount"))
                strChargeLabel = objDatabase.ReadOrdersDiscChargesDB("ChargeLabelText")
                strGDiscountAmount = fixCur(objDatabase.ReadOrdersDiscChargesDB("GlobalDiscountAmount"))
                strGDiscountLabel = objDatabase.ReadOrdersDiscChargesDB("GlobalDiscountLabelText")
                strGChargeAmount = fixCur(objDatabase.ReadOrdersDiscChargesDB("GlobalChargeAmount"))
                strGChargeLabel = objDatabase.ReadOrdersDiscChargesDB("GlobalChargeLabelText")
                strDrinksTotal = fixCur(objDatabase.ReadOrdersDB("DrinksTotal"))
                strBillTotal = fixCur(objDatabase.ReadOrdersDB("BillTotal"))

            Else    'table mode
                strSubTotal = fixCur(objDatabase.ReadTablesDB("MealTotal"))
                strSubTotalLabel = GetAppSettingCS("FoodLabelOnReceipt", "Food") & ": "
                strDiscountAmount = Abs(fixCur(objDatabase.ReadTablesDB("DiscountAmount")))
                strDiscountLabel = objDatabase.ReadTablesDB("DiscountLabelText")
                strChargesAmount = fixCur(objDatabase.ReadTablesDB("ChargeAmount"))
                strChargeLabel = objDatabase.ReadTablesDB("ChargeLabelText")
                strGDiscountAmount = fixCur(objDatabase.ReadTablesDB("GDiscountAmount"))
                strGDiscountLabel = objDatabase.ReadTablesDB("GDiscountLabelText")
                strGChargeAmount = fixCur(objDatabase.ReadTablesDB("GChargeAmount"))
                strGChargeLabel = objDatabase.ReadTablesDB("GChargeLabelText")
                strDrinksTotal = fixCur(TableRepo.DrinksTotal(TableUniqueID))
                strBillTotal = fixCur(objDatabase.ReadTablesDB("BillTotal"))

                'check if drinks are itemised, and also if food/drink price is separate
                If GetAppSettingCS("DrinksItemise", True) Then
                    If GetAppSettingCS("DrinksFoodSeparatePrice", 0) = 0 Then
                        strSubTotal = CDec(strSubTotal) + CDec(strDrinksTotal)
                        strDrinksTotal = "0.00"
                    End If
                End If
            End If

            Dim amountsNotZero As Boolean = Decimal.Parse(strDiscountAmount) <> 0 Or Decimal.Parse(strChargesAmount) <> 0 Or
                                            Decimal.Parse(strGDiscountAmount) <> 0 Or Decimal.Parse(strGChargeAmount) <> 0

            'print totals on shop copy
            If ShopOrKitchenCopy = CopyType.ShopCopy Then

                curPrintFont = New Font("Arial", GetAppSettingCS("FontSizeShop", 12))

                If GetAppSettingCS("DrinksAndFoodGrouped", True) Then
                    strSubTotal = CDec(strSubTotal) + CDec(strDrinksTotal)
                    strSubTotalLabel = "Subtotal" & ": "
                End If

                'put drink if it is grouped with food
                If Decimal.Parse(strDrinksTotal) <> 0 AndAlso GetAppSettingCS("DrinksAndFoodGrouped", True) Then
                    tempStrx = "Drinks"
                    PrintAt(tempStrx, 10, CurYPOS)
                    tempStrx = fixCur(strDrinksTotal)
                    PrintAt(tempStrx, RightSidePOS(tempStrx), CurYPOSLast)
                    'strSubTotal = CDec(strSubTotal) + CDec(strDrinksTotal)
                    blnPrintSubtotal = False
                End If

                'make paper a certain length
                PaperSizeProc("S")

                'print a line after dishes
                PrintAt(Lines40, CentrePOS(Lines40), CurYPOS) 'dashes/line

                If amountsNotZero Or Decimal.Parse(strDrinksTotal) <> 0 Then

                    'print subtotal
                    If blnPrintSubtotal = False Then blnPrintSubtotal = amountsNotZero

                    If blnPrintSubtotal = True Then
                        tempStrx = strSubTotalLabel & fixCur(strSubTotal)
                        PrintAt(tempStrx, RightSidePOS(tempStrx), CurYPOS)
                    End If

                    'put drinks above discount and charges for tables
                    If CurrentOrderType = OrderTypeEnum.Table Then
                        If Decimal.Parse(strDrinksTotal) <> 0 AndAlso GetAppSettingCS("DrinksAndFoodGrouped", 0) = 0 Then
                            tempStrx = GetAppSettingCS("DrinksLabelOnReceipt", "Drinks") & ": " & fixCur(objDatabase.ReadTablesDB("DrinksTotal"))
                            PrintAt(tempStrx, RightSidePOS(tempStrx), CurYPOS)
                        End If
                    End If

                    PrintAllDiscountsAndCharges(strDiscountAmount, strDiscountLabel, strChargesAmount, strChargeLabel,
                                                    strGDiscountAmount, strGDiscountLabel, strGChargeAmount, strGChargeLabel)

                    ''put drinks above discount and charges for tables
                    'If CDTVar = OrderTypeEnum.Table Then
                    '    If strDrinksTotal <> "0.00" AndAlso GetAppSettingCS("DrinksAndFoodGrouped", 0) = 0 Then
                    '        tempStrx = GetAppSettingCS("DrinksLabelOnReceipt", "Drinks") & ": " & fixCur(objDatabase.ReadTablesDB("DrinksTotal"))
                    '        PrintAt(tempStrx, RightSidePOS(tempStrx), CurYPOS)
                    '    End If
                    'End If

                    'put drinks beneath discount and charges for delivs and colns
                    If CurrentOrderType <> OrderTypeEnum.Table Then
                        If Decimal.Parse(strDrinksTotal) <> 0 AndAlso GetAppSettingCS("DrinksAndFoodGrouped", 0) = 0 Then
                            tempStrx = GetAppSettingCS("DrinksLabelOnReceipt", "Drinks") & ": " & fixCur(objDatabase.ReadOrdersDB("DrinksTotal"))
                            PrintAt(tempStrx, RightSidePOS(tempStrx), CurYPOS)
                        End If
                    End If

                End If

                'print total to pay
                tempStrx = "Total: " & fixCur(strBillTotal)
                PrintAt(tempStrx, RightSidePOS(tempStrx), CurYPOS + 0.2)

            ElseIf ShopOrKitchenCopy = CopyType.KitchenCopy Then

                PaperSizeProc("K")

                'print a line after dishes
                curPrintFont = New Font("Arial", LFont - 4)
                PrintAt(vbCrLf & Lines40, CentrePOS(Lines40), CurYPOS) 'dashes/line

                'print totals on kitchen copy, only for deliveries
                If CurrentOrderType = OrderTypeEnum.Delivery AndAlso GetAppSettingCS("PrintKitchenTotal", True) Then

                    curPrintFont = New Font("Arial", LFont - 2)

                    If amountsNotZero Or Decimal.Parse(strDrinksTotal) <> 0 Then

                        'print subtotal
                        If blnPrintSubtotal = False Then
                            blnPrintSubtotal = Decimal.Parse(strDiscountAmount) <> 0 Or Decimal.Parse(strChargesAmount) <> 0
                        End If
                        If blnPrintSubtotal = True Then
                            tempStrx = strSubTotalLabel & fixCur(strSubTotal)
                            PrintAt(tempStrx, RightSidePOS(tempStrx), CurYPOS)
                        End If

                        PrintAllDiscountsAndCharges(strDiscountAmount, strDiscountLabel, strChargesAmount, strChargeLabel,
                                                        strGDiscountAmount, strGDiscountLabel, strGChargeAmount, strGChargeLabel)

                    End If

                    'print total to pay
                    tempStrx = "Total: " & fixCur(objDatabase.ReadOrdersDB("BillTotal"))
                    PrintAt(tempStrx, RightSidePOS(tempStrx), CurYPOS)

                End If

            End If

            'mark if order is paid
            If CurrentOrderType <> OrderTypeEnum.Table Then
                tempStrx = ""
                If Boolean.Parse(objDatabase.ReadOrdersDB("OrderIsPaid")) = True Then
                    tempStrx = "PAID"
                End If
                If objDatabase.ReadOrdersDB("PaymentMethod") <> String.Empty Then
                    tempStrx = (tempStrx & " " & objDatabase.ReadOrdersDB("PaymentMethod").ToUpper).Trim
                End If

                If objDatabase.ReadOrdersDB("KitchenNote").ToString.IndexOf("PayPal status: Completed") <> -1 Then
                    tempStrx = "PAID VIA PAYPAL"
                End If

                If tempStrx <> String.Empty Then
                    curPrintFont = New Font("Arial", GetAppSettingCS("FontSizePaid", 10))
                    tempStrx = "* " & tempStrx & " *"
                    If GetAppSettingCS("PaidLocation", "Right") = "Right" Then
                        PrintAt(tempStrx, RightSidePOS(tempStrx), CurYPOS)
                    ElseIf GetAppSettingCS("PaidLocation", "Right") = "Left" Then
                        PrintAt(tempStrx, 0, CurYPOS)
                    Else
                        PrintAt(tempStrx, CentrePOS(tempStrx), CurYPOS)
                    End If
                End If

            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub PrintAllDiscountsAndCharges(strDiscounts As String, strDiscountsLabel As String, strCharges As String, strChargesLabel As String,
                                            strGlobalDiscounts As String, strGlobalDiscountsLabel As String, strGlobalCharges As String, strGlobalChargesLabel As String)

        If Decimal.Parse(strGlobalCharges) <> 0 Then
            If String.IsNullOrEmpty(strGlobalChargesLabel) Then strGlobalChargesLabel = "Charges"
            tempStrx = strGlobalChargesLabel & ": " & fixCur(strGlobalCharges)
            PrintAt(tempStrx, RightSidePOS(tempStrx), CurYPOS)
        End If

        If Decimal.Parse(strCharges) <> 0 Then
            If String.IsNullOrEmpty(strChargesLabel) Then strChargesLabel = "Charges"
            tempStrx = strChargesLabel & ": " & fixCur(strCharges)
            PrintAt(tempStrx, RightSidePOS(tempStrx), CurYPOS)
        End If

        If Decimal.Parse(strGlobalDiscounts) <> 0 Then
            If String.IsNullOrEmpty(strGlobalDiscountsLabel) Then strGlobalDiscountsLabel = "Discounts"
            tempStrx = strGlobalDiscountsLabel & ": -" & fixCur(strGlobalDiscounts)
            PrintAt(tempStrx, RightSidePOS(tempStrx), CurYPOS)
        End If

        If Decimal.Parse(strDiscounts) <> 0 Then
            If String.IsNullOrEmpty(strDiscountsLabel) Then strDiscountsLabel = "Discount:"
            tempStrx = strDiscountsLabel & ": -" & fixCur(strDiscounts)
            PrintAt(tempStrx, RightSidePOS(tempStrx), CurYPOS)
        End If

    End Sub

    Private Sub DoBottom()

        Try
            If ShopOrKitchenCopy = CopyType.ShopCopy Then
                PrintAt(" ", CentrePOS(" "), CurYPOS)

                'service charge note for tables
                If CurrentOrderType = OrderTypeEnum.Table AndAlso Short.Parse(GetAppSettingCS("PrintServiceCharge", 0)) <> 0 Then
                    curPrintFont = New Font("Arial", 10, FontStyle.Bold)
                    tempStrx = "* Service Charge Not Included *" & vbCrLf
                    PrintAt(tempStrx, CentrePOS(tempStrx), CurYPOS)
                End If

                curPrintFont = New Font("Arial", Short.Parse(GetAppSettingCS("FooterTextSize", 9)), FontStyle.Regular)
                Dim footerText As String = GetAppSettingCS("FooterText", "Thank you for your custom. Please call again.")
                If footerText.Contains(vbCrLf) Then
                    Dim footerLines() As String = footerText.Split(New String() {vbCrLf}, StringSplitOptions.None)
                    For Each line As String In footerLines
                        If Not String.IsNullOrWhiteSpace(line) Then
                            PrintAt(line.Trim(), CentrePOS(line.Trim()), CurYPOS)
                        End If
                    Next
                Else
                    PrintAt(footerText, CentrePOS(footerText), CurYPOS)
                End If
            End If

            'print online order
            If (CurrentOrderType = OrderTypeEnum.Collection Or CurrentOrderType = OrderTypeEnum.Delivery) AndAlso (objDatabase.ReadOrdersDB("OrderMethod") = "Online") Then
                curPrintFont = New Font("Arial", 10, FontStyle.Regular)
                tempStr = vbCrLf + vbCrLf + "* * This is a website order * *"
                If ShopOrKitchenCopy = CopyType.KitchenCopy Then tempStr = vbCrLf + tempStr
                PrintAt(tempStr, CentrePOS(tempStr), CurYPOS)
                CurYPOS = CurYPOSLast
            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub PrintDateTime()

        Dim strMyDateTime As String = String.Empty

        If CurrentOrderType = OrderTypeEnum.Table Then
            strMyDateTime = objDatabase.ReadTablesDB("PrintedTime")
            If ShopOrKitchenCopy = CopyType.ShopCopy Then
                If (GetAppSettingCS("PrintShopDate", 1) <> 0) And (GetAppSettingCS("PrintShopTime", 1) <> 0) Then
                    'its all ok no need to do anything
                ElseIf GetAppSettingCS("PrintShopDate", 1) <> 0 Then
                    strMyDateTime = strMyDateTime.Substring(strMyDateTime.IndexOf("  ")).Trim
                ElseIf GetAppSettingCS("PrintShopTime", 1) <> 0 Then
                    strMyDateTime = strMyDateTime.Substring(0, strMyDateTime.IndexOf("  ")).Trim
                End If

            ElseIf ShopOrKitchenCopy = CopyType.KitchenCopy Then
                If (GetAppSettingCS("PrintKitchenDate", 1) <> 0) And (GetAppSettingCS("PrintKitchenTime", 1) <> 0) Then
                    'its all ok no need to do anything
                ElseIf GetAppSettingCS("PrintKitchenDate", 1) <> 0 Then
                    strMyDateTime = strMyDateTime.Substring(strMyDateTime.IndexOf("  ")).Trim
                ElseIf GetAppSettingCS("PrintKitchenTime", 1) <> 0 Then
                    strMyDateTime = strMyDateTime.Substring(0, strMyDateTime.IndexOf("  ")).Trim
                End If
            End If

        Else

            If ShopOrKitchenCopy = CopyType.ShopCopy Then
                If (GetAppSettingCS("PrintShopDate", 1) <> 0) And (GetAppSettingCS("PrintShopTime", 1) <> 0) Then
                    strMyDateTime = GetDTString("DT")
                ElseIf GetAppSettingCS("PrintShopDate", 1) <> 0 Then
                    strMyDateTime = GetDTString("D")
                ElseIf GetAppSettingCS("PrintShopTime", 1) <> 0 Then
                    strMyDateTime = GetDTString("T")
                End If

            ElseIf ShopOrKitchenCopy = CopyType.KitchenCopy Then
                If (GetAppSettingCS("PrintKitchenDate", 1) <> 0) And (GetAppSettingCS("PrintKitchenTime", 1) <> 0) Then
                    strMyDateTime = GetDTString("DT")
                ElseIf GetAppSettingCS("PrintKitchenDate", 1) <> 0 Then
                    strMyDateTime = GetDTString("D")
                ElseIf GetAppSettingCS("PrintKitchenTime", 1) <> 0 Then
                    strMyDateTime = GetDTString("T")
                End If
            End If

        End If

        If strMyDateTime <> String.Empty Then
            'print the date and time
            curPrintFont = New Font("Arial", 9, FontStyle.Regular)
            If ShopOrKitchenCopy = CopyType.KitchenCopy Then
                If CurrentOrderType = OrderTypeEnum.Table Then
                Else
                    strMyDateTime = vbCrLf & vbCrLf & strMyDateTime
                End If
            End If
            PrintAt(strMyDateTime, CentrePOS(strMyDateTime), CurYPOS)
        End If

    End Sub

    Private Sub PrintFooterImage()

        If ShopOrKitchenCopy = CopyType.ShopCopy AndAlso File.Exists(AppPath() & "ezfooter.jpg") = True Then
            Dim img As Image = Image.FromFile(AppPath() & "ezfooter.jpg")
            'image size in 1/100 inch measurement
            Dim sz As New SizeF(100 * img.Width / img.HorizontalResolution, 100 * img.Height / img.VerticalResolution)
            Dim p As New PointF((myPapersize.Width - sz.Width) / 2, CurYPOS)
            evPtPgEvArg.Graphics.DrawImage(img, p)
            img.Dispose()
        End If

    End Sub

    Private Sub PaperSizeProc(strSorK As String)
        'make paper a certain length, otherwise it looks too small!

        Dim tempValx
        If strSorK = "S" Then
            tempValx = CInt(GetAppSettingCS("MinPaperS", 10))
        Else
            tempValx = CInt(GetAppSettingCS("MinPaperK", 1))
        End If

        If tempValx > 20 Then tempValx = 20
        If tempValx < 0 Then tempValx = 0

        tempValx *= 50

        Do While CurYPOS < tempValx
            'PrintAt(CInt(CurrentYPOS) & "-" & tempValx & vbCrLf, 0, CurrentYPOS)
            PrintAt("" & vbCrLf, 0, CurYPOS)
        Loop

    End Sub

    Private Function GetDTString(DorT As String)

        Dim strDTTemp As String
        Dim strXTemp As String = String.Empty

        Dim strDateString As String
        Dim strTimeString As String

        Try
            If DorT = "DT" Then
                strTimeString = objDatabase.ReadDB("OrderTime")
                If strTimeString = String.Empty Then
                    strTimeString = "Time: " & Date.Now.ToString("h:mm")
                Else
                    strTimeString = "Time: " & CDate(strTimeString).ToString("h:mm")
                End If

                strDateString = objDatabase.ReadDB("OrderDate")
                If strDateString = String.Empty Then
                    strDateString = "Date: " & Date.Now.ToString("dd/MM/yy")
                Else
                    strDateString = "Date: " & CDate(strDateString).ToString("dd/MM/yy")
                End If

                strDTTemp = strTimeString & Space(4) & strDateString

            ElseIf DorT = "D" Then
                strDTTemp = objDatabase.ReadDB("OrderDate")
                If strDTTemp = String.Empty Then strDTTemp = Format(Date.Now, "dd/MM/yy")
                strDTTemp = "Date: " & CDate(strXTemp).ToString("dd/MM/yy")

            Else
                strDTTemp = objDatabase.ReadDB("OrderTime")
                If strDTTemp = String.Empty Then strDTTemp = Format(Date.Now, "h:mm")
                strDTTemp = "Time: " & CDate(strDTTemp).ToString("h:mm")
            End If

        Catch ex As Exception
            WriteToLog(ex)
            strDTTemp = String.Empty
        End Try

        Return strDTTemp

    End Function

    Private Function GetCustomerDirections() As String

        SQLQuery = "SELECT * FROM Directions WHERE CustomerID = " & objDatabase.ReadOrdersDB("CustomerID")

        drDataRow = objDB.GetSingleRow(SQLQuery)
        If drDataRow IsNot Nothing Then
            Return drDataRow!Directions.ToString.Trim
        Else
            Return String.Empty
        End If

    End Function

    Private Sub PrintCustomerNote()

        Exit Sub
        ' SMX - fix the below code to work with online orders

        If objDatabase.ReadOrdersDB("UserName") = "Online" Then
            tempStrx = objDatabase.ReadOrdersDB("KitchenNote")
            If tempStrx <> String.Empty Then
                tempStrx = Replace(tempStrx, "^", vbCrLf).Trim
                tempStrx = Replace(tempStrx, "@", vbCrLf & "@").Trim
                curPrintFont = New Font("Arial", 11, FontStyle.Regular)
                If GetAppSettingCS("OLPrintPayPalID", 0) = 0 Then
                    Dim h As Short = tempStrx.IndexOf("PayPal status")
                    If h <> -1 Then
                        Dim tmpStr As String = tempStrx.Substring(0, h)
                        h = tempStrx.IndexOf(" GBP")
                        tmpStr &= tempStrx.Substring(h + 4)
                        tempStrx = tmpStr.Trim
                    End If
                End If
                If tempStrx <> String.Empty Then
                    PrintAt(vbCrLf, 0, CurYPOS)
                    PrintAt(WordWrap(tempStrx, curPrintFont), 10, CurYPOS)
                End If
            End If
        End If

    End Sub

    Private Function WordWrap(wText As String, wFont As Font,
                              Optional intSpaces As Short = 0,
                              Optional wMaxWidth As Integer = -1) As String

        Dim strWordsArray As String() = WordWrapArray(wText, wFont, wMaxWidth)
        Dim strTemp As String = String.Empty

        For arr = 0 To strWordsArray.Count - 1
            strTemp &= Space(intSpaces) & strWordsArray(arr).ToString
            If arr < strWordsArray.Count - 1 Then strTemp &= vbCrLf
        Next

        Return strTemp

    End Function

    Private Function WordWrapArray(vText As String, vFont As Font, Optional vMaxWidth As Integer = -1) As String()

        'Define a new collection of wrapped lines
        Dim WrappedLines As New List(Of String)()

        'Create a 'working copy' of the text
        Dim Line As String = vText.Trim()

        'Calculate the text's current width
        Dim CurrentWidth As Integer = TextRenderer.MeasureText(vText, vFont).Width

        If vMaxWidth = -1 Then vMaxWidth = evPtPgEvArg.PageSettings.PaperSize.Width

        'Don't wrap if the text already fits
        If CurrentWidth <= vMaxWidth Then
            WrappedLines.Add(vText)

        Else
            'Repeatedly remove the last character until the text fits
            While CurrentWidth > vMaxWidth
                Line = Line.Remove(Line.Length - 1, 1).Trim()
                CurrentWidth = TextRenderer.MeasureText(Line, vFont).Width
            End While

            'If applicable, wrap on the last space instead of cutting words in half
            Dim IndexOfLastSpace As Integer = Line.LastIndexOf(" "c)
            If IndexOfLastSpace > -1 Then
                Line = Line.Remove(IndexOfLastSpace, Line.Length - IndexOfLastSpace)
            End If

            'Add the wrapped line to the collection
            WrappedLines.Add(Line)

            'Recursively wrap the remainder of the text
            Dim Remainder As String = vText.Remove(0, Line.Length).Trim()
            WrappedLines.AddRange(WordWrapArray(Remainder, vFont, vMaxWidth))
        End If

        Return WrappedLines.ToArray()

    End Function

End Class