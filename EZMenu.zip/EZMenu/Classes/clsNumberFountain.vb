﻿Public Class clsNumberFountain

    Private shtNumber As Short

    Public ReadOnly Property NextId As Short
        Get
            If shtNumber < Short.MaxValue Then
                shtNumber += 1
            Else
                MsgBox("clsNumberFountain.NextId - overflow; cannot assign next value; current value = " & shtNumber)
            End If
            Return shtNumber
        End Get
    End Property

    Public Sub New()
        SetMaxValue()
    End Sub

    Private Sub SetMaxValue()
        'query the DB and set the starting value

        drDataRow = objDB.GetSingleRow("SELECT MAX(TabUniqueID) FROM Table_Bill")
        If drDataRow IsNot Nothing AndAlso Not IsDBNull(drDataRow(0)) Then
            shtNumber = Short.Parse(drDataRow(0))
        Else
            shtNumber = 0
        End If

    End Sub

End Class