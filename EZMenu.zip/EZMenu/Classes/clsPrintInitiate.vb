﻿Public Class clsPrintOrderClass

    Public Sub Print(OrderNumber As Short)

        Dim Order1 As New clsOrderPrintHandler
        Dim Order2 As New clsOrderPrintHandler
        blnPrintDone = False

        With Order1
            .PrinterLocation = clsOrderPrintHandler.PLocation.PrinterKitchen
            .OrderNumber = OrderNumber
            .DirectCopy = False
            .Print()
        End With

        If GetAppSettingCS("SimultaneousPrinting", 0) = 0 Then
            Dim tmNowTime = Date.Now.AddSeconds(10)
            Do Until Date.Now > tmNowTime Or blnPrintDone = True
                Application.DoEvents()
            Loop
        End If

        With Order2
            .PrinterLocation = clsOrderPrintHandler.PLocation.PrinterShop
            .OrderNumber = OrderNumber
            .DirectCopy = False
            .Print()
        End With

        ResetTabletField(OrderNumber)

    End Sub

    Public Sub Print(OrderNumber As Short, ShopORKitchenCopy As clsOrderPrintHandler.CopyType, PrinterLocation As clsOrderPrintHandler.PLocation)

        Dim Order1 As New clsOrderPrintHandler
        With Order1
            .PrinterLocation = PrinterLocation
            .ShopOrKitchenCopy = ShopORKitchenCopy
            .OrderNumber = OrderNumber
            .DirectCopy = True
            .Print()
        End With

        ResetTabletField(OrderNumber)

    End Sub

    Private Sub ResetTabletField(orderNumber As Short)

        Try
            Dim sql As String = $"UPDATE Orders SET OrderMethod = NULL WHERE OrderID = { orderNumber } AND OrderMethod = 'Tablet'"
            objDB.ExeNonQuery(sql)

        Catch ex As Exception
        End Try

    End Sub

    Public Sub Print(TableUniqueID As Single)

        Dim Order1 As New clsOrderPrintHandler
        With Order1
            .PrinterLocation = clsOrderPrintHandler.PLocation.PrinterKitchen
            .TableUniqueID = TableUniqueID
            .DirectCopy = False
            .PrintTable()
        End With

        Dim Order2 As New clsOrderPrintHandler
        With Order2
            .PrinterLocation = clsOrderPrintHandler.PLocation.PrinterShop
            .TableUniqueID = TableUniqueID
            .DirectCopy = False
            .PrintTable()
        End With

    End Sub

    Public Sub Print(TableUniqueID As Single, ShopORKitchenCopy As clsOrderPrintHandler.CopyType)

        Dim OrderT As New clsOrderPrintHandler
        With OrderT
            .ShopOrKitchenCopy = ShopORKitchenCopy
            If .ShopOrKitchenCopy = clsOrderPrintHandler.CopyType.KitchenCopy Then
                .PrinterLocation = clsOrderPrintHandler.PLocation.PrinterKitchen
            Else
                .PrinterLocation = clsOrderPrintHandler.PLocation.PrinterShop
            End If
            .TableUniqueID = TableUniqueID
            .PrintTable()
        End With

    End Sub

    Public Sub Print(TableUniqueID As Single, ShopORKitchenCopy As clsOrderPrintHandler.CopyType, PrinterLocation As clsOrderPrintHandler.PLocation)

        Dim OrderT As New clsOrderPrintHandler
        With OrderT
            .ShopOrKitchenCopy = ShopORKitchenCopy
            If .ShopOrKitchenCopy = clsOrderPrintHandler.CopyType.KitchenCopy Then
                .PrinterLocation = clsOrderPrintHandler.PLocation.PrinterKitchen
            Else
                .PrinterLocation = clsOrderPrintHandler.PLocation.PrinterShop
            End If
            .TableUniqueID = TableUniqueID
            .PrintTable()
        End With

    End Sub

End Class
