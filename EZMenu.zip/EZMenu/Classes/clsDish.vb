﻿Public Class clsDish
    Friend Shared Function GetDishDetails(sngUniqueID As Single) As DataRow

        SQLQuery = $"SELECT d.UniqueID, d.Code, d.DishName, 
                        CASE WHEN ShortName IS NULL OR ShortName = '' THEN DishName ELSE ShortName END AS ShortName, 
                        d.PriceIn, d.PriceOut, d.DoButton, d.Discountable, d.PrintLabel, d.GroupName, g.GroupIndex 
                    FROM Dish d
                        LEFT OUTER JOIN DishShortName dsn ON d.UniqueID = dsn.UniqueID 
                        INNER JOIN Groups g ON d.GroupName = g.GroupName 
                    WHERE d.UniqueID = { sngUniqueID }"

        Return objDB.GetSingleRow(SQLQuery)

    End Function

    Friend Shared Sub DeleteShortcode(strCuisine As String, strKey As String)

        SQLQuery = $"DELETE c 
                     FROM Codes c 
                        JOIN Dish d ON c.UniqueID = d.UniqueID 
                        JOIN Groups g ON d.GroupName = g.GroupName 
                     WHERE g.CuisineName = '{ strCuisine.Punctuate }' AND c.ShortCode = '{ strKey }'"
        objDB.ExeNonQuery(SQLQuery)

    End Sub

    Friend Shared Function CodeInUse(strCuisine As String, strCodeToAdd As String) As Boolean

        SQLQuery = $"SELECT d.DishName, c.ShortCode
                     FROM Codes c 
                        INNER JOIN Dish d ON c.UniqueID = d.UniqueID 
                        INNER JOIN Groups g ON d.GroupName = g.GroupName
                     WHERE g.CuisineName = '{ strCuisine.Punctuate }' AND c.ShortCode = '{ strCodeToAdd }'"

        drDataRow = objDB.GetSingleRow(SQLQuery)
        Return (drDataRow IsNot Nothing)

    End Function

    Friend Shared Sub CodeInsert(strUniqueID As String, strShortCode As String)

        SQLQuery = $"INSERT INTO Codes (UniqueID, ShortCode) VALUES ({ strUniqueID.Punctuate }, '{ strShortCode.Punctuate }')"
        objDB.ExeNonQuery(SQLQuery)

    End Sub

    Friend Shared Sub DeleteShortname(value As Object)

        SQLQuery = "DELETE FROM DishShortName WHERE UniqueID = " & value
        objDB.ExeNonQuery(SQLQuery)

    End Sub

    Friend Shared Sub DSLInsert(sngUniqueID As Single, strSmall As String, strLarge As String)

        SQLQuery = $"INSERT INTO DishSmallLarge (UniqueID, Small, Large) 
                     VALUES ({ sngUniqueID }, { strSmall }, { strLarge })"
        objDB.ExeNonQuery(SQLQuery)

    End Sub

    Friend Shared Sub DSLDelete(sngUniqueID As Single)

        SQLQuery = "DELETE FROM DishSmallLarge WHERE UniqueID = " & sngUniqueID
        objDB.ExeNonQuery(SQLQuery)

    End Sub

    Friend Shared Function ExistsDishname(strDish As String, strCuisine As String) As Boolean

        SQLQuery = $"SELECT d.DishName
                    FROM Dish d JOIN Groups g 
                        ON d.GroupName = g.GroupName 
                    WHERE(d.DishName = '{ strDish.Punctuate }' AND g.CuisineName = '{ strCuisine.Punctuate }')"
        Dim dr As DataRow = objDB.GetSingleRow(SQLQuery)
        Return (dr IsNot Nothing)

    End Function

    Friend Shared Function ExistsShortname(strShortname As String, strCuisine As String) As Boolean

        SQLQuery = $"SELECT ds.ShortName 
                     FROM Dish d
                        INNER JOIN DishShortName ds ON d.UniqueID = ds.UniqueID 
                        INNER JOIN Groups g ON d.GroupName = g.GroupName 
                     WHERE (g.CuisineName = '{ strCuisine }' AND ds.ShortName = '{ strShortname }')"
        Dim dr As DataRow = objDB.GetSingleRow(SQLQuery)
        Return (dr IsNot Nothing)

    End Function

    Friend Shared Function ExistsShortcode(strCode As String, strCuisine As String) As Boolean

        SQLQuery = $"SELECT c.ShortCode, g.CuisineName 
                     FROM Codes c 
                        INNER JOIN Dish d On c.UniqueID = d.UniqueID
                        INNER JOIN Groups g ON d.GroupName = g.GroupName 
                     WHERE (c.ShortCode = '{ strCode }') AND (g.CuisineName = '{ strCuisine }')"
        Dim dr As DataRow = objDB.GetSingleRow(SQLQuery)
        Return (dr IsNot Nothing)

    End Function

    Friend Shared Sub AddNewDish(nCode As String, nDName As String, nPriceIn As String, nPriceOut As String, nGroup As String)

        SQLQuery = $"INSERT INTO Dish (Code, DishName, PriceIn, PriceOut, PrintLabel, GroupName, DoButton) 
                     VALUES ({ nCode }, '{ nDName.Punctuate }', { nPriceIn }, { nPriceOut }, -1, '{ nGroup }', 'True')"
        objDB.ExeNonQuery(SQLQuery)

    End Sub

    Friend Shared Function GetDishName(sngUniqueID As Short, strDCode As String) As DataRowCollection

        If IsANumber(strDCode) Then
            SQLQuery = $"SELECT d.UniqueID, d.DishName, CASE WHEN ds.ShortName IS NULL OR ds.ShortName = '' THEN d.DishName ELSE ds.ShortName END AS ShortName
                         FROM Dish d LEFT OUTER JOIN DishShortName ds ON d.UniqueID = ds.UniqueID
                         WHERE d.UniqueID = { sngUniqueID }"
        Else
            SQLQuery = $"SELECT 1 AS OrdID, d.UniqueID, dc.DishName, dc.ShortName 
                         FROM Dish d INNER JOIN DishCascade dc ON d.UniqueID = dc.UniqueID 
                         WHERE (d.UniqueID = { sngUniqueID } AND dc.Shortcode = '{ strDCode }') 
                         UNION 
                         SELECT 2 AS OrdID, d.UniqueID, DishName, CASE WHEN ShortName IS NULL OR ShortName = '' THEN DishName ELSE ShortName END AS ShortName
                         FROM Dish d LEFT OUTER JOIN DishShortName ds ON d.UniqueID = ds.UniqueID  
                         WHERE d.UniqueID = { sngUniqueID }"
        End If

        Return objDB.GetDataRows(SQLQuery)

    End Function

    Friend Shared Sub AddShortCode(uniqueButtonID As Short, nSCode As String)

        SQLQuery = "INSERT INTO Codes (UniqueID, ShortCode) VALUES (" & uniqueButtonID & ",'" & nSCode & "')"
        objDB.ExeNonQuery(SQLQuery)

    End Sub

    Friend Shared Sub AddShortName(uniqueButtonID As Short, nPName As String)

        SQLQuery = "INSERT INTO DishShortName (UniqueID, ShortName) VALUES (" & uniqueButtonID & ",'" & nPName.Punctuate & "')"
        objDB.ExeNonQuery(SQLQuery)

    End Sub

    Friend Shared Function GetMaxCodeUniqueID(strCuisine As String) As DataRow

        SQLQuery = $"SELECT MAX(Code) AS MaxCode, MAX(UniqueID) AS MaxUniqueID 
                     FROM  (SELECT d.UniqueID, d.Code 
                            FROM Dish d JOIN Groups g ON d.GroupName = g.GroupName 
                            WHERE g.CuisineName = '{strCuisine}') AS Temptable"

        Return objDB.GetSingleRow(SQLQuery)

    End Function

    Friend Shared Sub SaveDishHistory()

        Dim strDish As String
        Dim intQty As Short
        Dim drcRecords As DataRowCollection
        Dim strTodaysDate As String = GetDateNow()

        Try

            'save delivery dishes (CustomerID < intMaxCustomerID)
            SQLQuery = $"SELECT oi.DishName, SUM(oi.Qty) AS Qty 
                         FROM OrderItems oi INNER JOIN Orders o ON oi.OrderID = o.OrderID 
                         WHERE o.CustomerID < { intMaxCustomerID }
                         GROUP BY oi.DishName"

            drcRecords = objDB.GetDataRows(SQLQuery)
            If drcRecords IsNot Nothing Then
                For Each myRow As DataRow In drcRecords
                    strDish = myRow!DishName.ToString.Punctuate
                    intQty = myRow!Qty
                    SQLQuery = $"SELECT TDish FROM DishHistory WHERE TDate = '{strTodaysDate}' AND TDish = '{strDish}'"
                    drDataRow = objDB.GetSingleRow(SQLQuery)
                    If drDataRow IsNot Nothing Then
                        'update dish qty
                        SQLQuery = $"UPDATE DishHistory SET TDelivery = {intQty} WHERE TDate = '{strTodaysDate}' AND TDish = '{strDish}'"
                    Else
                        'does not exist so insert it
                        SQLQuery = $"INSERT INTO DishHistory (TDate, TDish, TDelivery) VALUES ('{strTodaysDate}', '{strDish}', {intQty})"
                    End If
                    objDB.ExeNonQuery(SQLQuery)
                Next
            End If

            'save pickup dishes (CustomerID >= intMaxCustomerID)
            SQLQuery = $"SELECT oi.DishName, SUM(oi.Qty) AS Qty
                         FROM OrderItems oi INNER JOIN Orders o ON oi.OrderID = o.OrderID 
                         WHERE o.CustomerID >= {intMaxCustomerID} 
                         GROUP BY oi.DishName"

            drcRecords = objDB.GetDataRows(SQLQuery)
            If drcRecords IsNot Nothing Then
                For Each myRow As DataRow In drcRecords
                    strDish = myRow!DishName.ToString.Punctuate
                    intQty = myRow!Qty
                    SQLQuery = $"SELECT TDish FROM DishHistory WHERE TDate = '{strTodaysDate}' AND TDish = '{strDish}'"
                    drDataRow = objDB.GetSingleRow(SQLQuery)
                    If drDataRow IsNot Nothing Then
                        'update dish qty
                        SQLQuery = $"UPDATE DishHistory SET TPickup = {intQty} WHERE TDate = '{strTodaysDate}' AND TDish = '{strDish}'"
                        objDB.ExeNonQuery(SQLQuery)
                    Else
                        'does not exist so insert it
                        SQLQuery = $"INSERT INTO DishHistory (TDate, TDish, TPickup) VALUES ('{strTodaysDate}', '{strDish}', {intQty})"
                        objDB.ExeNonQuery(SQLQuery)
                    End If
                Next
            End If

            'save table dishes
            SQLQuery = "SELECT DishName, SUM(DishQty) AS Qty
                        FROM Table_Meal 
                        GROUP BY DishName"

            drcRecords = objDB.GetDataRows(SQLQuery)
            If drcRecords IsNot Nothing Then
                For Each myRow As DataRow In drcRecords
                    strDish = myRow!DishName.ToString.Punctuate
                    intQty = myRow!Qty
                    SQLQuery = $"SELECT TDish FROM DishHistory WHERE TDate = '{strTodaysDate}' AND TDish = '{strDish}'"
                    drDataRow = objDB.GetSingleRow(SQLQuery)
                    If drDataRow IsNot Nothing Then
                        'update dish qty
                        SQLQuery = $"UPDATE DishHistory SET TTable = {intQty} WHERE TDate = '{strTodaysDate}' AND TDish = '{strDish}'"
                        objDB.ExeNonQuery(SQLQuery)
                    Else
                        'does not exist so insert it
                        SQLQuery = $"INSERT INTO DishHistory (TDate, TDish, TTable) VALUES ('{strTodaysDate}', '{strDish}', {intQty})"
                        objDB.ExeNonQuery(SQLQuery)
                    End If
                Next
            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

End Class