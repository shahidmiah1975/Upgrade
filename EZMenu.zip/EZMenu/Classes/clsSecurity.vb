﻿Imports System.IO

Public Class clsSecurity

    <DebuggerStepThrough()>
    Public Function MD5Hash(strToHash As String) As String

        Dim md5Obj As New Security.Cryptography.MD5CryptoServiceProvider
        Dim strResult As String = ""
        Dim bytesToHash() As Byte = Text.Encoding.ASCII.GetBytes(strToHash)

        bytesToHash = md5Obj.ComputeHash(bytesToHash)
        For Each b As Byte In bytesToHash
            strResult &= b.ToString("x2")
        Next

        Return strResult

    End Function

    Public Function PadMD5Result(strToPad As String) As String
        'put dashes (-) between every four characters in the serial number
        'e.g. 1234567890123456 returns 1234-5678-9012-3456

        Dim tempToPad As String = ""

        For iCntr As Short = 1 To strToPad.Length Step 4
            tempToPad = tempToPad & Mid$(strToPad, iCntr, 4) & "-"
        Next
        If Right$(tempToPad, 1) = "-" Then tempToPad = Left$(tempToPad, tempToPad.Length - 1)
        Return tempToPad.ToUpper.Trim

    End Function

    <DebuggerStepThrough()>
    Public Function MD5Hash_ThenSplitAndSwap(strWorkstring) As String

        strWorkstring = objSecurity.MD5Hash(strWorkstring)
        Return strWorkstring.Substring(16) & strWorkstring.Substring(0, 16)

    End Function

    ' <DebuggerStepThrough()>
    Public Function AES_Encrypt(input As String) As String

        Dim AES As New Security.Cryptography.RijndaelManaged
        Dim Hash_AES As New Security.Cryptography.MD5CryptoServiceProvider
        Dim pass As String = My.Resources.ezresource.secretword

        Try
            Dim hash(31) As Byte
            Dim temp As Byte() = Hash_AES.ComputeHash(Text.Encoding.ASCII.GetBytes(pass))
            Array.Copy(temp, 0, hash, 0, 16)
            Array.Copy(temp, 0, hash, 15, 16)
            AES.Key = hash
            AES.Mode = Security.Cryptography.CipherMode.ECB
            Dim DESEncrypter As Security.Cryptography.ICryptoTransform = AES.CreateEncryptor
            Dim Buffer As Byte() = Text.Encoding.ASCII.GetBytes(input)
            Dim encrypted As String = Convert.ToBase64String(DESEncrypter.TransformFinalBlock(Buffer, 0, Buffer.Length))
            Return encrypted
        Catch ex As Exception
        End Try
        Return Nothing

    End Function

    ' <DebuggerStepThrough()>
    Public Function AES_Decrypt(input As String) As String

        Dim AES As New Security.Cryptography.RijndaelManaged
        Dim Hash_AES As New Security.Cryptography.MD5CryptoServiceProvider
        Dim pass As String = My.Resources.ezresource.secretword
        Try
            Dim hash(31) As Byte
            Dim temp As Byte() = Hash_AES.ComputeHash(Text.Encoding.ASCII.GetBytes(pass))
            Array.Copy(temp, 0, hash, 0, 16)
            Array.Copy(temp, 0, hash, 15, 16)
            AES.Key = hash
            AES.Mode = Security.Cryptography.CipherMode.ECB
            Dim DESDecrypter As Security.Cryptography.ICryptoTransform = AES.CreateDecryptor
            Dim Buffer As Byte() = Convert.FromBase64String(input)
            Dim decrypted As String = Text.Encoding.ASCII.GetString(DESDecrypter.TransformFinalBlock(Buffer, 0, Buffer.Length))
            Return decrypted
        Catch ex As Exception
        End Try
        Return Nothing

    End Function

    Public Sub DisplaySuperError()

        If frmOpener.cmdManager.Tag <> "CloseLogin" Then
            strMsgBox = "You need supervisor password for that action"
            Alert(strMsgBox)
        End If

        frmOpener.cmdManager.Tag = "this is used to track if Close button pressed"

    End Sub

    Public Sub SaveHardwareIDs()

        Dim uString, vString As String

        Try
            uString = objSecurity.MD5Hash_ThenSplitAndSwap(GetWMI("BaseBoard", "Product"))
            vString = "BaseBoard!Product"
            objDB.EZSettingWrite(vString, uString)

            uString = objSecurity.MD5Hash_ThenSplitAndSwap(GetWMI("DiskDrive", "Model"))
            vString = "DiskDrive!Model"
            objDB.EZSettingWrite(vString, uString)

            uString = objSecurity.MD5Hash_ThenSplitAndSwap(GetWMI("Processor", "ProcessorId"))
            vString = "Processor!ProcessorId"
            objDB.EZSettingWrite(vString, uString)

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Public Function IsMySystem() As Boolean

        Try
            Return Directory.Exists("G:\SWARE")

        Catch ex As Exception
            DisplayError(ex)
            Return False
        End Try

    End Function

End Class