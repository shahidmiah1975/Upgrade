﻿Imports System.ComponentModel
Imports System.Configuration
Imports System.Data.SqlClient
Imports EZMenu.Core

Public Class clsFakeOrder

    Private intCusId As Short
    Private SQLQueryx As String
    Private idIdentityX
    Private WithEvents bgwSaveFakeOrder As BackgroundWorker
    Private drDatarowX As DataRow
    Private drcDatarowCollectionX As DataRowCollection
    Private arrTwoValues As New List(Of Integer)
    Private blnExitLoop As Boolean = False
    Private blnFakeOrderDone As Boolean

    Public ReadOnly Property FakeOrderDone() As Boolean
        Get
            Return blnFakeOrderDone
        End Get
    End Property

    Public Sub StartFakeOrder()

        Try

            blnFakeOrderDone = False

            bgwSaveFakeOrder = New BackgroundWorker
            bgwSaveFakeOrder.RunWorkerAsync()

        Catch ex As Exception
            'DisplayErrorMessage(ex.Message)
        End Try

    End Sub

    Private Sub bgwSaveFakeOrder_DoWork(sender As Object, e As DoWorkEventArgs) Handles bgwSaveFakeOrder.DoWork

        Dim intBizId, intNDishes, _FOrderID As Short
        Dim decTotalX, decSubtotalX As Decimal
        Dim y1, y2, strFakeCustomer As String

        'generate biz id
        'geniune orders are between 40 and 60 inclusive
        intBizId = IIf(Rnd() < 0.5, GetRandomNum(1, 39), GetRandomNum(61, 99))

        Try
            strFakeCustomer = GetFakeCustomer()
            If strFakeCustomer <> String.Empty Then

                intNDishes = GetRandomNum(5, 15)

                Dim dblTableID = GetUniqueTableID()

                'make sure this is unique
                Dim blnExitLoop As Boolean = False
                Do
                    SQLQueryx = "SELECT * FROM Table_Bill WHERE TabUniqueID = " & dblTableID
                    drcDatarowCollectionX = objDB.GetDataRows(SQLQueryx)
                    If drcDatarowCollectionX IsNot Nothing AndAlso drcDatarowCollectionX.Count > 0 Then
                        dblTableID = GetUniqueTableID()
                        blnExitLoop = False
                    Else
                        blnExitLoop = True
                    End If
                Loop While blnExitLoop = False

                'get random number of dishes
                SQLQueryx = $"SELECT TOP {intNDishes} Dish.UniqueID, Dish.Code, Dish.DishName, Dish.PriceOut, Groups.GroupIndex 
                              FROM Dish INNER JOIN Groups ON Dish.GroupName = Groups.GroupName 
                              ORDER BY NEWID()"

                Dim drcFakeDishes As DataRowCollection = objDB.GetDataRows(SQLQueryx)

                For Each mrow In drcFakeDishes
                    decTotalX += mrow!PriceOut
                Next
                decSubtotalX = decTotalX

                y1 = "CustomerID, OrderTime, OrderDate, ToPay, Subtotal"
                y2 = intCusId & ", '" & GetTimeNow() & "', '" & GetDateNow() & "', " & decTotalX & ", " & decSubtotalX

                y1 &= ", CustomerName, DeliveryAddress1, DeliveryAddress2, DeliveryAddress3, DeliveryPostcode, Telephone"
                y2 &= strFakeCustomer & ",''"

                Dim pMetd As String = ""
                Select Case Rnd()
                    Case Is < 0.2
                        pMetd = "Cash"
                    Case 0.2 To 0.4
                        pMetd = "Card"
                    Case Else
                End Select

                y1 &= ", OrderIsPaid, BizId, PayMethod, CuisineName, ButtonStatus"
                y2 &= ", " & GetRandomNum(0, 1) & ", " & intBizId & ", '" & pMetd & "', 'Indian', 0"

                y1 = "(" & y1 & ")"
                y2 = "(" & y2 & ");"

                SQLQueryx = "INSERT INTO Orders " & y1 & " VALUES " & y2
                ExeNonQueryFO(SQLQueryx)
                _FOrderID = idIdentityX

                Try
                    Dim numCusts As Short = GetRandomNum(1, 10)   'custs and CAP
                    tempStr = "Time: " & Format(Now.AddMinutes(GetRandomNum(40, 100)), "h:mm") & "    Date: " & Format(Now, "dd/MM/yy")
                    Dim decMT = GetRandomNum(5, 60)
                    Dim decDT = GetRandomNum(10, 50)
                    SQLQuery = String.Format("INSERT INTO Table_Bill (TableNumber, TabUniqueId, NumCust, BillTotal, MealTotal, DrinksTotal, TableStatus, " &
                                             "CAPValue, PrintedTime, EntryTime, BizId) VALUES ({0}, {1}, {2}, {3}, {4}, {5}, {6}, {7}, '{8}', '{9}', {10})",
                                            GetRandomNum(1, 10), dblTableID, numCusts, decDT + decMT, decMT, decDT, GetRandomNum(1, 4), numCusts, tempStr,
                                            Format(Now, "HH:mm:ss"), intBizId)
                    objDB.ExeNonQuery(SQLQuery)

                Catch ex As Exception
                End Try

                For Each mrow In drcFakeDishes
                    SQLQueryx = String.Format("INSERT INTO OrderItems (OrderID, Code, Dish, Qty, Mods, UnitPrice, Discountable, GroupIndex) " &
                                              "VALUES ({0}, {1}, '{2}', {3}, '{4}', {5}, {6}, {7})",
                                             _FOrderID, mrow!Code, mrow!DishName.ToString.Punctuate, GetRandomNum(1, 5), "00", mrow!PriceOut, 1, mrow!GroupIndex)
                    ExeNonQueryFO(SQLQueryx)

                    'put the same in table orders
                    SQLQueryx = String.Format("INSERT INTO Table_Meal (TabUniqueID, Code, DishName, DishPrice, DishQty, IsStarter, GroupIndex, Mods, Discountable) " &
                                              "VALUES ({0}, {1}, '{2}', {3}, {4}, {5}, {6}, '{7}', {8})",
                                     dblTableID, mrow!Code, mrow!DishName.ToString.Punctuate, mrow!PriceOut, GetRandomNum(1, 50), 0, mrow!GroupIndex, "00", -1)
                    ExeNonQueryFO(SQLQueryx)
                Next

            End If

            blnFakeOrderDone = True

        Catch ex As Exception
            'DisplayErrorMessage(ex.Message, "Error in proc bgwSaveF*Order.DoWork:")
        End Try

    End Sub

    Private Function GetFakeCustomer()

        Dim tempStrZ As String = String.Empty
        SQLQueryx = "SELECT TOP(1) * FROM Customer ORDER BY NEWID()"
        drDatarowX = objDB.GetSingleRow(SQLQueryx)
        If drDatarowX IsNot Nothing Then
            intCusId = drDatarowX!CustomerID
            tempStrZ = ", '" & drDatarowX!Name.ToString.Punctuate & "'"
            tempStrZ &= ", '" & drDatarowX!Address1.ToString.Punctuate & "'"
            tempStrZ &= ", '" & drDatarowX!Address2.ToString.Punctuate & "'"
            tempStrZ &= ", '" & drDatarowX!Address3.ToString.Punctuate & "'"
            tempStrZ &= ", '" & drDatarowX!Postcode.ToString.Punctuate & "'"
            tempStrZ &= ", '" & drDatarowX!Phone & "'"
        End If

        Return tempStrZ

    End Function

    Private Function GetUniqueTableID()

        Dim intExitValue As Short = 0

        arrTwoValues.Clear()

        Do
            DoRandomValues()
            intExitValue += 1
        Loop Until (arrTwoValues(2) <> 0 Or intExitValue > 5)

        If intExitValue > 5 Then
            Return Date.Now.TimeOfDay.TotalSeconds
        Else
            Return arrTwoValues(2)
        End If

    End Function

    Private Sub DoRandomValues()

        Try
            Threading.Thread.Sleep(2)
            SQLQueryx = "SELECT TabUniqueID FROM Table_Bill ORDER BY TabUniqueID ASC"
            drcDatarowCollectionX = objDB.GetDataRows(SQLQueryx)
            If drcDatarowCollectionX IsNot Nothing AndAlso drcDatarowCollectionX.Count > 2 Then
                'pick a random position
                Dim intRanPos = GetRandomNum(1, drcDatarowCollectionX.Count - 1)
                Dim val1 = drcDatarowCollectionX(intRanPos)("TabUniqueID")
                Dim val2 = drcDatarowCollectionX(intRanPos + 1)("TabUniqueID")
                If (val2 - val1 > 2) Then
                    Dim myValue = GetRandomNum(val1 + 1, val2 - 1)
                    If (myValue = val1 Or myValue = val2) Then
                        arrTwoValues.Add(0)
                        arrTwoValues.Add(0)
                        arrTwoValues.Add(0)
                    Else
                        arrTwoValues.Add(val1)
                        arrTwoValues.Add(val2)
                        arrTwoValues.Add(myValue)
                    End If
                Else
                    arrTwoValues.Add(1)
                    arrTwoValues.Add(1)
                    tempStr = CInt(Date.Now.TimeOfDay.TotalSeconds).ToString
                    arrTwoValues.Add(tempStr)
                End If
            Else
                arrTwoValues.Add(1)
                arrTwoValues.Add(1)
                tempStr = CInt(Date.Now.TimeOfDay.TotalSeconds).ToString
                arrTwoValues.Add(tempStr)
            End If

        Catch ex As Exception
            'DisplayErrorMessage(ex.Message)
        End Try

    End Sub

    Private Sub ExeNonQueryFO(queryString As String)

        Using connectionX As New SqlConnection(ConfigurationManager.ConnectionStrings(EZConstants.EZDatabaseConnectionString).ConnectionString)

            Try
                Dim commandX As New SqlCommand(queryString, connectionX) With {
                    .CommandTimeout = 120
                }
                connectionX.Open()
                commandX.ExecuteNonQuery()
                Application.DoEvents()
                Try
                    idIdentityX = Nothing
                    If InStr(queryString, "INSERT INTO") Then
                        commandX.CommandText = "SELECT SCOPE_IDENTITY()"
                        idIdentityX = commandX.ExecuteScalar()
                    End If
                Catch ex As Exception
                    'nothing to do here
                End Try
                connectionX.Close()
            Catch ex As Exception
                'DisplayErrorMessage(ex.Message, "ExeNonQueryX in class FOrder failed:" & vbCrLf & queryString)
            End Try

        End Using

    End Sub

End Class