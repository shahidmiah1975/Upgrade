﻿Imports Infragistics.Win

Public Class clsOrder

    Friend Shared Function GetUsers() As IValueList

        Dim secList As New ValueList()
        SQLQuery = "SELECT UserName FROM Users"
        drcDatarowCollection = objDB.GetDataRows(SQLQuery)
        If drcDatarowCollection.Count > 0 Then
            secList.ValueListItems.Add("", "")
            For Each myRow As DataRow In drcDatarowCollection
                secList.ValueListItems.Add(myRow!UserName, myRow!UserName)
            Next
        End If

        Return secList

    End Function

    Friend Shared Function OnlineShops() As IValueList

        Dim secList As New ValueList()
        SQLQuery = "SELECT * FROM OnlineShops"
        drcDatarowCollection = objDB.GetDataRows(SQLQuery)
        If drcDatarowCollection.Count > 0 Then
            secList.ValueListItems.Add("", "")
            For Each myRow As DataRow In drcDatarowCollection
                secList.ValueListItems.Add(myRow!ShopName, myRow!ShopName)
            Next
        End If

        Return secList

    End Function

    Friend Shared Function GetAllOrders() As DataTable

        SQLQuery = "SELECT * FROM Orders WHERE BizId BETWEEN 40 AND 60 ORDER BY OrderTime DESC, OrderID DESC"
        Return objDB.GetDataTable(SQLQuery)

    End Function

    Friend Shared Function DeletePastOrders()

        Try

            If GetAppSettingCS("AutoDeleteOrders", True) Then

                Dim datVal As Date = Now.AddHours(-4)
                Dim dtCutoffTime As New Date(datVal.Year, datVal.Month, datVal.Day)
                SQLQuery = "SELECT * FROM Orders WHERE OrderDate < '" & Format(dtCutoffTime, "dd/MMM/yyyy") & "'"
                drcDatarowCollection = objDB.GetDataRows(SQLQuery)
                If drcDatarowCollection.Count > 0 Then
                    '...now delete everything in Order Details
                    For Each drow As DataRow In drcDatarowCollection
                        SQLQuery = "DELETE FROM OrderItems WHERE OrderID = " & drow("OrderID")
                        objDB.ExeNonQuery(SQLQuery)
                    Next
                End If

                SQLQuery = "DELETE FROM Orders WHERE OrderDate < '" & Format(dtCutoffTime, "dd/MMM/yyyy") & "'"
                objDB.ExeNonQuery(SQLQuery)

                'truncate tables if orders are clean
                SQLQuery = "SELECT * FROM Orders"
                drcDatarowCollection = objDB.GetDataRows(SQLQuery)
                If drcDatarowCollection.Count = 0 Then
                    objDB.ExeNonQuery("TRUNCATE TABLE OrderMods")
                    objDB.ExeNonQuery("TRUNCATE TABLE OrderItems")
                    objDB.ExeNonQuery("TRUNCATE TABLE Orders")
                End If

            End If

            Return True

        Catch ex As Exception
            Return False
        End Try

    End Function

End Class
