﻿Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("EZ-Menu")>
<Assembly: AssemblyDescription("EPOS System for Restaurants & Takeaways")>
<Assembly: AssemblyCompany("EZ-Menu Systems")>
<Assembly: AssemblyProduct("EZ-Menu")>
<Assembly: AssemblyCopyright("Copyright © Shahid Miah 2001-2025")>
<Assembly: AssemblyTrademark("")>

<Assembly: ComVisible(False)>

<Assembly: log4net.Config.XmlConfigurator(ConfigFile:="app.config", Watch:=True)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("edabc943-7ca1-4de2-acda-abd907997815")>

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("3.0.1")>
<Assembly: AssemblyFileVersion("3.0.1")>
