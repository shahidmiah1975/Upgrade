﻿Public Enum OrderTypeDCT
    Delivery
    Collection
    Table
    EditOn
    EditOff
End Enum