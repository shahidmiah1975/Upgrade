﻿<?xml version="1.0" encoding="utf-8"?>
<styleLibrary office2007CustomBlendColor="" office2013ColorScheme="LightGray" office2013CustomBlendColor="" office2013Theme="Outlook">
  <annotation>
    <lastModified>2025-03-07T22:34:53</lastModified>
  </annotation>
  <styleSets>
    <styleSet name="Default">
      <componentStyles>
        <componentStyle name="Inbox ListView">
          <properties>
            <property name="BackColor" colorCategory="{Default}">255, 255, 128</property>
            <property name="BorderStyle" colorCategory="{Default}">FixedSingle</property>
          </properties>
        </componentStyle>
        <componentStyle name="UltraButton">
          <properties>
            <property name="UseHotTracking" colorCategory="{Default}">True</property>
          </properties>
        </componentStyle>
        <componentStyle name="UltraGrid" useOsThemes="False" useFlatMode="True" />
        <componentStyle name="UltraListView" useOsThemes="False" useFlatMode="True" />
      </componentStyles>
      <styles>
        <style role="GridBandHeader">
          <states>
            <state name="Normal" backColor="255, 45, 45" backGradientStyle="None" backHatchStyle="None" />
          </states>
        </style>
        <style role="GridRow">
          <states>
            <state name="Normal" backColor="253, 253, 253" backGradientStyle="None" backHatchStyle="None" />
            <state name="Selected" backColor="255, 218, 181" backColor2="255, 161, 67" backGradientStyle="VerticalBump" />
            <state name="HotTracked" backColor2="255, 161, 67" />
            <state name="Active" backColor="255, 218, 181" borderColor="255, 184, 113" fontName="Arial" fontSize="9" backColor2="255, 161, 67" backGradientStyle="VerticalBump" />
            <state name="AlternateItem" backColor="250, 250, 250" backGradientStyle="None" backHatchStyle="None" />
          </states>
        </style>
        <style role="UltraButton">
          <states>
            <state name="Normal" backColor="0, 141, 23" backGradientStyle="None" backHatchStyle="None" />
          </states>
        </style>
        <style role="UltraButtonBase">
          <states>
            <state name="Normal" backColor="254, 0, 42" backGradientStyle="None" backHatchStyle="None" />
          </states>
        </style>
        <style role="UltraButtonDefault">
          <states>
            <state name="Normal" backColor="61, 22, 255" backGradientStyle="None" backHatchStyle="None" />
          </states>
        </style>
      </styles>
      <targetComponents>
        <targetComponent name="ColorBox" />
        <targetComponent name="Inbox Button" />
        <targetComponent name="Inbox CheckBox" />
        <targetComponent name="Inbox ComboBox" />
        <targetComponent name="Inbox Control" />
        <targetComponent name="Inbox DateTimePicker" />
        <targetComponent name="Inbox Form" />
        <targetComponent name="Inbox GroupBox" />
        <targetComponent name="Inbox Label" />
        <targetComponent name="Inbox LinkLabel" />
        <targetComponent name="Inbox ListBox" />
        <targetComponent name="Inbox ListView" />
        <targetComponent name="Inbox MonthCalendar" />
        <targetComponent name="Inbox Panel" />
        <targetComponent name="Inbox PictureBox" />
        <targetComponent name="Inbox PropertyGrid" />
        <targetComponent name="Inbox RadioButton" />
        <targetComponent name="Inbox RichTextBox" />
        <targetComponent name="Inbox SplitContainer" />
        <targetComponent name="Inbox Splitter" />
        <targetComponent name="Inbox TabControl" />
        <targetComponent name="Inbox TextBox" />
        <targetComponent name="Inbox TrackBar" />
        <targetComponent name="Inbox TreeView" />
        <targetComponent name="Inbox UserControl" />
        <targetComponent name="PeekControl" />
        <targetComponent name="UltraActivityIndicator" />
        <targetComponent name="UltraButton" />
        <targetComponent name="UltraCalculator" />
        <targetComponent name="UltraCalculatorDropDown" />
        <targetComponent name="UltraCalculatorDropDownHost" />
        <targetComponent name="UltraCalendarCombo" />
        <targetComponent name="UltraCarousel" />
        <targetComponent name="UltraCheckEditor" />
        <targetComponent name="UltraColorPalette" />
        <targetComponent name="UltraColorPicker" />
        <targetComponent name="UltraCombo" />
        <targetComponent name="UltraComboEditor" />
        <targetComponent name="UltraCurrencyEditor" />
        <targetComponent name="UltraDateTimeEditor" />
        <targetComponent name="UltraDayView" />
        <targetComponent name="UltraDesktopAlert" />
        <targetComponent name="UltraDockManager" />
        <targetComponent name="UltraDropDown" />
        <targetComponent name="UltraDropDownButton" />
        <targetComponent name="UltraExpandableGroupBox" />
        <targetComponent name="UltraExplorerBar" />
        <targetComponent name="UltraFontNameEditor" />
        <targetComponent name="UltraFormattedLinkLabel" />
        <targetComponent name="UltraFormattedTextEditor" />
        <targetComponent name="UltraFormManager" />
        <targetComponent name="UltraGanttView" />
        <targetComponent name="UltraGridCellProxy" />
        <targetComponent name="UltraGridColumnChooser" />
        <targetComponent name="UltraGridFilterUIProvider" />
        <targetComponent name="UltraGridRowEditTemplate" />
        <targetComponent name="UltraGroupBox" />
        <targetComponent name="UltraListView" />
        <targetComponent name="UltraLiveTileView" />
        <targetComponent name="UltraMaskedEdit" />
        <targetComponent name="UltraMessageBoxManager" />
        <targetComponent name="UltraMonthViewMulti" />
        <targetComponent name="UltraMonthViewSingle" />
        <targetComponent name="UltraNavigationBar" />
        <targetComponent name="UltraNumericEditor" />
        <targetComponent name="UltraOfficeNavBar" />
        <targetComponent name="UltraOptionSet" />
        <targetComponent name="UltraPanel" />
        <targetComponent name="UltraPeekPopup" />
        <targetComponent name="UltraPictureBox" />
        <targetComponent name="UltraPivotGrid" />
        <targetComponent name="UltraPopupControlContainer" />
        <targetComponent name="UltraPrintPreviewControl" />
        <targetComponent name="UltraPrintPreviewThumbnail" />
        <targetComponent name="UltraProgressBar" />
        <targetComponent name="UltraRadialMenu" />
        <targetComponent name="UltraRadioButton" />
        <targetComponent name="UltraRibbonCustomizationProvider" />
        <targetComponent name="UltraScrollBar" />
        <targetComponent name="UltraSpellChecker" />
        <targetComponent name="UltraSplitter" />
        <targetComponent name="UltraSpreadsheet" />
        <targetComponent name="UltraStatusBar" />
        <targetComponent name="UltraTabbedMdiManager" />
        <targetComponent name="UltraTabControl" />
        <targetComponent name="UltraTabStripControl" />
        <targetComponent name="UltraTextEditor" />
        <targetComponent name="UltraTile" />
        <targetComponent name="UltraTilePanel" />
        <targetComponent name="UltraTimelineView" />
        <targetComponent name="UltraTimeSpanEditor" />
        <targetComponent name="UltraTimeZoneEditor" />
        <targetComponent name="UltraToolbarsManager" />
        <targetComponent name="UltraToolTipManager" />
        <targetComponent name="UltraTrackBar" />
        <targetComponent name="UltraTree" />
        <targetComponent name="UltraWeekView" />
      </targetComponents>
    </styleSet>
    <styleSet name="StyleSet1" basedOn="Default">
      <styles>
        <style role="UltraButton">
          <states>
            <state name="Normal" backColor="250, 250, 250" foreColor="DimGray" borderColor="210, 210, 210" fontName="Gabriola" textVAlign="Bottom" imageBackgroundStyle="Centered" fontBold="True" fontSize="16" backColor2="210, 210, 210" backGradientStyle="Vertical" />
            <state name="HotTracked" backColor="LightYellow" foreColor="204, 110, 27" borderColor="Orange" backColor2="Orange" backGradientStyle="Vertical" />
            <state name="Pressed" backColor="LightYellow" foreColor="204, 110, 27" borderColor="Orange" backColor2="Orange" backGradientStyle="Vertical" />
          </states>
        </style>
        <style role="UltraButtonBase">
          <states>
            <state name="Normal" backColor="0, 34, 209" backGradientStyle="None" backHatchStyle="None" />
          </states>
        </style>
      </styles>
    </styleSet>
    <styleSet name="Reservation" basedOn="Default">
      <styles>
        <style role="Base">
          <states>
            <state name="Normal" themedElementAlpha="Transparent" />
          </states>
        </style>
        <style role="UltraButton">
          <states>
            <state name="Normal" backColor="210, 240, 210" foreColor="DarkGreen" borderColor="120, 170, 120" backColor2="120, 170, 120" backGradientStyle="Vertical" />
            <state name="HotTracked" backColor="LightYellow" foreColor="204, 110, 27" borderColor="Orange" backColor2="Orange" backGradientStyle="Vertical" />
            <state name="Pressed" backColor="LightYellow" foreColor="204, 110, 27" borderColor="Orange" backColor2="Orange" backGradientStyle="Vertical" />
          </states>
        </style>
        <style role="UltraLabel">
          <states>
            <state name="Normal" backColor="240, 240, 240" foreColor="0, 110, 190" backGradientStyle="None" backHatchStyle="None" />
          </states>
        </style>
        <style role="UltraPanel">
          <states>
            <state name="Normal" backColor="240, 240, 240" backGradientStyle="None" backHatchStyle="None" />
          </states>
        </style>
      </styles>
    </styleSet>
    <styleSet name="StatusBar" basedOn="Default">
      <styles>
        <style role="Base">
          <states>
            <state name="Normal" themedElementAlpha="Transparent" />
          </states>
        </style>
        <style role="UltraButton">
          <states>
            <state name="Normal" backColor="Transparent" backGradientStyle="None" backHatchStyle="None" />
            <state name="HotTracked" backColor="LightYellow" foreColor="204, 110, 27" borderColor="Orange" backColor2="Orange" backGradientStyle="Vertical" />
            <state name="Pressed" backColor="LightYellow" foreColor="204, 110, 27" borderColor="Orange" backColor2="Orange" backGradientStyle="Vertical" />
          </states>
        </style>
        <style role="UltraButtonBase">
          <states>
            <state name="HotTracked" backColor="SlateGray" backGradientStyle="None" backHatchStyle="None" />
          </states>
        </style>
        <style role="UltraLabel">
          <states>
            <state name="Normal" backColor="240, 240, 240" foreColor="DimGray" backGradientStyle="None" backHatchStyle="None" />
          </states>
        </style>
      </styles>
    </styleSet>
    <styleSet name="MinimiseButton" basedOn="Default">
      <styles>
        <style role="Base">
          <states>
            <state name="Normal" themedElementAlpha="Transparent" />
          </states>
        </style>
        <style role="UltraButton">
          <states>
            <state name="Normal" backColor="Transparent" backGradientStyle="None" backHatchStyle="None" />
            <state name="HotTracked" backColor="LightYellow" foreColor="204, 110, 27" borderColor="Orange" backColor2="Orange" backGradientStyle="Vertical" />
            <state name="Pressed" backColor="LightYellow" foreColor="204, 110, 27" borderColor="Orange" backColor2="Orange" backGradientStyle="Vertical" />
          </states>
        </style>
        <style role="UltraButtonBase">
          <states>
            <state name="HotTracked" backColor="SlateGray" backGradientStyle="None" backHatchStyle="None" />
          </states>
        </style>
      </styles>
    </styleSet>
    <styleSet name="CIDButton" basedOn="Default">
      <styles>
        <style role="Base">
          <states>
            <state name="Normal" themedElementAlpha="Transparent" />
          </states>
        </style>
        <style role="UltraButton">
          <states>
            <state name="Normal" backColor="Transparent" backGradientStyle="None" backHatchStyle="None" />
            <state name="HotTracked" backColor="LightYellow" foreColor="204, 110, 27" borderColor="Orange" backColor2="Orange" backGradientStyle="Vertical" />
            <state name="Pressed" backColor="LightYellow" foreColor="204, 110, 27" borderColor="Orange" backColor2="Orange" backGradientStyle="Vertical" />
          </states>
        </style>
        <style role="UltraButtonBase">
          <states>
            <state name="HotTracked" backColor="SlateGray" backGradientStyle="None" backHatchStyle="None" />
          </states>
        </style>
      </styles>
    </styleSet>
    <styleSet name="DCAddressButton" basedOn="Default">
      <styles>
        <style role="Base">
          <states>
            <state name="Normal" themedElementAlpha="Transparent" />
          </states>
        </style>
        <style role="UltraButton">
          <states>
            <state name="Normal" backColor="250, 250, 250" foreColor="DimGray" borderColor="Silver" fontName="Arial" textHAlign="Center" textVAlign="Middle" imageHAlign="Center" imageVAlign="Middle" fontSize="9" backColor2="240, 240, 240" backGradientStyle="Vertical" />
            <state name="HotTracked" backColor="LightYellow" foreColor="204, 110, 27" borderColor="Orange" backColor2="Orange" backGradientStyle="Vertical" />
            <state name="Pressed" backColor="LightYellow" foreColor="204, 110, 27" borderColor="Orange" backColor2="Orange" backGradientStyle="Vertical" />
          </states>
        </style>
        <style role="UltraButtonBase">
          <states>
            <state name="HotTracked" backColor="SlateGray" backGradientStyle="None" backHatchStyle="None" />
          </states>
        </style>
      </styles>
    </styleSet>
    <styleSet name="OEDishButton" basedOn="Default">
      <styles>
        <style role="Base">
          <states>
            <state name="Normal" themedElementAlpha="Transparent" />
          </states>
        </style>
        <style role="UltraButton">
          <states>
            <state name="Normal" backColor="238, 232, 215" foreColor="60, 60, 60" borderColor="230, 218, 196" fontName="Ebrima" textHAlign="Center" textVAlign="Middle" imageHAlign="Center" imageVAlign="Middle" fontSize="10" backColor2="238, 232, 215" backGradientStyle="Vertical" />
            <state name="HotTracked" backColor="LightYellow" foreColor="204, 110, 27" borderColor="Orange" backColor2="Orange" backGradientStyle="Vertical" />
            <state name="Pressed" backColor="LightYellow" foreColor="204, 110, 27" borderColor="Orange" backColor2="Orange" backGradientStyle="Vertical" />
          </states>
        </style>
        <style role="UltraButtonBase">
          <states>
            <state name="HotTracked" backColor="SlateGray" backGradientStyle="None" backHatchStyle="None" />
          </states>
        </style>
      </styles>
    </styleSet>
    <styleSet name="OEDishButtonGreen" basedOn="Default">
      <styles>
        <style role="Base">
          <states>
            <state name="Normal" themedElementAlpha="Transparent" />
          </states>
        </style>
        <style role="UltraButton">
          <states>
            <state name="Normal" backColor="212, 222, 212" foreColor="45, 45, 45" borderColor="172, 185, 172" fontName="Ebrima" textHAlign="Center" textVAlign="Middle" imageHAlign="Center" imageVAlign="Middle" fontSize="10" backGradientStyle="None" backHatchStyle="None" />
            <state name="HotTracked" backColor="LightYellow" foreColor="204, 110, 27" borderColor="Orange" backColor2="Orange" backGradientStyle="Vertical" />
            <state name="Pressed" backColor="LightYellow" foreColor="204, 110, 27" borderColor="Orange" backColor2="Orange" backGradientStyle="Vertical" />
          </states>
        </style>
        <style role="UltraButtonBase">
          <states>
            <state name="HotTracked" backColor="SlateGray" backGradientStyle="None" backHatchStyle="None" />
          </states>
        </style>
      </styles>
    </styleSet>
    <styleSet name="OEGroupButton" basedOn="Default">
      <styles>
        <style role="Base">
          <states>
            <state name="Normal" themedElementAlpha="Transparent" />
          </states>
        </style>
        <style role="UltraButton">
          <states>
            <state name="Normal" backColor="231, 226, 220" borderColor="207, 202, 197" fontName="Ebrima" textVAlign="Middle" fontSize="10" backGradientStyle="None" backHatchStyle="None" />
            <state name="HotTracked" backColor="LightYellow" foreColor="204, 110, 27" borderColor="Orange" backColor2="Orange" backGradientStyle="Vertical" />
            <state name="Pressed" backColor="LightYellow" foreColor="204, 110, 27" borderColor="Orange" backColor2="Orange" backGradientStyle="Vertical" />
          </states>
        </style>
      </styles>
    </styleSet>
    <styleSet name="OEGroupButtonPressed" basedOn="Default">
      <styles>
        <style role="Base">
          <states>
            <state name="Normal" themedElementAlpha="Transparent" />
          </states>
        </style>
        <style role="UltraButton">
          <states>
            <state name="Normal" backColor="160, 200, 160" foreColor="75, 100, 75" borderColor="102, 160, 102" fontName="Arial" textVAlign="Middle" fontSize="10" backGradientStyle="None" backHatchStyle="None" />
          </states>
        </style>
      </styles>
    </styleSet>
    <styleSet name="OEGroupButtonUpDown" basedOn="Default">
      <styles>
        <style role="Base">
          <states>
            <state name="Normal" themedElementAlpha="Transparent" />
          </states>
        </style>
        <style role="UltraButton">
          <states>
            <state name="Normal" backColor="214, 209, 203" borderColor="190, 185, 181" fontName="Arial" textVAlign="Middle" fontSize="10" backGradientStyle="None" backHatchStyle="None" />
          </states>
        </style>
      </styles>
    </styleSet>
    <styleSet name="OECascadeButton" basedOn="Default">
      <styles>
        <style role="Base">
          <states>
            <state name="Normal" themedElementAlpha="Transparent" />
          </states>
        </style>
        <style role="UltraButton">
          <states>
            <state name="Normal" backColor="242, 228, 167" foreColor="60, 60, 60" borderColor="219, 207, 151" fontName="Ebrima" textHAlign="Center" textVAlign="Middle" imageHAlign="Center" imageVAlign="Middle" fontSize="10" backGradientStyle="None" backHatchStyle="None" />
            <state name="HotTracked" backColor="LightYellow" foreColor="204, 110, 27" borderColor="Orange" backColor2="Orange" backGradientStyle="Vertical" />
            <state name="Pressed" backColor="LightYellow" foreColor="204, 110, 27" borderColor="Orange" backColor2="Orange" backGradientStyle="Vertical" />
          </states>
        </style>
        <style role="UltraButtonBase">
          <states>
            <state name="HotTracked" backColor="SlateGray" backGradientStyle="None" backHatchStyle="None" />
          </states>
        </style>
      </styles>
    </styleSet>
    <styleSet name="BigButton" basedOn="Default">
      <styles>
        <style role="UltraButton" buttonStyle="FlatBorderless">
          <states>
            <state name="Normal" backColor="Transparent" foreColor="DimGray" borderColor="Transparent" fontName="Segoe UI" textVAlign="Bottom" imageBackgroundStyle="Centered" fontBold="True" fontSize="12" borderColor2="Transparent" />
            <state name="HotTracked" backColor="LightYellow" foreColor="204, 110, 27" borderColor="Orange" backColor2="Orange" backGradientStyle="Vertical" />
            <state name="Pressed" backColor="LightYellow" foreColor="204, 110, 27" borderColor="Orange" backColor2="Orange" backGradientStyle="Vertical" />
          </states>
        </style>
        <style role="UltraButtonBase">
          <states>
            <state name="Normal" backColor="0, 34, 209" backGradientStyle="None" backHatchStyle="None" />
          </states>
        </style>
      </styles>
    </styleSet>
    <styleSet name="ManagerButton" basedOn="Default">
      <styles>
        <style role="UltraButton">
          <states>
            <state name="Normal" backColor="Transparent" foreColor="DimGray" borderColor="240, 240, 240" fontName="Arial" textVAlign="Bottom" imageBackgroundStyle="Centered" fontBold="True" fontSize="9" borderColor2="Transparent" />
            <state name="HotTracked" backColor="LightYellow" foreColor="204, 110, 27" borderColor="Orange" backColor2="Orange" backGradientStyle="Vertical" />
            <state name="Pressed" backColor="LightYellow" foreColor="204, 110, 27" borderColor="Orange" backColor2="Orange" backGradientStyle="Vertical" />
          </states>
        </style>
        <style role="UltraButtonBase">
          <states>
            <state name="Normal" backColor="0, 34, 209" backGradientStyle="None" backHatchStyle="None" />
          </states>
        </style>
      </styles>
    </styleSet>
    <styleSet name="TableBigButton" basedOn="Default">
      <styles>
        <style role="UltraButton" buttonStyle="FlatBorderless">
          <states>
            <state name="Normal" backColor="Transparent" foreColor="DimGray" borderColor="Transparent" fontName="Arial" textVAlign="Bottom" imageBackgroundStyle="Centered" fontBold="True" fontSize="9" borderColor2="Transparent" />
            <state name="HotTracked" backColor="LightYellow" foreColor="204, 110, 27" borderColor="Orange" backColor2="Orange" backGradientStyle="Vertical" />
            <state name="Pressed" backColor="LightYellow" foreColor="204, 110, 27" borderColor="Orange" backColor2="Orange" backGradientStyle="Vertical" />
          </states>
        </style>
        <style role="UltraButtonBase">
          <states>
            <state name="Normal" backColor="0, 34, 209" backGradientStyle="None" backHatchStyle="None" />
          </states>
        </style>
      </styles>
    </styleSet>
    <styleSet name="TextButton" basedOn="Default">
      <componentStyles>
        <componentStyle name="UltraButton" buttonStyle="Button" useOsThemes="False" useFlatMode="True">
          <properties>
            <property name="UseHotTracking" colorCategory="{Default}">True</property>
          </properties>
        </componentStyle>
      </componentStyles>
      <styles>
        <style role="UltraButton">
          <states>
            <state name="Normal" backColor="239, 239, 239" foreColor="DimGray" borderColor="210, 210, 210" fontName="Arial" fontBold="False" fontSize="9" backGradientStyle="None" backHatchStyle="None" />
            <state name="HotTracked" backColor="LightYellow" foreColor="204, 110, 27" borderColor="Orange" backColor2="Orange" backGradientStyle="Vertical" />
            <state name="Pressed" backColor="LightYellow" foreColor="204, 110, 27" borderColor="Orange" backColor2="Orange" backGradientStyle="Vertical" />
          </states>
        </style>
        <style role="UltraButtonBase">
          <states>
            <state name="Normal" backColor="0, 34, 209" backGradientStyle="None" backHatchStyle="None" />
          </states>
        </style>
      </styles>
    </styleSet>
    <styleSet name="TextEntryLabel" basedOn="Default">
      <styles>
        <style role="Base">
          <states>
            <state name="Normal" themedElementAlpha="Transparent" />
          </states>
        </style>
        <style role="UltraLabel">
          <states>
            <state name="Normal" fontName="Corbel" />
          </states>
        </style>
      </styles>
      <targetComponents>
        <targetComponent name="UltraLabel" />
      </targetComponents>
    </styleSet>
    <styleSet name="EZGrid" basedOn="Default">
      <styles>
        <style role="Base">
          <states>
            <state name="Normal" themedElementAlpha="Transparent" />
          </states>
        </style>
        <style role="GridBandHeader">
          <states>
            <state name="Normal" fontName="Ebrima" />
          </states>
        </style>
        <style role="GridColumnHeader">
          <states>
            <state name="Normal" fontName="Ebrima" />
          </states>
        </style>
        <style role="GridRow">
          <states>
            <state name="Normal" fontName="Ebrima" />
            <state name="Selected" backColor="238, 219, 176" borderColor="238, 219, 176" backGradientStyle="None" backHatchStyle="None" />
            <state name="Active" backColor="238, 219, 176" borderColor="238, 219, 176" backGradientStyle="None" backHatchStyle="None" />
          </states>
        </style>
      </styles>
    </styleSet>
    <styleSet name="MiscLabel" basedOn="Default">
      <styles>
        <style role="Base">
          <states>
            <state name="Normal" themedElementAlpha="Transparent" />
          </states>
        </style>
        <style role="UltraLabel">
          <states>
            <state name="Normal" fontName="Arial" />
          </states>
        </style>
      </styles>
    </styleSet>
  </styleSets>
  <resources>
    <resource name="Background" backColor="White" foreColor="68, 68, 68" backGradientStyle="None" backHatchStyle="None" />
    <resource name="Background DarkGray" backColor="246, 246, 246" backGradientStyle="None" backHatchStyle="None" />
    <resource name="Background Grid Hover" backColor="205, 230, 247" foreColor="68, 68, 68" backGradientStyle="None" backHatchStyle="None" />
    <resource name="Background Grid Pressed/Selected" backColor="177, 214, 240" foreColor="68, 68, 68" backGradientStyle="None" backHatchStyle="None" />
    <resource name="Background Hover" backColor="177, 214, 240" foreColor="68, 68, 68" backGradientStyle="None" backHatchStyle="None" />
    <resource name="Background LightGray" backColor="250, 250, 250" backGradientStyle="None" backHatchStyle="None" />
    <resource name="Background Selected" backColor="44, 142, 212" foreColor="68, 68, 68" backGradientStyle="None" backHatchStyle="None" />
    <resource name="BackgroundBorder Hover" backColor="205, 230, 247" foreColor="68, 68, 68" borderColor="44, 142, 212" backGradientStyle="None" backHatchStyle="None" />
    <resource name="BackgroundBorder Pressed/Selected" backColor="177, 214, 240" foreColor="68, 68, 68" borderColor="44, 142, 212" backGradientStyle="None" backHatchStyle="None" />
    <resource name="Border" borderColor="171, 171, 171" />
    <resource name="Border Disabled" borderColor="225, 225, 225" />
    <resource name="Border Hover" borderColor="44, 142, 212" />
    <resource name="Border Read Only" borderColor="225, 225, 225" />
    <resource name="Border Selected/Pressed" borderColor="2, 115, 198" />
    <resource name="Button" backColor="White" foreColor="68, 68, 68" borderColor="171, 171, 171" foreColorDisabled="109, 109, 109" backColorDisabled="240, 240, 240" backGradientStyle="None" backHatchStyle="None" />
    <resource name="Button Checked" backColor="44, 142, 212" foreColor="68, 68, 68" borderAlpha="Transparent" backGradientStyle="None" backHatchStyle="None" />
    <resource name="Button Focused" backColor="White" foreColor="68, 68, 68" borderColor="44, 142, 212" backGradientStyle="None" backHatchStyle="None" />
    <resource name="Button HotTrack" backColor="205, 230, 247" foreColor="68, 68, 68" borderColor="44, 142, 212" backGradientStyle="None" backHatchStyle="None" />
    <resource name="Button Pressed" backColor="44, 142, 212" foreColor="68, 68, 68" borderColor="2, 115, 198" backGradientStyle="None" backHatchStyle="None" />
    <resource name="Default_Cell_RowHotTracked" backColor="230, 242, 250" backGradientStyle="None" backHatchStyle="None" />
    <resource name="Foreground" foreColor="68, 68, 68" foreColorDisabled="210, 210, 210" />
    <resource name="Foreground Error" foreColor="210, 0, 0" />
    <resource name="Foreground Hover/Selected" foreColor="2, 115, 198" />
    <resource name="Grid Lines" borderColor="225, 225, 225" />
    <resource name="MainBlue Calendar" backColor="0, 114, 198" backGradientStyle="None" backHatchStyle="None" />
    <resource name="MainColor" backColor="2, 104, 177" backGradientStyle="None" backHatchStyle="None" />
    <resource name="MainColor_Border" borderColor="2, 115, 198" borderColor2="2, 115, 198" />
    <resource name="MainHoverColorOverBlue" backColor="0, 72, 123" backGradientStyle="None" backHatchStyle="None" />
    <resource name="MainSelectionColor" backColor="44, 142, 212" backGradientStyle="None" backHatchStyle="None" />
    <resource name="Schedule Active/Selected Back Color" backColor="2, 104, 177" foreColor="White" backGradientStyle="None" backHatchStyle="None" />
    <resource name="ScrollBar Button HotTracked" backColor="White" foreColor="119, 119, 119" borderColor="140, 140, 140" backGradientStyle="None" backHatchStyle="None" />
    <resource name="ScrollBar Button Normal" backColor="White" foreColor="119, 119, 119" borderColor="187, 187, 187" backGradientStyle="None" backHatchStyle="None" />
    <resource name="ScrollBar Button Pressed" backColor="244, 244, 244" foreColor="119, 119, 119" borderColor="141, 141, 141" backGradientStyle="None" backHatchStyle="None" />
    <resource name="ScrollBar Thumb HotTracked" backColor="240, 240, 240" borderColor="171, 171, 171" backGradientStyle="None" backHatchStyle="None" />
    <resource name="ScrollBar Thumb Normal" backColor="White" borderColor="187, 187, 187" backGradientStyle="None" backHatchStyle="None" />
    <resource name="ScrollBar Thumb Pressed" backColor="240, 240, 240" borderColor="119, 119, 119" backGradientStyle="None" backHatchStyle="None" />
    <resource name="ScrollBar TrackSection HotTracked" backColor="244, 244, 244" backGradientStyle="None" backHatchStyle="None" />
    <resource name="ScrollBar TrackSection Normal" backColor="244, 244, 244" backGradientStyle="None" backHatchStyle="None" />
    <resource name="ScrollBar TrackSection Pressed" backColor="237, 237, 237" backGradientStyle="None" backHatchStyle="None" />
    <resource name="ScrollBarTrackSection" backColor="230, 230, 230" backGradientStyle="None" backHatchStyle="None" />
  </resources>
</styleLibrary>