﻿Imports Infragistics.Win.Misc
Imports VB = Microsoft.VisualBasic

Public Class FullKeyboard

    Inherits Form

    Public Result As String

    Dim tempStr, strCharString As String
    Dim myBut, ubtnTemp As UltraButton
    Dim blnShiftOn As Boolean

    Public Sub New()

        MyBase.New()
        InitializeComponent()

    End Sub

    Public Sub New(LabelString As String)

        MyBase.New()
        InitializeComponent()

        lblEntryBox.Text = LabelString

    End Sub

    'Protected Overrides Sub WndProc(ByRef m As System.Windows.Forms.Message)
    '    Static Expanded As Boolean = True
    '    'Static Height As Integer
    '    Const WM_NCLBUTTONDBLCLK As Int32 = &HA3
    '    If m.Msg = WM_NCLBUTTONDBLCLK Then
    '        Exit Sub
    '    End If
    '    MyBase.WndProc(m)
    'End Sub

    Private Sub Me_Load(sender As Object, e As EventArgs) Handles Me.Load

        Try
            For Each ctrl As Control In upnlKeyboard.ClientArea.Controls
                If TypeName(ctrl) = "UltraButton" Then
                    Dim myBut = DirectCast(ctrl, UltraButton)
                    myBut.ShowFocusRect = False
                    myBut.ShowOutline = False
                    If myBut.Font.SizeInPoints = 20 Then
                        myBut.Appearance.FontData.SizeInPoints = 16
                    Else
                        myBut.Appearance.FontData.SizeInPoints = 20
                    End If
                End If
            Next

            'If GetAppSettingCS("KBCase", "U") = "L" Then
            '    ubtnCase_Click(sender, e)
            'End If

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub ShiftButtonsHandler(sender As Object, e As EventArgs) Handles ubtnShiftL.Click, ubtnShiftR.Click

        If blnShiftOn = True Then
            TurnShiftOff()
        Else
            TurnShiftOn()
        End If

    End Sub

    Private Sub AlphaNumHandler(sender As Object, e As EventArgs) _
                     Handles ubtnA.Click, ubtnB.Click, ubtnC.Click, ubtnD.Click, ubtnE.Click,
                     ubtnF.Click, ubtnG.Click, ubtnH.Click, ubtnI.Click, ubtnJ.Click,
                     ubtnK.Click, ubtnL.Click, ubtnM.Click, ubtnN.Click, ubtnO.Click,
                     ubtnP.Click, ubtnQ.Click, ubtnR.Click, ubtnS.Click, ubtnT.Click,
                     ubtnU.Click, ubtnV.Click, ubtnW.Click, ubtnX.Click, ubtnY.Click, ubtnZ.Click,
                     ubtnNum1.Click, ubtnNum2.Click, ubtnNum3.Click, ubtnNum4.Click, ubtnNum5.Click,
                     ubtnNum6.Click, ubtnNum7.Click, ubtnNum8.Click, ubtnNum9.Click, ubtnNum0.Click

        tempStr = sender.Text

        'check if shift button is pressed
        If blnShiftOn = True Then
            If ubtnCase.Tag = "Case L" Then
                tempStr = tempStr.ToLower()
            Else
                tempStr = tempStr.ToUpper()
            End If
            If tempStr = "&&" Then tempStr = "&"
            TurnShiftOff()
        End If

        CharToSend(tempStr)

    End Sub

    Private Sub cmdClear_Click(sender As Object, e As EventArgs) Handles ubtnClear.Click

        lblEntryBox.Text = String.Empty

    End Sub

    Private Sub cmdEnter_Click(sender As Object, e As EventArgs) Handles ubtnEnter.Click

        Result = lblEntryBox.Text
        Close()

    End Sub

    Private Sub ubtnCase_Click(sender As Object, e As EventArgs) Handles ubtnCase.Click

        upnlKeyboard.ClientArea.SuspendLayout()

        For Each ctrl As Control In upnlKeyboard.ClientArea.Controls
            If ctrl.Name.Length = 5 Then
                If ubtnCase.Tag = "Case L" Then
                    ctrl.Text = ctrl.Text.ToLower
                    SaveAppSetting("KBCase", "L")
                Else
                    ctrl.Text = ctrl.Text.ToUpper
                    SaveAppSetting("KBCase", "U")
                End If
            End If
        Next

        upnlKeyboard.ClientArea.ResumeLayout()

        If ubtnCase.Tag = "Case U" Then ubtnCase.Tag = "Case L" Else ubtnCase.Tag = "Case U"
        'picCaps.Visible = (ubtnCase.Tag = "Case L")

    End Sub

    Private Sub ubtnSpace_Click(sender As Object, e As EventArgs) Handles ubtnSpace.Click

        CharToSend(" ")

        If blnShiftOn Then TurnShiftOff()

    End Sub

    Private Sub CharToSend(strCharPressed As String)

        lblEntryBox.Text &= strCharPressed

    End Sub

    Private Sub SpCharHandler(sender As Object, e As EventArgs) Handles ubtnSpChar1.Click, ubtnSpChar2.Click,
   ubtnSpChar3.Click, ubtnSpChar4.Click, ubtnSpChar5.Click, ubtnSpChar6.Click, ubtnSpChar7.Click, ubtnSpChar9.Click, ubtnSpChar11.Click

        myBut = DirectCast(sender, UltraButton)
        CharToSend(myBut.Text)

        If blnShiftOn = True Then TurnShiftOff()

    End Sub

    Private Sub ubtnClear_Click(sender As Object, e As EventArgs) Handles ubtnClear.Click

        lblEntryBox.Text = String.Empty

    End Sub

    Private Sub TurnShiftOn()

        For Each ctrl As Control In upnlKeyboard.ClientArea.Controls
            If TypeName(ctrl) = "UltraButton" Then
                myBut = ctrl
                If VB.Left(myBut.Name, 10) = "ubtnSpChar" Or VB.Left(myBut.Name, 7) = "ubtnNum" Then
                    If myBut.Tag IsNot Nothing Then
                        Dim strVar1 = myBut.Tag
                        myBut.Tag = myBut.Text
                        myBut.Text = strVar1
                    End If
                End If
            End If
        Next

        picShiftL.Visible = True
        picShiftR.Visible = True
        blnShiftOn = True

    End Sub

    Private Sub TurnShiftOff()

        For Each ctrl As Control In upnlKeyboard.ClientArea.Controls
            If TypeName(ctrl) = "UltraButton" Then
                If VB.Left(ctrl.Name, 10) = "ubtnSpChar" Or VB.Left(ctrl.Name, 7) = "ubtnNum" Then
                    myBut = CType(ctrl, UltraButton)
                    If myBut.Tag IsNot Nothing Then
                        If myBut.Tag.ToString.Length = 1 Then
                            Dim strVar1 = myBut.Tag
                            myBut.Tag = myBut.Text
                            myBut.Text = strVar1
                        End If
                    End If
                End If
            End If
        Next

        picShiftL.Visible = False
        picShiftR.Visible = False
        blnShiftOn = False

    End Sub

    Private Sub ubtnBkSp_Click(sender As Object, e As EventArgs) Handles ubtnBkSp.Click

        Dim strTemp = lblEntryBox.Text

        If strTemp.Length > 0 Then
            strTemp = strTemp.Substring(0, strTemp.Length - 1)
            lblEntryBox.Text = strTemp
        End If

    End Sub

    Private Sub ubtnEsc_Click(sender As Object, e As EventArgs) Handles ubtnEsc.Click

        Result = "^Esc"
        Close()

    End Sub

End Class

Public Class EZFullKeyboard

    Public Shared Function Show() As String
        Dim objForm As New FullKeyboard()
        objForm.ShowDialog()
        Return objForm.Result
    End Function

    Public Shared Function Show(strKBText As String) As String
        Dim objForm As New FullKeyboard(strKBText)
        objForm.ShowDialog()
        Return objForm.Result
    End Function

End Class