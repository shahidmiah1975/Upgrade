﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DishKBControl
    Inherits System.Windows.Forms.UserControl

    'UserControl1 overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim Appearance1 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance2 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance3 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance4 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance5 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance6 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance7 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance8 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance9 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance10 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance11 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance12 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance13 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance14 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance15 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance16 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance17 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance18 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance19 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance20 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance21 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance22 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance23 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance24 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance25 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance26 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance27 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance28 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance29 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance30 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance31 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance32 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance33 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance34 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance35 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance36 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance37 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance38 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance39 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance40 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance41 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance42 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance43 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance44 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance45 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance46 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance47 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance48 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance49 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance50 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance51 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance52 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance53 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance54 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance55 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance56 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance57 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance58 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance59 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance60 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance61 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance62 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance63 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance64 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance65 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance66 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance67 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance68 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance69 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance70 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance71 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance72 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance73 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance74 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance75 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance76 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance77 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance78 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance79 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance80 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance81 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance82 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance83 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance84 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance85 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance86 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance87 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance88 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance89 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance90 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance91 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance92 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance93 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance94 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance95 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance96 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance97 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance98 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance99 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance100 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance101 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance102 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance103 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance104 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance105 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance106 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance107 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance108 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance109 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance110 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance111 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance112 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance113 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance114 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance115 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance116 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance117 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance118 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance119 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance120 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance121 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance122 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance123 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Me.upnlKeyboard = New Infragistics.Win.Misc.UltraPanel()
        Me.txtManualEntry = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.cmdVersion = New Infragistics.Win.Misc.UltraButton()
        Me.cmdBack = New Infragistics.Win.Misc.UltraButton()
        Me.lblCode = New Infragistics.Win.Misc.UltraLabel()
        Me.lblDish = New Infragistics.Win.Misc.UltraLabel()
        Me.cmdClear = New Infragistics.Win.Misc.UltraButton()
        Me.cmdOK = New Infragistics.Win.Misc.UltraButton()
        Me.but2 = New Infragistics.Win.Misc.UltraButton()
        Me.but3 = New Infragistics.Win.Misc.UltraButton()
        Me.but4 = New Infragistics.Win.Misc.UltraButton()
        Me.but5 = New Infragistics.Win.Misc.UltraButton()
        Me.but6 = New Infragistics.Win.Misc.UltraButton()
        Me.but7 = New Infragistics.Win.Misc.UltraButton()
        Me.but8 = New Infragistics.Win.Misc.UltraButton()
        Me.but9 = New Infragistics.Win.Misc.UltraButton()
        Me.but0 = New Infragistics.Win.Misc.UltraButton()
        Me.but1 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton9 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton11 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton12 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton13 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton14 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton15 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton19 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton2 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton3 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton4 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton5 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton6 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton7 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton8 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton10 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton16 = New Infragistics.Win.Misc.UltraButton()
        Me.butw = New Infragistics.Win.Misc.UltraButton()
        Me.bute = New Infragistics.Win.Misc.UltraButton()
        Me.butr = New Infragistics.Win.Misc.UltraButton()
        Me.butt = New Infragistics.Win.Misc.UltraButton()
        Me.buty = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton23 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton22 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton21 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton20 = New Infragistics.Win.Misc.UltraButton()
        Me.butq = New Infragistics.Win.Misc.UltraButton()
        Me.upnlKeyboard.ClientArea.SuspendLayout()
        Me.upnlKeyboard.SuspendLayout()
        CType(Me.txtManualEntry, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'upnlKeyboard
        '
        Me.upnlKeyboard.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        '
        'upnlKeyboard.ClientArea
        '
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.txtManualEntry)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.cmdVersion)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.cmdBack)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.lblCode)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.lblDish)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.cmdClear)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.cmdOK)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.but2)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.but3)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.but4)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.but5)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.but6)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.but7)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.but8)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.but9)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.but0)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.but1)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.UltraButton9)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.UltraButton11)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.UltraButton12)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.UltraButton13)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.UltraButton14)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.UltraButton15)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.UltraButton19)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.UltraButton2)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.UltraButton3)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.UltraButton4)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.UltraButton5)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.UltraButton6)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.UltraButton7)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.UltraButton8)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.UltraButton10)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.UltraButton16)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.butw)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.bute)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.butr)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.butt)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.buty)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.UltraButton23)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.UltraButton22)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.UltraButton21)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.UltraButton20)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.butq)
        Me.upnlKeyboard.ForeColor = System.Drawing.Color.White
        Me.upnlKeyboard.Location = New System.Drawing.Point(1, 1)
        Me.upnlKeyboard.Name = "upnlKeyboard"
        Me.upnlKeyboard.Size = New System.Drawing.Size(738, 313)
        Me.upnlKeyboard.TabIndex = 619
        '
        'txtManualEntry
        '
        Appearance1.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance1.BorderColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance1.ForeColor = System.Drawing.Color.White
        Appearance1.TextHAlignAsString = "Center"
        Me.txtManualEntry.Appearance = Appearance1
        Me.txtManualEntry.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Me.txtManualEntry.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtManualEntry.Font = New System.Drawing.Font("Calibri", 21.75!)
        Me.txtManualEntry.Location = New System.Drawing.Point(6, 6)
        Me.txtManualEntry.MaxLength = 8
        Me.txtManualEntry.Name = "txtManualEntry"
        Me.txtManualEntry.Size = New System.Drawing.Size(174, 47)
        Me.txtManualEntry.TabIndex = 660
        Me.txtManualEntry.UseAppStyling = False
        Me.txtManualEntry.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtManualEntry.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        Me.txtManualEntry.WordWrap = False
        '
        'cmdVersion
        '
        Appearance2.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance2.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance2.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance2.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance2.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance2.BorderColor2 = System.Drawing.Color.Maroon
        Appearance2.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance2.ForeColor = System.Drawing.Color.White
        Appearance2.TextVAlignAsString = "Middle"
        Me.cmdVersion.Appearance = Appearance2
        Me.cmdVersion.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance3.BackColor = System.Drawing.Color.DarkOrange
        Appearance3.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance3.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance3.ForeColor = System.Drawing.Color.Black
        Me.cmdVersion.HotTrackAppearance = Appearance3
        Me.cmdVersion.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdVersion.Location = New System.Drawing.Point(686, 262)
        Me.cmdVersion.Name = "cmdVersion"
        Appearance4.BackColor = System.Drawing.Color.OrangeRed
        Appearance4.BackColor2 = System.Drawing.Color.Tomato
        Appearance4.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdVersion.PressedAppearance = Appearance4
        Me.cmdVersion.ShowFocusRect = False
        Me.cmdVersion.ShowOutline = False
        Me.cmdVersion.Size = New System.Drawing.Size(44, 44)
        Me.cmdVersion.TabIndex = 659
        Me.cmdVersion.Tag = "6"
        Me.cmdVersion.Text = "v2"
        Me.cmdVersion.UseAppStyling = False
        Me.cmdVersion.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdVersion.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdVersion.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdBack
        '
        Appearance5.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance5.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance5.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance5.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance5.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance5.BorderColor2 = System.Drawing.Color.Maroon
        Appearance5.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance5.ForeColor = System.Drawing.Color.White
        Appearance5.TextVAlignAsString = "Middle"
        Me.cmdBack.Appearance = Appearance5
        Me.cmdBack.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance6.BackColor = System.Drawing.Color.DarkOrange
        Appearance6.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance6.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance6.ForeColor = System.Drawing.Color.Black
        Me.cmdBack.HotTrackAppearance = Appearance6
        Me.cmdBack.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdBack.Location = New System.Drawing.Point(580, 185)
        Me.cmdBack.Name = "cmdBack"
        Appearance7.BackColor = System.Drawing.Color.OrangeRed
        Appearance7.BackColor2 = System.Drawing.Color.Tomato
        Appearance7.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdBack.PressedAppearance = Appearance7
        Me.cmdBack.ShowFocusRect = False
        Me.cmdBack.ShowOutline = False
        Me.cmdBack.Size = New System.Drawing.Size(121, 60)
        Me.cmdBack.TabIndex = 658
        Me.cmdBack.Tag = ""
        Me.cmdBack.Text = "Back"
        Me.cmdBack.UseAppStyling = False
        Me.cmdBack.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdBack.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdBack.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblCode
        '
        Appearance8.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance8.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance8.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance8.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance8.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance8.ForeColor = System.Drawing.Color.White
        Appearance8.TextHAlignAsString = "Center"
        Appearance8.TextVAlignAsString = "Middle"
        Me.lblCode.Appearance = Appearance8
        Me.lblCode.BorderStyleOuter = Infragistics.Win.UIElementBorderStyle.Solid
        Me.lblCode.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCode.Location = New System.Drawing.Point(2, 2)
        Me.lblCode.Name = "lblCode"
        Me.lblCode.Size = New System.Drawing.Size(182, 55)
        Me.lblCode.TabIndex = 657
        Me.lblCode.Tag = "0"
        Me.lblCode.UseAppStyling = False
        '
        'lblDish
        '
        Appearance9.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance9.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance9.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance9.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance9.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance9.ForeColor = System.Drawing.Color.White
        Appearance9.TextHAlignAsString = "Center"
        Appearance9.TextVAlignAsString = "Middle"
        Me.lblDish.Appearance = Appearance9
        Me.lblDish.BorderStyleOuter = Infragistics.Win.UIElementBorderStyle.Solid
        Me.lblDish.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDish.Location = New System.Drawing.Point(185, 2)
        Me.lblDish.Name = "lblDish"
        Me.lblDish.Size = New System.Drawing.Size(548, 55)
        Me.lblDish.TabIndex = 656
        Me.lblDish.Tag = "0"
        Me.lblDish.UseAppStyling = False
        '
        'cmdClear
        '
        Appearance10.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance10.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance10.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance10.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance10.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance10.BorderColor2 = System.Drawing.Color.Maroon
        Appearance10.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance10.ForeColor = System.Drawing.Color.White
        Appearance10.TextVAlignAsString = "Middle"
        Me.cmdClear.Appearance = Appearance10
        Me.cmdClear.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance11.BackColor = System.Drawing.Color.DarkOrange
        Appearance11.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance11.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance11.ForeColor = System.Drawing.Color.Black
        Me.cmdClear.HotTrackAppearance = Appearance11
        Me.cmdClear.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdClear.Location = New System.Drawing.Point(490, 246)
        Me.cmdClear.Name = "cmdClear"
        Appearance12.BackColor = System.Drawing.Color.OrangeRed
        Appearance12.BackColor2 = System.Drawing.Color.Tomato
        Appearance12.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdClear.PressedAppearance = Appearance12
        Me.cmdClear.ShowFocusRect = False
        Me.cmdClear.ShowOutline = False
        Me.cmdClear.Size = New System.Drawing.Size(182, 60)
        Me.cmdClear.TabIndex = 655
        Me.cmdClear.Tag = "6"
        Me.cmdClear.Text = "Clear"
        Me.cmdClear.UseAppStyling = False
        Me.cmdClear.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdClear.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdClear.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdOK
        '
        Appearance13.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance13.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance13.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance13.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance13.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance13.BorderColor2 = System.Drawing.Color.Maroon
        Appearance13.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance13.ForeColor = System.Drawing.Color.White
        Appearance13.TextVAlignAsString = "Middle"
        Me.cmdOK.Appearance = Appearance13
        Me.cmdOK.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance14.BackColor = System.Drawing.Color.DarkOrange
        Appearance14.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance14.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance14.ForeColor = System.Drawing.Color.Black
        Me.cmdOK.HotTrackAppearance = Appearance14
        Me.cmdOK.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdOK.Location = New System.Drawing.Point(612, 63)
        Me.cmdOK.Name = "cmdOK"
        Appearance15.BackColor = System.Drawing.Color.OrangeRed
        Appearance15.BackColor2 = System.Drawing.Color.Tomato
        Appearance15.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdOK.PressedAppearance = Appearance15
        Me.cmdOK.ShowFocusRect = False
        Me.cmdOK.ShowOutline = False
        Me.cmdOK.Size = New System.Drawing.Size(121, 121)
        Me.cmdOK.TabIndex = 654
        Me.cmdOK.Tag = "6"
        Me.cmdOK.Text = "OK"
        Me.cmdOK.UseAppStyling = False
        Me.cmdOK.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOK.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOK.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'but2
        '
        Appearance16.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance16.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance16.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance16.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance16.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance16.BorderColor2 = System.Drawing.Color.Maroon
        Appearance16.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance16.ForeColor = System.Drawing.Color.White
        Appearance16.TextVAlignAsString = "Middle"
        Me.but2.Appearance = Appearance16
        Me.but2.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance17.BackColor = System.Drawing.Color.DarkOrange
        Appearance17.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance17.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance17.ForeColor = System.Drawing.Color.Black
        Me.but2.HotTrackAppearance = Appearance17
        Me.but2.ImageSize = New System.Drawing.Size(32, 32)
        Me.but2.Location = New System.Drawing.Point(63, 63)
        Me.but2.Name = "but2"
        Appearance18.BackColor = System.Drawing.Color.OrangeRed
        Appearance18.BackColor2 = System.Drawing.Color.Tomato
        Appearance18.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.but2.PressedAppearance = Appearance18
        Me.but2.ShowFocusRect = False
        Me.but2.ShowOutline = False
        Me.but2.Size = New System.Drawing.Size(60, 60)
        Me.but2.TabIndex = 653
        Me.but2.Tag = "6"
        Me.but2.Text = "2"
        Me.but2.UseAppStyling = False
        Me.but2.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.but2.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.but2.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'but3
        '
        Appearance19.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance19.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance19.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance19.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance19.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance19.BorderColor2 = System.Drawing.Color.Maroon
        Appearance19.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance19.ForeColor = System.Drawing.Color.White
        Appearance19.TextVAlignAsString = "Middle"
        Me.but3.Appearance = Appearance19
        Me.but3.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance20.BackColor = System.Drawing.Color.DarkOrange
        Appearance20.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance20.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance20.ForeColor = System.Drawing.Color.Black
        Me.but3.HotTrackAppearance = Appearance20
        Me.but3.ImageSize = New System.Drawing.Size(32, 32)
        Me.but3.Location = New System.Drawing.Point(124, 63)
        Me.but3.Name = "but3"
        Appearance21.BackColor = System.Drawing.Color.OrangeRed
        Appearance21.BackColor2 = System.Drawing.Color.Tomato
        Appearance21.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.but3.PressedAppearance = Appearance21
        Me.but3.ShowFocusRect = False
        Me.but3.ShowOutline = False
        Me.but3.Size = New System.Drawing.Size(60, 60)
        Me.but3.TabIndex = 652
        Me.but3.Tag = "6"
        Me.but3.Text = "3"
        Me.but3.UseAppStyling = False
        Me.but3.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.but3.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.but3.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'but4
        '
        Appearance22.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance22.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance22.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance22.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance22.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance22.BorderColor2 = System.Drawing.Color.Maroon
        Appearance22.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance22.ForeColor = System.Drawing.Color.White
        Appearance22.TextVAlignAsString = "Middle"
        Me.but4.Appearance = Appearance22
        Me.but4.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance23.BackColor = System.Drawing.Color.DarkOrange
        Appearance23.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance23.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance23.ForeColor = System.Drawing.Color.Black
        Me.but4.HotTrackAppearance = Appearance23
        Me.but4.ImageSize = New System.Drawing.Size(32, 32)
        Me.but4.Location = New System.Drawing.Point(185, 63)
        Me.but4.Name = "but4"
        Appearance24.BackColor = System.Drawing.Color.OrangeRed
        Appearance24.BackColor2 = System.Drawing.Color.Tomato
        Appearance24.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.but4.PressedAppearance = Appearance24
        Me.but4.ShowFocusRect = False
        Me.but4.ShowOutline = False
        Me.but4.Size = New System.Drawing.Size(60, 60)
        Me.but4.TabIndex = 651
        Me.but4.Tag = "6"
        Me.but4.Text = "4"
        Me.but4.UseAppStyling = False
        Me.but4.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.but4.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.but4.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'but5
        '
        Appearance25.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance25.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance25.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance25.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance25.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance25.BorderColor2 = System.Drawing.Color.Maroon
        Appearance25.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance25.ForeColor = System.Drawing.Color.White
        Appearance25.TextVAlignAsString = "Middle"
        Me.but5.Appearance = Appearance25
        Me.but5.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance26.BackColor = System.Drawing.Color.DarkOrange
        Appearance26.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance26.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance26.ForeColor = System.Drawing.Color.Black
        Me.but5.HotTrackAppearance = Appearance26
        Me.but5.ImageSize = New System.Drawing.Size(32, 32)
        Me.but5.Location = New System.Drawing.Point(246, 63)
        Me.but5.Name = "but5"
        Appearance27.BackColor = System.Drawing.Color.OrangeRed
        Appearance27.BackColor2 = System.Drawing.Color.Tomato
        Appearance27.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.but5.PressedAppearance = Appearance27
        Me.but5.ShowFocusRect = False
        Me.but5.ShowOutline = False
        Me.but5.Size = New System.Drawing.Size(60, 60)
        Me.but5.TabIndex = 650
        Me.but5.Tag = "6"
        Me.but5.Text = "5"
        Me.but5.UseAppStyling = False
        Me.but5.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.but5.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.but5.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'but6
        '
        Appearance28.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance28.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance28.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance28.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance28.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance28.BorderColor2 = System.Drawing.Color.Maroon
        Appearance28.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance28.ForeColor = System.Drawing.Color.White
        Appearance28.TextVAlignAsString = "Middle"
        Me.but6.Appearance = Appearance28
        Me.but6.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance29.BackColor = System.Drawing.Color.DarkOrange
        Appearance29.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance29.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance29.ForeColor = System.Drawing.Color.Black
        Me.but6.HotTrackAppearance = Appearance29
        Me.but6.ImageSize = New System.Drawing.Size(32, 32)
        Me.but6.Location = New System.Drawing.Point(307, 63)
        Me.but6.Name = "but6"
        Appearance30.BackColor = System.Drawing.Color.OrangeRed
        Appearance30.BackColor2 = System.Drawing.Color.Tomato
        Appearance30.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.but6.PressedAppearance = Appearance30
        Me.but6.ShowFocusRect = False
        Me.but6.ShowOutline = False
        Me.but6.Size = New System.Drawing.Size(60, 60)
        Me.but6.TabIndex = 649
        Me.but6.Tag = "6"
        Me.but6.Text = "6"
        Me.but6.UseAppStyling = False
        Me.but6.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.but6.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.but6.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'but7
        '
        Appearance31.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance31.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance31.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance31.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance31.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance31.BorderColor2 = System.Drawing.Color.Maroon
        Appearance31.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance31.ForeColor = System.Drawing.Color.White
        Appearance31.TextVAlignAsString = "Middle"
        Me.but7.Appearance = Appearance31
        Me.but7.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance32.BackColor = System.Drawing.Color.DarkOrange
        Appearance32.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance32.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance32.ForeColor = System.Drawing.Color.Black
        Me.but7.HotTrackAppearance = Appearance32
        Me.but7.ImageSize = New System.Drawing.Size(32, 32)
        Me.but7.Location = New System.Drawing.Point(368, 63)
        Me.but7.Name = "but7"
        Appearance33.BackColor = System.Drawing.Color.OrangeRed
        Appearance33.BackColor2 = System.Drawing.Color.Tomato
        Appearance33.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.but7.PressedAppearance = Appearance33
        Me.but7.ShowFocusRect = False
        Me.but7.ShowOutline = False
        Me.but7.Size = New System.Drawing.Size(60, 60)
        Me.but7.TabIndex = 648
        Me.but7.Tag = "6"
        Me.but7.Text = "7"
        Me.but7.UseAppStyling = False
        Me.but7.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.but7.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.but7.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'but8
        '
        Appearance34.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance34.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance34.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance34.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance34.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance34.BorderColor2 = System.Drawing.Color.Maroon
        Appearance34.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance34.ForeColor = System.Drawing.Color.White
        Appearance34.TextVAlignAsString = "Middle"
        Me.but8.Appearance = Appearance34
        Me.but8.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance35.BackColor = System.Drawing.Color.DarkOrange
        Appearance35.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance35.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance35.ForeColor = System.Drawing.Color.Black
        Me.but8.HotTrackAppearance = Appearance35
        Me.but8.ImageSize = New System.Drawing.Size(32, 32)
        Me.but8.Location = New System.Drawing.Point(429, 63)
        Me.but8.Name = "but8"
        Appearance36.BackColor = System.Drawing.Color.OrangeRed
        Appearance36.BackColor2 = System.Drawing.Color.Tomato
        Appearance36.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.but8.PressedAppearance = Appearance36
        Me.but8.ShowFocusRect = False
        Me.but8.ShowOutline = False
        Me.but8.Size = New System.Drawing.Size(60, 60)
        Me.but8.TabIndex = 647
        Me.but8.Tag = "6"
        Me.but8.Text = "8"
        Me.but8.UseAppStyling = False
        Me.but8.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.but8.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.but8.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'but9
        '
        Appearance37.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance37.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance37.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance37.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance37.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance37.BorderColor2 = System.Drawing.Color.Maroon
        Appearance37.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance37.ForeColor = System.Drawing.Color.White
        Appearance37.TextVAlignAsString = "Middle"
        Me.but9.Appearance = Appearance37
        Me.but9.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance38.BackColor = System.Drawing.Color.DarkOrange
        Appearance38.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance38.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance38.ForeColor = System.Drawing.Color.Black
        Me.but9.HotTrackAppearance = Appearance38
        Me.but9.ImageSize = New System.Drawing.Size(32, 32)
        Me.but9.Location = New System.Drawing.Point(490, 63)
        Me.but9.Name = "but9"
        Appearance39.BackColor = System.Drawing.Color.OrangeRed
        Appearance39.BackColor2 = System.Drawing.Color.Tomato
        Appearance39.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.but9.PressedAppearance = Appearance39
        Me.but9.ShowFocusRect = False
        Me.but9.ShowOutline = False
        Me.but9.Size = New System.Drawing.Size(60, 60)
        Me.but9.TabIndex = 646
        Me.but9.Tag = "6"
        Me.but9.Text = "9"
        Me.but9.UseAppStyling = False
        Me.but9.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.but9.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.but9.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'but0
        '
        Appearance40.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance40.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance40.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance40.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance40.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance40.BorderColor2 = System.Drawing.Color.Maroon
        Appearance40.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance40.ForeColor = System.Drawing.Color.White
        Appearance40.TextVAlignAsString = "Middle"
        Me.but0.Appearance = Appearance40
        Me.but0.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance41.BackColor = System.Drawing.Color.DarkOrange
        Appearance41.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance41.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance41.ForeColor = System.Drawing.Color.Black
        Me.but0.HotTrackAppearance = Appearance41
        Me.but0.ImageSize = New System.Drawing.Size(32, 32)
        Me.but0.Location = New System.Drawing.Point(551, 63)
        Me.but0.Name = "but0"
        Appearance42.BackColor = System.Drawing.Color.OrangeRed
        Appearance42.BackColor2 = System.Drawing.Color.Tomato
        Appearance42.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.but0.PressedAppearance = Appearance42
        Me.but0.ShowFocusRect = False
        Me.but0.ShowOutline = False
        Me.but0.Size = New System.Drawing.Size(60, 60)
        Me.but0.TabIndex = 645
        Me.but0.Tag = "6"
        Me.but0.Text = "0"
        Me.but0.UseAppStyling = False
        Me.but0.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.but0.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.but0.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'but1
        '
        Appearance43.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance43.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance43.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance43.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance43.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance43.BorderColor2 = System.Drawing.Color.Maroon
        Appearance43.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance43.ForeColor = System.Drawing.Color.White
        Appearance43.TextVAlignAsString = "Middle"
        Me.but1.Appearance = Appearance43
        Me.but1.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance44.BackColor = System.Drawing.Color.DarkOrange
        Appearance44.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance44.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance44.ForeColor = System.Drawing.Color.Black
        Me.but1.HotTrackAppearance = Appearance44
        Me.but1.ImageSize = New System.Drawing.Size(32, 32)
        Me.but1.Location = New System.Drawing.Point(2, 63)
        Me.but1.Name = "but1"
        Appearance45.BackColor = System.Drawing.Color.OrangeRed
        Appearance45.BackColor2 = System.Drawing.Color.Tomato
        Appearance45.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.but1.PressedAppearance = Appearance45
        Me.but1.ShowFocusRect = False
        Me.but1.ShowOutline = False
        Me.but1.Size = New System.Drawing.Size(60, 60)
        Me.but1.TabIndex = 644
        Me.but1.Tag = "6"
        Me.but1.Text = "1"
        Me.but1.UseAppStyling = False
        Me.but1.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.but1.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.but1.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton9
        '
        Appearance46.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance46.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance46.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance46.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance46.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance46.BorderColor2 = System.Drawing.Color.Maroon
        Appearance46.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance46.ForeColor = System.Drawing.Color.White
        Appearance46.TextVAlignAsString = "Middle"
        Me.UltraButton9.Appearance = Appearance46
        Me.UltraButton9.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance47.BackColor = System.Drawing.Color.DarkOrange
        Appearance47.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance47.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance47.ForeColor = System.Drawing.Color.Black
        Me.UltraButton9.HotTrackAppearance = Appearance47
        Me.UltraButton9.ImageSize = New System.Drawing.Size(32, 32)
        Me.UltraButton9.Location = New System.Drawing.Point(124, 246)
        Me.UltraButton9.Name = "UltraButton9"
        Appearance48.BackColor = System.Drawing.Color.OrangeRed
        Appearance48.BackColor2 = System.Drawing.Color.Tomato
        Appearance48.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.UltraButton9.PressedAppearance = Appearance48
        Me.UltraButton9.ShowFocusRect = False
        Me.UltraButton9.ShowOutline = False
        Me.UltraButton9.Size = New System.Drawing.Size(60, 60)
        Me.UltraButton9.TabIndex = 643
        Me.UltraButton9.Tag = "6"
        Me.UltraButton9.Text = "X"
        Me.UltraButton9.UseAppStyling = False
        Me.UltraButton9.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton9.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton9.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton11
        '
        Appearance49.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance49.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance49.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance49.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance49.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance49.BorderColor2 = System.Drawing.Color.Maroon
        Appearance49.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance49.ForeColor = System.Drawing.Color.White
        Appearance49.TextVAlignAsString = "Middle"
        Me.UltraButton11.Appearance = Appearance49
        Me.UltraButton11.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance50.BackColor = System.Drawing.Color.DarkOrange
        Appearance50.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance50.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance50.ForeColor = System.Drawing.Color.Black
        Me.UltraButton11.HotTrackAppearance = Appearance50
        Me.UltraButton11.ImageSize = New System.Drawing.Size(32, 32)
        Me.UltraButton11.Location = New System.Drawing.Point(185, 246)
        Me.UltraButton11.Name = "UltraButton11"
        Appearance51.BackColor = System.Drawing.Color.OrangeRed
        Appearance51.BackColor2 = System.Drawing.Color.Tomato
        Appearance51.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.UltraButton11.PressedAppearance = Appearance51
        Me.UltraButton11.ShowFocusRect = False
        Me.UltraButton11.ShowOutline = False
        Me.UltraButton11.Size = New System.Drawing.Size(60, 60)
        Me.UltraButton11.TabIndex = 642
        Me.UltraButton11.Tag = "6"
        Me.UltraButton11.Text = "C"
        Me.UltraButton11.UseAppStyling = False
        Me.UltraButton11.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton11.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton11.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton12
        '
        Appearance52.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance52.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance52.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance52.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance52.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance52.BorderColor2 = System.Drawing.Color.Maroon
        Appearance52.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance52.ForeColor = System.Drawing.Color.White
        Appearance52.TextVAlignAsString = "Middle"
        Me.UltraButton12.Appearance = Appearance52
        Me.UltraButton12.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance53.BackColor = System.Drawing.Color.DarkOrange
        Appearance53.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance53.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance53.ForeColor = System.Drawing.Color.Black
        Me.UltraButton12.HotTrackAppearance = Appearance53
        Me.UltraButton12.ImageSize = New System.Drawing.Size(32, 32)
        Me.UltraButton12.Location = New System.Drawing.Point(246, 246)
        Me.UltraButton12.Name = "UltraButton12"
        Appearance54.BackColor = System.Drawing.Color.OrangeRed
        Appearance54.BackColor2 = System.Drawing.Color.Tomato
        Appearance54.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.UltraButton12.PressedAppearance = Appearance54
        Me.UltraButton12.ShowFocusRect = False
        Me.UltraButton12.ShowOutline = False
        Me.UltraButton12.Size = New System.Drawing.Size(60, 60)
        Me.UltraButton12.TabIndex = 641
        Me.UltraButton12.Tag = "6"
        Me.UltraButton12.Text = "V"
        Me.UltraButton12.UseAppStyling = False
        Me.UltraButton12.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton12.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton12.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton13
        '
        Appearance55.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance55.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance55.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance55.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance55.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance55.BorderColor2 = System.Drawing.Color.Maroon
        Appearance55.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance55.ForeColor = System.Drawing.Color.White
        Appearance55.TextVAlignAsString = "Middle"
        Me.UltraButton13.Appearance = Appearance55
        Me.UltraButton13.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance56.BackColor = System.Drawing.Color.DarkOrange
        Appearance56.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance56.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance56.ForeColor = System.Drawing.Color.Black
        Me.UltraButton13.HotTrackAppearance = Appearance56
        Me.UltraButton13.ImageSize = New System.Drawing.Size(32, 32)
        Me.UltraButton13.Location = New System.Drawing.Point(307, 246)
        Me.UltraButton13.Name = "UltraButton13"
        Appearance57.BackColor = System.Drawing.Color.OrangeRed
        Appearance57.BackColor2 = System.Drawing.Color.Tomato
        Appearance57.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.UltraButton13.PressedAppearance = Appearance57
        Me.UltraButton13.ShowFocusRect = False
        Me.UltraButton13.ShowOutline = False
        Me.UltraButton13.Size = New System.Drawing.Size(60, 60)
        Me.UltraButton13.TabIndex = 640
        Me.UltraButton13.Tag = "6"
        Me.UltraButton13.Text = "B"
        Me.UltraButton13.UseAppStyling = False
        Me.UltraButton13.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton13.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton13.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton14
        '
        Appearance58.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance58.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance58.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance58.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance58.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance58.BorderColor2 = System.Drawing.Color.Maroon
        Appearance58.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance58.ForeColor = System.Drawing.Color.White
        Appearance58.TextVAlignAsString = "Middle"
        Me.UltraButton14.Appearance = Appearance58
        Me.UltraButton14.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance59.BackColor = System.Drawing.Color.DarkOrange
        Appearance59.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance59.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance59.ForeColor = System.Drawing.Color.Black
        Me.UltraButton14.HotTrackAppearance = Appearance59
        Me.UltraButton14.ImageSize = New System.Drawing.Size(32, 32)
        Me.UltraButton14.Location = New System.Drawing.Point(368, 246)
        Me.UltraButton14.Name = "UltraButton14"
        Appearance60.BackColor = System.Drawing.Color.OrangeRed
        Appearance60.BackColor2 = System.Drawing.Color.Tomato
        Appearance60.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.UltraButton14.PressedAppearance = Appearance60
        Me.UltraButton14.ShowFocusRect = False
        Me.UltraButton14.ShowOutline = False
        Me.UltraButton14.Size = New System.Drawing.Size(60, 60)
        Me.UltraButton14.TabIndex = 639
        Me.UltraButton14.Tag = "6"
        Me.UltraButton14.Text = "N"
        Me.UltraButton14.UseAppStyling = False
        Me.UltraButton14.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton14.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton14.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton15
        '
        Appearance61.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance61.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance61.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance61.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance61.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance61.BorderColor2 = System.Drawing.Color.Maroon
        Appearance61.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance61.ForeColor = System.Drawing.Color.White
        Appearance61.TextVAlignAsString = "Middle"
        Me.UltraButton15.Appearance = Appearance61
        Me.UltraButton15.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance62.BackColor = System.Drawing.Color.DarkOrange
        Appearance62.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance62.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance62.ForeColor = System.Drawing.Color.Black
        Me.UltraButton15.HotTrackAppearance = Appearance62
        Me.UltraButton15.ImageSize = New System.Drawing.Size(32, 32)
        Me.UltraButton15.Location = New System.Drawing.Point(429, 246)
        Me.UltraButton15.Name = "UltraButton15"
        Appearance63.BackColor = System.Drawing.Color.OrangeRed
        Appearance63.BackColor2 = System.Drawing.Color.Tomato
        Appearance63.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.UltraButton15.PressedAppearance = Appearance63
        Me.UltraButton15.ShowFocusRect = False
        Me.UltraButton15.ShowOutline = False
        Me.UltraButton15.Size = New System.Drawing.Size(60, 60)
        Me.UltraButton15.TabIndex = 638
        Me.UltraButton15.Tag = "6"
        Me.UltraButton15.Text = "M"
        Me.UltraButton15.UseAppStyling = False
        Me.UltraButton15.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton15.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton15.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton19
        '
        Appearance64.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance64.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance64.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance64.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance64.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance64.BorderColor2 = System.Drawing.Color.Maroon
        Appearance64.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance64.ForeColor = System.Drawing.Color.White
        Appearance64.TextVAlignAsString = "Middle"
        Me.UltraButton19.Appearance = Appearance64
        Me.UltraButton19.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance65.BackColor = System.Drawing.Color.DarkOrange
        Appearance65.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance65.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance65.ForeColor = System.Drawing.Color.Black
        Me.UltraButton19.HotTrackAppearance = Appearance65
        Me.UltraButton19.ImageSize = New System.Drawing.Size(32, 32)
        Me.UltraButton19.Location = New System.Drawing.Point(63, 246)
        Me.UltraButton19.Name = "UltraButton19"
        Appearance66.BackColor = System.Drawing.Color.OrangeRed
        Appearance66.BackColor2 = System.Drawing.Color.Tomato
        Appearance66.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.UltraButton19.PressedAppearance = Appearance66
        Me.UltraButton19.ShowFocusRect = False
        Me.UltraButton19.ShowOutline = False
        Me.UltraButton19.Size = New System.Drawing.Size(60, 60)
        Me.UltraButton19.TabIndex = 637
        Me.UltraButton19.Tag = "6"
        Me.UltraButton19.Text = "Z"
        Me.UltraButton19.UseAppStyling = False
        Me.UltraButton19.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton19.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton19.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton2
        '
        Appearance67.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance67.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance67.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance67.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance67.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance67.BorderColor2 = System.Drawing.Color.Maroon
        Appearance67.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance67.ForeColor = System.Drawing.Color.White
        Appearance67.TextVAlignAsString = "Middle"
        Me.UltraButton2.Appearance = Appearance67
        Me.UltraButton2.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance68.BackColor = System.Drawing.Color.DarkOrange
        Appearance68.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance68.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance68.ForeColor = System.Drawing.Color.Black
        Me.UltraButton2.HotTrackAppearance = Appearance68
        Me.UltraButton2.ImageSize = New System.Drawing.Size(32, 32)
        Me.UltraButton2.Location = New System.Drawing.Point(92, 185)
        Me.UltraButton2.Name = "UltraButton2"
        Appearance69.BackColor = System.Drawing.Color.OrangeRed
        Appearance69.BackColor2 = System.Drawing.Color.Tomato
        Appearance69.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.UltraButton2.PressedAppearance = Appearance69
        Me.UltraButton2.ShowFocusRect = False
        Me.UltraButton2.ShowOutline = False
        Me.UltraButton2.Size = New System.Drawing.Size(60, 60)
        Me.UltraButton2.TabIndex = 636
        Me.UltraButton2.Tag = "6"
        Me.UltraButton2.Text = "S"
        Me.UltraButton2.UseAppStyling = False
        Me.UltraButton2.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton2.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton2.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton3
        '
        Appearance70.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance70.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance70.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance70.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance70.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance70.BorderColor2 = System.Drawing.Color.Maroon
        Appearance70.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance70.ForeColor = System.Drawing.Color.White
        Appearance70.TextVAlignAsString = "Middle"
        Me.UltraButton3.Appearance = Appearance70
        Me.UltraButton3.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance71.BackColor = System.Drawing.Color.DarkOrange
        Appearance71.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance71.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance71.ForeColor = System.Drawing.Color.Black
        Me.UltraButton3.HotTrackAppearance = Appearance71
        Me.UltraButton3.ImageSize = New System.Drawing.Size(32, 32)
        Me.UltraButton3.Location = New System.Drawing.Point(153, 185)
        Me.UltraButton3.Name = "UltraButton3"
        Appearance72.BackColor = System.Drawing.Color.OrangeRed
        Appearance72.BackColor2 = System.Drawing.Color.Tomato
        Appearance72.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.UltraButton3.PressedAppearance = Appearance72
        Me.UltraButton3.ShowFocusRect = False
        Me.UltraButton3.ShowOutline = False
        Me.UltraButton3.Size = New System.Drawing.Size(60, 60)
        Me.UltraButton3.TabIndex = 635
        Me.UltraButton3.Tag = "6"
        Me.UltraButton3.Text = "D"
        Me.UltraButton3.UseAppStyling = False
        Me.UltraButton3.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton3.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton3.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton4
        '
        Appearance73.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance73.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance73.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance73.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance73.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance73.BorderColor2 = System.Drawing.Color.Maroon
        Appearance73.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance73.ForeColor = System.Drawing.Color.White
        Appearance73.TextVAlignAsString = "Middle"
        Me.UltraButton4.Appearance = Appearance73
        Me.UltraButton4.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance74.BackColor = System.Drawing.Color.DarkOrange
        Appearance74.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance74.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance74.ForeColor = System.Drawing.Color.Black
        Me.UltraButton4.HotTrackAppearance = Appearance74
        Me.UltraButton4.ImageSize = New System.Drawing.Size(32, 32)
        Me.UltraButton4.Location = New System.Drawing.Point(214, 185)
        Me.UltraButton4.Name = "UltraButton4"
        Appearance75.BackColor = System.Drawing.Color.OrangeRed
        Appearance75.BackColor2 = System.Drawing.Color.Tomato
        Appearance75.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.UltraButton4.PressedAppearance = Appearance75
        Me.UltraButton4.ShowFocusRect = False
        Me.UltraButton4.ShowOutline = False
        Me.UltraButton4.Size = New System.Drawing.Size(60, 60)
        Me.UltraButton4.TabIndex = 634
        Me.UltraButton4.Tag = "6"
        Me.UltraButton4.Text = "F"
        Me.UltraButton4.UseAppStyling = False
        Me.UltraButton4.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton4.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton4.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton5
        '
        Appearance76.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance76.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance76.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance76.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance76.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance76.BorderColor2 = System.Drawing.Color.Maroon
        Appearance76.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance76.ForeColor = System.Drawing.Color.White
        Appearance76.TextVAlignAsString = "Middle"
        Me.UltraButton5.Appearance = Appearance76
        Me.UltraButton5.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance77.BackColor = System.Drawing.Color.DarkOrange
        Appearance77.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance77.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance77.ForeColor = System.Drawing.Color.Black
        Me.UltraButton5.HotTrackAppearance = Appearance77
        Me.UltraButton5.ImageSize = New System.Drawing.Size(32, 32)
        Me.UltraButton5.Location = New System.Drawing.Point(275, 185)
        Me.UltraButton5.Name = "UltraButton5"
        Appearance78.BackColor = System.Drawing.Color.OrangeRed
        Appearance78.BackColor2 = System.Drawing.Color.Tomato
        Appearance78.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.UltraButton5.PressedAppearance = Appearance78
        Me.UltraButton5.ShowFocusRect = False
        Me.UltraButton5.ShowOutline = False
        Me.UltraButton5.Size = New System.Drawing.Size(60, 60)
        Me.UltraButton5.TabIndex = 633
        Me.UltraButton5.Tag = "6"
        Me.UltraButton5.Text = "G"
        Me.UltraButton5.UseAppStyling = False
        Me.UltraButton5.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton5.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton5.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton6
        '
        Appearance79.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance79.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance79.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance79.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance79.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance79.BorderColor2 = System.Drawing.Color.Maroon
        Appearance79.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance79.ForeColor = System.Drawing.Color.White
        Appearance79.TextVAlignAsString = "Middle"
        Me.UltraButton6.Appearance = Appearance79
        Me.UltraButton6.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance80.BackColor = System.Drawing.Color.DarkOrange
        Appearance80.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance80.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance80.ForeColor = System.Drawing.Color.Black
        Me.UltraButton6.HotTrackAppearance = Appearance80
        Me.UltraButton6.ImageSize = New System.Drawing.Size(32, 32)
        Me.UltraButton6.Location = New System.Drawing.Point(336, 185)
        Me.UltraButton6.Name = "UltraButton6"
        Appearance81.BackColor = System.Drawing.Color.OrangeRed
        Appearance81.BackColor2 = System.Drawing.Color.Tomato
        Appearance81.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.UltraButton6.PressedAppearance = Appearance81
        Me.UltraButton6.ShowFocusRect = False
        Me.UltraButton6.ShowOutline = False
        Me.UltraButton6.Size = New System.Drawing.Size(60, 60)
        Me.UltraButton6.TabIndex = 632
        Me.UltraButton6.Tag = "6"
        Me.UltraButton6.Text = "H"
        Me.UltraButton6.UseAppStyling = False
        Me.UltraButton6.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton6.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton6.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton7
        '
        Appearance82.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance82.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance82.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance82.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance82.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance82.BorderColor2 = System.Drawing.Color.Maroon
        Appearance82.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance82.ForeColor = System.Drawing.Color.White
        Appearance82.TextVAlignAsString = "Middle"
        Me.UltraButton7.Appearance = Appearance82
        Me.UltraButton7.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance83.BackColor = System.Drawing.Color.DarkOrange
        Appearance83.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance83.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance83.ForeColor = System.Drawing.Color.Black
        Me.UltraButton7.HotTrackAppearance = Appearance83
        Me.UltraButton7.ImageSize = New System.Drawing.Size(32, 32)
        Me.UltraButton7.Location = New System.Drawing.Point(397, 185)
        Me.UltraButton7.Name = "UltraButton7"
        Appearance84.BackColor = System.Drawing.Color.OrangeRed
        Appearance84.BackColor2 = System.Drawing.Color.Tomato
        Appearance84.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.UltraButton7.PressedAppearance = Appearance84
        Me.UltraButton7.ShowFocusRect = False
        Me.UltraButton7.ShowOutline = False
        Me.UltraButton7.Size = New System.Drawing.Size(60, 60)
        Me.UltraButton7.TabIndex = 631
        Me.UltraButton7.Tag = "6"
        Me.UltraButton7.Text = "J"
        Me.UltraButton7.UseAppStyling = False
        Me.UltraButton7.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton7.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton7.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton8
        '
        Appearance85.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance85.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance85.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance85.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance85.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance85.BorderColor2 = System.Drawing.Color.Maroon
        Appearance85.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance85.ForeColor = System.Drawing.Color.White
        Appearance85.TextVAlignAsString = "Middle"
        Me.UltraButton8.Appearance = Appearance85
        Me.UltraButton8.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance86.BackColor = System.Drawing.Color.DarkOrange
        Appearance86.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance86.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance86.ForeColor = System.Drawing.Color.Black
        Me.UltraButton8.HotTrackAppearance = Appearance86
        Me.UltraButton8.ImageSize = New System.Drawing.Size(32, 32)
        Me.UltraButton8.Location = New System.Drawing.Point(458, 185)
        Me.UltraButton8.Name = "UltraButton8"
        Appearance87.BackColor = System.Drawing.Color.OrangeRed
        Appearance87.BackColor2 = System.Drawing.Color.Tomato
        Appearance87.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.UltraButton8.PressedAppearance = Appearance87
        Me.UltraButton8.ShowFocusRect = False
        Me.UltraButton8.ShowOutline = False
        Me.UltraButton8.Size = New System.Drawing.Size(60, 60)
        Me.UltraButton8.TabIndex = 630
        Me.UltraButton8.Tag = "6"
        Me.UltraButton8.Text = "K"
        Me.UltraButton8.UseAppStyling = False
        Me.UltraButton8.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton8.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton8.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton10
        '
        Appearance88.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance88.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance88.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance88.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance88.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance88.BorderColor2 = System.Drawing.Color.Maroon
        Appearance88.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance88.ForeColor = System.Drawing.Color.White
        Appearance88.TextVAlignAsString = "Middle"
        Me.UltraButton10.Appearance = Appearance88
        Me.UltraButton10.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance89.BackColor = System.Drawing.Color.DarkOrange
        Appearance89.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance89.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance89.ForeColor = System.Drawing.Color.Black
        Me.UltraButton10.HotTrackAppearance = Appearance89
        Me.UltraButton10.ImageSize = New System.Drawing.Size(32, 32)
        Me.UltraButton10.Location = New System.Drawing.Point(519, 185)
        Me.UltraButton10.Name = "UltraButton10"
        Appearance90.BackColor = System.Drawing.Color.OrangeRed
        Appearance90.BackColor2 = System.Drawing.Color.Tomato
        Appearance90.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.UltraButton10.PressedAppearance = Appearance90
        Me.UltraButton10.ShowFocusRect = False
        Me.UltraButton10.ShowOutline = False
        Me.UltraButton10.Size = New System.Drawing.Size(60, 60)
        Me.UltraButton10.TabIndex = 629
        Me.UltraButton10.Tag = "6"
        Me.UltraButton10.Text = "L"
        Me.UltraButton10.UseAppStyling = False
        Me.UltraButton10.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton10.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton10.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton16
        '
        Appearance91.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance91.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance91.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance91.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance91.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance91.BorderColor2 = System.Drawing.Color.Maroon
        Appearance91.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance91.ForeColor = System.Drawing.Color.White
        Appearance91.TextVAlignAsString = "Middle"
        Me.UltraButton16.Appearance = Appearance91
        Me.UltraButton16.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance92.BackColor = System.Drawing.Color.DarkOrange
        Appearance92.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance92.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance92.ForeColor = System.Drawing.Color.Black
        Me.UltraButton16.HotTrackAppearance = Appearance92
        Me.UltraButton16.ImageSize = New System.Drawing.Size(32, 32)
        Me.UltraButton16.Location = New System.Drawing.Point(31, 185)
        Me.UltraButton16.Name = "UltraButton16"
        Appearance93.BackColor = System.Drawing.Color.OrangeRed
        Appearance93.BackColor2 = System.Drawing.Color.Tomato
        Appearance93.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.UltraButton16.PressedAppearance = Appearance93
        Me.UltraButton16.ShowFocusRect = False
        Me.UltraButton16.ShowOutline = False
        Me.UltraButton16.Size = New System.Drawing.Size(60, 60)
        Me.UltraButton16.TabIndex = 628
        Me.UltraButton16.Tag = "6"
        Me.UltraButton16.Text = "A"
        Me.UltraButton16.UseAppStyling = False
        Me.UltraButton16.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton16.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton16.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'butw
        '
        Appearance94.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance94.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance94.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance94.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance94.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance94.BorderColor2 = System.Drawing.Color.Maroon
        Appearance94.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance94.ForeColor = System.Drawing.Color.White
        Appearance94.TextVAlignAsString = "Middle"
        Me.butw.Appearance = Appearance94
        Me.butw.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance95.BackColor = System.Drawing.Color.DarkOrange
        Appearance95.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance95.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance95.ForeColor = System.Drawing.Color.Black
        Me.butw.HotTrackAppearance = Appearance95
        Me.butw.ImageSize = New System.Drawing.Size(32, 32)
        Me.butw.Location = New System.Drawing.Point(63, 124)
        Me.butw.Name = "butw"
        Appearance96.BackColor = System.Drawing.Color.OrangeRed
        Appearance96.BackColor2 = System.Drawing.Color.Tomato
        Appearance96.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.butw.PressedAppearance = Appearance96
        Me.butw.ShowFocusRect = False
        Me.butw.ShowOutline = False
        Me.butw.Size = New System.Drawing.Size(60, 60)
        Me.butw.TabIndex = 627
        Me.butw.Tag = "6"
        Me.butw.Text = "W"
        Me.butw.UseAppStyling = False
        Me.butw.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.butw.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.butw.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'bute
        '
        Appearance97.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance97.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance97.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance97.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance97.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance97.BorderColor2 = System.Drawing.Color.Maroon
        Appearance97.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance97.ForeColor = System.Drawing.Color.White
        Appearance97.TextVAlignAsString = "Middle"
        Me.bute.Appearance = Appearance97
        Me.bute.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance98.BackColor = System.Drawing.Color.DarkOrange
        Appearance98.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance98.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance98.ForeColor = System.Drawing.Color.Black
        Me.bute.HotTrackAppearance = Appearance98
        Me.bute.ImageSize = New System.Drawing.Size(32, 32)
        Me.bute.Location = New System.Drawing.Point(124, 124)
        Me.bute.Name = "bute"
        Appearance99.BackColor = System.Drawing.Color.OrangeRed
        Appearance99.BackColor2 = System.Drawing.Color.Tomato
        Appearance99.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.bute.PressedAppearance = Appearance99
        Me.bute.ShowFocusRect = False
        Me.bute.ShowOutline = False
        Me.bute.Size = New System.Drawing.Size(60, 60)
        Me.bute.TabIndex = 626
        Me.bute.Tag = "6"
        Me.bute.Text = "E"
        Me.bute.UseAppStyling = False
        Me.bute.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.bute.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.bute.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'butr
        '
        Appearance100.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance100.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance100.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance100.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance100.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance100.BorderColor2 = System.Drawing.Color.Maroon
        Appearance100.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance100.ForeColor = System.Drawing.Color.White
        Appearance100.TextVAlignAsString = "Middle"
        Me.butr.Appearance = Appearance100
        Me.butr.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance101.BackColor = System.Drawing.Color.DarkOrange
        Appearance101.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance101.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance101.ForeColor = System.Drawing.Color.Black
        Me.butr.HotTrackAppearance = Appearance101
        Me.butr.ImageSize = New System.Drawing.Size(32, 32)
        Me.butr.Location = New System.Drawing.Point(185, 124)
        Me.butr.Name = "butr"
        Appearance102.BackColor = System.Drawing.Color.OrangeRed
        Appearance102.BackColor2 = System.Drawing.Color.Tomato
        Appearance102.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.butr.PressedAppearance = Appearance102
        Me.butr.ShowFocusRect = False
        Me.butr.ShowOutline = False
        Me.butr.Size = New System.Drawing.Size(60, 60)
        Me.butr.TabIndex = 625
        Me.butr.Tag = "6"
        Me.butr.Text = "R"
        Me.butr.UseAppStyling = False
        Me.butr.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.butr.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.butr.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'butt
        '
        Appearance103.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance103.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance103.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance103.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance103.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance103.BorderColor2 = System.Drawing.Color.Maroon
        Appearance103.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance103.ForeColor = System.Drawing.Color.White
        Appearance103.TextVAlignAsString = "Middle"
        Me.butt.Appearance = Appearance103
        Me.butt.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance104.BackColor = System.Drawing.Color.DarkOrange
        Appearance104.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance104.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance104.ForeColor = System.Drawing.Color.Black
        Me.butt.HotTrackAppearance = Appearance104
        Me.butt.ImageSize = New System.Drawing.Size(32, 32)
        Me.butt.Location = New System.Drawing.Point(246, 124)
        Me.butt.Name = "butt"
        Appearance105.BackColor = System.Drawing.Color.OrangeRed
        Appearance105.BackColor2 = System.Drawing.Color.Tomato
        Appearance105.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.butt.PressedAppearance = Appearance105
        Me.butt.ShowFocusRect = False
        Me.butt.ShowOutline = False
        Me.butt.Size = New System.Drawing.Size(60, 60)
        Me.butt.TabIndex = 624
        Me.butt.Tag = "6"
        Me.butt.Text = "T"
        Me.butt.UseAppStyling = False
        Me.butt.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.butt.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.butt.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'buty
        '
        Appearance106.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance106.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance106.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance106.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance106.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance106.BorderColor2 = System.Drawing.Color.Maroon
        Appearance106.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance106.ForeColor = System.Drawing.Color.White
        Appearance106.TextVAlignAsString = "Middle"
        Me.buty.Appearance = Appearance106
        Me.buty.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance107.BackColor = System.Drawing.Color.DarkOrange
        Appearance107.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance107.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance107.ForeColor = System.Drawing.Color.Black
        Me.buty.HotTrackAppearance = Appearance107
        Me.buty.ImageSize = New System.Drawing.Size(32, 32)
        Me.buty.Location = New System.Drawing.Point(307, 124)
        Me.buty.Name = "buty"
        Appearance108.BackColor = System.Drawing.Color.OrangeRed
        Appearance108.BackColor2 = System.Drawing.Color.Tomato
        Appearance108.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.buty.PressedAppearance = Appearance108
        Me.buty.ShowFocusRect = False
        Me.buty.ShowOutline = False
        Me.buty.Size = New System.Drawing.Size(60, 60)
        Me.buty.TabIndex = 623
        Me.buty.Tag = "6"
        Me.buty.Text = "Y"
        Me.buty.UseAppStyling = False
        Me.buty.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.buty.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.buty.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton23
        '
        Appearance109.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance109.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance109.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance109.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance109.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance109.BorderColor2 = System.Drawing.Color.Maroon
        Appearance109.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance109.ForeColor = System.Drawing.Color.White
        Appearance109.TextVAlignAsString = "Middle"
        Me.UltraButton23.Appearance = Appearance109
        Me.UltraButton23.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance110.BackColor = System.Drawing.Color.DarkOrange
        Appearance110.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance110.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance110.ForeColor = System.Drawing.Color.Black
        Me.UltraButton23.HotTrackAppearance = Appearance110
        Me.UltraButton23.ImageSize = New System.Drawing.Size(32, 32)
        Me.UltraButton23.Location = New System.Drawing.Point(368, 124)
        Me.UltraButton23.Name = "UltraButton23"
        Appearance111.BackColor = System.Drawing.Color.OrangeRed
        Appearance111.BackColor2 = System.Drawing.Color.Tomato
        Appearance111.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.UltraButton23.PressedAppearance = Appearance111
        Me.UltraButton23.ShowFocusRect = False
        Me.UltraButton23.ShowOutline = False
        Me.UltraButton23.Size = New System.Drawing.Size(60, 60)
        Me.UltraButton23.TabIndex = 622
        Me.UltraButton23.Tag = "6"
        Me.UltraButton23.Text = "U"
        Me.UltraButton23.UseAppStyling = False
        Me.UltraButton23.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton23.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton23.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton22
        '
        Appearance112.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance112.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance112.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance112.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance112.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance112.BorderColor2 = System.Drawing.Color.Maroon
        Appearance112.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance112.ForeColor = System.Drawing.Color.White
        Appearance112.TextVAlignAsString = "Middle"
        Me.UltraButton22.Appearance = Appearance112
        Me.UltraButton22.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance113.BackColor = System.Drawing.Color.DarkOrange
        Appearance113.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance113.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance113.ForeColor = System.Drawing.Color.Black
        Me.UltraButton22.HotTrackAppearance = Appearance113
        Me.UltraButton22.ImageSize = New System.Drawing.Size(32, 32)
        Me.UltraButton22.Location = New System.Drawing.Point(429, 124)
        Me.UltraButton22.Name = "UltraButton22"
        Appearance114.BackColor = System.Drawing.Color.OrangeRed
        Appearance114.BackColor2 = System.Drawing.Color.Tomato
        Appearance114.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.UltraButton22.PressedAppearance = Appearance114
        Me.UltraButton22.ShowFocusRect = False
        Me.UltraButton22.ShowOutline = False
        Me.UltraButton22.Size = New System.Drawing.Size(60, 60)
        Me.UltraButton22.TabIndex = 621
        Me.UltraButton22.Tag = "6"
        Me.UltraButton22.Text = "I"
        Me.UltraButton22.UseAppStyling = False
        Me.UltraButton22.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton22.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton22.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton21
        '
        Appearance115.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance115.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance115.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance115.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance115.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance115.BorderColor2 = System.Drawing.Color.Maroon
        Appearance115.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance115.ForeColor = System.Drawing.Color.White
        Appearance115.TextVAlignAsString = "Middle"
        Me.UltraButton21.Appearance = Appearance115
        Me.UltraButton21.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance116.BackColor = System.Drawing.Color.DarkOrange
        Appearance116.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance116.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance116.ForeColor = System.Drawing.Color.Black
        Me.UltraButton21.HotTrackAppearance = Appearance116
        Me.UltraButton21.ImageSize = New System.Drawing.Size(32, 32)
        Me.UltraButton21.Location = New System.Drawing.Point(490, 124)
        Me.UltraButton21.Name = "UltraButton21"
        Appearance117.BackColor = System.Drawing.Color.OrangeRed
        Appearance117.BackColor2 = System.Drawing.Color.Tomato
        Appearance117.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.UltraButton21.PressedAppearance = Appearance117
        Me.UltraButton21.ShowFocusRect = False
        Me.UltraButton21.ShowOutline = False
        Me.UltraButton21.Size = New System.Drawing.Size(60, 60)
        Me.UltraButton21.TabIndex = 620
        Me.UltraButton21.Tag = "6"
        Me.UltraButton21.Text = "O"
        Me.UltraButton21.UseAppStyling = False
        Me.UltraButton21.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton21.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton21.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton20
        '
        Appearance118.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance118.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance118.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance118.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance118.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance118.BorderColor2 = System.Drawing.Color.Maroon
        Appearance118.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance118.ForeColor = System.Drawing.Color.White
        Appearance118.TextVAlignAsString = "Middle"
        Me.UltraButton20.Appearance = Appearance118
        Me.UltraButton20.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance119.BackColor = System.Drawing.Color.DarkOrange
        Appearance119.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance119.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance119.ForeColor = System.Drawing.Color.Black
        Me.UltraButton20.HotTrackAppearance = Appearance119
        Me.UltraButton20.ImageSize = New System.Drawing.Size(32, 32)
        Me.UltraButton20.Location = New System.Drawing.Point(551, 124)
        Me.UltraButton20.Name = "UltraButton20"
        Appearance120.BackColor = System.Drawing.Color.OrangeRed
        Appearance120.BackColor2 = System.Drawing.Color.Tomato
        Appearance120.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.UltraButton20.PressedAppearance = Appearance120
        Me.UltraButton20.ShowFocusRect = False
        Me.UltraButton20.ShowOutline = False
        Me.UltraButton20.Size = New System.Drawing.Size(60, 60)
        Me.UltraButton20.TabIndex = 619
        Me.UltraButton20.Tag = "6"
        Me.UltraButton20.Text = "P"
        Me.UltraButton20.UseAppStyling = False
        Me.UltraButton20.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton20.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton20.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'butq
        '
        Appearance121.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance121.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance121.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance121.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance121.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance121.BorderColor2 = System.Drawing.Color.Maroon
        Appearance121.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance121.ForeColor = System.Drawing.Color.White
        Appearance121.TextVAlignAsString = "Middle"
        Me.butq.Appearance = Appearance121
        Me.butq.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance122.BackColor = System.Drawing.Color.DarkOrange
        Appearance122.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance122.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance122.ForeColor = System.Drawing.Color.Black
        Me.butq.HotTrackAppearance = Appearance122
        Me.butq.ImageSize = New System.Drawing.Size(32, 32)
        Me.butq.Location = New System.Drawing.Point(2, 124)
        Me.butq.Name = "butq"
        Appearance123.BackColor = System.Drawing.Color.OrangeRed
        Appearance123.BackColor2 = System.Drawing.Color.Tomato
        Appearance123.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.butq.PressedAppearance = Appearance123
        Me.butq.ShowFocusRect = False
        Me.butq.ShowOutline = False
        Me.butq.Size = New System.Drawing.Size(60, 60)
        Me.butq.TabIndex = 618
        Me.butq.Tag = "6"
        Me.butq.Text = "Q"
        Me.butq.UseAppStyling = False
        Me.butq.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.butq.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.butq.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'DishKBControl
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(16, Byte), Integer), CType(CType(105, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.Controls.Add(Me.upnlKeyboard)
        Me.Name = "DishKBControl"
        Me.Size = New System.Drawing.Size(740, 315)
        Me.upnlKeyboard.ClientArea.ResumeLayout(False)
        Me.upnlKeyboard.ClientArea.PerformLayout()
        Me.upnlKeyboard.ResumeLayout(False)
        CType(Me.txtManualEntry, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents upnlKeyboard As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents cmdBack As Infragistics.Win.Misc.UltraButton
    Friend WithEvents lblCode As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblDish As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents cmdClear As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdOK As Infragistics.Win.Misc.UltraButton
    Friend WithEvents but2 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents but3 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents but4 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents but5 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents but6 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents but7 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents but8 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents but9 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents but0 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents but1 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton9 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton11 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton12 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton13 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton14 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton15 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton19 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton2 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton3 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton4 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton5 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton6 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton7 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton8 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton10 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton16 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents butw As Infragistics.Win.Misc.UltraButton
    Friend WithEvents bute As Infragistics.Win.Misc.UltraButton
    Friend WithEvents butr As Infragistics.Win.Misc.UltraButton
    Friend WithEvents butt As Infragistics.Win.Misc.UltraButton
    Friend WithEvents buty As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton23 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton22 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton21 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton20 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents butq As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdVersion As Infragistics.Win.Misc.UltraButton
    Friend WithEvents txtManualEntry As Infragistics.Win.UltraWinEditors.UltraTextEditor
End Class
