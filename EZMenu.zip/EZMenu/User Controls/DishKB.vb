﻿Imports Infragistics.Win.Misc

Public Class DishKBControl

    Public ctrlName As Control
    Public upnlDishChoices As UltraPanel

    Private mblnUnload, blnEraseBox As Boolean
    Private SQLQuery, strDQty, strDCode, strDName, tempStr As String
    Private drDataRow As DataRow
    Private drcDataRowCollection As DataRowCollection
    Private strVar As String
    Private sngUniqueID As Short

    Public Property QuantCode As String

        Get
            Return lblCode.Text
        End Get
        Set(Value As String)
            lblCode.Text = Value
        End Set

    End Property

    Public Property EZConnectionString As String

    Public Sub ClearAll()

        lblCode.Text = String.Empty
        lblCode.Tag = "0"
        lblDish.Text = String.Empty
        txtManualEntry.Text = String.Empty

        Try
            'this is in EZ-Menu frmOrderEntry screen
            upnlDishChoices.Visible = False
        Catch ex As Exception
        End Try

    End Sub

    Private Sub DishKBControl_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        For Each myCtrl As Control In upnlKeyboard.ClientArea.Controls
            If myCtrl.Width = 60 And myCtrl.Height = 60 Then
                AddHandler myCtrl.Click, AddressOf myButHandler
            End If
        Next

        'this is used for testing only
        'strConnectionString = My.Settings.EZConnString.ToString
        'ctrlName = New TextBox

    End Sub

    Private Sub cmdClear_Click(sender As Object, e As EventArgs) Handles cmdClear.Click

        ClearAll()

    End Sub

    Private Sub myButHandler(sender As Object, e As EventArgs)

        Try
            If blnEraseBox = True Then
                lblCode.Text = String.Empty
                lblDish.Text = String.Empty
                txtManualEntry.Text = String.Empty
                blnEraseBox = False
            End If

            If lblCode.Text.Length >= 8 Then Exit Sub

            lblCode.Text &= sender.text
            txtManualEntry.Text &= sender.text

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub SortInput(strEntry As String)

        strDQty = ""
        strDCode = ""

        'entered quantity & dish code at once in txCode box	(e.g 3CTM)
        If (IsANumber(strEntry.First) And Not IsANumber(strEntry.Last)) Or
            (IsANumber(strEntry.Last) And Not IsANumber(strEntry.First)) Then

            For Each x In strEntry
                If IsANumber(x) Then
                    strDQty &= x
                Else
                    strDCode &= x
                End If
            Next

        Else                                'dish shortcode (e.g CTM)   dish code (e.g 23)
            strDQty = 1
            strDCode = strEntry
        End If

    End Sub

    Private Function GetDishName(sngUniqueID As Short, strDCode As String) As String

        If sngUniqueID = 0 Then Return Nothing

        Try
            drcDataRowCollection = clsDish.GetDishName(sngUniqueID, strDCode)
            If drcDataRowCollection IsNot Nothing Then
                If (drcDataRowCollection.Count = 1) Or (drcDataRowCollection.Count > 1 AndAlso IsANumber(strDCode) = False) Then
                    Return drcDataRowCollection(0).Item(LNSNOnscreen)
                Else
                    Return drcDataRowCollection(1).Item(LNSNOnscreen)
                End If
            End If
        Catch ex As Exception

        End Try

        Return Nothing

    End Function

    Private Sub cmdVersion_Click(sender As Object, e As EventArgs) Handles cmdVersion.Click
        'txtManualEntry.Visible = Not txtManualEntry.Visible
    End Sub

    Private Function GetUniqueID(strDishCode As String) As Short

        If IsANumber(strDishCode) Then  'dish code 24
            SQLQuery = $"SELECT d.UniqueID
                         FROM Dish d INNER JOIN Groups g ON d.GroupName = g.GroupName
                         WHERE (d.Code = '{strDishCode}') AND (g.CuisineName = '{GetAppSettingCS("MultiCuisinesDefault", String.Empty)}')"

        Else                        'dish code CTM
            SQLQuery = $"SELECT d.UniqueID
                         FROM Codes c INNER JOIN Dish d ON c.UniqueID = d.UniqueID
                         INNER JOIN Groups g ON d.GroupName = g.GroupName
                         WHERE (c.ShortCode = '{strDishCode}') AND (g.CuisineName = '{GetAppSettingCS("MultiCuisinesDefault", String.Empty)}')"

            SQLQuery = $"SELECT d.UniqueID 
                         FROM Codes c INNER JOIN Dish d ON c.UniqueID = d.UniqueID 
                         INNER JOIN Groups g ON d.GroupName = g.GroupName 
                         WHERE (c.ShortCode = '{strDishCode}' AND g.CuisineName = '{GetAppSettingCS("MultiCuisinesDefault", String.Empty)}')
                         UNION 
                         SELECT dc.UniqueID 
                         FROM DishCascade dc INNER JOIN Groups g ON dc.GroupName = g.GroupName
                         WHERE (dc.Shortcode = '{strDishCode}') AND (g.CuisineName = '{GetAppSettingCS("MultiCuisinesDefault", String.Empty)}')"
        End If

        lblDish.Appearance.ForeColor = Color.White

        Try
            drcDataRowCollection = objDB.GetDataRows(SQLQuery)
            If drcDataRowCollection IsNot Nothing Then
                If drcDataRowCollection.Count = 1 Then
                    lblDish.Tag = "0"
                    Return drcDataRowCollection(0)("UniqueID")

                ElseIf drcDataRowCollection.Count > 1 Then
                    lblDish.Tag = "1"
                    lblDish.Appearance.ForeColor = Color.Yellow
                    Return drcDataRowCollection(0)("UniqueID")

                End If
            Else
                Return Nothing
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

        Return Nothing

    End Function

    Private Sub lblCode_TextChanged(sender As Object, e As EventArgs) Handles lblCode.TextChanged

        Try
            'this is in EZ-Menu frmOrderEntry screen
            upnlDishChoices.Visible = False
        Catch ex As Exception
        End Try

        If lblCode.Text.Length > 0 Then
            SortInput(lblCode.Text)
            sngUniqueID = GetUniqueID(strDCode)
            lblCode.Tag = sngUniqueID

            'see if this uniqueID is in DishCascade
            Dim blnIsInDishCascade As Boolean = FoundInDishCascade(sngUniqueID)
            If blnIsInDishCascade = True AndAlso IsANumber(strDCode) Then
                strDCode &= "*" & sngUniqueID
                lblDish.Tag = "1"
                lblDish.Appearance.ForeColor = Color.Yellow
            Else
                strDName = GetDishName(sngUniqueID, strDCode)
            End If

            If strDName <> String.Empty Then
                tempStr = strDQty & "  " & strDName
                If lblDish.Tag = "1" Then
                    tempStr = "<- select option above ->"
                    ctrlName.Text = "##" & strDCode
                End If
            Else
                tempStr = "<- no match found ->"
            End If

        Else
            tempStr = String.Empty
        End If

        lblDish.Text = tempStr

    End Sub

    Private Sub cmdOK_Click(sender As Object, e As EventArgs) Handles cmdOK.Click

        Try
            If lblDish.Text <> "<- select option above ->" Then
                blnEraseBox = True
                If Short.Parse(lblCode.Tag) > 0 Then
                    If ctrlName IsNot Nothing Then
                        tempStr = sngUniqueID & ";" & strDCode & ";" & strDQty & ";" & strDName
                        ctrlName.Text = tempStr
                        cmdClear_Click(sender, e)
                    Else
                        MsgBox("No control set")
                    End If
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub cmdBack_Click(sender As Object, e As EventArgs) Handles cmdBack.Click

        Try
            lblCode.Text = String.Empty
            lblDish.Text = String.Empty
            txtManualEntry.Text = String.Empty

            Try
                'this is in EZ-Menu frmOrderEntry screen
                upnlDishChoices.Visible = False
            Catch ex As Exception
            End Try

            Dispose()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Function LNSNOnscreen() As String

        If GetAppSettingCS("LNSNOnscreen", "LN") = "LN" Then
            Return "DishName"
        Else
            Return "ShortName"
        End If

    End Function

    Private Function FoundInDishCascade(sngUID As Single) As Boolean

        SQLQuery = "SELECT * FROM DishCascade WHERE UniqueID = " & sngUID
        drcDataRowCollection = objDB.GetDataRows(SQLQuery)
        If drcDataRowCollection IsNot Nothing AndAlso drcDataRowCollection.Count > 0 Then
            Return True
        Else
            Return False
        End If

    End Function

    Private Sub txtManualEntry_TextChanged(sender As Object, e As EventArgs) Handles txtManualEntry.TextChanged
        lblCode.Text = txtManualEntry.Text
    End Sub

    Private Sub txtManualEntry_KeyDown(sender As Object, e As KeyEventArgs) Handles txtManualEntry.KeyDown

        If (e.KeyCode = Keys.Enter) Then
            If txtManualEntry.Text.Length > 0 Then
                cmdOK_Click(sender, e)
                txtManualEntry.Text = String.Empty
            End If
        End If

    End Sub

End Class
