﻿Public Class ModifierButton

    Private _strPrice, _strText As String
    Private _fontControl As Font
    Private _ptAddress As Point
    Private _blnIsSelected As Boolean = False

    Public Event ModButtonClickHandler(sender As Object)

    Public Property SetText As String

        Get
            Return _strText
        End Get

        Set(Value As String)
            lblMod.Text = Value
            _strText = Value
        End Set

    End Property

    Public Property Price As String

        Get
            Return _strPrice
        End Get

        Set(Value As String)
            lblPrice.Text = Value
            _strPrice = Value
        End Set

    End Property

    Public Property SetFont As Font

        Get
            Return _fontControl
        End Get

        Set(Value As Font)
            lblMod.Font = Value
        End Set

    End Property

    Public Property ModLocation As Point

        Get
            Return _ptAddress
        End Get

        Set(Value As Point)
            _ptAddress = Value
            lblMod.Location = New Point(ModLocation)
        End Set

    End Property

    Public Property Selected As Boolean

        Get
            Return _blnIsSelected
        End Get

        Set(value As Boolean)
            _blnIsSelected = value

            If _blnIsSelected = True Then
                pnlMod.BackgroundImage = Image.FromFile(EZImages("mod_hilit2"))
            Else
                pnlMod.BackgroundImage = Image.FromFile(EZImages("mod_normal"))
            End If

        End Set

    End Property

    Public Sub New()

        MyBase.New()
        InitializeComponent()

        _blnIsSelected = False

        With lblMod
            .Size = New Size(129, 46)
            .Location = New Point(1, 1)
            '.BorderStyle = Windows.Forms.BorderStyle.FixedSingle
            .Visible = True
            .BringToFront()
        End With

    End Sub

    Private Sub CostClickHandler(sender As Object, e As EventArgs) Handles lblMod.Click, lblPrice.Click

        If _blnIsSelected = True Then
            pnlMod.BackgroundImage = Image.FromFile(EZImages("mod_normal"))
        Else
            pnlMod.BackgroundImage = Image.FromFile(EZImages("mod_hilit3"))
        End If

        _blnIsSelected = Not _blnIsSelected

        RaiseEvent ModButtonClickHandler(Me)

    End Sub

End Class