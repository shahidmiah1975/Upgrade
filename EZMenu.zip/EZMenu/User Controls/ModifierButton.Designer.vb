﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ModifierButton
    Inherits System.Windows.Forms.UserControl

    'UserControl1 overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ModifierButton))
        Me.lblMod = New System.Windows.Forms.Label()
        Me.pnlMod = New System.Windows.Forms.Panel()
        Me.lblPrice = New System.Windows.Forms.Label()
        Me.pnlMod.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblMod
        '
        Me.lblMod.BackColor = System.Drawing.Color.Transparent
        Me.lblMod.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMod.ForeColor = System.Drawing.Color.Black
        Me.lblMod.Location = New System.Drawing.Point(3, 3)
        Me.lblMod.Name = "lblMod"
        Me.lblMod.Size = New System.Drawing.Size(122, 42)
        Me.lblMod.TabIndex = 1
        Me.lblMod.Text = "<mod_desc>"
        Me.lblMod.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'pnlMod
        '
        Me.pnlMod.AutoSize = True
        Me.pnlMod.BackColor = System.Drawing.Color.Transparent
        Me.pnlMod.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.pnlMod.Controls.Add(Me.lblPrice)
        Me.pnlMod.Controls.Add(Me.lblMod)
        Me.pnlMod.Location = New System.Drawing.Point(0, 0)
        Me.pnlMod.Name = "pnlMod"
        Me.pnlMod.Size = New System.Drawing.Size(132, 63)
        Me.pnlMod.TabIndex = 2
        '
        'lblPrice
        '
        Me.lblPrice.BackColor = System.Drawing.Color.Transparent
        Me.lblPrice.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPrice.ForeColor = System.Drawing.Color.DimGray
        Me.lblPrice.Location = New System.Drawing.Point(5, 48)
        Me.lblPrice.Name = "lblPrice"
        Me.lblPrice.Size = New System.Drawing.Size(122, 11)
        Me.lblPrice.TabIndex = 2
        Me.lblPrice.Text = "<mod_price>"
        Me.lblPrice.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Modifier
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Maroon
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.Controls.Add(Me.pnlMod)
        Me.Name = "Modifier"
        Me.Size = New System.Drawing.Size(131, 63)
        Me.pnlMod.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblMod As System.Windows.Forms.Label
    Friend WithEvents pnlMod As System.Windows.Forms.Panel
    Friend WithEvents lblPrice As System.Windows.Forms.Label

End Class
