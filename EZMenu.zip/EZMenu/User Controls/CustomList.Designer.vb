﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class CustomListDesigner
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim Appearance1 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance2 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance3 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance4 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance5 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance6 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance7 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance8 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance9 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance10 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Me.cmdDC1 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDC2 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDC3 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDC4 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDC5 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDC6 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDC7 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDC8 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDC9 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdCancel = New Infragistics.Win.Misc.UltraButton()
        Me.SuspendLayout()
        '
        'cmdDC1
        '
        Me.cmdDC1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance1.BackColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Appearance1.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance1.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance1.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance1.ForeColor = System.Drawing.Color.DimGray
        Appearance1.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance1.ImageVAlign = Infragistics.Win.VAlign.Top
        Me.cmdDC1.Appearance = Appearance1
        Me.cmdDC1.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdDC1.ImageSize = New System.Drawing.Size(48, 48)
        Me.cmdDC1.Location = New System.Drawing.Point(16, 12)
        Me.cmdDC1.Name = "cmdDC1"
        Me.cmdDC1.ShowFocusRect = False
        Me.cmdDC1.ShowOutline = False
        Me.cmdDC1.Size = New System.Drawing.Size(279, 40)
        Me.cmdDC1.StyleSetName = "OECascadeButton"
        Me.cmdDC1.TabIndex = 566
        Me.cmdDC1.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDC1.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdDC1.Visible = False
        '
        'cmdDC2
        '
        Me.cmdDC2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance2.BackColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Appearance2.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance2.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance2.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance2.ForeColor = System.Drawing.Color.DimGray
        Appearance2.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance2.ImageVAlign = Infragistics.Win.VAlign.Top
        Me.cmdDC2.Appearance = Appearance2
        Me.cmdDC2.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdDC2.ImageSize = New System.Drawing.Size(48, 48)
        Me.cmdDC2.Location = New System.Drawing.Point(16, 58)
        Me.cmdDC2.Name = "cmdDC2"
        Me.cmdDC2.ShowFocusRect = False
        Me.cmdDC2.ShowOutline = False
        Me.cmdDC2.Size = New System.Drawing.Size(279, 40)
        Me.cmdDC2.StyleSetName = "OECascadeButton"
        Me.cmdDC2.TabIndex = 567
        Me.cmdDC2.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDC2.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdDC2.Visible = False
        '
        'cmdDC3
        '
        Me.cmdDC3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance3.BackColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Appearance3.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance3.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance3.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance3.ForeColor = System.Drawing.Color.DimGray
        Appearance3.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance3.ImageVAlign = Infragistics.Win.VAlign.Top
        Me.cmdDC3.Appearance = Appearance3
        Me.cmdDC3.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdDC3.ImageSize = New System.Drawing.Size(48, 48)
        Me.cmdDC3.Location = New System.Drawing.Point(16, 104)
        Me.cmdDC3.Name = "cmdDC3"
        Me.cmdDC3.ShowFocusRect = False
        Me.cmdDC3.ShowOutline = False
        Me.cmdDC3.Size = New System.Drawing.Size(279, 40)
        Me.cmdDC3.StyleSetName = "OECascadeButton"
        Me.cmdDC3.TabIndex = 568
        Me.cmdDC3.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDC3.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdDC3.Visible = False
        '
        'cmdDC4
        '
        Me.cmdDC4.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance4.BackColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Appearance4.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance4.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance4.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance4.ForeColor = System.Drawing.Color.DimGray
        Appearance4.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance4.ImageVAlign = Infragistics.Win.VAlign.Top
        Me.cmdDC4.Appearance = Appearance4
        Me.cmdDC4.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdDC4.ImageSize = New System.Drawing.Size(48, 48)
        Me.cmdDC4.Location = New System.Drawing.Point(16, 150)
        Me.cmdDC4.Name = "cmdDC4"
        Me.cmdDC4.ShowFocusRect = False
        Me.cmdDC4.ShowOutline = False
        Me.cmdDC4.Size = New System.Drawing.Size(279, 40)
        Me.cmdDC4.StyleSetName = "OECascadeButton"
        Me.cmdDC4.TabIndex = 569
        Me.cmdDC4.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDC4.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdDC4.Visible = False
        '
        'cmdDC5
        '
        Me.cmdDC5.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance5.BackColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Appearance5.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance5.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance5.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance5.ForeColor = System.Drawing.Color.DimGray
        Appearance5.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance5.ImageVAlign = Infragistics.Win.VAlign.Top
        Me.cmdDC5.Appearance = Appearance5
        Me.cmdDC5.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdDC5.ImageSize = New System.Drawing.Size(48, 48)
        Me.cmdDC5.Location = New System.Drawing.Point(16, 196)
        Me.cmdDC5.Name = "cmdDC5"
        Me.cmdDC5.ShowFocusRect = False
        Me.cmdDC5.ShowOutline = False
        Me.cmdDC5.Size = New System.Drawing.Size(279, 40)
        Me.cmdDC5.StyleSetName = "OECascadeButton"
        Me.cmdDC5.TabIndex = 570
        Me.cmdDC5.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDC5.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdDC5.Visible = False
        '
        'cmdDC6
        '
        Me.cmdDC6.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance6.BackColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Appearance6.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance6.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance6.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance6.ForeColor = System.Drawing.Color.DimGray
        Appearance6.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance6.ImageVAlign = Infragistics.Win.VAlign.Top
        Me.cmdDC6.Appearance = Appearance6
        Me.cmdDC6.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdDC6.ImageSize = New System.Drawing.Size(48, 48)
        Me.cmdDC6.Location = New System.Drawing.Point(16, 242)
        Me.cmdDC6.Name = "cmdDC6"
        Me.cmdDC6.ShowFocusRect = False
        Me.cmdDC6.ShowOutline = False
        Me.cmdDC6.Size = New System.Drawing.Size(279, 40)
        Me.cmdDC6.StyleSetName = "OECascadeButton"
        Me.cmdDC6.TabIndex = 571
        Me.cmdDC6.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDC6.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdDC6.Visible = False
        '
        'cmdDC7
        '
        Me.cmdDC7.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance7.BackColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Appearance7.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance7.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance7.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance7.ForeColor = System.Drawing.Color.DimGray
        Appearance7.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance7.ImageVAlign = Infragistics.Win.VAlign.Top
        Me.cmdDC7.Appearance = Appearance7
        Me.cmdDC7.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdDC7.ImageSize = New System.Drawing.Size(48, 48)
        Me.cmdDC7.Location = New System.Drawing.Point(16, 288)
        Me.cmdDC7.Name = "cmdDC7"
        Me.cmdDC7.ShowFocusRect = False
        Me.cmdDC7.ShowOutline = False
        Me.cmdDC7.Size = New System.Drawing.Size(279, 40)
        Me.cmdDC7.StyleSetName = "OECascadeButton"
        Me.cmdDC7.TabIndex = 572
        Me.cmdDC7.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDC7.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdDC7.Visible = False
        '
        'cmdDC8
        '
        Me.cmdDC8.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance8.BackColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Appearance8.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance8.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance8.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance8.ForeColor = System.Drawing.Color.DimGray
        Appearance8.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance8.ImageVAlign = Infragistics.Win.VAlign.Top
        Me.cmdDC8.Appearance = Appearance8
        Me.cmdDC8.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdDC8.ImageSize = New System.Drawing.Size(48, 48)
        Me.cmdDC8.Location = New System.Drawing.Point(16, 334)
        Me.cmdDC8.Name = "cmdDC8"
        Me.cmdDC8.ShowFocusRect = False
        Me.cmdDC8.ShowOutline = False
        Me.cmdDC8.Size = New System.Drawing.Size(279, 40)
        Me.cmdDC8.StyleSetName = "OECascadeButton"
        Me.cmdDC8.TabIndex = 573
        Me.cmdDC8.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDC8.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdDC8.Visible = False
        '
        'cmdDC9
        '
        Me.cmdDC9.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance9.BackColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Appearance9.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance9.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance9.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance9.ForeColor = System.Drawing.Color.DimGray
        Appearance9.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance9.ImageVAlign = Infragistics.Win.VAlign.Top
        Me.cmdDC9.Appearance = Appearance9
        Me.cmdDC9.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdDC9.ImageSize = New System.Drawing.Size(48, 48)
        Me.cmdDC9.Location = New System.Drawing.Point(16, 380)
        Me.cmdDC9.Name = "cmdDC9"
        Me.cmdDC9.ShowFocusRect = False
        Me.cmdDC9.ShowOutline = False
        Me.cmdDC9.Size = New System.Drawing.Size(279, 40)
        Me.cmdDC9.StyleSetName = "OECascadeButton"
        Me.cmdDC9.TabIndex = 574
        Me.cmdDC9.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDC9.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdDC9.Visible = False
        '
        'cmdCancel
        '
        Me.cmdCancel.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance10.BackColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Appearance10.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance10.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance10.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance10.ForeColor = System.Drawing.Color.DimGray
        Appearance10.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance10.ImageVAlign = Infragistics.Win.VAlign.Top
        Me.cmdCancel.Appearance = Appearance10
        Me.cmdCancel.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdCancel.ImageSize = New System.Drawing.Size(48, 48)
        Me.cmdCancel.Location = New System.Drawing.Point(86, 462)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.ShowFocusRect = False
        Me.cmdCancel.ShowOutline = False
        Me.cmdCancel.Size = New System.Drawing.Size(139, 40)
        Me.cmdCancel.StyleSetName = "OEGroupButton"
        Me.cmdCancel.TabIndex = 575
        Me.cmdCancel.Text = "Cancel"
        Me.cmdCancel.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdCancel.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'CustomListDesigner
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(220, Byte), Integer))
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(311, 517)
        Me.ControlBox = False
        Me.Controls.Add(Me.cmdCancel)
        Me.Controls.Add(Me.cmdDC9)
        Me.Controls.Add(Me.cmdDC8)
        Me.Controls.Add(Me.cmdDC7)
        Me.Controls.Add(Me.cmdDC6)
        Me.Controls.Add(Me.cmdDC5)
        Me.Controls.Add(Me.cmdDC4)
        Me.Controls.Add(Me.cmdDC3)
        Me.Controls.Add(Me.cmdDC2)
        Me.Controls.Add(Me.cmdDC1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow
        Me.Name = "CustomListDesigner"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents cmdDC1 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDC2 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDC3 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDC4 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDC5 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDC6 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDC7 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDC8 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDC9 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdCancel As Infragistics.Win.Misc.UltraButton
End Class
