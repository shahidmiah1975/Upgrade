﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ucDishCascadeMenu
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim Appearance1 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance2 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ucDishCascadeMenu))
        Dim Appearance3 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Me.cmdDC1 = New Infragistics.Win.Misc.UltraButton()
        Me.SuspendLayout()
        '
        'cmdDC1
        '
        Appearance1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Appearance1.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(55, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(15, Byte), Integer))
        Appearance1.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance1.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance1.BorderColor = System.Drawing.Color.Khaki
        Appearance1.BorderColor2 = System.Drawing.Color.Maroon
        Appearance1.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance1.ForeColor = System.Drawing.Color.White
        Appearance1.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance1.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance1.TextVAlignAsString = "Middle"
        Me.cmdDC1.Appearance = Appearance1
        Me.cmdDC1.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdDC1.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance2.BackColor = System.Drawing.Color.DarkOrange
        Appearance2.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance2.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance2.BorderColor = System.Drawing.Color.Transparent
        Appearance2.ForeColor = System.Drawing.Color.Gold
        Appearance2.ImageBackground = CType(resources.GetObject("Appearance2.ImageBackground"), System.Drawing.Image)
        Me.cmdDC1.HotTrackAppearance = Appearance2
        Me.cmdDC1.ImageSize = New System.Drawing.Size(40, 40)
        Me.cmdDC1.Location = New System.Drawing.Point(0, 0)
        Me.cmdDC1.Name = "cmdDC1"
        Appearance3.BackColor = System.Drawing.Color.OrangeRed
        Appearance3.BackColor2 = System.Drawing.Color.Tomato
        Appearance3.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance3.BorderColor = System.Drawing.Color.Transparent
        Appearance3.ForeColor = System.Drawing.Color.Gold
        Appearance3.ImageBackground = CType(resources.GetObject("Appearance3.ImageBackground"), System.Drawing.Image)
        Me.cmdDC1.PressedAppearance = Appearance3
        Me.cmdDC1.ShowFocusRect = False
        Me.cmdDC1.ShowOutline = False
        Me.cmdDC1.Size = New System.Drawing.Size(265, 40)
        Me.cmdDC1.TabIndex = 539
        Me.cmdDC1.Tag = ""
        Me.cmdDC1.UseAppStyling = False
        Me.cmdDC1.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDC1.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDC1.UseMnemonic = False
        Me.cmdDC1.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdDC1.Visible = False
        '
        'ucDishCascadeMenu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.cmdDC1)
        Me.Name = "ucDishCascadeMenu"
        Me.Size = New System.Drawing.Size(265, 326)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents cmdDC1 As Infragistics.Win.Misc.UltraButton
End Class
