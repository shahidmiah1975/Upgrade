﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FullKeyboard
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim Appearance1 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance2 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FullKeyboard))
        Dim Appearance3 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance4 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance5 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance6 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance7 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance8 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance9 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance10 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance11 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance12 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance13 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance14 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance15 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance16 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance17 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance18 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance19 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance20 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance21 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance22 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance23 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance24 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance25 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance26 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance27 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance28 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance29 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance30 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance31 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance32 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance33 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance34 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance35 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance36 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance37 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance38 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance39 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance40 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance41 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance42 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance43 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance44 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance45 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance46 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance47 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance48 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance49 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance50 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance51 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance52 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance53 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance54 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance55 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance56 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance57 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance58 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance59 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance60 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance61 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance62 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance63 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance64 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance65 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance66 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance67 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance68 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance69 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance70 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance71 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance72 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance73 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance74 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance75 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance76 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance77 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance78 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance79 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance80 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance81 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance82 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance83 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance84 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance85 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance86 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance87 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance88 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance89 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance90 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance91 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance92 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance93 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance94 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance95 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance96 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance97 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance98 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance99 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance100 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance101 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance102 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance103 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance104 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance105 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance106 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance107 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance108 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance109 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance110 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance111 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance112 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance113 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance114 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance115 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance116 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance117 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance118 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance119 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance120 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance121 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance122 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance123 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance124 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance125 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance126 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance127 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance128 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance129 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance130 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance131 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance132 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance133 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance134 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance135 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance136 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance137 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance138 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance139 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance140 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance141 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance142 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance143 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance144 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance145 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance146 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance147 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance148 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance149 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance150 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance151 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance152 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance153 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance154 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance155 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance156 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance157 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance158 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance159 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance160 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance161 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance162 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance163 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance164 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance165 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance166 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance167 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance168 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance169 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance170 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance171 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance172 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance173 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance174 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance175 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance176 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance177 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance178 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance179 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Me.upnlKeyboard = New Infragistics.Win.Misc.UltraPanel()
        Me.picShiftR = New System.Windows.Forms.PictureBox()
        Me.picShiftL = New System.Windows.Forms.PictureBox()
        Me.picCaps = New System.Windows.Forms.PictureBox()
        Me.ubtnArrowD = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnArrowU = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnArrowR = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnArrowL = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnShiftR = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnSpChar6 = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnSpChar9 = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnShiftL = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnCase = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnTab = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnSpChar3 = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnSpChar2 = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnSpChar1 = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnEsc = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnSpace = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnSpChar7 = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnSpChar5 = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnSpChar4 = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnUseless = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnBkSp = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnSpChar11 = New Infragistics.Win.Misc.UltraButton()
        Me.lblEntryBox = New Infragistics.Win.Misc.UltraLabel()
        Me.ubtnClear = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnEnter = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnNum2 = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnNum3 = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnNum4 = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnNum5 = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnNum6 = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnNum7 = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnNum8 = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnNum9 = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnNum0 = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnNum1 = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnX = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnC = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnV = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnB = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnN = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnM = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnZ = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnS = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnD = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnF = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnG = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnH = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnJ = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnK = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnL = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnA = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnW = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnE = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnR = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnT = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnY = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnU = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnI = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnO = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnP = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnQ = New Infragistics.Win.Misc.UltraButton()
        Me.upnlKeyboard.ClientArea.SuspendLayout()
        Me.upnlKeyboard.SuspendLayout()
        CType(Me.picShiftR, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picShiftL, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picCaps, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'upnlKeyboard
        '
        Appearance1.BackColor = System.Drawing.Color.FromArgb(CType(CType(16, Byte), Integer), CType(CType(105, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.upnlKeyboard.Appearance = Appearance1
        Me.upnlKeyboard.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        '
        'upnlKeyboard.ClientArea
        '
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.picShiftR)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.picShiftL)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.picCaps)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnArrowD)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnArrowU)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnArrowR)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnArrowL)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnShiftR)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnSpChar6)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnSpChar9)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnShiftL)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnCase)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnTab)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnSpChar3)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnSpChar2)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnSpChar1)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnEsc)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnSpace)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnSpChar7)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnSpChar5)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnSpChar4)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnUseless)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnBkSp)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnSpChar11)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.lblEntryBox)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnClear)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnEnter)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnNum2)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnNum3)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnNum4)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnNum5)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnNum6)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnNum7)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnNum8)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnNum9)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnNum0)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnNum1)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnX)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnC)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnV)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnB)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnN)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnM)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnZ)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnS)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnD)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnF)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnG)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnH)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnJ)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnK)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnL)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnA)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnW)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnE)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnR)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnT)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnY)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnU)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnI)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnO)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnP)
        Me.upnlKeyboard.ClientArea.Controls.Add(Me.ubtnQ)
        Me.upnlKeyboard.ForeColor = System.Drawing.Color.White
        Me.upnlKeyboard.Location = New System.Drawing.Point(2, 2)
        Me.upnlKeyboard.Name = "upnlKeyboard"
        Me.upnlKeyboard.Size = New System.Drawing.Size(949, 371)
        Me.upnlKeyboard.TabIndex = 621
        '
        'picShiftR
        '
        Me.picShiftR.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.picShiftR.Location = New System.Drawing.Point(907, 264)
        Me.picShiftR.Name = "picShiftR"
        Me.picShiftR.Size = New System.Drawing.Size(19, 18)
        Me.picShiftR.TabIndex = 664
        Me.picShiftR.TabStop = False
        Me.picShiftR.Visible = False
        '
        'picShiftL
        '
        Me.picShiftL.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.picShiftL.Location = New System.Drawing.Point(11, 264)
        Me.picShiftL.Name = "picShiftL"
        Me.picShiftL.Size = New System.Drawing.Size(19, 18)
        Me.picShiftL.TabIndex = 663
        Me.picShiftL.TabStop = False
        Me.picShiftL.Visible = False
        '
        'picCaps
        '
        Me.picCaps.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.picCaps.Location = New System.Drawing.Point(11, 204)
        Me.picCaps.Name = "picCaps"
        Me.picCaps.Size = New System.Drawing.Size(19, 18)
        Me.picCaps.TabIndex = 662
        Me.picCaps.TabStop = False
        Me.picCaps.Visible = False
        '
        'ubtnArrowD
        '
        Appearance2.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance2.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance2.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance2.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance2.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance2.BorderColor2 = System.Drawing.Color.Maroon
        Appearance2.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance2.ForeColor = System.Drawing.Color.White
        Appearance2.Image = CType(resources.GetObject("Appearance2.Image"), Object)
        Appearance2.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance2.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance2.TextVAlignAsString = "Middle"
        Me.ubtnArrowD.Appearance = Appearance2
        Me.ubtnArrowD.Font = New System.Drawing.Font("Calibri", 20.0!)
        Appearance3.BackColor = System.Drawing.Color.DarkOrange
        Appearance3.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance3.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance3.ForeColor = System.Drawing.Color.Black
        Me.ubtnArrowD.HotTrackAppearance = Appearance3
        Me.ubtnArrowD.ImageSize = New System.Drawing.Size(16, 26)
        Me.ubtnArrowD.Location = New System.Drawing.Point(884, 306)
        Me.ubtnArrowD.Name = "ubtnArrowD"
        Appearance4.BackColor = System.Drawing.Color.OrangeRed
        Appearance4.BackColor2 = System.Drawing.Color.Tomato
        Appearance4.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnArrowD.PressedAppearance = Appearance4
        Me.ubtnArrowD.ShowFocusRect = False
        Me.ubtnArrowD.ShowOutline = False
        Me.ubtnArrowD.Size = New System.Drawing.Size(60, 60)
        Me.ubtnArrowD.TabIndex = 59
        Me.ubtnArrowD.Tag = ""
        Me.ubtnArrowD.UseAppStyling = False
        Me.ubtnArrowD.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnArrowD.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnArrowD.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnArrowU
        '
        Appearance5.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance5.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance5.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance5.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance5.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance5.BorderColor2 = System.Drawing.Color.Maroon
        Appearance5.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance5.ForeColor = System.Drawing.Color.White
        Appearance5.Image = CType(resources.GetObject("Appearance5.Image"), Object)
        Appearance5.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance5.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance5.TextVAlignAsString = "Middle"
        Me.ubtnArrowU.Appearance = Appearance5
        Me.ubtnArrowU.Font = New System.Drawing.Font("Calibri", 20.0!)
        Appearance6.BackColor = System.Drawing.Color.DarkOrange
        Appearance6.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance6.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance6.ForeColor = System.Drawing.Color.Black
        Me.ubtnArrowU.HotTrackAppearance = Appearance6
        Me.ubtnArrowU.ImageSize = New System.Drawing.Size(16, 26)
        Me.ubtnArrowU.Location = New System.Drawing.Point(823, 306)
        Me.ubtnArrowU.Name = "ubtnArrowU"
        Appearance7.BackColor = System.Drawing.Color.OrangeRed
        Appearance7.BackColor2 = System.Drawing.Color.Tomato
        Appearance7.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnArrowU.PressedAppearance = Appearance7
        Me.ubtnArrowU.ShowFocusRect = False
        Me.ubtnArrowU.ShowOutline = False
        Me.ubtnArrowU.Size = New System.Drawing.Size(60, 60)
        Me.ubtnArrowU.TabIndex = 58
        Me.ubtnArrowU.Tag = ""
        Me.ubtnArrowU.UseAppStyling = False
        Me.ubtnArrowU.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnArrowU.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnArrowU.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnArrowR
        '
        Appearance8.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance8.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance8.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance8.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance8.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance8.BorderColor2 = System.Drawing.Color.Maroon
        Appearance8.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance8.ForeColor = System.Drawing.Color.White
        Appearance8.Image = CType(resources.GetObject("Appearance8.Image"), Object)
        Appearance8.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance8.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance8.TextVAlignAsString = "Middle"
        Me.ubtnArrowR.Appearance = Appearance8
        Me.ubtnArrowR.Font = New System.Drawing.Font("Calibri", 20.0!)
        Appearance9.BackColor = System.Drawing.Color.DarkOrange
        Appearance9.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance9.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance9.ForeColor = System.Drawing.Color.Black
        Me.ubtnArrowR.HotTrackAppearance = Appearance9
        Me.ubtnArrowR.ImageSize = New System.Drawing.Size(26, 16)
        Me.ubtnArrowR.Location = New System.Drawing.Point(762, 306)
        Me.ubtnArrowR.Name = "ubtnArrowR"
        Appearance10.BackColor = System.Drawing.Color.OrangeRed
        Appearance10.BackColor2 = System.Drawing.Color.Tomato
        Appearance10.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnArrowR.PressedAppearance = Appearance10
        Me.ubtnArrowR.ShowFocusRect = False
        Me.ubtnArrowR.ShowOutline = False
        Me.ubtnArrowR.Size = New System.Drawing.Size(60, 60)
        Me.ubtnArrowR.TabIndex = 57
        Me.ubtnArrowR.Tag = ""
        Me.ubtnArrowR.UseAppStyling = False
        Me.ubtnArrowR.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnArrowR.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnArrowR.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnArrowL
        '
        Appearance11.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance11.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance11.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance11.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance11.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance11.BorderColor2 = System.Drawing.Color.Maroon
        Appearance11.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance11.ForeColor = System.Drawing.Color.White
        Appearance11.Image = CType(resources.GetObject("Appearance11.Image"), Object)
        Appearance11.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance11.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance11.TextVAlignAsString = "Middle"
        Me.ubtnArrowL.Appearance = Appearance11
        Me.ubtnArrowL.Font = New System.Drawing.Font("Calibri", 20.0!)
        Appearance12.BackColor = System.Drawing.Color.DarkOrange
        Appearance12.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance12.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance12.ForeColor = System.Drawing.Color.Black
        Me.ubtnArrowL.HotTrackAppearance = Appearance12
        Me.ubtnArrowL.ImageSize = New System.Drawing.Size(26, 16)
        Me.ubtnArrowL.Location = New System.Drawing.Point(701, 306)
        Me.ubtnArrowL.Name = "ubtnArrowL"
        Appearance13.BackColor = System.Drawing.Color.OrangeRed
        Appearance13.BackColor2 = System.Drawing.Color.Tomato
        Appearance13.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnArrowL.PressedAppearance = Appearance13
        Me.ubtnArrowL.ShowFocusRect = False
        Me.ubtnArrowL.ShowOutline = False
        Me.ubtnArrowL.Size = New System.Drawing.Size(60, 60)
        Me.ubtnArrowL.TabIndex = 56
        Me.ubtnArrowL.Tag = ""
        Me.ubtnArrowL.UseAppStyling = False
        Me.ubtnArrowL.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnArrowL.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnArrowL.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnShiftR
        '
        Appearance14.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance14.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance14.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance14.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance14.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance14.BorderColor2 = System.Drawing.Color.Maroon
        Appearance14.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance14.ForeColor = System.Drawing.Color.White
        Appearance14.TextVAlignAsString = "Middle"
        Me.ubtnShiftR.Appearance = Appearance14
        Me.ubtnShiftR.Font = New System.Drawing.Font("Calibri", 20.0!)
        Appearance15.BackColor = System.Drawing.Color.DarkOrange
        Appearance15.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance15.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance15.ForeColor = System.Drawing.Color.Black
        Me.ubtnShiftR.HotTrackAppearance = Appearance15
        Me.ubtnShiftR.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnShiftR.Location = New System.Drawing.Point(794, 245)
        Me.ubtnShiftR.Name = "ubtnShiftR"
        Appearance16.BackColor = System.Drawing.Color.OrangeRed
        Appearance16.BackColor2 = System.Drawing.Color.Tomato
        Appearance16.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnShiftR.PressedAppearance = Appearance16
        Me.ubtnShiftR.ShowFocusRect = False
        Me.ubtnShiftR.ShowOutline = False
        Me.ubtnShiftR.Size = New System.Drawing.Size(150, 60)
        Me.ubtnShiftR.TabIndex = 60
        Me.ubtnShiftR.Tag = ""
        Me.ubtnShiftR.Text = "Shift"
        Me.ubtnShiftR.UseAppStyling = False
        Me.ubtnShiftR.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnShiftR.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnShiftR.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnSpChar6
        '
        Appearance17.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance17.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance17.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance17.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance17.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance17.BorderColor2 = System.Drawing.Color.Maroon
        Appearance17.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance17.ForeColor = System.Drawing.Color.White
        Appearance17.TextVAlignAsString = "Middle"
        Me.ubtnSpChar6.Appearance = Appearance17
        Me.ubtnSpChar6.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance18.BackColor = System.Drawing.Color.DarkOrange
        Appearance18.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance18.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance18.ForeColor = System.Drawing.Color.Black
        Me.ubtnSpChar6.HotTrackAppearance = Appearance18
        Me.ubtnSpChar6.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnSpChar6.Location = New System.Drawing.Point(762, 62)
        Me.ubtnSpChar6.Name = "ubtnSpChar6"
        Appearance19.BackColor = System.Drawing.Color.OrangeRed
        Appearance19.BackColor2 = System.Drawing.Color.Tomato
        Appearance19.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnSpChar6.PressedAppearance = Appearance19
        Me.ubtnSpChar6.ShowFocusRect = False
        Me.ubtnSpChar6.ShowOutline = False
        Me.ubtnSpChar6.Size = New System.Drawing.Size(60, 60)
        Me.ubtnSpChar6.TabIndex = 12
        Me.ubtnSpChar6.Tag = "+"
        Me.ubtnSpChar6.Text = "="
        Me.ubtnSpChar6.UseAppStyling = False
        Me.ubtnSpChar6.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnSpChar6.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnSpChar6.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnSpChar9
        '
        Appearance20.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance20.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance20.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance20.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance20.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance20.BorderColor2 = System.Drawing.Color.Maroon
        Appearance20.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance20.ForeColor = System.Drawing.Color.White
        Appearance20.TextVAlignAsString = "Middle"
        Me.ubtnSpChar9.Appearance = Appearance20
        Me.ubtnSpChar9.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance21.BackColor = System.Drawing.Color.DarkOrange
        Appearance21.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance21.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance21.ForeColor = System.Drawing.Color.Black
        Me.ubtnSpChar9.HotTrackAppearance = Appearance21
        Me.ubtnSpChar9.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnSpChar9.Location = New System.Drawing.Point(701, 62)
        Me.ubtnSpChar9.Name = "ubtnSpChar9"
        Appearance22.BackColor = System.Drawing.Color.OrangeRed
        Appearance22.BackColor2 = System.Drawing.Color.Tomato
        Appearance22.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnSpChar9.PressedAppearance = Appearance22
        Me.ubtnSpChar9.ShowFocusRect = False
        Me.ubtnSpChar9.ShowOutline = False
        Me.ubtnSpChar9.Size = New System.Drawing.Size(60, 60)
        Me.ubtnSpChar9.TabIndex = 11
        Me.ubtnSpChar9.Tag = "_"
        Me.ubtnSpChar9.Text = "-"
        Me.ubtnSpChar9.UseAppStyling = False
        Me.ubtnSpChar9.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnSpChar9.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnSpChar9.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnShiftL
        '
        Appearance23.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance23.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance23.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance23.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance23.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance23.BorderColor2 = System.Drawing.Color.Maroon
        Appearance23.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance23.ForeColor = System.Drawing.Color.White
        Appearance23.TextVAlignAsString = "Middle"
        Me.ubtnShiftL.Appearance = Appearance23
        Me.ubtnShiftL.Font = New System.Drawing.Font("Calibri", 20.0!)
        Appearance24.BackColor = System.Drawing.Color.DarkOrange
        Appearance24.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance24.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance24.ForeColor = System.Drawing.Color.Black
        Me.ubtnShiftL.HotTrackAppearance = Appearance24
        Me.ubtnShiftL.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnShiftL.Location = New System.Drawing.Point(1, 245)
        Me.ubtnShiftL.Name = "ubtnShiftL"
        Appearance25.BackColor = System.Drawing.Color.OrangeRed
        Appearance25.BackColor2 = System.Drawing.Color.Tomato
        Appearance25.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnShiftL.PressedAppearance = Appearance25
        Me.ubtnShiftL.ShowFocusRect = False
        Me.ubtnShiftL.ShowOutline = False
        Me.ubtnShiftL.Size = New System.Drawing.Size(121, 60)
        Me.ubtnShiftL.TabIndex = 53
        Me.ubtnShiftL.Tag = ""
        Me.ubtnShiftL.Text = "Shift"
        Me.ubtnShiftL.UseAppStyling = False
        Me.ubtnShiftL.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnShiftL.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnShiftL.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnCase
        '
        Appearance26.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance26.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance26.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance26.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance26.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance26.BorderColor2 = System.Drawing.Color.Maroon
        Appearance26.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance26.ForeColor = System.Drawing.Color.White
        Appearance26.TextVAlignAsString = "Middle"
        Me.ubtnCase.Appearance = Appearance26
        Me.ubtnCase.Font = New System.Drawing.Font("Calibri", 20.0!)
        Appearance27.BackColor = System.Drawing.Color.DarkOrange
        Appearance27.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance27.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance27.ForeColor = System.Drawing.Color.Black
        Me.ubtnCase.HotTrackAppearance = Appearance27
        Me.ubtnCase.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnCase.Location = New System.Drawing.Point(1, 184)
        Me.ubtnCase.Name = "ubtnCase"
        Appearance28.BackColor = System.Drawing.Color.OrangeRed
        Appearance28.BackColor2 = System.Drawing.Color.Tomato
        Appearance28.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnCase.PressedAppearance = Appearance28
        Me.ubtnCase.ShowFocusRect = False
        Me.ubtnCase.ShowOutline = False
        Me.ubtnCase.Size = New System.Drawing.Size(150, 60)
        Me.ubtnCase.TabIndex = 52
        Me.ubtnCase.Tag = "Case L"
        Me.ubtnCase.Text = "Caps"
        Me.ubtnCase.UseAppStyling = False
        Me.ubtnCase.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnCase.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnCase.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnTab
        '
        Appearance29.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance29.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance29.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance29.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance29.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance29.BorderColor2 = System.Drawing.Color.Maroon
        Appearance29.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance29.ForeColor = System.Drawing.Color.White
        Appearance29.TextVAlignAsString = "Middle"
        Me.ubtnTab.Appearance = Appearance29
        Me.ubtnTab.Font = New System.Drawing.Font("Calibri", 20.0!)
        Appearance30.BackColor = System.Drawing.Color.DarkOrange
        Appearance30.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance30.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance30.ForeColor = System.Drawing.Color.Black
        Me.ubtnTab.HotTrackAppearance = Appearance30
        Me.ubtnTab.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnTab.Location = New System.Drawing.Point(1, 123)
        Me.ubtnTab.Name = "ubtnTab"
        Appearance31.BackColor = System.Drawing.Color.OrangeRed
        Appearance31.BackColor2 = System.Drawing.Color.Tomato
        Appearance31.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnTab.PressedAppearance = Appearance31
        Me.ubtnTab.ShowFocusRect = False
        Me.ubtnTab.ShowOutline = False
        Me.ubtnTab.Size = New System.Drawing.Size(121, 60)
        Me.ubtnTab.TabIndex = 51
        Me.ubtnTab.Tag = ""
        Me.ubtnTab.Text = "Tab"
        Me.ubtnTab.UseAppStyling = False
        Me.ubtnTab.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnTab.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnTab.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnSpChar3
        '
        Appearance32.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance32.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance32.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance32.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance32.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance32.BorderColor2 = System.Drawing.Color.Maroon
        Appearance32.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance32.ForeColor = System.Drawing.Color.White
        Appearance32.TextVAlignAsString = "Middle"
        Me.ubtnSpChar3.Appearance = Appearance32
        Me.ubtnSpChar3.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance33.BackColor = System.Drawing.Color.DarkOrange
        Appearance33.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance33.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance33.ForeColor = System.Drawing.Color.Black
        Me.ubtnSpChar3.HotTrackAppearance = Appearance33
        Me.ubtnSpChar3.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnSpChar3.Location = New System.Drawing.Point(733, 245)
        Me.ubtnSpChar3.Name = "ubtnSpChar3"
        Appearance34.BackColor = System.Drawing.Color.OrangeRed
        Appearance34.BackColor2 = System.Drawing.Color.Tomato
        Appearance34.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnSpChar3.PressedAppearance = Appearance34
        Me.ubtnSpChar3.ShowFocusRect = False
        Me.ubtnSpChar3.ShowOutline = False
        Me.ubtnSpChar3.Size = New System.Drawing.Size(60, 60)
        Me.ubtnSpChar3.TabIndex = 45
        Me.ubtnSpChar3.Tag = "?"
        Me.ubtnSpChar3.Text = "/"
        Me.ubtnSpChar3.UseAppStyling = False
        Me.ubtnSpChar3.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnSpChar3.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnSpChar3.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnSpChar2
        '
        Appearance35.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance35.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance35.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance35.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance35.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance35.BorderColor2 = System.Drawing.Color.Maroon
        Appearance35.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance35.ForeColor = System.Drawing.Color.White
        Appearance35.TextVAlignAsString = "Middle"
        Me.ubtnSpChar2.Appearance = Appearance35
        Me.ubtnSpChar2.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance36.BackColor = System.Drawing.Color.DarkOrange
        Appearance36.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance36.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance36.ForeColor = System.Drawing.Color.Black
        Me.ubtnSpChar2.HotTrackAppearance = Appearance36
        Me.ubtnSpChar2.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnSpChar2.Location = New System.Drawing.Point(672, 245)
        Me.ubtnSpChar2.Name = "ubtnSpChar2"
        Appearance37.BackColor = System.Drawing.Color.OrangeRed
        Appearance37.BackColor2 = System.Drawing.Color.Tomato
        Appearance37.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnSpChar2.PressedAppearance = Appearance37
        Me.ubtnSpChar2.ShowFocusRect = False
        Me.ubtnSpChar2.ShowOutline = False
        Me.ubtnSpChar2.Size = New System.Drawing.Size(60, 60)
        Me.ubtnSpChar2.TabIndex = 44
        Me.ubtnSpChar2.Tag = ">"
        Me.ubtnSpChar2.Text = "."
        Me.ubtnSpChar2.UseAppStyling = False
        Me.ubtnSpChar2.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnSpChar2.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnSpChar2.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnSpChar1
        '
        Appearance38.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance38.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance38.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance38.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance38.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance38.BorderColor2 = System.Drawing.Color.Maroon
        Appearance38.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance38.ForeColor = System.Drawing.Color.White
        Appearance38.TextVAlignAsString = "Middle"
        Me.ubtnSpChar1.Appearance = Appearance38
        Me.ubtnSpChar1.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance39.BackColor = System.Drawing.Color.DarkOrange
        Appearance39.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance39.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance39.ForeColor = System.Drawing.Color.Black
        Me.ubtnSpChar1.HotTrackAppearance = Appearance39
        Me.ubtnSpChar1.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnSpChar1.Location = New System.Drawing.Point(611, 245)
        Me.ubtnSpChar1.Name = "ubtnSpChar1"
        Appearance40.BackColor = System.Drawing.Color.OrangeRed
        Appearance40.BackColor2 = System.Drawing.Color.Tomato
        Appearance40.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnSpChar1.PressedAppearance = Appearance40
        Me.ubtnSpChar1.ShowFocusRect = False
        Me.ubtnSpChar1.ShowOutline = False
        Me.ubtnSpChar1.Size = New System.Drawing.Size(60, 60)
        Me.ubtnSpChar1.TabIndex = 43
        Me.ubtnSpChar1.Tag = "<"
        Me.ubtnSpChar1.Text = ","
        Me.ubtnSpChar1.UseAppStyling = False
        Me.ubtnSpChar1.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnSpChar1.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnSpChar1.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnEsc
        '
        Appearance41.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance41.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance41.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance41.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance41.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance41.BorderColor2 = System.Drawing.Color.Maroon
        Appearance41.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance41.ForeColor = System.Drawing.Color.White
        Appearance41.TextVAlignAsString = "Middle"
        Me.ubtnEsc.Appearance = Appearance41
        Me.ubtnEsc.Font = New System.Drawing.Font("Calibri", 20.0!)
        Appearance42.BackColor = System.Drawing.Color.DarkOrange
        Appearance42.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance42.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance42.ForeColor = System.Drawing.Color.Black
        Me.ubtnEsc.HotTrackAppearance = Appearance42
        Me.ubtnEsc.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnEsc.Location = New System.Drawing.Point(1, 62)
        Me.ubtnEsc.Name = "ubtnEsc"
        Appearance43.BackColor = System.Drawing.Color.OrangeRed
        Appearance43.BackColor2 = System.Drawing.Color.Tomato
        Appearance43.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnEsc.PressedAppearance = Appearance43
        Me.ubtnEsc.ShowFocusRect = False
        Me.ubtnEsc.ShowOutline = False
        Me.ubtnEsc.Size = New System.Drawing.Size(89, 60)
        Me.ubtnEsc.TabIndex = 50
        Me.ubtnEsc.Tag = ""
        Me.ubtnEsc.Text = "Esc"
        Me.ubtnEsc.UseAppStyling = False
        Me.ubtnEsc.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnEsc.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnEsc.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnSpace
        '
        Appearance44.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance44.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance44.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance44.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance44.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance44.BorderColor2 = System.Drawing.Color.Maroon
        Appearance44.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance44.ForeColor = System.Drawing.Color.White
        Appearance44.TextVAlignAsString = "Middle"
        Me.ubtnSpace.Appearance = Appearance44
        Me.ubtnSpace.Font = New System.Drawing.Font("Calibri", 20.0!)
        Appearance45.BackColor = System.Drawing.Color.DarkOrange
        Appearance45.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance45.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance45.ForeColor = System.Drawing.Color.Black
        Me.ubtnSpace.HotTrackAppearance = Appearance45
        Me.ubtnSpace.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnSpace.Location = New System.Drawing.Point(185, 306)
        Me.ubtnSpace.Name = "ubtnSpace"
        Appearance46.BackColor = System.Drawing.Color.OrangeRed
        Appearance46.BackColor2 = System.Drawing.Color.Tomato
        Appearance46.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnSpace.PressedAppearance = Appearance46
        Me.ubtnSpace.ShowFocusRect = False
        Me.ubtnSpace.ShowOutline = False
        Me.ubtnSpace.Size = New System.Drawing.Size(515, 60)
        Me.ubtnSpace.TabIndex = 55
        Me.ubtnSpace.Tag = ""
        Me.ubtnSpace.Text = "Space"
        Me.ubtnSpace.UseAppStyling = False
        Me.ubtnSpace.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnSpace.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnSpace.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnSpChar7
        '
        Appearance47.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance47.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance47.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance47.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance47.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance47.BorderColor2 = System.Drawing.Color.Maroon
        Appearance47.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance47.ForeColor = System.Drawing.Color.White
        Appearance47.TextVAlignAsString = "Middle"
        Me.ubtnSpChar7.Appearance = Appearance47
        Me.ubtnSpChar7.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance48.BackColor = System.Drawing.Color.DarkOrange
        Appearance48.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance48.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance48.ForeColor = System.Drawing.Color.Black
        Me.ubtnSpChar7.HotTrackAppearance = Appearance48
        Me.ubtnSpChar7.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnSpChar7.Location = New System.Drawing.Point(733, 123)
        Me.ubtnSpChar7.Name = "ubtnSpChar7"
        Appearance49.BackColor = System.Drawing.Color.OrangeRed
        Appearance49.BackColor2 = System.Drawing.Color.Tomato
        Appearance49.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnSpChar7.PressedAppearance = Appearance49
        Me.ubtnSpChar7.ShowFocusRect = False
        Me.ubtnSpChar7.ShowOutline = False
        Me.ubtnSpChar7.Size = New System.Drawing.Size(60, 60)
        Me.ubtnSpChar7.TabIndex = 23
        Me.ubtnSpChar7.Tag = ""
        Me.ubtnSpChar7.Text = "#"
        Me.ubtnSpChar7.UseAppStyling = False
        Me.ubtnSpChar7.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnSpChar7.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnSpChar7.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnSpChar5
        '
        Appearance50.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance50.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance50.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance50.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance50.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance50.BorderColor2 = System.Drawing.Color.Maroon
        Appearance50.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance50.ForeColor = System.Drawing.Color.White
        Appearance50.TextVAlignAsString = "Middle"
        Me.ubtnSpChar5.Appearance = Appearance50
        Me.ubtnSpChar5.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance51.BackColor = System.Drawing.Color.DarkOrange
        Appearance51.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance51.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance51.ForeColor = System.Drawing.Color.Black
        Me.ubtnSpChar5.HotTrackAppearance = Appearance51
        Me.ubtnSpChar5.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnSpChar5.Location = New System.Drawing.Point(762, 184)
        Me.ubtnSpChar5.Name = "ubtnSpChar5"
        Appearance52.BackColor = System.Drawing.Color.OrangeRed
        Appearance52.BackColor2 = System.Drawing.Color.Tomato
        Appearance52.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnSpChar5.PressedAppearance = Appearance52
        Me.ubtnSpChar5.ShowFocusRect = False
        Me.ubtnSpChar5.ShowOutline = False
        Me.ubtnSpChar5.Size = New System.Drawing.Size(60, 60)
        Me.ubtnSpChar5.TabIndex = 34
        Me.ubtnSpChar5.Tag = "@"
        Me.ubtnSpChar5.Text = "'"
        Me.ubtnSpChar5.UseAppStyling = False
        Me.ubtnSpChar5.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnSpChar5.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnSpChar5.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnSpChar4
        '
        Appearance53.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance53.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance53.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance53.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance53.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance53.BorderColor2 = System.Drawing.Color.Maroon
        Appearance53.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance53.ForeColor = System.Drawing.Color.White
        Appearance53.TextVAlignAsString = "Middle"
        Me.ubtnSpChar4.Appearance = Appearance53
        Me.ubtnSpChar4.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance54.BackColor = System.Drawing.Color.DarkOrange
        Appearance54.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance54.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance54.ForeColor = System.Drawing.Color.Black
        Me.ubtnSpChar4.HotTrackAppearance = Appearance54
        Me.ubtnSpChar4.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnSpChar4.Location = New System.Drawing.Point(701, 184)
        Me.ubtnSpChar4.Name = "ubtnSpChar4"
        Appearance55.BackColor = System.Drawing.Color.OrangeRed
        Appearance55.BackColor2 = System.Drawing.Color.Tomato
        Appearance55.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnSpChar4.PressedAppearance = Appearance55
        Me.ubtnSpChar4.ShowFocusRect = False
        Me.ubtnSpChar4.ShowOutline = False
        Me.ubtnSpChar4.Size = New System.Drawing.Size(60, 60)
        Me.ubtnSpChar4.TabIndex = 33
        Me.ubtnSpChar4.Tag = ":"
        Me.ubtnSpChar4.Text = ";"
        Me.ubtnSpChar4.UseAppStyling = False
        Me.ubtnSpChar4.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnSpChar4.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnSpChar4.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnUseless
        '
        Appearance56.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance56.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance56.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance56.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance56.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance56.BorderColor2 = System.Drawing.Color.Maroon
        Appearance56.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance56.ForeColor = System.Drawing.Color.White
        Appearance56.TextVAlignAsString = "Middle"
        Me.ubtnUseless.Appearance = Appearance56
        Me.ubtnUseless.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance57.BackColor = System.Drawing.Color.DarkOrange
        Appearance57.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance57.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance57.ForeColor = System.Drawing.Color.Black
        Me.ubtnUseless.HotTrackAppearance = Appearance57
        Me.ubtnUseless.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnUseless.Location = New System.Drawing.Point(794, 123)
        Me.ubtnUseless.Name = "ubtnUseless"
        Appearance58.BackColor = System.Drawing.Color.OrangeRed
        Appearance58.BackColor2 = System.Drawing.Color.Tomato
        Appearance58.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnUseless.PressedAppearance = Appearance58
        Me.ubtnUseless.ShowFocusRect = False
        Me.ubtnUseless.ShowOutline = False
        Me.ubtnUseless.Size = New System.Drawing.Size(28, 60)
        Me.ubtnUseless.TabIndex = 661
        Me.ubtnUseless.Tag = ""
        Me.ubtnUseless.UseAppStyling = False
        Me.ubtnUseless.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnUseless.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnUseless.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnBkSp
        '
        Appearance59.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance59.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance59.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance59.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance59.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance59.BorderColor2 = System.Drawing.Color.Maroon
        Appearance59.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance59.ForeColor = System.Drawing.Color.White
        Appearance59.TextVAlignAsString = "Middle"
        Me.ubtnBkSp.Appearance = Appearance59
        Me.ubtnBkSp.Font = New System.Drawing.Font("Calibri", 20.0!)
        Appearance60.BackColor = System.Drawing.Color.DarkOrange
        Appearance60.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance60.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance60.ForeColor = System.Drawing.Color.Black
        Me.ubtnBkSp.HotTrackAppearance = Appearance60
        Me.ubtnBkSp.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnBkSp.Location = New System.Drawing.Point(823, 62)
        Me.ubtnBkSp.Name = "ubtnBkSp"
        Appearance61.BackColor = System.Drawing.Color.OrangeRed
        Appearance61.BackColor2 = System.Drawing.Color.Tomato
        Appearance61.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnBkSp.PressedAppearance = Appearance61
        Me.ubtnBkSp.ShowFocusRect = False
        Me.ubtnBkSp.ShowOutline = False
        Me.ubtnBkSp.Size = New System.Drawing.Size(121, 60)
        Me.ubtnBkSp.TabIndex = 62
        Me.ubtnBkSp.Tag = ""
        Me.ubtnBkSp.Text = "BkSp"
        Me.ubtnBkSp.UseAppStyling = False
        Me.ubtnBkSp.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnBkSp.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnBkSp.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnSpChar11
        '
        Appearance62.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance62.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance62.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance62.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance62.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance62.BorderColor2 = System.Drawing.Color.Maroon
        Appearance62.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance62.ForeColor = System.Drawing.Color.White
        Appearance62.TextVAlignAsString = "Middle"
        Me.ubtnSpChar11.Appearance = Appearance62
        Me.ubtnSpChar11.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance63.BackColor = System.Drawing.Color.DarkOrange
        Appearance63.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance63.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance63.ForeColor = System.Drawing.Color.Black
        Me.ubtnSpChar11.HotTrackAppearance = Appearance63
        Me.ubtnSpChar11.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnSpChar11.Location = New System.Drawing.Point(123, 245)
        Me.ubtnSpChar11.Name = "ubtnSpChar11"
        Appearance64.BackColor = System.Drawing.Color.OrangeRed
        Appearance64.BackColor2 = System.Drawing.Color.Tomato
        Appearance64.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnSpChar11.PressedAppearance = Appearance64
        Me.ubtnSpChar11.ShowFocusRect = False
        Me.ubtnSpChar11.ShowOutline = False
        Me.ubtnSpChar11.Size = New System.Drawing.Size(60, 60)
        Me.ubtnSpChar11.TabIndex = 35
        Me.ubtnSpChar11.Tag = "|"
        Me.ubtnSpChar11.Text = "\"
        Me.ubtnSpChar11.UseAppStyling = False
        Me.ubtnSpChar11.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnSpChar11.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnSpChar11.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblEntryBox
        '
        Appearance65.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance65.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance65.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance65.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance65.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance65.ForeColor = System.Drawing.Color.White
        Appearance65.TextHAlignAsString = "Center"
        Appearance65.TextVAlignAsString = "Middle"
        Me.lblEntryBox.Appearance = Appearance65
        Me.lblEntryBox.BorderStyleInner = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.lblEntryBox.BorderStyleOuter = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.lblEntryBox.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEntryBox.InnerBorderPadding = New System.Drawing.Size(1, 1)
        Me.lblEntryBox.Location = New System.Drawing.Point(1, 3)
        Me.lblEntryBox.Name = "lblEntryBox"
        Me.lblEntryBox.Size = New System.Drawing.Size(943, 55)
        Me.lblEntryBox.TabIndex = 0
        Me.lblEntryBox.Tag = "textbox"
        Me.lblEntryBox.UseAppStyling = False
        Me.lblEntryBox.UseMnemonic = False
        '
        'ubtnClear
        '
        Appearance66.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance66.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance66.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance66.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance66.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance66.BorderColor2 = System.Drawing.Color.Maroon
        Appearance66.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance66.ForeColor = System.Drawing.Color.White
        Appearance66.TextVAlignAsString = "Middle"
        Me.ubtnClear.Appearance = Appearance66
        Me.ubtnClear.Font = New System.Drawing.Font("Calibri", 20.0!)
        Appearance67.BackColor = System.Drawing.Color.DarkOrange
        Appearance67.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance67.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance67.ForeColor = System.Drawing.Color.Black
        Me.ubtnClear.HotTrackAppearance = Appearance67
        Me.ubtnClear.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnClear.Location = New System.Drawing.Point(1, 306)
        Me.ubtnClear.Name = "ubtnClear"
        Appearance68.BackColor = System.Drawing.Color.OrangeRed
        Appearance68.BackColor2 = System.Drawing.Color.Tomato
        Appearance68.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnClear.PressedAppearance = Appearance68
        Me.ubtnClear.ShowFocusRect = False
        Me.ubtnClear.ShowOutline = False
        Me.ubtnClear.Size = New System.Drawing.Size(183, 60)
        Me.ubtnClear.TabIndex = 54
        Me.ubtnClear.Tag = ""
        Me.ubtnClear.Text = "Clear"
        Me.ubtnClear.UseAppStyling = False
        Me.ubtnClear.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnClear.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnClear.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnEnter
        '
        Appearance69.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance69.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance69.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance69.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance69.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance69.BorderColor2 = System.Drawing.Color.Maroon
        Appearance69.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance69.ForeColor = System.Drawing.Color.White
        Appearance69.TextVAlignAsString = "Middle"
        Me.ubtnEnter.Appearance = Appearance69
        Me.ubtnEnter.Font = New System.Drawing.Font("Calibri", 20.0!)
        Appearance70.BackColor = System.Drawing.Color.DarkOrange
        Appearance70.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance70.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance70.ForeColor = System.Drawing.Color.Black
        Me.ubtnEnter.HotTrackAppearance = Appearance70
        Me.ubtnEnter.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnEnter.Location = New System.Drawing.Point(823, 123)
        Me.ubtnEnter.Name = "ubtnEnter"
        Appearance71.BackColor = System.Drawing.Color.OrangeRed
        Appearance71.BackColor2 = System.Drawing.Color.Tomato
        Appearance71.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnEnter.PressedAppearance = Appearance71
        Me.ubtnEnter.ShowFocusRect = False
        Me.ubtnEnter.ShowOutline = False
        Me.ubtnEnter.Size = New System.Drawing.Size(121, 121)
        Me.ubtnEnter.TabIndex = 61
        Me.ubtnEnter.Tag = ""
        Me.ubtnEnter.Text = "Enter"
        Me.ubtnEnter.UseAppStyling = False
        Me.ubtnEnter.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnEnter.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnEnter.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnNum2
        '
        Appearance72.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance72.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance72.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance72.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance72.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance72.BorderColor2 = System.Drawing.Color.Maroon
        Appearance72.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance72.ForeColor = System.Drawing.Color.White
        Appearance72.TextVAlignAsString = "Middle"
        Me.ubtnNum2.Appearance = Appearance72
        Me.ubtnNum2.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance73.BackColor = System.Drawing.Color.DarkOrange
        Appearance73.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance73.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance73.ForeColor = System.Drawing.Color.Black
        Me.ubtnNum2.HotTrackAppearance = Appearance73
        Me.ubtnNum2.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnNum2.Location = New System.Drawing.Point(152, 62)
        Me.ubtnNum2.Name = "ubtnNum2"
        Appearance74.BackColor = System.Drawing.Color.OrangeRed
        Appearance74.BackColor2 = System.Drawing.Color.Tomato
        Appearance74.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnNum2.PressedAppearance = Appearance74
        Me.ubtnNum2.ShowFocusRect = False
        Me.ubtnNum2.ShowOutline = False
        Me.ubtnNum2.Size = New System.Drawing.Size(60, 60)
        Me.ubtnNum2.TabIndex = 2
        Me.ubtnNum2.Tag = """"
        Me.ubtnNum2.Text = "2"
        Me.ubtnNum2.UseAppStyling = False
        Me.ubtnNum2.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnNum2.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnNum2.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnNum3
        '
        Appearance75.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance75.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance75.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance75.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance75.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance75.BorderColor2 = System.Drawing.Color.Maroon
        Appearance75.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance75.ForeColor = System.Drawing.Color.White
        Appearance75.TextVAlignAsString = "Middle"
        Me.ubtnNum3.Appearance = Appearance75
        Me.ubtnNum3.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance76.BackColor = System.Drawing.Color.DarkOrange
        Appearance76.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance76.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance76.ForeColor = System.Drawing.Color.Black
        Me.ubtnNum3.HotTrackAppearance = Appearance76
        Me.ubtnNum3.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnNum3.Location = New System.Drawing.Point(213, 62)
        Me.ubtnNum3.Name = "ubtnNum3"
        Appearance77.BackColor = System.Drawing.Color.OrangeRed
        Appearance77.BackColor2 = System.Drawing.Color.Tomato
        Appearance77.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnNum3.PressedAppearance = Appearance77
        Me.ubtnNum3.ShowFocusRect = False
        Me.ubtnNum3.ShowOutline = False
        Me.ubtnNum3.Size = New System.Drawing.Size(60, 60)
        Me.ubtnNum3.TabIndex = 3
        Me.ubtnNum3.Tag = "£"
        Me.ubtnNum3.Text = "3"
        Me.ubtnNum3.UseAppStyling = False
        Me.ubtnNum3.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnNum3.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnNum3.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnNum4
        '
        Appearance78.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance78.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance78.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance78.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance78.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance78.BorderColor2 = System.Drawing.Color.Maroon
        Appearance78.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance78.ForeColor = System.Drawing.Color.White
        Appearance78.TextVAlignAsString = "Middle"
        Me.ubtnNum4.Appearance = Appearance78
        Me.ubtnNum4.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance79.BackColor = System.Drawing.Color.DarkOrange
        Appearance79.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance79.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance79.ForeColor = System.Drawing.Color.Black
        Me.ubtnNum4.HotTrackAppearance = Appearance79
        Me.ubtnNum4.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnNum4.Location = New System.Drawing.Point(274, 62)
        Me.ubtnNum4.Name = "ubtnNum4"
        Appearance80.BackColor = System.Drawing.Color.OrangeRed
        Appearance80.BackColor2 = System.Drawing.Color.Tomato
        Appearance80.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnNum4.PressedAppearance = Appearance80
        Me.ubtnNum4.ShowFocusRect = False
        Me.ubtnNum4.ShowOutline = False
        Me.ubtnNum4.Size = New System.Drawing.Size(60, 60)
        Me.ubtnNum4.TabIndex = 4
        Me.ubtnNum4.Tag = "$"
        Me.ubtnNum4.Text = "4"
        Me.ubtnNum4.UseAppStyling = False
        Me.ubtnNum4.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnNum4.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnNum4.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnNum5
        '
        Appearance81.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance81.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance81.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance81.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance81.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance81.BorderColor2 = System.Drawing.Color.Maroon
        Appearance81.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance81.ForeColor = System.Drawing.Color.White
        Appearance81.TextVAlignAsString = "Middle"
        Me.ubtnNum5.Appearance = Appearance81
        Me.ubtnNum5.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance82.BackColor = System.Drawing.Color.DarkOrange
        Appearance82.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance82.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance82.ForeColor = System.Drawing.Color.Black
        Me.ubtnNum5.HotTrackAppearance = Appearance82
        Me.ubtnNum5.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnNum5.Location = New System.Drawing.Point(335, 62)
        Me.ubtnNum5.Name = "ubtnNum5"
        Appearance83.BackColor = System.Drawing.Color.OrangeRed
        Appearance83.BackColor2 = System.Drawing.Color.Tomato
        Appearance83.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnNum5.PressedAppearance = Appearance83
        Me.ubtnNum5.ShowFocusRect = False
        Me.ubtnNum5.ShowOutline = False
        Me.ubtnNum5.Size = New System.Drawing.Size(60, 60)
        Me.ubtnNum5.TabIndex = 5
        Me.ubtnNum5.Tag = "%"
        Me.ubtnNum5.Text = "5"
        Me.ubtnNum5.UseAppStyling = False
        Me.ubtnNum5.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnNum5.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnNum5.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnNum6
        '
        Appearance84.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance84.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance84.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance84.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance84.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance84.BorderColor2 = System.Drawing.Color.Maroon
        Appearance84.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance84.ForeColor = System.Drawing.Color.White
        Appearance84.TextVAlignAsString = "Middle"
        Me.ubtnNum6.Appearance = Appearance84
        Me.ubtnNum6.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance85.BackColor = System.Drawing.Color.DarkOrange
        Appearance85.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance85.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance85.ForeColor = System.Drawing.Color.Black
        Me.ubtnNum6.HotTrackAppearance = Appearance85
        Me.ubtnNum6.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnNum6.Location = New System.Drawing.Point(396, 62)
        Me.ubtnNum6.Name = "ubtnNum6"
        Appearance86.BackColor = System.Drawing.Color.OrangeRed
        Appearance86.BackColor2 = System.Drawing.Color.Tomato
        Appearance86.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnNum6.PressedAppearance = Appearance86
        Me.ubtnNum6.ShowFocusRect = False
        Me.ubtnNum6.ShowOutline = False
        Me.ubtnNum6.Size = New System.Drawing.Size(60, 60)
        Me.ubtnNum6.TabIndex = 6
        Me.ubtnNum6.Tag = "^"
        Me.ubtnNum6.Text = "6"
        Me.ubtnNum6.UseAppStyling = False
        Me.ubtnNum6.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnNum6.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnNum6.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnNum7
        '
        Appearance87.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance87.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance87.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance87.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance87.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance87.BorderColor2 = System.Drawing.Color.Maroon
        Appearance87.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance87.ForeColor = System.Drawing.Color.White
        Appearance87.TextVAlignAsString = "Middle"
        Me.ubtnNum7.Appearance = Appearance87
        Me.ubtnNum7.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance88.BackColor = System.Drawing.Color.DarkOrange
        Appearance88.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance88.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance88.ForeColor = System.Drawing.Color.Black
        Me.ubtnNum7.HotTrackAppearance = Appearance88
        Me.ubtnNum7.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnNum7.Location = New System.Drawing.Point(457, 62)
        Me.ubtnNum7.Name = "ubtnNum7"
        Appearance89.BackColor = System.Drawing.Color.OrangeRed
        Appearance89.BackColor2 = System.Drawing.Color.Tomato
        Appearance89.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnNum7.PressedAppearance = Appearance89
        Me.ubtnNum7.ShowFocusRect = False
        Me.ubtnNum7.ShowOutline = False
        Me.ubtnNum7.Size = New System.Drawing.Size(60, 60)
        Me.ubtnNum7.TabIndex = 7
        Me.ubtnNum7.Tag = "&&"
        Me.ubtnNum7.Text = "7"
        Me.ubtnNum7.UseAppStyling = False
        Me.ubtnNum7.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnNum7.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnNum7.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnNum8
        '
        Appearance90.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance90.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance90.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance90.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance90.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance90.BorderColor2 = System.Drawing.Color.Maroon
        Appearance90.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance90.ForeColor = System.Drawing.Color.White
        Appearance90.TextVAlignAsString = "Middle"
        Me.ubtnNum8.Appearance = Appearance90
        Me.ubtnNum8.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance91.BackColor = System.Drawing.Color.DarkOrange
        Appearance91.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance91.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance91.ForeColor = System.Drawing.Color.Black
        Me.ubtnNum8.HotTrackAppearance = Appearance91
        Me.ubtnNum8.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnNum8.Location = New System.Drawing.Point(518, 62)
        Me.ubtnNum8.Name = "ubtnNum8"
        Appearance92.BackColor = System.Drawing.Color.OrangeRed
        Appearance92.BackColor2 = System.Drawing.Color.Tomato
        Appearance92.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnNum8.PressedAppearance = Appearance92
        Me.ubtnNum8.ShowFocusRect = False
        Me.ubtnNum8.ShowOutline = False
        Me.ubtnNum8.Size = New System.Drawing.Size(60, 60)
        Me.ubtnNum8.TabIndex = 8
        Me.ubtnNum8.Tag = "*"
        Me.ubtnNum8.Text = "8"
        Me.ubtnNum8.UseAppStyling = False
        Me.ubtnNum8.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnNum8.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnNum8.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnNum9
        '
        Appearance93.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance93.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance93.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance93.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance93.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance93.BorderColor2 = System.Drawing.Color.Maroon
        Appearance93.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance93.ForeColor = System.Drawing.Color.White
        Appearance93.TextVAlignAsString = "Middle"
        Me.ubtnNum9.Appearance = Appearance93
        Me.ubtnNum9.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance94.BackColor = System.Drawing.Color.DarkOrange
        Appearance94.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance94.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance94.ForeColor = System.Drawing.Color.Black
        Me.ubtnNum9.HotTrackAppearance = Appearance94
        Me.ubtnNum9.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnNum9.Location = New System.Drawing.Point(579, 62)
        Me.ubtnNum9.Name = "ubtnNum9"
        Appearance95.BackColor = System.Drawing.Color.OrangeRed
        Appearance95.BackColor2 = System.Drawing.Color.Tomato
        Appearance95.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnNum9.PressedAppearance = Appearance95
        Me.ubtnNum9.ShowFocusRect = False
        Me.ubtnNum9.ShowOutline = False
        Me.ubtnNum9.Size = New System.Drawing.Size(60, 60)
        Me.ubtnNum9.TabIndex = 9
        Me.ubtnNum9.Tag = "("
        Me.ubtnNum9.Text = "9"
        Me.ubtnNum9.UseAppStyling = False
        Me.ubtnNum9.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnNum9.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnNum9.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnNum0
        '
        Appearance96.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance96.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance96.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance96.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance96.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance96.BorderColor2 = System.Drawing.Color.Maroon
        Appearance96.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance96.ForeColor = System.Drawing.Color.White
        Appearance96.TextVAlignAsString = "Middle"
        Me.ubtnNum0.Appearance = Appearance96
        Me.ubtnNum0.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance97.BackColor = System.Drawing.Color.DarkOrange
        Appearance97.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance97.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance97.ForeColor = System.Drawing.Color.Black
        Me.ubtnNum0.HotTrackAppearance = Appearance97
        Me.ubtnNum0.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnNum0.Location = New System.Drawing.Point(640, 62)
        Me.ubtnNum0.Name = "ubtnNum0"
        Appearance98.BackColor = System.Drawing.Color.OrangeRed
        Appearance98.BackColor2 = System.Drawing.Color.Tomato
        Appearance98.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnNum0.PressedAppearance = Appearance98
        Me.ubtnNum0.ShowFocusRect = False
        Me.ubtnNum0.ShowOutline = False
        Me.ubtnNum0.Size = New System.Drawing.Size(60, 60)
        Me.ubtnNum0.TabIndex = 10
        Me.ubtnNum0.Tag = ")"
        Me.ubtnNum0.Text = "0"
        Me.ubtnNum0.UseAppStyling = False
        Me.ubtnNum0.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnNum0.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnNum0.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnNum1
        '
        Appearance99.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance99.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance99.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance99.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance99.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance99.BorderColor2 = System.Drawing.Color.Maroon
        Appearance99.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance99.ForeColor = System.Drawing.Color.White
        Appearance99.TextVAlignAsString = "Middle"
        Me.ubtnNum1.Appearance = Appearance99
        Me.ubtnNum1.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance100.BackColor = System.Drawing.Color.DarkOrange
        Appearance100.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance100.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance100.ForeColor = System.Drawing.Color.Black
        Me.ubtnNum1.HotTrackAppearance = Appearance100
        Me.ubtnNum1.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnNum1.Location = New System.Drawing.Point(91, 62)
        Me.ubtnNum1.Name = "ubtnNum1"
        Appearance101.BackColor = System.Drawing.Color.OrangeRed
        Appearance101.BackColor2 = System.Drawing.Color.Tomato
        Appearance101.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnNum1.PressedAppearance = Appearance101
        Me.ubtnNum1.ShowFocusRect = False
        Me.ubtnNum1.ShowOutline = False
        Me.ubtnNum1.Size = New System.Drawing.Size(60, 60)
        Me.ubtnNum1.TabIndex = 1
        Me.ubtnNum1.Tag = "!"
        Me.ubtnNum1.Text = "1"
        Me.ubtnNum1.UseAppStyling = False
        Me.ubtnNum1.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnNum1.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnNum1.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnX
        '
        Appearance102.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance102.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance102.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance102.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance102.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance102.BorderColor2 = System.Drawing.Color.Maroon
        Appearance102.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance102.ForeColor = System.Drawing.Color.White
        Appearance102.TextVAlignAsString = "Middle"
        Me.ubtnX.Appearance = Appearance102
        Me.ubtnX.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance103.BackColor = System.Drawing.Color.DarkOrange
        Appearance103.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance103.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance103.ForeColor = System.Drawing.Color.Black
        Me.ubtnX.HotTrackAppearance = Appearance103
        Me.ubtnX.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnX.Location = New System.Drawing.Point(245, 245)
        Me.ubtnX.Name = "ubtnX"
        Appearance104.BackColor = System.Drawing.Color.OrangeRed
        Appearance104.BackColor2 = System.Drawing.Color.Tomato
        Appearance104.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnX.PressedAppearance = Appearance104
        Me.ubtnX.ShowFocusRect = False
        Me.ubtnX.ShowOutline = False
        Me.ubtnX.Size = New System.Drawing.Size(60, 60)
        Me.ubtnX.TabIndex = 37
        Me.ubtnX.Tag = "x"
        Me.ubtnX.Text = "X"
        Me.ubtnX.UseAppStyling = False
        Me.ubtnX.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnX.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnX.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnC
        '
        Appearance105.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance105.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance105.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance105.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance105.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance105.BorderColor2 = System.Drawing.Color.Maroon
        Appearance105.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance105.ForeColor = System.Drawing.Color.White
        Appearance105.TextVAlignAsString = "Middle"
        Me.ubtnC.Appearance = Appearance105
        Me.ubtnC.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance106.BackColor = System.Drawing.Color.DarkOrange
        Appearance106.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance106.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance106.ForeColor = System.Drawing.Color.Black
        Me.ubtnC.HotTrackAppearance = Appearance106
        Me.ubtnC.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnC.Location = New System.Drawing.Point(306, 245)
        Me.ubtnC.Name = "ubtnC"
        Appearance107.BackColor = System.Drawing.Color.OrangeRed
        Appearance107.BackColor2 = System.Drawing.Color.Tomato
        Appearance107.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnC.PressedAppearance = Appearance107
        Me.ubtnC.ShowFocusRect = False
        Me.ubtnC.ShowOutline = False
        Me.ubtnC.Size = New System.Drawing.Size(60, 60)
        Me.ubtnC.TabIndex = 38
        Me.ubtnC.Tag = "c"
        Me.ubtnC.Text = "C"
        Me.ubtnC.UseAppStyling = False
        Me.ubtnC.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnC.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnC.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnV
        '
        Appearance108.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance108.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance108.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance108.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance108.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance108.BorderColor2 = System.Drawing.Color.Maroon
        Appearance108.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance108.ForeColor = System.Drawing.Color.White
        Appearance108.TextVAlignAsString = "Middle"
        Me.ubtnV.Appearance = Appearance108
        Me.ubtnV.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance109.BackColor = System.Drawing.Color.DarkOrange
        Appearance109.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance109.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance109.ForeColor = System.Drawing.Color.Black
        Me.ubtnV.HotTrackAppearance = Appearance109
        Me.ubtnV.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnV.Location = New System.Drawing.Point(367, 245)
        Me.ubtnV.Name = "ubtnV"
        Appearance110.BackColor = System.Drawing.Color.OrangeRed
        Appearance110.BackColor2 = System.Drawing.Color.Tomato
        Appearance110.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnV.PressedAppearance = Appearance110
        Me.ubtnV.ShowFocusRect = False
        Me.ubtnV.ShowOutline = False
        Me.ubtnV.Size = New System.Drawing.Size(60, 60)
        Me.ubtnV.TabIndex = 39
        Me.ubtnV.Tag = "v"
        Me.ubtnV.Text = "V"
        Me.ubtnV.UseAppStyling = False
        Me.ubtnV.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnV.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnV.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnB
        '
        Appearance111.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance111.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance111.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance111.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance111.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance111.BorderColor2 = System.Drawing.Color.Maroon
        Appearance111.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance111.ForeColor = System.Drawing.Color.White
        Appearance111.TextVAlignAsString = "Middle"
        Me.ubtnB.Appearance = Appearance111
        Me.ubtnB.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance112.BackColor = System.Drawing.Color.DarkOrange
        Appearance112.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance112.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance112.ForeColor = System.Drawing.Color.Black
        Me.ubtnB.HotTrackAppearance = Appearance112
        Me.ubtnB.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnB.Location = New System.Drawing.Point(428, 245)
        Me.ubtnB.Name = "ubtnB"
        Appearance113.BackColor = System.Drawing.Color.OrangeRed
        Appearance113.BackColor2 = System.Drawing.Color.Tomato
        Appearance113.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnB.PressedAppearance = Appearance113
        Me.ubtnB.ShowFocusRect = False
        Me.ubtnB.ShowOutline = False
        Me.ubtnB.Size = New System.Drawing.Size(60, 60)
        Me.ubtnB.TabIndex = 40
        Me.ubtnB.Tag = "b"
        Me.ubtnB.Text = "B"
        Me.ubtnB.UseAppStyling = False
        Me.ubtnB.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnB.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnB.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnN
        '
        Appearance114.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance114.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance114.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance114.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance114.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance114.BorderColor2 = System.Drawing.Color.Maroon
        Appearance114.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance114.ForeColor = System.Drawing.Color.White
        Appearance114.TextVAlignAsString = "Middle"
        Me.ubtnN.Appearance = Appearance114
        Me.ubtnN.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance115.BackColor = System.Drawing.Color.DarkOrange
        Appearance115.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance115.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance115.ForeColor = System.Drawing.Color.Black
        Me.ubtnN.HotTrackAppearance = Appearance115
        Me.ubtnN.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnN.Location = New System.Drawing.Point(489, 245)
        Me.ubtnN.Name = "ubtnN"
        Appearance116.BackColor = System.Drawing.Color.OrangeRed
        Appearance116.BackColor2 = System.Drawing.Color.Tomato
        Appearance116.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnN.PressedAppearance = Appearance116
        Me.ubtnN.ShowFocusRect = False
        Me.ubtnN.ShowOutline = False
        Me.ubtnN.Size = New System.Drawing.Size(60, 60)
        Me.ubtnN.TabIndex = 41
        Me.ubtnN.Tag = "n"
        Me.ubtnN.Text = "N"
        Me.ubtnN.UseAppStyling = False
        Me.ubtnN.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnN.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnN.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnM
        '
        Appearance117.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance117.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance117.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance117.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance117.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance117.BorderColor2 = System.Drawing.Color.Maroon
        Appearance117.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance117.ForeColor = System.Drawing.Color.White
        Appearance117.TextVAlignAsString = "Middle"
        Me.ubtnM.Appearance = Appearance117
        Me.ubtnM.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance118.BackColor = System.Drawing.Color.DarkOrange
        Appearance118.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance118.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance118.ForeColor = System.Drawing.Color.Black
        Me.ubtnM.HotTrackAppearance = Appearance118
        Me.ubtnM.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnM.Location = New System.Drawing.Point(550, 245)
        Me.ubtnM.Name = "ubtnM"
        Appearance119.BackColor = System.Drawing.Color.OrangeRed
        Appearance119.BackColor2 = System.Drawing.Color.Tomato
        Appearance119.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnM.PressedAppearance = Appearance119
        Me.ubtnM.ShowFocusRect = False
        Me.ubtnM.ShowOutline = False
        Me.ubtnM.Size = New System.Drawing.Size(60, 60)
        Me.ubtnM.TabIndex = 42
        Me.ubtnM.Tag = "m"
        Me.ubtnM.Text = "M"
        Me.ubtnM.UseAppStyling = False
        Me.ubtnM.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnM.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnM.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnZ
        '
        Appearance120.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance120.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance120.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance120.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance120.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance120.BorderColor2 = System.Drawing.Color.Maroon
        Appearance120.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance120.ForeColor = System.Drawing.Color.White
        Appearance120.TextVAlignAsString = "Middle"
        Me.ubtnZ.Appearance = Appearance120
        Me.ubtnZ.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance121.BackColor = System.Drawing.Color.DarkOrange
        Appearance121.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance121.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance121.ForeColor = System.Drawing.Color.Black
        Me.ubtnZ.HotTrackAppearance = Appearance121
        Me.ubtnZ.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnZ.Location = New System.Drawing.Point(184, 245)
        Me.ubtnZ.Name = "ubtnZ"
        Appearance122.BackColor = System.Drawing.Color.OrangeRed
        Appearance122.BackColor2 = System.Drawing.Color.Tomato
        Appearance122.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnZ.PressedAppearance = Appearance122
        Me.ubtnZ.ShowFocusRect = False
        Me.ubtnZ.ShowOutline = False
        Me.ubtnZ.Size = New System.Drawing.Size(60, 60)
        Me.ubtnZ.TabIndex = 36
        Me.ubtnZ.Tag = "z"
        Me.ubtnZ.Text = "Z"
        Me.ubtnZ.UseAppStyling = False
        Me.ubtnZ.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnZ.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnZ.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnS
        '
        Appearance123.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance123.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance123.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance123.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance123.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance123.BorderColor2 = System.Drawing.Color.Maroon
        Appearance123.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance123.ForeColor = System.Drawing.Color.White
        Appearance123.TextVAlignAsString = "Middle"
        Me.ubtnS.Appearance = Appearance123
        Me.ubtnS.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance124.BackColor = System.Drawing.Color.DarkOrange
        Appearance124.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance124.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance124.ForeColor = System.Drawing.Color.Black
        Me.ubtnS.HotTrackAppearance = Appearance124
        Me.ubtnS.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnS.Location = New System.Drawing.Point(213, 184)
        Me.ubtnS.Name = "ubtnS"
        Appearance125.BackColor = System.Drawing.Color.OrangeRed
        Appearance125.BackColor2 = System.Drawing.Color.Tomato
        Appearance125.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnS.PressedAppearance = Appearance125
        Me.ubtnS.ShowFocusRect = False
        Me.ubtnS.ShowOutline = False
        Me.ubtnS.Size = New System.Drawing.Size(60, 60)
        Me.ubtnS.TabIndex = 25
        Me.ubtnS.Tag = "s"
        Me.ubtnS.Text = "S"
        Me.ubtnS.UseAppStyling = False
        Me.ubtnS.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnS.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnS.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnD
        '
        Appearance126.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance126.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance126.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance126.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance126.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance126.BorderColor2 = System.Drawing.Color.Maroon
        Appearance126.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance126.ForeColor = System.Drawing.Color.White
        Appearance126.TextVAlignAsString = "Middle"
        Me.ubtnD.Appearance = Appearance126
        Me.ubtnD.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance127.BackColor = System.Drawing.Color.DarkOrange
        Appearance127.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance127.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance127.ForeColor = System.Drawing.Color.Black
        Me.ubtnD.HotTrackAppearance = Appearance127
        Me.ubtnD.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnD.Location = New System.Drawing.Point(274, 184)
        Me.ubtnD.Name = "ubtnD"
        Appearance128.BackColor = System.Drawing.Color.OrangeRed
        Appearance128.BackColor2 = System.Drawing.Color.Tomato
        Appearance128.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnD.PressedAppearance = Appearance128
        Me.ubtnD.ShowFocusRect = False
        Me.ubtnD.ShowOutline = False
        Me.ubtnD.Size = New System.Drawing.Size(60, 60)
        Me.ubtnD.TabIndex = 26
        Me.ubtnD.Tag = "d"
        Me.ubtnD.Text = "D"
        Me.ubtnD.UseAppStyling = False
        Me.ubtnD.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnD.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnD.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnF
        '
        Appearance129.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance129.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance129.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance129.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance129.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance129.BorderColor2 = System.Drawing.Color.Maroon
        Appearance129.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance129.ForeColor = System.Drawing.Color.White
        Appearance129.TextVAlignAsString = "Middle"
        Me.ubtnF.Appearance = Appearance129
        Me.ubtnF.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance130.BackColor = System.Drawing.Color.DarkOrange
        Appearance130.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance130.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance130.ForeColor = System.Drawing.Color.Black
        Me.ubtnF.HotTrackAppearance = Appearance130
        Me.ubtnF.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnF.Location = New System.Drawing.Point(335, 184)
        Me.ubtnF.Name = "ubtnF"
        Appearance131.BackColor = System.Drawing.Color.OrangeRed
        Appearance131.BackColor2 = System.Drawing.Color.Tomato
        Appearance131.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnF.PressedAppearance = Appearance131
        Me.ubtnF.ShowFocusRect = False
        Me.ubtnF.ShowOutline = False
        Me.ubtnF.Size = New System.Drawing.Size(60, 60)
        Me.ubtnF.TabIndex = 27
        Me.ubtnF.Tag = "f"
        Me.ubtnF.Text = "F"
        Me.ubtnF.UseAppStyling = False
        Me.ubtnF.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnF.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnF.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnG
        '
        Appearance132.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance132.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance132.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance132.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance132.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance132.BorderColor2 = System.Drawing.Color.Maroon
        Appearance132.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance132.ForeColor = System.Drawing.Color.White
        Appearance132.TextVAlignAsString = "Middle"
        Me.ubtnG.Appearance = Appearance132
        Me.ubtnG.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance133.BackColor = System.Drawing.Color.DarkOrange
        Appearance133.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance133.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance133.ForeColor = System.Drawing.Color.Black
        Me.ubtnG.HotTrackAppearance = Appearance133
        Me.ubtnG.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnG.Location = New System.Drawing.Point(396, 184)
        Me.ubtnG.Name = "ubtnG"
        Appearance134.BackColor = System.Drawing.Color.OrangeRed
        Appearance134.BackColor2 = System.Drawing.Color.Tomato
        Appearance134.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnG.PressedAppearance = Appearance134
        Me.ubtnG.ShowFocusRect = False
        Me.ubtnG.ShowOutline = False
        Me.ubtnG.Size = New System.Drawing.Size(60, 60)
        Me.ubtnG.TabIndex = 28
        Me.ubtnG.Tag = "g"
        Me.ubtnG.Text = "G"
        Me.ubtnG.UseAppStyling = False
        Me.ubtnG.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnG.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnG.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnH
        '
        Appearance135.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance135.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance135.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance135.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance135.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance135.BorderColor2 = System.Drawing.Color.Maroon
        Appearance135.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance135.ForeColor = System.Drawing.Color.White
        Appearance135.TextVAlignAsString = "Middle"
        Me.ubtnH.Appearance = Appearance135
        Me.ubtnH.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance136.BackColor = System.Drawing.Color.DarkOrange
        Appearance136.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance136.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance136.ForeColor = System.Drawing.Color.Black
        Me.ubtnH.HotTrackAppearance = Appearance136
        Me.ubtnH.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnH.Location = New System.Drawing.Point(457, 184)
        Me.ubtnH.Name = "ubtnH"
        Appearance137.BackColor = System.Drawing.Color.OrangeRed
        Appearance137.BackColor2 = System.Drawing.Color.Tomato
        Appearance137.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnH.PressedAppearance = Appearance137
        Me.ubtnH.ShowFocusRect = False
        Me.ubtnH.ShowOutline = False
        Me.ubtnH.Size = New System.Drawing.Size(60, 60)
        Me.ubtnH.TabIndex = 29
        Me.ubtnH.Tag = "h"
        Me.ubtnH.Text = "H"
        Me.ubtnH.UseAppStyling = False
        Me.ubtnH.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnH.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnH.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnJ
        '
        Appearance138.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance138.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance138.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance138.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance138.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance138.BorderColor2 = System.Drawing.Color.Maroon
        Appearance138.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance138.ForeColor = System.Drawing.Color.White
        Appearance138.TextVAlignAsString = "Middle"
        Me.ubtnJ.Appearance = Appearance138
        Me.ubtnJ.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance139.BackColor = System.Drawing.Color.DarkOrange
        Appearance139.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance139.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance139.ForeColor = System.Drawing.Color.Black
        Me.ubtnJ.HotTrackAppearance = Appearance139
        Me.ubtnJ.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnJ.Location = New System.Drawing.Point(518, 184)
        Me.ubtnJ.Name = "ubtnJ"
        Appearance140.BackColor = System.Drawing.Color.OrangeRed
        Appearance140.BackColor2 = System.Drawing.Color.Tomato
        Appearance140.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnJ.PressedAppearance = Appearance140
        Me.ubtnJ.ShowFocusRect = False
        Me.ubtnJ.ShowOutline = False
        Me.ubtnJ.Size = New System.Drawing.Size(60, 60)
        Me.ubtnJ.TabIndex = 30
        Me.ubtnJ.Tag = "j"
        Me.ubtnJ.Text = "J"
        Me.ubtnJ.UseAppStyling = False
        Me.ubtnJ.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnJ.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnJ.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnK
        '
        Appearance141.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance141.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance141.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance141.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance141.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance141.BorderColor2 = System.Drawing.Color.Maroon
        Appearance141.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance141.ForeColor = System.Drawing.Color.White
        Appearance141.TextVAlignAsString = "Middle"
        Me.ubtnK.Appearance = Appearance141
        Me.ubtnK.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance142.BackColor = System.Drawing.Color.DarkOrange
        Appearance142.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance142.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance142.ForeColor = System.Drawing.Color.Black
        Me.ubtnK.HotTrackAppearance = Appearance142
        Me.ubtnK.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnK.Location = New System.Drawing.Point(579, 184)
        Me.ubtnK.Name = "ubtnK"
        Appearance143.BackColor = System.Drawing.Color.OrangeRed
        Appearance143.BackColor2 = System.Drawing.Color.Tomato
        Appearance143.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnK.PressedAppearance = Appearance143
        Me.ubtnK.ShowFocusRect = False
        Me.ubtnK.ShowOutline = False
        Me.ubtnK.Size = New System.Drawing.Size(60, 60)
        Me.ubtnK.TabIndex = 31
        Me.ubtnK.Tag = "k"
        Me.ubtnK.Text = "K"
        Me.ubtnK.UseAppStyling = False
        Me.ubtnK.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnK.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnK.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnL
        '
        Appearance144.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance144.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance144.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance144.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance144.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance144.BorderColor2 = System.Drawing.Color.Maroon
        Appearance144.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance144.ForeColor = System.Drawing.Color.White
        Appearance144.TextVAlignAsString = "Middle"
        Me.ubtnL.Appearance = Appearance144
        Me.ubtnL.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance145.BackColor = System.Drawing.Color.DarkOrange
        Appearance145.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance145.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance145.ForeColor = System.Drawing.Color.Black
        Me.ubtnL.HotTrackAppearance = Appearance145
        Me.ubtnL.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnL.Location = New System.Drawing.Point(640, 184)
        Me.ubtnL.Name = "ubtnL"
        Appearance146.BackColor = System.Drawing.Color.OrangeRed
        Appearance146.BackColor2 = System.Drawing.Color.Tomato
        Appearance146.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnL.PressedAppearance = Appearance146
        Me.ubtnL.ShowFocusRect = False
        Me.ubtnL.ShowOutline = False
        Me.ubtnL.Size = New System.Drawing.Size(60, 60)
        Me.ubtnL.TabIndex = 32
        Me.ubtnL.Tag = "l"
        Me.ubtnL.Text = "L"
        Me.ubtnL.UseAppStyling = False
        Me.ubtnL.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnL.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnL.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnA
        '
        Appearance147.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance147.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance147.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance147.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance147.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance147.BorderColor2 = System.Drawing.Color.Maroon
        Appearance147.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance147.ForeColor = System.Drawing.Color.White
        Appearance147.TextVAlignAsString = "Middle"
        Me.ubtnA.Appearance = Appearance147
        Me.ubtnA.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance148.BackColor = System.Drawing.Color.DarkOrange
        Appearance148.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance148.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance148.ForeColor = System.Drawing.Color.Black
        Me.ubtnA.HotTrackAppearance = Appearance148
        Me.ubtnA.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnA.Location = New System.Drawing.Point(152, 184)
        Me.ubtnA.Name = "ubtnA"
        Appearance149.BackColor = System.Drawing.Color.OrangeRed
        Appearance149.BackColor2 = System.Drawing.Color.Tomato
        Appearance149.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnA.PressedAppearance = Appearance149
        Me.ubtnA.ShowFocusRect = False
        Me.ubtnA.ShowOutline = False
        Me.ubtnA.Size = New System.Drawing.Size(60, 60)
        Me.ubtnA.TabIndex = 24
        Me.ubtnA.Tag = "a"
        Me.ubtnA.Text = "A"
        Me.ubtnA.UseAppStyling = False
        Me.ubtnA.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnA.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnA.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnW
        '
        Appearance150.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance150.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance150.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance150.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance150.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance150.BorderColor2 = System.Drawing.Color.Maroon
        Appearance150.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance150.ForeColor = System.Drawing.Color.White
        Appearance150.TextVAlignAsString = "Middle"
        Me.ubtnW.Appearance = Appearance150
        Me.ubtnW.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance151.BackColor = System.Drawing.Color.DarkOrange
        Appearance151.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance151.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance151.ForeColor = System.Drawing.Color.Black
        Me.ubtnW.HotTrackAppearance = Appearance151
        Me.ubtnW.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnW.Location = New System.Drawing.Point(184, 123)
        Me.ubtnW.Name = "ubtnW"
        Appearance152.BackColor = System.Drawing.Color.OrangeRed
        Appearance152.BackColor2 = System.Drawing.Color.Tomato
        Appearance152.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnW.PressedAppearance = Appearance152
        Me.ubtnW.ShowFocusRect = False
        Me.ubtnW.ShowOutline = False
        Me.ubtnW.Size = New System.Drawing.Size(60, 60)
        Me.ubtnW.TabIndex = 14
        Me.ubtnW.Tag = "w"
        Me.ubtnW.Text = "W"
        Me.ubtnW.UseAppStyling = False
        Me.ubtnW.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnW.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnW.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnE
        '
        Appearance153.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance153.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance153.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance153.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance153.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance153.BorderColor2 = System.Drawing.Color.Maroon
        Appearance153.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance153.ForeColor = System.Drawing.Color.White
        Appearance153.TextVAlignAsString = "Middle"
        Me.ubtnE.Appearance = Appearance153
        Me.ubtnE.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance154.BackColor = System.Drawing.Color.DarkOrange
        Appearance154.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance154.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance154.ForeColor = System.Drawing.Color.Black
        Me.ubtnE.HotTrackAppearance = Appearance154
        Me.ubtnE.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnE.Location = New System.Drawing.Point(245, 123)
        Me.ubtnE.Name = "ubtnE"
        Appearance155.BackColor = System.Drawing.Color.OrangeRed
        Appearance155.BackColor2 = System.Drawing.Color.Tomato
        Appearance155.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnE.PressedAppearance = Appearance155
        Me.ubtnE.ShowFocusRect = False
        Me.ubtnE.ShowOutline = False
        Me.ubtnE.Size = New System.Drawing.Size(60, 60)
        Me.ubtnE.TabIndex = 15
        Me.ubtnE.Tag = "e"
        Me.ubtnE.Text = "E"
        Me.ubtnE.UseAppStyling = False
        Me.ubtnE.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnE.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnE.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnR
        '
        Appearance156.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance156.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance156.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance156.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance156.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance156.BorderColor2 = System.Drawing.Color.Maroon
        Appearance156.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance156.ForeColor = System.Drawing.Color.White
        Appearance156.TextVAlignAsString = "Middle"
        Me.ubtnR.Appearance = Appearance156
        Me.ubtnR.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance157.BackColor = System.Drawing.Color.DarkOrange
        Appearance157.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance157.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance157.ForeColor = System.Drawing.Color.Black
        Me.ubtnR.HotTrackAppearance = Appearance157
        Me.ubtnR.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnR.Location = New System.Drawing.Point(306, 123)
        Me.ubtnR.Name = "ubtnR"
        Appearance158.BackColor = System.Drawing.Color.OrangeRed
        Appearance158.BackColor2 = System.Drawing.Color.Tomato
        Appearance158.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnR.PressedAppearance = Appearance158
        Me.ubtnR.ShowFocusRect = False
        Me.ubtnR.ShowOutline = False
        Me.ubtnR.Size = New System.Drawing.Size(60, 60)
        Me.ubtnR.TabIndex = 16
        Me.ubtnR.Tag = "r"
        Me.ubtnR.Text = "R"
        Me.ubtnR.UseAppStyling = False
        Me.ubtnR.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnR.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnR.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnT
        '
        Appearance159.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance159.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance159.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance159.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance159.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance159.BorderColor2 = System.Drawing.Color.Maroon
        Appearance159.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance159.ForeColor = System.Drawing.Color.White
        Appearance159.TextVAlignAsString = "Middle"
        Me.ubtnT.Appearance = Appearance159
        Me.ubtnT.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance160.BackColor = System.Drawing.Color.DarkOrange
        Appearance160.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance160.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance160.ForeColor = System.Drawing.Color.Black
        Me.ubtnT.HotTrackAppearance = Appearance160
        Me.ubtnT.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnT.Location = New System.Drawing.Point(367, 123)
        Me.ubtnT.Name = "ubtnT"
        Appearance161.BackColor = System.Drawing.Color.OrangeRed
        Appearance161.BackColor2 = System.Drawing.Color.Tomato
        Appearance161.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnT.PressedAppearance = Appearance161
        Me.ubtnT.ShowFocusRect = False
        Me.ubtnT.ShowOutline = False
        Me.ubtnT.Size = New System.Drawing.Size(60, 60)
        Me.ubtnT.TabIndex = 17
        Me.ubtnT.Tag = "t"
        Me.ubtnT.Text = "T"
        Me.ubtnT.UseAppStyling = False
        Me.ubtnT.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnT.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnT.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnY
        '
        Appearance162.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance162.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance162.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance162.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance162.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance162.BorderColor2 = System.Drawing.Color.Maroon
        Appearance162.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance162.ForeColor = System.Drawing.Color.White
        Appearance162.TextVAlignAsString = "Middle"
        Me.ubtnY.Appearance = Appearance162
        Me.ubtnY.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance163.BackColor = System.Drawing.Color.DarkOrange
        Appearance163.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance163.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance163.ForeColor = System.Drawing.Color.Black
        Me.ubtnY.HotTrackAppearance = Appearance163
        Me.ubtnY.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnY.Location = New System.Drawing.Point(428, 123)
        Me.ubtnY.Name = "ubtnY"
        Appearance164.BackColor = System.Drawing.Color.OrangeRed
        Appearance164.BackColor2 = System.Drawing.Color.Tomato
        Appearance164.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnY.PressedAppearance = Appearance164
        Me.ubtnY.ShowFocusRect = False
        Me.ubtnY.ShowOutline = False
        Me.ubtnY.Size = New System.Drawing.Size(60, 60)
        Me.ubtnY.TabIndex = 18
        Me.ubtnY.Tag = "y"
        Me.ubtnY.Text = "Y"
        Me.ubtnY.UseAppStyling = False
        Me.ubtnY.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnY.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnY.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnU
        '
        Appearance165.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance165.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance165.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance165.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance165.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance165.BorderColor2 = System.Drawing.Color.Maroon
        Appearance165.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance165.ForeColor = System.Drawing.Color.White
        Appearance165.TextVAlignAsString = "Middle"
        Me.ubtnU.Appearance = Appearance165
        Me.ubtnU.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance166.BackColor = System.Drawing.Color.DarkOrange
        Appearance166.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance166.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance166.ForeColor = System.Drawing.Color.Black
        Me.ubtnU.HotTrackAppearance = Appearance166
        Me.ubtnU.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnU.Location = New System.Drawing.Point(489, 123)
        Me.ubtnU.Name = "ubtnU"
        Appearance167.BackColor = System.Drawing.Color.OrangeRed
        Appearance167.BackColor2 = System.Drawing.Color.Tomato
        Appearance167.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnU.PressedAppearance = Appearance167
        Me.ubtnU.ShowFocusRect = False
        Me.ubtnU.ShowOutline = False
        Me.ubtnU.Size = New System.Drawing.Size(60, 60)
        Me.ubtnU.TabIndex = 19
        Me.ubtnU.Tag = "u"
        Me.ubtnU.Text = "U"
        Me.ubtnU.UseAppStyling = False
        Me.ubtnU.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnU.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnU.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnI
        '
        Appearance168.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance168.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance168.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance168.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance168.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance168.BorderColor2 = System.Drawing.Color.Maroon
        Appearance168.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance168.ForeColor = System.Drawing.Color.White
        Appearance168.TextVAlignAsString = "Middle"
        Me.ubtnI.Appearance = Appearance168
        Me.ubtnI.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance169.BackColor = System.Drawing.Color.DarkOrange
        Appearance169.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance169.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance169.ForeColor = System.Drawing.Color.Black
        Me.ubtnI.HotTrackAppearance = Appearance169
        Me.ubtnI.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnI.Location = New System.Drawing.Point(550, 123)
        Me.ubtnI.Name = "ubtnI"
        Appearance170.BackColor = System.Drawing.Color.OrangeRed
        Appearance170.BackColor2 = System.Drawing.Color.Tomato
        Appearance170.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnI.PressedAppearance = Appearance170
        Me.ubtnI.ShowFocusRect = False
        Me.ubtnI.ShowOutline = False
        Me.ubtnI.Size = New System.Drawing.Size(60, 60)
        Me.ubtnI.TabIndex = 20
        Me.ubtnI.Tag = "i"
        Me.ubtnI.Text = "I"
        Me.ubtnI.UseAppStyling = False
        Me.ubtnI.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnI.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnI.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnO
        '
        Appearance171.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance171.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance171.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance171.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance171.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance171.BorderColor2 = System.Drawing.Color.Maroon
        Appearance171.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance171.ForeColor = System.Drawing.Color.White
        Appearance171.TextVAlignAsString = "Middle"
        Me.ubtnO.Appearance = Appearance171
        Me.ubtnO.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance172.BackColor = System.Drawing.Color.DarkOrange
        Appearance172.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance172.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance172.ForeColor = System.Drawing.Color.Black
        Me.ubtnO.HotTrackAppearance = Appearance172
        Me.ubtnO.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnO.Location = New System.Drawing.Point(611, 123)
        Me.ubtnO.Name = "ubtnO"
        Appearance173.BackColor = System.Drawing.Color.OrangeRed
        Appearance173.BackColor2 = System.Drawing.Color.Tomato
        Appearance173.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnO.PressedAppearance = Appearance173
        Me.ubtnO.ShowFocusRect = False
        Me.ubtnO.ShowOutline = False
        Me.ubtnO.Size = New System.Drawing.Size(60, 60)
        Me.ubtnO.TabIndex = 21
        Me.ubtnO.Tag = "o"
        Me.ubtnO.Text = "O"
        Me.ubtnO.UseAppStyling = False
        Me.ubtnO.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnO.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnO.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnP
        '
        Appearance174.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance174.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance174.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance174.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance174.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance174.BorderColor2 = System.Drawing.Color.Maroon
        Appearance174.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance174.ForeColor = System.Drawing.Color.White
        Appearance174.TextVAlignAsString = "Middle"
        Me.ubtnP.Appearance = Appearance174
        Me.ubtnP.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance175.BackColor = System.Drawing.Color.DarkOrange
        Appearance175.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance175.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance175.ForeColor = System.Drawing.Color.Black
        Me.ubtnP.HotTrackAppearance = Appearance175
        Me.ubtnP.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnP.Location = New System.Drawing.Point(672, 123)
        Me.ubtnP.Name = "ubtnP"
        Appearance176.BackColor = System.Drawing.Color.OrangeRed
        Appearance176.BackColor2 = System.Drawing.Color.Tomato
        Appearance176.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnP.PressedAppearance = Appearance176
        Me.ubtnP.ShowFocusRect = False
        Me.ubtnP.ShowOutline = False
        Me.ubtnP.Size = New System.Drawing.Size(60, 60)
        Me.ubtnP.TabIndex = 22
        Me.ubtnP.Tag = "p"
        Me.ubtnP.Text = "P"
        Me.ubtnP.UseAppStyling = False
        Me.ubtnP.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnP.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnP.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnQ
        '
        Appearance177.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance177.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance177.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance177.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance177.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance177.BorderColor2 = System.Drawing.Color.Maroon
        Appearance177.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance177.ForeColor = System.Drawing.Color.White
        Appearance177.TextVAlignAsString = "Middle"
        Me.ubtnQ.Appearance = Appearance177
        Me.ubtnQ.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance178.BackColor = System.Drawing.Color.DarkOrange
        Appearance178.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance178.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance178.ForeColor = System.Drawing.Color.Black
        Me.ubtnQ.HotTrackAppearance = Appearance178
        Me.ubtnQ.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnQ.Location = New System.Drawing.Point(123, 123)
        Me.ubtnQ.Name = "ubtnQ"
        Appearance179.BackColor = System.Drawing.Color.OrangeRed
        Appearance179.BackColor2 = System.Drawing.Color.Tomato
        Appearance179.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnQ.PressedAppearance = Appearance179
        Me.ubtnQ.ShowFocusRect = False
        Me.ubtnQ.ShowOutline = False
        Me.ubtnQ.Size = New System.Drawing.Size(60, 60)
        Me.ubtnQ.TabIndex = 13
        Me.ubtnQ.Tag = "q"
        Me.ubtnQ.Text = "Q"
        Me.ubtnQ.UseAppStyling = False
        Me.ubtnQ.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnQ.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnQ.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'FullKeyboard
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(16, Byte), Integer), CType(CType(105, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(953, 375)
        Me.Controls.Add(Me.upnlKeyboard)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "FullKeyboard"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "EZKeyboard"
        Me.upnlKeyboard.ClientArea.ResumeLayout(False)
        Me.upnlKeyboard.ResumeLayout(False)
        CType(Me.picShiftR, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picShiftL, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picCaps, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents upnlKeyboard As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents picShiftR As System.Windows.Forms.PictureBox
    Friend WithEvents picShiftL As System.Windows.Forms.PictureBox
    Friend WithEvents picCaps As System.Windows.Forms.PictureBox
    Friend WithEvents ubtnArrowD As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnArrowU As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnArrowR As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnArrowL As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnShiftR As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnSpChar6 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnSpChar9 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnShiftL As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnCase As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnTab As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnSpChar3 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnSpChar2 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnSpChar1 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnEsc As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnSpace As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnSpChar7 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnSpChar5 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnSpChar4 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnUseless As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnBkSp As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnSpChar11 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents lblEntryBox As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents ubtnClear As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnEnter As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnNum2 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnNum3 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnNum4 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnNum5 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnNum6 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnNum7 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnNum8 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnNum9 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnNum0 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnNum1 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnX As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnC As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnV As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnB As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnN As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnM As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnZ As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnS As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnD As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnF As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnG As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnH As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnJ As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnK As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnL As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnA As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnW As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnE As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnR As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnT As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnY As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnU As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnI As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnO As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnP As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnQ As Infragistics.Win.Misc.UltraButton
End Class
