﻿Imports Infragistics.Win.Misc

Friend Class CustomListDesigner
    Inherits Form

    Public Result As String

    Public Sub New(strArray As List(Of String), blnSortList As Boolean, Optional strCancelText As String = "Cancel")

        MyBase.New()
        InitializeComponent()

        Dim intTopLocation As Short = -1

        If blnSortList = True Then strArray.Sort()

        'set buttons' text
        For xI As Short = 0 To strArray.Count - 1
            For Each myObj As Object In Controls
                If TypeName(myObj) = "UltraButton" AndAlso myObj.text = String.Empty AndAlso myObj.name.ToString.IndexOf((xI + 1).ToString) <> -1 Then
                    Dim ubtnButton As UltraButton = DirectCast(myObj, UltraButton)
                    ubtnButton.Text = strArray(xI)
                    ubtnButton.Visible = True
                    AddHandler ubtnButton.Click, AddressOf ButtonsClickHandler
                    intTopLocation = myObj.top
                    Exit For
                End If
            Next
        Next

        CancelButton = cmdCancel
        cmdCancel.Text = strCancelText
        cmdCancel.Top = intTopLocation + cmdCancel.Height * 2
        AddHandler cmdCancel.Click, AddressOf ButtonsClickHandler

        Height = cmdCancel.Top + (cmdCancel.Height * 1.7)

    End Sub

    Private Sub ButtonsClickHandler(sender As Object, e As EventArgs)

        Result = sender.text
        If sender.name = "cmdCancel" Then Result = "^Cancel"
        Dispose()

    End Sub

End Class

Public Class CustomList

    Public Shared Function Show(strArray As List(Of String), blnSortList As Boolean, Optional strCancelText As String = "Cancel") As String

        Dim objForm As New CustomListDesigner(strArray, blnSortList, strCancelText)
        objForm.ShowDialog()

        Return objForm.Result

    End Function

End Class