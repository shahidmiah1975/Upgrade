﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmPayment
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim Appearance1 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance2 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance3 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance4 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance5 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance6 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance7 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance8 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance9 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance10 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance11 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance12 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance13 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance14 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance15 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance16 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance17 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance18 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance19 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance20 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance21 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance22 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance23 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance24 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance25 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance26 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance27 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance28 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance29 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance30 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance31 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance32 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance33 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance34 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance35 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance36 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance37 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance38 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance39 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance40 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance41 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance42 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance43 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance44 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance45 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance46 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance47 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance48 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance49 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance50 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance51 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance52 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance53 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance54 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance55 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance56 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance57 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance58 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance59 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance60 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance61 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance62 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance63 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance64 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance65 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance66 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance67 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance68 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance69 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmPayment))
        Dim Appearance70 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance71 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance72 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance73 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance74 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance75 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance76 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance77 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance78 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance79 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance80 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance81 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance82 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance83 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance84 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance85 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance86 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance87 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance88 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance89 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance90 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance91 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance92 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance93 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance94 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance95 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance96 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance97 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance98 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance99 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance100 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance101 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance102 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance103 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Me.UltraLabel1 = New Infragistics.Win.Misc.UltraLabel()
        Me.cmdSplitPayment = New Infragistics.Win.Misc.UltraButton()
        Me.upnlCard = New Infragistics.Win.Misc.UltraPanel()
        Me.cmdSplitDishes = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnTips = New Infragistics.Win.Misc.UltraButton()
        Me.txtTips = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.cmdTender20 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdTender10 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdTender50 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdTenderCard = New Infragistics.Win.Misc.UltraButton()
        Me.cmdTenderCash = New Infragistics.Win.Misc.UltraButton()
        Me.UltraPanel3 = New Infragistics.Win.Misc.UltraPanel()
        Me.cmdClearTender = New Infragistics.Win.Misc.UltraButton()
        Me.cmdTenderOther = New Infragistics.Win.Misc.UltraButton()
        Me.cmdTenderExact = New Infragistics.Win.Misc.UltraButton()
        Me.cmdNumDot = New Infragistics.Win.Misc.UltraButton()
        Me.txtChange = New System.Windows.Forms.TextBox()
        Me.cmdNum0 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdNum3 = New Infragistics.Win.Misc.UltraButton()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.cmdNum2 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdNum1 = New Infragistics.Win.Misc.UltraButton()
        Me.txtTendered = New System.Windows.Forms.TextBox()
        Me.cmdNum6 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdNum5 = New Infragistics.Win.Misc.UltraButton()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cmdNum4 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdNum9 = New Infragistics.Win.Misc.UltraButton()
        Me.txtBillTotal = New System.Windows.Forms.TextBox()
        Me.cmdNum8 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdNum7 = New Infragistics.Win.Misc.UltraButton()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cmdKBTime = New Infragistics.Win.Misc.UltraButton()
        Me.cmdWaiting = New Infragistics.Win.Misc.UltraButton()
        Me.cmdPaid = New Infragistics.Win.Misc.UltraButton()
        Me.UltraPanel2 = New Infragistics.Win.Misc.UltraPanel()
        Me.lblTime = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.cmdClearKitchenNote = New Infragistics.Win.Misc.UltraButton()
        Me.txtKitchenNote = New System.Windows.Forms.TextBox()
        Me.UltraPanel1 = New Infragistics.Win.Misc.UltraPanel()
        Me.cmdKBNote = New Infragistics.Win.Misc.UltraButton()
        Me.cmdSaveOrder = New Infragistics.Win.Misc.UltraButton()
        Me.cmdShopCopy = New Infragistics.Win.Misc.UltraButton()
        Me.cmdKitchenCopy = New Infragistics.Win.Misc.UltraButton()
        Me.cmdBack = New Infragistics.Win.Misc.UltraButton()
        Me.cmdPrintOrder = New Infragistics.Win.Misc.UltraButton()
        Me.cmdOEHome = New Infragistics.Win.Misc.UltraButton()
        Me.upnlCard.ClientArea.SuspendLayout()
        Me.upnlCard.SuspendLayout()
        Me.UltraPanel3.ClientArea.SuspendLayout()
        Me.UltraPanel3.SuspendLayout()
        Me.UltraPanel2.ClientArea.SuspendLayout()
        Me.UltraPanel2.SuspendLayout()
        Me.UltraPanel1.ClientArea.SuspendLayout()
        Me.UltraPanel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'UltraLabel1
        '
        Me.UltraLabel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance1.BorderColor = System.Drawing.Color.Silver
        Me.UltraLabel1.Appearance = Appearance1
        Me.UltraLabel1.BorderStyleInner = Infragistics.Win.UIElementBorderStyle.Solid
        Me.UltraLabel1.Location = New System.Drawing.Point(-1, 627)
        Me.UltraLabel1.Name = "UltraLabel1"
        Me.UltraLabel1.Size = New System.Drawing.Size(987, 1)
        Me.UltraLabel1.TabIndex = 549
        '
        'cmdSplitPayment
        '
        Appearance2.BackColor = System.Drawing.Color.DarkGoldenrod
        Appearance2.BackColor2 = System.Drawing.Color.DarkOliveGreen
        Appearance2.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance2.BorderColor = System.Drawing.Color.Khaki
        Appearance2.BorderColor2 = System.Drawing.Color.Maroon
        Appearance2.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance2.ForeColor = System.Drawing.Color.White
        Appearance2.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance2.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance2.TextVAlignAsString = "Middle"
        Me.cmdSplitPayment.Appearance = Appearance2
        Me.cmdSplitPayment.Enabled = False
        Me.cmdSplitPayment.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance3.BackColor = System.Drawing.Color.DarkOrange
        Appearance3.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance3.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance3.ForeColor = System.Drawing.Color.Black
        Me.cmdSplitPayment.HotTrackAppearance = Appearance3
        Me.cmdSplitPayment.ImageSize = New System.Drawing.Size(40, 40)
        Me.cmdSplitPayment.Location = New System.Drawing.Point(65, 32)
        Me.cmdSplitPayment.Name = "cmdSplitPayment"
        Appearance4.BackColor = System.Drawing.Color.OrangeRed
        Appearance4.BackColor2 = System.Drawing.Color.Tomato
        Appearance4.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdSplitPayment.PressedAppearance = Appearance4
        Me.cmdSplitPayment.ShowFocusRect = False
        Me.cmdSplitPayment.ShowOutline = False
        Me.cmdSplitPayment.Size = New System.Drawing.Size(140, 45)
        Me.cmdSplitPayment.TabIndex = 535
        Me.cmdSplitPayment.Tag = ""
        Me.cmdSplitPayment.Text = "Split Payment"
        Me.cmdSplitPayment.UseAppStyling = False
        Me.cmdSplitPayment.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdSplitPayment.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdSplitPayment.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'upnlCard
        '
        Appearance5.BackColor = System.Drawing.Color.Transparent
        Me.upnlCard.Appearance = Appearance5
        Me.upnlCard.BorderStyle = Infragistics.Win.UIElementBorderStyle.Etched
        '
        'upnlCard.ClientArea
        '
        Me.upnlCard.ClientArea.Controls.Add(Me.cmdSplitDishes)
        Me.upnlCard.ClientArea.Controls.Add(Me.cmdSplitPayment)
        Me.upnlCard.Location = New System.Drawing.Point(258, 14)
        Me.upnlCard.Name = "upnlCard"
        Me.upnlCard.Size = New System.Drawing.Size(274, 173)
        Me.upnlCard.TabIndex = 550
        '
        'cmdSplitDishes
        '
        Appearance6.BackColor = System.Drawing.Color.DarkGoldenrod
        Appearance6.BackColor2 = System.Drawing.Color.DarkOliveGreen
        Appearance6.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance6.BorderColor = System.Drawing.Color.Khaki
        Appearance6.BorderColor2 = System.Drawing.Color.Maroon
        Appearance6.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance6.ForeColor = System.Drawing.Color.White
        Appearance6.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance6.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance6.TextVAlignAsString = "Middle"
        Me.cmdSplitDishes.Appearance = Appearance6
        Me.cmdSplitDishes.Enabled = False
        Me.cmdSplitDishes.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance7.BackColor = System.Drawing.Color.DarkOrange
        Appearance7.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance7.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance7.ForeColor = System.Drawing.Color.Black
        Me.cmdSplitDishes.HotTrackAppearance = Appearance7
        Me.cmdSplitDishes.ImageSize = New System.Drawing.Size(40, 40)
        Me.cmdSplitDishes.Location = New System.Drawing.Point(65, 91)
        Me.cmdSplitDishes.Name = "cmdSplitDishes"
        Appearance8.BackColor = System.Drawing.Color.OrangeRed
        Appearance8.BackColor2 = System.Drawing.Color.Tomato
        Appearance8.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdSplitDishes.PressedAppearance = Appearance8
        Me.cmdSplitDishes.ShowFocusRect = False
        Me.cmdSplitDishes.ShowOutline = False
        Me.cmdSplitDishes.Size = New System.Drawing.Size(140, 45)
        Me.cmdSplitDishes.TabIndex = 536
        Me.cmdSplitDishes.Tag = ""
        Me.cmdSplitDishes.Text = "Split Dishes"
        Me.cmdSplitDishes.UseAppStyling = False
        Me.cmdSplitDishes.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdSplitDishes.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdSplitDishes.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnTips
        '
        Appearance9.BackColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(120, Byte), Integer), CType(CType(36, Byte), Integer))
        Appearance9.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(30, Byte), Integer))
        Appearance9.BackGradientStyle = Infragistics.Win.GradientStyle.VerticalBump
        Appearance9.BorderColor = System.Drawing.Color.FromArgb(CType(CType(166, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance9.BorderColor2 = System.Drawing.Color.Maroon
        Appearance9.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance9.ForeColor = System.Drawing.Color.White
        Me.ubtnTips.Appearance = Appearance9
        Me.ubtnTips.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance10.BackColor = System.Drawing.Color.PowderBlue
        Appearance10.BackColor2 = System.Drawing.Color.Aqua
        Appearance10.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance10.ForeColor = System.Drawing.Color.Black
        Me.ubtnTips.HotTrackAppearance = Appearance10
        Me.ubtnTips.Location = New System.Drawing.Point(223, 69)
        Me.ubtnTips.Name = "ubtnTips"
        Me.ubtnTips.ShowFocusRect = False
        Me.ubtnTips.ShowOutline = False
        Me.ubtnTips.Size = New System.Drawing.Size(100, 29)
        Me.ubtnTips.TabIndex = 533
        Me.ubtnTips.Text = "Tips -->"
        Me.ubtnTips.UseAppStyling = False
        Me.ubtnTips.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnTips.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.ubtnTips.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtTips
        '
        Me.txtTips.BackColor = System.Drawing.Color.Beige
        Me.txtTips.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTips.ForeColor = System.Drawing.Color.Navy
        Me.txtTips.Location = New System.Drawing.Point(329, 69)
        Me.txtTips.MaxLength = 7
        Me.txtTips.Name = "txtTips"
        Me.txtTips.Size = New System.Drawing.Size(100, 29)
        Me.txtTips.TabIndex = 531
        Me.txtTips.Text = "0.00"
        Me.txtTips.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.SlateGray
        Me.Label10.Location = New System.Drawing.Point(325, 47)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(48, 19)
        Me.Label10.TabIndex = 532
        Me.Label10.Text = "Tips:"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'cmdTender20
        '
        Appearance11.BackColor = System.Drawing.Color.SlateBlue
        Appearance11.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance11.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance11.BorderColor = System.Drawing.Color.MediumPurple
        Appearance11.BorderColor2 = System.Drawing.Color.Maroon
        Appearance11.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance11.ForeColor = System.Drawing.Color.White
        Appearance11.ImageHAlign = Infragistics.Win.HAlign.Left
        Appearance11.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance11.TextVAlignAsString = "Middle"
        Me.cmdTender20.Appearance = Appearance11
        Me.cmdTender20.Font = New System.Drawing.Font("Arial", 20.0!)
        Appearance12.BackColor = System.Drawing.Color.DarkOrange
        Appearance12.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance12.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance12.ForeColor = System.Drawing.Color.Black
        Me.cmdTender20.HotTrackAppearance = Appearance12
        Me.cmdTender20.ImageSize = New System.Drawing.Size(24, 24)
        Me.cmdTender20.Location = New System.Drawing.Point(223, 155)
        Me.cmdTender20.Name = "cmdTender20"
        Appearance13.BackColor = System.Drawing.Color.OrangeRed
        Appearance13.BackColor2 = System.Drawing.Color.Tomato
        Appearance13.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdTender20.PressedAppearance = Appearance13
        Me.cmdTender20.ShowFocusRect = False
        Me.cmdTender20.ShowOutline = False
        Me.cmdTender20.Size = New System.Drawing.Size(100, 45)
        Me.cmdTender20.TabIndex = 530
        Me.cmdTender20.Tag = "20.00"
        Me.cmdTender20.Text = "£20"
        Me.cmdTender20.UseAppStyling = False
        Me.cmdTender20.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTender20.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTender20.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdTender10
        '
        Appearance14.BackColor = System.Drawing.Color.SlateBlue
        Appearance14.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(164, Byte), Integer), CType(CType(185, Byte), Integer))
        Appearance14.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance14.BorderColor = System.Drawing.Color.MediumPurple
        Appearance14.BorderColor2 = System.Drawing.Color.Maroon
        Appearance14.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance14.ForeColor = System.Drawing.Color.White
        Appearance14.ImageHAlign = Infragistics.Win.HAlign.Left
        Appearance14.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance14.TextVAlignAsString = "Middle"
        Me.cmdTender10.Appearance = Appearance14
        Me.cmdTender10.Font = New System.Drawing.Font("Arial", 20.0!)
        Appearance15.BackColor = System.Drawing.Color.DarkOrange
        Appearance15.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance15.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance15.ForeColor = System.Drawing.Color.Black
        Me.cmdTender10.HotTrackAppearance = Appearance15
        Me.cmdTender10.ImageSize = New System.Drawing.Size(24, 24)
        Me.cmdTender10.Location = New System.Drawing.Point(223, 104)
        Me.cmdTender10.Name = "cmdTender10"
        Appearance16.BackColor = System.Drawing.Color.OrangeRed
        Appearance16.BackColor2 = System.Drawing.Color.Tomato
        Appearance16.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdTender10.PressedAppearance = Appearance16
        Me.cmdTender10.ShowFocusRect = False
        Me.cmdTender10.ShowOutline = False
        Me.cmdTender10.Size = New System.Drawing.Size(100, 45)
        Me.cmdTender10.TabIndex = 529
        Me.cmdTender10.Tag = "10.00"
        Me.cmdTender10.Text = "£10"
        Me.cmdTender10.UseAppStyling = False
        Me.cmdTender10.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTender10.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTender10.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdTender50
        '
        Appearance17.BackColor = System.Drawing.Color.SlateBlue
        Appearance17.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance17.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance17.BorderColor = System.Drawing.Color.MediumPurple
        Appearance17.BorderColor2 = System.Drawing.Color.Maroon
        Appearance17.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance17.ForeColor = System.Drawing.Color.White
        Appearance17.ImageHAlign = Infragistics.Win.HAlign.Left
        Appearance17.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance17.TextVAlignAsString = "Middle"
        Me.cmdTender50.Appearance = Appearance17
        Me.cmdTender50.Font = New System.Drawing.Font("Arial", 20.0!)
        Appearance18.BackColor = System.Drawing.Color.DarkOrange
        Appearance18.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance18.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance18.ForeColor = System.Drawing.Color.Black
        Me.cmdTender50.HotTrackAppearance = Appearance18
        Me.cmdTender50.ImageSize = New System.Drawing.Size(24, 24)
        Me.cmdTender50.Location = New System.Drawing.Point(223, 206)
        Me.cmdTender50.Name = "cmdTender50"
        Appearance19.BackColor = System.Drawing.Color.OrangeRed
        Appearance19.BackColor2 = System.Drawing.Color.Tomato
        Appearance19.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdTender50.PressedAppearance = Appearance19
        Me.cmdTender50.ShowFocusRect = False
        Me.cmdTender50.ShowOutline = False
        Me.cmdTender50.Size = New System.Drawing.Size(100, 45)
        Me.cmdTender50.TabIndex = 528
        Me.cmdTender50.Tag = "50.00"
        Me.cmdTender50.Text = "£50"
        Me.cmdTender50.UseAppStyling = False
        Me.cmdTender50.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTender50.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTender50.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdTenderCard
        '
        Appearance20.BackColor = System.Drawing.Color.SlateBlue
        Appearance20.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance20.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance20.BorderColor = System.Drawing.Color.MediumPurple
        Appearance20.BorderColor2 = System.Drawing.Color.Maroon
        Appearance20.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance20.ForeColor = System.Drawing.Color.White
        Appearance20.ImageHAlign = Infragistics.Win.HAlign.Left
        Appearance20.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance20.TextVAlignAsString = "Middle"
        Me.cmdTenderCard.Appearance = Appearance20
        Me.cmdTenderCard.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance21.BackColor = System.Drawing.Color.DarkOrange
        Appearance21.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance21.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance21.ForeColor = System.Drawing.Color.Black
        Me.cmdTenderCard.HotTrackAppearance = Appearance21
        Me.cmdTenderCard.ImageSize = New System.Drawing.Size(24, 24)
        Me.cmdTenderCard.Location = New System.Drawing.Point(329, 155)
        Me.cmdTenderCard.Name = "cmdTenderCard"
        Appearance22.BackColor = System.Drawing.Color.OrangeRed
        Appearance22.BackColor2 = System.Drawing.Color.Tomato
        Appearance22.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdTenderCard.PressedAppearance = Appearance22
        Me.cmdTenderCard.ShowFocusRect = False
        Me.cmdTenderCard.ShowOutline = False
        Me.cmdTenderCard.Size = New System.Drawing.Size(100, 45)
        Me.cmdTenderCard.TabIndex = 527
        Me.cmdTenderCard.Tag = "0"
        Me.cmdTenderCard.Text = "Card"
        Me.cmdTenderCard.UseAppStyling = False
        Me.cmdTenderCard.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTenderCard.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTenderCard.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdTenderCash
        '
        Appearance23.BackColor = System.Drawing.Color.SlateBlue
        Appearance23.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance23.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance23.BorderColor = System.Drawing.Color.MediumPurple
        Appearance23.BorderColor2 = System.Drawing.Color.Maroon
        Appearance23.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance23.ForeColor = System.Drawing.Color.White
        Appearance23.ImageHAlign = Infragistics.Win.HAlign.Left
        Appearance23.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance23.TextVAlignAsString = "Middle"
        Me.cmdTenderCash.Appearance = Appearance23
        Me.cmdTenderCash.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance24.BackColor = System.Drawing.Color.DarkOrange
        Appearance24.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance24.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance24.ForeColor = System.Drawing.Color.Black
        Me.cmdTenderCash.HotTrackAppearance = Appearance24
        Me.cmdTenderCash.ImageSize = New System.Drawing.Size(24, 24)
        Me.cmdTenderCash.Location = New System.Drawing.Point(329, 104)
        Me.cmdTenderCash.Name = "cmdTenderCash"
        Appearance25.BackColor = System.Drawing.Color.OrangeRed
        Appearance25.BackColor2 = System.Drawing.Color.Tomato
        Appearance25.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdTenderCash.PressedAppearance = Appearance25
        Me.cmdTenderCash.ShowFocusRect = False
        Me.cmdTenderCash.ShowOutline = False
        Me.cmdTenderCash.Size = New System.Drawing.Size(100, 45)
        Me.cmdTenderCash.TabIndex = 526
        Me.cmdTenderCash.Tag = "0"
        Me.cmdTenderCash.Text = "Cash"
        Me.cmdTenderCash.UseAppStyling = False
        Me.cmdTenderCash.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTenderCash.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTenderCash.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraPanel3
        '
        Appearance26.BackColor = System.Drawing.Color.Transparent
        Me.UltraPanel3.Appearance = Appearance26
        Me.UltraPanel3.BorderStyle = Infragistics.Win.UIElementBorderStyle.Etched
        '
        'UltraPanel3.ClientArea
        '
        Me.UltraPanel3.ClientArea.Controls.Add(Me.ubtnTips)
        Me.UltraPanel3.ClientArea.Controls.Add(Me.txtTips)
        Me.UltraPanel3.ClientArea.Controls.Add(Me.Label10)
        Me.UltraPanel3.ClientArea.Controls.Add(Me.cmdTender20)
        Me.UltraPanel3.ClientArea.Controls.Add(Me.cmdTender10)
        Me.UltraPanel3.ClientArea.Controls.Add(Me.cmdTender50)
        Me.UltraPanel3.ClientArea.Controls.Add(Me.cmdTenderCard)
        Me.UltraPanel3.ClientArea.Controls.Add(Me.cmdTenderCash)
        Me.UltraPanel3.ClientArea.Controls.Add(Me.cmdClearTender)
        Me.UltraPanel3.ClientArea.Controls.Add(Me.cmdTenderOther)
        Me.UltraPanel3.ClientArea.Controls.Add(Me.cmdTenderExact)
        Me.UltraPanel3.ClientArea.Controls.Add(Me.cmdNumDot)
        Me.UltraPanel3.ClientArea.Controls.Add(Me.txtChange)
        Me.UltraPanel3.ClientArea.Controls.Add(Me.cmdNum0)
        Me.UltraPanel3.ClientArea.Controls.Add(Me.cmdNum3)
        Me.UltraPanel3.ClientArea.Controls.Add(Me.Label3)
        Me.UltraPanel3.ClientArea.Controls.Add(Me.cmdNum2)
        Me.UltraPanel3.ClientArea.Controls.Add(Me.cmdNum1)
        Me.UltraPanel3.ClientArea.Controls.Add(Me.txtTendered)
        Me.UltraPanel3.ClientArea.Controls.Add(Me.cmdNum6)
        Me.UltraPanel3.ClientArea.Controls.Add(Me.cmdNum5)
        Me.UltraPanel3.ClientArea.Controls.Add(Me.Label2)
        Me.UltraPanel3.ClientArea.Controls.Add(Me.cmdNum4)
        Me.UltraPanel3.ClientArea.Controls.Add(Me.cmdNum9)
        Me.UltraPanel3.ClientArea.Controls.Add(Me.txtBillTotal)
        Me.UltraPanel3.ClientArea.Controls.Add(Me.cmdNum8)
        Me.UltraPanel3.ClientArea.Controls.Add(Me.cmdNum7)
        Me.UltraPanel3.ClientArea.Controls.Add(Me.Label1)
        Me.UltraPanel3.Location = New System.Drawing.Point(538, 14)
        Me.UltraPanel3.Name = "UltraPanel3"
        Me.UltraPanel3.Size = New System.Drawing.Size(443, 315)
        Me.UltraPanel3.TabIndex = 559
        '
        'cmdClearTender
        '
        Appearance27.BackColor = System.Drawing.Color.SlateBlue
        Appearance27.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance27.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance27.BorderColor = System.Drawing.Color.MediumPurple
        Appearance27.BorderColor2 = System.Drawing.Color.Maroon
        Appearance27.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance27.ForeColor = System.Drawing.Color.White
        Appearance27.TextVAlignAsString = "Middle"
        Me.cmdClearTender.Appearance = Appearance27
        Me.cmdClearTender.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance28.BackColor = System.Drawing.Color.DarkOrange
        Appearance28.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance28.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance28.ForeColor = System.Drawing.Color.Black
        Me.cmdClearTender.HotTrackAppearance = Appearance28
        Me.cmdClearTender.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdClearTender.Location = New System.Drawing.Point(329, 257)
        Me.cmdClearTender.Name = "cmdClearTender"
        Appearance29.BackColor = System.Drawing.Color.OrangeRed
        Appearance29.BackColor2 = System.Drawing.Color.Tomato
        Appearance29.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdClearTender.PressedAppearance = Appearance29
        Me.cmdClearTender.ShowFocusRect = False
        Me.cmdClearTender.ShowOutline = False
        Me.cmdClearTender.Size = New System.Drawing.Size(100, 45)
        Me.cmdClearTender.TabIndex = 522
        Me.cmdClearTender.Tag = ""
        Me.cmdClearTender.Text = "Clear"
        Me.cmdClearTender.UseAppStyling = False
        Me.cmdClearTender.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdClearTender.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdClearTender.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdTenderOther
        '
        Appearance30.BackColor = System.Drawing.Color.SlateBlue
        Appearance30.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance30.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance30.BorderColor = System.Drawing.Color.MediumPurple
        Appearance30.BorderColor2 = System.Drawing.Color.Maroon
        Appearance30.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance30.ForeColor = System.Drawing.Color.White
        Appearance30.ImageHAlign = Infragistics.Win.HAlign.Left
        Appearance30.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance30.TextVAlignAsString = "Middle"
        Me.cmdTenderOther.Appearance = Appearance30
        Me.cmdTenderOther.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance31.BackColor = System.Drawing.Color.DarkOrange
        Appearance31.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance31.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance31.ForeColor = System.Drawing.Color.Black
        Me.cmdTenderOther.HotTrackAppearance = Appearance31
        Me.cmdTenderOther.ImageSize = New System.Drawing.Size(24, 24)
        Me.cmdTenderOther.Location = New System.Drawing.Point(329, 206)
        Me.cmdTenderOther.Name = "cmdTenderOther"
        Appearance32.BackColor = System.Drawing.Color.OrangeRed
        Appearance32.BackColor2 = System.Drawing.Color.Tomato
        Appearance32.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdTenderOther.PressedAppearance = Appearance32
        Me.cmdTenderOther.ShowFocusRect = False
        Me.cmdTenderOther.ShowOutline = False
        Me.cmdTenderOther.Size = New System.Drawing.Size(100, 45)
        Me.cmdTenderOther.TabIndex = 521
        Me.cmdTenderOther.Tag = "0"
        Me.cmdTenderOther.Text = "Other"
        Me.cmdTenderOther.UseAppStyling = False
        Me.cmdTenderOther.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTenderOther.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTenderOther.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdTenderExact
        '
        Appearance33.BackColor = System.Drawing.Color.SlateBlue
        Appearance33.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance33.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance33.BorderColor = System.Drawing.Color.MediumPurple
        Appearance33.BorderColor2 = System.Drawing.Color.Maroon
        Appearance33.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance33.ForeColor = System.Drawing.Color.White
        Appearance33.TextVAlignAsString = "Middle"
        Me.cmdTenderExact.Appearance = Appearance33
        Me.cmdTenderExact.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance34.BackColor = System.Drawing.Color.DarkOrange
        Appearance34.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance34.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance34.ForeColor = System.Drawing.Color.Black
        Me.cmdTenderExact.HotTrackAppearance = Appearance34
        Me.cmdTenderExact.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdTenderExact.Location = New System.Drawing.Point(223, 257)
        Me.cmdTenderExact.Name = "cmdTenderExact"
        Appearance35.BackColor = System.Drawing.Color.OrangeRed
        Appearance35.BackColor2 = System.Drawing.Color.Tomato
        Appearance35.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdTenderExact.PressedAppearance = Appearance35
        Me.cmdTenderExact.ShowFocusRect = False
        Me.cmdTenderExact.ShowOutline = False
        Me.cmdTenderExact.Size = New System.Drawing.Size(100, 45)
        Me.cmdTenderExact.TabIndex = 518
        Me.cmdTenderExact.Tag = ""
        Me.cmdTenderExact.Text = "Exact"
        Me.cmdTenderExact.UseAppStyling = False
        Me.cmdTenderExact.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTenderExact.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTenderExact.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdNumDot
        '
        Appearance36.BackColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance36.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance36.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance36.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance36.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance36.BorderColor2 = System.Drawing.Color.Maroon
        Appearance36.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance36.ForeColor = System.Drawing.Color.White
        Appearance36.TextVAlignAsString = "Middle"
        Me.cmdNumDot.Appearance = Appearance36
        Me.cmdNumDot.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance37.BackColor = System.Drawing.Color.DarkOrange
        Appearance37.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance37.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance37.ForeColor = System.Drawing.Color.Black
        Me.cmdNumDot.HotTrackAppearance = Appearance37
        Me.cmdNumDot.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdNumDot.Location = New System.Drawing.Point(10, 257)
        Me.cmdNumDot.Name = "cmdNumDot"
        Appearance38.BackColor = System.Drawing.Color.OrangeRed
        Appearance38.BackColor2 = System.Drawing.Color.Tomato
        Appearance38.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdNumDot.PressedAppearance = Appearance38
        Me.cmdNumDot.ShowFocusRect = False
        Me.cmdNumDot.ShowOutline = False
        Me.cmdNumDot.Size = New System.Drawing.Size(65, 45)
        Me.cmdNumDot.TabIndex = 514
        Me.cmdNumDot.Tag = ""
        Me.cmdNumDot.Text = "."
        Me.cmdNumDot.UseAppStyling = False
        Me.cmdNumDot.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdNumDot.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdNumDot.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtChange
        '
        Me.txtChange.BackColor = System.Drawing.Color.Beige
        Me.txtChange.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtChange.ForeColor = System.Drawing.Color.Navy
        Me.txtChange.Location = New System.Drawing.Point(117, 69)
        Me.txtChange.MaxLength = 7
        Me.txtChange.Name = "txtChange"
        Me.txtChange.Size = New System.Drawing.Size(100, 29)
        Me.txtChange.TabIndex = 470
        Me.txtChange.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'cmdNum0
        '
        Appearance39.BackColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance39.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance39.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance39.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance39.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance39.BorderColor2 = System.Drawing.Color.Maroon
        Appearance39.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance39.ForeColor = System.Drawing.Color.White
        Appearance39.TextVAlignAsString = "Middle"
        Me.cmdNum0.Appearance = Appearance39
        Me.cmdNum0.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance40.BackColor = System.Drawing.Color.DarkOrange
        Appearance40.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance40.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance40.ForeColor = System.Drawing.Color.Black
        Me.cmdNum0.HotTrackAppearance = Appearance40
        Me.cmdNum0.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdNum0.Location = New System.Drawing.Point(81, 257)
        Me.cmdNum0.Name = "cmdNum0"
        Appearance41.BackColor = System.Drawing.Color.OrangeRed
        Appearance41.BackColor2 = System.Drawing.Color.Tomato
        Appearance41.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdNum0.PressedAppearance = Appearance41
        Me.cmdNum0.ShowFocusRect = False
        Me.cmdNum0.ShowOutline = False
        Me.cmdNum0.Size = New System.Drawing.Size(136, 45)
        Me.cmdNum0.TabIndex = 513
        Me.cmdNum0.Tag = ""
        Me.cmdNum0.Text = "0"
        Me.cmdNum0.UseAppStyling = False
        Me.cmdNum0.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdNum0.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdNum0.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdNum3
        '
        Appearance42.BackColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance42.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance42.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance42.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance42.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance42.BorderColor2 = System.Drawing.Color.Maroon
        Appearance42.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance42.ForeColor = System.Drawing.Color.White
        Appearance42.TextVAlignAsString = "Middle"
        Me.cmdNum3.Appearance = Appearance42
        Me.cmdNum3.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance43.BackColor = System.Drawing.Color.DarkOrange
        Appearance43.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance43.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance43.ForeColor = System.Drawing.Color.Black
        Me.cmdNum3.HotTrackAppearance = Appearance43
        Me.cmdNum3.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdNum3.Location = New System.Drawing.Point(152, 206)
        Me.cmdNum3.Name = "cmdNum3"
        Appearance44.BackColor = System.Drawing.Color.OrangeRed
        Appearance44.BackColor2 = System.Drawing.Color.Tomato
        Appearance44.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdNum3.PressedAppearance = Appearance44
        Me.cmdNum3.ShowFocusRect = False
        Me.cmdNum3.ShowOutline = False
        Me.cmdNum3.Size = New System.Drawing.Size(65, 45)
        Me.cmdNum3.TabIndex = 512
        Me.cmdNum3.Tag = ""
        Me.cmdNum3.Text = "3"
        Me.cmdNum3.UseAppStyling = False
        Me.cmdNum3.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdNum3.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdNum3.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.SlateGray
        Me.Label3.Location = New System.Drawing.Point(12, 72)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(99, 18)
        Me.Label3.TabIndex = 471
        Me.Label3.Text = "Change:"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'cmdNum2
        '
        Appearance45.BackColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance45.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance45.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance45.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance45.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance45.BorderColor2 = System.Drawing.Color.Maroon
        Appearance45.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance45.ForeColor = System.Drawing.Color.White
        Appearance45.TextVAlignAsString = "Middle"
        Me.cmdNum2.Appearance = Appearance45
        Me.cmdNum2.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance46.BackColor = System.Drawing.Color.DarkOrange
        Appearance46.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance46.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance46.ForeColor = System.Drawing.Color.Black
        Me.cmdNum2.HotTrackAppearance = Appearance46
        Me.cmdNum2.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdNum2.Location = New System.Drawing.Point(81, 206)
        Me.cmdNum2.Name = "cmdNum2"
        Appearance47.BackColor = System.Drawing.Color.OrangeRed
        Appearance47.BackColor2 = System.Drawing.Color.Tomato
        Appearance47.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdNum2.PressedAppearance = Appearance47
        Me.cmdNum2.ShowFocusRect = False
        Me.cmdNum2.ShowOutline = False
        Me.cmdNum2.Size = New System.Drawing.Size(65, 45)
        Me.cmdNum2.TabIndex = 511
        Me.cmdNum2.Tag = ""
        Me.cmdNum2.Text = "2"
        Me.cmdNum2.UseAppStyling = False
        Me.cmdNum2.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdNum2.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdNum2.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdNum1
        '
        Appearance48.BackColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance48.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance48.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance48.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance48.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance48.BorderColor2 = System.Drawing.Color.Maroon
        Appearance48.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance48.ForeColor = System.Drawing.Color.White
        Appearance48.TextVAlignAsString = "Middle"
        Me.cmdNum1.Appearance = Appearance48
        Me.cmdNum1.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance49.BackColor = System.Drawing.Color.DarkOrange
        Appearance49.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance49.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance49.ForeColor = System.Drawing.Color.Black
        Me.cmdNum1.HotTrackAppearance = Appearance49
        Me.cmdNum1.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdNum1.Location = New System.Drawing.Point(10, 206)
        Me.cmdNum1.Name = "cmdNum1"
        Appearance50.BackColor = System.Drawing.Color.OrangeRed
        Appearance50.BackColor2 = System.Drawing.Color.Tomato
        Appearance50.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdNum1.PressedAppearance = Appearance50
        Me.cmdNum1.ShowFocusRect = False
        Me.cmdNum1.ShowOutline = False
        Me.cmdNum1.Size = New System.Drawing.Size(65, 45)
        Me.cmdNum1.TabIndex = 510
        Me.cmdNum1.Tag = ""
        Me.cmdNum1.Text = "1"
        Me.cmdNum1.UseAppStyling = False
        Me.cmdNum1.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdNum1.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdNum1.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtTendered
        '
        Me.txtTendered.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTendered.ForeColor = System.Drawing.Color.Navy
        Me.txtTendered.Location = New System.Drawing.Point(117, 37)
        Me.txtTendered.MaxLength = 7
        Me.txtTendered.Name = "txtTendered"
        Me.txtTendered.Size = New System.Drawing.Size(100, 29)
        Me.txtTendered.TabIndex = 469
        Me.txtTendered.Text = "0.00"
        Me.txtTendered.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'cmdNum6
        '
        Appearance51.BackColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance51.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance51.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance51.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance51.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance51.BorderColor2 = System.Drawing.Color.Maroon
        Appearance51.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance51.ForeColor = System.Drawing.Color.White
        Appearance51.TextVAlignAsString = "Middle"
        Me.cmdNum6.Appearance = Appearance51
        Me.cmdNum6.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance52.BackColor = System.Drawing.Color.DarkOrange
        Appearance52.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance52.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance52.ForeColor = System.Drawing.Color.Black
        Me.cmdNum6.HotTrackAppearance = Appearance52
        Me.cmdNum6.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdNum6.Location = New System.Drawing.Point(152, 155)
        Me.cmdNum6.Name = "cmdNum6"
        Appearance53.BackColor = System.Drawing.Color.OrangeRed
        Appearance53.BackColor2 = System.Drawing.Color.Tomato
        Appearance53.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdNum6.PressedAppearance = Appearance53
        Me.cmdNum6.ShowFocusRect = False
        Me.cmdNum6.ShowOutline = False
        Me.cmdNum6.Size = New System.Drawing.Size(65, 45)
        Me.cmdNum6.TabIndex = 509
        Me.cmdNum6.Tag = ""
        Me.cmdNum6.Text = "6"
        Me.cmdNum6.UseAppStyling = False
        Me.cmdNum6.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdNum6.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdNum6.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdNum5
        '
        Appearance54.BackColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance54.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance54.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance54.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance54.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance54.BorderColor2 = System.Drawing.Color.Maroon
        Appearance54.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance54.ForeColor = System.Drawing.Color.White
        Appearance54.TextVAlignAsString = "Middle"
        Me.cmdNum5.Appearance = Appearance54
        Me.cmdNum5.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance55.BackColor = System.Drawing.Color.DarkOrange
        Appearance55.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance55.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance55.ForeColor = System.Drawing.Color.Black
        Me.cmdNum5.HotTrackAppearance = Appearance55
        Me.cmdNum5.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdNum5.Location = New System.Drawing.Point(81, 155)
        Me.cmdNum5.Name = "cmdNum5"
        Appearance56.BackColor = System.Drawing.Color.OrangeRed
        Appearance56.BackColor2 = System.Drawing.Color.Tomato
        Appearance56.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdNum5.PressedAppearance = Appearance56
        Me.cmdNum5.ShowFocusRect = False
        Me.cmdNum5.ShowOutline = False
        Me.cmdNum5.Size = New System.Drawing.Size(65, 45)
        Me.cmdNum5.TabIndex = 508
        Me.cmdNum5.Tag = ""
        Me.cmdNum5.Text = "5"
        Me.cmdNum5.UseAppStyling = False
        Me.cmdNum5.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdNum5.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdNum5.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.SlateGray
        Me.Label2.Location = New System.Drawing.Point(12, 40)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(99, 18)
        Me.Label2.TabIndex = 469
        Me.Label2.Text = "Tendered:"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'cmdNum4
        '
        Appearance57.BackColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance57.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance57.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance57.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance57.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance57.BorderColor2 = System.Drawing.Color.Maroon
        Appearance57.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance57.ForeColor = System.Drawing.Color.White
        Appearance57.TextVAlignAsString = "Middle"
        Me.cmdNum4.Appearance = Appearance57
        Me.cmdNum4.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance58.BackColor = System.Drawing.Color.DarkOrange
        Appearance58.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance58.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance58.ForeColor = System.Drawing.Color.Black
        Me.cmdNum4.HotTrackAppearance = Appearance58
        Me.cmdNum4.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdNum4.Location = New System.Drawing.Point(10, 155)
        Me.cmdNum4.Name = "cmdNum4"
        Appearance59.BackColor = System.Drawing.Color.OrangeRed
        Appearance59.BackColor2 = System.Drawing.Color.Tomato
        Appearance59.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdNum4.PressedAppearance = Appearance59
        Me.cmdNum4.ShowFocusRect = False
        Me.cmdNum4.ShowOutline = False
        Me.cmdNum4.Size = New System.Drawing.Size(65, 45)
        Me.cmdNum4.TabIndex = 507
        Me.cmdNum4.Tag = ""
        Me.cmdNum4.Text = "4"
        Me.cmdNum4.UseAppStyling = False
        Me.cmdNum4.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdNum4.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdNum4.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdNum9
        '
        Appearance60.BackColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance60.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance60.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance60.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance60.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance60.BorderColor2 = System.Drawing.Color.Maroon
        Appearance60.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance60.ForeColor = System.Drawing.Color.White
        Appearance60.TextVAlignAsString = "Middle"
        Me.cmdNum9.Appearance = Appearance60
        Me.cmdNum9.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance61.BackColor = System.Drawing.Color.DarkOrange
        Appearance61.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance61.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance61.ForeColor = System.Drawing.Color.Black
        Me.cmdNum9.HotTrackAppearance = Appearance61
        Me.cmdNum9.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdNum9.Location = New System.Drawing.Point(152, 104)
        Me.cmdNum9.Name = "cmdNum9"
        Appearance62.BackColor = System.Drawing.Color.OrangeRed
        Appearance62.BackColor2 = System.Drawing.Color.Tomato
        Appearance62.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdNum9.PressedAppearance = Appearance62
        Me.cmdNum9.ShowFocusRect = False
        Me.cmdNum9.ShowOutline = False
        Me.cmdNum9.Size = New System.Drawing.Size(65, 45)
        Me.cmdNum9.TabIndex = 506
        Me.cmdNum9.Tag = ""
        Me.cmdNum9.Text = "9"
        Me.cmdNum9.UseAppStyling = False
        Me.cmdNum9.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdNum9.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdNum9.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtBillTotal
        '
        Me.txtBillTotal.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBillTotal.ForeColor = System.Drawing.Color.Navy
        Me.txtBillTotal.Location = New System.Drawing.Point(117, 5)
        Me.txtBillTotal.MaxLength = 10
        Me.txtBillTotal.Name = "txtBillTotal"
        Me.txtBillTotal.Size = New System.Drawing.Size(100, 29)
        Me.txtBillTotal.TabIndex = 468
        Me.txtBillTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'cmdNum8
        '
        Appearance63.BackColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance63.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance63.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance63.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance63.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance63.BorderColor2 = System.Drawing.Color.Maroon
        Appearance63.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance63.ForeColor = System.Drawing.Color.White
        Appearance63.TextVAlignAsString = "Middle"
        Me.cmdNum8.Appearance = Appearance63
        Me.cmdNum8.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance64.BackColor = System.Drawing.Color.DarkOrange
        Appearance64.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance64.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance64.ForeColor = System.Drawing.Color.Black
        Me.cmdNum8.HotTrackAppearance = Appearance64
        Me.cmdNum8.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdNum8.Location = New System.Drawing.Point(81, 104)
        Me.cmdNum8.Name = "cmdNum8"
        Appearance65.BackColor = System.Drawing.Color.OrangeRed
        Appearance65.BackColor2 = System.Drawing.Color.Tomato
        Appearance65.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdNum8.PressedAppearance = Appearance65
        Me.cmdNum8.ShowFocusRect = False
        Me.cmdNum8.ShowOutline = False
        Me.cmdNum8.Size = New System.Drawing.Size(65, 45)
        Me.cmdNum8.TabIndex = 505
        Me.cmdNum8.Tag = ""
        Me.cmdNum8.Text = "8"
        Me.cmdNum8.UseAppStyling = False
        Me.cmdNum8.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdNum8.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdNum8.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdNum7
        '
        Appearance66.BackColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance66.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance66.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance66.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance66.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance66.BorderColor2 = System.Drawing.Color.Maroon
        Appearance66.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance66.ForeColor = System.Drawing.Color.White
        Appearance66.TextVAlignAsString = "Middle"
        Me.cmdNum7.Appearance = Appearance66
        Me.cmdNum7.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance67.BackColor = System.Drawing.Color.DarkOrange
        Appearance67.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance67.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance67.ForeColor = System.Drawing.Color.Black
        Me.cmdNum7.HotTrackAppearance = Appearance67
        Me.cmdNum7.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdNum7.Location = New System.Drawing.Point(10, 104)
        Me.cmdNum7.Name = "cmdNum7"
        Appearance68.BackColor = System.Drawing.Color.OrangeRed
        Appearance68.BackColor2 = System.Drawing.Color.Tomato
        Appearance68.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdNum7.PressedAppearance = Appearance68
        Me.cmdNum7.ShowFocusRect = False
        Me.cmdNum7.ShowOutline = False
        Me.cmdNum7.Size = New System.Drawing.Size(65, 45)
        Me.cmdNum7.TabIndex = 504
        Me.cmdNum7.Tag = ""
        Me.cmdNum7.Text = "7"
        Me.cmdNum7.UseAppStyling = False
        Me.cmdNum7.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdNum7.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdNum7.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.SlateGray
        Me.Label1.Location = New System.Drawing.Point(12, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(99, 18)
        Me.Label1.TabIndex = 467
        Me.Label1.Text = "To Pay:"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'cmdKBTime
        '
        Appearance69.BackColor = System.Drawing.Color.Transparent
        Appearance69.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance69.BackGradientStyle = Infragistics.Win.GradientStyle.None
        Appearance69.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance69.BorderColor = System.Drawing.Color.Transparent
        Appearance69.BorderColor2 = System.Drawing.Color.Transparent
        Appearance69.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance69.ForeColor = System.Drawing.Color.Black
        Appearance69.Image = CType(resources.GetObject("Appearance69.Image"), Object)
        Appearance69.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance69.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance69.TextVAlignAsString = "Bottom"
        Me.cmdKBTime.Appearance = Appearance69
        Me.cmdKBTime.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdKBTime.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance70.BackColor = System.Drawing.Color.DarkOrange
        Appearance70.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance70.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance70.ForeColor = System.Drawing.Color.Black
        Me.cmdKBTime.HotTrackAppearance = Appearance70
        Me.cmdKBTime.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdKBTime.Location = New System.Drawing.Point(154, 12)
        Me.cmdKBTime.Name = "cmdKBTime"
        Appearance71.BackColor = System.Drawing.Color.Transparent
        Appearance71.BackColor2 = System.Drawing.Color.Transparent
        Me.cmdKBTime.PressedAppearance = Appearance71
        Me.cmdKBTime.ShowFocusRect = False
        Me.cmdKBTime.ShowOutline = False
        Me.cmdKBTime.Size = New System.Drawing.Size(50, 36)
        Me.cmdKBTime.StyleSetName = "StatusBar"
        Me.cmdKBTime.TabIndex = 543
        Me.cmdKBTime.Tag = "Keyboard"
        Me.cmdKBTime.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBTime.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBTime.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdWaiting
        '
        Appearance72.BackColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance72.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance72.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance72.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance72.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance72.BorderColor2 = System.Drawing.Color.Maroon
        Appearance72.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance72.ForeColor = System.Drawing.Color.White
        Appearance72.ImageHAlign = Infragistics.Win.HAlign.Right
        Appearance72.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance72.TextHAlignAsString = "Center"
        Appearance72.TextVAlignAsString = "Middle"
        Me.cmdWaiting.Appearance = Appearance72
        Me.cmdWaiting.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance73.BackColor = System.Drawing.Color.DarkOrange
        Appearance73.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance73.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance73.ForeColor = System.Drawing.Color.Black
        Me.cmdWaiting.HotTrackAppearance = Appearance73
        Me.cmdWaiting.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdWaiting.Location = New System.Drawing.Point(47, 111)
        Me.cmdWaiting.Name = "cmdWaiting"
        Appearance74.BackColor = System.Drawing.Color.OrangeRed
        Appearance74.BackColor2 = System.Drawing.Color.Tomato
        Appearance74.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdWaiting.PressedAppearance = Appearance74
        Me.cmdWaiting.ShowFocusRect = False
        Me.cmdWaiting.ShowOutline = False
        Me.cmdWaiting.Size = New System.Drawing.Size(140, 45)
        Me.cmdWaiting.TabIndex = 498
        Me.cmdWaiting.Tag = "2"
        Me.cmdWaiting.Text = "Waiting"
        Me.cmdWaiting.UseAppStyling = False
        Me.cmdWaiting.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdWaiting.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdWaiting.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdPaid
        '
        Appearance75.BackColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance75.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance75.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance75.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance75.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance75.BorderColor2 = System.Drawing.Color.Maroon
        Appearance75.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance75.ForeColor = System.Drawing.Color.White
        Appearance75.ImageHAlign = Infragistics.Win.HAlign.Right
        Appearance75.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance75.TextHAlignAsString = "Center"
        Appearance75.TextVAlignAsString = "Middle"
        Me.cmdPaid.Appearance = Appearance75
        Me.cmdPaid.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance76.BackColor = System.Drawing.Color.DarkOrange
        Appearance76.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance76.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance76.ForeColor = System.Drawing.Color.Black
        Me.cmdPaid.HotTrackAppearance = Appearance76
        Me.cmdPaid.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdPaid.Location = New System.Drawing.Point(47, 60)
        Me.cmdPaid.Name = "cmdPaid"
        Appearance77.BackColor = System.Drawing.Color.OrangeRed
        Appearance77.BackColor2 = System.Drawing.Color.Tomato
        Appearance77.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdPaid.PressedAppearance = Appearance77
        Me.cmdPaid.ShowFocusRect = False
        Me.cmdPaid.ShowOutline = False
        Me.cmdPaid.Size = New System.Drawing.Size(140, 45)
        Me.cmdPaid.TabIndex = 497
        Me.cmdPaid.Tag = "2"
        Me.cmdPaid.Text = "Paid"
        Me.cmdPaid.UseAppStyling = False
        Me.cmdPaid.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPaid.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPaid.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraPanel2
        '
        Appearance78.BackColor = System.Drawing.Color.Transparent
        Me.UltraPanel2.Appearance = Appearance78
        Me.UltraPanel2.BorderStyle = Infragistics.Win.UIElementBorderStyle.Etched
        '
        'UltraPanel2.ClientArea
        '
        Me.UltraPanel2.ClientArea.Controls.Add(Me.cmdKBTime)
        Me.UltraPanel2.ClientArea.Controls.Add(Me.cmdWaiting)
        Me.UltraPanel2.ClientArea.Controls.Add(Me.cmdPaid)
        Me.UltraPanel2.ClientArea.Controls.Add(Me.lblTime)
        Me.UltraPanel2.Location = New System.Drawing.Point(13, 14)
        Me.UltraPanel2.Name = "UltraPanel2"
        Me.UltraPanel2.Size = New System.Drawing.Size(239, 173)
        Me.UltraPanel2.TabIndex = 551
        '
        'lblTime
        '
        Me.lblTime.BackColor = System.Drawing.Color.Transparent
        Me.lblTime.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTime.ForeColor = System.Drawing.Color.SlateGray
        Me.lblTime.Location = New System.Drawing.Point(40, 21)
        Me.lblTime.Name = "lblTime"
        Me.lblTime.Size = New System.Drawing.Size(107, 19)
        Me.lblTime.TabIndex = 433
        Me.lblTime.Text = "Time: ASAP"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.SlateGray
        Me.Label4.Location = New System.Drawing.Point(6, 5)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(108, 19)
        Me.Label4.TabIndex = 499
        Me.Label4.Text = "Kitchen Note"
        '
        'cmdClearKitchenNote
        '
        Appearance79.BackColor = System.Drawing.Color.Transparent
        Appearance79.BackColor2 = System.Drawing.Color.Transparent
        Appearance79.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance79.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance79.BorderColor = System.Drawing.Color.Transparent
        Appearance79.BorderColor2 = System.Drawing.Color.Maroon
        Appearance79.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance79.ForeColor = System.Drawing.Color.Black
        Appearance79.Image = CType(resources.GetObject("Appearance79.Image"), Object)
        Appearance79.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance79.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance79.TextVAlignAsString = "Bottom"
        Me.cmdClearKitchenNote.Appearance = Appearance79
        Me.cmdClearKitchenNote.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance80.BackColor = System.Drawing.Color.DarkOrange
        Appearance80.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance80.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance80.ForeColor = System.Drawing.Color.Black
        Me.cmdClearKitchenNote.HotTrackAppearance = Appearance80
        Me.cmdClearKitchenNote.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdClearKitchenNote.Location = New System.Drawing.Point(470, 72)
        Me.cmdClearKitchenNote.Name = "cmdClearKitchenNote"
        Appearance81.BackColor = System.Drawing.Color.OrangeRed
        Appearance81.BackColor2 = System.Drawing.Color.Tomato
        Appearance81.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdClearKitchenNote.PressedAppearance = Appearance81
        Me.cmdClearKitchenNote.ShowFocusRect = False
        Me.cmdClearKitchenNote.ShowOutline = False
        Me.cmdClearKitchenNote.Size = New System.Drawing.Size(35, 35)
        Me.cmdClearKitchenNote.StyleSetName = "StatusBar"
        Me.cmdClearKitchenNote.TabIndex = 501
        Me.cmdClearKitchenNote.Tag = ""
        Me.cmdClearKitchenNote.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdClearKitchenNote.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdClearKitchenNote.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdClearKitchenNote.Visible = False
        '
        'txtKitchenNote
        '
        Me.txtKitchenNote.BackColor = System.Drawing.Color.Beige
        Me.txtKitchenNote.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtKitchenNote.ForeColor = System.Drawing.Color.Black
        Me.txtKitchenNote.Location = New System.Drawing.Point(7, 26)
        Me.txtKitchenNote.MaxLength = 500
        Me.txtKitchenNote.Multiline = True
        Me.txtKitchenNote.Name = "txtKitchenNote"
        Me.txtKitchenNote.Size = New System.Drawing.Size(452, 100)
        Me.txtKitchenNote.TabIndex = 444
        '
        'UltraPanel1
        '
        Appearance82.BackColor = System.Drawing.Color.Transparent
        Me.UltraPanel1.Appearance = Appearance82
        Me.UltraPanel1.BorderStyle = Infragistics.Win.UIElementBorderStyle.Etched
        '
        'UltraPanel1.ClientArea
        '
        Me.UltraPanel1.ClientArea.Controls.Add(Me.cmdKBNote)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.cmdClearKitchenNote)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.txtKitchenNote)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.Label4)
        Me.UltraPanel1.Location = New System.Drawing.Point(13, 193)
        Me.UltraPanel1.Name = "UltraPanel1"
        Me.UltraPanel1.Size = New System.Drawing.Size(519, 136)
        Me.UltraPanel1.TabIndex = 558
        '
        'cmdKBNote
        '
        Appearance83.BackColor = System.Drawing.Color.Transparent
        Appearance83.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance83.BackGradientStyle = Infragistics.Win.GradientStyle.None
        Appearance83.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance83.BorderColor = System.Drawing.Color.Transparent
        Appearance83.BorderColor2 = System.Drawing.Color.Transparent
        Appearance83.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance83.ForeColor = System.Drawing.Color.Black
        Appearance83.Image = CType(resources.GetObject("Appearance83.Image"), Object)
        Appearance83.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance83.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance83.TextVAlignAsString = "Bottom"
        Me.cmdKBNote.Appearance = Appearance83
        Me.cmdKBNote.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdKBNote.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance84.BackColor = System.Drawing.Color.DarkOrange
        Appearance84.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance84.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance84.ForeColor = System.Drawing.Color.Black
        Me.cmdKBNote.HotTrackAppearance = Appearance84
        Me.cmdKBNote.ImageSize = New System.Drawing.Size(42, 25)
        Me.cmdKBNote.Location = New System.Drawing.Point(465, 26)
        Me.cmdKBNote.Name = "cmdKBNote"
        Appearance85.BackColor = System.Drawing.Color.Transparent
        Appearance85.BackColor2 = System.Drawing.Color.Transparent
        Me.cmdKBNote.PressedAppearance = Appearance85
        Me.cmdKBNote.ShowFocusRect = False
        Me.cmdKBNote.ShowOutline = False
        Me.cmdKBNote.Size = New System.Drawing.Size(42, 40)
        Me.cmdKBNote.StyleSetName = "StatusBar"
        Me.cmdKBNote.TabIndex = 596
        Me.cmdKBNote.Tag = "Keyboard"
        Me.cmdKBNote.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBNote.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBNote.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdSaveOrder
        '
        Me.cmdSaveOrder.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Appearance86.BackColor = System.Drawing.Color.Transparent
        Appearance86.BackColor2 = System.Drawing.Color.Transparent
        Appearance86.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance86.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance86.BorderColor = System.Drawing.Color.FromArgb(CType(CType(175, Byte), Integer), CType(CType(215, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance86.BorderColor2 = System.Drawing.Color.Maroon
        Appearance86.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance86.ForeColor = System.Drawing.Color.Black
        Appearance86.Image = CType(resources.GetObject("Appearance86.Image"), Object)
        Appearance86.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance86.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance86.TextVAlignAsString = "Bottom"
        Me.cmdSaveOrder.Appearance = Appearance86
        Me.cmdSaveOrder.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdSaveOrder.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance87.BackColor = System.Drawing.Color.DarkOrange
        Appearance87.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance87.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance87.BorderColor = System.Drawing.Color.Transparent
        Appearance87.ForeColor = System.Drawing.Color.Black
        Me.cmdSaveOrder.HotTrackAppearance = Appearance87
        Me.cmdSaveOrder.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdSaveOrder.Location = New System.Drawing.Point(240, 634)
        Me.cmdSaveOrder.Name = "cmdSaveOrder"
        Appearance88.BackColor = System.Drawing.Color.OrangeRed
        Appearance88.BackColor2 = System.Drawing.Color.Tomato
        Appearance88.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance88.BorderColor = System.Drawing.Color.Transparent
        Me.cmdSaveOrder.PressedAppearance = Appearance88
        Me.cmdSaveOrder.ShowFocusRect = False
        Me.cmdSaveOrder.ShowOutline = False
        Me.cmdSaveOrder.Size = New System.Drawing.Size(70, 39)
        Me.cmdSaveOrder.StyleSetName = "StatusBar"
        Me.cmdSaveOrder.TabIndex = 557
        Me.cmdSaveOrder.Tag = "Save"
        Me.cmdSaveOrder.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdSaveOrder.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdSaveOrder.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdShopCopy
        '
        Me.cmdShopCopy.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Appearance89.BackColor = System.Drawing.Color.Transparent
        Appearance89.BackColor2 = System.Drawing.Color.Transparent
        Appearance89.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance89.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance89.BorderColor = System.Drawing.Color.FromArgb(CType(CType(175, Byte), Integer), CType(CType(215, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance89.BorderColor2 = System.Drawing.Color.Maroon
        Appearance89.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance89.ForeColor = System.Drawing.Color.Black
        Appearance89.Image = CType(resources.GetObject("Appearance89.Image"), Object)
        Appearance89.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance89.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance89.TextVAlignAsString = "Bottom"
        Me.cmdShopCopy.Appearance = Appearance89
        Me.cmdShopCopy.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdShopCopy.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance90.BackColor = System.Drawing.Color.DarkOrange
        Appearance90.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance90.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance90.BorderColor = System.Drawing.Color.Transparent
        Appearance90.ForeColor = System.Drawing.Color.Black
        Me.cmdShopCopy.HotTrackAppearance = Appearance90
        Me.cmdShopCopy.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdShopCopy.Location = New System.Drawing.Point(164, 634)
        Me.cmdShopCopy.Name = "cmdShopCopy"
        Appearance91.BackColor = System.Drawing.Color.OrangeRed
        Appearance91.BackColor2 = System.Drawing.Color.Tomato
        Appearance91.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance91.BorderColor = System.Drawing.Color.Transparent
        Me.cmdShopCopy.PressedAppearance = Appearance91
        Me.cmdShopCopy.ShowFocusRect = False
        Me.cmdShopCopy.ShowOutline = False
        Me.cmdShopCopy.Size = New System.Drawing.Size(70, 39)
        Me.cmdShopCopy.StyleSetName = "StatusBar"
        Me.cmdShopCopy.TabIndex = 556
        Me.cmdShopCopy.Tag = "Shop"
        Me.cmdShopCopy.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdShopCopy.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdShopCopy.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdKitchenCopy
        '
        Me.cmdKitchenCopy.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Appearance92.BackColor = System.Drawing.Color.Transparent
        Appearance92.BackColor2 = System.Drawing.Color.Transparent
        Appearance92.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance92.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance92.BorderColor = System.Drawing.Color.FromArgb(CType(CType(175, Byte), Integer), CType(CType(215, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance92.BorderColor2 = System.Drawing.Color.Maroon
        Appearance92.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance92.ForeColor = System.Drawing.Color.Black
        Appearance92.Image = CType(resources.GetObject("Appearance92.Image"), Object)
        Appearance92.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance92.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance92.TextVAlignAsString = "Bottom"
        Me.cmdKitchenCopy.Appearance = Appearance92
        Me.cmdKitchenCopy.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdKitchenCopy.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance93.BackColor = System.Drawing.Color.DarkOrange
        Appearance93.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance93.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance93.BorderColor = System.Drawing.Color.Transparent
        Appearance93.ForeColor = System.Drawing.Color.Black
        Me.cmdKitchenCopy.HotTrackAppearance = Appearance93
        Me.cmdKitchenCopy.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdKitchenCopy.Location = New System.Drawing.Point(88, 634)
        Me.cmdKitchenCopy.Name = "cmdKitchenCopy"
        Appearance94.BackColor = System.Drawing.Color.OrangeRed
        Appearance94.BackColor2 = System.Drawing.Color.Tomato
        Appearance94.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance94.BorderColor = System.Drawing.Color.Transparent
        Me.cmdKitchenCopy.PressedAppearance = Appearance94
        Me.cmdKitchenCopy.ShowFocusRect = False
        Me.cmdKitchenCopy.ShowOutline = False
        Me.cmdKitchenCopy.Size = New System.Drawing.Size(70, 39)
        Me.cmdKitchenCopy.StyleSetName = "StatusBar"
        Me.cmdKitchenCopy.TabIndex = 555
        Me.cmdKitchenCopy.Tag = "Kitchen"
        Me.cmdKitchenCopy.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKitchenCopy.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKitchenCopy.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdBack
        '
        Me.cmdBack.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Appearance95.BackColor = System.Drawing.Color.Transparent
        Appearance95.BackColor2 = System.Drawing.Color.Transparent
        Appearance95.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance95.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance95.BorderColor = System.Drawing.Color.FromArgb(CType(CType(175, Byte), Integer), CType(CType(215, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance95.BorderColor2 = System.Drawing.Color.Maroon
        Appearance95.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance95.ForeColor = System.Drawing.Color.Black
        Appearance95.Image = CType(resources.GetObject("Appearance95.Image"), Object)
        Appearance95.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance95.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance95.TextVAlignAsString = "Bottom"
        Me.cmdBack.Appearance = Appearance95
        Me.cmdBack.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdBack.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance96.BackColor = System.Drawing.Color.DarkOrange
        Appearance96.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance96.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance96.BorderColor = System.Drawing.Color.Transparent
        Appearance96.ForeColor = System.Drawing.Color.Black
        Me.cmdBack.HotTrackAppearance = Appearance96
        Me.cmdBack.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdBack.Location = New System.Drawing.Point(12, 634)
        Me.cmdBack.Name = "cmdBack"
        Appearance97.BackColor = System.Drawing.Color.OrangeRed
        Appearance97.BackColor2 = System.Drawing.Color.Tomato
        Appearance97.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance97.BorderColor = System.Drawing.Color.Transparent
        Me.cmdBack.PressedAppearance = Appearance97
        Me.cmdBack.ShowFocusRect = False
        Me.cmdBack.ShowOutline = False
        Me.cmdBack.Size = New System.Drawing.Size(70, 39)
        Me.cmdBack.StyleSetName = "StatusBar"
        Me.cmdBack.TabIndex = 554
        Me.cmdBack.Tag = "Back"
        Me.cmdBack.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdBack.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdBack.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdPrintOrder
        '
        Me.cmdPrintOrder.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Appearance98.BackColor = System.Drawing.Color.Transparent
        Appearance98.BackColor2 = System.Drawing.Color.Transparent
        Appearance98.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance98.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance98.BorderColor = System.Drawing.Color.FromArgb(CType(CType(175, Byte), Integer), CType(CType(215, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance98.BorderColor2 = System.Drawing.Color.Maroon
        Appearance98.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance98.ForeColor = System.Drawing.Color.Black
        Appearance98.Image = CType(resources.GetObject("Appearance98.Image"), Object)
        Appearance98.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance98.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance98.TextVAlignAsString = "Bottom"
        Me.cmdPrintOrder.Appearance = Appearance98
        Me.cmdPrintOrder.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdPrintOrder.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance99.BackColor = System.Drawing.Color.DarkOrange
        Appearance99.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance99.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance99.BorderColor = System.Drawing.Color.Transparent
        Appearance99.ForeColor = System.Drawing.Color.Black
        Me.cmdPrintOrder.HotTrackAppearance = Appearance99
        Me.cmdPrintOrder.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdPrintOrder.Location = New System.Drawing.Point(457, 634)
        Me.cmdPrintOrder.Name = "cmdPrintOrder"
        Appearance100.BackColor = System.Drawing.Color.OrangeRed
        Appearance100.BackColor2 = System.Drawing.Color.Tomato
        Appearance100.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance100.BorderColor = System.Drawing.Color.Transparent
        Me.cmdPrintOrder.PressedAppearance = Appearance100
        Me.cmdPrintOrder.ShowFocusRect = False
        Me.cmdPrintOrder.ShowOutline = False
        Me.cmdPrintOrder.Size = New System.Drawing.Size(70, 39)
        Me.cmdPrintOrder.StyleSetName = "StatusBar"
        Me.cmdPrintOrder.TabIndex = 553
        Me.cmdPrintOrder.Tag = "Print"
        Me.cmdPrintOrder.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPrintOrder.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPrintOrder.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdOEHome
        '
        Me.cmdOEHome.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance101.BackColor = System.Drawing.Color.Transparent
        Appearance101.BackColor2 = System.Drawing.Color.Transparent
        Appearance101.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance101.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance101.BorderColor = System.Drawing.Color.FromArgb(CType(CType(175, Byte), Integer), CType(CType(215, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance101.BorderColor2 = System.Drawing.Color.Maroon
        Appearance101.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance101.ForeColor = System.Drawing.Color.Black
        Appearance101.Image = CType(resources.GetObject("Appearance101.Image"), Object)
        Appearance101.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance101.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance101.TextVAlignAsString = "Bottom"
        Me.cmdOEHome.Appearance = Appearance101
        Me.cmdOEHome.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdOEHome.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance102.BackColor = System.Drawing.Color.DarkOrange
        Appearance102.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance102.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance102.BorderColor = System.Drawing.Color.Transparent
        Appearance102.ForeColor = System.Drawing.Color.Black
        Me.cmdOEHome.HotTrackAppearance = Appearance102
        Me.cmdOEHome.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdOEHome.Location = New System.Drawing.Point(902, 634)
        Me.cmdOEHome.Name = "cmdOEHome"
        Appearance103.BackColor = System.Drawing.Color.OrangeRed
        Appearance103.BackColor2 = System.Drawing.Color.Tomato
        Appearance103.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance103.BorderColor = System.Drawing.Color.Transparent
        Me.cmdOEHome.PressedAppearance = Appearance103
        Me.cmdOEHome.ShowFocusRect = False
        Me.cmdOEHome.ShowOutline = False
        Me.cmdOEHome.Size = New System.Drawing.Size(70, 39)
        Me.cmdOEHome.StyleSetName = "StatusBar"
        Me.cmdOEHome.TabIndex = 552
        Me.cmdOEHome.Tag = "Return"
        Me.cmdOEHome.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOEHome.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOEHome.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'frmPayment
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(253, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(253, Byte), Integer))
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(984, 684)
        Me.ControlBox = False
        Me.Controls.Add(Me.upnlCard)
        Me.Controls.Add(Me.UltraPanel3)
        Me.Controls.Add(Me.UltraPanel2)
        Me.Controls.Add(Me.UltraPanel1)
        Me.Controls.Add(Me.cmdSaveOrder)
        Me.Controls.Add(Me.cmdShopCopy)
        Me.Controls.Add(Me.cmdKitchenCopy)
        Me.Controls.Add(Me.cmdBack)
        Me.Controls.Add(Me.cmdPrintOrder)
        Me.Controls.Add(Me.cmdOEHome)
        Me.Controls.Add(Me.UltraLabel1)
        Me.DoubleBuffered = True
        Me.MinimumSize = New System.Drawing.Size(1000, 700)
        Me.Name = "frmPayment"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.upnlCard.ClientArea.ResumeLayout(False)
        Me.upnlCard.ResumeLayout(False)
        Me.UltraPanel3.ClientArea.ResumeLayout(False)
        Me.UltraPanel3.ClientArea.PerformLayout()
        Me.UltraPanel3.ResumeLayout(False)
        Me.UltraPanel2.ClientArea.ResumeLayout(False)
        Me.UltraPanel2.ResumeLayout(False)
        Me.UltraPanel1.ClientArea.ResumeLayout(False)
        Me.UltraPanel1.ClientArea.PerformLayout()
        Me.UltraPanel1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents UltraLabel1 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents cmdSplitPayment As Infragistics.Win.Misc.UltraButton
    Friend WithEvents upnlCard As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents cmdSplitDishes As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnTips As Infragistics.Win.Misc.UltraButton
    Friend WithEvents txtTips As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents cmdTender20 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdTender10 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdTender50 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdTenderCard As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdTenderCash As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraPanel3 As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents cmdClearTender As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdTenderOther As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdTenderExact As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdNumDot As Infragistics.Win.Misc.UltraButton
    Friend WithEvents txtChange As TextBox
    Friend WithEvents cmdNum0 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdNum3 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents Label3 As Label
    Friend WithEvents cmdNum2 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdNum1 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents txtTendered As TextBox
    Friend WithEvents cmdNum6 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdNum5 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents Label2 As Label
    Friend WithEvents cmdNum4 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdNum9 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents txtBillTotal As TextBox
    Friend WithEvents cmdNum8 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdNum7 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents Label1 As Label
    Friend WithEvents cmdKBTime As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdWaiting As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdPaid As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraPanel2 As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents lblTime As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents cmdClearKitchenNote As Infragistics.Win.Misc.UltraButton
    Friend WithEvents txtKitchenNote As TextBox
    Friend WithEvents UltraPanel1 As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents cmdSaveOrder As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdShopCopy As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdKitchenCopy As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdBack As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdPrintOrder As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdOEHome As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdKBNote As Infragistics.Win.Misc.UltraButton
End Class