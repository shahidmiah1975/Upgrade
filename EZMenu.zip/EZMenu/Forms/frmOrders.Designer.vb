﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmOrders
    Inherits EZMenu.frmBaseForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim Appearance7 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraGridBand1 As Infragistics.Win.UltraWinGrid.UltraGridBand = New Infragistics.Win.UltraWinGrid.UltraGridBand("Orders", -1)
        Dim UltraGridColumn1 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("OrderID")
        Dim UltraGridColumn2 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("CustomerID")
        Dim UltraGridColumn3 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("CollectionOrDeliveryTime")
        Dim UltraGridColumn6 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("PaymentMethod")
        Dim UltraGridColumn7 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Driver")
        Dim UltraGridColumn8 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("UserName")
        Dim UltraGridColumn9 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("BillTotal")
        Dim UltraGridColumn10 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("OrderIsPaid")
        Dim UltraGridColumn11 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("CustomerName")
        Dim UltraGridColumn12 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("DeliveryAddress")
        Dim UltraGridColumn13 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Telephone")
        Dim UltraGridColumn14 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("DeliveryAddress1")
        Dim UltraGridColumn15 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("DeliveryAddress2")
        Dim UltraGridColumn16 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("DeliveryAddress3")
        Dim UltraGridColumn17 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("DeliveryPostcode")
        Dim UltraGridColumn18 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("OrderTime")
        Dim UltraGridColumn19 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("OrderDate")
        Dim UltraGridColumn20 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("OrderSource")
        Dim UltraGridColumn21 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("BizId")
        Dim UltraGridColumn4 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("ToPay")
        Dim UltraGridColumn5 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("CustomerIsWaiting")
        Dim Appearance8 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance9 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance10 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance11 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance12 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance13 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance14 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance15 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance16 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance17 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance18 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance19 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance20 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraGridBand2 As Infragistics.Win.UltraWinGrid.UltraGridBand = New Infragistics.Win.UltraWinGrid.UltraGridBand("Table_Bill", -1)
        Dim UltraGridColumn22 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("TabUniqueID")
        Dim UltraGridColumn23 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("NumCust")
        Dim Appearance21 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraGridColumn24 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("BillTotal")
        Dim Appearance22 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraGridColumn25 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("MealTotal")
        Dim Appearance23 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraGridColumn26 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("DrinksTotal")
        Dim Appearance24 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraGridColumn27 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Tips")
        Dim Appearance25 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraGridColumn29 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("TableNumber")
        Dim Appearance26 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraGridColumn30 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("TableStatus")
        Dim UltraGridColumn31 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("PrintedTime")
        Dim UltraGridColumn32 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("TableNote")
        Dim UltraGridColumn33 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("CAPValue")
        Dim UltraGridColumn34 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("EntryTime")
        Dim UltraGridColumn35 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("DiscountAmount")
        Dim UltraGridColumn36 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("ChargeAmount")
        Dim UltraGridColumn37 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("DiscountLabelText")
        Dim UltraGridColumn38 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("ChargeLabelText")
        Dim UltraGridColumn39 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("OrderDate")
        Dim UltraGridColumn40 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("UserName")
        Dim UltraGridColumn41 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("PCash")
        Dim UltraGridColumn42 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("PCard")
        Dim UltraGridColumn43 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("POther")
        Dim UltraGridColumn44 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("TCash")
        Dim UltraGridColumn45 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("TCard")
        Dim UltraGridColumn46 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("TOther")
        Dim Appearance27 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance28 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance29 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance30 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance31 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance32 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance33 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance34 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance35 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance36 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance37 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance38 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance39 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance40 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance41 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance42 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance43 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance44 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance45 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance46 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance47 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance48 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance49 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance50 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance51 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance52 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance53 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance54 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance55 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance56 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance57 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance58 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance59 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance60 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance61 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance62 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance63 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance64 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance65 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance66 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance67 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance68 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance1 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmOrders))
        Dim Appearance2 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance3 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance69 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance70 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance71 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance4 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance5 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance6 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance72 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance73 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance74 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Me.ugdOrderGrid = New Infragistics.Win.UltraWinGrid.UltraGrid()
        Me.OrdersBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.EZMenuDataSet = New EZMenu.EZMenuDataSet()
        Me.EZMenuDataSetBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.OrdersTableAdapter = New EZMenu.EZMenuDataSetTableAdapters.OrdersTableAdapter()
        Me.OrderItemsTableAdapter = New EZMenu.EZMenuDataSetTableAdapters.OrderItemsTableAdapter()
        Me.OrderItemsBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ugdTableOrders = New Infragistics.Win.UltraWinGrid.UltraGrid()
        Me.Table_BillBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Table_BillTableAdapter = New EZMenu.EZMenuDataSetTableAdapters.Table_BillTableAdapter()
        Me.TableAdapterManager = New EZMenu.EZMenuDataSetTableAdapters.TableAdapterManager()
        Me.cmdDriver = New Infragistics.Win.Misc.UltraButton()
        Me.cmdMap = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDelete = New Infragistics.Win.Misc.UltraButton()
        Me.cmdEdit = New Infragistics.Win.Misc.UltraButton()
        Me.cmdGridView = New Infragistics.Win.Misc.UltraButton()
        Me.cmdReprint = New Infragistics.Win.Misc.UltraButton()
        Me.cmdTables = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDelivColn = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDown = New Infragistics.Win.Misc.UltraButton()
        Me.cmdUp = New Infragistics.Win.Misc.UltraButton()
        Me.cmdReturn = New Infragistics.Win.Misc.UltraButton()
        Me.cmdCuisine = New Infragistics.Win.Misc.UltraButton()
        Me.cmdShowTotals = New Infragistics.Win.Misc.UltraButton()
        Me.cmdOrderItems = New Infragistics.Win.Misc.UltraButton()
        Me.uplBasePanel.ClientArea.SuspendLayout()
        Me.uplBasePanel.SuspendLayout()
        CType(Me.ugdOrderGrid, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.OrdersBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EZMenuDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EZMenuDataSetBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.OrderItemsBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ugdTableOrders, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Table_BillBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'uplBasePanel
        '
        '
        'uplBasePanel.ClientArea
        '
        Me.uplBasePanel.ClientArea.Controls.Add(Me.cmdReturn)
        Me.uplBasePanel.ClientArea.Controls.Add(Me.cmdShowTotals)
        Me.uplBasePanel.Location = New System.Drawing.Point(0, 750)
        Me.uplBasePanel.Size = New System.Drawing.Size(1184, 50)
        '
        'ugdOrderGrid
        '
        Me.ugdOrderGrid.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ugdOrderGrid.DataSource = Me.OrdersBindingSource
        Appearance7.BackColor = System.Drawing.Color.Transparent
        Appearance7.BorderColor = System.Drawing.Color.Transparent
        Me.ugdOrderGrid.DisplayLayout.Appearance = Appearance7
        UltraGridColumn1.Header.VisiblePosition = 0
        UltraGridColumn1.Hidden = True
        UltraGridColumn2.Header.Caption = "Cust ID"
        UltraGridColumn2.Header.VisiblePosition = 1
        UltraGridColumn2.Width = 55
        UltraGridColumn3.Format = ""
        UltraGridColumn3.Header.Caption = "Delivery Time"
        UltraGridColumn3.Header.VisiblePosition = 7
        UltraGridColumn6.Header.Caption = "Pay method"
        UltraGridColumn6.Header.VisiblePosition = 8
        UltraGridColumn6.Style = Infragistics.Win.UltraWinGrid.ColumnStyle.DropDownList
        UltraGridColumn6.Width = 93
        UltraGridColumn7.Header.VisiblePosition = 10
        UltraGridColumn7.Nullable = Infragistics.Win.UltraWinGrid.Nullable.EmptyString
        UltraGridColumn7.Style = Infragistics.Win.UltraWinGrid.ColumnStyle.DropDownList
        UltraGridColumn8.Header.VisiblePosition = 11
        UltraGridColumn8.Nullable = Infragistics.Win.UltraWinGrid.Nullable.EmptyString
        UltraGridColumn8.Style = Infragistics.Win.UltraWinGrid.ColumnStyle.DropDownList
        UltraGridColumn9.Header.Caption = "To Pay"
        UltraGridColumn9.Header.VisiblePosition = 2
        UltraGridColumn10.Header.Caption = "Order Paid"
        UltraGridColumn10.Header.VisiblePosition = 9
        UltraGridColumn11.Header.Caption = "Customer Name"
        UltraGridColumn11.Header.VisiblePosition = 4
        UltraGridColumn12.CellMultiLine = Infragistics.Win.DefaultableBoolean.[True]
        UltraGridColumn12.Header.Caption = "Delivery Address"
        UltraGridColumn12.Header.VisiblePosition = 5
        UltraGridColumn13.Header.VisiblePosition = 6
        UltraGridColumn14.Header.VisiblePosition = 12
        UltraGridColumn14.Hidden = True
        UltraGridColumn15.Header.VisiblePosition = 13
        UltraGridColumn15.Hidden = True
        UltraGridColumn16.Header.VisiblePosition = 14
        UltraGridColumn16.Hidden = True
        UltraGridColumn17.Header.VisiblePosition = 15
        UltraGridColumn17.Hidden = True
        UltraGridColumn18.Header.Caption = "Order Time"
        UltraGridColumn18.Header.VisiblePosition = 3
        UltraGridColumn19.Header.VisiblePosition = 16
        UltraGridColumn19.Hidden = True
        UltraGridColumn20.Header.VisiblePosition = 17
        UltraGridColumn20.Style = Infragistics.Win.UltraWinGrid.ColumnStyle.DropDownList
        UltraGridColumn21.Header.VisiblePosition = 19
        UltraGridColumn21.Hidden = True
        UltraGridColumn4.Header.VisiblePosition = 18
        UltraGridColumn5.Header.VisiblePosition = 20
        UltraGridBand1.Columns.AddRange(New Object() {UltraGridColumn1, UltraGridColumn2, UltraGridColumn3, UltraGridColumn6, UltraGridColumn7, UltraGridColumn8, UltraGridColumn9, UltraGridColumn10, UltraGridColumn11, UltraGridColumn12, UltraGridColumn13, UltraGridColumn14, UltraGridColumn15, UltraGridColumn16, UltraGridColumn17, UltraGridColumn18, UltraGridColumn19, UltraGridColumn20, UltraGridColumn21, UltraGridColumn4, UltraGridColumn5})
        Appearance8.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        UltraGridBand1.Header.Appearance = Appearance8
        UltraGridBand1.Override.AllowAddNew = Infragistics.Win.UltraWinGrid.AllowAddNew.Yes
        Me.ugdOrderGrid.DisplayLayout.BandsSerializer.Add(UltraGridBand1)
        Me.ugdOrderGrid.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Me.ugdOrderGrid.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.[False]
        Appearance9.BackColor = System.Drawing.SystemColors.ActiveBorder
        Appearance9.BackColor2 = System.Drawing.SystemColors.ControlDark
        Appearance9.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance9.BorderColor = System.Drawing.SystemColors.Window
        Me.ugdOrderGrid.DisplayLayout.GroupByBox.Appearance = Appearance9
        Appearance10.ForeColor = System.Drawing.SystemColors.GrayText
        Me.ugdOrderGrid.DisplayLayout.GroupByBox.BandLabelAppearance = Appearance10
        Me.ugdOrderGrid.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Appearance11.BackColor = System.Drawing.SystemColors.ControlLightLight
        Appearance11.BackColor2 = System.Drawing.SystemColors.Control
        Appearance11.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal
        Appearance11.ForeColor = System.Drawing.SystemColors.GrayText
        Me.ugdOrderGrid.DisplayLayout.GroupByBox.PromptAppearance = Appearance11
        Me.ugdOrderGrid.DisplayLayout.MaxColScrollRegions = 1
        Me.ugdOrderGrid.DisplayLayout.MaxRowScrollRegions = 1
        Appearance12.BackColor = System.Drawing.Color.Orange
        Appearance12.BackColor2 = System.Drawing.Color.DarkOrange
        Appearance12.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ugdOrderGrid.DisplayLayout.Override.ActiveRowAppearance = Appearance12
        Me.ugdOrderGrid.DisplayLayout.Override.AllowColMoving = Infragistics.Win.UltraWinGrid.AllowColMoving.NotAllowed
        Me.ugdOrderGrid.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted
        Me.ugdOrderGrid.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted
        Appearance13.BackColor = System.Drawing.SystemColors.Window
        Me.ugdOrderGrid.DisplayLayout.Override.CardAreaAppearance = Appearance13
        Appearance14.BorderColor = System.Drawing.Color.Silver
        Appearance14.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter
        Me.ugdOrderGrid.DisplayLayout.Override.CellAppearance = Appearance14
        Me.ugdOrderGrid.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.EditAndSelectText
        Me.ugdOrderGrid.DisplayLayout.Override.CellPadding = 0
        Appearance15.BackColor = System.Drawing.SystemColors.Control
        Appearance15.BackColor2 = System.Drawing.SystemColors.ControlDark
        Appearance15.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element
        Appearance15.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal
        Appearance15.BorderColor = System.Drawing.SystemColors.Window
        Me.ugdOrderGrid.DisplayLayout.Override.GroupByRowAppearance = Appearance15
        Appearance16.BackColor = System.Drawing.Color.FromArgb(CType(CType(205, Byte), Integer), CType(CType(212, Byte), Integer), CType(CType(222, Byte), Integer))
        Appearance16.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(205, Byte), Integer), CType(CType(212, Byte), Integer), CType(CType(222, Byte), Integer))
        Appearance16.ForeColor = System.Drawing.Color.DimGray
        Appearance16.TextHAlignAsString = "Center"
        Me.ugdOrderGrid.DisplayLayout.Override.HeaderAppearance = Appearance16
        Me.ugdOrderGrid.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti
        Me.ugdOrderGrid.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand
        Appearance17.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.ugdOrderGrid.DisplayLayout.Override.RowAlternateAppearance = Appearance17
        Appearance18.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.ugdOrderGrid.DisplayLayout.Override.RowAppearance = Appearance18
        Me.ugdOrderGrid.DisplayLayout.Override.RowSelectorHeaderStyle = Infragistics.Win.UltraWinGrid.RowSelectorHeaderStyle.SeparateElement
        Me.ugdOrderGrid.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.[True]
        Me.ugdOrderGrid.DisplayLayout.Override.RowSizing = Infragistics.Win.UltraWinGrid.RowSizing.Sychronized
        Me.ugdOrderGrid.DisplayLayout.Override.RowSizingArea = Infragistics.Win.UltraWinGrid.RowSizingArea.RowBordersOnly
        Me.ugdOrderGrid.DisplayLayout.Override.SelectTypeCol = Infragistics.Win.UltraWinGrid.SelectType.None
        Me.ugdOrderGrid.DisplayLayout.Override.SelectTypeRow = Infragistics.Win.UltraWinGrid.SelectType.[Single]
        Appearance19.BackColor = System.Drawing.SystemColors.ControlLight
        Me.ugdOrderGrid.DisplayLayout.Override.TemplateAddRowAppearance = Appearance19
        Me.ugdOrderGrid.DisplayLayout.Override.WrapHeaderText = Infragistics.Win.DefaultableBoolean.[True]
        Me.ugdOrderGrid.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill
        Me.ugdOrderGrid.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate
        Me.ugdOrderGrid.DisplayLayout.ViewStyle = Infragistics.Win.UltraWinGrid.ViewStyle.SingleBand
        Me.ugdOrderGrid.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ugdOrderGrid.Location = New System.Drawing.Point(8, 56)
        Me.ugdOrderGrid.Name = "ugdOrderGrid"
        Me.ugdOrderGrid.Size = New System.Drawing.Size(1108, 684)
        Me.ugdOrderGrid.TabIndex = 360
        '
        'OrdersBindingSource
        '
        Me.OrdersBindingSource.DataMember = "Orders"
        Me.OrdersBindingSource.DataSource = Me.EZMenuDataSet
        '
        'EZMenuDataSet
        '
        Me.EZMenuDataSet.DataSetName = "EZMenuDataSet"
        Me.EZMenuDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'EZMenuDataSetBindingSource
        '
        Me.EZMenuDataSetBindingSource.DataSource = Me.EZMenuDataSet
        Me.EZMenuDataSetBindingSource.Position = 0
        '
        'OrdersTableAdapter
        '
        Me.OrdersTableAdapter.ClearBeforeFill = True
        '
        'OrderItemsTableAdapter
        '
        Me.OrderItemsTableAdapter.ClearBeforeFill = True
        '
        'OrderItemsBindingSource
        '
        Me.OrderItemsBindingSource.DataMember = "OrderItems"
        Me.OrderItemsBindingSource.DataSource = Me.EZMenuDataSet
        '
        'ugdTableOrders
        '
        Me.ugdTableOrders.DataSource = Me.Table_BillBindingSource
        Appearance20.BackColor = System.Drawing.Color.Transparent
        Appearance20.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Me.ugdTableOrders.DisplayLayout.Appearance = Appearance20
        UltraGridColumn22.Header.VisiblePosition = 0
        UltraGridColumn22.Hidden = True
        Appearance21.TextHAlignAsString = "Center"
        UltraGridColumn23.CellAppearance = Appearance21
        UltraGridColumn23.Header.Caption = "Covers"
        UltraGridColumn23.Header.VisiblePosition = 2
        Appearance22.TextHAlignAsString = "Right"
        UltraGridColumn24.CellAppearance = Appearance22
        UltraGridColumn24.Header.Caption = "Total"
        UltraGridColumn24.Header.VisiblePosition = 3
        Appearance23.TextHAlignAsString = "Right"
        UltraGridColumn25.CellAppearance = Appearance23
        UltraGridColumn25.Header.Caption = "Meal"
        UltraGridColumn25.Header.VisiblePosition = 4
        Appearance24.TextHAlignAsString = "Right"
        UltraGridColumn26.CellAppearance = Appearance24
        UltraGridColumn26.Header.Caption = "Drinks"
        UltraGridColumn26.Header.VisiblePosition = 5
        Appearance25.TextHAlignAsString = "Right"
        UltraGridColumn27.CellAppearance = Appearance25
        UltraGridColumn27.Header.VisiblePosition = 6
        Appearance26.TextHAlignAsString = "Center"
        UltraGridColumn29.CellAppearance = Appearance26
        UltraGridColumn29.Header.Caption = "Table"
        UltraGridColumn29.Header.VisiblePosition = 1
        UltraGridColumn30.Header.VisiblePosition = 7
        UltraGridColumn30.Hidden = True
        UltraGridColumn31.Header.VisiblePosition = 8
        UltraGridColumn31.Hidden = True
        UltraGridColumn32.Header.VisiblePosition = 9
        UltraGridColumn32.Hidden = True
        UltraGridColumn33.Header.VisiblePosition = 13
        UltraGridColumn33.Hidden = True
        UltraGridColumn34.Header.VisiblePosition = 10
        UltraGridColumn34.Hidden = True
        UltraGridColumn35.Header.VisiblePosition = 11
        UltraGridColumn35.Hidden = True
        UltraGridColumn36.Header.VisiblePosition = 12
        UltraGridColumn36.Hidden = True
        UltraGridColumn37.Header.VisiblePosition = 14
        UltraGridColumn37.Hidden = True
        UltraGridColumn38.Header.VisiblePosition = 15
        UltraGridColumn38.Hidden = True
        UltraGridColumn39.Header.VisiblePosition = 16
        UltraGridColumn39.Hidden = True
        UltraGridColumn40.Header.VisiblePosition = 17
        UltraGridColumn40.Hidden = True
        UltraGridColumn41.Header.VisiblePosition = 18
        UltraGridColumn41.Hidden = True
        UltraGridColumn42.Header.VisiblePosition = 19
        UltraGridColumn42.Hidden = True
        UltraGridColumn43.Header.VisiblePosition = 20
        UltraGridColumn43.Hidden = True
        UltraGridColumn44.Header.VisiblePosition = 21
        UltraGridColumn44.Hidden = True
        UltraGridColumn45.Header.VisiblePosition = 22
        UltraGridColumn45.Hidden = True
        UltraGridColumn46.Header.VisiblePosition = 23
        UltraGridColumn46.Hidden = True
        UltraGridBand2.Columns.AddRange(New Object() {UltraGridColumn22, UltraGridColumn23, UltraGridColumn24, UltraGridColumn25, UltraGridColumn26, UltraGridColumn27, UltraGridColumn29, UltraGridColumn30, UltraGridColumn31, UltraGridColumn32, UltraGridColumn33, UltraGridColumn34, UltraGridColumn35, UltraGridColumn36, UltraGridColumn37, UltraGridColumn38, UltraGridColumn39, UltraGridColumn40, UltraGridColumn41, UltraGridColumn42, UltraGridColumn43, UltraGridColumn44, UltraGridColumn45, UltraGridColumn46})
        Appearance27.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        UltraGridBand2.Header.Appearance = Appearance27
        UltraGridBand2.Override.AllowAddNew = Infragistics.Win.UltraWinGrid.AllowAddNew.Yes
        Me.ugdTableOrders.DisplayLayout.BandsSerializer.Add(UltraGridBand2)
        Me.ugdTableOrders.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Me.ugdTableOrders.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.[False]
        Appearance28.BackColor = System.Drawing.SystemColors.ActiveBorder
        Appearance28.BackColor2 = System.Drawing.SystemColors.ControlDark
        Appearance28.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance28.BorderColor = System.Drawing.SystemColors.Window
        Me.ugdTableOrders.DisplayLayout.GroupByBox.Appearance = Appearance28
        Appearance29.ForeColor = System.Drawing.SystemColors.GrayText
        Me.ugdTableOrders.DisplayLayout.GroupByBox.BandLabelAppearance = Appearance29
        Me.ugdTableOrders.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Appearance30.BackColor = System.Drawing.SystemColors.ControlLightLight
        Appearance30.BackColor2 = System.Drawing.SystemColors.Control
        Appearance30.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal
        Appearance30.ForeColor = System.Drawing.SystemColors.GrayText
        Me.ugdTableOrders.DisplayLayout.GroupByBox.PromptAppearance = Appearance30
        Me.ugdTableOrders.DisplayLayout.MaxColScrollRegions = 1
        Me.ugdTableOrders.DisplayLayout.MaxRowScrollRegions = 1
        Appearance31.BackColor = System.Drawing.Color.Orange
        Appearance31.BackColor2 = System.Drawing.Color.DarkOrange
        Appearance31.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ugdTableOrders.DisplayLayout.Override.ActiveRowAppearance = Appearance31
        Me.ugdTableOrders.DisplayLayout.Override.AllowColMoving = Infragistics.Win.UltraWinGrid.AllowColMoving.NotAllowed
        Me.ugdTableOrders.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted
        Me.ugdTableOrders.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted
        Appearance32.BackColor = System.Drawing.SystemColors.Window
        Me.ugdTableOrders.DisplayLayout.Override.CardAreaAppearance = Appearance32
        Appearance33.BorderColor = System.Drawing.Color.Silver
        Appearance33.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter
        Me.ugdTableOrders.DisplayLayout.Override.CellAppearance = Appearance33
        Me.ugdTableOrders.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.EditAndSelectText
        Me.ugdTableOrders.DisplayLayout.Override.CellPadding = 0
        Appearance34.BackColor = System.Drawing.SystemColors.Control
        Appearance34.BackColor2 = System.Drawing.SystemColors.ControlDark
        Appearance34.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element
        Appearance34.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal
        Appearance34.BorderColor = System.Drawing.SystemColors.Window
        Me.ugdTableOrders.DisplayLayout.Override.GroupByRowAppearance = Appearance34
        Appearance35.BackColor = System.Drawing.Color.FromArgb(CType(CType(205, Byte), Integer), CType(CType(212, Byte), Integer), CType(CType(222, Byte), Integer))
        Appearance35.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(205, Byte), Integer), CType(CType(212, Byte), Integer), CType(CType(222, Byte), Integer))
        Appearance35.ForeColor = System.Drawing.Color.DimGray
        Appearance35.TextHAlignAsString = "Center"
        Me.ugdTableOrders.DisplayLayout.Override.HeaderAppearance = Appearance35
        Me.ugdTableOrders.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti
        Me.ugdTableOrders.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand
        Appearance36.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.ugdTableOrders.DisplayLayout.Override.RowAlternateAppearance = Appearance36
        Appearance37.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.ugdTableOrders.DisplayLayout.Override.RowAppearance = Appearance37
        Me.ugdTableOrders.DisplayLayout.Override.RowSelectorHeaderStyle = Infragistics.Win.UltraWinGrid.RowSelectorHeaderStyle.SeparateElement
        Me.ugdTableOrders.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.[True]
        Me.ugdTableOrders.DisplayLayout.Override.RowSizing = Infragistics.Win.UltraWinGrid.RowSizing.Sychronized
        Me.ugdTableOrders.DisplayLayout.Override.RowSizingArea = Infragistics.Win.UltraWinGrid.RowSizingArea.RowBordersOnly
        Me.ugdTableOrders.DisplayLayout.Override.SelectTypeCol = Infragistics.Win.UltraWinGrid.SelectType.None
        Me.ugdTableOrders.DisplayLayout.Override.SelectTypeRow = Infragistics.Win.UltraWinGrid.SelectType.[Single]
        Appearance38.BackColor = System.Drawing.SystemColors.ControlLight
        Me.ugdTableOrders.DisplayLayout.Override.TemplateAddRowAppearance = Appearance38
        Me.ugdTableOrders.DisplayLayout.Override.WrapHeaderText = Infragistics.Win.DefaultableBoolean.[True]
        Me.ugdTableOrders.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill
        Me.ugdTableOrders.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate
        Me.ugdTableOrders.DisplayLayout.ViewStyle = Infragistics.Win.UltraWinGrid.ViewStyle.SingleBand
        Me.ugdTableOrders.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ugdTableOrders.Location = New System.Drawing.Point(12, 60)
        Me.ugdTableOrders.Name = "ugdTableOrders"
        Me.ugdTableOrders.Size = New System.Drawing.Size(922, 623)
        Me.ugdTableOrders.TabIndex = 457
        Me.ugdTableOrders.Visible = False
        '
        'Table_BillBindingSource
        '
        Me.Table_BillBindingSource.DataMember = "Table_Bill"
        Me.Table_BillBindingSource.DataSource = Me.EZMenuDataSet
        '
        'Table_BillTableAdapter
        '
        Me.Table_BillTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.AltAddressTableAdapter = Nothing
        Me.TableAdapterManager.Alternative_PhoneTableAdapter = Nothing
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.BankingTableAdapter = Nothing
        Me.TableAdapterManager.BankPrintTableAdapter = Nothing
        Me.TableAdapterManager.CallerIDLogTableAdapter = Nothing
        Me.TableAdapterManager.CodesTableAdapter = Nothing
        Me.TableAdapterManager.CollectorTableAdapter = Nothing
        Me.TableAdapterManager.CustomerTableAdapter = Nothing
        Me.TableAdapterManager.DirectionsTableAdapter = Nothing
        Me.TableAdapterManager.DishTableAdapter = Nothing
        Me.TableAdapterManager.DrinksTableAdapter = Nothing
        Me.TableAdapterManager.FreeOffersTableAdapter = Nothing
        Me.TableAdapterManager.GroupsTableAdapter = Nothing
        Me.TableAdapterManager.KitchenNotesTableAdapter = Nothing
        Me.TableAdapterManager.ModifiersTableAdapter = Nothing
        Me.TableAdapterManager.NotesDBTableAdapter = Nothing
        Me.TableAdapterManager.OffersTableAdapter = Nothing
        Me.TableAdapterManager.OrderItemsTableAdapter = Me.OrderItemsTableAdapter
        Me.TableAdapterManager.OrdersTableAdapter = Me.OrdersTableAdapter
        Me.TableAdapterManager.SetIDTableAdapter = Nothing
        Me.TableAdapterManager.SetMealsTableAdapter = Nothing
        Me.TableAdapterManager.SetSelectedItemsTableAdapter = Nothing
        Me.TableAdapterManager.SetSelectedTableAdapter = Nothing
        Me.TableAdapterManager.SummaryTableAdapter = Nothing
        Me.TableAdapterManager.Table_BillTableAdapter = Me.Table_BillTableAdapter
        Me.TableAdapterManager.Table_DrinksTableAdapter = Nothing
        Me.TableAdapterManager.Table_MealTableAdapter = Nothing
        Me.TableAdapterManager.TypicalTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = EZMenu.EZMenuDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        Me.TableAdapterManager.UsersTableAdapter = Nothing
        '
        'cmdDriver
        '
        Me.cmdDriver.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance39.BackColor = System.Drawing.Color.Transparent
        Appearance39.BackColor2 = System.Drawing.Color.Transparent
        Appearance39.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance39.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance39.BorderColor = System.Drawing.Color.Transparent
        Appearance39.ForeColor = System.Drawing.Color.Black
        Appearance39.Image = CType(resources.GetObject("Appearance39.Image"), Object)
        Appearance39.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance39.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance39.TextVAlignAsString = "Bottom"
        Me.cmdDriver.Appearance = Appearance39
        Me.cmdDriver.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdDriver.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance40.BackColor = System.Drawing.Color.DarkOrange
        Appearance40.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance40.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance40.BorderColor = System.Drawing.Color.Transparent
        Appearance40.ForeColor = System.Drawing.Color.Black
        Me.cmdDriver.HotTrackAppearance = Appearance40
        Me.cmdDriver.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdDriver.Location = New System.Drawing.Point(1126, 524)
        Me.cmdDriver.Name = "cmdDriver"
        Appearance41.BackColor = System.Drawing.Color.OrangeRed
        Appearance41.BackColor2 = System.Drawing.Color.Tomato
        Appearance41.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance41.BorderColor = System.Drawing.Color.Transparent
        Me.cmdDriver.PressedAppearance = Appearance41
        Me.cmdDriver.ShowFocusRect = False
        Me.cmdDriver.ShowOutline = False
        Me.cmdDriver.Size = New System.Drawing.Size(46, 45)
        Me.cmdDriver.StyleSetName = "StatusBar"
        Me.cmdDriver.TabIndex = 508
        Me.cmdDriver.Tag = "Drinks"
        Me.cmdDriver.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDriver.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDriver.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdMap
        '
        Me.cmdMap.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance42.BackColor = System.Drawing.Color.Transparent
        Appearance42.BackColor2 = System.Drawing.Color.Transparent
        Appearance42.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance42.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance42.BorderColor = System.Drawing.Color.Transparent
        Appearance42.ForeColor = System.Drawing.Color.Black
        Appearance42.Image = CType(resources.GetObject("Appearance42.Image"), Object)
        Appearance42.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance42.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance42.TextVAlignAsString = "Bottom"
        Me.cmdMap.Appearance = Appearance42
        Me.cmdMap.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdMap.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance43.BackColor = System.Drawing.Color.DarkOrange
        Appearance43.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance43.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance43.BorderColor = System.Drawing.Color.Transparent
        Appearance43.ForeColor = System.Drawing.Color.Black
        Me.cmdMap.HotTrackAppearance = Appearance43
        Me.cmdMap.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdMap.Location = New System.Drawing.Point(1126, 466)
        Me.cmdMap.Name = "cmdMap"
        Appearance44.BackColor = System.Drawing.Color.OrangeRed
        Appearance44.BackColor2 = System.Drawing.Color.Tomato
        Appearance44.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance44.BorderColor = System.Drawing.Color.Transparent
        Me.cmdMap.PressedAppearance = Appearance44
        Me.cmdMap.ShowFocusRect = False
        Me.cmdMap.ShowOutline = False
        Me.cmdMap.Size = New System.Drawing.Size(46, 45)
        Me.cmdMap.StyleSetName = "StatusBar"
        Me.cmdMap.TabIndex = 507
        Me.cmdMap.Tag = "x"
        Me.cmdMap.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdMap.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdMap.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDelete
        '
        Me.cmdDelete.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance45.BackColor = System.Drawing.Color.Transparent
        Appearance45.BackColor2 = System.Drawing.Color.Transparent
        Appearance45.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance45.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance45.BorderColor = System.Drawing.Color.Transparent
        Appearance45.ForeColor = System.Drawing.Color.Black
        Appearance45.Image = CType(resources.GetObject("Appearance45.Image"), Object)
        Appearance45.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance45.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance45.TextVAlignAsString = "Bottom"
        Me.cmdDelete.Appearance = Appearance45
        Me.cmdDelete.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdDelete.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance46.BackColor = System.Drawing.Color.DarkOrange
        Appearance46.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance46.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance46.BorderColor = System.Drawing.Color.Transparent
        Appearance46.ForeColor = System.Drawing.Color.Black
        Me.cmdDelete.HotTrackAppearance = Appearance46
        Me.cmdDelete.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdDelete.Location = New System.Drawing.Point(1126, 408)
        Me.cmdDelete.Name = "cmdDelete"
        Appearance47.BackColor = System.Drawing.Color.OrangeRed
        Appearance47.BackColor2 = System.Drawing.Color.Tomato
        Appearance47.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance47.BorderColor = System.Drawing.Color.Transparent
        Me.cmdDelete.PressedAppearance = Appearance47
        Me.cmdDelete.ShowFocusRect = False
        Me.cmdDelete.ShowOutline = False
        Me.cmdDelete.Size = New System.Drawing.Size(46, 45)
        Me.cmdDelete.StyleSetName = "StatusBar"
        Me.cmdDelete.TabIndex = 506
        Me.cmdDelete.Tag = "New"
        Me.cmdDelete.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDelete.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDelete.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdEdit
        '
        Me.cmdEdit.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance48.BackColor = System.Drawing.Color.Transparent
        Appearance48.BackColor2 = System.Drawing.Color.Transparent
        Appearance48.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance48.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance48.BorderColor = System.Drawing.Color.Transparent
        Appearance48.ForeColor = System.Drawing.Color.Black
        Appearance48.Image = CType(resources.GetObject("Appearance48.Image"), Object)
        Appearance48.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance48.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance48.TextVAlignAsString = "Bottom"
        Me.cmdEdit.Appearance = Appearance48
        Me.cmdEdit.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdEdit.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance49.BackColor = System.Drawing.Color.DarkOrange
        Appearance49.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance49.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance49.BorderColor = System.Drawing.Color.Transparent
        Appearance49.ForeColor = System.Drawing.Color.Black
        Me.cmdEdit.HotTrackAppearance = Appearance49
        Me.cmdEdit.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdEdit.Location = New System.Drawing.Point(1126, 350)
        Me.cmdEdit.Name = "cmdEdit"
        Appearance50.BackColor = System.Drawing.Color.OrangeRed
        Appearance50.BackColor2 = System.Drawing.Color.Tomato
        Appearance50.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance50.BorderColor = System.Drawing.Color.Transparent
        Me.cmdEdit.PressedAppearance = Appearance50
        Me.cmdEdit.ShowFocusRect = False
        Me.cmdEdit.ShowOutline = False
        Me.cmdEdit.Size = New System.Drawing.Size(46, 45)
        Me.cmdEdit.StyleSetName = "StatusBar"
        Me.cmdEdit.TabIndex = 505
        Me.cmdEdit.Tag = "New"
        Me.cmdEdit.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdEdit.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdEdit.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdGridView
        '
        Me.cmdGridView.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance51.BackColor = System.Drawing.Color.Transparent
        Appearance51.BackColor2 = System.Drawing.Color.Transparent
        Appearance51.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance51.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance51.BorderColor = System.Drawing.Color.Transparent
        Appearance51.ForeColor = System.Drawing.Color.Black
        Appearance51.Image = CType(resources.GetObject("Appearance51.Image"), Object)
        Appearance51.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance51.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance51.TextVAlignAsString = "Bottom"
        Me.cmdGridView.Appearance = Appearance51
        Me.cmdGridView.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdGridView.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance52.BackColor = System.Drawing.Color.DarkOrange
        Appearance52.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance52.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance52.BorderColor = System.Drawing.Color.Transparent
        Appearance52.ForeColor = System.Drawing.Color.Black
        Me.cmdGridView.HotTrackAppearance = Appearance52
        Me.cmdGridView.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdGridView.Location = New System.Drawing.Point(1126, 640)
        Me.cmdGridView.Name = "cmdGridView"
        Appearance53.BackColor = System.Drawing.Color.OrangeRed
        Appearance53.BackColor2 = System.Drawing.Color.Tomato
        Appearance53.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance53.BorderColor = System.Drawing.Color.Transparent
        Me.cmdGridView.PressedAppearance = Appearance53
        Me.cmdGridView.ShowFocusRect = False
        Me.cmdGridView.ShowOutline = False
        Me.cmdGridView.Size = New System.Drawing.Size(46, 45)
        Me.cmdGridView.StyleSetName = "StatusBar"
        Me.cmdGridView.TabIndex = 504
        Me.cmdGridView.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdGridView.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdGridView.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdReprint
        '
        Me.cmdReprint.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance54.BackColor = System.Drawing.Color.Transparent
        Appearance54.BackColor2 = System.Drawing.Color.Transparent
        Appearance54.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance54.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance54.BorderColor = System.Drawing.Color.Transparent
        Appearance54.ForeColor = System.Drawing.Color.Black
        Appearance54.Image = CType(resources.GetObject("Appearance54.Image"), Object)
        Appearance54.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance54.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance54.TextVAlignAsString = "Bottom"
        Me.cmdReprint.Appearance = Appearance54
        Me.cmdReprint.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdReprint.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance55.BackColor = System.Drawing.Color.DarkOrange
        Appearance55.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance55.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance55.BorderColor = System.Drawing.Color.Transparent
        Appearance55.ForeColor = System.Drawing.Color.Black
        Me.cmdReprint.HotTrackAppearance = Appearance55
        Me.cmdReprint.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdReprint.Location = New System.Drawing.Point(1126, 292)
        Me.cmdReprint.Name = "cmdReprint"
        Appearance56.BackColor = System.Drawing.Color.OrangeRed
        Appearance56.BackColor2 = System.Drawing.Color.Tomato
        Appearance56.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance56.BorderColor = System.Drawing.Color.Transparent
        Me.cmdReprint.PressedAppearance = Appearance56
        Me.cmdReprint.ShowFocusRect = False
        Me.cmdReprint.ShowOutline = False
        Me.cmdReprint.Size = New System.Drawing.Size(46, 45)
        Me.cmdReprint.StyleSetName = "StatusBar"
        Me.cmdReprint.TabIndex = 503
        Me.cmdReprint.Tag = "x"
        Me.cmdReprint.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdReprint.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdReprint.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdTables
        '
        Me.cmdTables.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance57.BackColor = System.Drawing.Color.Transparent
        Appearance57.BackColor2 = System.Drawing.Color.Transparent
        Appearance57.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance57.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance57.BorderColor = System.Drawing.Color.Transparent
        Appearance57.ForeColor = System.Drawing.Color.Black
        Appearance57.Image = CType(resources.GetObject("Appearance57.Image"), Object)
        Appearance57.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance57.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance57.TextVAlignAsString = "Bottom"
        Me.cmdTables.Appearance = Appearance57
        Me.cmdTables.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdTables.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance58.BackColor = System.Drawing.Color.DarkOrange
        Appearance58.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance58.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance58.BorderColor = System.Drawing.Color.Transparent
        Appearance58.ForeColor = System.Drawing.Color.Black
        Me.cmdTables.HotTrackAppearance = Appearance58
        Me.cmdTables.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdTables.Location = New System.Drawing.Point(1126, 234)
        Me.cmdTables.Name = "cmdTables"
        Appearance59.BackColor = System.Drawing.Color.OrangeRed
        Appearance59.BackColor2 = System.Drawing.Color.Tomato
        Appearance59.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance59.BorderColor = System.Drawing.Color.Transparent
        Me.cmdTables.PressedAppearance = Appearance59
        Me.cmdTables.ShowFocusRect = False
        Me.cmdTables.ShowOutline = False
        Me.cmdTables.Size = New System.Drawing.Size(46, 45)
        Me.cmdTables.StyleSetName = "StatusBar"
        Me.cmdTables.TabIndex = 502
        Me.cmdTables.Tag = "-"
        Me.cmdTables.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTables.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTables.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDelivColn
        '
        Me.cmdDelivColn.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance60.BackColor = System.Drawing.Color.Transparent
        Appearance60.BackColor2 = System.Drawing.Color.Transparent
        Appearance60.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance60.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance60.BorderColor = System.Drawing.Color.Transparent
        Appearance60.ForeColor = System.Drawing.Color.Black
        Appearance60.Image = CType(resources.GetObject("Appearance60.Image"), Object)
        Appearance60.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance60.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance60.TextVAlignAsString = "Bottom"
        Me.cmdDelivColn.Appearance = Appearance60
        Me.cmdDelivColn.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdDelivColn.Enabled = False
        Me.cmdDelivColn.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance61.BackColor = System.Drawing.Color.DarkOrange
        Appearance61.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance61.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance61.BorderColor = System.Drawing.Color.Transparent
        Appearance61.ForeColor = System.Drawing.Color.Black
        Me.cmdDelivColn.HotTrackAppearance = Appearance61
        Me.cmdDelivColn.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdDelivColn.Location = New System.Drawing.Point(1126, 176)
        Me.cmdDelivColn.Name = "cmdDelivColn"
        Appearance62.BackColor = System.Drawing.Color.OrangeRed
        Appearance62.BackColor2 = System.Drawing.Color.Tomato
        Appearance62.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance62.BorderColor = System.Drawing.Color.Transparent
        Me.cmdDelivColn.PressedAppearance = Appearance62
        Me.cmdDelivColn.ShowFocusRect = False
        Me.cmdDelivColn.ShowOutline = False
        Me.cmdDelivColn.Size = New System.Drawing.Size(46, 45)
        Me.cmdDelivColn.StyleSetName = "StatusBar"
        Me.cmdDelivColn.TabIndex = 501
        Me.cmdDelivColn.Tag = "+"
        Me.cmdDelivColn.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDelivColn.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDelivColn.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDown
        '
        Me.cmdDown.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance63.BackColor = System.Drawing.Color.Transparent
        Appearance63.BackColor2 = System.Drawing.Color.Transparent
        Appearance63.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance63.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance63.BorderColor = System.Drawing.Color.Transparent
        Appearance63.ForeColor = System.Drawing.Color.Black
        Appearance63.Image = CType(resources.GetObject("Appearance63.Image"), Object)
        Appearance63.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance63.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance63.TextVAlignAsString = "Bottom"
        Me.cmdDown.Appearance = Appearance63
        Me.cmdDown.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdDown.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance64.BackColor = System.Drawing.Color.DarkOrange
        Appearance64.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance64.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance64.BorderColor = System.Drawing.Color.Transparent
        Appearance64.ForeColor = System.Drawing.Color.Black
        Me.cmdDown.HotTrackAppearance = Appearance64
        Me.cmdDown.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdDown.Location = New System.Drawing.Point(1126, 118)
        Me.cmdDown.Name = "cmdDown"
        Appearance65.BackColor = System.Drawing.Color.OrangeRed
        Appearance65.BackColor2 = System.Drawing.Color.Tomato
        Appearance65.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance65.BorderColor = System.Drawing.Color.Transparent
        Me.cmdDown.PressedAppearance = Appearance65
        Me.cmdDown.ShowFocusRect = False
        Me.cmdDown.ShowOutline = False
        Me.cmdDown.Size = New System.Drawing.Size(46, 45)
        Me.cmdDown.StyleSetName = "StatusBar"
        Me.cmdDown.TabIndex = 500
        Me.cmdDown.Tag = "Down"
        Me.cmdDown.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDown.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDown.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdUp
        '
        Me.cmdUp.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance66.BackColor = System.Drawing.Color.Transparent
        Appearance66.BackColor2 = System.Drawing.Color.Transparent
        Appearance66.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance66.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance66.BorderColor = System.Drawing.Color.Transparent
        Appearance66.ForeColor = System.Drawing.Color.Black
        Appearance66.Image = CType(resources.GetObject("Appearance66.Image"), Object)
        Appearance66.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance66.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance66.TextVAlignAsString = "Bottom"
        Me.cmdUp.Appearance = Appearance66
        Me.cmdUp.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdUp.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance67.BackColor = System.Drawing.Color.DarkOrange
        Appearance67.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance67.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance67.BorderColor = System.Drawing.Color.Transparent
        Appearance67.ForeColor = System.Drawing.Color.Black
        Me.cmdUp.HotTrackAppearance = Appearance67
        Me.cmdUp.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdUp.Location = New System.Drawing.Point(1126, 60)
        Me.cmdUp.Name = "cmdUp"
        Appearance68.BackColor = System.Drawing.Color.OrangeRed
        Appearance68.BackColor2 = System.Drawing.Color.Tomato
        Appearance68.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance68.BorderColor = System.Drawing.Color.Transparent
        Me.cmdUp.PressedAppearance = Appearance68
        Me.cmdUp.ShowFocusRect = False
        Me.cmdUp.ShowOutline = False
        Me.cmdUp.Size = New System.Drawing.Size(46, 45)
        Me.cmdUp.StyleSetName = "StatusBar"
        Me.cmdUp.TabIndex = 499
        Me.cmdUp.Tag = "Up"
        Me.cmdUp.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdUp.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdUp.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdReturn
        '
        Me.cmdReturn.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance1.BackColor = System.Drawing.Color.Transparent
        Appearance1.BackColor2 = System.Drawing.Color.Transparent
        Appearance1.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance1.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance1.BorderColor2 = System.Drawing.Color.Maroon
        Appearance1.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance1.ForeColor = System.Drawing.Color.White
        Appearance1.Image = CType(resources.GetObject("Appearance1.Image"), Object)
        Appearance1.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance1.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance1.TextVAlignAsString = "Bottom"
        Me.cmdReturn.Appearance = Appearance1
        Me.cmdReturn.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdReturn.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance2.BackColor = System.Drawing.Color.DarkOrange
        Appearance2.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance2.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance2.BorderColor = System.Drawing.Color.Transparent
        Appearance2.ForeColor = System.Drawing.Color.Black
        Me.cmdReturn.HotTrackAppearance = Appearance2
        Me.cmdReturn.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdReturn.Location = New System.Drawing.Point(1102, 8)
        Me.cmdReturn.Name = "cmdReturn"
        Appearance3.BackColor = System.Drawing.Color.OrangeRed
        Appearance3.BackColor2 = System.Drawing.Color.Tomato
        Appearance3.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance3.BorderColor = System.Drawing.Color.Transparent
        Me.cmdReturn.PressedAppearance = Appearance3
        Me.cmdReturn.ShowFocusRect = False
        Me.cmdReturn.ShowOutline = False
        Me.cmdReturn.Size = New System.Drawing.Size(70, 39)
        Me.cmdReturn.StyleSetName = "StatusBar"
        Me.cmdReturn.TabIndex = 510
        Me.cmdReturn.Tag = "Return"
        Me.cmdReturn.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdReturn.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdReturn.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdCuisine
        '
        Me.cmdCuisine.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance69.BackColor = System.Drawing.Color.Transparent
        Appearance69.BackColor2 = System.Drawing.Color.Transparent
        Appearance69.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance69.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance69.BorderColor = System.Drawing.Color.Transparent
        Appearance69.ForeColor = System.Drawing.Color.Black
        Appearance69.Image = CType(resources.GetObject("Appearance69.Image"), Object)
        Appearance69.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance69.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance69.TextVAlignAsString = "Bottom"
        Me.cmdCuisine.Appearance = Appearance69
        Me.cmdCuisine.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdCuisine.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance70.BackColor = System.Drawing.Color.DarkOrange
        Appearance70.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance70.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance70.BorderColor = System.Drawing.Color.Transparent
        Appearance70.ForeColor = System.Drawing.Color.Black
        Me.cmdCuisine.HotTrackAppearance = Appearance70
        Me.cmdCuisine.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdCuisine.Location = New System.Drawing.Point(1126, 692)
        Me.cmdCuisine.Name = "cmdCuisine"
        Appearance71.BackColor = System.Drawing.Color.OrangeRed
        Appearance71.BackColor2 = System.Drawing.Color.Tomato
        Appearance71.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance71.BorderColor = System.Drawing.Color.Transparent
        Me.cmdCuisine.PressedAppearance = Appearance71
        Me.cmdCuisine.ShowFocusRect = False
        Me.cmdCuisine.ShowOutline = False
        Me.cmdCuisine.Size = New System.Drawing.Size(46, 39)
        Me.cmdCuisine.StyleSetName = "StatusBar"
        Me.cmdCuisine.TabIndex = 511
        Me.cmdCuisine.Tag = "x"
        Me.cmdCuisine.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdCuisine.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdCuisine.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdShowTotals
        '
        Me.cmdShowTotals.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Appearance4.BackColor = System.Drawing.Color.Transparent
        Appearance4.BackColor2 = System.Drawing.Color.Transparent
        Appearance4.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance4.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance4.BorderColor = System.Drawing.Color.Transparent
        Appearance4.ForeColor = System.Drawing.Color.Black
        Appearance4.Image = Global.EZMenu.My.Resources.ezresource.money
        Appearance4.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance4.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance4.TextVAlignAsString = "Bottom"
        Me.cmdShowTotals.Appearance = Appearance4
        Me.cmdShowTotals.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdShowTotals.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance5.BackColor = System.Drawing.Color.DarkOrange
        Appearance5.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance5.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance5.BorderColor = System.Drawing.Color.Transparent
        Appearance5.ForeColor = System.Drawing.Color.Black
        Me.cmdShowTotals.HotTrackAppearance = Appearance5
        Me.cmdShowTotals.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdShowTotals.Location = New System.Drawing.Point(12, 8)
        Me.cmdShowTotals.Name = "cmdShowTotals"
        Appearance6.BackColor = System.Drawing.Color.OrangeRed
        Appearance6.BackColor2 = System.Drawing.Color.Tomato
        Appearance6.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance6.BorderColor = System.Drawing.Color.Transparent
        Me.cmdShowTotals.PressedAppearance = Appearance6
        Me.cmdShowTotals.ShowFocusRect = False
        Me.cmdShowTotals.ShowOutline = False
        Me.cmdShowTotals.Size = New System.Drawing.Size(46, 39)
        Me.cmdShowTotals.StyleSetName = "StatusBar"
        Me.cmdShowTotals.TabIndex = 512
        Me.cmdShowTotals.Tag = "x"
        Me.cmdShowTotals.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdShowTotals.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdShowTotals.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdOrderItems
        '
        Me.cmdOrderItems.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance72.BackColor = System.Drawing.Color.Transparent
        Appearance72.BackColor2 = System.Drawing.Color.Transparent
        Appearance72.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance72.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance72.BorderColor = System.Drawing.Color.Transparent
        Appearance72.ForeColor = System.Drawing.Color.Black
        Appearance72.Image = CType(resources.GetObject("Appearance72.Image"), Object)
        Appearance72.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance72.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance72.TextVAlignAsString = "Bottom"
        Me.cmdOrderItems.Appearance = Appearance72
        Me.cmdOrderItems.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdOrderItems.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance73.BackColor = System.Drawing.Color.DarkOrange
        Appearance73.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance73.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance73.BorderColor = System.Drawing.Color.Transparent
        Appearance73.ForeColor = System.Drawing.Color.Black
        Me.cmdOrderItems.HotTrackAppearance = Appearance73
        Me.cmdOrderItems.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdOrderItems.Location = New System.Drawing.Point(1126, 582)
        Me.cmdOrderItems.Name = "cmdOrderItems"
        Appearance74.BackColor = System.Drawing.Color.OrangeRed
        Appearance74.BackColor2 = System.Drawing.Color.Tomato
        Appearance74.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance74.BorderColor = System.Drawing.Color.Transparent
        Me.cmdOrderItems.PressedAppearance = Appearance74
        Me.cmdOrderItems.ShowFocusRect = False
        Me.cmdOrderItems.ShowOutline = False
        Me.cmdOrderItems.Size = New System.Drawing.Size(46, 45)
        Me.cmdOrderItems.StyleSetName = "StatusBar"
        Me.cmdOrderItems.TabIndex = 513
        Me.cmdOrderItems.Tag = "x"
        Me.cmdOrderItems.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOrderItems.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOrderItems.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'frmOrders
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1184, 800)
        Me.Controls.Add(Me.cmdOrderItems)
        Me.Controls.Add(Me.cmdCuisine)
        Me.Controls.Add(Me.cmdDriver)
        Me.Controls.Add(Me.cmdMap)
        Me.Controls.Add(Me.cmdDelete)
        Me.Controls.Add(Me.cmdEdit)
        Me.Controls.Add(Me.cmdGridView)
        Me.Controls.Add(Me.cmdReprint)
        Me.Controls.Add(Me.cmdTables)
        Me.Controls.Add(Me.cmdDelivColn)
        Me.Controls.Add(Me.cmdDown)
        Me.Controls.Add(Me.cmdUp)
        Me.Controls.Add(Me.ugdTableOrders)
        Me.Controls.Add(Me.ugdOrderGrid)
        Me.Name = "frmOrders"
        Me.Controls.SetChildIndex(Me.ugdOrderGrid, 0)
        Me.Controls.SetChildIndex(Me.ugdTableOrders, 0)
        Me.Controls.SetChildIndex(Me.cmdUp, 0)
        Me.Controls.SetChildIndex(Me.cmdDown, 0)
        Me.Controls.SetChildIndex(Me.cmdDelivColn, 0)
        Me.Controls.SetChildIndex(Me.cmdTables, 0)
        Me.Controls.SetChildIndex(Me.cmdReprint, 0)
        Me.Controls.SetChildIndex(Me.cmdGridView, 0)
        Me.Controls.SetChildIndex(Me.cmdEdit, 0)
        Me.Controls.SetChildIndex(Me.cmdDelete, 0)
        Me.Controls.SetChildIndex(Me.cmdMap, 0)
        Me.Controls.SetChildIndex(Me.cmdDriver, 0)
        Me.Controls.SetChildIndex(Me.cmdCuisine, 0)
        Me.Controls.SetChildIndex(Me.cmdOrderItems, 0)
        Me.Controls.SetChildIndex(Me.uplBasePanel, 0)
        Me.uplBasePanel.ClientArea.ResumeLayout(False)
        Me.uplBasePanel.ResumeLayout(False)
        CType(Me.ugdOrderGrid, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.OrdersBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EZMenuDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EZMenuDataSetBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.OrderItemsBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ugdTableOrders, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Table_BillBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents ugdOrderGrid As Infragistics.Win.UltraWinGrid.UltraGrid
    Friend WithEvents OrdersBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents OrdersTableAdapter As EZMenu.EZMenuDataSetTableAdapters.OrdersTableAdapter
    Friend WithEvents OrderItemsTableAdapter As EZMenu.EZMenuDataSetTableAdapters.OrderItemsTableAdapter
    Friend WithEvents OrderItemsBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents EZMenuDataSetBindingSource As System.Windows.Forms.BindingSource
    Private WithEvents EZMenuDataSet As EZMenu.EZMenuDataSet
    Friend WithEvents ugdTableOrders As Infragistics.Win.UltraWinGrid.UltraGrid
    Friend WithEvents Table_BillBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents Table_BillTableAdapter As EZMenu.EZMenuDataSetTableAdapters.Table_BillTableAdapter
    Friend WithEvents TableAdapterManager As EZMenu.EZMenuDataSetTableAdapters.TableAdapterManager
    Friend WithEvents cmdDriver As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdMap As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDelete As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdEdit As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdGridView As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdReprint As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdTables As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDelivColn As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDown As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdUp As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdReturn As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdCuisine As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdShowTotals As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdOrderItems As Infragistics.Win.Misc.UltraButton
End Class
