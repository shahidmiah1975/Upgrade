﻿Imports Infragistics.Win.Misc

Public Class frmDishCascadeMenu

    Dim _strItemName As String

    Private _blnIsConcise As Boolean = False
    Private _btnDish As UltraButton
    Private _drcDishaNames As DataRowCollection

    Public Sub New(drcDishNames As DataRowCollection, btnDish As UltraButton, blnIsConcise As Boolean)

        InitializeComponent()

        _btnDish = btnDish
        _blnIsConcise = blnIsConcise
        _drcDishaNames = drcDishNames

    End Sub

    Public Sub Display()

        Dim intCtr As Short = 1
        Dim myTop As Short = 0

        'lblOption.Text = $"Options for { _btnDish.Text }:"

        For Each myRow In drcDatarowCollection
            For Each myObj As Object In Controls
                If TypeName(myObj) = "UltraButton" AndAlso myObj.name.ToString.IndexOf(intCtr.ToString) <> -1 Then
                    Dim myObjs = CType(myObj, UltraButton)
                    myObj.text = myRow("DishName").ToString
                    If GetAppSettingCS("DishesUppercase", True) Then
                        myObj.text = myObj.text.ToString.ToUpper
                    End If
                    If GetAppSettingCS("DishesUseSimpleName", True) Then
                        myObj.text = Replace(myObj.text, _strItemName, "", , , CompareMethod.Text)
                    End If
                    If _blnIsConcise = True Then
                        myObj.tag = myRow("UniqueID")
                    Else
                        myObj.tag = myRow("DishName").ToString & "^" & myRow("PriceIn").ToString & "^" & myRow("PriceOut").ToString
                    End If

                    myObj.visible = True
                    intCtr += 1
                    myTop = myObj.top
                    Exit For
                End If
            Next
        Next

        CancelButton = cmdCancel
        cmdCancel.Top = myTop + (2.5 * cmdCancel.Height)
        Height = cmdCancel.Top + (2 * cmdCancel.Height)

        MinimumSize = Size
        MaximumSize = Size

        CenterToScreen()
        ShowDialog()

    End Sub

    Private Sub ButtonsHandler(sender As Object, e As EventArgs) Handles cmdDC1.Click, cmdDC2.Click, cmdDC3.Click, cmdDC4.Click, cmdDC5.Click, cmdDC6.Click, cmdDC7.Click, cmdDC8.Click, cmdDC9.Click

        tempStr = sender.tag
        Hide()

    End Sub

    Private Sub cmdCancel_Click(sender As Object, e As EventArgs) Handles cmdCancel.Click

        tempStr = ""
        Hide()

    End Sub

End Class