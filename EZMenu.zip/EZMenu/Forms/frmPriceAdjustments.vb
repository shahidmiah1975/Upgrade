﻿Imports Infragistics.Win.Misc
Imports EZControls
Imports EZMenu.Core.Enums
Imports EZMenu.Core.Models

Public Class frmPriceAdjustments

    Const strGlobalChargesOn As String = "On Global Charges"
    Const strGlobalChargesOff As String = "Off Global Charges"
    Const strGlobalDiscountsOn As String = "On Global Discounts"
    Const strGlobalDiscountsOff As String = "Off Global Discounts"
    Const strDefaultLabelDiscounts As String = "Discounts:"
    Const strDefaultLabelCharges As String = "Charges:"

    Private _orderType As OrderTypeEnum
    Private _returnValue As PriceAdjustmentsModel
    Private paDiscounts As PriceAdjustmentsModel
    Private paCharges As PriceAdjustmentsModel
    Private criteriaSuccess As Boolean

    Public Property ReturnValue
        Set(value)
            _returnValue = value
        End Set
        Get
            Return _returnValue
        End Get
    End Property

    Public Sub Display(orderType As OrderTypeEnum, ByRef paDiscount As PriceAdjustmentsModel, ByRef paCharge As PriceAdjustmentsModel)

        _orderType = orderType
        criteriaSuccess = True
        _returnValue = New PriceAdjustmentsModel
        paDiscounts = paDiscount
        paCharges = paCharge

        HighLightOff(upnlPercPounds)
        HighLightOff(upnlDiscChargeOptions)
        HighLightOff(upnlAppliesTo)

        SetupButtons()

        HighLightOn(cmdShowDiscounts)
        GetDiscounts()

        ShowDialog()

    End Sub

    Private Sub SetupButtons()

        cmdOK.Tag = cmdOK.Text
        cmdOK.Text = String.Empty
        AddHandler cmdOK.MouseEnter, AddressOf ButtonMouseEnter
        AddHandler cmdOK.MouseLeave, AddressOf ButtonMouseLeave

        cmdCancel.Tag = cmdCancel.Text
        cmdCancel.Text = String.Empty
        AddHandler cmdCancel.MouseEnter, AddressOf ButtonMouseEnter
        AddHandler cmdCancel.MouseLeave, AddressOf ButtonMouseLeave

        If _orderType = OrderTypeEnum.Table Then
            cmdAppliesToItem.Text = "Meal only"
            cmdAppliesToItem.Tag = "Meal"
            cmdAppliesToBill.Text = "Drinks only"
            cmdAppliesToBill.Tag = "Drinks"
            cmdAppliesToMealDrinks.Text = "Meal + Drinks"
            cmdAppliesToMealDrinks.Tag = "Both"
            cmdAppliesToMealDrinks.Visible = True
            HighLightOn(cmdAppliesToMealDrinks)
            ubtnDCToggleGlobal.Visible = False
        Else
            HighLightOn(cmdAppliesToBill)
            cmdAppliesToItem.Visible = False
            cmdAppliesToBill.Visible = False
            cmdAppliesToMealDrinks.Visible = False
        End If

    End Sub

    Private Sub NumHandler(sender As Object, e As EventArgs) Handles ubtn0.Click, ubtn1.Click, ubtn2.Click, ubtn3.Click, ubtn4.Click, ubtn5.Click, ubtn6.Click, ubtn7.Click, ubtn8.Click, ubtn9.Click

        If lblEntryBox.Text.Length = 10 Then Exit Sub

        HighLightOff(upnlDiscChargeOptions)

        Dim intNum As Short = sender.text
        Dim IsOK As Boolean = False

        Select Case intNum
            Case 0
                If lblEntryBox.Text <> "0" Then
                    IsOK = True
                End If

            Case 1 To 9
                If lblEntryBox.Text = "0" Then
                    lblEntryBox.Text = String.Empty
                End If
                IsOK = True

            Case Else

        End Select

        If IsOK Then lblEntryBox.Text += intNum.ToString

    End Sub

    Private Sub ubtnCancel_Click(sender As Object, e As EventArgs) Handles ubtnCancel.Click

        lblEntryBox.Text = "0"

    End Sub

    Private Sub FixedDCButtonHandler(sender As Object, e As EventArgs) Handles ubtnDC1.Click, ubtnDC2.Click, ubtnDC3.Click,
                                                                               ubtnDC4.Click, ubtnDC5.Click, ubtnDCNone.Click,
                                                                               ubtnDCToggleGlobal.Click
        If sender.text.ToString = "" Then Exit Sub

        lblEntryBox.Text = String.Empty
        HighLightOff(upnlPercPounds)
        HighLightOff(upnlDiscChargeOptions)
        HighLightOn(sender)

    End Sub

    Private Sub HighLightOff(upnlPanelName As UltraPanel)

        If upnlPanelName.Name = "upnlBlueButtons" Then
            For Each myBut As UltraButton In upnlPanelName.ClientArea.Controls
                myBut.Appearance.BackColor = Color.SteelBlue
                myBut.Appearance.BackColor2 = Color.LightSteelBlue
                myBut.Appearance.BorderColor = Color.Navy
                myBut.Appearance.ForeColor = Color.White
            Next

        ElseIf upnlPanelName.Name = "upnlDiscChargeOptions" Then
            For Each myBut As UltraButton In upnlDiscChargeOptions.ClientArea.Controls
                myBut.Appearance.BackColor = Color.FromArgb(230, 240, 230)
                myBut.Appearance.ForeColor = Color.DarkGreen
            Next
            ubtnDCNone.Appearance.BackColor = Color.FromArgb(230, 240, 230)
            ubtnDCNone.Appearance.ForeColor = Color.DarkGreen

        ElseIf upnlPanelName.Name = "upnlAppliesTo" Then
            For Each myBut As UltraButton In upnlAppliesTo.ClientArea.Controls
                myBut.Appearance.BackColor = Color.FromArgb(230, 240, 230)
                myBut.Appearance.ForeColor = Color.DarkGreen
            Next

        ElseIf upnlPanelName.Name = "upnlPercPounds" Then
            For Each myBut As UltraButton In upnlPercPounds.ClientArea.Controls
                myBut.Appearance.BackColor = Color.FromArgb(230, 240, 230)
                myBut.Appearance.ForeColor = Color.DarkGreen
            Next

        ElseIf upnlPanelName.Name = "upnlDiscCharges" Then
            For Each myBut As UltraButton In upnlDiscCharges.ClientArea.Controls
                myBut.Appearance.BackColor = Color.White
                myBut.Appearance.BackColor2 = Color.FromArgb(240, 240, 240)
                myBut.Appearance.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
                myBut.Appearance.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
                myBut.Appearance.BorderColor = Color.DarkGray
                myBut.Appearance.BorderColor2 = Color.Silver
                myBut.Appearance.BorderColor3DBase = Color.FromArgb(0, 192, 0)
                myBut.Appearance.ForeColor = Color.DimGray
                myBut.Appearance.TextVAlignAsString = "Middle"
            Next
        End If

    End Sub

    Private Sub HighLightOn(ctrlHL As UltraButton)

        ctrlHL.Appearance.BackColor = Color.Orange
        ctrlHL.Appearance.BackColor2 = Color.DarkOrange
        ctrlHL.Appearance.ForeColor = Color.Maroon

    End Sub

    Private Sub cmdOK_Click(sender As Object, e As EventArgs) Handles cmdOK.Click

        If _orderType = OrderTypeEnum.Table Then
            BuildPriceAdjustmentsObject()
        Else
            BuildPriceAdjustmentsObject()
        End If

        If criteriaSuccess = True Then
            Close()
        End If

    End Sub

    Private Sub BuildPriceAdjustmentsObject()

        Try
            criteriaSuccess = True

            'discount or charge
            If cmdShowDiscounts.Appearance.BackColor = Color.Orange Then
                _returnValue = paDiscounts
                _returnValue.DiscountOrCharge = DiscountOrChargeEnum.Discount
                If _returnValue.Name = "" Then _returnValue.Name = strDefaultLabelDiscounts
            ElseIf cmdShowCharges.Appearance.BackColor = Color.Orange Then
                _returnValue = paCharges
                _returnValue.DiscountOrCharge = DiscountOrChargeEnum.Charge
                If _returnValue.Name = "" Then _returnValue.Name = strDefaultLabelCharges
            Else
                strMsgBox = "Please select either 'Discounts' or 'Charges' option."
                EZMsgBox.Show(strMsgBox, MessageBoxButtons.OK)
                criteriaSuccess = False
                Exit Sub
            End If

            _returnValue.Reset = False

            'remove any selected discount/charge
            If ubtnDCNone.Appearance.BackColor = Color.Orange Then
                _returnValue.Name = "None"
                _returnValue.AmountOrPercentage = Nothing
                _returnValue.Value = 0
                _returnValue.Reset = True
                criteriaSuccess = True
                Exit Sub
            End If

            'code for toggling Global D/C
            If ubtnDCToggleGlobal.Appearance.BackColor = Color.Orange Then
                _returnValue.GlobalIsOff = IIf(ubtnDCToggleGlobal.Text.StartsWith("Off"), True, False)
                criteriaSuccess = True
                Exit Sub
            End If


            'check if any set discounts are applied
            Dim selectionDone As Boolean = False
            For Each myObj In upnlDiscChargeOptions.ClientArea.Controls
                If myObj.Appearance.BackColor = Color.Orange Then
                    Dim a_p As String = myObj.tag.ToString.Substring(0, 1).ToUpper
                    _returnValue.AmountOrPercentage = IIf(a_p = "P", AmountOrPercentageEnum.Percentage, AmountOrPercentageEnum.Amount)
                    _returnValue.Value = myObj.tag.ToString.Substring(1)
                    _returnValue.Name = myObj.Text
                    selectionDone = True
                    Exit For
                End If
            Next

            If selectionDone = False Then
                If lblEntryBox.Text = String.Empty Then
                    strMsgBox = "Please select an option or enter an amount/percentage."
                    EZMsgBox.Show(strMsgBox, MessageBoxButtons.OK)
                    criteriaSuccess = False
                    Exit Sub
                Else
                    _returnValue.Value = lblEntryBox.Text
                End If

                'amount or percentage
                If cmdPercentage.Appearance.BackColor = Color.Orange Then
                    _returnValue.AmountOrPercentage = AmountOrPercentageEnum.Percentage
                ElseIf cmdAmount.Appearance.BackColor = Color.Orange Then
                    _returnValue.AmountOrPercentage = AmountOrPercentageEnum.Amount
                Else
                    strMsgBox = "Please select '£' (amount) or '%' (percentage)"
                    EZMsgBox.Show(strMsgBox, MessageBoxButtons.OK)
                    criteriaSuccess = False
                    Exit Sub
                End If

                If cmdShowDiscounts.Appearance.BackColor = Color.Orange Then
                    _returnValue.Name = strDefaultLabelDiscounts
                Else
                    _returnValue.Name = strDefaultLabelCharges
                End If

            End If

            If _orderType = OrderTypeEnum.Table Then
                'amount on which to apply discount/charge
                If cmdAppliesToItem.Appearance.BackColor = Color.Orange Then
                    _returnValue.MealDrinksBoth = AppliesToTableEnum.MealOnly    'meal only
                ElseIf cmdAppliesToBill.Appearance.BackColor = Color.Orange Then
                    _returnValue.MealDrinksBoth = AppliesToTableEnum.DrinksOnly  'drinks only
                Else
                    _returnValue.MealDrinksBoth = AppliesToTableEnum.Both        'both
                End If
            End If

            _returnValue.Cancelled = False

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub cmdCancel_Click(sender As Object, e As EventArgs) Handles cmdCancel.Click

        _returnValue.Cancelled = True

        Close()

    End Sub

    Private Sub PercentAmount(sender As Object, e As EventArgs) Handles cmdAmount.Click, cmdPercentage.Click

        HighLightOff(upnlPercPounds)
        HighLightOff(upnlDiscChargeOptions)

        HighLightOn(sender)

        'CalcDiscounts()

    End Sub

    Private Sub TableDCHandler()

        'Try
        '    discount Or charge
        '    If cmdShowDiscounts.Appearance.BackColor = Color.Orange Then
        '        OrderDiscountsAndCharges.DiscOrChrg = "D"
        '    ElseIf cmdShowCharges.Appearance.BackColor = Color.Orange Then
        '        OrderDiscountsAndCharges.DiscOrChrg = "C"
        '    End If

        '    remove any selected discount/charge
        '    If ubtnDCNone.Appearance.BackColor = Color.Orange Then
        '        OrderDiscountsAndCharges.Reset = True

        '    Else
        '        amount on which to apply discount/charge
        '        If cmdAppliesToItem.Appearance.BackColor = Color.Orange Then
        '            OrderDiscountsAndCharges.MealDrinksBoth = AppliesToTable.MealOnly    'meal only
        '        ElseIf cmdAppliesToBill.Appearance.BackColor = Color.Orange Then
        '            OrderDiscountsAndCharges.MealDrinksBoth = AppliesToTable.DrinksOnly  'drinks only
        '        Else
        '            OrderDiscountsAndCharges.MealDrinksBoth = AppliesToTable.Both        'both
        '        End If

        '        amount Or percentage
        '        If cmdPercentage.Appearance.BackColor = Color.Orange Then
        '            OrderDiscountsAndCharges.AmtOrPercent = "P"
        '        ElseIf cmdAmount.Appearance.BackColor = Color.Orange Then
        '            OrderDiscountsAndCharges.AmtOrPercent = "A"
        '        End If

        '        OrderDiscountsAndCharges.Value = lblEntryBox.Text

        '        validations
        '        If OrderDiscountsAndCharges.AmtOrPercent = String.Empty Then
        '            strMsgBox = "Please select '£' (amount) or '%' (percentage)"
        '            EZMsgBox.Show(strMsgBox, MessageBoxButtons.OK)
        '            Exit Sub
        '        End If

        '        If OrderDiscountsAndCharges.Value = String.Empty Then
        '            strMsgBox = "Please enter an amount or percentage."
        '            EZMsgBox.Show(strMsgBox, MessageBoxButtons.OK)
        '            Exit Sub
        '        End If

        '    End If

        '    OrderDiscountsAndCharges.Cancelled = False

        '    ReturnValue = OrderDiscountsAndCharges

        'Catch ex As Exception
        '    DisplayError(ex)
        'End Try

    End Sub

    Private Sub DotHandler(sender As Object, e As EventArgs) Handles ubtnDot.Click

        If lblEntryBox.Text.Length = 10 Then Exit Sub

        If InStr(lblEntryBox.Text, ".") = 0 Then
            lblEntryBox.Text += "."
        End If

    End Sub

    Private Sub ButtonMouseEnter(sender As Object, e As EventArgs)
        sender.text = sender.tag
    End Sub

    Private Sub ButtonMouseLeave(sender As Object, e As EventArgs)
        sender.Text = String.Empty
    End Sub

    Private Sub AppliesToItemOrBill(sender As Object, e As EventArgs) Handles cmdAppliesToItem.Click, cmdAppliesToBill.Click, cmdAppliesToMealDrinks.Click

        HighLightOff(upnlAppliesTo)
        HighLightOn(sender)

    End Sub

    Private Sub ShowFixedDiscCharges(sender As Object, e As EventArgs) Handles cmdShowDiscounts.Click, cmdShowCharges.Click

        HighLightOff(upnlDiscCharges)
        HighLightOff(upnlDiscChargeOptions)
        HighLightOn(sender)

        If sender.text = "Charges" Then GetCharges() Else GetDiscounts()

    End Sub

    Private Sub ClearButtons()

        For Each myObj In upnlDiscChargeOptions.ClientArea.Controls
            If (TypeOf myObj Is UltraButton) Then
                myObj.text = String.Empty
            End If
        Next

    End Sub

    Private Sub GetCharges()

        ClearButtons()

        SQLQuery = "SELECT TOP 5 * FROM DiscCharges WHERE eType = 'Charge' ORDER BY eName ASC"
        drcDatarowCollection = objDB.GetDataRows(SQLQuery)
        If drcDatarowCollection IsNot Nothing AndAlso drcDatarowCollection.Count > 0 Then
            Dim intLoopCntr As Short = 0
            For Each myObj In upnlDiscChargeOptions.ClientArea.Controls
                If (TypeOf myObj Is UltraButton) Then
                    drDataRow = drcDatarowCollection.Item(intLoopCntr)
                    myObj.text = drDataRow.Item("eName").ToString
                    myObj.tag = drDataRow("eAorP").ToString & drDataRow("eValue").ToString
                    If myObj.text = paCharges.Name Then myObj.Appearance.BackColor = Color.Orange
                    intLoopCntr += 1
                    If intLoopCntr = drcDatarowCollection.Count Then Exit For
                End If
            Next
        End If

        ubtnDCNone.Text = "None"
        If paCharges.Name = ubtnDCNone.Text Then ubtnDCNone.Appearance.BackColor = Color.Orange
        ubtnDCToggleGlobal.Text = IIf(paCharges.GlobalIsOff = True, strGlobalChargesOn, strGlobalChargesOff)
        ubtnDCToggleGlobal.Enabled = GetAppSettingCS("AllChargesCheck", True)

    End Sub

    Private Sub GetDiscounts()

        ClearButtons()

        SQLQuery = "SELECT TOP 5 * FROM DiscCharges WHERE eType = 'Discount' ORDER BY eName ASC"
        drcDatarowCollection = objDB.GetDataRows(SQLQuery)
        If drcDatarowCollection IsNot Nothing AndAlso drcDatarowCollection.Count > 0 Then
            Dim intLoopCntr As Short = 0
            For Each myObj In upnlDiscChargeOptions.ClientArea.Controls
                If (TypeOf myObj Is UltraButton) Then
                    drDataRow = drcDatarowCollection.Item(intLoopCntr)
                    myObj.text = drDataRow.Item("eName").ToString
                    myObj.tag = drDataRow("eAorP").ToString & drDataRow("eValue").ToString
                    If myObj.text = paDiscounts.Name Then myObj.Appearance.BackColor = Color.Orange
                    intLoopCntr += 1
                    If intLoopCntr = drcDatarowCollection.Count Then Exit For
                End If
            Next
        End If

        ubtnDCNone.Text = "None"
        If paDiscounts.Name = ubtnDCNone.Text Then ubtnDCNone.Appearance.BackColor = Color.Orange
        ubtnDCToggleGlobal.Text = IIf(paDiscounts.GlobalIsOff = True, strGlobalDiscountsOn, strGlobalDiscountsOff)
        ubtnDCToggleGlobal.Enabled = GetAppSettingCS("AllDiscountsCheck", True)

    End Sub

End Class