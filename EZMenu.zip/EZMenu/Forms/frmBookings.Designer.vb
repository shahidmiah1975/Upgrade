﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmBookings
    Inherits EZMenu.frmBaseForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim Appearance4 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance5 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance6 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance7 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance8 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance9 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance10 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance11 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance12 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance13 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance14 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance15 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance16 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance17 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance18 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance19 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance20 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance21 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance22 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance23 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance24 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance25 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance26 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance27 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance28 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance29 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance30 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance31 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance32 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance33 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance34 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance35 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance36 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance37 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance38 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance39 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance40 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance41 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance42 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance43 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance44 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance45 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance46 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance47 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance48 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance49 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance50 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance51 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance52 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance53 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance54 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance55 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance56 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance57 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance58 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance59 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance60 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance61 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance62 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance63 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance64 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance65 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance66 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance67 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance68 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance69 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance70 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance71 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance72 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance73 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraGridBand1 As Infragistics.Win.UltraWinGrid.UltraGridBand = New Infragistics.Win.UltraWinGrid.UltraGridBand("Bookings", -1)
        Dim UltraGridColumn1 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("ID")
        Dim UltraGridColumn2 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Date")
        Dim UltraGridColumn3 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Time")
        Dim UltraGridColumn4 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Name")
        Dim UltraGridColumn5 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Covers")
        Dim UltraGridColumn6 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Table")
        Dim UltraGridColumn7 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Phone")
        Dim UltraGridColumn8 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Note")
        Dim UltraGridColumn9 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Status")
        Dim UltraGridColumn10 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("OnlineID")
        Dim Appearance74 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance75 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance76 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance77 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance78 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance79 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance80 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance81 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance82 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance83 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance84 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance1 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmBookings))
        Dim Appearance2 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance3 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance85 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance86 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance87 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance88 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance89 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance90 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance91 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance92 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance93 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Me.cmdStatus = New Infragistics.Win.Misc.UltraButton()
        Me.cmdViewSameDate = New Infragistics.Win.Misc.UltraButton()
        Me.cmdViewAll = New Infragistics.Win.Misc.UltraButton()
        Me.cmdOK = New Infragistics.Win.Misc.UltraButton()
        Me.cmdClearAll = New Infragistics.Win.Misc.UltraButton()
        Me.cmdEditBooking = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDeleteBooking = New Infragistics.Win.Misc.UltraButton()
        Me.cmdGridDown = New Infragistics.Win.Misc.UltraButton()
        Me.cmdGridUp = New Infragistics.Win.Misc.UltraButton()
        Me.cmdUpdate = New Infragistics.Win.Misc.UltraButton()
        Me.upnlCustomerInfo = New Infragistics.Win.Misc.UltraPanel()
        Me.lblBookings = New System.Windows.Forms.Label()
        Me.cmdKBTable = New Infragistics.Win.Misc.UltraButton()
        Me.cmdKBBookingNote = New Infragistics.Win.Misc.UltraButton()
        Me.cmdKBCovers = New Infragistics.Win.Misc.UltraButton()
        Me.cmdClearButton = New Infragistics.Win.Misc.UltraButton()
        Me.cmdViewCalendar = New Infragistics.Win.Misc.UltraButton()
        Me.cmdKBTelephone = New Infragistics.Win.Misc.UltraButton()
        Me.cmdKBTime = New Infragistics.Win.Misc.UltraButton()
        Me.cmdKBName = New Infragistics.Win.Misc.UltraButton()
        Me.UltraLabel5 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel6 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel7 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel4 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel3 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel2 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel1 = New Infragistics.Win.Misc.UltraLabel()
        Me.txtBookingNote = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtCovers = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtTable = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtBookingDate = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtTime = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtName = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtTelephone = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.ugdBookings = New Infragistics.Win.UltraWinGrid.UltraGrid()
        Me.UltraCalendarLook1 = New Infragistics.Win.UltraWinSchedule.UltraCalendarLook(Me.components)
        Me.cmdClose = New Infragistics.Win.Misc.UltraButton()
        Me.cmdOnlineBookings = New Infragistics.Win.Misc.UltraButton()
        Me.cmdOnlineBookingAccept = New Infragistics.Win.Misc.UltraButton()
        Me.cmdOnlineBookingReject = New Infragistics.Win.Misc.UltraButton()
        Me.uplBasePanel.ClientArea.SuspendLayout()
        Me.uplBasePanel.SuspendLayout()
        Me.upnlCustomerInfo.ClientArea.SuspendLayout()
        Me.upnlCustomerInfo.SuspendLayout()
        CType(Me.txtBookingNote, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtCovers, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTable, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtBookingDate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTime, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtName, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTelephone, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ugdBookings, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'uplBasePanel
        '
        '
        'uplBasePanel.ClientArea
        '
        Me.uplBasePanel.ClientArea.Controls.Add(Me.cmdClose)
        Me.uplBasePanel.Location = New System.Drawing.Point(0, 669)
        Me.uplBasePanel.Size = New System.Drawing.Size(1098, 50)
        '
        'cmdStatus
        '
        Me.cmdStatus.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance4.BackColor = System.Drawing.Color.Transparent
        Appearance4.BackColor2 = System.Drawing.Color.Transparent
        Appearance4.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance4.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance4.BorderColor = System.Drawing.Color.Transparent
        Appearance4.ForeColor = System.Drawing.Color.White
        Appearance4.Image = CType(resources.GetObject("Appearance4.Image"), Object)
        Appearance4.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance4.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance4.TextVAlignAsString = "Bottom"
        Me.cmdStatus.Appearance = Appearance4
        Me.cmdStatus.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance5.BackColor = System.Drawing.Color.DarkOrange
        Appearance5.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance5.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance5.ForeColor = System.Drawing.Color.Black
        Me.cmdStatus.HotTrackAppearance = Appearance5
        Me.cmdStatus.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdStatus.Location = New System.Drawing.Point(1040, 300)
        Me.cmdStatus.Name = "cmdStatus"
        Appearance6.BackColor = System.Drawing.Color.OrangeRed
        Appearance6.BackColor2 = System.Drawing.Color.Tomato
        Appearance6.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdStatus.PressedAppearance = Appearance6
        Me.cmdStatus.ShowFocusRect = False
        Me.cmdStatus.ShowOutline = False
        Me.cmdStatus.Size = New System.Drawing.Size(46, 45)
        Me.cmdStatus.StyleSetName = "StatusBar"
        Me.cmdStatus.TabIndex = 560
        Me.cmdStatus.Tag = "New"
        Me.cmdStatus.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdStatus.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdStatus.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdViewSameDate
        '
        Me.cmdViewSameDate.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance7.BackColor = System.Drawing.Color.Transparent
        Appearance7.BackColor2 = System.Drawing.Color.Transparent
        Appearance7.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance7.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance7.BorderColor = System.Drawing.Color.Transparent
        Appearance7.ForeColor = System.Drawing.Color.White
        Appearance7.Image = CType(resources.GetObject("Appearance7.Image"), Object)
        Appearance7.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance7.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance7.TextVAlignAsString = "Bottom"
        Me.cmdViewSameDate.Appearance = Appearance7
        Me.cmdViewSameDate.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance8.BackColor = System.Drawing.Color.DarkOrange
        Appearance8.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance8.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance8.ForeColor = System.Drawing.Color.Black
        Me.cmdViewSameDate.HotTrackAppearance = Appearance8
        Me.cmdViewSameDate.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdViewSameDate.Location = New System.Drawing.Point(1040, 400)
        Me.cmdViewSameDate.Name = "cmdViewSameDate"
        Appearance9.BackColor = System.Drawing.Color.OrangeRed
        Appearance9.BackColor2 = System.Drawing.Color.Tomato
        Appearance9.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdViewSameDate.PressedAppearance = Appearance9
        Me.cmdViewSameDate.ShowFocusRect = False
        Me.cmdViewSameDate.ShowOutline = False
        Me.cmdViewSameDate.Size = New System.Drawing.Size(46, 45)
        Me.cmdViewSameDate.StyleSetName = "StatusBar"
        Me.cmdViewSameDate.TabIndex = 559
        Me.cmdViewSameDate.Tag = "x"
        Me.cmdViewSameDate.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdViewSameDate.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdViewSameDate.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdViewAll
        '
        Me.cmdViewAll.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance10.BackColor = System.Drawing.Color.Transparent
        Appearance10.BackColor2 = System.Drawing.Color.Transparent
        Appearance10.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance10.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance10.BorderColor = System.Drawing.Color.Transparent
        Appearance10.ForeColor = System.Drawing.Color.White
        Appearance10.Image = CType(resources.GetObject("Appearance10.Image"), Object)
        Appearance10.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance10.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance10.TextVAlignAsString = "Bottom"
        Me.cmdViewAll.Appearance = Appearance10
        Me.cmdViewAll.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance11.BackColor = System.Drawing.Color.DarkOrange
        Appearance11.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance11.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance11.ForeColor = System.Drawing.Color.Black
        Me.cmdViewAll.HotTrackAppearance = Appearance11
        Me.cmdViewAll.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdViewAll.Location = New System.Drawing.Point(1040, 450)
        Me.cmdViewAll.Name = "cmdViewAll"
        Appearance12.BackColor = System.Drawing.Color.OrangeRed
        Appearance12.BackColor2 = System.Drawing.Color.Tomato
        Appearance12.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdViewAll.PressedAppearance = Appearance12
        Me.cmdViewAll.ShowFocusRect = False
        Me.cmdViewAll.ShowOutline = False
        Me.cmdViewAll.Size = New System.Drawing.Size(46, 45)
        Me.cmdViewAll.StyleSetName = "StatusBar"
        Me.cmdViewAll.TabIndex = 557
        Me.cmdViewAll.Tag = "x"
        Me.cmdViewAll.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdViewAll.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdViewAll.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdOK
        '
        Me.cmdOK.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance13.BackColor = System.Drawing.Color.Transparent
        Appearance13.BackColor2 = System.Drawing.Color.Transparent
        Appearance13.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance13.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance13.BorderColor = System.Drawing.Color.Transparent
        Appearance13.ForeColor = System.Drawing.Color.White
        Appearance13.Image = CType(resources.GetObject("Appearance13.Image"), Object)
        Appearance13.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance13.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance13.TextVAlignAsString = "Bottom"
        Me.cmdOK.Appearance = Appearance13
        Me.cmdOK.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance14.BackColor = System.Drawing.Color.DarkOrange
        Appearance14.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance14.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance14.ForeColor = System.Drawing.Color.Black
        Me.cmdOK.HotTrackAppearance = Appearance14
        Me.cmdOK.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdOK.Location = New System.Drawing.Point(1040, 50)
        Me.cmdOK.Name = "cmdOK"
        Appearance15.BackColor = System.Drawing.Color.OrangeRed
        Appearance15.BackColor2 = System.Drawing.Color.Tomato
        Appearance15.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdOK.PressedAppearance = Appearance15
        Me.cmdOK.ShowFocusRect = False
        Me.cmdOK.ShowOutline = False
        Me.cmdOK.Size = New System.Drawing.Size(46, 45)
        Me.cmdOK.StyleSetName = "StatusBar"
        Me.cmdOK.TabIndex = 556
        Me.cmdOK.Tag = "OK"
        Me.cmdOK.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOK.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOK.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdClearAll
        '
        Me.cmdClearAll.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance16.BackColor = System.Drawing.Color.Transparent
        Appearance16.BackColor2 = System.Drawing.Color.Transparent
        Appearance16.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance16.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance16.BorderColor = System.Drawing.Color.Transparent
        Appearance16.ForeColor = System.Drawing.Color.White
        Appearance16.Image = CType(resources.GetObject("Appearance16.Image"), Object)
        Appearance16.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance16.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance16.TextVAlignAsString = "Bottom"
        Me.cmdClearAll.Appearance = Appearance16
        Me.cmdClearAll.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance17.BackColor = System.Drawing.Color.DarkOrange
        Appearance17.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance17.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance17.ForeColor = System.Drawing.Color.Black
        Me.cmdClearAll.HotTrackAppearance = Appearance17
        Me.cmdClearAll.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdClearAll.Location = New System.Drawing.Point(1040, 100)
        Me.cmdClearAll.Name = "cmdClearAll"
        Appearance18.BackColor = System.Drawing.Color.OrangeRed
        Appearance18.BackColor2 = System.Drawing.Color.Tomato
        Appearance18.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdClearAll.PressedAppearance = Appearance18
        Me.cmdClearAll.ShowFocusRect = False
        Me.cmdClearAll.ShowOutline = False
        Me.cmdClearAll.Size = New System.Drawing.Size(46, 45)
        Me.cmdClearAll.StyleSetName = "StatusBar"
        Me.cmdClearAll.TabIndex = 554
        Me.cmdClearAll.Tag = "x"
        Me.cmdClearAll.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdClearAll.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdClearAll.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdEditBooking
        '
        Me.cmdEditBooking.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance19.BackColor = System.Drawing.Color.Transparent
        Appearance19.BackColor2 = System.Drawing.Color.Transparent
        Appearance19.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance19.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance19.BorderColor = System.Drawing.Color.Transparent
        Appearance19.ForeColor = System.Drawing.Color.White
        Appearance19.Image = CType(resources.GetObject("Appearance19.Image"), Object)
        Appearance19.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance19.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance19.TextVAlignAsString = "Bottom"
        Me.cmdEditBooking.Appearance = Appearance19
        Me.cmdEditBooking.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance20.BackColor = System.Drawing.Color.DarkOrange
        Appearance20.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance20.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance20.ForeColor = System.Drawing.Color.Black
        Me.cmdEditBooking.HotTrackAppearance = Appearance20
        Me.cmdEditBooking.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdEditBooking.Location = New System.Drawing.Point(1040, 350)
        Me.cmdEditBooking.Name = "cmdEditBooking"
        Appearance21.BackColor = System.Drawing.Color.OrangeRed
        Appearance21.BackColor2 = System.Drawing.Color.Tomato
        Appearance21.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdEditBooking.PressedAppearance = Appearance21
        Me.cmdEditBooking.ShowFocusRect = False
        Me.cmdEditBooking.ShowOutline = False
        Me.cmdEditBooking.Size = New System.Drawing.Size(46, 45)
        Me.cmdEditBooking.StyleSetName = "StatusBar"
        Me.cmdEditBooking.TabIndex = 555
        Me.cmdEditBooking.Tag = "New"
        Me.cmdEditBooking.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdEditBooking.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdEditBooking.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDeleteBooking
        '
        Me.cmdDeleteBooking.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance22.BackColor = System.Drawing.Color.Transparent
        Appearance22.BackColor2 = System.Drawing.Color.Transparent
        Appearance22.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance22.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance22.BorderColor = System.Drawing.Color.Transparent
        Appearance22.ForeColor = System.Drawing.Color.White
        Appearance22.Image = CType(resources.GetObject("Appearance22.Image"), Object)
        Appearance22.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance22.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance22.TextVAlignAsString = "Bottom"
        Me.cmdDeleteBooking.Appearance = Appearance22
        Me.cmdDeleteBooking.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance23.BackColor = System.Drawing.Color.DarkOrange
        Appearance23.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance23.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance23.ForeColor = System.Drawing.Color.Black
        Me.cmdDeleteBooking.HotTrackAppearance = Appearance23
        Me.cmdDeleteBooking.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdDeleteBooking.Location = New System.Drawing.Point(1040, 550)
        Me.cmdDeleteBooking.Name = "cmdDeleteBooking"
        Appearance24.BackColor = System.Drawing.Color.OrangeRed
        Appearance24.BackColor2 = System.Drawing.Color.Tomato
        Appearance24.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdDeleteBooking.PressedAppearance = Appearance24
        Me.cmdDeleteBooking.ShowFocusRect = False
        Me.cmdDeleteBooking.ShowOutline = False
        Me.cmdDeleteBooking.Size = New System.Drawing.Size(46, 45)
        Me.cmdDeleteBooking.StyleSetName = "StatusBar"
        Me.cmdDeleteBooking.TabIndex = 553
        Me.cmdDeleteBooking.Tag = "x"
        Me.cmdDeleteBooking.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDeleteBooking.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDeleteBooking.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdGridDown
        '
        Me.cmdGridDown.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance25.BackColor = System.Drawing.Color.Transparent
        Appearance25.BackColor2 = System.Drawing.Color.Transparent
        Appearance25.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance25.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance25.BorderColor = System.Drawing.Color.Transparent
        Appearance25.ForeColor = System.Drawing.Color.White
        Appearance25.Image = CType(resources.GetObject("Appearance25.Image"), Object)
        Appearance25.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance25.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance25.TextVAlignAsString = "Bottom"
        Me.cmdGridDown.Appearance = Appearance25
        Me.cmdGridDown.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance26.BackColor = System.Drawing.Color.DarkOrange
        Appearance26.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance26.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance26.ForeColor = System.Drawing.Color.Black
        Me.cmdGridDown.HotTrackAppearance = Appearance26
        Me.cmdGridDown.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdGridDown.Location = New System.Drawing.Point(1040, 250)
        Me.cmdGridDown.Name = "cmdGridDown"
        Appearance27.BackColor = System.Drawing.Color.OrangeRed
        Appearance27.BackColor2 = System.Drawing.Color.Tomato
        Appearance27.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdGridDown.PressedAppearance = Appearance27
        Me.cmdGridDown.ShowFocusRect = False
        Me.cmdGridDown.ShowOutline = False
        Me.cmdGridDown.Size = New System.Drawing.Size(46, 45)
        Me.cmdGridDown.StyleSetName = "StatusBar"
        Me.cmdGridDown.TabIndex = 552
        Me.cmdGridDown.Tag = "Down"
        Me.cmdGridDown.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdGridDown.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdGridDown.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdGridUp
        '
        Me.cmdGridUp.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance28.BackColor = System.Drawing.Color.Transparent
        Appearance28.BackColor2 = System.Drawing.Color.Transparent
        Appearance28.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance28.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance28.BorderColor = System.Drawing.Color.Transparent
        Appearance28.ForeColor = System.Drawing.Color.White
        Appearance28.Image = CType(resources.GetObject("Appearance28.Image"), Object)
        Appearance28.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance28.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance28.TextVAlignAsString = "Bottom"
        Me.cmdGridUp.Appearance = Appearance28
        Me.cmdGridUp.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance29.BackColor = System.Drawing.Color.DarkOrange
        Appearance29.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance29.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance29.ForeColor = System.Drawing.Color.Black
        Me.cmdGridUp.HotTrackAppearance = Appearance29
        Me.cmdGridUp.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdGridUp.Location = New System.Drawing.Point(1040, 200)
        Me.cmdGridUp.Name = "cmdGridUp"
        Appearance30.BackColor = System.Drawing.Color.OrangeRed
        Appearance30.BackColor2 = System.Drawing.Color.Tomato
        Appearance30.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdGridUp.PressedAppearance = Appearance30
        Me.cmdGridUp.ShowFocusRect = False
        Me.cmdGridUp.ShowOutline = False
        Me.cmdGridUp.Size = New System.Drawing.Size(46, 45)
        Me.cmdGridUp.StyleSetName = "StatusBar"
        Me.cmdGridUp.TabIndex = 551
        Me.cmdGridUp.Tag = "Up"
        Me.cmdGridUp.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdGridUp.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdGridUp.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdUpdate
        '
        Me.cmdUpdate.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance31.BackColor = System.Drawing.Color.Transparent
        Appearance31.BackColor2 = System.Drawing.Color.Transparent
        Appearance31.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance31.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance31.BorderColor = System.Drawing.Color.Transparent
        Appearance31.ForeColor = System.Drawing.Color.White
        Appearance31.Image = CType(resources.GetObject("Appearance31.Image"), Object)
        Appearance31.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance31.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance31.TextVAlignAsString = "Bottom"
        Me.cmdUpdate.Appearance = Appearance31
        Me.cmdUpdate.Enabled = False
        Me.cmdUpdate.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance32.BackColor = System.Drawing.Color.DarkOrange
        Appearance32.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance32.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance32.ForeColor = System.Drawing.Color.Black
        Me.cmdUpdate.HotTrackAppearance = Appearance32
        Me.cmdUpdate.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdUpdate.Location = New System.Drawing.Point(1040, 150)
        Me.cmdUpdate.Name = "cmdUpdate"
        Appearance33.BackColor = System.Drawing.Color.OrangeRed
        Appearance33.BackColor2 = System.Drawing.Color.Tomato
        Appearance33.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdUpdate.PressedAppearance = Appearance33
        Me.cmdUpdate.ShowFocusRect = False
        Me.cmdUpdate.ShowOutline = False
        Me.cmdUpdate.Size = New System.Drawing.Size(46, 45)
        Me.cmdUpdate.StyleSetName = "StatusBar"
        Me.cmdUpdate.TabIndex = 558
        Me.cmdUpdate.Tag = "Update"
        Me.cmdUpdate.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdUpdate.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdUpdate.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'upnlCustomerInfo
        '
        Me.upnlCustomerInfo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance34.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Appearance34.BorderColor = System.Drawing.Color.FromArgb(CType(CType(222, Byte), Integer), CType(CType(222, Byte), Integer), CType(CType(222, Byte), Integer))
        Me.upnlCustomerInfo.Appearance = Appearance34
        '
        'upnlCustomerInfo.ClientArea
        '
        Me.upnlCustomerInfo.ClientArea.Controls.Add(Me.lblBookings)
        Me.upnlCustomerInfo.ClientArea.Controls.Add(Me.cmdKBTable)
        Me.upnlCustomerInfo.ClientArea.Controls.Add(Me.cmdKBBookingNote)
        Me.upnlCustomerInfo.ClientArea.Controls.Add(Me.cmdKBCovers)
        Me.upnlCustomerInfo.ClientArea.Controls.Add(Me.cmdClearButton)
        Me.upnlCustomerInfo.ClientArea.Controls.Add(Me.cmdViewCalendar)
        Me.upnlCustomerInfo.ClientArea.Controls.Add(Me.cmdKBTelephone)
        Me.upnlCustomerInfo.ClientArea.Controls.Add(Me.cmdKBTime)
        Me.upnlCustomerInfo.ClientArea.Controls.Add(Me.cmdKBName)
        Me.upnlCustomerInfo.ClientArea.Controls.Add(Me.UltraLabel5)
        Me.upnlCustomerInfo.ClientArea.Controls.Add(Me.UltraLabel6)
        Me.upnlCustomerInfo.ClientArea.Controls.Add(Me.UltraLabel7)
        Me.upnlCustomerInfo.ClientArea.Controls.Add(Me.UltraLabel4)
        Me.upnlCustomerInfo.ClientArea.Controls.Add(Me.UltraLabel3)
        Me.upnlCustomerInfo.ClientArea.Controls.Add(Me.UltraLabel2)
        Me.upnlCustomerInfo.ClientArea.Controls.Add(Me.UltraLabel1)
        Me.upnlCustomerInfo.ClientArea.Controls.Add(Me.txtBookingNote)
        Me.upnlCustomerInfo.ClientArea.Controls.Add(Me.txtCovers)
        Me.upnlCustomerInfo.ClientArea.Controls.Add(Me.txtTable)
        Me.upnlCustomerInfo.ClientArea.Controls.Add(Me.txtBookingDate)
        Me.upnlCustomerInfo.ClientArea.Controls.Add(Me.txtTime)
        Me.upnlCustomerInfo.ClientArea.Controls.Add(Me.txtName)
        Me.upnlCustomerInfo.ClientArea.Controls.Add(Me.txtTelephone)
        Me.upnlCustomerInfo.Location = New System.Drawing.Point(2, 46)
        Me.upnlCustomerInfo.Name = "upnlCustomerInfo"
        Me.upnlCustomerInfo.Size = New System.Drawing.Size(1032, 226)
        Me.upnlCustomerInfo.TabIndex = 561
        '
        'lblBookings
        '
        Me.lblBookings.BackColor = System.Drawing.Color.Transparent
        Me.lblBookings.Font = New System.Drawing.Font("Franklin Gothic Medium", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBookings.ForeColor = System.Drawing.Color.SlateGray
        Me.lblBookings.Location = New System.Drawing.Point(7, 200)
        Me.lblBookings.Name = "lblBookings"
        Me.lblBookings.Size = New System.Drawing.Size(566, 18)
        Me.lblBookings.TabIndex = 549
        '
        'cmdKBTable
        '
        Appearance35.BackColor = System.Drawing.Color.Transparent
        Appearance35.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance35.BackGradientStyle = Infragistics.Win.GradientStyle.None
        Appearance35.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance35.BorderColor = System.Drawing.Color.Transparent
        Appearance35.BorderColor2 = System.Drawing.Color.Transparent
        Appearance35.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance35.ForeColor = System.Drawing.Color.Black
        Appearance35.Image = CType(resources.GetObject("Appearance35.Image"), Object)
        Appearance35.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance35.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance35.TextVAlignAsString = "Bottom"
        Me.cmdKBTable.Appearance = Appearance35
        Me.cmdKBTable.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdKBTable.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance36.BackColor = System.Drawing.Color.DarkOrange
        Appearance36.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance36.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance36.ForeColor = System.Drawing.Color.Black
        Me.cmdKBTable.HotTrackAppearance = Appearance36
        Me.cmdKBTable.ImageSize = New System.Drawing.Size(42, 25)
        Me.cmdKBTable.Location = New System.Drawing.Point(890, 56)
        Me.cmdKBTable.Name = "cmdKBTable"
        Appearance37.BackColor = System.Drawing.Color.Transparent
        Appearance37.BackColor2 = System.Drawing.Color.Transparent
        Me.cmdKBTable.PressedAppearance = Appearance37
        Me.cmdKBTable.ShowFocusRect = False
        Me.cmdKBTable.ShowOutline = False
        Me.cmdKBTable.Size = New System.Drawing.Size(42, 25)
        Me.cmdKBTable.TabIndex = 547
        Me.cmdKBTable.Tag = "Keyboard"
        Me.cmdKBTable.UseAppStyling = False
        Me.cmdKBTable.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBTable.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdKBTable.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdKBBookingNote
        '
        Appearance38.BackColor = System.Drawing.Color.Transparent
        Appearance38.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance38.BackGradientStyle = Infragistics.Win.GradientStyle.None
        Appearance38.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance38.BorderColor = System.Drawing.Color.Transparent
        Appearance38.BorderColor2 = System.Drawing.Color.Transparent
        Appearance38.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance38.ForeColor = System.Drawing.Color.Black
        Appearance38.Image = CType(resources.GetObject("Appearance38.Image"), Object)
        Appearance38.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance38.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance38.TextVAlignAsString = "Bottom"
        Me.cmdKBBookingNote.Appearance = Appearance38
        Me.cmdKBBookingNote.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdKBBookingNote.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance39.BackColor = System.Drawing.Color.DarkOrange
        Appearance39.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance39.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance39.ForeColor = System.Drawing.Color.Black
        Me.cmdKBBookingNote.HotTrackAppearance = Appearance39
        Me.cmdKBBookingNote.ImageSize = New System.Drawing.Size(42, 25)
        Me.cmdKBBookingNote.Location = New System.Drawing.Point(890, 91)
        Me.cmdKBBookingNote.Name = "cmdKBBookingNote"
        Appearance40.BackColor = System.Drawing.Color.Transparent
        Appearance40.BackColor2 = System.Drawing.Color.Transparent
        Me.cmdKBBookingNote.PressedAppearance = Appearance40
        Me.cmdKBBookingNote.ShowFocusRect = False
        Me.cmdKBBookingNote.ShowOutline = False
        Me.cmdKBBookingNote.Size = New System.Drawing.Size(42, 25)
        Me.cmdKBBookingNote.TabIndex = 548
        Me.cmdKBBookingNote.Tag = "Keyboard"
        Me.cmdKBBookingNote.UseAppStyling = False
        Me.cmdKBBookingNote.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBBookingNote.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdKBBookingNote.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdKBCovers
        '
        Appearance41.BackColor = System.Drawing.Color.Transparent
        Appearance41.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance41.BackGradientStyle = Infragistics.Win.GradientStyle.None
        Appearance41.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance41.BorderColor = System.Drawing.Color.Transparent
        Appearance41.BorderColor2 = System.Drawing.Color.Transparent
        Appearance41.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance41.ForeColor = System.Drawing.Color.Black
        Appearance41.Image = CType(resources.GetObject("Appearance41.Image"), Object)
        Appearance41.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance41.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance41.TextVAlignAsString = "Bottom"
        Me.cmdKBCovers.Appearance = Appearance41
        Me.cmdKBCovers.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdKBCovers.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance42.BackColor = System.Drawing.Color.DarkOrange
        Appearance42.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance42.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance42.ForeColor = System.Drawing.Color.Black
        Me.cmdKBCovers.HotTrackAppearance = Appearance42
        Me.cmdKBCovers.ImageSize = New System.Drawing.Size(42, 25)
        Me.cmdKBCovers.Location = New System.Drawing.Point(890, 22)
        Me.cmdKBCovers.Name = "cmdKBCovers"
        Appearance43.BackColor = System.Drawing.Color.Transparent
        Appearance43.BackColor2 = System.Drawing.Color.Transparent
        Me.cmdKBCovers.PressedAppearance = Appearance43
        Me.cmdKBCovers.ShowFocusRect = False
        Me.cmdKBCovers.ShowOutline = False
        Me.cmdKBCovers.Size = New System.Drawing.Size(42, 25)
        Me.cmdKBCovers.TabIndex = 546
        Me.cmdKBCovers.Tag = "Keyboard"
        Me.cmdKBCovers.UseAppStyling = False
        Me.cmdKBCovers.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBCovers.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdKBCovers.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdClearButton
        '
        Appearance44.BackColor = System.Drawing.Color.Transparent
        Appearance44.BackColor2 = System.Drawing.Color.Transparent
        Appearance44.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance44.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance44.BorderColor = System.Drawing.Color.Transparent
        Appearance44.BorderColor2 = System.Drawing.Color.Maroon
        Appearance44.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance44.ForeColor = System.Drawing.Color.Black
        Appearance44.Image = CType(resources.GetObject("Appearance44.Image"), Object)
        Appearance44.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance44.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance44.TextVAlignAsString = "Bottom"
        Me.cmdClearButton.Appearance = Appearance44
        Me.cmdClearButton.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance45.BackColor = System.Drawing.Color.DarkOrange
        Appearance45.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance45.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance45.ForeColor = System.Drawing.Color.Black
        Me.cmdClearButton.HotTrackAppearance = Appearance45
        Me.cmdClearButton.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdClearButton.Location = New System.Drawing.Point(512, 18)
        Me.cmdClearButton.Name = "cmdClearButton"
        Appearance46.BackColor = System.Drawing.Color.OrangeRed
        Appearance46.BackColor2 = System.Drawing.Color.Tomato
        Appearance46.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdClearButton.PressedAppearance = Appearance46
        Me.cmdClearButton.ShowFocusRect = False
        Me.cmdClearButton.ShowOutline = False
        Me.cmdClearButton.Size = New System.Drawing.Size(35, 35)
        Me.cmdClearButton.TabIndex = 542
        Me.cmdClearButton.TabStop = False
        Me.cmdClearButton.Tag = ""
        Me.cmdClearButton.UseAppStyling = False
        Me.cmdClearButton.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdClearButton.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdClearButton.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdClearButton.Visible = False
        '
        'cmdViewCalendar
        '
        Appearance47.BackColor = System.Drawing.Color.Transparent
        Appearance47.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance47.BackGradientStyle = Infragistics.Win.GradientStyle.None
        Appearance47.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance47.BorderColor = System.Drawing.Color.Transparent
        Appearance47.BorderColor2 = System.Drawing.Color.Transparent
        Appearance47.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance47.ForeColor = System.Drawing.Color.Black
        Appearance47.Image = CType(resources.GetObject("Appearance47.Image"), Object)
        Appearance47.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance47.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance47.TextVAlignAsString = "Bottom"
        Me.cmdViewCalendar.Appearance = Appearance47
        Me.cmdViewCalendar.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdViewCalendar.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance48.BackColor = System.Drawing.Color.DarkOrange
        Appearance48.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance48.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance48.ForeColor = System.Drawing.Color.Black
        Me.cmdViewCalendar.HotTrackAppearance = Appearance48
        Me.cmdViewCalendar.ImageSize = New System.Drawing.Size(42, 25)
        Me.cmdViewCalendar.Location = New System.Drawing.Point(464, 21)
        Me.cmdViewCalendar.Name = "cmdViewCalendar"
        Appearance49.BackColor = System.Drawing.Color.Transparent
        Appearance49.BackColor2 = System.Drawing.Color.Transparent
        Me.cmdViewCalendar.PressedAppearance = Appearance49
        Me.cmdViewCalendar.ShowFocusRect = False
        Me.cmdViewCalendar.ShowOutline = False
        Me.cmdViewCalendar.Size = New System.Drawing.Size(42, 25)
        Me.cmdViewCalendar.TabIndex = 541
        Me.cmdViewCalendar.Tag = "Keyboard"
        Me.cmdViewCalendar.UseAppStyling = False
        Me.cmdViewCalendar.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdViewCalendar.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdViewCalendar.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdKBTelephone
        '
        Appearance50.BackColor = System.Drawing.Color.Transparent
        Appearance50.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance50.BackGradientStyle = Infragistics.Win.GradientStyle.None
        Appearance50.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance50.BorderColor = System.Drawing.Color.Transparent
        Appearance50.BorderColor2 = System.Drawing.Color.Transparent
        Appearance50.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance50.ForeColor = System.Drawing.Color.Black
        Appearance50.Image = CType(resources.GetObject("Appearance50.Image"), Object)
        Appearance50.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance50.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance50.TextVAlignAsString = "Bottom"
        Me.cmdKBTelephone.Appearance = Appearance50
        Me.cmdKBTelephone.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdKBTelephone.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance51.BackColor = System.Drawing.Color.DarkOrange
        Appearance51.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance51.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance51.ForeColor = System.Drawing.Color.Black
        Me.cmdKBTelephone.HotTrackAppearance = Appearance51
        Me.cmdKBTelephone.ImageSize = New System.Drawing.Size(42, 25)
        Me.cmdKBTelephone.Location = New System.Drawing.Point(464, 90)
        Me.cmdKBTelephone.Name = "cmdKBTelephone"
        Appearance52.BackColor = System.Drawing.Color.Transparent
        Appearance52.BackColor2 = System.Drawing.Color.Transparent
        Me.cmdKBTelephone.PressedAppearance = Appearance52
        Me.cmdKBTelephone.ShowFocusRect = False
        Me.cmdKBTelephone.ShowOutline = False
        Me.cmdKBTelephone.Size = New System.Drawing.Size(42, 25)
        Me.cmdKBTelephone.TabIndex = 544
        Me.cmdKBTelephone.Tag = "Keyboard"
        Me.cmdKBTelephone.UseAppStyling = False
        Me.cmdKBTelephone.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBTelephone.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdKBTelephone.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdKBTime
        '
        Appearance53.BackColor = System.Drawing.Color.Transparent
        Appearance53.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance53.BackGradientStyle = Infragistics.Win.GradientStyle.None
        Appearance53.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance53.BorderColor = System.Drawing.Color.Transparent
        Appearance53.BorderColor2 = System.Drawing.Color.Transparent
        Appearance53.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance53.ForeColor = System.Drawing.Color.Black
        Appearance53.Image = CType(resources.GetObject("Appearance53.Image"), Object)
        Appearance53.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance53.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance53.TextVAlignAsString = "Bottom"
        Me.cmdKBTime.Appearance = Appearance53
        Me.cmdKBTime.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdKBTime.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance54.BackColor = System.Drawing.Color.DarkOrange
        Appearance54.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance54.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance54.ForeColor = System.Drawing.Color.Black
        Me.cmdKBTime.HotTrackAppearance = Appearance54
        Me.cmdKBTime.ImageSize = New System.Drawing.Size(42, 25)
        Me.cmdKBTime.Location = New System.Drawing.Point(464, 126)
        Me.cmdKBTime.Name = "cmdKBTime"
        Appearance55.BackColor = System.Drawing.Color.Transparent
        Appearance55.BackColor2 = System.Drawing.Color.Transparent
        Me.cmdKBTime.PressedAppearance = Appearance55
        Me.cmdKBTime.ShowFocusRect = False
        Me.cmdKBTime.ShowOutline = False
        Me.cmdKBTime.Size = New System.Drawing.Size(42, 25)
        Me.cmdKBTime.TabIndex = 545
        Me.cmdKBTime.Tag = "Keyboard"
        Me.cmdKBTime.UseAppStyling = False
        Me.cmdKBTime.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBTime.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdKBTime.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdKBName
        '
        Appearance56.BackColor = System.Drawing.Color.Transparent
        Appearance56.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance56.BackGradientStyle = Infragistics.Win.GradientStyle.None
        Appearance56.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance56.BorderColor = System.Drawing.Color.Transparent
        Appearance56.BorderColor2 = System.Drawing.Color.Transparent
        Appearance56.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance56.ForeColor = System.Drawing.Color.Black
        Appearance56.Image = CType(resources.GetObject("Appearance56.Image"), Object)
        Appearance56.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance56.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance56.TextVAlignAsString = "Bottom"
        Me.cmdKBName.Appearance = Appearance56
        Me.cmdKBName.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdKBName.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance57.BackColor = System.Drawing.Color.DarkOrange
        Appearance57.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance57.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance57.ForeColor = System.Drawing.Color.Black
        Me.cmdKBName.HotTrackAppearance = Appearance57
        Me.cmdKBName.ImageSize = New System.Drawing.Size(42, 25)
        Me.cmdKBName.Location = New System.Drawing.Point(464, 55)
        Me.cmdKBName.Name = "cmdKBName"
        Appearance58.BackColor = System.Drawing.Color.Transparent
        Appearance58.BackColor2 = System.Drawing.Color.Transparent
        Me.cmdKBName.PressedAppearance = Appearance58
        Me.cmdKBName.ShowFocusRect = False
        Me.cmdKBName.ShowOutline = False
        Me.cmdKBName.Size = New System.Drawing.Size(42, 25)
        Me.cmdKBName.TabIndex = 543
        Me.cmdKBName.Tag = "Keyboard"
        Me.cmdKBName.UseAppStyling = False
        Me.cmdKBName.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBName.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdKBName.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraLabel5
        '
        Appearance59.BackColor = System.Drawing.Color.Transparent
        Appearance59.ForeColor = System.Drawing.Color.DimGray
        Appearance59.TextHAlignAsString = "Right"
        Me.UltraLabel5.Appearance = Appearance59
        Me.UltraLabel5.AutoSize = True
        Me.UltraLabel5.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UltraLabel5.Location = New System.Drawing.Point(587, 94)
        Me.UltraLabel5.Name = "UltraLabel5"
        Me.UltraLabel5.Size = New System.Drawing.Size(45, 20)
        Me.UltraLabel5.StyleSetName = "TextEntryLabel"
        Me.UltraLabel5.TabIndex = 540
        Me.UltraLabel5.Text = "Note:"
        Me.UltraLabel5.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraLabel6
        '
        Appearance60.BackColor = System.Drawing.Color.Transparent
        Appearance60.ForeColor = System.Drawing.Color.DimGray
        Appearance60.TextHAlignAsString = "Right"
        Me.UltraLabel6.Appearance = Appearance60
        Me.UltraLabel6.AutoSize = True
        Me.UltraLabel6.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UltraLabel6.Location = New System.Drawing.Point(587, 60)
        Me.UltraLabel6.Name = "UltraLabel6"
        Me.UltraLabel6.Size = New System.Drawing.Size(52, 20)
        Me.UltraLabel6.StyleSetName = "TextEntryLabel"
        Me.UltraLabel6.TabIndex = 539
        Me.UltraLabel6.Text = "Table:"
        Me.UltraLabel6.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraLabel7
        '
        Appearance61.BackColor = System.Drawing.Color.Transparent
        Appearance61.ForeColor = System.Drawing.Color.DimGray
        Appearance61.TextHAlignAsString = "Right"
        Me.UltraLabel7.Appearance = Appearance61
        Me.UltraLabel7.AutoSize = True
        Me.UltraLabel7.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UltraLabel7.Location = New System.Drawing.Point(587, 26)
        Me.UltraLabel7.Name = "UltraLabel7"
        Me.UltraLabel7.Size = New System.Drawing.Size(63, 20)
        Me.UltraLabel7.StyleSetName = "TextEntryLabel"
        Me.UltraLabel7.TabIndex = 538
        Me.UltraLabel7.Text = "Covers:"
        Me.UltraLabel7.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraLabel4
        '
        Appearance62.BackColor = System.Drawing.Color.Transparent
        Appearance62.ForeColor = System.Drawing.Color.DimGray
        Appearance62.TextHAlignAsString = "Right"
        Me.UltraLabel4.Appearance = Appearance62
        Me.UltraLabel4.AutoSize = True
        Me.UltraLabel4.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UltraLabel4.Location = New System.Drawing.Point(161, 129)
        Me.UltraLabel4.Name = "UltraLabel4"
        Me.UltraLabel4.Size = New System.Drawing.Size(47, 20)
        Me.UltraLabel4.StyleSetName = "TextEntryLabel"
        Me.UltraLabel4.TabIndex = 537
        Me.UltraLabel4.Text = "Time:"
        Me.UltraLabel4.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraLabel3
        '
        Appearance63.BackColor = System.Drawing.Color.Transparent
        Appearance63.ForeColor = System.Drawing.Color.DimGray
        Appearance63.TextHAlignAsString = "Right"
        Me.UltraLabel3.Appearance = Appearance63
        Me.UltraLabel3.AutoSize = True
        Me.UltraLabel3.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UltraLabel3.Location = New System.Drawing.Point(161, 95)
        Me.UltraLabel3.Name = "UltraLabel3"
        Me.UltraLabel3.Size = New System.Drawing.Size(88, 20)
        Me.UltraLabel3.StyleSetName = "TextEntryLabel"
        Me.UltraLabel3.TabIndex = 536
        Me.UltraLabel3.Text = "Telephone:"
        Me.UltraLabel3.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraLabel2
        '
        Appearance64.BackColor = System.Drawing.Color.Transparent
        Appearance64.ForeColor = System.Drawing.Color.DimGray
        Appearance64.TextHAlignAsString = "Right"
        Me.UltraLabel2.Appearance = Appearance64
        Me.UltraLabel2.AutoSize = True
        Me.UltraLabel2.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UltraLabel2.Location = New System.Drawing.Point(161, 60)
        Me.UltraLabel2.Name = "UltraLabel2"
        Me.UltraLabel2.Size = New System.Drawing.Size(54, 20)
        Me.UltraLabel2.StyleSetName = "TextEntryLabel"
        Me.UltraLabel2.TabIndex = 535
        Me.UltraLabel2.Text = "Name:"
        Me.UltraLabel2.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraLabel1
        '
        Appearance65.BackColor = System.Drawing.Color.Transparent
        Appearance65.ForeColor = System.Drawing.Color.DimGray
        Appearance65.TextHAlignAsString = "Right"
        Me.UltraLabel1.Appearance = Appearance65
        Me.UltraLabel1.AutoSize = True
        Me.UltraLabel1.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UltraLabel1.Location = New System.Drawing.Point(161, 26)
        Me.UltraLabel1.Name = "UltraLabel1"
        Me.UltraLabel1.Size = New System.Drawing.Size(45, 20)
        Me.UltraLabel1.StyleSetName = "TextEntryLabel"
        Me.UltraLabel1.TabIndex = 534
        Me.UltraLabel1.Text = "Date:"
        Me.UltraLabel1.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtBookingNote
        '
        Appearance66.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance66.BorderColor = System.Drawing.Color.LightGray
        Appearance66.BorderColor2 = System.Drawing.Color.Yellow
        Appearance66.BorderColor3DBase = System.Drawing.Color.Teal
        Appearance66.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Me.txtBookingNote.Appearance = Appearance66
        Me.txtBookingNote.AutoSize = False
        Me.txtBookingNote.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtBookingNote.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtBookingNote.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBookingNote.Location = New System.Drawing.Point(681, 89)
        Me.txtBookingNote.MaxLength = 15
        Me.txtBookingNote.Name = "txtBookingNote"
        Me.txtBookingNote.Size = New System.Drawing.Size(203, 28)
        Me.txtBookingNote.StyleSetName = "TextEntry"
        Me.txtBookingNote.TabIndex = 524
        Me.txtBookingNote.UseAppStyling = False
        Me.txtBookingNote.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtBookingNote.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtCovers
        '
        Appearance67.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance67.BorderColor = System.Drawing.Color.LightGray
        Appearance67.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Me.txtCovers.Appearance = Appearance67
        Me.txtCovers.AutoSize = False
        Me.txtCovers.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtCovers.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtCovers.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCovers.Location = New System.Drawing.Point(681, 21)
        Me.txtCovers.MaxLength = 50
        Me.txtCovers.Name = "txtCovers"
        Me.txtCovers.Size = New System.Drawing.Size(203, 28)
        Me.txtCovers.StyleSetName = "TextEntry"
        Me.txtCovers.TabIndex = 523
        Me.txtCovers.UseAppStyling = False
        Me.txtCovers.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtCovers.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtTable
        '
        Appearance68.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance68.BorderColor = System.Drawing.Color.LightGray
        Appearance68.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Me.txtTable.Appearance = Appearance68
        Me.txtTable.AutoSize = False
        Me.txtTable.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtTable.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtTable.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTable.Location = New System.Drawing.Point(681, 55)
        Me.txtTable.MaxLength = 10
        Me.txtTable.Name = "txtTable"
        Me.txtTable.Size = New System.Drawing.Size(203, 28)
        Me.txtTable.StyleSetName = "TextEntry"
        Me.txtTable.TabIndex = 524
        Me.txtTable.UseAppStyling = False
        Me.txtTable.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtTable.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtBookingDate
        '
        Appearance69.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance69.BorderColor = System.Drawing.Color.LightGray
        Appearance69.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Me.txtBookingDate.Appearance = Appearance69
        Me.txtBookingDate.AutoSize = False
        Me.txtBookingDate.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtBookingDate.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtBookingDate.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBookingDate.Location = New System.Drawing.Point(255, 21)
        Me.txtBookingDate.MaxLength = 50
        Me.txtBookingDate.Name = "txtBookingDate"
        Me.txtBookingDate.Size = New System.Drawing.Size(203, 28)
        Me.txtBookingDate.StyleSetName = "TextEntry"
        Me.txtBookingDate.TabIndex = 519
        Me.txtBookingDate.UseAppStyling = False
        Me.txtBookingDate.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtBookingDate.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtTime
        '
        Appearance70.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance70.BorderColor = System.Drawing.Color.LightGray
        Appearance70.BorderColor2 = System.Drawing.Color.Yellow
        Appearance70.BorderColor3DBase = System.Drawing.Color.Teal
        Appearance70.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Me.txtTime.Appearance = Appearance70
        Me.txtTime.AutoSize = False
        Me.txtTime.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtTime.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtTime.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTime.Location = New System.Drawing.Point(255, 124)
        Me.txtTime.MaxLength = 15
        Me.txtTime.Name = "txtTime"
        Me.txtTime.Size = New System.Drawing.Size(203, 28)
        Me.txtTime.StyleSetName = "TextEntry"
        Me.txtTime.TabIndex = 522
        Me.txtTime.UseAppStyling = False
        Me.txtTime.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtTime.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtName
        '
        Appearance71.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance71.BorderColor = System.Drawing.Color.LightGray
        Appearance71.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Me.txtName.Appearance = Appearance71
        Me.txtName.AutoSize = False
        Me.txtName.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtName.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtName.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName.Location = New System.Drawing.Point(255, 55)
        Me.txtName.MaxLength = 50
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(203, 28)
        Me.txtName.StyleSetName = "TextEntry"
        Me.txtName.TabIndex = 520
        Me.txtName.UseAppStyling = False
        Me.txtName.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtName.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtTelephone
        '
        Appearance72.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance72.BorderColor = System.Drawing.Color.LightGray
        Appearance72.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Me.txtTelephone.Appearance = Appearance72
        Me.txtTelephone.AutoSize = False
        Me.txtTelephone.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtTelephone.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtTelephone.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTelephone.Location = New System.Drawing.Point(255, 90)
        Me.txtTelephone.MaxLength = 11
        Me.txtTelephone.Name = "txtTelephone"
        Me.txtTelephone.Size = New System.Drawing.Size(203, 28)
        Me.txtTelephone.StyleSetName = "TextEntry"
        Me.txtTelephone.TabIndex = 521
        Me.txtTelephone.UseAppStyling = False
        Me.txtTelephone.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtTelephone.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ugdBookings
        '
        Me.ugdBookings.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance73.BackColor = System.Drawing.Color.Transparent
        Appearance73.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Me.ugdBookings.DisplayLayout.Appearance = Appearance73
        UltraGridColumn1.Header.VisiblePosition = 0
        UltraGridColumn1.Hidden = True
        UltraGridColumn2.Format = "dd/MM/yyyy"
        UltraGridColumn2.Header.VisiblePosition = 1
        UltraGridColumn3.Header.VisiblePosition = 2
        UltraGridColumn4.Header.VisiblePosition = 3
        UltraGridColumn4.Width = 157
        UltraGridColumn5.Header.VisiblePosition = 4
        UltraGridColumn5.Width = 98
        UltraGridColumn6.Header.VisiblePosition = 5
        UltraGridColumn6.Width = 92
        UltraGridColumn7.Header.VisiblePosition = 6
        UltraGridColumn8.Header.VisiblePosition = 7
        UltraGridColumn8.Width = 271
        UltraGridColumn9.Header.VisiblePosition = 8
        UltraGridColumn9.Hidden = True
        UltraGridColumn10.Header.VisiblePosition = 9
        UltraGridColumn10.Hidden = True
        UltraGridBand1.Columns.AddRange(New Object() {UltraGridColumn1, UltraGridColumn2, UltraGridColumn3, UltraGridColumn4, UltraGridColumn5, UltraGridColumn6, UltraGridColumn7, UltraGridColumn8, UltraGridColumn9, UltraGridColumn10})
        Me.ugdBookings.DisplayLayout.BandsSerializer.Add(UltraGridBand1)
        Me.ugdBookings.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Me.ugdBookings.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.[False]
        Appearance74.BackColor = System.Drawing.SystemColors.ActiveBorder
        Appearance74.BackColor2 = System.Drawing.SystemColors.ControlDark
        Appearance74.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance74.BorderColor = System.Drawing.SystemColors.Window
        Me.ugdBookings.DisplayLayout.GroupByBox.Appearance = Appearance74
        Appearance75.ForeColor = System.Drawing.SystemColors.GrayText
        Me.ugdBookings.DisplayLayout.GroupByBox.BandLabelAppearance = Appearance75
        Me.ugdBookings.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Appearance76.BackColor = System.Drawing.SystemColors.ControlLightLight
        Appearance76.BackColor2 = System.Drawing.SystemColors.Control
        Appearance76.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal
        Appearance76.ForeColor = System.Drawing.SystemColors.GrayText
        Me.ugdBookings.DisplayLayout.GroupByBox.PromptAppearance = Appearance76
        Me.ugdBookings.DisplayLayout.MaxColScrollRegions = 1
        Me.ugdBookings.DisplayLayout.MaxRowScrollRegions = 1
        Appearance77.BackColor = System.Drawing.Color.Orange
        Appearance77.BackColor2 = System.Drawing.Color.DarkOrange
        Appearance77.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ugdBookings.DisplayLayout.Override.ActiveRowAppearance = Appearance77
        Me.ugdBookings.DisplayLayout.Override.AllowColMoving = Infragistics.Win.UltraWinGrid.AllowColMoving.NotAllowed
        Me.ugdBookings.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted
        Me.ugdBookings.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted
        Appearance78.BackColor = System.Drawing.SystemColors.Window
        Me.ugdBookings.DisplayLayout.Override.CardAreaAppearance = Appearance78
        Appearance79.BorderColor = System.Drawing.Color.Silver
        Appearance79.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter
        Me.ugdBookings.DisplayLayout.Override.CellAppearance = Appearance79
        Me.ugdBookings.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.EditAndSelectText
        Me.ugdBookings.DisplayLayout.Override.CellPadding = 0
        Appearance80.BackColor = System.Drawing.SystemColors.Control
        Appearance80.BackColor2 = System.Drawing.SystemColors.ControlDark
        Appearance80.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element
        Appearance80.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal
        Appearance80.BorderColor = System.Drawing.SystemColors.Window
        Me.ugdBookings.DisplayLayout.Override.GroupByRowAppearance = Appearance80
        Appearance81.BackColor = System.Drawing.Color.FromArgb(CType(CType(162, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance81.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(162, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance81.TextHAlignAsString = "Center"
        Me.ugdBookings.DisplayLayout.Override.HeaderAppearance = Appearance81
        Me.ugdBookings.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti
        Me.ugdBookings.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand
        Appearance82.BackColor = System.Drawing.Color.FromArgb(CType(CType(252, Byte), Integer), CType(CType(252, Byte), Integer), CType(CType(252, Byte), Integer))
        Me.ugdBookings.DisplayLayout.Override.RowAlternateAppearance = Appearance82
        Appearance83.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.ugdBookings.DisplayLayout.Override.RowAppearance = Appearance83
        Me.ugdBookings.DisplayLayout.Override.RowSelectorHeaderStyle = Infragistics.Win.UltraWinGrid.RowSelectorHeaderStyle.SeparateElement
        Me.ugdBookings.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.[True]
        Me.ugdBookings.DisplayLayout.Override.RowSizing = Infragistics.Win.UltraWinGrid.RowSizing.Sychronized
        Me.ugdBookings.DisplayLayout.Override.RowSizingArea = Infragistics.Win.UltraWinGrid.RowSizingArea.RowBordersOnly
        Me.ugdBookings.DisplayLayout.Override.SelectTypeCol = Infragistics.Win.UltraWinGrid.SelectType.None
        Me.ugdBookings.DisplayLayout.Override.SelectTypeRow = Infragistics.Win.UltraWinGrid.SelectType.[Single]
        Appearance84.BackColor = System.Drawing.SystemColors.ControlLight
        Me.ugdBookings.DisplayLayout.Override.TemplateAddRowAppearance = Appearance84
        Me.ugdBookings.DisplayLayout.Override.WrapHeaderText = Infragistics.Win.DefaultableBoolean.[True]
        Me.ugdBookings.DisplayLayout.RowConnectorStyle = Infragistics.Win.UltraWinGrid.RowConnectorStyle.None
        Me.ugdBookings.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill
        Me.ugdBookings.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate
        Me.ugdBookings.DisplayLayout.ViewStyle = Infragistics.Win.UltraWinGrid.ViewStyle.SingleBand
        Me.ugdBookings.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ugdBookings.Location = New System.Drawing.Point(13, 278)
        Me.ugdBookings.Name = "ugdBookings"
        Me.ugdBookings.Size = New System.Drawing.Size(1021, 376)
        Me.ugdBookings.StyleSetName = "EZGrid"
        Me.ugdBookings.TabIndex = 562
        '
        'UltraCalendarLook1
        '
        Me.UltraCalendarLook1.ViewStyle = Infragistics.Win.UltraWinSchedule.ViewStyle.Office2003
        '
        'cmdClose
        '
        Me.cmdClose.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Appearance1.BackColor = System.Drawing.Color.Transparent
        Appearance1.BackColor2 = System.Drawing.Color.Transparent
        Appearance1.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance1.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance1.BorderColor = System.Drawing.Color.Transparent
        Appearance1.ForeColor = System.Drawing.Color.White
        Appearance1.Image = CType(resources.GetObject("Appearance1.Image"), Object)
        Appearance1.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance1.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance1.TextVAlignAsString = "Bottom"
        Me.cmdClose.Appearance = Appearance1
        Me.cmdClose.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance2.BackColor = System.Drawing.Color.DarkOrange
        Appearance2.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance2.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance2.ForeColor = System.Drawing.Color.Black
        Me.cmdClose.HotTrackAppearance = Appearance2
        Me.cmdClose.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdClose.Location = New System.Drawing.Point(526, 6)
        Me.cmdClose.Name = "cmdClose"
        Appearance3.BackColor = System.Drawing.Color.OrangeRed
        Appearance3.BackColor2 = System.Drawing.Color.Tomato
        Appearance3.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdClose.PressedAppearance = Appearance3
        Me.cmdClose.ShowFocusRect = False
        Me.cmdClose.ShowOutline = False
        Me.cmdClose.Size = New System.Drawing.Size(46, 39)
        Me.cmdClose.StyleSetName = "StatusBar"
        Me.cmdClose.TabIndex = 563
        Me.cmdClose.Tag = "Return"
        Me.cmdClose.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdClose.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdClose.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdOnlineBookings
        '
        Me.cmdOnlineBookings.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance85.BackColor = System.Drawing.Color.Transparent
        Appearance85.BackColor2 = System.Drawing.Color.Transparent
        Appearance85.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance85.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance85.BorderColor = System.Drawing.Color.Transparent
        Appearance85.ForeColor = System.Drawing.Color.White
        Appearance85.Image = CType(resources.GetObject("Appearance85.Image"), Object)
        Appearance85.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance85.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance85.TextVAlignAsString = "Bottom"
        Me.cmdOnlineBookings.Appearance = Appearance85
        Me.cmdOnlineBookings.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance86.BackColor = System.Drawing.Color.DarkOrange
        Appearance86.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance86.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance86.ForeColor = System.Drawing.Color.Black
        Me.cmdOnlineBookings.HotTrackAppearance = Appearance86
        Me.cmdOnlineBookings.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdOnlineBookings.Location = New System.Drawing.Point(1040, 500)
        Me.cmdOnlineBookings.Name = "cmdOnlineBookings"
        Appearance87.BackColor = System.Drawing.Color.OrangeRed
        Appearance87.BackColor2 = System.Drawing.Color.Tomato
        Appearance87.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdOnlineBookings.PressedAppearance = Appearance87
        Me.cmdOnlineBookings.ShowFocusRect = False
        Me.cmdOnlineBookings.ShowOutline = False
        Me.cmdOnlineBookings.Size = New System.Drawing.Size(46, 45)
        Me.cmdOnlineBookings.StyleSetName = "StatusBar"
        Me.cmdOnlineBookings.TabIndex = 563
        Me.cmdOnlineBookings.Tag = "x"
        Me.cmdOnlineBookings.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOnlineBookings.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOnlineBookings.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdOnlineBookingAccept
        '
        Me.cmdOnlineBookingAccept.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance88.BackColor = System.Drawing.Color.Transparent
        Appearance88.BackColor2 = System.Drawing.Color.Transparent
        Appearance88.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance88.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance88.BorderColor = System.Drawing.Color.Transparent
        Appearance88.ForeColor = System.Drawing.Color.White
        Appearance88.Image = CType(resources.GetObject("Appearance88.Image"), Object)
        Appearance88.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance88.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance88.TextVAlignAsString = "Bottom"
        Me.cmdOnlineBookingAccept.Appearance = Appearance88
        Me.cmdOnlineBookingAccept.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance89.BackColor = System.Drawing.Color.DarkOrange
        Appearance89.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance89.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance89.ForeColor = System.Drawing.Color.Black
        Me.cmdOnlineBookingAccept.HotTrackAppearance = Appearance89
        Me.cmdOnlineBookingAccept.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdOnlineBookingAccept.Location = New System.Drawing.Point(1040, 584)
        Me.cmdOnlineBookingAccept.Name = "cmdOnlineBookingAccept"
        Appearance90.BackColor = System.Drawing.Color.OrangeRed
        Appearance90.BackColor2 = System.Drawing.Color.Tomato
        Appearance90.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdOnlineBookingAccept.PressedAppearance = Appearance90
        Me.cmdOnlineBookingAccept.ShowFocusRect = False
        Me.cmdOnlineBookingAccept.ShowOutline = False
        Me.cmdOnlineBookingAccept.Size = New System.Drawing.Size(46, 45)
        Me.cmdOnlineBookingAccept.StyleSetName = "StatusBar"
        Me.cmdOnlineBookingAccept.TabIndex = 564
        Me.cmdOnlineBookingAccept.Tag = "OK"
        Me.cmdOnlineBookingAccept.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOnlineBookingAccept.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOnlineBookingAccept.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdOnlineBookingAccept.Visible = False
        '
        'cmdOnlineBookingReject
        '
        Me.cmdOnlineBookingReject.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance91.BackColor = System.Drawing.Color.Transparent
        Appearance91.BackColor2 = System.Drawing.Color.Transparent
        Appearance91.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance91.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance91.BorderColor = System.Drawing.Color.Transparent
        Appearance91.ForeColor = System.Drawing.Color.White
        Appearance91.Image = CType(resources.GetObject("Appearance91.Image"), Object)
        Appearance91.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance91.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance91.TextVAlignAsString = "Bottom"
        Me.cmdOnlineBookingReject.Appearance = Appearance91
        Me.cmdOnlineBookingReject.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance92.BackColor = System.Drawing.Color.DarkOrange
        Appearance92.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance92.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance92.ForeColor = System.Drawing.Color.Black
        Me.cmdOnlineBookingReject.HotTrackAppearance = Appearance92
        Me.cmdOnlineBookingReject.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdOnlineBookingReject.Location = New System.Drawing.Point(1040, 618)
        Me.cmdOnlineBookingReject.Name = "cmdOnlineBookingReject"
        Appearance93.BackColor = System.Drawing.Color.OrangeRed
        Appearance93.BackColor2 = System.Drawing.Color.Tomato
        Appearance93.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdOnlineBookingReject.PressedAppearance = Appearance93
        Me.cmdOnlineBookingReject.ShowFocusRect = False
        Me.cmdOnlineBookingReject.ShowOutline = False
        Me.cmdOnlineBookingReject.Size = New System.Drawing.Size(46, 45)
        Me.cmdOnlineBookingReject.StyleSetName = "StatusBar"
        Me.cmdOnlineBookingReject.TabIndex = 565
        Me.cmdOnlineBookingReject.Tag = "OK"
        Me.cmdOnlineBookingReject.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOnlineBookingReject.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOnlineBookingReject.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdOnlineBookingReject.Visible = False
        '
        'frmBookings
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(253, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(253, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1098, 719)
        Me.Controls.Add(Me.cmdOnlineBookingReject)
        Me.Controls.Add(Me.cmdOnlineBookingAccept)
        Me.Controls.Add(Me.cmdOnlineBookings)
        Me.Controls.Add(Me.ugdBookings)
        Me.Controls.Add(Me.upnlCustomerInfo)
        Me.Controls.Add(Me.cmdStatus)
        Me.Controls.Add(Me.cmdViewSameDate)
        Me.Controls.Add(Me.cmdViewAll)
        Me.Controls.Add(Me.cmdOK)
        Me.Controls.Add(Me.cmdClearAll)
        Me.Controls.Add(Me.cmdEditBooking)
        Me.Controls.Add(Me.cmdDeleteBooking)
        Me.Controls.Add(Me.cmdGridDown)
        Me.Controls.Add(Me.cmdGridUp)
        Me.Controls.Add(Me.cmdUpdate)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmBookings"
        Me.Controls.SetChildIndex(Me.cmdUpdate, 0)
        Me.Controls.SetChildIndex(Me.cmdGridUp, 0)
        Me.Controls.SetChildIndex(Me.cmdGridDown, 0)
        Me.Controls.SetChildIndex(Me.cmdDeleteBooking, 0)
        Me.Controls.SetChildIndex(Me.cmdEditBooking, 0)
        Me.Controls.SetChildIndex(Me.cmdClearAll, 0)
        Me.Controls.SetChildIndex(Me.cmdOK, 0)
        Me.Controls.SetChildIndex(Me.cmdViewAll, 0)
        Me.Controls.SetChildIndex(Me.cmdViewSameDate, 0)
        Me.Controls.SetChildIndex(Me.cmdStatus, 0)
        Me.Controls.SetChildIndex(Me.upnlCustomerInfo, 0)
        Me.Controls.SetChildIndex(Me.ugdBookings, 0)
        Me.Controls.SetChildIndex(Me.uplBasePanel, 0)
        Me.Controls.SetChildIndex(Me.cmdOnlineBookings, 0)
        Me.Controls.SetChildIndex(Me.cmdOnlineBookingAccept, 0)
        Me.Controls.SetChildIndex(Me.cmdOnlineBookingReject, 0)
        Me.uplBasePanel.ClientArea.ResumeLayout(False)
        Me.uplBasePanel.ResumeLayout(False)
        Me.upnlCustomerInfo.ClientArea.ResumeLayout(False)
        Me.upnlCustomerInfo.ClientArea.PerformLayout()
        Me.upnlCustomerInfo.ResumeLayout(False)
        CType(Me.txtBookingNote, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtCovers, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTable, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtBookingDate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTime, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtName, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTelephone, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ugdBookings, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents cmdStatus As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdViewSameDate As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdViewAll As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdOK As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdClearAll As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdEditBooking As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDeleteBooking As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdGridDown As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdGridUp As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdUpdate As Infragistics.Win.Misc.UltraButton
    Friend WithEvents upnlCustomerInfo As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents txtBookingDate As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtTime As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtName As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtTelephone As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents ugdBookings As Infragistics.Win.UltraWinGrid.UltraGrid
    Friend WithEvents txtBookingNote As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtCovers As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtTable As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents UltraLabel5 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel6 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel7 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel4 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel3 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel2 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel1 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraCalendarLook1 As Infragistics.Win.UltraWinSchedule.UltraCalendarLook
    Friend WithEvents BookingsBindingSource As BindingSource
    Friend WithEvents cmdClose As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdClearButton As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdViewCalendar As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdKBTelephone As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdKBTime As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdKBName As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdKBTable As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdKBBookingNote As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdKBCovers As Infragistics.Win.Misc.UltraButton
    Friend WithEvents lblBookings As Label
    Friend WithEvents cmdOnlineBookings As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdOnlineBookingAccept As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdOnlineBookingReject As Infragistics.Win.Misc.UltraButton
End Class
