﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmOrderEntry
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim Appearance1 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance2 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance3 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance4 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmOrderEntry))
        Dim Appearance5 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance6 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance7 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance8 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance9 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance10 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance11 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance12 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance13 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance14 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance15 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance16 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance17 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance18 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance19 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance20 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance21 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance22 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance23 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance24 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance25 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance26 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance27 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance28 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance29 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance30 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance31 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance32 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance33 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance34 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance35 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance36 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance37 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance38 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance39 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance40 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance41 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance42 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance43 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance44 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance45 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance46 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance47 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance48 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance49 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance50 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance51 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance52 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance53 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance54 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance55 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance56 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance57 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance58 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance59 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance60 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance61 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance62 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance63 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance64 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance65 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance66 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance67 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance68 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance69 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance70 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance71 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance72 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance73 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance74 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance75 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance76 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance77 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance78 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance79 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance80 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance81 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance82 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance83 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance84 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance85 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance86 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraGridBand1 As Infragistics.Win.UltraWinGrid.UltraGridBand = New Infragistics.Win.UltraWinGrid.UltraGridBand("Band 0", -1)
        Dim UltraGridColumn1 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("DCode", 0)
        Dim UltraGridColumn2 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("DName", 1)
        Dim UltraGridColumn3 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("DPrice", 2)
        Dim Appearance87 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraGridColumn4 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("DQty", 3)
        Dim Appearance88 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraGridColumn5 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Total", 4)
        Dim Appearance89 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraGridColumn6 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Mods", 5)
        Dim UltraGridColumn7 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Discountable", 6)
        Dim UltraGridColumn8 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("OriPrice", 7)
        Dim UltraGridColumn9 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("PriceIn", 8)
        Dim UltraGridColumn10 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("PriceOut", 9)
        Dim UltraGridColumn11 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("GroupIndex", 10)
        Dim UltraGridColumn13 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("HiLite", 11)
        Dim UltraGridColumn14 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("ShortName", 12)
        Dim UltraGridColumn12 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("IsStarter", 13)
        Dim Appearance90 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance91 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance92 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance93 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance94 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance95 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance96 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance97 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance98 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraDataColumn1 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("DCode")
        Dim UltraDataColumn2 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("DName")
        Dim UltraDataColumn3 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("DPrice")
        Dim UltraDataColumn4 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("DQty")
        Dim UltraDataColumn5 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("Total")
        Dim UltraDataColumn6 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("Mods")
        Dim UltraDataColumn7 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("Discountable")
        Dim UltraDataColumn8 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("IsStarter")
        Dim UltraDataColumn9 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("OriPrice")
        Dim UltraDataColumn10 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("PriceIn")
        Dim UltraDataColumn11 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("PriceOut")
        Dim UltraDataColumn12 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("GroupIndex")
        Dim UltraDataColumn13 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("HiLite")
        Dim Appearance99 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance100 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance101 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance102 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance103 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance104 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance105 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance106 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance107 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance108 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance109 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance110 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance111 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance112 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance113 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance114 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Me.pnlHeader = New Infragistics.Win.Misc.UltraPanel()
        Me.lblHeader = New Infragistics.Win.Misc.UltraLabel()
        Me.lblStatusBarDiv = New Infragistics.Win.Misc.UltraLabel()
        Me.cmdPrintLabels = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDishesBack = New Infragistics.Win.Misc.UltraButton()
        Me.cmdShowKeyboard = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDishesNext = New Infragistics.Win.Misc.UltraButton()
        Me.cmdOEDiscounts = New Infragistics.Win.Misc.UltraButton()
        Me.cmdOEHome = New Infragistics.Win.Misc.UltraButton()
        Me.cmdOEBack = New Infragistics.Win.Misc.UltraButton()
        Me.cmdPrevOrder = New Infragistics.Win.Misc.UltraButton()
        Me.cmdOENext = New Infragistics.Win.Misc.UltraButton()
        Me.cmdSetMeals = New Infragistics.Win.Misc.UltraButton()
        Me.cmdAddDrink = New Infragistics.Win.Misc.UltraButton()
        Me.cmdManualEntry = New Infragistics.Win.Misc.UltraButton()
        Me.cmdLastItemQty = New Infragistics.Win.Misc.UltraButton()
        Me.cmdEditDish = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDishClearAll = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDeleteDish = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDecDish = New Infragistics.Win.Misc.UltraButton()
        Me.cmdIncDish = New Infragistics.Win.Misc.UltraButton()
        Me.cmdOGDown = New Infragistics.Win.Misc.UltraButton()
        Me.cmdOGUp = New Infragistics.Win.Misc.UltraButton()
        Me.upnlChoices = New Infragistics.Win.Misc.UltraPanel()
        Me.cmdChoice7 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdChoice6 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdChoice5 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdChoice4 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdChoice3 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdChoice2 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdChoice1 = New Infragistics.Win.Misc.UltraButton()
        Me.EZMenuDataSet = New EZMenu.EZMenuDataSet()
        Me.txtKBCode = New System.Windows.Forms.TextBox()
        Me.ugdOrderGrid = New Infragistics.Win.UltraWinGrid.UltraGrid()
        Me.udsOrder = New Infragistics.Win.UltraWinDataSource.UltraDataSource(Me.components)
        Me.GroupsBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.GroupsTableAdapter = New EZMenu.EZMenuDataSetTableAdapters.GroupsTableAdapter()
        Me.TableAdapterManager = New EZMenu.EZMenuDataSetTableAdapters.TableAdapterManager()
        Me.DishBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DishTableAdapter = New EZMenu.EZMenuDataSetTableAdapters.DishTableAdapter()
        Me.pnlDishesMain = New Infragistics.Win.Misc.UltraPanel()
        Me.pnlDishes = New Infragistics.Win.Misc.UltraPanel()
        Me.cmdGroupDown = New Infragistics.Win.Misc.UltraButton()
        Me.cmdGroupUp = New Infragistics.Win.Misc.UltraButton()
        Me.pnlGroupMain = New Infragistics.Win.Misc.UltraPanel()
        Me.pnlGroup = New Infragistics.Win.Misc.UltraPanel()
        Me.ufmGroups = New Infragistics.Win.Misc.UltraFlowLayoutManager(Me.components)
        Me.ufmDishes = New Infragistics.Win.Misc.UltraFlowLayoutManager(Me.components)
        Me.cmdTypical = New Infragistics.Win.Misc.UltraButton()
        Me.cmdCuisine = New Infragistics.Win.Misc.UltraButton()
        Me.lblNumItems = New Infragistics.Win.Misc.UltraLabel()
        Me.lblToPayLbl = New Infragistics.Win.Misc.UltraLabel()
        Me.lblToPay = New Infragistics.Win.Misc.UltraLabel()
        Me.ufmTotals = New Infragistics.Win.Misc.UltraFlowLayoutManager(Me.components)
        Me.upnlSummary = New Infragistics.Win.Misc.UltraPanel()
        Me.uplSSubtotal = New Infragistics.Win.Misc.UltraPanel()
        Me.lblSubtotal = New Infragistics.Win.Misc.UltraLabel()
        Me.lblSubTotalLbl = New Infragistics.Win.Misc.UltraLabel()
        Me.uplSDrinks = New Infragistics.Win.Misc.UltraPanel()
        Me.lblDrinksOELbl = New Infragistics.Win.Misc.UltraLabel()
        Me.lblDrinksOE = New Infragistics.Win.Misc.UltraLabel()
        Me.uplSGDiscounts = New Infragistics.Win.Misc.UltraPanel()
        Me.lblGDiscounts = New Infragistics.Win.Misc.UltraLabel()
        Me.lblGDiscountsLbl = New Infragistics.Win.Misc.UltraLabel()
        Me.uplSGCharges = New Infragistics.Win.Misc.UltraPanel()
        Me.lblGCharges = New Infragistics.Win.Misc.UltraLabel()
        Me.lblGChargesLbl = New Infragistics.Win.Misc.UltraLabel()
        Me.uplSDiscounts = New Infragistics.Win.Misc.UltraPanel()
        Me.lblPriceAdjDiscounts = New Infragistics.Win.Misc.UltraLabel()
        Me.lblPriceAdjDiscountsLbl = New Infragistics.Win.Misc.UltraLabel()
        Me.uplSCharges = New Infragistics.Win.Misc.UltraPanel()
        Me.lblPriceAdjCharges = New Infragistics.Win.Misc.UltraLabel()
        Me.lblPriceAdjChargesLbl = New Infragistics.Win.Misc.UltraLabel()
        Me.pnlHeader.ClientArea.SuspendLayout()
        Me.pnlHeader.SuspendLayout()
        Me.upnlChoices.ClientArea.SuspendLayout()
        Me.upnlChoices.SuspendLayout()
        CType(Me.EZMenuDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ugdOrderGrid, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.udsOrder, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GroupsBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DishBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlDishesMain.ClientArea.SuspendLayout()
        Me.pnlDishesMain.SuspendLayout()
        Me.pnlDishes.SuspendLayout()
        Me.pnlGroupMain.ClientArea.SuspendLayout()
        Me.pnlGroupMain.SuspendLayout()
        Me.pnlGroup.SuspendLayout()
        CType(Me.ufmGroups, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ufmDishes, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ufmTotals, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.upnlSummary.ClientArea.SuspendLayout()
        Me.upnlSummary.SuspendLayout()
        Me.uplSSubtotal.ClientArea.SuspendLayout()
        Me.uplSSubtotal.SuspendLayout()
        Me.uplSDrinks.ClientArea.SuspendLayout()
        Me.uplSDrinks.SuspendLayout()
        Me.uplSGDiscounts.ClientArea.SuspendLayout()
        Me.uplSGDiscounts.SuspendLayout()
        Me.uplSGCharges.ClientArea.SuspendLayout()
        Me.uplSGCharges.SuspendLayout()
        Me.uplSDiscounts.ClientArea.SuspendLayout()
        Me.uplSDiscounts.SuspendLayout()
        Me.uplSCharges.ClientArea.SuspendLayout()
        Me.uplSCharges.SuspendLayout()
        Me.SuspendLayout()
        '
        'pnlHeader
        '
        Me.pnlHeader.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance1.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.pnlHeader.Appearance = Appearance1
        '
        'pnlHeader.ClientArea
        '
        Me.pnlHeader.ClientArea.Controls.Add(Me.lblHeader)
        Me.pnlHeader.Location = New System.Drawing.Point(0, 0)
        Me.pnlHeader.Name = "pnlHeader"
        Me.pnlHeader.Size = New System.Drawing.Size(1171, 42)
        Me.pnlHeader.StyleSetName = "Reservation"
        Me.pnlHeader.TabIndex = 548
        Me.pnlHeader.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblHeader
        '
        Appearance2.BackColor = System.Drawing.Color.Transparent
        Appearance2.ForeColor = System.Drawing.Color.Maroon
        Appearance2.TextVAlignAsString = "Middle"
        Me.lblHeader.Appearance = Appearance2
        Me.lblHeader.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHeader.Location = New System.Drawing.Point(3, 4)
        Me.lblHeader.Name = "lblHeader"
        Me.lblHeader.Size = New System.Drawing.Size(240, 35)
        Me.lblHeader.StyleSetName = "Reservation"
        Me.lblHeader.TabIndex = 460
        Me.lblHeader.Text = "ezMENU"
        Me.lblHeader.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblStatusBarDiv
        '
        Me.lblStatusBarDiv.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance3.BorderColor = System.Drawing.Color.Silver
        Me.lblStatusBarDiv.Appearance = Appearance3
        Me.lblStatusBarDiv.BorderStyleInner = Infragistics.Win.UIElementBorderStyle.Solid
        Me.lblStatusBarDiv.Location = New System.Drawing.Point(-1, 627)
        Me.lblStatusBarDiv.Name = "lblStatusBarDiv"
        Me.lblStatusBarDiv.Size = New System.Drawing.Size(1171, 1)
        Me.lblStatusBarDiv.TabIndex = 549
        '
        'cmdPrintLabels
        '
        Me.cmdPrintLabels.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Appearance4.BackColor = System.Drawing.Color.Transparent
        Appearance4.BackColor2 = System.Drawing.Color.Transparent
        Appearance4.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance4.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance4.BorderColor2 = System.Drawing.Color.Maroon
        Appearance4.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance4.ForeColor = System.Drawing.Color.White
        Appearance4.Image = CType(resources.GetObject("Appearance4.Image"), Object)
        Appearance4.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance4.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance4.TextVAlignAsString = "Bottom"
        Me.cmdPrintLabels.Appearance = Appearance4
        Me.cmdPrintLabels.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdPrintLabels.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance5.BackColor = System.Drawing.Color.DarkOrange
        Appearance5.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance5.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance5.BorderColor = System.Drawing.Color.Transparent
        Appearance5.ForeColor = System.Drawing.Color.Black
        Me.cmdPrintLabels.HotTrackAppearance = Appearance5
        Me.cmdPrintLabels.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdPrintLabels.Location = New System.Drawing.Point(622, 635)
        Me.cmdPrintLabels.Name = "cmdPrintLabels"
        Me.cmdPrintLabels.Padding = New System.Drawing.Size(15, 0)
        Appearance6.BackColor = System.Drawing.Color.OrangeRed
        Appearance6.BackColor2 = System.Drawing.Color.Tomato
        Appearance6.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance6.BorderColor = System.Drawing.Color.Transparent
        Me.cmdPrintLabels.PressedAppearance = Appearance6
        Me.cmdPrintLabels.ShowFocusRect = False
        Me.cmdPrintLabels.ShowOutline = False
        Me.cmdPrintLabels.Size = New System.Drawing.Size(64, 44)
        Me.cmdPrintLabels.StyleSetName = "StatusBar"
        Me.cmdPrintLabels.TabIndex = 584
        Me.cmdPrintLabels.Tag = "Print labels"
        Me.cmdPrintLabels.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPrintLabels.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPrintLabels.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDishesBack
        '
        Me.cmdDishesBack.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Appearance7.BackColor = System.Drawing.Color.Transparent
        Appearance7.BackColor2 = System.Drawing.Color.Transparent
        Appearance7.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance7.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance7.BorderColor2 = System.Drawing.Color.Maroon
        Appearance7.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance7.ForeColor = System.Drawing.Color.White
        Appearance7.Image = CType(resources.GetObject("Appearance7.Image"), Object)
        Appearance7.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance7.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance7.TextVAlignAsString = "Bottom"
        Me.cmdDishesBack.Appearance = Appearance7
        Me.cmdDishesBack.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdDishesBack.Enabled = False
        Me.cmdDishesBack.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance8.BackColor = System.Drawing.Color.DarkOrange
        Appearance8.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance8.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance8.BorderColor = System.Drawing.Color.Transparent
        Appearance8.ForeColor = System.Drawing.Color.Black
        Me.cmdDishesBack.HotTrackAppearance = Appearance8
        Me.cmdDishesBack.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdDishesBack.Location = New System.Drawing.Point(342, 635)
        Me.cmdDishesBack.Name = "cmdDishesBack"
        Me.cmdDishesBack.Padding = New System.Drawing.Size(15, 0)
        Appearance9.BackColor = System.Drawing.Color.OrangeRed
        Appearance9.BackColor2 = System.Drawing.Color.Tomato
        Appearance9.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance9.BorderColor = System.Drawing.Color.Transparent
        Me.cmdDishesBack.PressedAppearance = Appearance9
        Me.cmdDishesBack.ShowFocusRect = False
        Me.cmdDishesBack.ShowOutline = False
        Me.cmdDishesBack.Size = New System.Drawing.Size(64, 44)
        Me.cmdDishesBack.StyleSetName = "StatusBar"
        Me.cmdDishesBack.TabIndex = 577
        Me.cmdDishesBack.Tag = "Prev dishes"
        Me.cmdDishesBack.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDishesBack.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDishesBack.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdShowKeyboard
        '
        Me.cmdShowKeyboard.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Appearance10.BackColor = System.Drawing.Color.Transparent
        Appearance10.BackColor2 = System.Drawing.Color.Transparent
        Appearance10.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance10.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance10.BorderColor2 = System.Drawing.Color.Maroon
        Appearance10.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance10.ForeColor = System.Drawing.Color.White
        Appearance10.Image = CType(resources.GetObject("Appearance10.Image"), Object)
        Appearance10.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance10.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance10.TextVAlignAsString = "Bottom"
        Me.cmdShowKeyboard.Appearance = Appearance10
        Me.cmdShowKeyboard.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdShowKeyboard.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance11.BackColor = System.Drawing.Color.DarkOrange
        Appearance11.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance11.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance11.BorderColor = System.Drawing.Color.Transparent
        Appearance11.ForeColor = System.Drawing.Color.Black
        Me.cmdShowKeyboard.HotTrackAppearance = Appearance11
        Me.cmdShowKeyboard.ImageSize = New System.Drawing.Size(38, 38)
        Me.cmdShowKeyboard.Location = New System.Drawing.Point(482, 635)
        Me.cmdShowKeyboard.Name = "cmdShowKeyboard"
        Me.cmdShowKeyboard.Padding = New System.Drawing.Size(15, 0)
        Appearance12.BackColor = System.Drawing.Color.OrangeRed
        Appearance12.BackColor2 = System.Drawing.Color.Tomato
        Appearance12.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance12.BorderColor = System.Drawing.Color.Transparent
        Me.cmdShowKeyboard.PressedAppearance = Appearance12
        Me.cmdShowKeyboard.ShowFocusRect = False
        Me.cmdShowKeyboard.ShowOutline = False
        Me.cmdShowKeyboard.Size = New System.Drawing.Size(64, 44)
        Me.cmdShowKeyboard.StyleSetName = "StatusBar"
        Me.cmdShowKeyboard.TabIndex = 582
        Me.cmdShowKeyboard.Tag = "Keyboard"
        Me.cmdShowKeyboard.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdShowKeyboard.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdShowKeyboard.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDishesNext
        '
        Me.cmdDishesNext.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Appearance13.BackColor = System.Drawing.Color.Transparent
        Appearance13.BackColor2 = System.Drawing.Color.Transparent
        Appearance13.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance13.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance13.BorderColor2 = System.Drawing.Color.Maroon
        Appearance13.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance13.ForeColor = System.Drawing.Color.White
        Appearance13.Image = CType(resources.GetObject("Appearance13.Image"), Object)
        Appearance13.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance13.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance13.TextVAlignAsString = "Bottom"
        Me.cmdDishesNext.Appearance = Appearance13
        Me.cmdDishesNext.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdDishesNext.Enabled = False
        Me.cmdDishesNext.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance14.BackColor = System.Drawing.Color.DarkOrange
        Appearance14.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance14.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance14.BorderColor = System.Drawing.Color.Transparent
        Appearance14.ForeColor = System.Drawing.Color.Black
        Me.cmdDishesNext.HotTrackAppearance = Appearance14
        Me.cmdDishesNext.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdDishesNext.Location = New System.Drawing.Point(412, 635)
        Me.cmdDishesNext.Name = "cmdDishesNext"
        Me.cmdDishesNext.Padding = New System.Drawing.Size(15, 0)
        Appearance15.BackColor = System.Drawing.Color.OrangeRed
        Appearance15.BackColor2 = System.Drawing.Color.Tomato
        Appearance15.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance15.BorderColor = System.Drawing.Color.Transparent
        Me.cmdDishesNext.PressedAppearance = Appearance15
        Me.cmdDishesNext.ShowFocusRect = False
        Me.cmdDishesNext.ShowOutline = False
        Me.cmdDishesNext.Size = New System.Drawing.Size(64, 44)
        Me.cmdDishesNext.StyleSetName = "StatusBar"
        Me.cmdDishesNext.TabIndex = 578
        Me.cmdDishesNext.Tag = "Next dishes"
        Me.cmdDishesNext.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDishesNext.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDishesNext.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdOEDiscounts
        '
        Me.cmdOEDiscounts.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Appearance16.BackColor = System.Drawing.Color.Transparent
        Appearance16.BackColor2 = System.Drawing.Color.Transparent
        Appearance16.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance16.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance16.BorderColor2 = System.Drawing.Color.Maroon
        Appearance16.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance16.ForeColor = System.Drawing.Color.White
        Appearance16.Image = CType(resources.GetObject("Appearance16.Image"), Object)
        Appearance16.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance16.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance16.TextVAlignAsString = "Bottom"
        Me.cmdOEDiscounts.Appearance = Appearance16
        Me.cmdOEDiscounts.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdOEDiscounts.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance17.BackColor = System.Drawing.Color.DarkOrange
        Appearance17.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance17.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance17.BorderColor = System.Drawing.Color.Transparent
        Appearance17.ForeColor = System.Drawing.Color.Black
        Me.cmdOEDiscounts.HotTrackAppearance = Appearance17
        Me.cmdOEDiscounts.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdOEDiscounts.Location = New System.Drawing.Point(552, 635)
        Me.cmdOEDiscounts.Name = "cmdOEDiscounts"
        Me.cmdOEDiscounts.Padding = New System.Drawing.Size(15, 0)
        Appearance18.BackColor = System.Drawing.Color.OrangeRed
        Appearance18.BackColor2 = System.Drawing.Color.Tomato
        Appearance18.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance18.BorderColor = System.Drawing.Color.Transparent
        Me.cmdOEDiscounts.PressedAppearance = Appearance18
        Me.cmdOEDiscounts.ShowFocusRect = False
        Me.cmdOEDiscounts.ShowOutline = False
        Me.cmdOEDiscounts.Size = New System.Drawing.Size(64, 44)
        Me.cmdOEDiscounts.StyleSetName = "StatusBar"
        Me.cmdOEDiscounts.TabIndex = 579
        Me.cmdOEDiscounts.Tag = "D && C"
        Me.cmdOEDiscounts.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOEDiscounts.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOEDiscounts.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdOEHome
        '
        Me.cmdOEHome.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Appearance19.BackColor = System.Drawing.Color.Transparent
        Appearance19.BackColor2 = System.Drawing.Color.Transparent
        Appearance19.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance19.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance19.BorderColor2 = System.Drawing.Color.Maroon
        Appearance19.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance19.ForeColor = System.Drawing.Color.White
        Appearance19.Image = CType(resources.GetObject("Appearance19.Image"), Object)
        Appearance19.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance19.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance19.TextVAlignAsString = "Bottom"
        Me.cmdOEHome.Appearance = Appearance19
        Me.cmdOEHome.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdOEHome.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance20.BackColor = System.Drawing.Color.DarkOrange
        Appearance20.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance20.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance20.BorderColor = System.Drawing.Color.Transparent
        Appearance20.ForeColor = System.Drawing.Color.Black
        Me.cmdOEHome.HotTrackAppearance = Appearance20
        Me.cmdOEHome.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdOEHome.Location = New System.Drawing.Point(762, 635)
        Me.cmdOEHome.Name = "cmdOEHome"
        Me.cmdOEHome.Padding = New System.Drawing.Size(15, 0)
        Appearance21.BackColor = System.Drawing.Color.OrangeRed
        Appearance21.BackColor2 = System.Drawing.Color.Tomato
        Appearance21.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance21.BorderColor = System.Drawing.Color.Transparent
        Me.cmdOEHome.PressedAppearance = Appearance21
        Me.cmdOEHome.ShowFocusRect = False
        Me.cmdOEHome.ShowOutline = False
        Me.cmdOEHome.Size = New System.Drawing.Size(64, 44)
        Me.cmdOEHome.StyleSetName = "StatusBar"
        Me.cmdOEHome.TabIndex = 580
        Me.cmdOEHome.Tag = "Return"
        Me.cmdOEHome.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOEHome.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOEHome.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdOEBack
        '
        Me.cmdOEBack.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Appearance22.BackColor = System.Drawing.Color.Transparent
        Appearance22.BackColor2 = System.Drawing.Color.Transparent
        Appearance22.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance22.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance22.BorderColor2 = System.Drawing.Color.Maroon
        Appearance22.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance22.ForeColor = System.Drawing.Color.Black
        Appearance22.Image = CType(resources.GetObject("Appearance22.Image"), Object)
        Appearance22.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance22.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance22.TextVAlignAsString = "Bottom"
        Me.cmdOEBack.Appearance = Appearance22
        Me.cmdOEBack.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdOEBack.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance23.BackColor = System.Drawing.Color.DarkOrange
        Appearance23.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance23.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance23.BorderColor = System.Drawing.Color.Transparent
        Appearance23.ForeColor = System.Drawing.Color.Black
        Me.cmdOEBack.HotTrackAppearance = Appearance23
        Me.cmdOEBack.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdOEBack.Location = New System.Drawing.Point(12, 635)
        Me.cmdOEBack.Name = "cmdOEBack"
        Me.cmdOEBack.Padding = New System.Drawing.Size(15, 0)
        Appearance24.BackColor = System.Drawing.Color.OrangeRed
        Appearance24.BackColor2 = System.Drawing.Color.Tomato
        Appearance24.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance24.BorderColor = System.Drawing.Color.Transparent
        Me.cmdOEBack.PressedAppearance = Appearance24
        Me.cmdOEBack.ShowFocusRect = False
        Me.cmdOEBack.ShowOutline = False
        Me.cmdOEBack.Size = New System.Drawing.Size(64, 44)
        Me.cmdOEBack.StyleSetName = "StatusBar"
        Me.cmdOEBack.TabIndex = 581
        Me.cmdOEBack.Tag = "Back"
        Me.cmdOEBack.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOEBack.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOEBack.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdPrevOrder
        '
        Me.cmdPrevOrder.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Appearance25.BackColor = System.Drawing.Color.Transparent
        Appearance25.BackColor2 = System.Drawing.Color.Transparent
        Appearance25.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance25.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance25.BorderColor2 = System.Drawing.Color.Maroon
        Appearance25.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance25.ForeColor = System.Drawing.Color.White
        Appearance25.Image = CType(resources.GetObject("Appearance25.Image"), Object)
        Appearance25.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance25.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance25.TextVAlignAsString = "Bottom"
        Me.cmdPrevOrder.Appearance = Appearance25
        Me.cmdPrevOrder.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdPrevOrder.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance26.BackColor = System.Drawing.Color.DarkOrange
        Appearance26.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance26.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance26.BorderColor = System.Drawing.Color.Transparent
        Appearance26.ForeColor = System.Drawing.Color.Black
        Me.cmdPrevOrder.HotTrackAppearance = Appearance26
        Me.cmdPrevOrder.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdPrevOrder.Location = New System.Drawing.Point(692, 635)
        Me.cmdPrevOrder.Name = "cmdPrevOrder"
        Me.cmdPrevOrder.Padding = New System.Drawing.Size(15, 0)
        Appearance27.BackColor = System.Drawing.Color.OrangeRed
        Appearance27.BackColor2 = System.Drawing.Color.Tomato
        Appearance27.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance27.BorderColor = System.Drawing.Color.Transparent
        Me.cmdPrevOrder.PressedAppearance = Appearance27
        Me.cmdPrevOrder.ShowFocusRect = False
        Me.cmdPrevOrder.ShowOutline = False
        Me.cmdPrevOrder.Size = New System.Drawing.Size(64, 44)
        Me.cmdPrevOrder.StyleSetName = "StatusBar"
        Me.cmdPrevOrder.TabIndex = 586
        Me.cmdPrevOrder.Tag = "Past order"
        Me.cmdPrevOrder.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPrevOrder.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPrevOrder.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdOENext
        '
        Me.cmdOENext.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance28.BackColor = System.Drawing.Color.Transparent
        Appearance28.BackColor2 = System.Drawing.Color.Transparent
        Appearance28.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance28.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance28.BorderColor2 = System.Drawing.Color.Maroon
        Appearance28.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance28.ForeColor = System.Drawing.Color.Black
        Appearance28.Image = CType(resources.GetObject("Appearance28.Image"), Object)
        Appearance28.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance28.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance28.TextVAlignAsString = "Bottom"
        Me.cmdOENext.Appearance = Appearance28
        Me.cmdOENext.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdOENext.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance29.BackColor = System.Drawing.Color.DarkOrange
        Appearance29.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance29.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance29.BorderColor = System.Drawing.Color.Transparent
        Appearance29.ForeColor = System.Drawing.Color.Black
        Me.cmdOENext.HotTrackAppearance = Appearance29
        Me.cmdOENext.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdOENext.Location = New System.Drawing.Point(1092, 635)
        Me.cmdOENext.Name = "cmdOENext"
        Me.cmdOENext.Padding = New System.Drawing.Size(15, 0)
        Appearance30.BackColor = System.Drawing.Color.OrangeRed
        Appearance30.BackColor2 = System.Drawing.Color.Tomato
        Appearance30.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance30.BorderColor = System.Drawing.Color.Transparent
        Me.cmdOENext.PressedAppearance = Appearance30
        Me.cmdOENext.ShowFocusRect = False
        Me.cmdOENext.ShowOutline = False
        Me.cmdOENext.Size = New System.Drawing.Size(64, 44)
        Me.cmdOENext.StyleSetName = "StatusBar"
        Me.cmdOENext.TabIndex = 583
        Me.cmdOENext.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOENext.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOENext.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdSetMeals
        '
        Me.cmdSetMeals.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance31.BackColor = System.Drawing.Color.Transparent
        Appearance31.BackColor2 = System.Drawing.Color.Transparent
        Appearance31.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance31.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance31.BorderColor = System.Drawing.Color.Transparent
        Appearance31.ForeColor = System.Drawing.Color.Black
        Appearance31.Image = CType(resources.GetObject("Appearance31.Image"), Object)
        Appearance31.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance31.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance31.TextVAlignAsString = "Bottom"
        Me.cmdSetMeals.Appearance = Appearance31
        Me.cmdSetMeals.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdSetMeals.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance32.BackColor = System.Drawing.Color.DarkOrange
        Appearance32.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance32.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance32.BorderColor = System.Drawing.Color.Transparent
        Appearance32.ForeColor = System.Drawing.Color.Black
        Me.cmdSetMeals.HotTrackAppearance = Appearance32
        Me.cmdSetMeals.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdSetMeals.Location = New System.Drawing.Point(1112, 507)
        Me.cmdSetMeals.Name = "cmdSetMeals"
        Appearance33.BorderColor = System.Drawing.Color.Transparent
        Me.cmdSetMeals.PressedAppearance = Appearance33
        Me.cmdSetMeals.ShowFocusRect = False
        Me.cmdSetMeals.ShowOutline = False
        Me.cmdSetMeals.Size = New System.Drawing.Size(46, 45)
        Me.cmdSetMeals.StyleSetName = "StatusBar"
        Me.cmdSetMeals.TabIndex = 597
        Me.cmdSetMeals.Tag = "x"
        Me.cmdSetMeals.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdSetMeals.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdSetMeals.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdAddDrink
        '
        Me.cmdAddDrink.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance34.BackColor = System.Drawing.Color.Transparent
        Appearance34.BackColor2 = System.Drawing.Color.Transparent
        Appearance34.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance34.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance34.BorderColor = System.Drawing.Color.Transparent
        Appearance34.ForeColor = System.Drawing.Color.Black
        Appearance34.Image = CType(resources.GetObject("Appearance34.Image"), Object)
        Appearance34.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance34.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance34.TextVAlignAsString = "Bottom"
        Me.cmdAddDrink.Appearance = Appearance34
        Me.cmdAddDrink.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdAddDrink.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance35.BackColor = System.Drawing.Color.DarkOrange
        Appearance35.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance35.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance35.BorderColor = System.Drawing.Color.Transparent
        Appearance35.ForeColor = System.Drawing.Color.Black
        Me.cmdAddDrink.HotTrackAppearance = Appearance35
        Me.cmdAddDrink.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdAddDrink.Location = New System.Drawing.Point(1112, 456)
        Me.cmdAddDrink.Name = "cmdAddDrink"
        Appearance36.BackColor = System.Drawing.Color.OrangeRed
        Appearance36.BackColor2 = System.Drawing.Color.Tomato
        Appearance36.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance36.BorderColor = System.Drawing.Color.Transparent
        Me.cmdAddDrink.PressedAppearance = Appearance36
        Me.cmdAddDrink.ShowFocusRect = False
        Me.cmdAddDrink.ShowOutline = False
        Me.cmdAddDrink.Size = New System.Drawing.Size(46, 45)
        Me.cmdAddDrink.StyleSetName = "StatusBar"
        Me.cmdAddDrink.TabIndex = 596
        Me.cmdAddDrink.Tag = "Drinks"
        Me.cmdAddDrink.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdAddDrink.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdAddDrink.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdManualEntry
        '
        Me.cmdManualEntry.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance37.BackColor = System.Drawing.Color.Transparent
        Appearance37.BackColor2 = System.Drawing.Color.Transparent
        Appearance37.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance37.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance37.BorderColor = System.Drawing.Color.Transparent
        Appearance37.ForeColor = System.Drawing.Color.Black
        Appearance37.Image = CType(resources.GetObject("Appearance37.Image"), Object)
        Appearance37.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance37.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance37.TextVAlignAsString = "Bottom"
        Me.cmdManualEntry.Appearance = Appearance37
        Me.cmdManualEntry.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdManualEntry.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance38.BackColor = System.Drawing.Color.DarkOrange
        Appearance38.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance38.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance38.BorderColor = System.Drawing.Color.Transparent
        Appearance38.ForeColor = System.Drawing.Color.Black
        Me.cmdManualEntry.HotTrackAppearance = Appearance38
        Me.cmdManualEntry.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdManualEntry.Location = New System.Drawing.Point(1112, 405)
        Me.cmdManualEntry.Name = "cmdManualEntry"
        Appearance39.BackColor = System.Drawing.Color.OrangeRed
        Appearance39.BackColor2 = System.Drawing.Color.Tomato
        Appearance39.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance39.BorderColor = System.Drawing.Color.Transparent
        Me.cmdManualEntry.PressedAppearance = Appearance39
        Me.cmdManualEntry.ShowFocusRect = False
        Me.cmdManualEntry.ShowOutline = False
        Me.cmdManualEntry.Size = New System.Drawing.Size(46, 45)
        Me.cmdManualEntry.StyleSetName = "StatusBar"
        Me.cmdManualEntry.TabIndex = 595
        Me.cmdManualEntry.Tag = "x"
        Me.cmdManualEntry.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdManualEntry.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdManualEntry.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdLastItemQty
        '
        Me.cmdLastItemQty.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance40.BackColor = System.Drawing.Color.Transparent
        Appearance40.BackColor2 = System.Drawing.Color.Transparent
        Appearance40.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance40.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance40.BorderColor = System.Drawing.Color.Transparent
        Appearance40.ForeColor = System.Drawing.Color.Black
        Appearance40.Image = CType(resources.GetObject("Appearance40.Image"), Object)
        Appearance40.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance40.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance40.TextVAlignAsString = "Bottom"
        Me.cmdLastItemQty.Appearance = Appearance40
        Me.cmdLastItemQty.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdLastItemQty.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance41.BackColor = System.Drawing.Color.DarkOrange
        Appearance41.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance41.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance41.BorderColor = System.Drawing.Color.Transparent
        Appearance41.ForeColor = System.Drawing.Color.Black
        Me.cmdLastItemQty.HotTrackAppearance = Appearance41
        Me.cmdLastItemQty.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdLastItemQty.Location = New System.Drawing.Point(1112, 303)
        Me.cmdLastItemQty.Name = "cmdLastItemQty"
        Appearance42.BackColor = System.Drawing.Color.OrangeRed
        Appearance42.BackColor2 = System.Drawing.Color.Tomato
        Appearance42.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance42.BorderColor = System.Drawing.Color.Transparent
        Me.cmdLastItemQty.PressedAppearance = Appearance42
        Me.cmdLastItemQty.ShowFocusRect = False
        Me.cmdLastItemQty.ShowOutline = False
        Me.cmdLastItemQty.Size = New System.Drawing.Size(46, 45)
        Me.cmdLastItemQty.StyleSetName = "StatusBar"
        Me.cmdLastItemQty.TabIndex = 594
        Me.cmdLastItemQty.Tag = "New"
        Me.cmdLastItemQty.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdLastItemQty.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdLastItemQty.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdEditDish
        '
        Me.cmdEditDish.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance43.BackColor = System.Drawing.Color.Transparent
        Appearance43.BackColor2 = System.Drawing.Color.Transparent
        Appearance43.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance43.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance43.BorderColor = System.Drawing.Color.Transparent
        Appearance43.ForeColor = System.Drawing.Color.Black
        Appearance43.Image = CType(resources.GetObject("Appearance43.Image"), Object)
        Appearance43.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance43.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance43.TextVAlignAsString = "Bottom"
        Me.cmdEditDish.Appearance = Appearance43
        Me.cmdEditDish.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdEditDish.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance44.BackColor = System.Drawing.Color.DarkOrange
        Appearance44.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance44.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance44.BorderColor = System.Drawing.Color.Transparent
        Appearance44.ForeColor = System.Drawing.Color.Black
        Me.cmdEditDish.HotTrackAppearance = Appearance44
        Me.cmdEditDish.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdEditDish.Location = New System.Drawing.Point(1112, 354)
        Me.cmdEditDish.Name = "cmdEditDish"
        Appearance45.BackColor = System.Drawing.Color.OrangeRed
        Appearance45.BackColor2 = System.Drawing.Color.Tomato
        Appearance45.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance45.BorderColor = System.Drawing.Color.Transparent
        Me.cmdEditDish.PressedAppearance = Appearance45
        Me.cmdEditDish.ShowFocusRect = False
        Me.cmdEditDish.ShowOutline = False
        Me.cmdEditDish.Size = New System.Drawing.Size(46, 45)
        Me.cmdEditDish.StyleSetName = "StatusBar"
        Me.cmdEditDish.TabIndex = 593
        Me.cmdEditDish.Tag = "New"
        Me.cmdEditDish.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdEditDish.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdEditDish.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDishClearAll
        '
        Me.cmdDishClearAll.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance46.BackColor = System.Drawing.Color.Transparent
        Appearance46.BackColor2 = System.Drawing.Color.Transparent
        Appearance46.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance46.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance46.BorderColor = System.Drawing.Color.Transparent
        Appearance46.ForeColor = System.Drawing.Color.Black
        Appearance46.Image = CType(resources.GetObject("Appearance46.Image"), Object)
        Appearance46.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance46.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance46.TextVAlignAsString = "Bottom"
        Me.cmdDishClearAll.Appearance = Appearance46
        Me.cmdDishClearAll.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdDishClearAll.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance47.BackColor = System.Drawing.Color.DarkOrange
        Appearance47.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance47.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance47.BorderColor = System.Drawing.Color.Transparent
        Appearance47.ForeColor = System.Drawing.Color.Black
        Me.cmdDishClearAll.HotTrackAppearance = Appearance47
        Me.cmdDishClearAll.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdDishClearAll.Location = New System.Drawing.Point(1112, 558)
        Me.cmdDishClearAll.Name = "cmdDishClearAll"
        Appearance48.BackColor = System.Drawing.Color.OrangeRed
        Appearance48.BackColor2 = System.Drawing.Color.Tomato
        Appearance48.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance48.BorderColor = System.Drawing.Color.Transparent
        Me.cmdDishClearAll.PressedAppearance = Appearance48
        Me.cmdDishClearAll.ShowFocusRect = False
        Me.cmdDishClearAll.ShowOutline = False
        Me.cmdDishClearAll.Size = New System.Drawing.Size(46, 45)
        Me.cmdDishClearAll.StyleSetName = "StatusBar"
        Me.cmdDishClearAll.TabIndex = 592
        Me.cmdDishClearAll.Tag = "x"
        Me.cmdDishClearAll.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDishClearAll.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDishClearAll.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDeleteDish
        '
        Me.cmdDeleteDish.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance49.BackColor = System.Drawing.Color.Transparent
        Appearance49.BackColor2 = System.Drawing.Color.Transparent
        Appearance49.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance49.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance49.BorderColor = System.Drawing.Color.Transparent
        Appearance49.ForeColor = System.Drawing.Color.Black
        Appearance49.Image = CType(resources.GetObject("Appearance49.Image"), Object)
        Appearance49.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance49.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance49.TextVAlignAsString = "Bottom"
        Me.cmdDeleteDish.Appearance = Appearance49
        Me.cmdDeleteDish.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdDeleteDish.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance50.BackColor = System.Drawing.Color.DarkOrange
        Appearance50.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance50.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance50.BorderColor = System.Drawing.Color.Transparent
        Appearance50.ForeColor = System.Drawing.Color.Black
        Me.cmdDeleteDish.HotTrackAppearance = Appearance50
        Me.cmdDeleteDish.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdDeleteDish.Location = New System.Drawing.Point(1112, 252)
        Me.cmdDeleteDish.Name = "cmdDeleteDish"
        Appearance51.BackColor = System.Drawing.Color.OrangeRed
        Appearance51.BackColor2 = System.Drawing.Color.Tomato
        Appearance51.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance51.BorderColor = System.Drawing.Color.Transparent
        Me.cmdDeleteDish.PressedAppearance = Appearance51
        Me.cmdDeleteDish.ShowFocusRect = False
        Me.cmdDeleteDish.ShowOutline = False
        Me.cmdDeleteDish.Size = New System.Drawing.Size(46, 45)
        Me.cmdDeleteDish.StyleSetName = "StatusBar"
        Me.cmdDeleteDish.TabIndex = 591
        Me.cmdDeleteDish.Tag = "x"
        Me.cmdDeleteDish.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDeleteDish.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDeleteDish.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDecDish
        '
        Me.cmdDecDish.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance52.BackColor = System.Drawing.Color.Transparent
        Appearance52.BackColor2 = System.Drawing.Color.Transparent
        Appearance52.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance52.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance52.BorderColor = System.Drawing.Color.Transparent
        Appearance52.ForeColor = System.Drawing.Color.Black
        Appearance52.Image = CType(resources.GetObject("Appearance52.Image"), Object)
        Appearance52.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance52.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance52.TextVAlignAsString = "Bottom"
        Me.cmdDecDish.Appearance = Appearance52
        Me.cmdDecDish.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdDecDish.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance53.BackColor = System.Drawing.Color.DarkOrange
        Appearance53.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance53.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance53.BorderColor = System.Drawing.Color.Transparent
        Appearance53.ForeColor = System.Drawing.Color.Black
        Me.cmdDecDish.HotTrackAppearance = Appearance53
        Me.cmdDecDish.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdDecDish.Location = New System.Drawing.Point(1112, 201)
        Me.cmdDecDish.Name = "cmdDecDish"
        Appearance54.BackColor = System.Drawing.Color.OrangeRed
        Appearance54.BackColor2 = System.Drawing.Color.Tomato
        Appearance54.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance54.BorderColor = System.Drawing.Color.Transparent
        Me.cmdDecDish.PressedAppearance = Appearance54
        Me.cmdDecDish.ShowFocusRect = False
        Me.cmdDecDish.ShowOutline = False
        Me.cmdDecDish.Size = New System.Drawing.Size(46, 45)
        Me.cmdDecDish.StyleSetName = "StatusBar"
        Me.cmdDecDish.TabIndex = 590
        Me.cmdDecDish.Tag = "-"
        Me.cmdDecDish.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDecDish.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDecDish.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdIncDish
        '
        Me.cmdIncDish.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance55.BackColor = System.Drawing.Color.Transparent
        Appearance55.BackColor2 = System.Drawing.Color.Transparent
        Appearance55.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance55.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance55.BorderColor = System.Drawing.Color.Transparent
        Appearance55.ForeColor = System.Drawing.Color.Black
        Appearance55.Image = CType(resources.GetObject("Appearance55.Image"), Object)
        Appearance55.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance55.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance55.TextVAlignAsString = "Bottom"
        Me.cmdIncDish.Appearance = Appearance55
        Me.cmdIncDish.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdIncDish.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance56.BackColor = System.Drawing.Color.DarkOrange
        Appearance56.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance56.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance56.BorderColor = System.Drawing.Color.Transparent
        Appearance56.ForeColor = System.Drawing.Color.Black
        Me.cmdIncDish.HotTrackAppearance = Appearance56
        Me.cmdIncDish.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdIncDish.Location = New System.Drawing.Point(1112, 150)
        Me.cmdIncDish.Name = "cmdIncDish"
        Appearance57.BackColor = System.Drawing.Color.OrangeRed
        Appearance57.BackColor2 = System.Drawing.Color.Tomato
        Appearance57.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance57.BorderColor = System.Drawing.Color.Transparent
        Me.cmdIncDish.PressedAppearance = Appearance57
        Me.cmdIncDish.ShowFocusRect = False
        Me.cmdIncDish.ShowOutline = False
        Me.cmdIncDish.Size = New System.Drawing.Size(46, 45)
        Me.cmdIncDish.StyleSetName = "StatusBar"
        Me.cmdIncDish.TabIndex = 589
        Me.cmdIncDish.Tag = "+"
        Me.cmdIncDish.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdIncDish.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdIncDish.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdOGDown
        '
        Me.cmdOGDown.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance58.BackColor = System.Drawing.Color.Transparent
        Appearance58.BackColor2 = System.Drawing.Color.Transparent
        Appearance58.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance58.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance58.BorderColor = System.Drawing.Color.Transparent
        Appearance58.ForeColor = System.Drawing.Color.Black
        Appearance58.Image = CType(resources.GetObject("Appearance58.Image"), Object)
        Appearance58.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance58.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance58.TextVAlignAsString = "Bottom"
        Me.cmdOGDown.Appearance = Appearance58
        Me.cmdOGDown.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdOGDown.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance59.BackColor = System.Drawing.Color.DarkOrange
        Appearance59.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance59.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance59.BorderColor = System.Drawing.Color.Transparent
        Appearance59.ForeColor = System.Drawing.Color.Black
        Me.cmdOGDown.HotTrackAppearance = Appearance59
        Me.cmdOGDown.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdOGDown.Location = New System.Drawing.Point(1112, 99)
        Me.cmdOGDown.Name = "cmdOGDown"
        Appearance60.BackColor = System.Drawing.Color.OrangeRed
        Appearance60.BackColor2 = System.Drawing.Color.Tomato
        Appearance60.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance60.BorderColor = System.Drawing.Color.Transparent
        Me.cmdOGDown.PressedAppearance = Appearance60
        Me.cmdOGDown.ShowFocusRect = False
        Me.cmdOGDown.ShowOutline = False
        Me.cmdOGDown.Size = New System.Drawing.Size(46, 45)
        Me.cmdOGDown.StyleSetName = "StatusBar"
        Me.cmdOGDown.TabIndex = 588
        Me.cmdOGDown.Tag = "Down"
        Me.cmdOGDown.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOGDown.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOGDown.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdOGUp
        '
        Me.cmdOGUp.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance61.BackColor = System.Drawing.Color.Transparent
        Appearance61.BackColor2 = System.Drawing.Color.Transparent
        Appearance61.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance61.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance61.BorderColor = System.Drawing.Color.Transparent
        Appearance61.ForeColor = System.Drawing.Color.Black
        Appearance61.Image = CType(resources.GetObject("Appearance61.Image"), Object)
        Appearance61.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance61.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance61.TextVAlignAsString = "Bottom"
        Me.cmdOGUp.Appearance = Appearance61
        Me.cmdOGUp.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdOGUp.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance62.BackColor = System.Drawing.Color.DarkOrange
        Appearance62.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance62.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance62.BorderColor = System.Drawing.Color.Transparent
        Appearance62.ForeColor = System.Drawing.Color.Black
        Me.cmdOGUp.HotTrackAppearance = Appearance62
        Me.cmdOGUp.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdOGUp.Location = New System.Drawing.Point(1112, 48)
        Me.cmdOGUp.Name = "cmdOGUp"
        Appearance63.BackColor = System.Drawing.Color.OrangeRed
        Appearance63.BackColor2 = System.Drawing.Color.Tomato
        Appearance63.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance63.BorderColor = System.Drawing.Color.Transparent
        Me.cmdOGUp.PressedAppearance = Appearance63
        Me.cmdOGUp.ShowFocusRect = False
        Me.cmdOGUp.ShowOutline = False
        Me.cmdOGUp.Size = New System.Drawing.Size(46, 45)
        Me.cmdOGUp.StyleSetName = "StatusBar"
        Me.cmdOGUp.TabIndex = 587
        Me.cmdOGUp.Tag = "Up"
        Me.cmdOGUp.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOGUp.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOGUp.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'upnlChoices
        '
        Appearance64.BackColor = System.Drawing.Color.Transparent
        Me.upnlChoices.Appearance = Appearance64
        '
        'upnlChoices.ClientArea
        '
        Me.upnlChoices.ClientArea.Controls.Add(Me.cmdChoice7)
        Me.upnlChoices.ClientArea.Controls.Add(Me.cmdChoice6)
        Me.upnlChoices.ClientArea.Controls.Add(Me.cmdChoice5)
        Me.upnlChoices.ClientArea.Controls.Add(Me.cmdChoice4)
        Me.upnlChoices.ClientArea.Controls.Add(Me.cmdChoice3)
        Me.upnlChoices.ClientArea.Controls.Add(Me.cmdChoice2)
        Me.upnlChoices.ClientArea.Controls.Add(Me.cmdChoice1)
        Me.upnlChoices.Location = New System.Drawing.Point(750, 56)
        Me.upnlChoices.Name = "upnlChoices"
        Me.upnlChoices.Size = New System.Drawing.Size(233, 302)
        Me.upnlChoices.TabIndex = 601
        Me.upnlChoices.Visible = False
        '
        'cmdChoice7
        '
        Appearance65.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(170, Byte), Integer))
        Appearance65.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(110, Byte), Integer), CType(CType(160, Byte), Integer))
        Appearance65.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop20
        Appearance65.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance65.BorderColor = System.Drawing.Color.FromArgb(CType(CType(90, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(200, Byte), Integer))
        Appearance65.BorderColor2 = System.Drawing.Color.Maroon
        Appearance65.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance65.ForeColor = System.Drawing.Color.WhiteSmoke
        Appearance65.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance65.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance65.TextVAlignAsString = "Middle"
        Me.cmdChoice7.Appearance = Appearance65
        Me.cmdChoice7.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance66.BackColor = System.Drawing.Color.DarkOrange
        Appearance66.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance66.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance66.ForeColor = System.Drawing.Color.Black
        Me.cmdChoice7.HotTrackAppearance = Appearance66
        Me.cmdChoice7.ImageSize = New System.Drawing.Size(40, 40)
        Me.cmdChoice7.Location = New System.Drawing.Point(2, 2)
        Me.cmdChoice7.Name = "cmdChoice7"
        Appearance67.BackColor = System.Drawing.Color.OrangeRed
        Appearance67.BackColor2 = System.Drawing.Color.Tomato
        Appearance67.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdChoice7.PressedAppearance = Appearance67
        Me.cmdChoice7.ShowFocusRect = False
        Me.cmdChoice7.ShowOutline = False
        Me.cmdChoice7.Size = New System.Drawing.Size(220, 41)
        Me.cmdChoice7.StyleSetName = "OEDishButtonGreen"
        Me.cmdChoice7.TabIndex = 501
        Me.cmdChoice7.Tag = ""
        Me.cmdChoice7.Text = "10"
        Me.cmdChoice7.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdChoice7.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdChoice7.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdChoice6
        '
        Appearance68.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(170, Byte), Integer))
        Appearance68.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(110, Byte), Integer), CType(CType(160, Byte), Integer))
        Appearance68.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop20
        Appearance68.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance68.BorderColor = System.Drawing.Color.FromArgb(CType(CType(90, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(200, Byte), Integer))
        Appearance68.BorderColor2 = System.Drawing.Color.Maroon
        Appearance68.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance68.ForeColor = System.Drawing.Color.WhiteSmoke
        Appearance68.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance68.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance68.TextVAlignAsString = "Middle"
        Me.cmdChoice6.Appearance = Appearance68
        Me.cmdChoice6.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance69.BackColor = System.Drawing.Color.DarkOrange
        Appearance69.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance69.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance69.ForeColor = System.Drawing.Color.Black
        Me.cmdChoice6.HotTrackAppearance = Appearance69
        Me.cmdChoice6.ImageSize = New System.Drawing.Size(40, 40)
        Me.cmdChoice6.Location = New System.Drawing.Point(2, 44)
        Me.cmdChoice6.Name = "cmdChoice6"
        Appearance70.BackColor = System.Drawing.Color.OrangeRed
        Appearance70.BackColor2 = System.Drawing.Color.Tomato
        Appearance70.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdChoice6.PressedAppearance = Appearance70
        Me.cmdChoice6.ShowFocusRect = False
        Me.cmdChoice6.ShowOutline = False
        Me.cmdChoice6.Size = New System.Drawing.Size(220, 41)
        Me.cmdChoice6.StyleSetName = "OEDishButtonGreen"
        Me.cmdChoice6.TabIndex = 500
        Me.cmdChoice6.Tag = ""
        Me.cmdChoice6.Text = "10"
        Me.cmdChoice6.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdChoice6.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdChoice6.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdChoice5
        '
        Appearance71.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(170, Byte), Integer))
        Appearance71.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(110, Byte), Integer), CType(CType(160, Byte), Integer))
        Appearance71.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop20
        Appearance71.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance71.BorderColor = System.Drawing.Color.FromArgb(CType(CType(90, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(200, Byte), Integer))
        Appearance71.BorderColor2 = System.Drawing.Color.Maroon
        Appearance71.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance71.ForeColor = System.Drawing.Color.WhiteSmoke
        Appearance71.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance71.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance71.TextVAlignAsString = "Middle"
        Me.cmdChoice5.Appearance = Appearance71
        Me.cmdChoice5.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance72.BackColor = System.Drawing.Color.DarkOrange
        Appearance72.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance72.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance72.ForeColor = System.Drawing.Color.Black
        Me.cmdChoice5.HotTrackAppearance = Appearance72
        Me.cmdChoice5.ImageSize = New System.Drawing.Size(40, 40)
        Me.cmdChoice5.Location = New System.Drawing.Point(2, 86)
        Me.cmdChoice5.Name = "cmdChoice5"
        Appearance73.BackColor = System.Drawing.Color.OrangeRed
        Appearance73.BackColor2 = System.Drawing.Color.Tomato
        Appearance73.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdChoice5.PressedAppearance = Appearance73
        Me.cmdChoice5.ShowFocusRect = False
        Me.cmdChoice5.ShowOutline = False
        Me.cmdChoice5.Size = New System.Drawing.Size(220, 41)
        Me.cmdChoice5.StyleSetName = "OEDishButtonGreen"
        Me.cmdChoice5.TabIndex = 499
        Me.cmdChoice5.Tag = ""
        Me.cmdChoice5.Text = "10"
        Me.cmdChoice5.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdChoice5.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdChoice5.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdChoice4
        '
        Appearance74.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(170, Byte), Integer))
        Appearance74.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(110, Byte), Integer), CType(CType(160, Byte), Integer))
        Appearance74.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop20
        Appearance74.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance74.BorderColor = System.Drawing.Color.FromArgb(CType(CType(90, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(200, Byte), Integer))
        Appearance74.BorderColor2 = System.Drawing.Color.Maroon
        Appearance74.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance74.ForeColor = System.Drawing.Color.WhiteSmoke
        Appearance74.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance74.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance74.TextVAlignAsString = "Middle"
        Me.cmdChoice4.Appearance = Appearance74
        Me.cmdChoice4.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance75.BackColor = System.Drawing.Color.DarkOrange
        Appearance75.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance75.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance75.ForeColor = System.Drawing.Color.Black
        Me.cmdChoice4.HotTrackAppearance = Appearance75
        Me.cmdChoice4.ImageSize = New System.Drawing.Size(40, 40)
        Me.cmdChoice4.Location = New System.Drawing.Point(2, 128)
        Me.cmdChoice4.Name = "cmdChoice4"
        Appearance76.BackColor = System.Drawing.Color.OrangeRed
        Appearance76.BackColor2 = System.Drawing.Color.Tomato
        Appearance76.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdChoice4.PressedAppearance = Appearance76
        Me.cmdChoice4.ShowFocusRect = False
        Me.cmdChoice4.ShowOutline = False
        Me.cmdChoice4.Size = New System.Drawing.Size(220, 41)
        Me.cmdChoice4.StyleSetName = "OEDishButtonGreen"
        Me.cmdChoice4.TabIndex = 498
        Me.cmdChoice4.Tag = ""
        Me.cmdChoice4.Text = "10"
        Me.cmdChoice4.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdChoice4.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdChoice4.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdChoice3
        '
        Appearance77.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(170, Byte), Integer))
        Appearance77.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(110, Byte), Integer), CType(CType(160, Byte), Integer))
        Appearance77.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop20
        Appearance77.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance77.BorderColor = System.Drawing.Color.FromArgb(CType(CType(90, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(200, Byte), Integer))
        Appearance77.BorderColor2 = System.Drawing.Color.Maroon
        Appearance77.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance77.ForeColor = System.Drawing.Color.WhiteSmoke
        Appearance77.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance77.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance77.TextVAlignAsString = "Middle"
        Me.cmdChoice3.Appearance = Appearance77
        Me.cmdChoice3.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance78.BackColor = System.Drawing.Color.DarkOrange
        Appearance78.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance78.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance78.ForeColor = System.Drawing.Color.Black
        Me.cmdChoice3.HotTrackAppearance = Appearance78
        Me.cmdChoice3.ImageSize = New System.Drawing.Size(40, 40)
        Me.cmdChoice3.Location = New System.Drawing.Point(2, 170)
        Me.cmdChoice3.Name = "cmdChoice3"
        Appearance79.BackColor = System.Drawing.Color.OrangeRed
        Appearance79.BackColor2 = System.Drawing.Color.Tomato
        Appearance79.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdChoice3.PressedAppearance = Appearance79
        Me.cmdChoice3.ShowFocusRect = False
        Me.cmdChoice3.ShowOutline = False
        Me.cmdChoice3.Size = New System.Drawing.Size(220, 41)
        Me.cmdChoice3.StyleSetName = "OEDishButtonGreen"
        Me.cmdChoice3.TabIndex = 497
        Me.cmdChoice3.Tag = ""
        Me.cmdChoice3.Text = "10"
        Me.cmdChoice3.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdChoice3.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdChoice3.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdChoice2
        '
        Appearance80.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(170, Byte), Integer))
        Appearance80.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(110, Byte), Integer), CType(CType(160, Byte), Integer))
        Appearance80.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop20
        Appearance80.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance80.BorderColor = System.Drawing.Color.FromArgb(CType(CType(90, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(200, Byte), Integer))
        Appearance80.BorderColor2 = System.Drawing.Color.Maroon
        Appearance80.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance80.ForeColor = System.Drawing.Color.WhiteSmoke
        Appearance80.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance80.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance80.TextVAlignAsString = "Middle"
        Me.cmdChoice2.Appearance = Appearance80
        Me.cmdChoice2.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance81.BackColor = System.Drawing.Color.DarkOrange
        Appearance81.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance81.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance81.ForeColor = System.Drawing.Color.Black
        Me.cmdChoice2.HotTrackAppearance = Appearance81
        Me.cmdChoice2.ImageSize = New System.Drawing.Size(40, 40)
        Me.cmdChoice2.Location = New System.Drawing.Point(2, 212)
        Me.cmdChoice2.Name = "cmdChoice2"
        Appearance82.BackColor = System.Drawing.Color.OrangeRed
        Appearance82.BackColor2 = System.Drawing.Color.Tomato
        Appearance82.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdChoice2.PressedAppearance = Appearance82
        Me.cmdChoice2.ShowFocusRect = False
        Me.cmdChoice2.ShowOutline = False
        Me.cmdChoice2.Size = New System.Drawing.Size(220, 41)
        Me.cmdChoice2.StyleSetName = "OEDishButtonGreen"
        Me.cmdChoice2.TabIndex = 496
        Me.cmdChoice2.Tag = ""
        Me.cmdChoice2.Text = "10"
        Me.cmdChoice2.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdChoice2.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdChoice2.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdChoice1
        '
        Appearance83.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(170, Byte), Integer))
        Appearance83.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(110, Byte), Integer), CType(CType(160, Byte), Integer))
        Appearance83.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop20
        Appearance83.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance83.BorderColor = System.Drawing.Color.FromArgb(CType(CType(90, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(200, Byte), Integer))
        Appearance83.BorderColor2 = System.Drawing.Color.Maroon
        Appearance83.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance83.ForeColor = System.Drawing.Color.WhiteSmoke
        Appearance83.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance83.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance83.TextVAlignAsString = "Middle"
        Me.cmdChoice1.Appearance = Appearance83
        Me.cmdChoice1.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance84.BackColor = System.Drawing.Color.DarkOrange
        Appearance84.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance84.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance84.ForeColor = System.Drawing.Color.Black
        Me.cmdChoice1.HotTrackAppearance = Appearance84
        Me.cmdChoice1.ImageSize = New System.Drawing.Size(40, 40)
        Me.cmdChoice1.Location = New System.Drawing.Point(2, 254)
        Me.cmdChoice1.Name = "cmdChoice1"
        Appearance85.BackColor = System.Drawing.Color.OrangeRed
        Appearance85.BackColor2 = System.Drawing.Color.Tomato
        Appearance85.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdChoice1.PressedAppearance = Appearance85
        Me.cmdChoice1.ShowFocusRect = False
        Me.cmdChoice1.ShowOutline = False
        Me.cmdChoice1.Size = New System.Drawing.Size(220, 41)
        Me.cmdChoice1.StyleSetName = "OEDishButtonGreen"
        Me.cmdChoice1.TabIndex = 495
        Me.cmdChoice1.Tag = ""
        Me.cmdChoice1.Text = "10"
        Me.cmdChoice1.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdChoice1.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdChoice1.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'EZMenuDataSet
        '
        Me.EZMenuDataSet.DataSetName = "EZMenuDataSet"
        Me.EZMenuDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'txtKBCode
        '
        Me.txtKBCode.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtKBCode.Location = New System.Drawing.Point(1124, 590)
        Me.txtKBCode.Name = "txtKBCode"
        Me.txtKBCode.Size = New System.Drawing.Size(32, 20)
        Me.txtKBCode.TabIndex = 611
        Me.txtKBCode.Visible = False
        '
        'ugdOrderGrid
        '
        Me.ugdOrderGrid.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance86.BackColor = System.Drawing.Color.FromArgb(CType(CType(253, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(253, Byte), Integer))
        Appearance86.BorderColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.ugdOrderGrid.DisplayLayout.Appearance = Appearance86
        UltraGridColumn1.DataType = GetType(Short)
        UltraGridColumn1.DefaultCellValue = CType(0, Short)
        UltraGridColumn1.Header.Caption = "Code"
        UltraGridColumn1.Header.VisiblePosition = 0
        UltraGridColumn1.Hidden = True
        UltraGridColumn1.Width = 48
        UltraGridColumn2.DefaultCellValue = """"""
        UltraGridColumn2.Header.Caption = "Name"
        UltraGridColumn2.Header.VisiblePosition = 2
        UltraGridColumn2.Width = 222
        Appearance87.TextHAlignAsString = "Right"
        UltraGridColumn3.CellAppearance = Appearance87
        UltraGridColumn3.DataType = GetType(Decimal)
        UltraGridColumn3.DefaultCellValue = New Decimal(New Integer() {0, 0, 0, 0})
        UltraGridColumn3.Header.Caption = "Price"
        UltraGridColumn3.Header.VisiblePosition = 3
        UltraGridColumn3.Hidden = True
        Appearance88.TextHAlignAsString = "Center"
        UltraGridColumn4.CellAppearance = Appearance88
        UltraGridColumn4.DataType = GetType(Short)
        UltraGridColumn4.DefaultCellValue = CType(0, Short)
        UltraGridColumn4.Header.Caption = "Qty"
        UltraGridColumn4.Header.VisiblePosition = 1
        UltraGridColumn4.Width = 34
        Appearance89.TextHAlignAsString = "Right"
        UltraGridColumn5.CellAppearance = Appearance89
        UltraGridColumn5.DataType = GetType(Decimal)
        UltraGridColumn5.DefaultCellValue = New Decimal(New Integer() {0, 0, 0, 0})
        UltraGridColumn5.Format = "#0.00"
        UltraGridColumn5.Header.VisiblePosition = 4
        UltraGridColumn5.Width = 55
        UltraGridColumn6.DefaultCellValue = """"""
        UltraGridColumn6.Header.VisiblePosition = 5
        UltraGridColumn6.Hidden = True
        UltraGridColumn6.Nullable = Infragistics.Win.UltraWinGrid.Nullable.EmptyString
        UltraGridColumn7.DataType = GetType(Short)
        UltraGridColumn7.DefaultCellValue = CType(0, Short)
        UltraGridColumn7.Header.VisiblePosition = 6
        UltraGridColumn7.Hidden = True
        UltraGridColumn8.DataType = GetType(Decimal)
        UltraGridColumn8.DefaultCellValue = New Decimal(New Integer() {0, 0, 0, 0})
        UltraGridColumn8.Header.VisiblePosition = 7
        UltraGridColumn8.Hidden = True
        UltraGridColumn9.DataType = GetType(Decimal)
        UltraGridColumn9.DefaultCellValue = New Decimal(New Integer() {0, 0, 0, 0})
        UltraGridColumn9.Header.VisiblePosition = 8
        UltraGridColumn9.Hidden = True
        UltraGridColumn10.DataType = GetType(Decimal)
        UltraGridColumn10.DefaultCellValue = New Decimal(New Integer() {0, 0, 0, 0})
        UltraGridColumn10.Header.VisiblePosition = 9
        UltraGridColumn10.Hidden = True
        UltraGridColumn11.DataType = GetType(Short)
        UltraGridColumn11.DefaultCellValue = CType(0, Short)
        UltraGridColumn11.Header.VisiblePosition = 10
        UltraGridColumn11.Hidden = True
        UltraGridColumn13.DataType = GetType(Short)
        UltraGridColumn13.DefaultCellValue = CType(0, Short)
        UltraGridColumn13.Header.VisiblePosition = 11
        UltraGridColumn13.Hidden = True
        UltraGridColumn14.DefaultCellValue = """"""
        UltraGridColumn14.Header.VisiblePosition = 12
        UltraGridColumn14.Hidden = True
        UltraGridColumn14.Nullable = Infragistics.Win.UltraWinGrid.Nullable.EmptyString
        UltraGridColumn12.DataType = GetType(Short)
        UltraGridColumn12.DefaultCellValue = CType(0, Short)
        UltraGridColumn12.Header.VisiblePosition = 13
        UltraGridColumn12.Hidden = True
        UltraGridColumn12.Nullable = Infragistics.Win.UltraWinGrid.Nullable.EmptyString
        UltraGridBand1.Columns.AddRange(New Object() {UltraGridColumn1, UltraGridColumn2, UltraGridColumn3, UltraGridColumn4, UltraGridColumn5, UltraGridColumn6, UltraGridColumn7, UltraGridColumn8, UltraGridColumn9, UltraGridColumn10, UltraGridColumn11, UltraGridColumn13, UltraGridColumn14, UltraGridColumn12})
        UltraGridBand1.Override.AllowAddNew = Infragistics.Win.UltraWinGrid.AllowAddNew.Yes
        Me.ugdOrderGrid.DisplayLayout.BandsSerializer.Add(UltraGridBand1)
        Me.ugdOrderGrid.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Me.ugdOrderGrid.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.[False]
        Me.ugdOrderGrid.DisplayLayout.DefaultSelectedBackColor = System.Drawing.Color.Empty
        Me.ugdOrderGrid.DisplayLayout.DefaultSelectedForeColor = System.Drawing.Color.Empty
        Appearance90.BackColor = System.Drawing.SystemColors.ActiveBorder
        Appearance90.BackColor2 = System.Drawing.SystemColors.ControlDark
        Appearance90.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance90.BorderColor = System.Drawing.SystemColors.Window
        Me.ugdOrderGrid.DisplayLayout.GroupByBox.Appearance = Appearance90
        Appearance91.ForeColor = System.Drawing.SystemColors.GrayText
        Me.ugdOrderGrid.DisplayLayout.GroupByBox.BandLabelAppearance = Appearance91
        Me.ugdOrderGrid.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Appearance92.BackColor = System.Drawing.SystemColors.ControlLightLight
        Appearance92.BackColor2 = System.Drawing.SystemColors.Control
        Appearance92.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal
        Appearance92.ForeColor = System.Drawing.SystemColors.GrayText
        Me.ugdOrderGrid.DisplayLayout.GroupByBox.PromptAppearance = Appearance92
        Me.ugdOrderGrid.DisplayLayout.MaxColScrollRegions = 1
        Me.ugdOrderGrid.DisplayLayout.MaxRowScrollRegions = 1
        Me.ugdOrderGrid.DisplayLayout.Override.AllowColMoving = Infragistics.Win.UltraWinGrid.AllowColMoving.NotAllowed
        Me.ugdOrderGrid.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted
        Me.ugdOrderGrid.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted
        Appearance93.BackColor = System.Drawing.SystemColors.Window
        Me.ugdOrderGrid.DisplayLayout.Override.CardAreaAppearance = Appearance93
        Appearance94.BorderColor = System.Drawing.Color.Silver
        Appearance94.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter
        Me.ugdOrderGrid.DisplayLayout.Override.CellAppearance = Appearance94
        Me.ugdOrderGrid.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.EditAndSelectText
        Me.ugdOrderGrid.DisplayLayout.Override.CellPadding = 0
        Appearance95.BackColor = System.Drawing.SystemColors.Control
        Appearance95.BackColor2 = System.Drawing.SystemColors.ControlDark
        Appearance95.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element
        Appearance95.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal
        Appearance95.BorderColor = System.Drawing.SystemColors.Window
        Me.ugdOrderGrid.DisplayLayout.Override.GroupByRowAppearance = Appearance95
        Appearance96.BackColor = System.Drawing.Color.Gainsboro
        Appearance96.BackColor2 = System.Drawing.Color.Gainsboro
        Appearance96.TextHAlignAsString = "Center"
        Me.ugdOrderGrid.DisplayLayout.Override.HeaderAppearance = Appearance96
        Me.ugdOrderGrid.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti
        Me.ugdOrderGrid.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand
        Appearance97.BackColor = System.Drawing.Color.FromArgb(CType(CType(238, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(238, Byte), Integer))
        Me.ugdOrderGrid.DisplayLayout.Override.RowAlternateAppearance = Appearance97
        Appearance98.BackColor = System.Drawing.Color.FromArgb(CType(CType(247, Byte), Integer), CType(CType(247, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.ugdOrderGrid.DisplayLayout.Override.RowAppearance = Appearance98
        Me.ugdOrderGrid.DisplayLayout.Override.RowSelectorHeaderStyle = Infragistics.Win.UltraWinGrid.RowSelectorHeaderStyle.None
        Me.ugdOrderGrid.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.[False]
        Me.ugdOrderGrid.DisplayLayout.Override.RowSizing = Infragistics.Win.UltraWinGrid.RowSizing.Sychronized
        Me.ugdOrderGrid.DisplayLayout.Override.RowSizingArea = Infragistics.Win.UltraWinGrid.RowSizingArea.RowBordersOnly
        Me.ugdOrderGrid.DisplayLayout.Override.SelectTypeCol = Infragistics.Win.UltraWinGrid.SelectType.None
        Me.ugdOrderGrid.DisplayLayout.Override.SelectTypeRow = Infragistics.Win.UltraWinGrid.SelectType.[Single]
        Me.ugdOrderGrid.DisplayLayout.Override.WrapHeaderText = Infragistics.Win.DefaultableBoolean.[True]
        Me.ugdOrderGrid.DisplayLayout.Scrollbars = Infragistics.Win.UltraWinGrid.Scrollbars.None
        Me.ugdOrderGrid.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill
        Me.ugdOrderGrid.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate
        Me.ugdOrderGrid.DisplayLayout.ViewStyle = Infragistics.Win.UltraWinGrid.ViewStyle.SingleBand
        Me.ugdOrderGrid.Font = New System.Drawing.Font("Arial", 10.0!)
        Me.ugdOrderGrid.Location = New System.Drawing.Point(784, 48)
        Me.ugdOrderGrid.Name = "ugdOrderGrid"
        Me.ugdOrderGrid.Size = New System.Drawing.Size(320, 394)
        Me.ugdOrderGrid.StyleSetName = "EZGrid"
        Me.ugdOrderGrid.TabIndex = 610
        '
        'udsOrder
        '
        UltraDataColumn3.DataType = GetType(Decimal)
        UltraDataColumn4.DefaultValue = "''"
        UltraDataColumn5.DataType = GetType(Decimal)
        UltraDataColumn7.DataType = GetType(Short)
        UltraDataColumn8.DataType = GetType(Short)
        UltraDataColumn9.DataType = GetType(Decimal)
        UltraDataColumn10.DataType = GetType(Decimal)
        UltraDataColumn11.DataType = GetType(Decimal)
        UltraDataColumn12.DataType = GetType(Short)
        UltraDataColumn13.DataType = GetType(Short)
        Me.udsOrder.Band.Columns.AddRange(New Object() {UltraDataColumn1, UltraDataColumn2, UltraDataColumn3, UltraDataColumn4, UltraDataColumn5, UltraDataColumn6, UltraDataColumn7, UltraDataColumn8, UltraDataColumn9, UltraDataColumn10, UltraDataColumn11, UltraDataColumn12, UltraDataColumn13})
        '
        'GroupsBindingSource
        '
        Me.GroupsBindingSource.DataMember = "Groups"
        Me.GroupsBindingSource.DataSource = Me.EZMenuDataSet
        '
        'GroupsTableAdapter
        '
        Me.GroupsTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.AltAddressTableAdapter = Nothing
        Me.TableAdapterManager.Alternative_PhoneTableAdapter = Nothing
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.BankingTableAdapter = Nothing
        Me.TableAdapterManager.BankPrintTableAdapter = Nothing
        Me.TableAdapterManager.CallerIDLogTableAdapter = Nothing
        Me.TableAdapterManager.CodesTableAdapter = Nothing
        Me.TableAdapterManager.CollectorTableAdapter = Nothing
        Me.TableAdapterManager.CustomerTableAdapter = Nothing
        Me.TableAdapterManager.DirectionsTableAdapter = Nothing
        Me.TableAdapterManager.DishTableAdapter = Nothing
        Me.TableAdapterManager.DrinksTableAdapter = Nothing
        Me.TableAdapterManager.FreeOffersTableAdapter = Nothing
        Me.TableAdapterManager.GroupsTableAdapter = Me.GroupsTableAdapter
        Me.TableAdapterManager.KitchenNotesTableAdapter = Nothing
        Me.TableAdapterManager.ModifiersTableAdapter = Nothing
        Me.TableAdapterManager.NotesDBTableAdapter = Nothing
        Me.TableAdapterManager.OffersTableAdapter = Nothing
        Me.TableAdapterManager.OrderItemsTableAdapter = Nothing
        Me.TableAdapterManager.OrdersTableAdapter = Nothing
        Me.TableAdapterManager.SetIDTableAdapter = Nothing
        Me.TableAdapterManager.SetMealsTableAdapter = Nothing
        Me.TableAdapterManager.SetSelectedItemsTableAdapter = Nothing
        Me.TableAdapterManager.SetSelectedTableAdapter = Nothing
        Me.TableAdapterManager.SummaryTableAdapter = Nothing
        Me.TableAdapterManager.Table_BillTableAdapter = Nothing
        Me.TableAdapterManager.Table_DrinksTableAdapter = Nothing
        Me.TableAdapterManager.Table_MealTableAdapter = Nothing
        Me.TableAdapterManager.TypicalTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = EZMenu.EZMenuDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        Me.TableAdapterManager.UsersTableAdapter = Nothing
        '
        'DishBindingSource
        '
        Me.DishBindingSource.DataMember = "Dish"
        Me.DishBindingSource.DataSource = Me.EZMenuDataSet
        '
        'DishTableAdapter
        '
        Me.DishTableAdapter.ClearBeforeFill = True
        '
        'pnlDishesMain
        '
        Me.pnlDishesMain.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance99.BorderColor = System.Drawing.Color.LightGray
        Me.pnlDishesMain.Appearance = Appearance99
        Me.pnlDishesMain.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        '
        'pnlDishesMain.ClientArea
        '
        Me.pnlDishesMain.ClientArea.Controls.Add(Me.pnlDishes)
        Me.pnlDishesMain.Location = New System.Drawing.Point(164, 45)
        Me.pnlDishesMain.Name = "pnlDishesMain"
        Me.pnlDishesMain.Size = New System.Drawing.Size(600, 577)
        Me.pnlDishesMain.TabIndex = 618
        '
        'pnlDishes
        '
        Me.pnlDishes.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.pnlDishes.AutoSize = True
        Me.pnlDishes.Location = New System.Drawing.Point(2, 2)
        Me.pnlDishes.Name = "pnlDishes"
        Me.pnlDishes.Size = New System.Drawing.Size(46, 571)
        Me.pnlDishes.TabIndex = 5
        '
        'cmdGroupDown
        '
        Me.cmdGroupDown.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.cmdGroupDown.Location = New System.Drawing.Point(15, 576)
        Me.cmdGroupDown.Name = "cmdGroupDown"
        Me.cmdGroupDown.Size = New System.Drawing.Size(137, 41)
        Me.cmdGroupDown.StyleSetName = "OEGroupButtonUpDown"
        Me.cmdGroupDown.TabIndex = 617
        Me.cmdGroupDown.Text = "Down"
        Me.cmdGroupDown.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdGroupDown.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdGroupDown.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdGroupUp
        '
        Me.cmdGroupUp.Location = New System.Drawing.Point(15, 48)
        Me.cmdGroupUp.Name = "cmdGroupUp"
        Me.cmdGroupUp.Size = New System.Drawing.Size(137, 41)
        Me.cmdGroupUp.StyleSetName = "OEGroupButtonUpDown"
        Me.cmdGroupUp.TabIndex = 616
        Me.cmdGroupUp.Text = "Up"
        Me.cmdGroupUp.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdGroupUp.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdGroupUp.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'pnlGroupMain
        '
        Me.pnlGroupMain.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        '
        'pnlGroupMain.ClientArea
        '
        Me.pnlGroupMain.ClientArea.Controls.Add(Me.pnlGroup)
        Me.pnlGroupMain.Location = New System.Drawing.Point(4, 89)
        Me.pnlGroupMain.Name = "pnlGroupMain"
        Me.pnlGroupMain.Size = New System.Drawing.Size(166, 487)
        Me.pnlGroupMain.TabIndex = 615
        '
        'pnlGroup
        '
        Me.pnlGroup.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.pnlGroup.AutoSize = True
        Me.pnlGroup.Location = New System.Drawing.Point(0, 0)
        Me.pnlGroup.Name = "pnlGroup"
        Me.pnlGroup.Size = New System.Drawing.Size(160, 487)
        Me.pnlGroup.TabIndex = 1
        '
        'ufmGroups
        '
        Me.ufmGroups.ContainerControl = Me.pnlGroup.ClientArea
        Me.ufmGroups.HorizontalGap = 0
        Me.ufmGroups.VerticalGap = 1
        '
        'ufmDishes
        '
        Me.ufmDishes.ContainerControl = Me.pnlDishes.ClientArea
        Me.ufmDishes.HorizontalGap = 1
        Me.ufmDishes.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.ufmDishes.VerticalAlignment = Infragistics.Win.Layout.DefaultableFlowLayoutAlignment.Near
        Me.ufmDishes.VerticalGap = 1
        '
        'cmdTypical
        '
        Me.cmdTypical.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.cmdTypical.Location = New System.Drawing.Point(82, 636)
        Me.cmdTypical.Name = "cmdTypical"
        Me.cmdTypical.Size = New System.Drawing.Size(120, 41)
        Me.cmdTypical.StyleSetName = "OEGroupButtonUpDown"
        Me.cmdTypical.TabIndex = 619
        Me.cmdTypical.Text = "Typical"
        Me.cmdTypical.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTypical.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTypical.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdCuisine
        '
        Me.cmdCuisine.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdCuisine.Location = New System.Drawing.Point(963, 636)
        Me.cmdCuisine.Name = "cmdCuisine"
        Me.cmdCuisine.Size = New System.Drawing.Size(120, 41)
        Me.cmdCuisine.StyleSetName = "OEGroupButtonUpDown"
        Me.cmdCuisine.TabIndex = 620
        Me.cmdCuisine.Text = "<cuisine>"
        Me.cmdCuisine.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdCuisine.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdCuisine.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblNumItems
        '
        Me.lblNumItems.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance100.BackColor = System.Drawing.Color.Transparent
        Appearance100.ForeColor = System.Drawing.Color.DarkSlateGray
        Appearance100.TextHAlignAsString = "Right"
        Me.lblNumItems.Appearance = Appearance100
        Me.lblNumItems.AutoSize = True
        Me.lblNumItems.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNumItems.Location = New System.Drawing.Point(804, 595)
        Me.lblNumItems.Name = "lblNumItems"
        Me.lblNumItems.Size = New System.Drawing.Size(55, 17)
        Me.lblNumItems.StyleSetName = "MiscLabel"
        Me.lblNumItems.TabIndex = 621
        Me.lblNumItems.Text = "Items: 0"
        Me.lblNumItems.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblToPayLbl
        '
        Me.lblToPayLbl.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance101.BackColor = System.Drawing.Color.Transparent
        Appearance101.ForeColor = System.Drawing.Color.DarkSlateGray
        Appearance101.TextHAlignAsString = "Right"
        Me.lblToPayLbl.Appearance = Appearance101
        Me.lblToPayLbl.AutoSize = True
        Me.lblToPayLbl.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblToPayLbl.Location = New System.Drawing.Point(914, 595)
        Me.lblToPayLbl.Name = "lblToPayLbl"
        Me.lblToPayLbl.Size = New System.Drawing.Size(59, 17)
        Me.lblToPayLbl.StyleSetName = "MiscLabel"
        Me.lblToPayLbl.TabIndex = 626
        Me.lblToPayLbl.Text = "TO PAY:"
        Me.lblToPayLbl.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblToPay
        '
        Me.lblToPay.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance102.BackColor = System.Drawing.Color.Transparent
        Appearance102.ForeColor = System.Drawing.Color.DarkSlateGray
        Appearance102.TextHAlignAsString = "Right"
        Me.lblToPay.Appearance = Appearance102
        Me.lblToPay.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblToPay.Location = New System.Drawing.Point(979, 590)
        Me.lblToPay.Name = "lblToPay"
        Me.lblToPay.Size = New System.Drawing.Size(74, 22)
        Me.lblToPay.StyleSetName = "MiscLabel"
        Me.lblToPay.TabIndex = 631
        Me.lblToPay.Text = "0.00"
        Me.lblToPay.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ufmTotals
        '
        Me.ufmTotals.ContainerControl = Me.upnlSummary.ClientArea
        Me.ufmTotals.HorizontalAlignment = Infragistics.Win.Layout.DefaultableFlowLayoutAlignment.Far
        Me.ufmTotals.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.ufmTotals.VerticalAlignment = Infragistics.Win.Layout.DefaultableFlowLayoutAlignment.Far
        Me.ufmTotals.VerticalGap = 1
        '
        'upnlSummary
        '
        Me.upnlSummary.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        '
        'upnlSummary.ClientArea
        '
        Me.upnlSummary.ClientArea.Controls.Add(Me.uplSSubtotal)
        Me.upnlSummary.ClientArea.Controls.Add(Me.uplSDrinks)
        Me.upnlSummary.ClientArea.Controls.Add(Me.uplSGDiscounts)
        Me.upnlSummary.ClientArea.Controls.Add(Me.uplSGCharges)
        Me.upnlSummary.ClientArea.Controls.Add(Me.uplSDiscounts)
        Me.upnlSummary.ClientArea.Controls.Add(Me.uplSCharges)
        Me.upnlSummary.Location = New System.Drawing.Point(772, 448)
        Me.upnlSummary.Name = "upnlSummary"
        Me.upnlSummary.Size = New System.Drawing.Size(283, 141)
        Me.upnlSummary.TabIndex = 639
        '
        'uplSSubtotal
        '
        '
        'uplSSubtotal.ClientArea
        '
        Me.uplSSubtotal.ClientArea.Controls.Add(Me.lblSubtotal)
        Me.uplSSubtotal.ClientArea.Controls.Add(Me.lblSubTotalLbl)
        Me.uplSSubtotal.Location = New System.Drawing.Point(5, 3)
        Me.uplSSubtotal.Name = "uplSSubtotal"
        Me.uplSSubtotal.Size = New System.Drawing.Size(274, 22)
        Me.uplSSubtotal.TabIndex = 0
        Me.uplSSubtotal.Visible = False
        '
        'lblSubtotal
        '
        Me.lblSubtotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance103.BackColor = System.Drawing.Color.Transparent
        Appearance103.ForeColor = System.Drawing.Color.DarkSlateGray
        Appearance103.TextHAlignAsString = "Right"
        Me.lblSubtotal.Appearance = Appearance103
        Me.lblSubtotal.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSubtotal.Location = New System.Drawing.Point(218, 3)
        Me.lblSubtotal.Name = "lblSubtotal"
        Me.lblSubtotal.Size = New System.Drawing.Size(53, 17)
        Me.lblSubtotal.StyleSetName = "MiscLabel"
        Me.lblSubtotal.TabIndex = 635
        Me.lblSubtotal.Text = "0.00"
        Me.lblSubtotal.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblSubTotalLbl
        '
        Me.lblSubTotalLbl.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance104.BackColor = System.Drawing.Color.Transparent
        Appearance104.ForeColor = System.Drawing.Color.DarkSlateGray
        Appearance104.TextHAlignAsString = "Right"
        Me.lblSubTotalLbl.Appearance = Appearance104
        Me.lblSubTotalLbl.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSubTotalLbl.Location = New System.Drawing.Point(7, 3)
        Me.lblSubTotalLbl.Name = "lblSubTotalLbl"
        Me.lblSubTotalLbl.Size = New System.Drawing.Size(189, 17)
        Me.lblSubTotalLbl.StyleSetName = "MiscLabel"
        Me.lblSubTotalLbl.TabIndex = 631
        Me.lblSubTotalLbl.Text = "Subtotal:"
        Me.lblSubTotalLbl.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'uplSDrinks
        '
        '
        'uplSDrinks.ClientArea
        '
        Me.uplSDrinks.ClientArea.Controls.Add(Me.lblDrinksOELbl)
        Me.uplSDrinks.ClientArea.Controls.Add(Me.lblDrinksOE)
        Me.uplSDrinks.Location = New System.Drawing.Point(5, 26)
        Me.uplSDrinks.Name = "uplSDrinks"
        Me.uplSDrinks.Size = New System.Drawing.Size(274, 22)
        Me.uplSDrinks.TabIndex = 637
        Me.uplSDrinks.Visible = False
        '
        'lblDrinksOELbl
        '
        Me.lblDrinksOELbl.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance105.BackColor = System.Drawing.Color.Transparent
        Appearance105.ForeColor = System.Drawing.Color.DarkSlateGray
        Appearance105.TextHAlignAsString = "Right"
        Me.lblDrinksOELbl.Appearance = Appearance105
        Me.lblDrinksOELbl.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDrinksOELbl.Location = New System.Drawing.Point(7, 3)
        Me.lblDrinksOELbl.Name = "lblDrinksOELbl"
        Me.lblDrinksOELbl.Size = New System.Drawing.Size(189, 17)
        Me.lblDrinksOELbl.StyleSetName = "MiscLabel"
        Me.lblDrinksOELbl.TabIndex = 634
        Me.lblDrinksOELbl.Text = "Drinks:"
        Me.lblDrinksOELbl.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblDrinksOE
        '
        Me.lblDrinksOE.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance106.BackColor = System.Drawing.Color.Transparent
        Appearance106.ForeColor = System.Drawing.Color.DarkSlateGray
        Appearance106.TextHAlignAsString = "Right"
        Me.lblDrinksOE.Appearance = Appearance106
        Me.lblDrinksOE.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDrinksOE.Location = New System.Drawing.Point(218, 3)
        Me.lblDrinksOE.Name = "lblDrinksOE"
        Me.lblDrinksOE.Size = New System.Drawing.Size(53, 17)
        Me.lblDrinksOE.StyleSetName = "MiscLabel"
        Me.lblDrinksOE.TabIndex = 638
        Me.lblDrinksOE.Text = "0.00"
        Me.lblDrinksOE.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'uplSGDiscounts
        '
        '
        'uplSGDiscounts.ClientArea
        '
        Me.uplSGDiscounts.ClientArea.Controls.Add(Me.lblGDiscounts)
        Me.uplSGDiscounts.ClientArea.Controls.Add(Me.lblGDiscountsLbl)
        Me.uplSGDiscounts.Location = New System.Drawing.Point(5, 49)
        Me.uplSGDiscounts.Name = "uplSGDiscounts"
        Me.uplSGDiscounts.Size = New System.Drawing.Size(274, 22)
        Me.uplSGDiscounts.TabIndex = 638
        Me.uplSGDiscounts.Visible = False
        '
        'lblGDiscounts
        '
        Me.lblGDiscounts.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance107.BackColor = System.Drawing.Color.Transparent
        Appearance107.ForeColor = System.Drawing.Color.DarkSlateGray
        Appearance107.TextHAlignAsString = "Right"
        Me.lblGDiscounts.Appearance = Appearance107
        Me.lblGDiscounts.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGDiscounts.Location = New System.Drawing.Point(218, 2)
        Me.lblGDiscounts.Name = "lblGDiscounts"
        Me.lblGDiscounts.Size = New System.Drawing.Size(53, 17)
        Me.lblGDiscounts.StyleSetName = "MiscLabel"
        Me.lblGDiscounts.TabIndex = 637
        Me.lblGDiscounts.Text = "0.00"
        Me.lblGDiscounts.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblGDiscountsLbl
        '
        Me.lblGDiscountsLbl.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance108.BackColor = System.Drawing.Color.Transparent
        Appearance108.ForeColor = System.Drawing.Color.DarkSlateGray
        Appearance108.TextHAlignAsString = "Right"
        Me.lblGDiscountsLbl.Appearance = Appearance108
        Me.lblGDiscountsLbl.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGDiscountsLbl.Location = New System.Drawing.Point(7, 2)
        Me.lblGDiscountsLbl.Name = "lblGDiscountsLbl"
        Me.lblGDiscountsLbl.Size = New System.Drawing.Size(189, 17)
        Me.lblGDiscountsLbl.StyleSetName = "MiscLabel"
        Me.lblGDiscountsLbl.TabIndex = 633
        Me.lblGDiscountsLbl.Text = "Discounts:"
        Me.lblGDiscountsLbl.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'uplSGCharges
        '
        '
        'uplSGCharges.ClientArea
        '
        Me.uplSGCharges.ClientArea.Controls.Add(Me.lblGCharges)
        Me.uplSGCharges.ClientArea.Controls.Add(Me.lblGChargesLbl)
        Me.uplSGCharges.Location = New System.Drawing.Point(5, 72)
        Me.uplSGCharges.Name = "uplSGCharges"
        Me.uplSGCharges.Size = New System.Drawing.Size(274, 22)
        Me.uplSGCharges.TabIndex = 639
        Me.uplSGCharges.Visible = False
        '
        'lblGCharges
        '
        Me.lblGCharges.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance109.BackColor = System.Drawing.Color.Transparent
        Appearance109.ForeColor = System.Drawing.Color.DarkSlateGray
        Appearance109.TextHAlignAsString = "Right"
        Me.lblGCharges.Appearance = Appearance109
        Me.lblGCharges.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGCharges.Location = New System.Drawing.Point(218, 2)
        Me.lblGCharges.Name = "lblGCharges"
        Me.lblGCharges.Size = New System.Drawing.Size(53, 17)
        Me.lblGCharges.StyleSetName = "MiscLabel"
        Me.lblGCharges.TabIndex = 637
        Me.lblGCharges.Text = "0.00"
        Me.lblGCharges.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblGChargesLbl
        '
        Me.lblGChargesLbl.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance110.BackColor = System.Drawing.Color.Transparent
        Appearance110.ForeColor = System.Drawing.Color.DarkSlateGray
        Appearance110.TextHAlignAsString = "Right"
        Me.lblGChargesLbl.Appearance = Appearance110
        Me.lblGChargesLbl.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGChargesLbl.Location = New System.Drawing.Point(7, 2)
        Me.lblGChargesLbl.Name = "lblGChargesLbl"
        Me.lblGChargesLbl.Size = New System.Drawing.Size(189, 17)
        Me.lblGChargesLbl.StyleSetName = "MiscLabel"
        Me.lblGChargesLbl.TabIndex = 633
        Me.lblGChargesLbl.Text = "Charges:"
        Me.lblGChargesLbl.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'uplSDiscounts
        '
        '
        'uplSDiscounts.ClientArea
        '
        Me.uplSDiscounts.ClientArea.Controls.Add(Me.lblPriceAdjDiscounts)
        Me.uplSDiscounts.ClientArea.Controls.Add(Me.lblPriceAdjDiscountsLbl)
        Me.uplSDiscounts.Location = New System.Drawing.Point(5, 95)
        Me.uplSDiscounts.Name = "uplSDiscounts"
        Me.uplSDiscounts.Size = New System.Drawing.Size(274, 22)
        Me.uplSDiscounts.TabIndex = 636
        Me.uplSDiscounts.Visible = False
        '
        'lblPriceAdjDiscounts
        '
        Me.lblPriceAdjDiscounts.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance111.BackColor = System.Drawing.Color.Transparent
        Appearance111.ForeColor = System.Drawing.Color.DarkSlateGray
        Appearance111.TextHAlignAsString = "Right"
        Me.lblPriceAdjDiscounts.Appearance = Appearance111
        Me.lblPriceAdjDiscounts.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPriceAdjDiscounts.Location = New System.Drawing.Point(218, 3)
        Me.lblPriceAdjDiscounts.Name = "lblPriceAdjDiscounts"
        Me.lblPriceAdjDiscounts.Size = New System.Drawing.Size(53, 17)
        Me.lblPriceAdjDiscounts.StyleSetName = "MiscLabel"
        Me.lblPriceAdjDiscounts.TabIndex = 636
        Me.lblPriceAdjDiscounts.Text = "0.00"
        Me.lblPriceAdjDiscounts.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblPriceAdjDiscountsLbl
        '
        Me.lblPriceAdjDiscountsLbl.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance112.BackColor = System.Drawing.Color.Transparent
        Appearance112.ForeColor = System.Drawing.Color.DarkSlateGray
        Appearance112.TextHAlignAsString = "Right"
        Me.lblPriceAdjDiscountsLbl.Appearance = Appearance112
        Me.lblPriceAdjDiscountsLbl.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPriceAdjDiscountsLbl.Location = New System.Drawing.Point(7, 3)
        Me.lblPriceAdjDiscountsLbl.Name = "lblPriceAdjDiscountsLbl"
        Me.lblPriceAdjDiscountsLbl.Size = New System.Drawing.Size(189, 17)
        Me.lblPriceAdjDiscountsLbl.StyleSetName = "MiscLabel"
        Me.lblPriceAdjDiscountsLbl.TabIndex = 632
        Me.lblPriceAdjDiscountsLbl.Text = "PriceAdjDiscounts:"
        Me.lblPriceAdjDiscountsLbl.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'uplSCharges
        '
        '
        'uplSCharges.ClientArea
        '
        Me.uplSCharges.ClientArea.Controls.Add(Me.lblPriceAdjCharges)
        Me.uplSCharges.ClientArea.Controls.Add(Me.lblPriceAdjChargesLbl)
        Me.uplSCharges.Location = New System.Drawing.Point(5, 118)
        Me.uplSCharges.Name = "uplSCharges"
        Me.uplSCharges.Size = New System.Drawing.Size(274, 22)
        Me.uplSCharges.TabIndex = 636
        Me.uplSCharges.Visible = False
        '
        'lblPriceAdjCharges
        '
        Me.lblPriceAdjCharges.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance113.BackColor = System.Drawing.Color.Transparent
        Appearance113.ForeColor = System.Drawing.Color.DarkSlateGray
        Appearance113.TextHAlignAsString = "Right"
        Me.lblPriceAdjCharges.Appearance = Appearance113
        Me.lblPriceAdjCharges.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPriceAdjCharges.Location = New System.Drawing.Point(218, 2)
        Me.lblPriceAdjCharges.Name = "lblPriceAdjCharges"
        Me.lblPriceAdjCharges.Size = New System.Drawing.Size(53, 17)
        Me.lblPriceAdjCharges.StyleSetName = "MiscLabel"
        Me.lblPriceAdjCharges.TabIndex = 637
        Me.lblPriceAdjCharges.Text = "0.00"
        Me.lblPriceAdjCharges.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblPriceAdjChargesLbl
        '
        Me.lblPriceAdjChargesLbl.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance114.BackColor = System.Drawing.Color.Transparent
        Appearance114.ForeColor = System.Drawing.Color.DarkSlateGray
        Appearance114.TextHAlignAsString = "Right"
        Me.lblPriceAdjChargesLbl.Appearance = Appearance114
        Me.lblPriceAdjChargesLbl.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPriceAdjChargesLbl.Location = New System.Drawing.Point(7, 2)
        Me.lblPriceAdjChargesLbl.Name = "lblPriceAdjChargesLbl"
        Me.lblPriceAdjChargesLbl.Size = New System.Drawing.Size(189, 17)
        Me.lblPriceAdjChargesLbl.StyleSetName = "MiscLabel"
        Me.lblPriceAdjChargesLbl.TabIndex = 633
        Me.lblPriceAdjChargesLbl.Text = "PriceAdjCharges:"
        Me.lblPriceAdjChargesLbl.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'frmOrderEntry
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(253, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(253, Byte), Integer))
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(1168, 684)
        Me.ControlBox = False
        Me.Controls.Add(Me.upnlSummary)
        Me.Controls.Add(Me.lblToPay)
        Me.Controls.Add(Me.lblToPayLbl)
        Me.Controls.Add(Me.lblNumItems)
        Me.Controls.Add(Me.upnlChoices)
        Me.Controls.Add(Me.cmdCuisine)
        Me.Controls.Add(Me.cmdTypical)
        Me.Controls.Add(Me.pnlDishesMain)
        Me.Controls.Add(Me.cmdGroupDown)
        Me.Controls.Add(Me.cmdGroupUp)
        Me.Controls.Add(Me.pnlGroupMain)
        Me.Controls.Add(Me.txtKBCode)
        Me.Controls.Add(Me.ugdOrderGrid)
        Me.Controls.Add(Me.cmdSetMeals)
        Me.Controls.Add(Me.cmdAddDrink)
        Me.Controls.Add(Me.cmdManualEntry)
        Me.Controls.Add(Me.cmdLastItemQty)
        Me.Controls.Add(Me.cmdEditDish)
        Me.Controls.Add(Me.cmdDishClearAll)
        Me.Controls.Add(Me.cmdDeleteDish)
        Me.Controls.Add(Me.cmdDecDish)
        Me.Controls.Add(Me.cmdIncDish)
        Me.Controls.Add(Me.cmdOGDown)
        Me.Controls.Add(Me.cmdOGUp)
        Me.Controls.Add(Me.cmdPrintLabels)
        Me.Controls.Add(Me.cmdDishesBack)
        Me.Controls.Add(Me.cmdShowKeyboard)
        Me.Controls.Add(Me.cmdDishesNext)
        Me.Controls.Add(Me.cmdOEDiscounts)
        Me.Controls.Add(Me.cmdOEHome)
        Me.Controls.Add(Me.cmdOEBack)
        Me.Controls.Add(Me.cmdPrevOrder)
        Me.Controls.Add(Me.cmdOENext)
        Me.Controls.Add(Me.lblStatusBarDiv)
        Me.Controls.Add(Me.pnlHeader)
        Me.DoubleBuffered = True
        Me.MinimumSize = New System.Drawing.Size(1000, 700)
        Me.Name = "frmOrderEntry"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.pnlHeader.ClientArea.ResumeLayout(False)
        Me.pnlHeader.ResumeLayout(False)
        Me.upnlChoices.ClientArea.ResumeLayout(False)
        Me.upnlChoices.ResumeLayout(False)
        CType(Me.EZMenuDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ugdOrderGrid, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.udsOrder, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GroupsBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DishBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlDishesMain.ClientArea.ResumeLayout(False)
        Me.pnlDishesMain.ClientArea.PerformLayout()
        Me.pnlDishesMain.ResumeLayout(False)
        Me.pnlDishes.ResumeLayout(False)
        Me.pnlDishes.PerformLayout()
        Me.pnlGroupMain.ClientArea.ResumeLayout(False)
        Me.pnlGroupMain.ClientArea.PerformLayout()
        Me.pnlGroupMain.ResumeLayout(False)
        Me.pnlGroup.ResumeLayout(False)
        Me.pnlGroup.PerformLayout()
        CType(Me.ufmGroups, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ufmDishes, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ufmTotals, System.ComponentModel.ISupportInitialize).EndInit()
        Me.upnlSummary.ClientArea.ResumeLayout(False)
        Me.upnlSummary.ResumeLayout(False)
        Me.uplSSubtotal.ClientArea.ResumeLayout(False)
        Me.uplSSubtotal.ResumeLayout(False)
        Me.uplSDrinks.ClientArea.ResumeLayout(False)
        Me.uplSDrinks.ResumeLayout(False)
        Me.uplSGDiscounts.ClientArea.ResumeLayout(False)
        Me.uplSGDiscounts.ResumeLayout(False)
        Me.uplSGCharges.ClientArea.ResumeLayout(False)
        Me.uplSGCharges.ResumeLayout(False)
        Me.uplSDiscounts.ClientArea.ResumeLayout(False)
        Me.uplSDiscounts.ResumeLayout(False)
        Me.uplSCharges.ClientArea.ResumeLayout(False)
        Me.uplSCharges.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents pnlHeader As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents lblHeader As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblStatusBarDiv As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents cmdPrintLabels As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDishesBack As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdShowKeyboard As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDishesNext As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdOEDiscounts As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdOEHome As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdOEBack As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdPrevOrder As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdOENext As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdSetMeals As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdAddDrink As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdManualEntry As Infragistics.Win.Misc.UltraButton
    Private WithEvents EZMenuDataSet As EZMenu.EZMenuDataSet
    Friend WithEvents cmdLastItemQty As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdEditDish As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDishClearAll As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDeleteDish As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDecDish As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdIncDish As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdOGDown As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdOGUp As Infragistics.Win.Misc.UltraButton
    Friend WithEvents upnlChoices As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents cmdChoice7 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdChoice6 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdChoice5 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdChoice4 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdChoice3 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdChoice2 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdChoice1 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents txtKBCode As TextBox
    Friend WithEvents ugdOrderGrid As Infragistics.Win.UltraWinGrid.UltraGrid
    Friend WithEvents udsOrder As Infragistics.Win.UltraWinDataSource.UltraDataSource
    Friend WithEvents GroupsBindingSource As BindingSource
    Friend WithEvents GroupsTableAdapter As EZMenuDataSetTableAdapters.GroupsTableAdapter
    Friend WithEvents TableAdapterManager As EZMenuDataSetTableAdapters.TableAdapterManager
    Friend WithEvents DishBindingSource As BindingSource
    Friend WithEvents DishTableAdapter As EZMenuDataSetTableAdapters.DishTableAdapter
    Friend WithEvents pnlDishesMain As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents pnlDishes As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents cmdGroupDown As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdGroupUp As Infragistics.Win.Misc.UltraButton
    Friend WithEvents pnlGroupMain As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents pnlGroup As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents ufmGroups As Infragistics.Win.Misc.UltraFlowLayoutManager
    Friend WithEvents ufmDishes As Infragistics.Win.Misc.UltraFlowLayoutManager
    Friend WithEvents cmdTypical As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdCuisine As Infragistics.Win.Misc.UltraButton
    Friend WithEvents lblNumItems As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblToPayLbl As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblToPay As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents ufmTotals As Infragistics.Win.Misc.UltraFlowLayoutManager
    Friend WithEvents upnlSummary As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents uplSSubtotal As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents lblSubtotal As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblSubTotalLbl As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents uplSDrinks As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents uplSDiscounts As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents lblPriceAdjDiscounts As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblPriceAdjDiscountsLbl As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents uplSCharges As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents lblPriceAdjCharges As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblPriceAdjChargesLbl As Infragistics.Win.Misc.UltraLabel
    Public WithEvents lblDrinksOELbl As Infragistics.Win.Misc.UltraLabel
    Public WithEvents lblDrinksOE As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents uplSGCharges As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents lblGCharges As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblGChargesLbl As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents uplSGDiscounts As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents lblGDiscounts As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblGDiscountsLbl As Infragistics.Win.Misc.UltraLabel
End Class
