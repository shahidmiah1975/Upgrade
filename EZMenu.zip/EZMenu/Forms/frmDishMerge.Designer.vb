﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDishMerge
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim Appearance19 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmDishMerge))
        Dim Appearance20 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance21 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance22 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance23 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance24 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance25 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance26 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance27 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance28 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance29 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance30 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance13 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance31 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance32 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance33 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance34 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance35 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Me.cmdClose = New Infragistics.Win.Misc.UltraButton()
        Me.cmdKBName = New Infragistics.Win.Misc.UltraButton()
        Me.cmdAddToList = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDeleteName = New Infragistics.Win.Misc.UltraButton()
        Me.lstConcise = New Infragistics.Win.UltraWinListView.UltraListView()
        Me.cmdDeleteConcise = New Infragistics.Win.Misc.UltraButton()
        Me.cmbConcise = New Infragistics.Win.UltraWinEditors.UltraComboEditor()
        Me.lblDCHeader = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraPanel1 = New Infragistics.Win.Misc.UltraPanel()
        CType(Me.lstConcise, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbConcise, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.UltraPanel1.ClientArea.SuspendLayout()
        Me.UltraPanel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'cmdClose
        '
        Me.cmdClose.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance19.BackColor = System.Drawing.Color.Transparent
        Appearance19.BackColor2 = System.Drawing.Color.Transparent
        Appearance19.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance19.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance19.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance19.ForeColor = System.Drawing.Color.Black
        Appearance19.Image = CType(resources.GetObject("Appearance19.Image"), Object)
        Appearance19.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance19.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance19.TextVAlignAsString = "Bottom"
        Me.cmdClose.Appearance = Appearance19
        Me.cmdClose.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance20.BackColor = System.Drawing.Color.DarkOrange
        Appearance20.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance20.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance20.ForeColor = System.Drawing.Color.Black
        Me.cmdClose.HotTrackAppearance = Appearance20
        Me.cmdClose.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdClose.Location = New System.Drawing.Point(313, 377)
        Me.cmdClose.Name = "cmdClose"
        Appearance21.BackColor = System.Drawing.Color.OrangeRed
        Appearance21.BackColor2 = System.Drawing.Color.Tomato
        Appearance21.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdClose.PressedAppearance = Appearance21
        Me.cmdClose.ShowFocusRect = False
        Me.cmdClose.ShowOutline = False
        Me.cmdClose.Size = New System.Drawing.Size(58, 41)
        Me.cmdClose.StyleSetName = "StatusBar"
        Me.cmdClose.TabIndex = 537
        Me.cmdClose.Tag = "Back"
        Me.cmdClose.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdClose.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdClose.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdKBName
        '
        Appearance22.BackColor = System.Drawing.Color.Transparent
        Appearance22.BackColor2 = System.Drawing.Color.Transparent
        Appearance22.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance22.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance22.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance22.ForeColor = System.Drawing.Color.Black
        Appearance22.Image = CType(resources.GetObject("Appearance22.Image"), Object)
        Appearance22.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance22.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance22.TextVAlignAsString = "Bottom"
        Me.cmdKBName.Appearance = Appearance22
        Me.cmdKBName.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance23.BackColor = System.Drawing.Color.DarkOrange
        Appearance23.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance23.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance23.ForeColor = System.Drawing.Color.Black
        Me.cmdKBName.HotTrackAppearance = Appearance23
        Me.cmdKBName.ImageSize = New System.Drawing.Size(30, 18)
        Me.cmdKBName.Location = New System.Drawing.Point(253, 94)
        Me.cmdKBName.Name = "cmdKBName"
        Appearance24.BackColor = System.Drawing.Color.OrangeRed
        Appearance24.BackColor2 = System.Drawing.Color.Tomato
        Appearance24.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdKBName.PressedAppearance = Appearance24
        Me.cmdKBName.ShowFocusRect = False
        Me.cmdKBName.ShowOutline = False
        Me.cmdKBName.Size = New System.Drawing.Size(54, 34)
        Me.cmdKBName.StyleSetName = "StatusBar"
        Me.cmdKBName.TabIndex = 667
        Me.cmdKBName.Tag = "Back"
        Me.cmdKBName.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBName.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBName.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdAddToList
        '
        Appearance25.BackColor = System.Drawing.Color.Transparent
        Appearance25.BackColor2 = System.Drawing.Color.Transparent
        Appearance25.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance25.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance25.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance25.ForeColor = System.Drawing.Color.Black
        Appearance25.Image = CType(resources.GetObject("Appearance25.Image"), Object)
        Appearance25.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance25.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance25.TextVAlignAsString = "Bottom"
        Me.cmdAddToList.Appearance = Appearance25
        Me.cmdAddToList.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance26.BackColor = System.Drawing.Color.DarkOrange
        Appearance26.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance26.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance26.ForeColor = System.Drawing.Color.Black
        Me.cmdAddToList.HotTrackAppearance = Appearance26
        Me.cmdAddToList.ImageSize = New System.Drawing.Size(24, 24)
        Me.cmdAddToList.Location = New System.Drawing.Point(253, 134)
        Me.cmdAddToList.Name = "cmdAddToList"
        Appearance27.BackColor = System.Drawing.Color.OrangeRed
        Appearance27.BackColor2 = System.Drawing.Color.Tomato
        Appearance27.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdAddToList.PressedAppearance = Appearance27
        Me.cmdAddToList.ShowFocusRect = False
        Me.cmdAddToList.ShowOutline = False
        Me.cmdAddToList.Size = New System.Drawing.Size(54, 34)
        Me.cmdAddToList.StyleSetName = "StatusBar"
        Me.cmdAddToList.TabIndex = 669
        Me.cmdAddToList.Tag = "Back"
        Me.cmdAddToList.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdAddToList.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdAddToList.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDeleteName
        '
        Appearance28.BackColor = System.Drawing.Color.Transparent
        Appearance28.BackColor2 = System.Drawing.Color.Transparent
        Appearance28.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance28.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance28.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance28.ForeColor = System.Drawing.Color.Black
        Appearance28.Image = CType(resources.GetObject("Appearance28.Image"), Object)
        Appearance28.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance28.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance28.TextVAlignAsString = "Bottom"
        Me.cmdDeleteName.Appearance = Appearance28
        Me.cmdDeleteName.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance29.BackColor = System.Drawing.Color.DarkOrange
        Appearance29.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance29.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance29.ForeColor = System.Drawing.Color.Black
        Me.cmdDeleteName.HotTrackAppearance = Appearance29
        Me.cmdDeleteName.ImageSize = New System.Drawing.Size(30, 24)
        Me.cmdDeleteName.Location = New System.Drawing.Point(313, 94)
        Me.cmdDeleteName.Name = "cmdDeleteName"
        Appearance30.BackColor = System.Drawing.Color.OrangeRed
        Appearance30.BackColor2 = System.Drawing.Color.Tomato
        Appearance30.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdDeleteName.PressedAppearance = Appearance30
        Me.cmdDeleteName.ShowFocusRect = False
        Me.cmdDeleteName.ShowOutline = False
        Me.cmdDeleteName.Size = New System.Drawing.Size(54, 34)
        Me.cmdDeleteName.StyleSetName = "StatusBar"
        Me.cmdDeleteName.TabIndex = 670
        Me.cmdDeleteName.Tag = "Back"
        Me.cmdDeleteName.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDeleteName.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDeleteName.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lstConcise
        '
        Appearance13.BorderColor = System.Drawing.Color.Silver
        Me.lstConcise.Appearance = Appearance13
        Me.lstConcise.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Me.lstConcise.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstConcise.ItemSettings.AllowEdit = Infragistics.Win.DefaultableBoolean.[False]
        Me.lstConcise.ItemSettings.HideSelection = False
        Me.lstConcise.ItemSettings.HotTracking = True
        Me.lstConcise.Location = New System.Drawing.Point(37, 128)
        Me.lstConcise.Name = "lstConcise"
        Me.lstConcise.ShowGroups = False
        Me.lstConcise.Size = New System.Drawing.Size(210, 244)
        Me.lstConcise.TabIndex = 674
        Me.lstConcise.UseAppStyling = False
        Me.lstConcise.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        Me.lstConcise.View = Infragistics.Win.UltraWinListView.UltraListViewStyle.List
        Me.lstConcise.ViewSettingsList.ImageSize = New System.Drawing.Size(0, 0)
        Me.lstConcise.ViewSettingsList.MultiColumn = False
        '
        'cmdDeleteConcise
        '
        Appearance31.BackColor = System.Drawing.Color.Transparent
        Appearance31.BackColor2 = System.Drawing.Color.Transparent
        Appearance31.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance31.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance31.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance31.ForeColor = System.Drawing.Color.Black
        Appearance31.Image = CType(resources.GetObject("Appearance31.Image"), Object)
        Appearance31.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance31.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance31.TextVAlignAsString = "Bottom"
        Me.cmdDeleteConcise.Appearance = Appearance31
        Me.cmdDeleteConcise.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance32.BackColor = System.Drawing.Color.DarkOrange
        Appearance32.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance32.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance32.ForeColor = System.Drawing.Color.Black
        Me.cmdDeleteConcise.HotTrackAppearance = Appearance32
        Me.cmdDeleteConcise.ImageSize = New System.Drawing.Size(20, 20)
        Me.cmdDeleteConcise.Location = New System.Drawing.Point(253, 241)
        Me.cmdDeleteConcise.Name = "cmdDeleteConcise"
        Appearance33.BackColor = System.Drawing.Color.OrangeRed
        Appearance33.BackColor2 = System.Drawing.Color.Tomato
        Appearance33.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdDeleteConcise.PressedAppearance = Appearance33
        Me.cmdDeleteConcise.ShowFocusRect = False
        Me.cmdDeleteConcise.ShowOutline = False
        Me.cmdDeleteConcise.Size = New System.Drawing.Size(54, 34)
        Me.cmdDeleteConcise.StyleSetName = "StatusBar"
        Me.cmdDeleteConcise.TabIndex = 675
        Me.cmdDeleteConcise.Tag = "Back"
        Me.cmdDeleteConcise.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDeleteConcise.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDeleteConcise.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmbConcise
        '
        Me.cmbConcise.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbConcise.Location = New System.Drawing.Point(37, 96)
        Me.cmbConcise.Name = "cmbConcise"
        Me.cmbConcise.Size = New System.Drawing.Size(210, 26)
        Me.cmbConcise.TabIndex = 676
        Me.cmbConcise.UseAppStyling = False
        '
        'lblDCHeader
        '
        Me.lblDCHeader.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance34.ForeColor = System.Drawing.Color.DimGray
        Appearance34.TextHAlignAsString = "Center"
        Me.lblDCHeader.Appearance = Appearance34
        Me.lblDCHeader.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDCHeader.Location = New System.Drawing.Point(2, 29)
        Me.lblDCHeader.Name = "lblDCHeader"
        Me.lblDCHeader.Size = New System.Drawing.Size(385, 23)
        Me.lblDCHeader.TabIndex = 677
        Me.lblDCHeader.Text = "<header>"
        '
        'UltraPanel1
        '
        Me.UltraPanel1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance35.BorderColor = System.Drawing.Color.Silver
        Me.UltraPanel1.Appearance = Appearance35
        Me.UltraPanel1.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        '
        'UltraPanel1.ClientArea
        '
        Me.UltraPanel1.ClientArea.Controls.Add(Me.lblDCHeader)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.cmdClose)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.cmbConcise)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.cmdDeleteConcise)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.cmdKBName)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.lstConcise)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.cmdAddToList)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.cmdDeleteName)
        Me.UltraPanel1.Location = New System.Drawing.Point(12, 12)
        Me.UltraPanel1.Name = "UltraPanel1"
        Me.UltraPanel1.Size = New System.Drawing.Size(391, 439)
        Me.UltraPanel1.TabIndex = 678
        '
        'frmDishMerge
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(415, 463)
        Me.ControlBox = False
        Me.Controls.Add(Me.UltraPanel1)
        Me.MaximumSize = New System.Drawing.Size(431, 479)
        Me.MinimumSize = New System.Drawing.Size(431, 479)
        Me.Name = "frmDishMerge"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        CType(Me.lstConcise, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbConcise, System.ComponentModel.ISupportInitialize).EndInit()
        Me.UltraPanel1.ClientArea.ResumeLayout(False)
        Me.UltraPanel1.ClientArea.PerformLayout()
        Me.UltraPanel1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents cmdClose As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdKBName As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdAddToList As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDeleteName As Infragistics.Win.Misc.UltraButton
    Friend WithEvents lstConcise As Infragistics.Win.UltraWinListView.UltraListView
    Friend WithEvents cmdDeleteConcise As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmbConcise As Infragistics.Win.UltraWinEditors.UltraComboEditor
    Friend WithEvents lblDCHeader As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraPanel1 As Infragistics.Win.Misc.UltraPanel
End Class
