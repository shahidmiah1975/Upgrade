﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmOpener
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim Appearance1 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance2 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance3 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance4 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance5 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance6 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance7 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance8 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmOpener))
        Dim Appearance9 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance10 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance11 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance12 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance13 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance14 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance15 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance16 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance17 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance18 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance19 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance20 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance21 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance22 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance23 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance24 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance25 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance26 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance27 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance28 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance29 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance30 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance31 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance32 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.tmrCallPhone = New System.Windows.Forms.Timer(Me.components)
        Me.lblDateTime = New Infragistics.Win.Misc.UltraLabel()
        Me.tmrUpdateClock = New System.Windows.Forms.Timer(Me.components)
        Me.lblBizname = New Infragistics.Win.Misc.UltraLabel()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.cmdMinimise = New Infragistics.Win.Misc.UltraButton()
        Me.pnlHeader = New Infragistics.Win.Misc.UltraPanel()
        Me.lblHeader = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel1 = New Infragistics.Win.Misc.UltraLabel()
        Me.cmdShowCID = New Infragistics.Win.Misc.UltraButton()
        Me.lblCallerIDBox0 = New System.Windows.Forms.Label()
        Me.lblCallerIDBox1 = New System.Windows.Forms.Label()
        Me.lblCallerIDBox2 = New System.Windows.Forms.Label()
        Me.imgMobile = New System.Windows.Forms.PictureBox()
        Me.cmdCIDRecall = New Infragistics.Win.Misc.UltraButton()
        Me.cmdCIDAccept = New Infragistics.Win.Misc.UltraButton()
        Me.cmdCIDHide = New Infragistics.Win.Misc.UltraButton()
        Me.cmdCIDLog = New Infragistics.Win.Misc.UltraButton()
        Me.pnlCID = New System.Windows.Forms.Panel()
        Me.UltraButton1 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdManager = New Infragistics.Win.Misc.UltraButton()
        Me.cmdQuit = New Infragistics.Win.Misc.UltraButton()
        Me.cmdBookingsToday = New Infragistics.Win.Misc.UltraButton()
        Me.cmdOrders = New Infragistics.Win.Misc.UltraButton()
        Me.cmdBookings = New Infragistics.Win.Misc.UltraButton()
        Me.cmdOnline = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDelivery = New Infragistics.Win.Misc.UltraButton()
        Me.cmdPickup = New Infragistics.Win.Misc.UltraButton()
        Me.cmdTables = New Infragistics.Win.Misc.UltraButton()
        Me.pnlHeader.ClientArea.SuspendLayout()
        Me.pnlHeader.SuspendLayout()
        CType(Me.imgMobile, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlCID.SuspendLayout()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(12, 48)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(58, 47)
        Me.Button1.TabIndex = 98
        Me.Button1.Text = "cid"
        Me.Button1.UseVisualStyleBackColor = True
        Me.Button1.Visible = False
        '
        'tmrCallPhone
        '
        Me.tmrCallPhone.Interval = 500
        '
        'lblDateTime
        '
        Me.lblDateTime.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance1.BackColor = System.Drawing.Color.Transparent
        Appearance1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(120, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance1.TextHAlignAsString = "Right"
        Me.lblDateTime.Appearance = Appearance1
        Me.lblDateTime.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDateTime.Location = New System.Drawing.Point(885, 23)
        Me.lblDateTime.Name = "lblDateTime"
        Me.lblDateTime.Size = New System.Drawing.Size(250, 17)
        Me.lblDateTime.StyleSetName = "Reservation"
        Me.lblDateTime.TabIndex = 124
        Me.lblDateTime.Text = "<datetime>"
        Me.lblDateTime.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'tmrUpdateClock
        '
        Me.tmrUpdateClock.Enabled = True
        Me.tmrUpdateClock.Interval = 2000
        '
        'lblBizname
        '
        Me.lblBizname.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance2.BackColor = System.Drawing.Color.Transparent
        Appearance2.ForeColor = System.Drawing.Color.DimGray
        Appearance2.TextHAlignAsString = "Center"
        Me.lblBizname.Appearance = Appearance2
        Me.lblBizname.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBizname.Location = New System.Drawing.Point(294, 753)
        Me.lblBizname.Name = "lblBizname"
        Me.lblBizname.Size = New System.Drawing.Size(597, 19)
        Me.lblBizname.StyleSetName = "StatusBar"
        Me.lblBizname.TabIndex = 456
        Me.lblBizname.Text = "<BizName>"
        Me.lblBizname.UseAppStyling = False
        Me.lblBizname.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.lblBizname.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(76, 48)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(58, 47)
        Me.Button2.TabIndex = 123
        Me.Button2.Text = "gn"
        Me.Button2.UseVisualStyleBackColor = True
        Me.Button2.Visible = False
        '
        'cmdMinimise
        '
        Me.cmdMinimise.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance3.BackColor = System.Drawing.Color.Gainsboro
        Appearance3.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance3.BorderColor = System.Drawing.Color.Gainsboro
        Appearance3.ForeColor = System.Drawing.Color.White
        Appearance3.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance3.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance3.TextVAlignAsString = "Middle"
        Me.cmdMinimise.Appearance = Appearance3
        Me.cmdMinimise.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance4.BackColor = System.Drawing.Color.DarkOrange
        Appearance4.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance4.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance4.ForeColor = System.Drawing.Color.Black
        Me.cmdMinimise.HotTrackAppearance = Appearance4
        Me.cmdMinimise.ImageSize = New System.Drawing.Size(40, 40)
        Me.cmdMinimise.Location = New System.Drawing.Point(1143, 3)
        Me.cmdMinimise.Name = "cmdMinimise"
        Appearance5.BackColor = System.Drawing.Color.OrangeRed
        Appearance5.BackColor2 = System.Drawing.Color.Tomato
        Appearance5.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdMinimise.PressedAppearance = Appearance5
        Me.cmdMinimise.ShowFocusRect = False
        Me.cmdMinimise.ShowOutline = False
        Me.cmdMinimise.Size = New System.Drawing.Size(31, 31)
        Me.cmdMinimise.StyleSetName = "MinimiseButton"
        Me.cmdMinimise.TabIndex = 459
        Me.cmdMinimise.Tag = "Up"
        Me.cmdMinimise.Text = "__"
        Me.cmdMinimise.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdMinimise.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdMinimise.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'pnlHeader
        '
        Me.pnlHeader.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance6.BackColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        Me.pnlHeader.Appearance = Appearance6
        '
        'pnlHeader.ClientArea
        '
        Me.pnlHeader.ClientArea.Controls.Add(Me.lblHeader)
        Me.pnlHeader.ClientArea.Controls.Add(Me.cmdMinimise)
        Me.pnlHeader.ClientArea.Controls.Add(Me.lblDateTime)
        Me.pnlHeader.Location = New System.Drawing.Point(0, 0)
        Me.pnlHeader.Name = "pnlHeader"
        Me.pnlHeader.Size = New System.Drawing.Size(1186, 42)
        Me.pnlHeader.StyleSetName = "Reservation"
        Me.pnlHeader.TabIndex = 548
        Me.pnlHeader.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblHeader
        '
        Appearance7.BackColor = System.Drawing.Color.Transparent
        Appearance7.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(120, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance7.TextVAlignAsString = "Middle"
        Me.lblHeader.Appearance = Appearance7
        Me.lblHeader.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHeader.Location = New System.Drawing.Point(3, 4)
        Me.lblHeader.Name = "lblHeader"
        Me.lblHeader.Size = New System.Drawing.Size(240, 35)
        Me.lblHeader.StyleSetName = "Reservation"
        Me.lblHeader.TabIndex = 460
        Me.lblHeader.Text = "ezMENU"
        Me.lblHeader.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraLabel1
        '
        Me.UltraLabel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance8.BorderColor = System.Drawing.Color.Silver
        Me.UltraLabel1.Appearance = Appearance8
        Me.UltraLabel1.BorderStyleInner = Infragistics.Win.UIElementBorderStyle.Solid
        Me.UltraLabel1.Location = New System.Drawing.Point(-1, 727)
        Me.UltraLabel1.Name = "UltraLabel1"
        Me.UltraLabel1.Size = New System.Drawing.Size(1187, 1)
        Me.UltraLabel1.TabIndex = 549
        '
        'cmdShowCID
        '
        Me.cmdShowCID.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.cmdShowCID.AutoSize = True
        Me.cmdShowCID.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdShowCID.ImageSize = New System.Drawing.Size(42, 42)
        Me.cmdShowCID.Location = New System.Drawing.Point(3, 732)
        Me.cmdShowCID.Name = "cmdShowCID"
        Me.cmdShowCID.Padding = New System.Drawing.Size(10, 0)
        Me.cmdShowCID.ShowFocusRect = False
        Me.cmdShowCID.ShowOutline = False
        Me.cmdShowCID.Size = New System.Drawing.Size(22, 2)
        Me.cmdShowCID.StyleSetName = "StatusBar"
        Me.cmdShowCID.TabIndex = 553
        Me.cmdShowCID.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdShowCID.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblCallerIDBox0
        '
        Me.lblCallerIDBox0.AutoSize = True
        Me.lblCallerIDBox0.BackColor = System.Drawing.Color.Transparent
        Me.lblCallerIDBox0.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCallerIDBox0.Location = New System.Drawing.Point(2, 4)
        Me.lblCallerIDBox0.Name = "lblCallerIDBox0"
        Me.lblCallerIDBox0.Size = New System.Drawing.Size(86, 14)
        Me.lblCallerIDBox0.TabIndex = 10
        Me.lblCallerIDBox0.Text = "INCOMING CALL"
        '
        'lblCallerIDBox1
        '
        Me.lblCallerIDBox1.AutoSize = True
        Me.lblCallerIDBox1.BackColor = System.Drawing.Color.Transparent
        Me.lblCallerIDBox1.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCallerIDBox1.Location = New System.Drawing.Point(46, 28)
        Me.lblCallerIDBox1.Name = "lblCallerIDBox1"
        Me.lblCallerIDBox1.Size = New System.Drawing.Size(144, 16)
        Me.lblCallerIDBox1.TabIndex = 11
        Me.lblCallerIDBox1.Text = "NO CUSTOMER NAME"
        '
        'lblCallerIDBox2
        '
        Me.lblCallerIDBox2.BackColor = System.Drawing.Color.Transparent
        Me.lblCallerIDBox2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCallerIDBox2.Location = New System.Drawing.Point(46, 52)
        Me.lblCallerIDBox2.Name = "lblCallerIDBox2"
        Me.lblCallerIDBox2.Size = New System.Drawing.Size(195, 111)
        Me.lblCallerIDBox2.TabIndex = 12
        Me.lblCallerIDBox2.Text = "ADDRESS UNAVAILABLE"
        '
        'imgMobile
        '
        Me.imgMobile.BackColor = System.Drawing.Color.Transparent
        Me.imgMobile.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.imgMobile.Image = CType(resources.GetObject("imgMobile.Image"), System.Drawing.Image)
        Me.imgMobile.Location = New System.Drawing.Point(222, 41)
        Me.imgMobile.Name = "imgMobile"
        Me.imgMobile.Size = New System.Drawing.Size(50, 99)
        Me.imgMobile.TabIndex = 8
        Me.imgMobile.TabStop = False
        Me.imgMobile.Tag = "0"
        '
        'cmdCIDRecall
        '
        Appearance9.BackColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(30, Byte), Integer))
        Appearance9.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(120, Byte), Integer), CType(CType(36, Byte), Integer))
        Appearance9.BackGradientStyle = Infragistics.Win.GradientStyle.VerticalBump
        Appearance9.BorderColor = System.Drawing.Color.DarkGreen
        Appearance9.BorderColor2 = System.Drawing.Color.Brown
        Appearance9.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance9.ForeColor = System.Drawing.Color.White
        Me.cmdCIDRecall.Appearance = Appearance9
        Me.cmdCIDRecall.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance10.BackColor = System.Drawing.Color.PowderBlue
        Appearance10.BackColor2 = System.Drawing.Color.Aqua
        Appearance10.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance10.ForeColor = System.Drawing.Color.Black
        Me.cmdCIDRecall.HotTrackAppearance = Appearance10
        Me.cmdCIDRecall.Location = New System.Drawing.Point(3, 165)
        Me.cmdCIDRecall.Name = "cmdCIDRecall"
        Appearance11.BackColor = System.Drawing.Color.Orange
        Appearance11.BackColor2 = System.Drawing.Color.DarkOrange
        Appearance11.BorderColor = System.Drawing.Color.Maroon
        Appearance11.ForeColor = System.Drawing.Color.Maroon
        Me.cmdCIDRecall.PressedAppearance = Appearance11
        Me.cmdCIDRecall.ShowFocusRect = False
        Me.cmdCIDRecall.ShowOutline = False
        Me.cmdCIDRecall.Size = New System.Drawing.Size(40, 40)
        Me.cmdCIDRecall.StyleSetName = "CIDButton"
        Me.cmdCIDRecall.TabIndex = 113
        Me.cmdCIDRecall.Text = "R"
        Me.cmdCIDRecall.UseAppStyling = False
        Me.cmdCIDRecall.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdCIDRecall.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdCIDRecall.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdCIDRecall.Visible = False
        '
        'cmdCIDAccept
        '
        Appearance12.BackColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(30, Byte), Integer))
        Appearance12.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(120, Byte), Integer), CType(CType(36, Byte), Integer))
        Appearance12.BackGradientStyle = Infragistics.Win.GradientStyle.VerticalBump
        Appearance12.BorderColor = System.Drawing.Color.DarkGreen
        Appearance12.BorderColor2 = System.Drawing.Color.Brown
        Appearance12.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance12.ForeColor = System.Drawing.Color.White
        Me.cmdCIDAccept.Appearance = Appearance12
        Me.cmdCIDAccept.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance13.BackColor = System.Drawing.Color.PowderBlue
        Appearance13.BackColor2 = System.Drawing.Color.Aqua
        Appearance13.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance13.ForeColor = System.Drawing.Color.Black
        Me.cmdCIDAccept.HotTrackAppearance = Appearance13
        Me.cmdCIDAccept.Location = New System.Drawing.Point(48, 165)
        Me.cmdCIDAccept.Name = "cmdCIDAccept"
        Appearance14.BackColor = System.Drawing.Color.Orange
        Appearance14.BackColor2 = System.Drawing.Color.DarkOrange
        Appearance14.BorderColor = System.Drawing.Color.Maroon
        Appearance14.ForeColor = System.Drawing.Color.Maroon
        Me.cmdCIDAccept.PressedAppearance = Appearance14
        Me.cmdCIDAccept.ShowFocusRect = False
        Me.cmdCIDAccept.ShowOutline = False
        Me.cmdCIDAccept.Size = New System.Drawing.Size(75, 40)
        Me.cmdCIDAccept.StyleSetName = "CIDButton"
        Me.cmdCIDAccept.TabIndex = 114
        Me.cmdCIDAccept.Text = "Accept"
        Me.cmdCIDAccept.UseAppStyling = False
        Me.cmdCIDAccept.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdCIDAccept.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdCIDAccept.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdCIDHide
        '
        Appearance15.BackColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(30, Byte), Integer))
        Appearance15.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(120, Byte), Integer), CType(CType(36, Byte), Integer))
        Appearance15.BackGradientStyle = Infragistics.Win.GradientStyle.VerticalBump
        Appearance15.BorderColor = System.Drawing.Color.DarkGreen
        Appearance15.BorderColor2 = System.Drawing.Color.Brown
        Appearance15.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance15.ForeColor = System.Drawing.Color.White
        Me.cmdCIDHide.Appearance = Appearance15
        Me.cmdCIDHide.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance16.BackColor = System.Drawing.Color.PowderBlue
        Appearance16.BackColor2 = System.Drawing.Color.Aqua
        Appearance16.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance16.ForeColor = System.Drawing.Color.Black
        Me.cmdCIDHide.HotTrackAppearance = Appearance16
        Me.cmdCIDHide.Location = New System.Drawing.Point(127, 165)
        Me.cmdCIDHide.Name = "cmdCIDHide"
        Appearance17.BackColor = System.Drawing.Color.Orange
        Appearance17.BackColor2 = System.Drawing.Color.DarkOrange
        Appearance17.BorderColor = System.Drawing.Color.Maroon
        Appearance17.ForeColor = System.Drawing.Color.Maroon
        Me.cmdCIDHide.PressedAppearance = Appearance17
        Me.cmdCIDHide.ShowFocusRect = False
        Me.cmdCIDHide.ShowOutline = False
        Me.cmdCIDHide.Size = New System.Drawing.Size(75, 40)
        Me.cmdCIDHide.StyleSetName = "CIDButton"
        Me.cmdCIDHide.TabIndex = 115
        Me.cmdCIDHide.Text = "Hide"
        Me.cmdCIDHide.UseAppStyling = False
        Me.cmdCIDHide.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdCIDHide.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdCIDHide.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdCIDLog
        '
        Appearance18.BackColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(30, Byte), Integer))
        Appearance18.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(120, Byte), Integer), CType(CType(36, Byte), Integer))
        Appearance18.BackGradientStyle = Infragistics.Win.GradientStyle.VerticalBump
        Appearance18.BorderColor = System.Drawing.Color.DarkGreen
        Appearance18.BorderColor2 = System.Drawing.Color.Brown
        Appearance18.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance18.ForeColor = System.Drawing.Color.White
        Me.cmdCIDLog.Appearance = Appearance18
        Me.cmdCIDLog.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance19.BackColor = System.Drawing.Color.PowderBlue
        Appearance19.BackColor2 = System.Drawing.Color.Aqua
        Appearance19.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance19.ForeColor = System.Drawing.Color.Black
        Me.cmdCIDLog.HotTrackAppearance = Appearance19
        Me.cmdCIDLog.Location = New System.Drawing.Point(206, 165)
        Me.cmdCIDLog.Name = "cmdCIDLog"
        Appearance20.BackColor = System.Drawing.Color.Orange
        Appearance20.BackColor2 = System.Drawing.Color.DarkOrange
        Appearance20.BorderColor = System.Drawing.Color.Maroon
        Appearance20.ForeColor = System.Drawing.Color.Maroon
        Me.cmdCIDLog.PressedAppearance = Appearance20
        Me.cmdCIDLog.ShowFocusRect = False
        Me.cmdCIDLog.ShowOutline = False
        Me.cmdCIDLog.Size = New System.Drawing.Size(75, 40)
        Me.cmdCIDLog.StyleSetName = "CIDButton"
        Me.cmdCIDLog.TabIndex = 116
        Me.cmdCIDLog.Text = "Log"
        Me.cmdCIDLog.UseAppStyling = False
        Me.cmdCIDLog.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdCIDLog.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdCIDLog.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'pnlCID
        '
        Me.pnlCID.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.pnlCID.BackgroundImage = CType(resources.GetObject("pnlCID.BackgroundImage"), System.Drawing.Image)
        Me.pnlCID.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pnlCID.Controls.Add(Me.cmdCIDLog)
        Me.pnlCID.Controls.Add(Me.cmdCIDHide)
        Me.pnlCID.Controls.Add(Me.cmdCIDAccept)
        Me.pnlCID.Controls.Add(Me.cmdCIDRecall)
        Me.pnlCID.Controls.Add(Me.imgMobile)
        Me.pnlCID.Controls.Add(Me.lblCallerIDBox2)
        Me.pnlCID.Controls.Add(Me.lblCallerIDBox1)
        Me.pnlCID.Controls.Add(Me.lblCallerIDBox0)
        Me.pnlCID.Location = New System.Drawing.Point(12, 512)
        Me.pnlCID.Name = "pnlCID"
        Me.pnlCID.Size = New System.Drawing.Size(286, 209)
        Me.pnlCID.TabIndex = 97
        Me.pnlCID.Visible = False
        '
        'UltraButton1
        '
        Me.UltraButton1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Appearance21.Image = CType(resources.GetObject("Appearance21.Image"), Object)
        Me.UltraButton1.Appearance = Appearance21
        Me.UltraButton1.AutoSize = True
        Me.UltraButton1.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.UltraButton1.ImageSize = New System.Drawing.Size(42, 42)
        Me.UltraButton1.Location = New System.Drawing.Point(4, 734)
        Me.UltraButton1.Name = "UltraButton1"
        Me.UltraButton1.Padding = New System.Drawing.Size(10, 0)
        Me.UltraButton1.ShowFocusRect = False
        Me.UltraButton1.ShowOutline = False
        Me.UltraButton1.Size = New System.Drawing.Size(64, 44)
        Me.UltraButton1.StyleSetName = "StatusBar"
        Me.UltraButton1.TabIndex = 563
        Me.UltraButton1.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton1.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdManager
        '
        Me.cmdManager.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance22.Image = CType(resources.GetObject("Appearance22.Image"), Object)
        Me.cmdManager.Appearance = Appearance22
        Me.cmdManager.AutoSize = True
        Me.cmdManager.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdManager.ImageSize = New System.Drawing.Size(42, 42)
        Me.cmdManager.Location = New System.Drawing.Point(1039, 736)
        Me.cmdManager.Name = "cmdManager"
        Me.cmdManager.Padding = New System.Drawing.Size(10, 0)
        Me.cmdManager.ShowFocusRect = False
        Me.cmdManager.ShowOutline = False
        Me.cmdManager.Size = New System.Drawing.Size(64, 44)
        Me.cmdManager.StyleSetName = "StatusBar"
        Me.cmdManager.TabIndex = 561
        Me.cmdManager.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdManager.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdQuit
        '
        Me.cmdQuit.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance23.Image = CType(resources.GetObject("Appearance23.Image"), Object)
        Me.cmdQuit.Appearance = Appearance23
        Me.cmdQuit.AutoSize = True
        Me.cmdQuit.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdQuit.ImageSize = New System.Drawing.Size(42, 42)
        Me.cmdQuit.Location = New System.Drawing.Point(1115, 736)
        Me.cmdQuit.Name = "cmdQuit"
        Me.cmdQuit.Padding = New System.Drawing.Size(10, 0)
        Me.cmdQuit.ShowFocusRect = False
        Me.cmdQuit.ShowOutline = False
        Me.cmdQuit.Size = New System.Drawing.Size(64, 44)
        Me.cmdQuit.StyleSetName = "StatusBar"
        Me.cmdQuit.TabIndex = 560
        Me.cmdQuit.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdQuit.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdBookingsToday
        '
        Me.cmdBookingsToday.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance24.BackColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance24.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance24.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance24.BorderColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance24.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance24.ForeColor = System.Drawing.Color.DarkGreen
        Appearance24.Image = CType(resources.GetObject("Appearance24.Image"), Object)
        Appearance24.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance24.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance24.TextVAlignAsString = "Bottom"
        Me.cmdBookingsToday.Appearance = Appearance24
        Me.cmdBookingsToday.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance25.BackColor = System.Drawing.Color.DarkOrange
        Appearance25.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance25.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance25.ForeColor = System.Drawing.Color.Black
        Me.cmdBookingsToday.HotTrackAppearance = Appearance25
        Me.cmdBookingsToday.ImageSize = New System.Drawing.Size(40, 40)
        Me.cmdBookingsToday.Location = New System.Drawing.Point(1050, 639)
        Me.cmdBookingsToday.Name = "cmdBookingsToday"
        Appearance26.BackColor = System.Drawing.Color.OrangeRed
        Appearance26.BackColor2 = System.Drawing.Color.Tomato
        Appearance26.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdBookingsToday.PressedAppearance = Appearance26
        Me.cmdBookingsToday.ShowFocusRect = False
        Me.cmdBookingsToday.ShowOutline = False
        Me.cmdBookingsToday.Size = New System.Drawing.Size(129, 78)
        Me.cmdBookingsToday.StyleSetName = "Reservation"
        Me.cmdBookingsToday.TabIndex = 564
        Me.cmdBookingsToday.Tag = "Up"
        Me.cmdBookingsToday.Text = "2 reservations"
        Me.cmdBookingsToday.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdBookingsToday.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdBookingsToday.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdOrders
        '
        Me.cmdOrders.Anchor = System.Windows.Forms.AnchorStyles.None
        Appearance27.BackColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Appearance27.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Appearance27.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance27.BorderColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer))
        Appearance27.ForeColor = System.Drawing.Color.DimGray
        Appearance27.Image = CType(resources.GetObject("Appearance27.Image"), Object)
        Appearance27.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance27.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance27.TextVAlignAsString = "Bottom"
        Me.cmdOrders.Appearance = Appearance27
        Me.cmdOrders.Font = New System.Drawing.Font("Ebrima", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdOrders.ImageSize = New System.Drawing.Size(48, 54)
        Me.cmdOrders.Location = New System.Drawing.Point(514, 438)
        Me.cmdOrders.Margin = New System.Windows.Forms.Padding(10)
        Me.cmdOrders.Name = "cmdOrders"
        Me.cmdOrders.ShowFocusRect = False
        Me.cmdOrders.ShowOutline = False
        Me.cmdOrders.Size = New System.Drawing.Size(157, 89)
        Me.cmdOrders.StyleSetName = "BigButton"
        Me.cmdOrders.TabIndex = 569
        Me.cmdOrders.Text = "Orders"
        Me.cmdOrders.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOrders.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdBookings
        '
        Me.cmdBookings.Anchor = System.Windows.Forms.AnchorStyles.None
        Appearance28.BackColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Appearance28.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Appearance28.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance28.BorderColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer))
        Appearance28.ForeColor = System.Drawing.Color.DimGray
        Appearance28.Image = CType(resources.GetObject("Appearance28.Image"), Object)
        Appearance28.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance28.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance28.TextVAlignAsString = "Bottom"
        Me.cmdBookings.Appearance = Appearance28
        Me.cmdBookings.Font = New System.Drawing.Font("Ebrima", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdBookings.ImageSize = New System.Drawing.Size(48, 54)
        Me.cmdBookings.Location = New System.Drawing.Point(314, 438)
        Me.cmdBookings.Margin = New System.Windows.Forms.Padding(10)
        Me.cmdBookings.Name = "cmdBookings"
        Me.cmdBookings.ShowFocusRect = False
        Me.cmdBookings.ShowOutline = False
        Me.cmdBookings.Size = New System.Drawing.Size(157, 89)
        Me.cmdBookings.StyleSetName = "BigButton"
        Me.cmdBookings.TabIndex = 568
        Me.cmdBookings.Text = "Reservations"
        Me.cmdBookings.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdBookings.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdOnline
        '
        Me.cmdOnline.Anchor = System.Windows.Forms.AnchorStyles.None
        Appearance29.BackColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Appearance29.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Appearance29.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance29.BorderColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer))
        Appearance29.ForeColor = System.Drawing.Color.DimGray
        Appearance29.Image = CType(resources.GetObject("Appearance29.Image"), Object)
        Appearance29.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance29.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance29.TextVAlignAsString = "Bottom"
        Me.cmdOnline.Appearance = Appearance29
        Me.cmdOnline.Font = New System.Drawing.Font("Ebrima", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdOnline.ImageSize = New System.Drawing.Size(42, 54)
        Me.cmdOnline.Location = New System.Drawing.Point(714, 438)
        Me.cmdOnline.Margin = New System.Windows.Forms.Padding(10)
        Me.cmdOnline.Name = "cmdOnline"
        Me.cmdOnline.ShowFocusRect = False
        Me.cmdOnline.ShowOutline = False
        Me.cmdOnline.Size = New System.Drawing.Size(157, 89)
        Me.cmdOnline.StyleSetName = "BigButton"
        Me.cmdOnline.TabIndex = 570
        Me.cmdOnline.Text = "Online"
        Me.cmdOnline.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOnline.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDelivery
        '
        Me.cmdDelivery.Anchor = System.Windows.Forms.AnchorStyles.None
        Appearance30.BackColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Appearance30.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Appearance30.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance30.BorderColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer))
        Appearance30.ForeColor = System.Drawing.Color.DimGray
        Appearance30.Image = CType(resources.GetObject("Appearance30.Image"), Object)
        Appearance30.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance30.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance30.TextVAlignAsString = "Bottom"
        Me.cmdDelivery.Appearance = Appearance30
        Me.cmdDelivery.Font = New System.Drawing.Font("Ebrima", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdDelivery.ImageSize = New System.Drawing.Size(48, 48)
        Me.cmdDelivery.Location = New System.Drawing.Point(314, 258)
        Me.cmdDelivery.Margin = New System.Windows.Forms.Padding(10)
        Me.cmdDelivery.Name = "cmdDelivery"
        Me.cmdDelivery.ShowFocusRect = False
        Me.cmdDelivery.ShowOutline = False
        Me.cmdDelivery.Size = New System.Drawing.Size(157, 89)
        Me.cmdDelivery.StyleSetName = "BigButton"
        Me.cmdDelivery.TabIndex = 565
        Me.cmdDelivery.Text = "Delivery"
        Me.cmdDelivery.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDelivery.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdPickup
        '
        Me.cmdPickup.Anchor = System.Windows.Forms.AnchorStyles.None
        Appearance31.BackColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Appearance31.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Appearance31.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance31.BorderColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer))
        Appearance31.ForeColor = System.Drawing.Color.DimGray
        Appearance31.Image = CType(resources.GetObject("Appearance31.Image"), Object)
        Appearance31.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance31.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance31.TextVAlignAsString = "Bottom"
        Me.cmdPickup.Appearance = Appearance31
        Me.cmdPickup.Font = New System.Drawing.Font("Ebrima", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdPickup.ImageSize = New System.Drawing.Size(42, 54)
        Me.cmdPickup.Location = New System.Drawing.Point(514, 258)
        Me.cmdPickup.Margin = New System.Windows.Forms.Padding(10)
        Me.cmdPickup.Name = "cmdPickup"
        Me.cmdPickup.ShowFocusRect = False
        Me.cmdPickup.ShowOutline = False
        Me.cmdPickup.Size = New System.Drawing.Size(157, 89)
        Me.cmdPickup.StyleSetName = "BigButton"
        Me.cmdPickup.TabIndex = 566
        Me.cmdPickup.Text = "Collection"
        Me.cmdPickup.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPickup.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdTables
        '
        Me.cmdTables.Anchor = System.Windows.Forms.AnchorStyles.None
        Appearance32.BackColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Appearance32.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Appearance32.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance32.BorderColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer))
        Appearance32.ForeColor = System.Drawing.Color.DimGray
        Appearance32.Image = CType(resources.GetObject("Appearance32.Image"), Object)
        Appearance32.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance32.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance32.TextVAlignAsString = "Bottom"
        Me.cmdTables.Appearance = Appearance32
        Me.cmdTables.Font = New System.Drawing.Font("Ebrima", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdTables.ImageSize = New System.Drawing.Size(48, 54)
        Me.cmdTables.Location = New System.Drawing.Point(714, 258)
        Me.cmdTables.Margin = New System.Windows.Forms.Padding(10)
        Me.cmdTables.Name = "cmdTables"
        Me.cmdTables.ShowFocusRect = False
        Me.cmdTables.ShowOutline = False
        Me.cmdTables.Size = New System.Drawing.Size(157, 89)
        Me.cmdTables.StyleSetName = "BigButton"
        Me.cmdTables.TabIndex = 567
        Me.cmdTables.Text = "Tables"
        Me.cmdTables.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTables.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'frmOpener
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(1184, 784)
        Me.ControlBox = False
        Me.Controls.Add(Me.cmdOnline)
        Me.Controls.Add(Me.cmdOrders)
        Me.Controls.Add(Me.cmdBookings)
        Me.Controls.Add(Me.cmdTables)
        Me.Controls.Add(Me.cmdPickup)
        Me.Controls.Add(Me.cmdDelivery)
        Me.Controls.Add(Me.cmdBookingsToday)
        Me.Controls.Add(Me.UltraButton1)
        Me.Controls.Add(Me.cmdManager)
        Me.Controls.Add(Me.cmdQuit)
        Me.Controls.Add(Me.pnlCID)
        Me.Controls.Add(Me.cmdShowCID)
        Me.Controls.Add(Me.UltraLabel1)
        Me.Controls.Add(Me.pnlHeader)
        Me.Controls.Add(Me.lblBizname)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.DoubleBuffered = True
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.MinimumSize = New System.Drawing.Size(1000, 700)
        Me.Name = "frmOpener"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.pnlHeader.ClientArea.ResumeLayout(False)
        Me.pnlHeader.ResumeLayout(False)
        CType(Me.imgMobile, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlCID.ResumeLayout(False)
        Me.pnlCID.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents tmrCallPhone As System.Windows.Forms.Timer
    Friend WithEvents lblDateTime As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents tmrUpdateClock As System.Windows.Forms.Timer
    Friend WithEvents lblBizname As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents cmdMinimise As Infragistics.Win.Misc.UltraButton
    Friend WithEvents pnlHeader As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents lblHeader As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel1 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents cmdShowCID As Infragistics.Win.Misc.UltraButton
    Friend WithEvents lblCallerIDBox0 As Label
    Friend WithEvents lblCallerIDBox1 As Label
    Friend WithEvents lblCallerIDBox2 As Label
    Friend WithEvents imgMobile As PictureBox
    Friend WithEvents cmdCIDRecall As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdCIDAccept As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdCIDHide As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdCIDLog As Infragistics.Win.Misc.UltraButton
    Friend WithEvents pnlCID As Panel
    Friend WithEvents UltraButton1 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdManager As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdQuit As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdBookingsToday As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdOrders As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdBookings As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdOnline As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDelivery As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdPickup As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdTables As Infragistics.Win.Misc.UltraButton
End Class
