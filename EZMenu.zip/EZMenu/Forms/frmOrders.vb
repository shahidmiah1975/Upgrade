﻿Imports System.Configuration
Imports Infragistics.Win
Imports Infragistics.Win.Misc
Imports Infragistics.Win.UltraWinDataSource
Imports EZControls
Imports EZMenu.Core.Enums
Imports EZMenu.Core.Models
Imports EZService.Repository
Imports Infragistics.Win.Layout
Imports Infragistics.Win.UltraWinGrid
Imports EZMenu.Core

Public Class frmOrders

    Private ugdTemp As UltraWinGrid.UltraGrid
    Private dtOrders As DataTable
    Private btnOrdersButton As EZOrderTicket
    Private btnLastOrdersButton As EZOrderTicket
    Private upnlOrdersButtons As UltraPanel
    Private _orderType As OrderTypeEnum
    Private Const strIsModRow As String = "ismodrow"
    Private orderRepo As New OrderRepository()

    Private Sub frmOrders_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Tag = Nothing

        lblBaseHeader.Text = $"Orders"

        Size = Owner.Size
        Location = Owner.Location

        ugdTableOrders.Location = ugdOrderGrid.Location

        FillDropDrown()

        Try
            OrderItemsTableAdapter.Connection.ConnectionString = ConfigurationManager.ConnectionStrings(EZConstants.EZDatabaseConnectionString).ConnectionString
            OrdersTableAdapter.Connection.ConnectionString = ConfigurationManager.ConnectionStrings(EZConstants.EZDatabaseConnectionString).ConnectionString
            Table_BillTableAdapter.Connection.ConnectionString = ConfigurationManager.ConnectionStrings(EZConstants.EZDatabaseConnectionString).ConnectionString
            TableAdapterManager.Connection.ConnectionString = ConfigurationManager.ConnectionStrings(EZConstants.EZDatabaseConnectionString).ConnectionString

            OrdersTableAdapter.Fill(EZMenuDataSet.Orders)
            ugdOrderGrid.DataSource = EZMenuDataSet.Orders
            ugdOrderGrid.Refresh()

            Table_BillTableAdapter.FillByPrinted(EZMenuDataSet.Table_Bill)
            ugdTableOrders.DataSource = EZMenuDataSet.Table_Bill
            ugdTableOrders.Refresh()

        Catch ex As Exception
            DisplayError(ex)
        End Try

        If ugdOrderGrid.Rows.Count > 0 Then
            ugdOrderGrid.ActiveRow = ugdOrderGrid.Rows(0)
        Else
            ugdOrderGrid.ActiveRow = Nothing
        End If
        ugdOrderGrid.DisplayLayout.Override.MinRowHeight = 32

        If ugdTableOrders.Rows.Count > 0 Then
            ugdTableOrders.ActiveRow = ugdTableOrders.Rows(0)
        Else
            ugdTableOrders.ActiveRow = Nothing
        End If
        ugdTableOrders.DisplayLayout.Override.MinRowHeight = 32

        ugdTemp = ugdOrderGrid

        GetOrdersInfo()

        cmdCuisine.Visible = GetAppSettingCS("MultiCuisines", True)
        'cmdGridView.Visible = objSecurity.IsMySystem()

        'If GetAppSettingCS("XOrderTotals", True) Then
        '    cmdShowTotals.Appearance.Image = My.Resources.ezresource.login
        'Else
        cmdShowTotals.Appearance.Image = My.Resources.ezresource.money
        'End If

        Application.DoEvents()

        If GetAppSettingCS("OGViewButtons", True) = True Then
            DisplayGridLayout()
        End If

    End Sub

    Private Sub cmdClose_Click(sender As Object, e As EventArgs) Handles cmdReturn.Click

        'SMX - clean this line!!
        If Tag = "EditMode" AndAlso objDelivColn IsNot Nothing Then objDelivColn.SetScreen(OrderTypeEnum.EditOff)
        Close()

    End Sub

    Private Sub FillDropDrown()

        Try

            Dim myList As New ValueList()

            myList = ugdOrderGrid.DisplayLayout.ValueLists.Add()
            myList.ValueListItems.Add("", "")
            myList.ValueListItems.Add("Cash", "Cash")
            myList.ValueListItems.Add("Card", "Card")
            myList.ValueListItems.Add("Mixed", "Mixed")
            myList.ValueListItems.Add("Other", "Other")
            ugdOrderGrid.DisplayLayout.Bands(0).Columns("PaymentMethod").ValueList = myList

            myList = ugdTableOrders.DisplayLayout.ValueLists.Add()
            myList.ValueListItems.Add("", "")
            myList.ValueListItems.Add("Cash", "Cash")
            myList.ValueListItems.Add("Card", "Card")
            myList.ValueListItems.Add("Mixed", "Mixed")
            myList.ValueListItems.Add("Other", "Other")

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub GetOrdersInfo()

        Dim intDelvieries, intCollections, intTables, intTableCusts As Short
        Dim decSumCollections, decSumDeliveries, decSumTables As Decimal

        intCollections = 0
        intDelvieries = 0
        decSumCollections = 0
        decSumDeliveries = 0
        decSumTables = 0

        For Each mrow In ugdOrderGrid.Rows
            If mrow.Cells("CustomerID").Value >= intMaxCustomerID Then
                intCollections += 1
                decSumCollections += mrow.Cells("BillTotal").Value
            Else
                intDelvieries += 1
                decSumDeliveries += mrow.Cells("BillTotal").Value
            End If
        Next

        For Each mrow In ugdTableOrders.Rows
            decSumTables += mrow.Cells("BillTotal").Value
            intTableCusts += mrow.Cells("NumCust").Value
        Next
        intTables = ugdTableOrders.Rows.Count

    End Sub

    Private Sub cmdDelete_Click(sender As Object, e As EventArgs) Handles cmdDelete.Click

        If ugdTemp.Rows.Count = 0 Then
            strMsgBox = "There are no orders"
            Alert(strMsgBox, MessageBoxIcon.Exclamation)

        Else 'If 'objSecurity.GotAccess("XOrderDelete") = True Then
            If ugdTemp.ActiveRow IsNot Nothing Then
                ugdTemp.ActiveRow.Delete(False)
                OrdersTableAdapter.Update(EZMenuDataSet.Orders)
                GetOrdersInfo()

                If GetAppSettingCS("OGViewButtons", True) = True Then
                    btnOrdersButton.Dispose()
                End If
            End If

        End If

    End Sub

    Private Sub cmdOrderItems_Click(sender As Object, e As EventArgs) Handles cmdOrderItems.Click

        If ugdOrderGrid.Visible = True Then
            If ugdTemp.Rows.Count = 0 Then
                strMsgBox = "There are no orders"
                Alert(strMsgBox, MessageBoxIcon.Exclamation)
            Else
                If ugdOrderGrid.ActiveRow IsNot Nothing Then
                    Dim objOrderItems As New frmOrderItems(ugdOrderGrid.ActiveRow.Cells("OrderID").Value)
                    objOrderItems.ShowDialog()
                Else
                    strMsgBox = "Select an order from the grid first."
                    Alert(strMsgBox, MessageBoxIcon.Information)
                End If
            End If
        End If

    End Sub

    Private Sub cmdReturn_Click(sender As Object, e As EventArgs) Handles cmdReturn.Click

        OrdersTableAdapter.Update(EZMenuDataSet.Orders)
        Table_BillTableAdapter.Update(EZMenuDataSet.Table_Bill)

        Close()

    End Sub

    Private Sub OGUpDown(sender As Object, e As EventArgs) Handles cmdUp.Click, cmdDown.Click

        If ugdOrderGrid.Visible = True Then
            ugdTemp = ugdOrderGrid
        Else
            ugdTemp = ugdTableOrders
        End If

        If ugdTemp.Rows.Count = 0 Then Exit Sub

        If ugdTemp.ActiveRow Is Nothing Then ugdTemp.ActiveRow = ugdTemp.Rows(0)

        If sender.name = "cmdUp" Then

            If ugdTemp.ActiveRow.Index > 0 Then
                ugdTemp.ActiveRow = ugdTemp.Rows(ugdTemp.ActiveRow.Index - 1)
            Else
                ugdTemp.ActiveRow = ugdTemp.Rows(ugdTemp.Rows.Count - 1)
            End If

        Else

            If ugdTemp.ActiveRow.Index < ugdTemp.Rows.Count - 1 Then
                ugdTemp.ActiveRow = ugdTemp.Rows(ugdTemp.ActiveRow.Index + 1)
            Else
                ugdTemp.ActiveRow = ugdTemp.Rows(0)
            End If

        End If

    End Sub

    Private Sub cmdReprint_Click(sender As Object, e As EventArgs) Handles cmdReprint.Click

        Dim repCustId As Short
        Dim _orderId As Integer

        If ugdTemp.Rows.Count = 0 Then
            strMsgBox = "There are no orders"
            Alert(strMsgBox, MessageBoxIcon.Exclamation)
            Exit Sub
        End If

        'If objSecurity.GotAccess("XOrderReprint") = True Then
        If ugdTemp.ActiveRow Is Nothing Then
                strMsgBox = "No order has been selected in the grid"
                Alert(strMsgBox, MessageBoxIcon.Exclamation)

            Else
                'deliver / collection
                If ugdOrderGrid.Visible = True Then
                    repCustId = ugdOrderGrid.ActiveRow.Cells("CustomerID").Value
                    If repCustId < intMaxCustomerID Then
                        _orderType = OrderTypeEnum.Delivery
                    Else
                        _orderType = OrderTypeEnum.Collection
                    End If
                    _orderId = ugdOrderGrid.ActiveRow.Cells("OrderID").Value

                    'table order
                ElseIf ugdTableOrders.Visible = True Then
                    _orderType = OrderTypeEnum.Table
                    _orderId = ugdTableOrders.ActiveRow.Cells("TabUniqueID").Value
                End If

                Using objReprint As New frmReprint(_orderType, _orderId)
                    objReprint.ShowDialog()
                End Using

            End If

        'End If

    End Sub

    Private Sub PopulateOrderEntryForEdit()
        'copies the order from the frmOrders tab onto the main form for editing purposes

        objOrderEntry.Show(Me)
        objOrderEntry.Visible = False

        'clear the main form grid
        objOrderEntry.udsOrder.Rows.Clear()

        Dim orderData As List(Of OrderEditDataModel) = orderRepo.GetOrderData(ugdOrderGrid.ActiveRow.Cells("OrderID").Value)

        'copy all the items in the bill to the editing section
        For Each item In orderData
            If item.DishName <> "Drinks" Then
                Dim udrRow As UltraDataRow = objOrderEntry.udsOrder.Rows.Add
                udrRow.Item("DCode") = item.Code
                udrRow.Item("DName") = item.DishName
                udrRow.Item("DPrice") = item.UnitPrice
                udrRow.Item("DQty") = item.Qty
                udrRow.Item("Total") = item.UnitPrice * item.Qty
                udrRow.Item("Mods") = String.Empty
                udrRow.Item("Discountable") = item.Discountable
                udrRow.Item("OriPrice") = item.UnitPrice
                udrRow.Item("GroupIndex") = item.GroupIndex
                udrRow.Item("HiLite") = "0"

                'get any mod row
                Dim orderMods As IEnumerable(Of OrderModsModel) = orderRepo.GetOrderModsFromDB(OrderID, item.DishName)
                If orderMods.Any Then
                    For Each om In orderMods
                        Dim udrModRow As UltraDataRow = objOrderEntry.udsOrder.Rows.Add
                        udrModRow.Item("DQty") = String.Empty
                        udrModRow.Item("DName") = "- " + om.ModName
                        udrModRow.Item("DPrice") = om.ModCost
                        udrModRow.Item("Total") = item.Qty * om.ModCost
                        udrModRow.Item("Mods") = strIsModRow
                        udrModRow.Item("Discountable") = 0
                    Next
                End If

                'get any set items
                'If tempStr.Substring(1, 1) = "1" Then
                '    Dim strSetItems As String = objDB.GetSetItemsFromDB(OrderID, myRow("Dish"))
                '    If strSetItems <> String.Empty Then
                '        Dim arrSets = strSetItems.Split("^^")
                '        For aCnt = arrSets.GetLowerBound(0) To arrSets.GetUpperBound(0)
                '            If arrSets(aCnt) <> String.Empty Then
                '                Dim arrSetItems() = arrSets(aCnt).Split("#")
                '                Dim udrModRow As UltraDataRow = objOrderEntry.udsOrder.Rows.Add
                '                udrModRow.Item("DQty") = arrSetItems(0)
                '                udrModRow.Item("DName") = "- " & arrSetItems(1)
                '                udrModRow.Item("DPrice") = arrSetItems(2)
                '                udrModRow.Item("Total") = fixCur(arrSetItems(0) * arrSetItems(2))
                '                udrModRow.Item("Mods") = strIsSetItem
                '                udrModRow.Item("Discountable") = 0
                '            End If
                '        Next
                '    End If
                'End If

            End If
        Next

        objOrderEntry.ugdOrderGrid.DataSource = objOrderEntry.udsOrder

        OrderID = ugdOrderGrid.ActiveRow.Cells("OrderID").Value

        'get drinks now
        'SQLQuery = $"SELECT COALESCE(DrinksTotal, 0) AS DrinksTotal
        '                 FROM Orders 
        '                 WHERE OrderID = { ugdOrderGrid.ActiveRow.Cells("OrderID").Value }"
        'drDataRow = objDB.GetSingleRow(SQLQuery)
        'If drDataRow IsNot Nothing Then
        '    If (drDataRow!DrinksTotal) > 0 Then
        '        With objOrderEntry
        '            .lblDrinksOE.Text = fixCur(drDataRow!DrinksTotal)
        '            .lblDrinksOELbl.Visible = True
        '            .lblDrinksOE.Visible = True
        '        End With
        '    End If

        '    'copy drinks to the drinks list in frmTables
        '    Dim udsDrinks As New UltraDataSource
        '    udsDrinks.Band.Columns.Add("DkQty", GetType(Short))
        '    udsDrinks.Band.Columns.Add("DkName", GetType(String))
        '    udsDrinks.Band.Columns.Add("DkPrice", GetType(Decimal))
        '    udsDrinks.Band.Columns.Add("DkTotal", GetType(Decimal))
        '    objTables.Tag = "DrinkAwayEdit"
        '    objTables.udsDrinks = udsDrinks

        '    SQLQuery = "SELECT DkName, DkPrice, DkQty FROM CollectionDrinks WHERE OrderID = " & OrderID
        '    drcDatarowCollection = objDB.GetDataRows(SQLQuery)
        '    Dim decDrinksTotals As Decimal = 0
        '    If drcDatarowCollection IsNot Nothing Then

        '        For Each myRow As DataRow In drcDatarowCollection
        '            Dim udrRow As UltraDataRow = udsDrinks.Rows.Add
        '            udrRow.Item("DkQty") = myRow("DkQty")
        '            udrRow.Item("DkName") = myRow("DkName")
        '            udrRow.Item("DkPrice") = myRow("DkPrice")
        '            udrRow.Item("DkTotal") = myRow("DkQty") * myRow("DkPrice")
        '            decDrinksTotals += udrRow.Item("DkTotal")
        '        Next

        '        objTables.ugdDrinksGrid.DataSource = udsDrinks
        '        'work out the drinks total
        '        objTables.lblDrinksTotal.Text = fixCur(decDrinksTotals)
        '    End If

        '    'fill in drinks row in bill if there are drinks selected
        '    If decDrinksTotals > 0 Then
        '        objTables.lblTDrinks.Text = fixCur(decDrinksTotals)
        '    End If

        'End If

        With objOrderEntry
            .lblSubtotal.Text = fixCur(FromOrdersDB("Subtotal"))
            '.lblPriceAdjCharges.Text = fixCur(FromOrdersDB("ChargeAmount"))
            '.lblPriceAdjDiscounts.Text = "-" + fixCur(FromOrdersDB("DiscountAmount"))
            .lblToPay.Text = fixCur(FromOrdersDB("BillTotal"))
            .lblNumItems.Text = "Items: " & NumberOfItems()
            .cmdCuisine.Visible = GetAppSettingCS("MultiCuisines", True)
            .pnlDishes.ClientArea.Controls.Clear()
            .Show()
        End With

    End Sub

    Private Sub cmdEdit_Click(sender As Object, e As EventArgs) Handles cmdEdit.Click

        If ugdOrderGrid.Visible = True Then
            If ugdOrderGrid.Rows.Count = 0 Then
                strMsgBox = "There are no orders"
                Alert(strMsgBox, MessageBoxIcon.Exclamation)
                Exit Sub
            ElseIf ugdOrderGrid.ActiveRow Is Nothing Then
                strMsgBox = "No order has been selected in the grid"
                Alert(strMsgBox, MessageBoxIcon.Exclamation)
                Exit Sub
            End If
        End If

        'If objSecurity.GotAccess("XOrderEdit") = False Then Exit Sub

        'all ok to go ahead
        Dim selectedOrder As UltraGridRow = ugdOrderGrid.ActiveRow

        StartNewOrder()

        OrderID = CShort(selectedOrder.Cells("OrderID").Value)
        CustID = CShort(selectedOrder.Cells("CustomerID").Value)

        If objDelivColn Is Nothing Then objDelivColn = New frmDelivColn(OrderTypeEnum.EditOn, Nothing, Nothing, Nothing, False)
        If objPayment Is Nothing Then objPayment = New frmPayment()
        If objOrderEntry Is Nothing Then objOrderEntry = New frmOrderEntry()

        With objDelivColn
            If CustID < intMaxCustomerID Then  'delivery
                _orderType = OrderTypeEnum.Delivery
                .SetScreen(OrderTypeEnum.Delivery)
                .txtAddress1.Text = selectedOrder.Cells("DeliveryAddress1").Value
                .txtAddress2.Text = selectedOrder.Cells("DeliveryAddress2").Value
                .txtAddress3.Text = selectedOrder.Cells("DeliveryAddress3").Value
                .txtPostcode.Text = selectedOrder.Cells("DeliveryPostcode").Value

            Else    'collection
                _orderType = OrderTypeEnum.Collection
                .SetScreen(OrderTypeEnum.Collection)
            End If

            .txtName.Text = selectedOrder.Cells("CustomerName").Value.ToString
            .txtTelephone.Text = selectedOrder.Cells("Telephone").Value.ToString
            .lblCustomerData.Text = "Customer ID: " & CustID
        End With

        objOrderEntry.CurrentOrderType = _orderType

        PopulateOrderEntryForEdit()

        'set discount and charges
        'GlobalDiscounts.Discount2 = FromOrdersDB("Discount2")
        'GlobalDiscounts.Discount2AorP = FromOrdersDB("Discount2AorP")
        'GlobalDiscounts.Discount2Rate = FromOrdersDB("Discount2Rate")
        'GlobalCharges.Charge2 = FromOrdersDB("Charge2")
        'GlobalCharges.Charge2AorP = FromOrdersDB("Charge2AorP")
        'GlobalCharges.Charge2Rate = FromOrdersDB("Charge2Rate")

        RefreshPaymentScreen(selectedOrder)

    End Sub

    Private Sub RefreshPaymentScreen(selectedOrder As UltraGridRow)

        With objPayment
            If Not String.IsNullOrEmpty(selectedOrder.Cells("CollectionOrDeliveryTime").Value) Then
                .lblTime.Text = "Time: " & Format(CDate(selectedOrder.Cells("CollectionOrDeliveryTime").Value.ToString), "hh") & ":" & Format(CDate(selectedOrder.Cells("CollectionOrDeliveryTime").Value.ToString), "mm")
            End If

            Dim var = 0
            If CustID < intMaxCustomerID Then  'delivery
                .CurrentOrderType = OrderTypeEnum.Delivery
            Else  'collection
                .CurrentOrderType = OrderTypeEnum.Collection
                var = Val(selectedOrder.Cells("CustomerIsWaiting").Value)
                If var = 0 Then var = cstButTogClr 'do not put X but a clear on Paid button
                ButtonToggle(objPayment.cmdWaiting, var)
            End If

            var = Val(selectedOrder.Cells("OrderIsPaid").Value)
            If var = 0 Then var = cstButTogClr 'do not put X but a clear on Paid button
            ButtonToggle(objPayment.cmdPaid, var)

            .txtKitchenNote.Text = FromOrdersDB("KitchenNote")

            If Not IsDBNull(selectedOrder.Cells("PaymentMethod").Value) Then
                If selectedOrder.Cells("PaymentMethod").Value = "Cash" Then
                    ButtonToggle(objPayment.cmdTenderCash, cstButTogYes)
                ElseIf selectedOrder.Cells("PaymentMethod").Value = "Card" Then
                    ButtonToggle(objPayment.cmdTenderCard, cstButTogYes)
                ElseIf selectedOrder.Cells("PaymentMethod").Value = "Other" Then
                    ButtonToggle(objPayment.cmdTenderOther, cstButTogYes)
                End If
            End If

        End With

    End Sub

    Public Sub RefreshOrdersGrid()

        OrdersTableAdapter.Fill(EZMenuDataSet.Orders)
        ugdOrderGrid.DataSource = EZMenuDataSet.Orders
        ugdOrderGrid.Refresh()

        GetOrdersInfo()

    End Sub

    Private Sub cmdDelivColn_Click(sender As Object, e As EventArgs) Handles cmdDelivColn.Click

        ugdTemp = ugdOrderGrid
        ugdTableOrders.Visible = False

        Dim blnOGViewButton As Boolean = GetAppSettingCS("OGViewButtons", True)

        If blnOGViewButton = True Then
            Dim grid As UltraPanel = CType(Me.Controls("PanelOrdersButton"), UltraPanel)
            If grid IsNot Nothing Then
                grid.Show()
            Else
                DisplayGridLayout()
            End If
        Else
            ugdOrderGrid.Visible = True
        End If

        cmdEdit.Enabled = True
        cmdTables.Enabled = True
        cmdDelivColn.Enabled = False
        cmdOrderItems.Enabled = True
        cmdGridView.Enabled = True

    End Sub

    Private Sub cmdTables_Click(sender As Object, e As EventArgs) Handles cmdTables.Click

        ugdTemp = ugdTableOrders
        ugdTableOrders.Visible = True
        ugdOrderGrid.Visible = False
        cmdEdit.Enabled = False
        cmdTables.Enabled = False
        cmdDelivColn.Enabled = True
        cmdOrderItems.Enabled = False
        cmdMap.Enabled = False
        cmdGridView.Enabled = False

        Dim grid As UltraPanel = CType(Controls("PanelOrdersButton"), UltraPanel)
        If grid IsNot Nothing Then grid.Hide()

    End Sub

    Private Sub cmdUnlock_Click(sender As Object, e As EventArgs) Handles cmdShowTotals.Click

        If GetAppSettingCS("XOrderTotals", True) Then
            If GetSuperFromDB() = True Then
                frmOrderTotals.ShowDialog(Me)
            End If
        Else
            frmOrderTotals.ShowDialog(Me)
        End If

    End Sub

    Private Sub cmdMap_Click(sender As Object, e As EventArgs) Handles cmdMap.Click

        Try

            Dim strDestination As String = ""

            Dim conn As New EZService.ConnectivityService
            If conn.IsInternetAvailable() Then

                If ugdOrderGrid.Rows.Count > 0 AndAlso ugdOrderGrid.ActiveRow IsNot Nothing Then

                    If (ugdOrderGrid.ActiveRow.Cells("CustomerID").Value < intMaxCustomerID AndAlso Not IsDBNull(ugdOrderGrid.ActiveRow.Cells("DeliveryPostcode").Value)) Then
                        strDestination = ugdOrderGrid.ActiveRow.Cells("DeliveryPostcode").Value.Trim
                    Else
                        strMsgBox = "This order does not have a postcode."
                        Alert(strMsgBox)
                    End If

                    If strDestination <> "" Then
                        If GetAppSettingCS("MyPostcode", "") <> "" Then
                            strMsgBox = "Do you wish to see directions?"
                            intResponseBox = EZMsgBox.Show(strMsgBox, MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question)
                        Else
                            intResponseBox = vbNo
                        End If

                        If intResponseBox <> vbCancel Then
                            If intResponseBox = vbYes Then
                                tempStr = String.Format("http://maps.google.co.uk/maps?saddr={0}&daddr={1}",
                                                        GetAppSettingCS("MyPostcode", "SE2 9EL").ToString.Replace(" ", "+"),
                                                        strDestination.Replace(" ", "+"))
                            ElseIf intResponseBox = vbNo Then
                                tempStr = String.Format("https://maps.google.co.uk/?output=embed&hl=en&layer=t&q={0}&z=16",
                                                        strDestination.Replace(" ", "+"))
                            End If
                            frmMaps.WebBrowser1.Navigate(tempStr)
                            frmMaps.ShowDialog()
                            frmMaps.Dispose()
                        End If
                    End If

                Else
                    If ugdOrderGrid.Rows.Count = 0 Then
                        strMsgBox = "There are no orders"
                    Else
                        strMsgBox = "Select an order from the list first"
                    End If
                    Alert(strMsgBox)
                End If

            Else
                strMsgBox = "Internet connection could not be detected. Internet connection is required for this feature."
                DisplayError(strMsgBox)
            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub cmdGridView_Click(sender As Object, e As EventArgs) Handles cmdGridView.Click

        Try

            Dim blnOGViewButton As Boolean = Not GetAppSettingCS("OGViewButtons", True)

            If blnOGViewButton = True Then
                DisplayGridLayout()

            Else
                ugdOrderGrid.Visible = True

                '**** NOTE - Need two loops of For Each to get rid of both command buttons!!!! ****
                For Each myObj In Controls
                    If TypeOf myObj Is UltraPanel AndAlso myObj.name = "PanelOrdersButton" Then
                        myObj.Dispose()
                    ElseIf TypeOf myObj Is UltraButton Then
                        Dim myButton As UltraButton = DirectCast(myObj, UltraButton)
                        If myButton.Name = "cmdGridPrev" Or myButton.Name = "cmdGridNext" Then
                            myButton.Dispose()
                        End If
                    End If
                Next
                For Each myObj In Controls
                    Dim myButton As UltraButton = TryCast(myObj, UltraButton)
                    If (myButton IsNot Nothing) Then
                        If myButton.Name = "cmdGridPrev" Or myButton.Name = "cmdGridNext" Then
                            myButton.Dispose()
                        End If
                    End If
                Next
            End If

            SaveAppSetting("OGViewButtons", blnOGViewButton)

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub DisplayGridLayout(Optional blnDrawPanel As Boolean = True)

        dtOrders = clsOrder.GetAllOrders

        If dtOrders.Rows.Count > 0 Then

            upnlOrdersButtons = New UltraPanel

            upnlOrdersButtons.SuspendLayout()

            With upnlOrdersButtons
                .Visible = False
                .Parent = Me
                .Size = ugdOrderGrid.Size
                .Location = ugdOrderGrid.Location
                .Anchor = AnchorStyles.Top + AnchorStyles.Bottom + AnchorStyles.Left + AnchorStyles.Right
                .Name = "PanelOrdersButton"
                .BringToFront()
                .BorderStyle = UIElementBorderStyle.Solid
                .Appearance.BorderColor = Color.Silver
                .AutoScroll = True
            End With

            For Each row In dtOrders.Rows
                Dim aa As New EZOrderTicket
                With aa
                    .Initialize()
                    .Name = "OrdersButton"
                    .AddressLocation = New Point(0, 20)
                    .BackColor = Color.Transparent
                    .ColorAddress = Color.Black
                    .ColorTime = Color.Gray
                    .ColorOrderID = .ColorTime
                    .TopInfo(row("OrderID"), row.Item("OrderTime").ToString.Trim)
                    .OrderID = row("OrderID")
                    .Address = GetRecordData(row)
                    .SetFontAddress = New Font("Arial", 8)
                    .Status = row("ButtonStatus")
                    upnlOrdersButtons.ClientArea.Controls.Add(aa)
                    .Visible = True
                End With
                AddHandler aa.OrdersButtonClickHandler, AddressOf OrdersButtonClickHandler
            Next

            Dim ufmFlow = New UltraFlowLayoutManager With {
                    .ContainerControl = upnlOrdersButtons.ClientArea,
                    .HorizontalAlignment = DefaultableFlowLayoutAlignment.Near,
                    .VerticalAlignment = DefaultableFlowLayoutAlignment.Near}

            upnlOrdersButtons.ResumeLayout()
            upnlOrdersButtons.Visible = True
            Application.DoEvents()

        End If

    End Sub

    Private Sub OrdersButtonClickHandler(sender As Object)

        btnOrdersButton = DirectCast(sender, EZOrderTicket)

        'hilit the same in orders grid
        For Each mrow In ugdOrderGrid.Rows
            If mrow.Cells("OrderID").Value = btnOrdersButton.OrderID Then
                ugdOrderGrid.Rows(mrow.Index).Activate()
                Exit For
            End If
        Next

        If btnLastOrdersButton Is Nothing Then
            btnLastOrdersButton = btnOrdersButton

        ElseIf btnLastOrdersButton.OrderID = btnOrdersButton.OrderID Then

        Else
            btnLastOrdersButton.ResetClick()
            btnLastOrdersButton = btnOrdersButton

        End If

        'save the button's status
        SQLQuery = "UPDATE Orders SET ButtonStatus = " & btnOrdersButton.Status & " WHERE OrderID = " & btnOrdersButton.OrderID
        objDB.ExeNonQuery(SQLQuery)

    End Sub

    Private Sub NavOrderButtons(sender As Object, e As EventArgs)

        Try

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Function GetObject(strName As String, strTypeName As String)

        For Each myObj In Controls
            If myObj.name = strName Then
                If TypeName(myObj) = strTypeName AndAlso strTypeName = "UltraButton" Then
                    Return DirectCast(myObj, UltraButton)
                ElseIf TypeName(myObj) = strTypeName AndAlso strTypeName = "UltraLabel" Then
                    Return DirectCast(myObj, UltraLabel)
                End If
            End If
        Next

        Return Nothing

    End Function

    Private Function GetObjectInPanel(strName As String, objContainer As UltraPanel, strTypeName As String)

        For Each myObj In objContainer.ClientArea.Controls
            If myObj.name = strName Then
                If TypeName(myObj) = strTypeName AndAlso strTypeName = "UltraButton" Then
                    Return DirectCast(myObj, UltraButton)
                ElseIf TypeName(myObj) = strTypeName AndAlso strTypeName = "UltraLabel" Then
                    Return DirectCast(myObj, UltraLabel)
                End If
            End If
        Next

        Return Nothing

    End Function

    Private Function GetRecordData(dRow As DataRow)

        Dim strTmp, strMyDetails As String

        strMyDetails = dRow("CustomerName").ToString.Trim
        strTmp = dRow("DeliveryAddress1").ToString.Trim
        If strTmp <> String.Empty Then strMyDetails &= vbCrLf & strTmp
        strTmp = dRow("DeliveryAddress2").ToString.Trim
        If strTmp <> String.Empty Then strMyDetails &= vbCrLf & strTmp
        strTmp = dRow("DeliveryAddress3").ToString.Trim
        If strTmp <> String.Empty Then strMyDetails &= vbCrLf & strTmp
        strTmp = dRow("DeliveryPostcode").ToString.Trim
        If strTmp <> String.Empty Then strMyDetails &= vbCrLf & strTmp
        If strMyDetails.Trim = String.Empty Then strMyDetails = "Collection Order"

        Return strMyDetails

    End Function

    Private Sub cmdCuisine_Click(sender As Object, e As EventArgs) Handles cmdCuisine.Click

        SQLQuery = "SELECT CuisineName FROM Cuisine WHERE CuisineName <> '' ORDER BY ID"
        drcDatarowCollection = objDB.GetDataRows(SQLQuery)
        If drcDatarowCollection IsNot Nothing AndAlso drcDatarowCollection.Count > 0 Then
            Dim CuisineList As New List(Of String) From {
                "All Cuisines"
            }

            For Each myRow As DataRow In drcDatarowCollection
                CuisineList.Add(myRow.Item("CuisineName").ToString())
            Next

            Dim strResponse As String = CustomList.Show(CuisineList, False)
            If strResponse <> strCustomListBoxCancelString Then
                'cmdCuisine.Text = strResponse
                If strResponse = "All Cuisines" Then
                    OrdersTableAdapter.Fill(EZMenuDataSet.Orders)
                Else
                    OrdersTableAdapter.FillByCuisine(EZMenuDataSet.Orders, strResponse)
                End If
                ugdOrderGrid.DataSource = EZMenuDataSet.Orders
                ugdOrderGrid.Refresh()
                GetOrdersInfo()
            End If
        Else
            Alert("There are no cuisines specified")
        End If

    End Sub

End Class