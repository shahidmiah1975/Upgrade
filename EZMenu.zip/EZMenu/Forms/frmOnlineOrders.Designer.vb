﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmOnlineOrders
    Inherits EZMenu.frmBaseForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim Appearance8 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance9 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance10 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance11 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance12 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance13 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance7 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance14 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance15 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance16 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance17 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance18 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance19 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance20 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraGridBand1 As Infragistics.Win.UltraWinGrid.UltraGridBand = New Infragistics.Win.UltraWinGrid.UltraGridBand("", -1)
        Dim Appearance21 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance22 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance23 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance24 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance25 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance26 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance27 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance28 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance29 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance30 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance31 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance32 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance33 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance34 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance35 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance36 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance37 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance38 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance39 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance40 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance41 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance42 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance43 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance44 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance45 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance46 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance4 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance5 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance6 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance47 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance1 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmOnlineOrders))
        Dim Appearance2 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance3 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance48 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Me.cmdDown = New Infragistics.Win.Misc.UltraButton()
        Me.cmdUp = New Infragistics.Win.Misc.UltraButton()
        Me.cmdClearGrids = New Infragistics.Win.Misc.UltraButton()
        Me.cmdStartTimer = New Infragistics.Win.Misc.UltraButton()
        Me.cmdPrintOrder = New Infragistics.Win.Misc.UltraButton()
        Me.cmdGetOrderItems = New Infragistics.Win.Misc.UltraButton()
        Me.lblStatusBar = New Infragistics.Win.Misc.UltraLabel()
        Me.chkAutoPrint = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.lblUpdateIntervalLabel = New Infragistics.Win.Misc.UltraLabel()
        Me.cmbTimeInterval = New Infragistics.Win.UltraWinEditors.UltraComboEditor()
        Me.lblNextUpdate = New Infragistics.Win.Misc.UltraLabel()
        Me.lblLastUpdate = New Infragistics.Win.Misc.UltraLabel()
        Me.lblClock = New Infragistics.Win.Misc.UltraLabel()
        Me.ugdOrderItems = New Infragistics.Win.UltraWinGrid.UltraGrid()
        Me.ugdOrders = New Infragistics.Win.UltraWinGrid.UltraGrid()
        Me.tmrCheckOnline = New System.Windows.Forms.Timer(Me.components)
        Me.tmrTimeNow = New System.Windows.Forms.Timer(Me.components)
        Me.cmdFetchToday = New Infragistics.Win.Misc.UltraButton()
        Me.cmdHide = New Infragistics.Win.Misc.UltraButton()
        Me.chkBringToFront = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.cmdSendToBack = New Infragistics.Win.Misc.UltraButton()
        Me.cmdTestConn = New Infragistics.Win.Misc.UltraButton()
        Me.uplBasePanel.ClientArea.SuspendLayout()
        Me.uplBasePanel.SuspendLayout()
        CType(Me.chkAutoPrint, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbTimeInterval, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ugdOrderItems, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ugdOrders, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkBringToFront, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'uplBasePanel
        '
        '
        'uplBasePanel.ClientArea
        '
        Me.uplBasePanel.ClientArea.Controls.Add(Me.cmdSendToBack)
        Me.uplBasePanel.ClientArea.Controls.Add(Me.cmdHide)
        Me.uplBasePanel.ClientArea.Controls.Add(Me.lblStatusBar)
        Me.uplBasePanel.Size = New System.Drawing.Size(1135, 50)
        '
        'cmdDown
        '
        Me.cmdDown.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance8.BackColor = System.Drawing.Color.Transparent
        Appearance8.Image = CType(resources.GetObject("Appearance8.Image"), Object)
        Appearance8.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance8.ImageVAlign = Infragistics.Win.VAlign.Middle
        Me.cmdDown.Appearance = Appearance8
        Me.cmdDown.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdDown.Location = New System.Drawing.Point(1013, 110)
        Me.cmdDown.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.cmdDown.Name = "cmdDown"
        Me.cmdDown.ShowFocusRect = False
        Me.cmdDown.ShowOutline = False
        Me.cmdDown.Size = New System.Drawing.Size(85, 40)
        Me.cmdDown.TabIndex = 490
        '
        'cmdUp
        '
        Me.cmdUp.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance9.BackColor = System.Drawing.Color.Transparent
        Appearance9.Image = CType(resources.GetObject("Appearance9.Image"), Object)
        Appearance9.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance9.ImageVAlign = Infragistics.Win.VAlign.Middle
        Me.cmdUp.Appearance = Appearance9
        Me.cmdUp.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdUp.Location = New System.Drawing.Point(1013, 62)
        Me.cmdUp.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.cmdUp.Name = "cmdUp"
        Me.cmdUp.ShowFocusRect = False
        Me.cmdUp.ShowOutline = False
        Me.cmdUp.Size = New System.Drawing.Size(85, 40)
        Me.cmdUp.TabIndex = 489
        '
        'cmdClearGrids
        '
        Me.cmdClearGrids.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance10.BackColor = System.Drawing.Color.Transparent
        Me.cmdClearGrids.Appearance = Appearance10
        Me.cmdClearGrids.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdClearGrids.Location = New System.Drawing.Point(978, 301)
        Me.cmdClearGrids.Name = "cmdClearGrids"
        Me.cmdClearGrids.ShowFocusRect = False
        Me.cmdClearGrids.ShowOutline = False
        Me.cmdClearGrids.Size = New System.Drawing.Size(145, 40)
        Me.cmdClearGrids.TabIndex = 487
        Me.cmdClearGrids.Text = "Clear grids"
        '
        'cmdStartTimer
        '
        Me.cmdStartTimer.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance11.BackColor = System.Drawing.Color.Transparent
        Me.cmdStartTimer.Appearance = Appearance11
        Me.cmdStartTimer.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdStartTimer.Location = New System.Drawing.Point(978, 394)
        Me.cmdStartTimer.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.cmdStartTimer.Name = "cmdStartTimer"
        Me.cmdStartTimer.ShowFocusRect = False
        Me.cmdStartTimer.ShowOutline = False
        Me.cmdStartTimer.Size = New System.Drawing.Size(145, 40)
        Me.cmdStartTimer.TabIndex = 480
        Me.cmdStartTimer.Text = "Start Online Checks"
        '
        'cmdPrintOrder
        '
        Me.cmdPrintOrder.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance12.BackColor = System.Drawing.Color.Transparent
        Me.cmdPrintOrder.Appearance = Appearance12
        Me.cmdPrintOrder.Enabled = False
        Me.cmdPrintOrder.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdPrintOrder.Location = New System.Drawing.Point(978, 254)
        Me.cmdPrintOrder.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.cmdPrintOrder.Name = "cmdPrintOrder"
        Me.cmdPrintOrder.ShowFocusRect = False
        Me.cmdPrintOrder.ShowOutline = False
        Me.cmdPrintOrder.Size = New System.Drawing.Size(145, 40)
        Me.cmdPrintOrder.TabIndex = 479
        Me.cmdPrintOrder.Text = "Print order"
        '
        'cmdGetOrderItems
        '
        Me.cmdGetOrderItems.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance13.BackColor = System.Drawing.Color.Transparent
        Me.cmdGetOrderItems.Appearance = Appearance13
        Me.cmdGetOrderItems.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdGetOrderItems.Location = New System.Drawing.Point(978, 206)
        Me.cmdGetOrderItems.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.cmdGetOrderItems.Name = "cmdGetOrderItems"
        Me.cmdGetOrderItems.ShowFocusRect = False
        Me.cmdGetOrderItems.ShowOutline = False
        Me.cmdGetOrderItems.Size = New System.Drawing.Size(145, 40)
        Me.cmdGetOrderItems.TabIndex = 478
        Me.cmdGetOrderItems.Text = "Get details"
        '
        'lblStatusBar
        '
        Me.lblStatusBar.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Appearance7.BorderColor = System.Drawing.Color.Maroon
        Appearance7.ForeColor = System.Drawing.Color.Maroon
        Appearance7.TextHAlignAsString = "Center"
        Me.lblStatusBar.Appearance = Appearance7
        Me.lblStatusBar.BorderStyleInner = Infragistics.Win.UIElementBorderStyle.Solid
        Me.lblStatusBar.BorderStyleOuter = Infragistics.Win.UIElementBorderStyle.Solid
        Me.lblStatusBar.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStatusBar.Location = New System.Drawing.Point(364, 15)
        Me.lblStatusBar.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.lblStatusBar.Name = "lblStatusBar"
        Me.lblStatusBar.Size = New System.Drawing.Size(406, 25)
        Me.lblStatusBar.TabIndex = 508
        Me.lblStatusBar.Text = "AUTO-PRINTING - WAIT..."
        Me.lblStatusBar.UseAppStyling = False
        Me.lblStatusBar.Visible = False
        '
        'chkAutoPrint
        '
        Me.chkAutoPrint.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Appearance14.FontData.Name = "Verdana"
        Appearance14.FontData.SizeInPoints = 9.0!
        Me.chkAutoPrint.Appearance = Appearance14
        Me.chkAutoPrint.AutoSize = True
        Me.chkAutoPrint.BackColor = System.Drawing.Color.Transparent
        Me.chkAutoPrint.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkAutoPrint.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkAutoPrint.Location = New System.Drawing.Point(65, 582)
        Me.chkAutoPrint.Name = "chkAutoPrint"
        Me.chkAutoPrint.Size = New System.Drawing.Size(134, 20)
        Me.chkAutoPrint.TabIndex = 507
        Me.chkAutoPrint.Text = "Auto-print orders:"
        Me.chkAutoPrint.UseAppStyling = False
        '
        'lblUpdateIntervalLabel
        '
        Me.lblUpdateIntervalLabel.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Appearance15.BackColor = System.Drawing.Color.Transparent
        Appearance15.TextHAlignAsString = "Right"
        Me.lblUpdateIntervalLabel.Appearance = Appearance15
        Me.lblUpdateIntervalLabel.AutoSize = True
        Me.lblUpdateIntervalLabel.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUpdateIntervalLabel.Location = New System.Drawing.Point(32, 561)
        Me.lblUpdateIntervalLabel.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.lblUpdateIntervalLabel.Name = "lblUpdateIntervalLabel"
        Me.lblUpdateIntervalLabel.Size = New System.Drawing.Size(151, 17)
        Me.lblUpdateIntervalLabel.TabIndex = 501
        Me.lblUpdateIntervalLabel.Text = "Update interval (mins):"
        Me.lblUpdateIntervalLabel.UseAppStyling = False
        '
        'cmbTimeInterval
        '
        Me.cmbTimeInterval.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Appearance16.BackColor = System.Drawing.Color.Transparent
        Me.cmbTimeInterval.Appearance = Appearance16
        Me.cmbTimeInterval.BackColor = System.Drawing.Color.Transparent
        Me.cmbTimeInterval.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList
        Me.cmbTimeInterval.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbTimeInterval.Location = New System.Drawing.Point(189, 557)
        Me.cmbTimeInterval.Name = "cmbTimeInterval"
        Me.cmbTimeInterval.Size = New System.Drawing.Size(58, 22)
        Me.cmbTimeInterval.TabIndex = 500
        Me.cmbTimeInterval.UseAppStyling = False
        '
        'lblNextUpdate
        '
        Me.lblNextUpdate.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Appearance17.BackColor = System.Drawing.Color.Transparent
        Appearance17.TextHAlignAsString = "Right"
        Me.lblNextUpdate.Appearance = Appearance17
        Me.lblNextUpdate.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNextUpdate.Location = New System.Drawing.Point(12, 523)
        Me.lblNextUpdate.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.lblNextUpdate.Name = "lblNextUpdate"
        Me.lblNextUpdate.Size = New System.Drawing.Size(172, 19)
        Me.lblNextUpdate.TabIndex = 499
        Me.lblNextUpdate.Text = "Next update:"
        Me.lblNextUpdate.UseAppStyling = False
        '
        'lblLastUpdate
        '
        Me.lblLastUpdate.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Appearance18.BackColor = System.Drawing.Color.Transparent
        Appearance18.TextHAlignAsString = "Right"
        Me.lblLastUpdate.Appearance = Appearance18
        Me.lblLastUpdate.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLastUpdate.Location = New System.Drawing.Point(12, 508)
        Me.lblLastUpdate.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.lblLastUpdate.Name = "lblLastUpdate"
        Me.lblLastUpdate.Size = New System.Drawing.Size(172, 19)
        Me.lblLastUpdate.TabIndex = 498
        Me.lblLastUpdate.Text = "Last update:"
        Me.lblLastUpdate.UseAppStyling = False
        '
        'lblClock
        '
        Me.lblClock.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Appearance19.BackColor = System.Drawing.Color.Transparent
        Appearance19.TextHAlignAsString = "Right"
        Me.lblClock.Appearance = Appearance19
        Me.lblClock.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblClock.Location = New System.Drawing.Point(12, 493)
        Me.lblClock.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.lblClock.Name = "lblClock"
        Me.lblClock.Size = New System.Drawing.Size(172, 19)
        Me.lblClock.TabIndex = 497
        Me.lblClock.Text = "Time now:"
        Me.lblClock.UseAppStyling = False
        '
        'ugdOrderItems
        '
        Me.ugdOrderItems.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance20.BackColor = System.Drawing.SystemColors.Window
        Appearance20.BorderColor = System.Drawing.SystemColors.InactiveCaption
        Me.ugdOrderItems.DisplayLayout.Appearance = Appearance20
        UltraGridBand1.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.[False]
        Me.ugdOrderItems.DisplayLayout.BandsSerializer.Add(UltraGridBand1)
        Me.ugdOrderItems.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Me.ugdOrderItems.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.[False]
        Appearance21.BackColor = System.Drawing.SystemColors.ActiveBorder
        Appearance21.BackColor2 = System.Drawing.SystemColors.ControlDark
        Appearance21.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance21.BorderColor = System.Drawing.SystemColors.Window
        Me.ugdOrderItems.DisplayLayout.GroupByBox.Appearance = Appearance21
        Appearance22.ForeColor = System.Drawing.SystemColors.GrayText
        Me.ugdOrderItems.DisplayLayout.GroupByBox.BandLabelAppearance = Appearance22
        Me.ugdOrderItems.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Appearance23.BackColor = System.Drawing.SystemColors.ControlLightLight
        Appearance23.BackColor2 = System.Drawing.SystemColors.Control
        Appearance23.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal
        Appearance23.ForeColor = System.Drawing.SystemColors.GrayText
        Me.ugdOrderItems.DisplayLayout.GroupByBox.PromptAppearance = Appearance23
        Me.ugdOrderItems.DisplayLayout.MaxColScrollRegions = 1
        Me.ugdOrderItems.DisplayLayout.MaxRowScrollRegions = 1
        Appearance24.BackColor = System.Drawing.SystemColors.Window
        Appearance24.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ugdOrderItems.DisplayLayout.Override.ActiveCellAppearance = Appearance24
        Appearance25.BackColor = System.Drawing.SystemColors.Highlight
        Appearance25.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.ugdOrderItems.DisplayLayout.Override.ActiveRowAppearance = Appearance25
        Me.ugdOrderItems.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted
        Me.ugdOrderItems.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted
        Appearance26.BackColor = System.Drawing.SystemColors.Window
        Me.ugdOrderItems.DisplayLayout.Override.CardAreaAppearance = Appearance26
        Appearance27.BorderColor = System.Drawing.Color.Silver
        Appearance27.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter
        Me.ugdOrderItems.DisplayLayout.Override.CellAppearance = Appearance27
        Me.ugdOrderItems.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.EditAndSelectText
        Me.ugdOrderItems.DisplayLayout.Override.CellPadding = 0
        Appearance28.BackColor = System.Drawing.SystemColors.Control
        Appearance28.BackColor2 = System.Drawing.SystemColors.ControlDark
        Appearance28.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element
        Appearance28.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal
        Appearance28.BorderColor = System.Drawing.SystemColors.Window
        Me.ugdOrderItems.DisplayLayout.Override.GroupByRowAppearance = Appearance28
        Appearance29.TextHAlignAsString = "Left"
        Me.ugdOrderItems.DisplayLayout.Override.HeaderAppearance = Appearance29
        Me.ugdOrderItems.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti
        Me.ugdOrderItems.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand
        Appearance30.BackColor = System.Drawing.Color.FromArgb(CType(CType(252, Byte), Integer), CType(CType(252, Byte), Integer), CType(CType(252, Byte), Integer))
        Me.ugdOrderItems.DisplayLayout.Override.RowAlternateAppearance = Appearance30
        Appearance31.BackColor = System.Drawing.Color.FromArgb(CType(CType(247, Byte), Integer), CType(CType(247, Byte), Integer), CType(CType(247, Byte), Integer))
        Appearance31.BorderColor = System.Drawing.Color.Silver
        Me.ugdOrderItems.DisplayLayout.Override.RowAppearance = Appearance31
        Me.ugdOrderItems.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.[False]
        Appearance32.BackColor = System.Drawing.SystemColors.ControlLight
        Me.ugdOrderItems.DisplayLayout.Override.TemplateAddRowAppearance = Appearance32
        Me.ugdOrderItems.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill
        Me.ugdOrderItems.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate
        Me.ugdOrderItems.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ugdOrderItems.Location = New System.Drawing.Point(12, 240)
        Me.ugdOrderItems.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.ugdOrderItems.Name = "ugdOrderItems"
        Me.ugdOrderItems.Size = New System.Drawing.Size(953, 239)
        Me.ugdOrderItems.TabIndex = 496
        Me.ugdOrderItems.Text = "UltraGrid2"
        Me.ugdOrderItems.UseAppStyling = False
        Me.ugdOrderItems.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'ugdOrders
        '
        Me.ugdOrders.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance33.BackColor = System.Drawing.SystemColors.Window
        Appearance33.BorderColor = System.Drawing.SystemColors.InactiveCaption
        Me.ugdOrders.DisplayLayout.Appearance = Appearance33
        Me.ugdOrders.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Me.ugdOrders.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.[False]
        Appearance34.BackColor = System.Drawing.SystemColors.ActiveBorder
        Appearance34.BackColor2 = System.Drawing.SystemColors.ControlDark
        Appearance34.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance34.BorderColor = System.Drawing.SystemColors.Window
        Me.ugdOrders.DisplayLayout.GroupByBox.Appearance = Appearance34
        Appearance35.ForeColor = System.Drawing.SystemColors.GrayText
        Me.ugdOrders.DisplayLayout.GroupByBox.BandLabelAppearance = Appearance35
        Me.ugdOrders.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Appearance36.BackColor = System.Drawing.SystemColors.ControlLightLight
        Appearance36.BackColor2 = System.Drawing.SystemColors.Control
        Appearance36.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal
        Appearance36.ForeColor = System.Drawing.SystemColors.GrayText
        Me.ugdOrders.DisplayLayout.GroupByBox.PromptAppearance = Appearance36
        Me.ugdOrders.DisplayLayout.MaxColScrollRegions = 1
        Me.ugdOrders.DisplayLayout.MaxRowScrollRegions = 1
        Appearance37.BackColor = System.Drawing.SystemColors.Window
        Appearance37.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ugdOrders.DisplayLayout.Override.ActiveCellAppearance = Appearance37
        Appearance38.BackColor = System.Drawing.SystemColors.Highlight
        Appearance38.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.ugdOrders.DisplayLayout.Override.ActiveRowAppearance = Appearance38
        Me.ugdOrders.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted
        Me.ugdOrders.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted
        Appearance39.BackColor = System.Drawing.SystemColors.Window
        Me.ugdOrders.DisplayLayout.Override.CardAreaAppearance = Appearance39
        Appearance40.BorderColor = System.Drawing.Color.Silver
        Appearance40.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter
        Me.ugdOrders.DisplayLayout.Override.CellAppearance = Appearance40
        Me.ugdOrders.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.EditAndSelectText
        Me.ugdOrders.DisplayLayout.Override.CellPadding = 0
        Appearance41.BackColor = System.Drawing.SystemColors.Control
        Appearance41.BackColor2 = System.Drawing.SystemColors.ControlDark
        Appearance41.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element
        Appearance41.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal
        Appearance41.BorderColor = System.Drawing.SystemColors.Window
        Me.ugdOrders.DisplayLayout.Override.GroupByRowAppearance = Appearance41
        Appearance42.TextHAlignAsString = "Left"
        Me.ugdOrders.DisplayLayout.Override.HeaderAppearance = Appearance42
        Me.ugdOrders.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti
        Me.ugdOrders.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand
        Appearance43.BackColor = System.Drawing.Color.FromArgb(CType(CType(252, Byte), Integer), CType(CType(252, Byte), Integer), CType(CType(252, Byte), Integer))
        Me.ugdOrders.DisplayLayout.Override.RowAlternateAppearance = Appearance43
        Appearance44.BackColor = System.Drawing.Color.FromArgb(CType(CType(247, Byte), Integer), CType(CType(247, Byte), Integer), CType(CType(247, Byte), Integer))
        Appearance44.BorderColor = System.Drawing.Color.Silver
        Me.ugdOrders.DisplayLayout.Override.RowAppearance = Appearance44
        Me.ugdOrders.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.[False]
        Appearance45.BackColor = System.Drawing.SystemColors.ControlLight
        Me.ugdOrders.DisplayLayout.Override.TemplateAddRowAppearance = Appearance45
        Me.ugdOrders.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill
        Me.ugdOrders.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate
        Me.ugdOrders.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ugdOrders.Location = New System.Drawing.Point(12, 47)
        Me.ugdOrders.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.ugdOrders.Name = "ugdOrders"
        Me.ugdOrders.Size = New System.Drawing.Size(953, 185)
        Me.ugdOrders.TabIndex = 492
        Me.ugdOrders.Text = "UltraGrid1"
        Me.ugdOrders.UseAppStyling = False
        '
        'tmrCheckOnline
        '
        Me.tmrCheckOnline.Interval = 30000
        '
        'tmrTimeNow
        '
        Me.tmrTimeNow.Enabled = True
        Me.tmrTimeNow.Interval = 1000
        '
        'cmdFetchToday
        '
        Me.cmdFetchToday.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance46.BackColor = System.Drawing.Color.Transparent
        Me.cmdFetchToday.Appearance = Appearance46
        Me.cmdFetchToday.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdFetchToday.Location = New System.Drawing.Point(978, 158)
        Me.cmdFetchToday.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.cmdFetchToday.Name = "cmdFetchToday"
        Me.cmdFetchToday.ShowFocusRect = False
        Me.cmdFetchToday.ShowOutline = False
        Me.cmdFetchToday.Size = New System.Drawing.Size(145, 40)
        Me.cmdFetchToday.TabIndex = 516
        Me.cmdFetchToday.Text = "Today's Orders"
        '
        'cmdHide
        '
        Me.cmdHide.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance4.BackColor = System.Drawing.Color.Transparent
        Appearance4.BackColor2 = System.Drawing.Color.Transparent
        Appearance4.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance4.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance4.BorderColor = System.Drawing.Color.Transparent
        Appearance4.BorderColor2 = System.Drawing.Color.Maroon
        Appearance4.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance4.ForeColor = System.Drawing.Color.White
        Appearance4.Image = CType(resources.GetObject("Appearance4.Image"), Object)
        Appearance4.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance4.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance4.TextVAlignAsString = "Bottom"
        Me.cmdHide.Appearance = Appearance4
        Me.cmdHide.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdHide.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance5.BackColor = System.Drawing.Color.DarkOrange
        Appearance5.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance5.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance5.BorderColor = System.Drawing.Color.Transparent
        Appearance5.ForeColor = System.Drawing.Color.Black
        Me.cmdHide.HotTrackAppearance = Appearance5
        Me.cmdHide.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdHide.Location = New System.Drawing.Point(1066, 3)
        Me.cmdHide.Name = "cmdHide"
        Me.cmdHide.Padding = New System.Drawing.Size(15, 0)
        Appearance6.BackColor = System.Drawing.Color.OrangeRed
        Appearance6.BackColor2 = System.Drawing.Color.Tomato
        Appearance6.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance6.BorderColor = System.Drawing.Color.Transparent
        Me.cmdHide.PressedAppearance = Appearance6
        Me.cmdHide.ShowFocusRect = False
        Me.cmdHide.ShowOutline = False
        Me.cmdHide.Size = New System.Drawing.Size(64, 44)
        Me.cmdHide.StyleSetName = "StatusBar"
        Me.cmdHide.TabIndex = 559
        Me.cmdHide.Tag = "Return"
        Me.cmdHide.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdHide.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdHide.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'chkBringToFront
        '
        Me.chkBringToFront.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Appearance47.FontData.Name = "Verdana"
        Appearance47.FontData.SizeInPoints = 9.0!
        Me.chkBringToFront.Appearance = Appearance47
        Me.chkBringToFront.AutoSize = True
        Me.chkBringToFront.BackColor = System.Drawing.Color.Transparent
        Me.chkBringToFront.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkBringToFront.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkBringToFront.Location = New System.Drawing.Point(12, 604)
        Me.chkBringToFront.Name = "chkBringToFront"
        Me.chkBringToFront.Size = New System.Drawing.Size(187, 20)
        Me.chkBringToFront.TabIndex = 551
        Me.chkBringToFront.Text = "Auto-focus on new orders:"
        Me.chkBringToFront.UseAppStyling = False
        '
        'cmdSendToBack
        '
        Me.cmdSendToBack.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Appearance1.BackColor = System.Drawing.Color.Transparent
        Appearance1.BackColor2 = System.Drawing.Color.Transparent
        Appearance1.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance1.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance1.BorderColor2 = System.Drawing.Color.Maroon
        Appearance1.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance1.ForeColor = System.Drawing.Color.Black
        Appearance1.Image = CType(resources.GetObject("Appearance1.Image"), Object)
        Appearance1.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance1.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance1.TextVAlignAsString = "Bottom"
        Me.cmdSendToBack.Appearance = Appearance1
        Me.cmdSendToBack.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdSendToBack.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance2.BackColor = System.Drawing.Color.DarkOrange
        Appearance2.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance2.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance2.BorderColor = System.Drawing.Color.Transparent
        Appearance2.ForeColor = System.Drawing.Color.Black
        Me.cmdSendToBack.HotTrackAppearance = Appearance2
        Me.cmdSendToBack.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdSendToBack.Location = New System.Drawing.Point(12, 3)
        Me.cmdSendToBack.Name = "cmdSendToBack"
        Me.cmdSendToBack.Padding = New System.Drawing.Size(15, 0)
        Appearance3.BackColor = System.Drawing.Color.OrangeRed
        Appearance3.BackColor2 = System.Drawing.Color.Tomato
        Appearance3.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance3.BorderColor = System.Drawing.Color.Transparent
        Me.cmdSendToBack.PressedAppearance = Appearance3
        Me.cmdSendToBack.ShowFocusRect = False
        Me.cmdSendToBack.ShowOutline = False
        Me.cmdSendToBack.Size = New System.Drawing.Size(64, 44)
        Me.cmdSendToBack.StyleSetName = "StatusBar"
        Me.cmdSendToBack.TabIndex = 582
        Me.cmdSendToBack.Tag = "Back"
        Me.cmdSendToBack.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdSendToBack.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdSendToBack.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdTestConn
        '
        Me.cmdTestConn.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance48.BackColor = System.Drawing.Color.Transparent
        Me.cmdTestConn.Appearance = Appearance48
        Me.cmdTestConn.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdTestConn.Location = New System.Drawing.Point(978, 347)
        Me.cmdTestConn.Name = "cmdTestConn"
        Me.cmdTestConn.ShowFocusRect = False
        Me.cmdTestConn.ShowOutline = False
        Me.cmdTestConn.Size = New System.Drawing.Size(145, 40)
        Me.cmdTestConn.TabIndex = 488
        Me.cmdTestConn.Text = "Test connection"
        '
        'frmOnlineOrders
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1135, 684)
        Me.Controls.Add(Me.chkBringToFront)
        Me.Controls.Add(Me.cmdFetchToday)
        Me.Controls.Add(Me.chkAutoPrint)
        Me.Controls.Add(Me.lblUpdateIntervalLabel)
        Me.Controls.Add(Me.cmbTimeInterval)
        Me.Controls.Add(Me.lblNextUpdate)
        Me.Controls.Add(Me.lblLastUpdate)
        Me.Controls.Add(Me.lblClock)
        Me.Controls.Add(Me.ugdOrderItems)
        Me.Controls.Add(Me.ugdOrders)
        Me.Controls.Add(Me.cmdDown)
        Me.Controls.Add(Me.cmdUp)
        Me.Controls.Add(Me.cmdTestConn)
        Me.Controls.Add(Me.cmdClearGrids)
        Me.Controls.Add(Me.cmdStartTimer)
        Me.Controls.Add(Me.cmdPrintOrder)
        Me.Controls.Add(Me.cmdGetOrderItems)
        Me.Name = "frmOnlineOrders"
        Me.ShowInTaskbar = True
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Controls.SetChildIndex(Me.cmdGetOrderItems, 0)
        Me.Controls.SetChildIndex(Me.cmdPrintOrder, 0)
        Me.Controls.SetChildIndex(Me.cmdStartTimer, 0)
        Me.Controls.SetChildIndex(Me.cmdClearGrids, 0)
        Me.Controls.SetChildIndex(Me.cmdTestConn, 0)
        Me.Controls.SetChildIndex(Me.cmdUp, 0)
        Me.Controls.SetChildIndex(Me.cmdDown, 0)
        Me.Controls.SetChildIndex(Me.ugdOrders, 0)
        Me.Controls.SetChildIndex(Me.ugdOrderItems, 0)
        Me.Controls.SetChildIndex(Me.lblClock, 0)
        Me.Controls.SetChildIndex(Me.lblLastUpdate, 0)
        Me.Controls.SetChildIndex(Me.lblNextUpdate, 0)
        Me.Controls.SetChildIndex(Me.cmbTimeInterval, 0)
        Me.Controls.SetChildIndex(Me.lblUpdateIntervalLabel, 0)
        Me.Controls.SetChildIndex(Me.chkAutoPrint, 0)
        Me.Controls.SetChildIndex(Me.cmdFetchToday, 0)
        Me.Controls.SetChildIndex(Me.chkBringToFront, 0)
        Me.Controls.SetChildIndex(Me.uplBasePanel, 0)
        Me.uplBasePanel.ClientArea.ResumeLayout(False)
        Me.uplBasePanel.ResumeLayout(False)
        CType(Me.chkAutoPrint, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbTimeInterval, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ugdOrderItems, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ugdOrders, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkBringToFront, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents cmdDown As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdUp As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdClearGrids As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdStartTimer As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdPrintOrder As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdGetOrderItems As Infragistics.Win.Misc.UltraButton
    Friend WithEvents lblStatusBar As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents chkAutoPrint As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents lblUpdateIntervalLabel As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents cmbTimeInterval As Infragistics.Win.UltraWinEditors.UltraComboEditor
    Friend WithEvents lblNextUpdate As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblLastUpdate As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblClock As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents ugdOrderItems As Infragistics.Win.UltraWinGrid.UltraGrid
    Friend WithEvents ugdOrders As Infragistics.Win.UltraWinGrid.UltraGrid
    Friend WithEvents tmrCheckOnline As System.Windows.Forms.Timer
    Friend WithEvents tmrTimeNow As System.Windows.Forms.Timer
    Friend WithEvents cmdFetchToday As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdHide As Infragistics.Win.Misc.UltraButton
    Friend WithEvents chkBringToFront As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents cmdSendToBack As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdTestConn As Infragistics.Win.Misc.UltraButton
End Class
