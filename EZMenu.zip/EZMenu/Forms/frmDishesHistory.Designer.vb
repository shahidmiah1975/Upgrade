﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDishesHistory
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim Appearance110 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmDishesHistory))
        Dim Appearance111 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance112 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance3 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance6 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance7 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance4 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance75 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance76 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance14 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance11 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance32 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraGridBand1 As Infragistics.Win.UltraWinGrid.UltraGridBand = New Infragistics.Win.UltraWinGrid.UltraGridBand("Band 0", -1)
        Dim UltraGridColumn1 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Date")
        Dim UltraGridColumn2 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Dish")
        Dim UltraGridColumn3 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Pickup")
        Dim UltraGridColumn4 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Delivery")
        Dim UltraGridColumn5 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Table")
        Dim UltraGridColumn6 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Total")
        Dim Appearance1 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance2 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance36 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance37 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance38 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance39 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance40 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance41 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance42 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance70 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance44 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance45 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraDataColumn1 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("Date")
        Dim UltraDataColumn2 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("Dish")
        Dim UltraDataColumn3 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("Pickup")
        Dim UltraDataColumn4 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("Delivery")
        Dim UltraDataColumn5 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("Table")
        Dim UltraDataColumn6 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("Total")
        Dim Appearance5 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance8 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance9 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance90 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance91 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance92 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance10 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance15 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance16 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance57 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance58 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance59 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Me.cmdOEHome = New Infragistics.Win.Misc.UltraButton()
        Me.cmdKBPrintEnd = New Infragistics.Win.Misc.UltraButton()
        Me.txtEndDate = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cmdKBPrintStart = New Infragistics.Win.Misc.UltraButton()
        Me.txtStartDate = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.UltraCalendarLook1 = New Infragistics.Win.UltraWinSchedule.UltraCalendarLook(Me.components)
        Me.ugdDishesHistory = New Infragistics.Win.UltraWinGrid.UltraGrid()
        Me.udsDishesHistory = New Infragistics.Win.UltraWinDataSource.UltraDataSource(Me.components)
        Me.cmdOK = New Infragistics.Win.Misc.UltraButton()
        Me.cmdClear = New Infragistics.Win.Misc.UltraButton()
        Me.lblNumRecords = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.cmdDelHistoryAll = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDelHistoryDated = New Infragistics.Win.Misc.UltraButton()
        CType(Me.txtEndDate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtStartDate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ugdDishesHistory, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.udsDishesHistory, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'cmdOEHome
        '
        Appearance110.BackColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance110.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance110.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance110.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance110.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance110.BorderColor2 = System.Drawing.Color.Maroon
        Appearance110.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance110.ForeColor = System.Drawing.Color.Black
        Appearance110.Image = CType(resources.GetObject("Appearance110.Image"), Object)
        Appearance110.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance110.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance110.TextVAlignAsString = "Bottom"
        Me.cmdOEHome.Appearance = Appearance110
        Me.cmdOEHome.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance111.BackColor = System.Drawing.Color.DarkOrange
        Appearance111.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance111.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance111.ForeColor = System.Drawing.Color.Black
        Me.cmdOEHome.HotTrackAppearance = Appearance111
        Me.cmdOEHome.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdOEHome.Location = New System.Drawing.Point(907, 632)
        Me.cmdOEHome.Name = "cmdOEHome"
        Appearance112.BackColor = System.Drawing.Color.OrangeRed
        Appearance112.BackColor2 = System.Drawing.Color.Tomato
        Appearance112.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdOEHome.PressedAppearance = Appearance112
        Me.cmdOEHome.ShowFocusRect = False
        Me.cmdOEHome.ShowOutline = False
        Me.cmdOEHome.Size = New System.Drawing.Size(70, 60)
        Me.cmdOEHome.TabIndex = 492
        Me.cmdOEHome.Tag = "Return"
        Me.cmdOEHome.UseAppStyling = False
        Me.cmdOEHome.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOEHome.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOEHome.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdKBPrintEnd
        '
        Appearance3.BackColor = System.Drawing.Color.Transparent
        Appearance3.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance3.BackGradientStyle = Infragistics.Win.GradientStyle.None
        Appearance3.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance3.BorderColor = System.Drawing.Color.Transparent
        Appearance3.BorderColor2 = System.Drawing.Color.Transparent
        Appearance3.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance3.ForeColor = System.Drawing.Color.Black
        Appearance3.Image = CType(resources.GetObject("Appearance3.Image"), Object)
        Appearance3.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance3.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance3.TextVAlignAsString = "Bottom"
        Me.cmdKBPrintEnd.Appearance = Appearance3
        Me.cmdKBPrintEnd.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdKBPrintEnd.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance6.BackColor = System.Drawing.Color.DarkOrange
        Appearance6.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance6.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance6.ForeColor = System.Drawing.Color.Black
        Me.cmdKBPrintEnd.HotTrackAppearance = Appearance6
        Me.cmdKBPrintEnd.ImageSize = New System.Drawing.Size(42, 25)
        Me.cmdKBPrintEnd.Location = New System.Drawing.Point(210, 241)
        Me.cmdKBPrintEnd.Name = "cmdKBPrintEnd"
        Appearance7.BackColor = System.Drawing.Color.Transparent
        Appearance7.BackColor2 = System.Drawing.Color.Transparent
        Me.cmdKBPrintEnd.PressedAppearance = Appearance7
        Me.cmdKBPrintEnd.ShowFocusRect = False
        Me.cmdKBPrintEnd.ShowOutline = False
        Me.cmdKBPrintEnd.Size = New System.Drawing.Size(42, 25)
        Me.cmdKBPrintEnd.TabIndex = 541
        Me.cmdKBPrintEnd.Tag = "Keyboard"
        Me.cmdKBPrintEnd.UseAppStyling = False
        Me.cmdKBPrintEnd.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBPrintEnd.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdKBPrintEnd.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtEndDate
        '
        Appearance4.TextHAlignAsString = "Right"
        Me.txtEndDate.Appearance = Appearance4
        Me.txtEndDate.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEndDate.Location = New System.Drawing.Point(90, 240)
        Me.txtEndDate.Name = "txtEndDate"
        Me.txtEndDate.Size = New System.Drawing.Size(114, 27)
        Me.txtEndDate.TabIndex = 540
        Me.txtEndDate.Text = "01/11/10"
        Me.txtEndDate.UseAppStyling = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(40, 244)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(28, 18)
        Me.Label2.TabIndex = 539
        Me.Label2.Text = "To:"
        '
        'cmdKBPrintStart
        '
        Appearance75.BackColor = System.Drawing.Color.Transparent
        Appearance75.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance75.BackGradientStyle = Infragistics.Win.GradientStyle.None
        Appearance75.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance75.BorderColor = System.Drawing.Color.Transparent
        Appearance75.BorderColor2 = System.Drawing.Color.Transparent
        Appearance75.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance75.ForeColor = System.Drawing.Color.Black
        Appearance75.Image = CType(resources.GetObject("Appearance75.Image"), Object)
        Appearance75.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance75.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance75.TextVAlignAsString = "Bottom"
        Me.cmdKBPrintStart.Appearance = Appearance75
        Me.cmdKBPrintStart.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdKBPrintStart.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance76.BackColor = System.Drawing.Color.DarkOrange
        Appearance76.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance76.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance76.ForeColor = System.Drawing.Color.Black
        Me.cmdKBPrintStart.HotTrackAppearance = Appearance76
        Me.cmdKBPrintStart.ImageSize = New System.Drawing.Size(42, 25)
        Me.cmdKBPrintStart.Location = New System.Drawing.Point(210, 198)
        Me.cmdKBPrintStart.Name = "cmdKBPrintStart"
        Appearance14.BackColor = System.Drawing.Color.Transparent
        Appearance14.BackColor2 = System.Drawing.Color.Transparent
        Me.cmdKBPrintStart.PressedAppearance = Appearance14
        Me.cmdKBPrintStart.ShowFocusRect = False
        Me.cmdKBPrintStart.ShowOutline = False
        Me.cmdKBPrintStart.Size = New System.Drawing.Size(42, 25)
        Me.cmdKBPrintStart.TabIndex = 538
        Me.cmdKBPrintStart.Tag = "Keyboard"
        Me.cmdKBPrintStart.UseAppStyling = False
        Me.cmdKBPrintStart.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBPrintStart.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdKBPrintStart.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtStartDate
        '
        Appearance11.TextHAlignAsString = "Right"
        Me.txtStartDate.Appearance = Appearance11
        Me.txtStartDate.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtStartDate.Location = New System.Drawing.Point(90, 197)
        Me.txtStartDate.Name = "txtStartDate"
        Me.txtStartDate.Size = New System.Drawing.Size(114, 27)
        Me.txtStartDate.TabIndex = 537
        Me.txtStartDate.Text = "02/04/10"
        Me.txtStartDate.UseAppStyling = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(40, 201)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(49, 18)
        Me.Label3.TabIndex = 536
        Me.Label3.Text = "From:"
        '
        'UltraCalendarLook1
        '
        Me.UltraCalendarLook1.ViewStyle = Infragistics.Win.UltraWinSchedule.ViewStyle.Office2003
        '
        'ugdDishesHistory
        '
        Me.ugdDishesHistory.DataSource = Me.udsDishesHistory
        Appearance32.BackColor = System.Drawing.Color.Transparent
        Appearance32.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Me.ugdDishesHistory.DisplayLayout.Appearance = Appearance32
        UltraGridColumn1.Header.VisiblePosition = 0
        UltraGridColumn2.Header.VisiblePosition = 1
        UltraGridColumn2.Width = 161
        UltraGridColumn3.Header.VisiblePosition = 2
        UltraGridColumn4.Header.VisiblePosition = 3
        UltraGridColumn5.Header.VisiblePosition = 4
        UltraGridColumn6.Header.VisiblePosition = 5
        UltraGridBand1.Columns.AddRange(New Object() {UltraGridColumn1, UltraGridColumn2, UltraGridColumn3, UltraGridColumn4, UltraGridColumn5, UltraGridColumn6})
        Appearance1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        UltraGridBand1.Header.Appearance = Appearance1
        Appearance2.BackColor = System.Drawing.Color.DarkOrange
        Appearance2.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance2.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        UltraGridBand1.Override.ActiveRowAppearance = Appearance2
        UltraGridBand1.Override.AllowAddNew = Infragistics.Win.UltraWinGrid.AllowAddNew.Yes
        Me.ugdDishesHistory.DisplayLayout.BandsSerializer.Add(UltraGridBand1)
        Me.ugdDishesHistory.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Me.ugdDishesHistory.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.[False]
        Appearance36.BackColor = System.Drawing.SystemColors.ActiveBorder
        Appearance36.BackColor2 = System.Drawing.SystemColors.ControlDark
        Appearance36.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance36.BorderColor = System.Drawing.SystemColors.Window
        Me.ugdDishesHistory.DisplayLayout.GroupByBox.Appearance = Appearance36
        Appearance37.ForeColor = System.Drawing.SystemColors.GrayText
        Me.ugdDishesHistory.DisplayLayout.GroupByBox.BandLabelAppearance = Appearance37
        Me.ugdDishesHistory.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Appearance38.BackColor = System.Drawing.SystemColors.ControlLightLight
        Appearance38.BackColor2 = System.Drawing.SystemColors.Control
        Appearance38.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal
        Appearance38.ForeColor = System.Drawing.SystemColors.GrayText
        Me.ugdDishesHistory.DisplayLayout.GroupByBox.PromptAppearance = Appearance38
        Me.ugdDishesHistory.DisplayLayout.MaxColScrollRegions = 1
        Me.ugdDishesHistory.DisplayLayout.MaxRowScrollRegions = 1
        Me.ugdDishesHistory.DisplayLayout.Override.AllowColMoving = Infragistics.Win.UltraWinGrid.AllowColMoving.NotAllowed
        Me.ugdDishesHistory.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted
        Me.ugdDishesHistory.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted
        Appearance39.BackColor = System.Drawing.SystemColors.Window
        Me.ugdDishesHistory.DisplayLayout.Override.CardAreaAppearance = Appearance39
        Appearance40.BorderColor = System.Drawing.Color.Silver
        Appearance40.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter
        Me.ugdDishesHistory.DisplayLayout.Override.CellAppearance = Appearance40
        Me.ugdDishesHistory.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.EditAndSelectText
        Me.ugdDishesHistory.DisplayLayout.Override.CellPadding = 0
        Appearance41.BackColor = System.Drawing.SystemColors.Control
        Appearance41.BackColor2 = System.Drawing.SystemColors.ControlDark
        Appearance41.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element
        Appearance41.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal
        Appearance41.BorderColor = System.Drawing.SystemColors.Window
        Me.ugdDishesHistory.DisplayLayout.Override.GroupByRowAppearance = Appearance41
        Appearance42.BackColor = System.Drawing.Color.FromArgb(CType(CType(162, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance42.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(162, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance42.TextHAlignAsString = "Center"
        Me.ugdDishesHistory.DisplayLayout.Override.HeaderAppearance = Appearance42
        Me.ugdDishesHistory.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti
        Me.ugdDishesHistory.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand
        Appearance70.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.ugdDishesHistory.DisplayLayout.Override.RowAlternateAppearance = Appearance70
        Appearance44.BackColor = System.Drawing.Color.Gainsboro
        Me.ugdDishesHistory.DisplayLayout.Override.RowAppearance = Appearance44
        Me.ugdDishesHistory.DisplayLayout.Override.RowSelectorHeaderStyle = Infragistics.Win.UltraWinGrid.RowSelectorHeaderStyle.None
        Me.ugdDishesHistory.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.[False]
        Me.ugdDishesHistory.DisplayLayout.Override.RowSizing = Infragistics.Win.UltraWinGrid.RowSizing.Sychronized
        Me.ugdDishesHistory.DisplayLayout.Override.RowSizingArea = Infragistics.Win.UltraWinGrid.RowSizingArea.RowBordersOnly
        Me.ugdDishesHistory.DisplayLayout.Override.SelectTypeCol = Infragistics.Win.UltraWinGrid.SelectType.None
        Me.ugdDishesHistory.DisplayLayout.Override.SelectTypeRow = Infragistics.Win.UltraWinGrid.SelectType.[Single]
        Appearance45.BackColor = System.Drawing.SystemColors.ControlLight
        Me.ugdDishesHistory.DisplayLayout.Override.TemplateAddRowAppearance = Appearance45
        Me.ugdDishesHistory.DisplayLayout.Override.WrapHeaderText = Infragistics.Win.DefaultableBoolean.[True]
        Me.ugdDishesHistory.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill
        Me.ugdDishesHistory.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate
        Me.ugdDishesHistory.DisplayLayout.ViewStyle = Infragistics.Win.UltraWinGrid.ViewStyle.SingleBand
        Me.ugdDishesHistory.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ugdDishesHistory.Location = New System.Drawing.Point(365, 97)
        Me.ugdDishesHistory.Name = "ugdDishesHistory"
        Me.ugdDishesHistory.Size = New System.Drawing.Size(536, 576)
        Me.ugdDishesHistory.TabIndex = 542
        '
        'udsDishesHistory
        '
        UltraDataColumn1.DataType = GetType(Date)
        UltraDataColumn1.DefaultValue = New Date(CType(0, Long))
        UltraDataColumn2.DefaultValue = ""
        UltraDataColumn3.DataType = GetType(Short)
        UltraDataColumn3.DefaultValue = CType(0, Short)
        UltraDataColumn4.DataType = GetType(Short)
        UltraDataColumn4.DefaultValue = CType(0, Short)
        UltraDataColumn5.DataType = GetType(Short)
        UltraDataColumn5.DefaultValue = CType(0, Short)
        UltraDataColumn6.DataType = GetType(Short)
        UltraDataColumn6.DefaultValue = CType(0, Short)
        Me.udsDishesHistory.Band.Columns.AddRange(New Object() {UltraDataColumn1, UltraDataColumn2, UltraDataColumn3, UltraDataColumn4, UltraDataColumn5, UltraDataColumn6})
        '
        'cmdOK
        '
        Appearance5.BackColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance5.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance5.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance5.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance5.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance5.BorderColor2 = System.Drawing.Color.Maroon
        Appearance5.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance5.ForeColor = System.Drawing.Color.Black
        Appearance5.Image = CType(resources.GetObject("Appearance5.Image"), Object)
        Appearance5.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance5.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance5.TextVAlignAsString = "Bottom"
        Me.cmdOK.Appearance = Appearance5
        Me.cmdOK.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance8.BackColor = System.Drawing.Color.DarkOrange
        Appearance8.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance8.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance8.ForeColor = System.Drawing.Color.Black
        Me.cmdOK.HotTrackAppearance = Appearance8
        Me.cmdOK.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdOK.Location = New System.Drawing.Point(273, 188)
        Me.cmdOK.Name = "cmdOK"
        Appearance9.BackColor = System.Drawing.Color.OrangeRed
        Appearance9.BackColor2 = System.Drawing.Color.Tomato
        Appearance9.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdOK.PressedAppearance = Appearance9
        Me.cmdOK.ShowFocusRect = False
        Me.cmdOK.ShowOutline = False
        Me.cmdOK.Size = New System.Drawing.Size(65, 40)
        Me.cmdOK.TabIndex = 543
        Me.cmdOK.Tag = "OK"
        Me.cmdOK.UseAppStyling = False
        Me.cmdOK.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOK.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOK.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdClear
        '
        Appearance90.BackColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance90.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance90.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance90.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance90.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance90.BorderColor2 = System.Drawing.Color.Maroon
        Appearance90.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance90.ForeColor = System.Drawing.Color.Black
        Appearance90.Image = CType(resources.GetObject("Appearance90.Image"), Object)
        Appearance90.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance90.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance90.TextVAlignAsString = "Bottom"
        Me.cmdClear.Appearance = Appearance90
        Me.cmdClear.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance91.BackColor = System.Drawing.Color.DarkOrange
        Appearance91.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance91.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance91.ForeColor = System.Drawing.Color.Black
        Me.cmdClear.HotTrackAppearance = Appearance91
        Me.cmdClear.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdClear.Location = New System.Drawing.Point(273, 234)
        Me.cmdClear.Name = "cmdClear"
        Appearance92.BackColor = System.Drawing.Color.OrangeRed
        Appearance92.BackColor2 = System.Drawing.Color.Tomato
        Appearance92.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdClear.PressedAppearance = Appearance92
        Me.cmdClear.ShowFocusRect = False
        Me.cmdClear.ShowOutline = False
        Me.cmdClear.Size = New System.Drawing.Size(65, 40)
        Me.cmdClear.TabIndex = 544
        Me.cmdClear.Tag = "x"
        Me.cmdClear.UseAppStyling = False
        Me.cmdClear.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdClear.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdClear.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblNumRecords
        '
        Me.lblNumRecords.AutoSize = True
        Me.lblNumRecords.BackColor = System.Drawing.Color.Transparent
        Me.lblNumRecords.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNumRecords.ForeColor = System.Drawing.Color.White
        Me.lblNumRecords.Location = New System.Drawing.Point(362, 676)
        Me.lblNumRecords.Name = "lblNumRecords"
        Me.lblNumRecords.Size = New System.Drawing.Size(341, 17)
        Me.lblNumRecords.TabIndex = 555
        Me.lblNumRecords.Tag = "(only the recent 1000 records are shown by default)"
        Me.lblNumRecords.Text = "(only the recent 1000 records are shown by default)"
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(197, 51)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(606, 35)
        Me.Label4.TabIndex = 556
        Me.Label4.Text = "Select a date range to see the number of items sold during that period. Selecting" & _
    " the same value for From: and To: will display items for that particular date on" & _
    "ly."
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'cmdDelHistoryAll
        '
        Appearance10.BackColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance10.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance10.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance10.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance10.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance10.BorderColor2 = System.Drawing.Color.Maroon
        Appearance10.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance10.ForeColor = System.Drawing.Color.White
        Appearance10.Image = CType(resources.GetObject("Appearance10.Image"), Object)
        Appearance10.ImageHAlign = Infragistics.Win.HAlign.Left
        Appearance10.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance10.TextVAlignAsString = "Middle"
        Me.cmdDelHistoryAll.Appearance = Appearance10
        Me.cmdDelHistoryAll.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance15.BackColor = System.Drawing.Color.DarkOrange
        Appearance15.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance15.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance15.ForeColor = System.Drawing.Color.Black
        Me.cmdDelHistoryAll.HotTrackAppearance = Appearance15
        Me.cmdDelHistoryAll.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdDelHistoryAll.Location = New System.Drawing.Point(58, 628)
        Me.cmdDelHistoryAll.Name = "cmdDelHistoryAll"
        Appearance16.BackColor = System.Drawing.Color.OrangeRed
        Appearance16.BackColor2 = System.Drawing.Color.Tomato
        Appearance16.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdDelHistoryAll.PressedAppearance = Appearance16
        Me.cmdDelHistoryAll.ShowFocusRect = False
        Me.cmdDelHistoryAll.ShowOutline = False
        Me.cmdDelHistoryAll.Size = New System.Drawing.Size(241, 40)
        Me.cmdDelHistoryAll.TabIndex = 557
        Me.cmdDelHistoryAll.Tag = ""
        Me.cmdDelHistoryAll.Text = "Delete all history"
        Me.cmdDelHistoryAll.UseAppStyling = False
        Me.cmdDelHistoryAll.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDelHistoryAll.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDelHistoryAll.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDelHistoryDated
        '
        Appearance57.BackColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance57.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance57.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance57.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance57.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance57.BorderColor2 = System.Drawing.Color.Maroon
        Appearance57.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance57.ForeColor = System.Drawing.Color.White
        Appearance57.Image = CType(resources.GetObject("Appearance57.Image"), Object)
        Appearance57.ImageHAlign = Infragistics.Win.HAlign.Left
        Appearance57.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance57.TextVAlignAsString = "Middle"
        Me.cmdDelHistoryDated.Appearance = Appearance57
        Me.cmdDelHistoryDated.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance58.BackColor = System.Drawing.Color.DarkOrange
        Appearance58.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance58.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance58.ForeColor = System.Drawing.Color.Black
        Me.cmdDelHistoryDated.HotTrackAppearance = Appearance58
        Me.cmdDelHistoryDated.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdDelHistoryDated.Location = New System.Drawing.Point(58, 582)
        Me.cmdDelHistoryDated.Name = "cmdDelHistoryDated"
        Appearance59.BackColor = System.Drawing.Color.OrangeRed
        Appearance59.BackColor2 = System.Drawing.Color.Tomato
        Appearance59.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdDelHistoryDated.PressedAppearance = Appearance59
        Me.cmdDelHistoryDated.ShowFocusRect = False
        Me.cmdDelHistoryDated.ShowOutline = False
        Me.cmdDelHistoryDated.Size = New System.Drawing.Size(241, 40)
        Me.cmdDelHistoryDated.TabIndex = 558
        Me.cmdDelHistoryDated.Tag = ""
        Me.cmdDelHistoryDated.Text = "Delete history between the specified dates"
        Me.cmdDelHistoryDated.UseAppStyling = False
        Me.cmdDelHistoryDated.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDelHistoryDated.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDelHistoryDated.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'frmDishesHistory
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.Color.SteelBlue
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(1000, 730)
        Me.ControlBox = False
        Me.Controls.Add(Me.cmdDelHistoryDated)
        Me.Controls.Add(Me.cmdDelHistoryAll)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.lblNumRecords)
        Me.Controls.Add(Me.cmdClear)
        Me.Controls.Add(Me.cmdOK)
        Me.Controls.Add(Me.ugdDishesHistory)
        Me.Controls.Add(Me.cmdKBPrintEnd)
        Me.Controls.Add(Me.txtEndDate)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.cmdKBPrintStart)
        Me.Controls.Add(Me.txtStartDate)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.cmdOEHome)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "frmDishesHistory"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        CType(Me.txtEndDate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtStartDate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ugdDishesHistory, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.udsDishesHistory, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents cmdOEHome As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdKBPrintEnd As Infragistics.Win.Misc.UltraButton
    Friend WithEvents txtEndDate As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents cmdKBPrintStart As Infragistics.Win.Misc.UltraButton
    Friend WithEvents txtStartDate As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents ugdDishesHistory As Infragistics.Win.UltraWinGrid.UltraGrid
    Friend WithEvents udsDishesHistory As Infragistics.Win.UltraWinDataSource.UltraDataSource
    Friend WithEvents cmdOK As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdClear As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraCalendarLook1 As Infragistics.Win.UltraWinSchedule.UltraCalendarLook
    Friend WithEvents lblNumRecords As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents cmdDelHistoryAll As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDelHistoryDated As Infragistics.Win.Misc.UltraButton
End Class
