﻿Imports EZControls
Imports EZMenu.Core.Enums
Imports EZMenu.Core.Models
Imports EZService.Repository
Imports Infragistics.Win.UltraWinGrid

Public Class frmModify

    Private _orderType As OrderTypeEnum
    Private dishRepo As DishRepository

    Public Sub New(objForm As frmOrderEntry, orderType As OrderTypeEnum)

        ' This call is required by the designer.
        InitializeComponent()

        Dim ubtnTemp As ModifierButton
        dishRepo = New DishRepository()

        Size = objForm.Size
        Location = objForm.Location

        _orderType = orderType

        cmdPrintLabelsMod.Visible = GetAppSettingCS("ModLabelPrinter", 0)

        If Not cmdPrintLabelsMod.Visible Then cmdClear.Location = cmdPrintLabelsMod.Location

        Try
            upnlModItems.ClientArea.Controls.Clear()

            Dim modifiers As List(Of ModifierModel) = dishRepo.GetModifiers()

            If modifiers.Count > 0 Then
                For Each item As ModifierModel In modifiers
                    ubtnTemp = New ModifierButton
                    With ubtnTemp
                        .Selected = False
                        .SetText = item.Name
                        .Price = item.Cost
                        If .Price = "0.00" Then .Price = ""
                        .SetFont = New Font($"Calibri", 12)
                        .Visible = True
                    End With
                    upnlModItems.ClientArea.Controls.Add(ubtnTemp)
                Next
            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Public Sub Edit(activeRow As UltraGridRow)

        txtDName.Text = activeRow.Cells("DName").Value.ToString.Replace(GetAppSettingCS("PortionSmall", "[S]"), "").Trim
        txtDName.Text = txtDName.Text.Replace(GetAppSettingCS("PortionLarge", "[L]"), "").Trim
        txtDName.Enabled = True
        txtDPrice.Text = activeRow.Cells("DPrice").Value
        txtDPrice.Tag = txtDPrice.Text
        txtDPrice.Enabled = (GetAppSettingCS("DisablePriceChangeInMod", 0) = 0)
        txtDQty.Text = activeRow.Cells("DQty").Value
        txtDQty.Enabled = True
        txtMod.Text = String.Empty
        cmdChangePrice.Visible = (GetAppSettingCS("DisablePriceChangeInMod", 0) = 0)
        Tag = "Edit"

        cmdIsMain.Appearance.Image = Nothing
        cmdIsStarter.Appearance.Image = Nothing
        cmdIsStarter.Tag = 0
        cmdIsMain.Tag = 0

        cmdPortionSmall.Appearance.Image = Nothing
        cmdPortionLarge.Appearance.Image = Nothing
        cmdPortionSmall.Tag = 0
        cmdPortionLarge.Tag = 0
        cmdPortionLarge.Visible = True
        cmdPortionSmall.Visible = True

        'If OrderType =OrderTypeEnum.Table Then
        If (Not IsDBNull(activeRow.Cells("IsStarter").Value)) AndAlso (activeRow.Cells("IsStarter").Value <> 0) Then
            cmdIsStarter.Appearance.Image = My.Resources.ezresource.tick
            cmdIsStarter.Tag = -1
        Else
            cmdIsMain.Appearance.Image = My.Resources.ezresource.tick
            cmdIsMain.Tag = -1
        End If
        'Else

        If activeRow.Cells("DName").Value.ToString.IndexOf(GetAppSettingCS("PortionSmall", "[S]")) <> -1 Then
            cmdPortionSmall.Appearance.Image = My.Resources.ezresource.tick
            cmdPortionSmall.Tag = -1
        ElseIf activeRow.Cells("DName").Value.ToString.IndexOf(GetAppSettingCS("PortionLarge", "[L]")) <> -1 Then
            cmdPortionLarge.Appearance.Image = My.Resources.ezresource.tick
            cmdPortionLarge.Tag = -1
        End If
        'End If

    End Sub

    Private Sub frmModify_Activated(sender As Object, e As EventArgs) Handles Me.Activated

        Try
            If Tag = "New" Then txtDName.Focus() Else txtMod.Focus()
        Catch ex As Exception
        End Try

    End Sub

    Private Sub cmdBack_Click(sender As Object, e As EventArgs) Handles cmdBack.Click

        ClearModGrid()
        Close()

    End Sub

    Private Sub cmdOk_Click(sender As Object, e As EventArgs) Handles cmdOK.Click

        Try
            Dim arrModInfo As New ArrayList
            Dim strModText, strCost As String

            'validate inputs
            If txtDName.Text = String.Empty Then
                Alert("Enter a name for this dish")
                txtDName.Focus()
                Exit Sub
            ElseIf Not IsANumber(txtDPrice.Text) Then
                Alert("Entered price is invalid")
                txtDPrice.Focus()
                Exit Sub
            ElseIf Not IsANumber(txtDQty.Text) And Tag <> "Edit" And Tag <> "SetItem" Then
                Alert("Entered quantity is invalid")
                txtDQty.Focus()
                Exit Sub
            ElseIf Not IsANumber(txtDQty.Text) And Tag = "Edit" Then
                Alert("Entered quantity is invalid")
                txtDQty.Focus()
                Exit Sub
            ElseIf txtPrice.Text.Length > 0 AndAlso Not IsANumber(txtPrice.Text) Then
                Alert("Entered price is invalid")
                txtDPrice.Focus()
                Exit Sub
            End If

            txtDPrice.Text = fixCur(txtDPrice.Text)
            txtDQty.Text = Int(txtDQty.Text)

            For Each mObj In upnlModItems.ClientArea.Controls
                If TypeOf mObj Is ModifierButton Then
                    Dim btnModifier As ModifierButton = mObj
                    If btnModifier.Selected = True Then
                        arrModInfo.Add(btnModifier.SetText & ";" & btnModifier.Price)
                    End If
                End If
            Next

            strModText = ""
            strCost = "0"

            If txtMod.Text <> String.Empty Then strModText = txtMod.Text
            If txtPrice.Text <> String.Empty Then strCost = txtPrice.Text

            If Tag = "Edit" Then

                If RowIsNotModifier() Then

                    'check if dish has been changed
                    If txtDName.Text <> String.Empty Then
                        objOrderEntry.ugdOrderGrid.ActiveRow.Cells("DName").Value = txtDName.Text
                    End If
                    If txtDQty.Text <> String.Empty Then
                        objOrderEntry.ugdOrderGrid.ActiveRow.Cells("DQty").Value = txtDQty.Text
                        UpdateRowPrice()
                    End If
                    If txtDPrice.Text <> String.Empty Then
                        objOrderEntry.ugdOrderGrid.ActiveRow.Cells("DPrice").Value = txtDPrice.Text
                        UpdateRowPrice()
                    End If
                    objOrderEntry.ugdOrderGrid.ActiveRow.Cells("Mods").Value = ""

                    For iModCnt As Integer = 0 To arrModInfo.Count - 1
                        Dim h As Short = arrModInfo(iModCnt).ToString.IndexOf(";")
                        Dim strNamex As String = arrModInfo(iModCnt).ToString.Substring(0, h)
                        Dim strCostx As String = arrModInfo(iModCnt).ToString.Substring(h + 1)
                        If strCostx = "" Then strCostx = "0"
                        objOrderEntry.AddModifier(strNamex, strCostx)
                    Next

                    If strModText <> String.Empty Then
                        objOrderEntry.AddModifier(strModText, strCost)
                    End If

                Else
                    objOrderEntry.ugdOrderGrid.ActiveRow.Cells("DName").Value = "- " & txtMod.Text
                End If

                If strModText = String.Empty AndAlso objOrderEntry.ugdOrderGrid.ActiveRow.Cells("DName").Value = "- " Then
                    objOrderEntry.ModRowAction("DelModRow")
                    objOrderEntry.ugdOrderGrid.ActiveRow = Nothing
                Else
                    objOrderEntry.ModRowAction("UpdateAllCosts")
                End If

                'starter or main indication
                If (objOrderEntry.ugdOrderGrid.ActiveRow IsNot Nothing) Then

                    If cmdIsStarter.Tag = -1 Then
                        objOrderEntry.ugdOrderGrid.ActiveRow.Cells("IsStarter").Value = 1
                    Else
                        objOrderEntry.ugdOrderGrid.ActiveRow.Cells("IsStarter").Value = 0
                    End If

                    If cmdPortionSmall.Tag = -1 Then
                        objOrderEntry.ugdOrderGrid.ActiveRow.Cells("DName").Value = txtDName.Text & GetAppSettingCS("PortionSmall", "[S]")
                    ElseIf cmdPortionLarge.Tag = -1 Then
                        objOrderEntry.ugdOrderGrid.ActiveRow.Cells("DName").Value = txtDName.Text & GetAppSettingCS("PortionLarge", "[L]")
                    End If

                End If

                'AddUpGridTotals()

            ElseIf Tag = "SetItem" Then

                If RowIsNotSet() = False Then
                    If txtDName.Text <> String.Empty Then
                        objOrderEntry.ugdOrderGrid.ActiveRow.Cells("DName").Value = "- " & txtDName.Text
                    End If
                    If txtDQty.Text <> String.Empty Then
                        Dim tmpStr = objOrderEntry.ugdOrderGrid.ActiveRow.Cells("DQty").Value.ToString
                        If IsANumber(tmpStr) Then tmpStr = txtDQty.Text Else tmpStr = String.Empty
                        objOrderEntry.ugdOrderGrid.ActiveRow.Cells("DQty").Value = tmpStr
                        UpdateRowPrice()
                    End If
                    If txtDPrice.Text <> String.Empty Then
                        objOrderEntry.ugdOrderGrid.ActiveRow.Cells("DPrice").Value = txtDPrice.Text
                        UpdateRowPrice()
                    End If
                End If

            ElseIf Tag = "New" Then    'add new dish

                If (txtDName.Text <> String.Empty And txtDPrice.Text <> String.Empty And txtDQty.Text <> String.Empty) Then
                    Dim dishItem As New DishModel With {
                        .DishName = txtDName.Text.Punctuate,
                        .PriceIn = txtDPrice.Text,
                        .PriceOut = txtDPrice.Text,
                        .Qty = txtDQty.Text,
                        .Code = 500,
                        .GroupName = "Other",
                        .GroupIndex = 100,
                        .IsStarter = 0
                    }

                    'starter or main indication
                    If _orderType = OrderTypeEnum.Table Then
                        If cmdIsStarter.Tag = -1 Then dishItem.IsStarter = 1
                    End If
                    objOrderEntry.AddNewDish(dishItem)
                Else
                    strMsgBox = "You must specify item name, price and quantity"
                    EZMsgBox.Show(strMsgBox, MessageBoxIcon.Asterisk)
                    Exit Sub
                End If

            End If

            ClearModGrid()
            Close()

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub ClearModGrid()

        txtMod.Clear()
        txtPrice.Clear()
        Dim myObj As Control, ubtnTemp As ModifierButton

        For Each myObj In upnlModItems.ClientArea.Controls
            If TypeOf myObj Is ModifierButton Then
                ubtnTemp = DirectCast(myObj, ModifierButton)
                If ubtnTemp.Selected = True Then ubtnTemp.Selected = False
            End If
        Next

        cmdIsStarter.Tag = 0
        cmdIsMain.Tag = 0

    End Sub

    Private Sub UpdateRowPrice()

        Try
            With objOrderEntry.ugdOrderGrid.ActiveRow
                Dim cVal
                If IsANumber(.Cells("DQty").Value) Then cVal = .Cells("DQty").Value Else cVal = 1
                .Cells("Total").Value = .Cells("DPrice").Value * cVal
            End With

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub cmdClear_Click(sender As Object, e As EventArgs) Handles cmdClear.Click
        ClearModGrid()
    End Sub

    Private Sub cmdChangePrice_Click(sender As Object, e As EventArgs) Handles cmdChangePrice.Click
        GetAmount()
    End Sub

    Private Sub cmdMainORStarter_Click(sender As Object, e As EventArgs) Handles cmdIsStarter.Click, cmdIsMain.Click

        Dim blnImagedButton As Boolean = False

        If sender.Appearance.Image IsNot Nothing Then
            blnImagedButton = True
        End If

        cmdIsStarter.Appearance.Image = Nothing
        cmdIsMain.Appearance.Image = Nothing
        cmdIsStarter.Tag = 0
        cmdIsMain.Tag = 0

        If blnImagedButton = False Then
            sender.Appearance.Image = My.Resources.ezresource.tick
            sender.tag = -1
        End If

    End Sub

    Private Sub txtMod_KeyDown(sender As Object, e As KeyEventArgs) Handles txtMod.KeyDown
        If e.KeyCode = Keys.Enter Then cmdOk_Click(sender, e)
    End Sub

    Private Sub cmdPrintLabelsMod_Click(sender As Object, e As EventArgs) Handles cmdPrintLabelsMod.Click

        Try
            If txtMod.Text.Trim <> String.Empty Then

                Dim _strLabelPrinter As String = GetAppSettingCS("PrinterLabels" & intCurrentCuisine.ToString, "")
                If _strLabelPrinter = "" Then
                    strMsgBox = "Label printer has not been set for this cuisine."
                    Alert(strMsgBox)

                Else
                    Dim arrLabels As New ArrayList

                    If txtMod.Text.Contains("#") Then
                        Dim arrMods() = txtMod.Text.Split("#")
                        For aCnt = arrMods.GetLowerBound(0) To arrMods.GetUpperBound(0)
                            arrLabels.Add(arrMods(aCnt))
                        Next
                    Else
                        arrLabels.Add(txtMod.Text.Trim)
                    End If

                    Dim PrintLabelsHandler As New clsPrintLabels(arrLabels, intCurrentCuisine)
                    PrintLabelsHandler.PrintLabels()
                    PrintLabelsHandler = Nothing
                End If
            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub GetAmount()

        Dim strNumInput As String

        Using objFormQty As New frmQty
            objFormQty.Display("Enter new price", "0.00")
            strNumInput = objFormQty.ReturnValue
        End Using

        If strNumInput <> "x" Then
            Try
                Dim decNewAmount As Decimal = strNumInput
                If (decNewAmount >= 0 And decNewAmount < 100) Then
                    txtDPrice.Text = fixCur(decNewAmount)
                    txtDPrice.Tag = txtDPrice.Text
                Else
                    strMsgBox = "Number must between 0 and 99"
                    EZMsgBox.Show(strMsgBox, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                End If

            Catch ex As Exception
                strMsgBox = "Number must between 0 and 99"
                EZMsgBox.Show(strMsgBox, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            End Try

        End If

    End Sub

    Private Sub cmdQty_Click(sender As Object, e As EventArgs) Handles cmdQty.Click

        Dim strNumInput As String

        Using objFormQty As New frmQty
            objFormQty.Display("Enter quantity", 0)
            strNumInput = objFormQty.ReturnValue
        End Using

        If strNumInput <> "x" Then
            If CShort(strNumInput) > 0 And CShort(strNumInput) < 101 Then
                txtDQty.Text = strNumInput
            Else
                strMsgBox = "Quantity must be between 1 and 100"
                EZMsgBox.Show(strMsgBox, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            End If
        End If

    End Sub

    Private Sub cmdPortionLarge_Click(sender As Object, e As EventArgs) Handles cmdPortionLarge.Click, cmdPortionSmall.Click

        Dim blnImagedButton As Boolean = False
        Dim decVal As Decimal = 0

        If sender.Appearance.Image IsNot Nothing Then
            blnImagedButton = True
        End If

        cmdPortionSmall.Appearance.Image = Nothing
        cmdPortionLarge.Appearance.Image = Nothing
        cmdPortionSmall.Tag = 0
        cmdPortionLarge.Tag = 0

        If blnImagedButton = False Then
            sender.Appearance.Image = My.Resources.ezresource.tick
            sender.tag = -1
        End If

        'get the unique ID
        SQLQuery = $"SELECT d.UniqueID, d.Code, d.DishName, ds.ShortName 
                     FROM Dish d LEFT OUTER Join DishShortName ds 
                        ON d.UniqueID = ds.UniqueID 
                     WHERE (d.DishName = '{txtDName.Text.Trim.Punctuate}' OR ds.ShortName = '{txtDName.Text.Trim.Punctuate}')"

        drDataRow = objDB.GetSingleRow(SQLQuery)
        If drDataRow IsNot Nothing Then
            'get the small/large price
            SQLQuery = "SELECT * FROM DishSmallLarge WHERE UniqueID = " & drDataRow!UniqueID
            drDataRow = objDB.GetSingleRow(SQLQuery)
            If drDataRow IsNot Nothing Then
                If sender.text = "Small" Then
                    If Not IsDBNull(drDataRow!Small) Then
                        decVal = drDataRow!Small
                        If sender.tag = 0 Then
                            If objOrderEntry.ugdOrderGrid.ActiveRow.Cells("DName").Value.ToString.Contains(GetAppSettingCS("PortionSmall", "[S]")) Then
                                decVal = Abs(decVal)
                            Else
                                decVal = 0
                            End If
                        Else
                            If objOrderEntry.ugdOrderGrid.ActiveRow.Cells("DName").Value.ToString.Contains(GetAppSettingCS("PortionSmall", "[S]")) Then
                                decVal = 0
                            Else
                                decVal = decVal
                            End If
                        End If
                    End If

                Else

                    If Not IsDBNull(drDataRow!Large) Then
                        decVal = drDataRow!Large
                        If sender.tag = 0 Then
                            If objOrderEntry.ugdOrderGrid.ActiveRow.Cells("DName").Value.ToString.Contains(GetAppSettingCS("PortionLarge", "[L]")) Then
                                decVal = -decVal
                            Else
                                decVal = 0
                            End If
                        Else
                            If objOrderEntry.ugdOrderGrid.ActiveRow.Cells("DName").Value.ToString.Contains(GetAppSettingCS("PortionLarge", "[L]")) Then
                                decVal = 0
                            Else
                                decVal = decVal
                            End If
                        End If
                    End If
                End If

                If IsANumber(decVal) Then txtDPrice.Text = fixCur(CDec(txtDPrice.Tag) + decVal)

            Else
                GetAmount()
            End If
        Else
            GetAmount()
        End If

    End Sub

    Private Sub cmdDName_Click(sender As Object, e As EventArgs) Handles cmdDName.Click

        strKBInput = EZFullKeyboard.Show(txtDName.Text)
        If strKBInput <> EZKBEscape Then
            txtDName.Text = strKBInput.Trim
        End If

    End Sub

    Friend Sub EditSetItem(activeRow As UltraGridRow)

        txtDName.Text = Replace(activeRow.Cells("DName").Value.ToString, "- ", "", , 1).Trim
        txtDName.Enabled = True
        Dim tmpStr = activeRow.Cells("DPrice").Value.ToString
        If IsANumber(tmpStr) Then tmpStr = fixCur(tmpStr) Else tmpStr = String.Empty
        txtDPrice.Text = tmpStr
        txtDPrice.Tag = txtDPrice.Text
        txtDPrice.Enabled = True
        txtDQty.Text = IIf(IsDBNull(activeRow.Cells("DQty").Value), "", activeRow.Cells("DQty").Value.ToString)
        txtDQty.Enabled = True
        txtMod.Text = String.Empty
        cmdChangePrice.Visible = True
        Tag = "SetItem"

        cmdIsMain.Appearance.Image = Nothing
        cmdIsStarter.Appearance.Image = Nothing
        cmdIsStarter.Visible = False
        cmdIsMain.Visible = False

        cmdPortionSmall.Appearance.Image = Nothing
        cmdPortionLarge.Appearance.Image = Nothing
        cmdPortionSmall.Visible = False
        cmdPortionLarge.Visible = False

    End Sub

    Friend Sub EditModifier(activeRow As UltraGridRow, dName As String, dPrice As String, dQty As String)

        txtDName.Text = dName
        txtDName.Enabled = False
        txtDPrice.Text = dPrice
        txtDPrice.Tag = dPrice
        txtDPrice.Enabled = False
        txtDQty.Text = dQty
        txtDQty.Enabled = False
        txtMod.Text = Replace(activeRow.Cells("DName").Value.ToString, "- ", "", , 1).Trim
        cmdChangePrice.Visible = False
        Tag = "Edit"

        cmdIsMain.Appearance.Image = Nothing
        cmdIsStarter.Appearance.Image = Nothing
        cmdIsStarter.Visible = False
        cmdIsMain.Visible = False

        cmdPortionSmall.Appearance.Image = Nothing
        cmdPortionLarge.Appearance.Image = Nothing
        cmdPortionSmall.Visible = False
        cmdPortionLarge.Visible = False

    End Sub

    ''Declare the variables
    'Dim drag As Boolean
    'Dim mousex As Integer
    'Dim mousey As Integer

    'Private Sub Form1_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Me.MouseDown
    '    drag = True 'Sets the variable drag to true.
    '    mousex = Windows.Forms.Cursor.Position.X - Me.Left 'Sets variable mousex
    '    mousey = Windows.Forms.Cursor.Position.Y - Me.Top 'Sets variable mousey
    'End Sub

    'Private Sub Form1_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Me.MouseMove
    '    'If drag is set to true then move the form accordingly.
    '    If drag Then
    '        Me.Top = Windows.Forms.Cursor.Position.Y - mousey
    '        Me.Left = Windows.Forms.Cursor.Position.X - mousex
    '    End If
    'End Sub

    'Private Sub Form1_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Me.MouseUp
    '    drag = False 'Sets drag to false, so the form does not move according to the code in MouseMove
    'End Sub

    Private Sub cmdKBModifier_Click(sender As Object, e As EventArgs) Handles cmdKBModifier.Click

        strKBInput = EZFullKeyboard.Show(txtMod.Text)
        If strKBInput <> EZKBEscape Then
            txtMod.Text = strKBInput.Trim
        End If

    End Sub

    Private Sub cmdGetPrice_Click(sender As Object, e As EventArgs) Handles cmdGetPrice.Click

        Dim strNumInput As String = String.Empty

        Using objFormQty As New frmQty
            objFormQty.Display("Enter new price", txtPrice.Text)
            strNumInput = objFormQty.ReturnValue
        End Using

        If strNumInput <> "x" Then
            Try
                Dim decNewAmount As Decimal = strNumInput
                If (decNewAmount >= 0 And decNewAmount < 100) Then
                    txtPrice.Text = fixCur(decNewAmount)
                Else
                    strMsgBox = "Number must between 0 and 99"
                    EZMsgBox.Show(strMsgBox, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                End If

            Catch ex As Exception
                strMsgBox = "Number must between 0 and 99"
                EZMsgBox.Show(strMsgBox, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            End Try

        End If

    End Sub

    Friend Sub ManualEntry()

        txtDName.Clear()
        txtDPrice.Clear()
        txtDQty.Text = 1
        txtMod.Clear()
        Tag = "New"
        cmdIsStarter.Visible = (_orderType = OrderTypeEnum.Table)
        cmdIsMain.Visible = (_orderType = OrderTypeEnum.Table)
        cmdPortionLarge.Visible = False
        cmdPortionSmall.Visible = False


    End Sub
End Class