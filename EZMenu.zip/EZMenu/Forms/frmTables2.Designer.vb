﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmTables2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim Appearance1 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance2 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance3 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance4 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance5 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmTables2))
        Dim Appearance6 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance7 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance8 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance9 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance10 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance11 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance12 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance13 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance14 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance15 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance16 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance17 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance18 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance19 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance20 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance21 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance22 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance23 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance24 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraGridBand1 As Infragistics.Win.UltraWinGrid.UltraGridBand = New Infragistics.Win.UltraWinGrid.UltraGridBand("Band 0", -1)
        Dim UltraGridColumn5 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Code", 0)
        Dim UltraGridColumn6 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Dish", 1)
        Dim UltraGridColumn7 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Price", 2)
        Dim Appearance25 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraGridColumn8 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Qty", 3)
        Dim Appearance26 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraGridColumn9 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Total", 4)
        Dim Appearance27 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraGridColumn10 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Notes", 5)
        Dim UltraGridColumn11 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("IsStarter", 6)
        Dim UltraGridColumn12 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("OriPrice", 7)
        Dim UltraGridColumn13 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("PriceIn", 8)
        Dim UltraGridColumn14 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("GroupIndex", 9)
        Dim UltraGridColumn15 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Mods", 10)
        Dim UltraGridColumn16 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Discountable", 11)
        Dim Appearance28 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance29 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance30 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance31 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance32 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance33 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance34 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance35 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance36 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance37 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance38 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance39 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance40 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance41 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance42 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance43 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance44 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance45 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance46 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance47 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance48 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance49 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance50 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance51 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance52 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance53 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance54 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance55 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance56 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance57 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance58 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance59 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance60 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance61 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance62 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance63 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance64 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance65 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance66 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance67 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance68 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance69 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance70 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance71 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance72 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance73 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance74 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance75 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance76 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance77 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance78 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance79 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraGridBand2 As Infragistics.Win.UltraWinGrid.UltraGridBand = New Infragistics.Win.UltraWinGrid.UltraGridBand("Band 0", -1)
        Dim UltraGridColumn1 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("DkName", 0)
        Dim UltraGridColumn2 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("DkPrice", 1)
        Dim UltraGridColumn3 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("DkQty", 2)
        Dim Appearance80 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraGridColumn4 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("DkTotal", 3)
        Dim Appearance81 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance82 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance83 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance84 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance85 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance86 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance87 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance88 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance89 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance90 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance91 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance92 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance93 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance94 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraTab1 As Infragistics.Win.UltraWinTabControl.UltraTab = New Infragistics.Win.UltraWinTabControl.UltraTab()
        Dim UltraTab3 As Infragistics.Win.UltraWinTabControl.UltraTab = New Infragistics.Win.UltraWinTabControl.UltraTab()
        Dim UltraTab2 As Infragistics.Win.UltraWinTabControl.UltraTab = New Infragistics.Win.UltraWinTabControl.UltraTab()
        Dim UltraDataColumn1 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("Code")
        Dim UltraDataColumn2 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("Dish")
        Dim UltraDataColumn3 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("Price")
        Dim UltraDataColumn4 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("Qty")
        Dim UltraDataColumn5 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("Total")
        Dim UltraDataColumn6 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("IsStarter")
        Dim UltraDataColumn7 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("Discountable")
        Dim UltraDataColumn8 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("Mods")
        Dim UltraDataColumn9 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("GroupIndex")
        Dim Appearance95 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance96 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance97 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance98 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance99 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance100 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance101 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance102 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance103 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Me.UltraTabPageControl1 = New Infragistics.Win.UltraWinTabControl.UltraTabPageControl()
        Me.pnlTables = New Infragistics.Win.Misc.UltraPanel()
        Me.pnlHeader = New Infragistics.Win.Misc.UltraPanel()
        Me.lblHeader = New Infragistics.Win.Misc.UltraLabel()
        Me.tlpTables = New System.Windows.Forms.TableLayoutPanel()
        Me.UltraTabPageControl3 = New Infragistics.Win.UltraWinTabControl.UltraTabPageControl()
        Me.pnlBill = New Infragistics.Win.Misc.UltraPanel()
        Me.UltraPanel1 = New Infragistics.Win.Misc.UltraPanel()
        Me.lblBillHeader = New Infragistics.Win.Misc.UltraLabel()
        Me.cmdLightsStatus = New Infragistics.Win.Misc.UltraButton()
        Me.cmdCAP = New Infragistics.Win.Misc.UltraButton()
        Me.cmdMoveTable = New Infragistics.Win.Misc.UltraButton()
        Me.cmdTableDiscounts = New Infragistics.Win.Misc.UltraButton()
        Me.cmdCovers = New Infragistics.Win.Misc.UltraButton()
        Me.cmdTablePayment = New Infragistics.Win.Misc.UltraButton()
        Me.cmdKitchenNote = New Infragistics.Win.Misc.UltraButton()
        Me.cmdTableKCopy = New Infragistics.Win.Misc.UltraButton()
        Me.cmdTableClear = New Infragistics.Win.Misc.UltraButton()
        Me.cmdTableTables = New Infragistics.Win.Misc.UltraButton()
        Me.cmdTableDrinks = New Infragistics.Win.Misc.UltraButton()
        Me.cmdTablePrint = New Infragistics.Win.Misc.UltraButton()
        Me.cmdTableEdit = New Infragistics.Win.Misc.UltraButton()
        Me.cmdTableDiscard = New Infragistics.Win.Misc.UltraButton()
        Me.lblEntryTime = New Infragistics.Win.Misc.UltraLabel()
        Me.upnlMiniTables = New Infragistics.Win.Misc.UltraPanel()
        Me.lblMiniHilit = New Infragistics.Win.Misc.UltraLabel()
        Me.lblTipsLabel = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel6 = New Infragistics.Win.Misc.UltraLabel()
        Me.ugdTableGrid = New Infragistics.Win.UltraWinGrid.UltraGrid()
        Me.lblChargesLbl = New Infragistics.Win.Misc.UltraLabel()
        Me.lblBillTotalLbl = New Infragistics.Win.Misc.UltraLabel()
        Me.lblDiscountsLbl = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel4 = New Infragistics.Win.Misc.UltraLabel()
        Me.lblTTips = New Infragistics.Win.Misc.UltraLabel()
        Me.lblTDrinks = New Infragistics.Win.Misc.UltraLabel()
        Me.lblCharges = New Infragistics.Win.Misc.UltraLabel()
        Me.lblBillTotal = New Infragistics.Win.Misc.UltraLabel()
        Me.lblDiscounts = New Infragistics.Win.Misc.UltraLabel()
        Me.lblTSubtotal = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraTabPageControl2 = New Infragistics.Win.UltraWinTabControl.UltraTabPageControl()
        Me.pnlDrinks = New Infragistics.Win.Misc.UltraPanel()
        Me.UltraPanel2 = New Infragistics.Win.Misc.UltraPanel()
        Me.lblDrinksHeader = New Infragistics.Win.Misc.UltraLabel()
        Me.cmdDkPrint = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDkAddMisc = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDkClearAll = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDkDelete = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDkDeduct = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDkAdd = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDkDown = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDkUp = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDkClose = New Infragistics.Win.Misc.UltraButton()
        Me.pnlDrinksContainer = New Infragistics.Win.Misc.UltraPanel()
        Me.pnlDrinksDrinks = New Infragistics.Win.Misc.UltraPanel()
        Me.UltraLabel5 = New Infragistics.Win.Misc.UltraLabel()
        Me.lblDrinksTotal = New Infragistics.Win.Misc.UltraLabel()
        Me.ugdDrinksGrid = New Infragistics.Win.UltraWinGrid.UltraGrid()
        Me.lblStatusbarDivider = New Infragistics.Win.Misc.UltraLabel()
        Me.pnlContainer = New Infragistics.Win.Misc.UltraPanel()
        Me.utcAllPanels = New Infragistics.Win.UltraWinTabControl.UltraTabControl()
        Me.UltraTabSharedControlsPage1 = New Infragistics.Win.UltraWinTabControl.UltraTabSharedControlsPage()
        Me.uflTables = New Infragistics.Win.Misc.UltraFlowLayoutManager(Me.components)
        Me.uflDinks = New Infragistics.Win.Misc.UltraFlowLayoutManager(Me.components)
        Me.udsTableGrid = New Infragistics.Win.UltraWinDataSource.UltraDataSource(Me.components)
        Me.udsDrinks = New Infragistics.Win.UltraWinDataSource.UltraDataSource(Me.components)
        Me.DrinksBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.EZMenuDataSet = New EZMenu.EZMenuDataSet()
        Me.DrinksTableAdapter = New EZMenu.EZMenuDataSetTableAdapters.DrinksTableAdapter()
        Me.TableAdapterManager = New EZMenu.EZMenuDataSetTableAdapters.TableAdapterManager()
        Me.cmdClosePanel = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDkPrevious = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDkNext = New Infragistics.Win.Misc.UltraButton()
        Me.UltraTabPageControl1.SuspendLayout()
        Me.pnlTables.ClientArea.SuspendLayout()
        Me.pnlTables.SuspendLayout()
        Me.pnlHeader.ClientArea.SuspendLayout()
        Me.pnlHeader.SuspendLayout()
        Me.UltraTabPageControl3.SuspendLayout()
        Me.pnlBill.ClientArea.SuspendLayout()
        Me.pnlBill.SuspendLayout()
        Me.UltraPanel1.ClientArea.SuspendLayout()
        Me.UltraPanel1.SuspendLayout()
        Me.upnlMiniTables.ClientArea.SuspendLayout()
        Me.upnlMiniTables.SuspendLayout()
        CType(Me.ugdTableGrid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.UltraTabPageControl2.SuspendLayout()
        Me.pnlDrinks.ClientArea.SuspendLayout()
        Me.pnlDrinks.SuspendLayout()
        Me.UltraPanel2.ClientArea.SuspendLayout()
        Me.UltraPanel2.SuspendLayout()
        Me.pnlDrinksContainer.ClientArea.SuspendLayout()
        Me.pnlDrinksContainer.SuspendLayout()
        Me.pnlDrinksDrinks.SuspendLayout()
        CType(Me.ugdDrinksGrid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlContainer.ClientArea.SuspendLayout()
        Me.pnlContainer.SuspendLayout()
        CType(Me.utcAllPanels, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.utcAllPanels.SuspendLayout()
        CType(Me.uflTables, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.uflDinks, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.udsTableGrid, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.udsDrinks, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DrinksBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EZMenuDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'UltraTabPageControl1
        '
        Me.UltraTabPageControl1.Controls.Add(Me.pnlTables)
        Me.UltraTabPageControl1.Location = New System.Drawing.Point(1, 23)
        Me.UltraTabPageControl1.Name = "UltraTabPageControl1"
        Me.UltraTabPageControl1.Size = New System.Drawing.Size(958, 578)
        '
        'pnlTables
        '
        Me.pnlTables.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        '
        'pnlTables.ClientArea
        '
        Me.pnlTables.ClientArea.Controls.Add(Me.pnlHeader)
        Me.pnlTables.ClientArea.Controls.Add(Me.tlpTables)
        Me.pnlTables.Location = New System.Drawing.Point(3, 3)
        Me.pnlTables.Name = "pnlTables"
        Me.pnlTables.Size = New System.Drawing.Size(1151, 597)
        Me.pnlTables.TabIndex = 0
        '
        'pnlHeader
        '
        Me.pnlHeader.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance1.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.pnlHeader.Appearance = Appearance1
        '
        'pnlHeader.ClientArea
        '
        Me.pnlHeader.ClientArea.Controls.Add(Me.lblHeader)
        Me.pnlHeader.Location = New System.Drawing.Point(0, 0)
        Me.pnlHeader.Name = "pnlHeader"
        Me.pnlHeader.Size = New System.Drawing.Size(1150, 42)
        Me.pnlHeader.StyleSetName = "Reservation"
        Me.pnlHeader.TabIndex = 577
        Me.pnlHeader.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblHeader
        '
        Me.lblHeader.Anchor = System.Windows.Forms.AnchorStyles.Top
        Appearance2.BackColor = System.Drawing.Color.Transparent
        Appearance2.ForeColor = System.Drawing.Color.Maroon
        Appearance2.TextHAlignAsString = "Center"
        Appearance2.TextVAlignAsString = "Middle"
        Me.lblHeader.Appearance = Appearance2
        Me.lblHeader.Font = New System.Drawing.Font("Calibri", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHeader.Location = New System.Drawing.Point(320, 4)
        Me.lblHeader.Name = "lblHeader"
        Me.lblHeader.Size = New System.Drawing.Size(511, 35)
        Me.lblHeader.StyleSetName = "Reservation"
        Me.lblHeader.TabIndex = 460
        Me.lblHeader.Text = "Select a table"
        Me.lblHeader.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'tlpTables
        '
        Me.tlpTables.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.tlpTables.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.tlpTables.ColumnCount = 1
        Me.tlpTables.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571!))
        Me.tlpTables.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571!))
        Me.tlpTables.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571!))
        Me.tlpTables.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571!))
        Me.tlpTables.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571!))
        Me.tlpTables.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571!))
        Me.tlpTables.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571!))
        Me.tlpTables.Location = New System.Drawing.Point(178, 135)
        Me.tlpTables.Name = "tlpTables"
        Me.tlpTables.RowCount = 1
        Me.tlpTables.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.tlpTables.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.tlpTables.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.tlpTables.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.tlpTables.Size = New System.Drawing.Size(752, 398)
        Me.tlpTables.TabIndex = 564
        '
        'UltraTabPageControl3
        '
        Me.UltraTabPageControl3.Controls.Add(Me.pnlBill)
        Me.UltraTabPageControl3.Location = New System.Drawing.Point(-10000, -10000)
        Me.UltraTabPageControl3.Name = "UltraTabPageControl3"
        Me.UltraTabPageControl3.Size = New System.Drawing.Size(958, 578)
        '
        'pnlBill
        '
        Me.pnlBill.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        '
        'pnlBill.ClientArea
        '
        Me.pnlBill.ClientArea.Controls.Add(Me.UltraPanel1)
        Me.pnlBill.ClientArea.Controls.Add(Me.cmdLightsStatus)
        Me.pnlBill.ClientArea.Controls.Add(Me.cmdCAP)
        Me.pnlBill.ClientArea.Controls.Add(Me.cmdMoveTable)
        Me.pnlBill.ClientArea.Controls.Add(Me.cmdTableDiscounts)
        Me.pnlBill.ClientArea.Controls.Add(Me.cmdCovers)
        Me.pnlBill.ClientArea.Controls.Add(Me.cmdTablePayment)
        Me.pnlBill.ClientArea.Controls.Add(Me.cmdKitchenNote)
        Me.pnlBill.ClientArea.Controls.Add(Me.cmdTableKCopy)
        Me.pnlBill.ClientArea.Controls.Add(Me.cmdTableClear)
        Me.pnlBill.ClientArea.Controls.Add(Me.cmdTableTables)
        Me.pnlBill.ClientArea.Controls.Add(Me.cmdTableDrinks)
        Me.pnlBill.ClientArea.Controls.Add(Me.cmdTablePrint)
        Me.pnlBill.ClientArea.Controls.Add(Me.cmdTableEdit)
        Me.pnlBill.ClientArea.Controls.Add(Me.cmdTableDiscard)
        Me.pnlBill.ClientArea.Controls.Add(Me.lblEntryTime)
        Me.pnlBill.ClientArea.Controls.Add(Me.upnlMiniTables)
        Me.pnlBill.ClientArea.Controls.Add(Me.lblTipsLabel)
        Me.pnlBill.ClientArea.Controls.Add(Me.UltraLabel6)
        Me.pnlBill.ClientArea.Controls.Add(Me.ugdTableGrid)
        Me.pnlBill.ClientArea.Controls.Add(Me.lblChargesLbl)
        Me.pnlBill.ClientArea.Controls.Add(Me.lblBillTotalLbl)
        Me.pnlBill.ClientArea.Controls.Add(Me.lblDiscountsLbl)
        Me.pnlBill.ClientArea.Controls.Add(Me.UltraLabel4)
        Me.pnlBill.ClientArea.Controls.Add(Me.lblTTips)
        Me.pnlBill.ClientArea.Controls.Add(Me.lblTDrinks)
        Me.pnlBill.ClientArea.Controls.Add(Me.lblCharges)
        Me.pnlBill.ClientArea.Controls.Add(Me.lblBillTotal)
        Me.pnlBill.ClientArea.Controls.Add(Me.lblDiscounts)
        Me.pnlBill.ClientArea.Controls.Add(Me.lblTSubtotal)
        Me.pnlBill.Location = New System.Drawing.Point(3, 3)
        Me.pnlBill.Name = "pnlBill"
        Me.pnlBill.Size = New System.Drawing.Size(954, 578)
        Me.pnlBill.TabIndex = 1
        '
        'UltraPanel1
        '
        Me.UltraPanel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance3.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.UltraPanel1.Appearance = Appearance3
        '
        'UltraPanel1.ClientArea
        '
        Me.UltraPanel1.ClientArea.Controls.Add(Me.lblBillHeader)
        Me.UltraPanel1.Location = New System.Drawing.Point(0, 0)
        Me.UltraPanel1.Name = "UltraPanel1"
        Me.UltraPanel1.Size = New System.Drawing.Size(953, 42)
        Me.UltraPanel1.StyleSetName = "Reservation"
        Me.UltraPanel1.TabIndex = 585
        Me.UltraPanel1.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblBillHeader
        '
        Me.lblBillHeader.Anchor = System.Windows.Forms.AnchorStyles.Top
        Appearance4.BackColor = System.Drawing.Color.Transparent
        Appearance4.ForeColor = System.Drawing.Color.Maroon
        Appearance4.TextHAlignAsString = "Center"
        Appearance4.TextVAlignAsString = "Middle"
        Me.lblBillHeader.Appearance = Appearance4
        Me.lblBillHeader.Font = New System.Drawing.Font("Calibri", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBillHeader.Location = New System.Drawing.Point(221, 4)
        Me.lblBillHeader.Name = "lblBillHeader"
        Me.lblBillHeader.Size = New System.Drawing.Size(496, 35)
        Me.lblBillHeader.StyleSetName = "Reservation"
        Me.lblBillHeader.TabIndex = 460
        Me.lblBillHeader.Text = "Bill for table X"
        Me.lblBillHeader.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdLightsStatus
        '
        Me.cmdLightsStatus.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance5.BackColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Appearance5.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance5.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance5.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance5.ForeColor = System.Drawing.Color.DimGray
        Appearance5.Image = CType(resources.GetObject("Appearance5.Image"), Object)
        Appearance5.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance5.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance5.TextVAlignAsString = "Bottom"
        Me.cmdLightsStatus.Appearance = Appearance5
        Me.cmdLightsStatus.Font = New System.Drawing.Font("Corbel", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdLightsStatus.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdLightsStatus.Location = New System.Drawing.Point(685, 406)
        Me.cmdLightsStatus.Margin = New System.Windows.Forms.Padding(10)
        Me.cmdLightsStatus.Name = "cmdLightsStatus"
        Me.cmdLightsStatus.ShowFocusRect = False
        Me.cmdLightsStatus.ShowOutline = False
        Me.cmdLightsStatus.Size = New System.Drawing.Size(126, 65)
        Me.cmdLightsStatus.StyleSetName = "TableBigButton"
        Me.cmdLightsStatus.TabIndex = 570
        Me.cmdLightsStatus.Text = "Status"
        Me.cmdLightsStatus.UseAppStyling = False
        Me.cmdLightsStatus.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdLightsStatus.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdCAP
        '
        Me.cmdCAP.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance6.BackColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Appearance6.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance6.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance6.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance6.ForeColor = System.Drawing.Color.DimGray
        Appearance6.Image = CType(resources.GetObject("Appearance6.Image"), Object)
        Appearance6.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance6.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance6.TextVAlignAsString = "Bottom"
        Me.cmdCAP.Appearance = Appearance6
        Me.cmdCAP.Font = New System.Drawing.Font("Corbel", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdCAP.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdCAP.Location = New System.Drawing.Point(818, 193)
        Me.cmdCAP.Margin = New System.Windows.Forms.Padding(10)
        Me.cmdCAP.Name = "cmdCAP"
        Me.cmdCAP.ShowFocusRect = False
        Me.cmdCAP.ShowOutline = False
        Me.cmdCAP.Size = New System.Drawing.Size(126, 65)
        Me.cmdCAP.StyleSetName = "TableBigButton"
        Me.cmdCAP.TabIndex = 571
        Me.cmdCAP.Text = "Chutney Tray"
        Me.cmdCAP.UseAppStyling = False
        Me.cmdCAP.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdCAP.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdMoveTable
        '
        Me.cmdMoveTable.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance7.BackColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Appearance7.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance7.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance7.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance7.ForeColor = System.Drawing.Color.DimGray
        Appearance7.Image = CType(resources.GetObject("Appearance7.Image"), Object)
        Appearance7.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance7.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance7.TextVAlignAsString = "Bottom"
        Me.cmdMoveTable.Appearance = Appearance7
        Me.cmdMoveTable.Font = New System.Drawing.Font("Corbel", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdMoveTable.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdMoveTable.Location = New System.Drawing.Point(818, 264)
        Me.cmdMoveTable.Margin = New System.Windows.Forms.Padding(10)
        Me.cmdMoveTable.Name = "cmdMoveTable"
        Me.cmdMoveTable.ShowFocusRect = False
        Me.cmdMoveTable.ShowOutline = False
        Me.cmdMoveTable.Size = New System.Drawing.Size(126, 65)
        Me.cmdMoveTable.StyleSetName = "TableBigButton"
        Me.cmdMoveTable.TabIndex = 572
        Me.cmdMoveTable.Text = "Move Table"
        Me.cmdMoveTable.UseAppStyling = False
        Me.cmdMoveTable.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdMoveTable.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdTableDiscounts
        '
        Me.cmdTableDiscounts.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance8.BackColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Appearance8.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance8.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance8.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance8.ForeColor = System.Drawing.Color.DimGray
        Appearance8.Image = CType(resources.GetObject("Appearance8.Image"), Object)
        Appearance8.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance8.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance8.TextVAlignAsString = "Bottom"
        Me.cmdTableDiscounts.Appearance = Appearance8
        Me.cmdTableDiscounts.Font = New System.Drawing.Font("Corbel", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdTableDiscounts.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdTableDiscounts.Location = New System.Drawing.Point(818, 335)
        Me.cmdTableDiscounts.Margin = New System.Windows.Forms.Padding(10)
        Me.cmdTableDiscounts.Name = "cmdTableDiscounts"
        Me.cmdTableDiscounts.ShowFocusRect = False
        Me.cmdTableDiscounts.ShowOutline = False
        Me.cmdTableDiscounts.Size = New System.Drawing.Size(126, 65)
        Me.cmdTableDiscounts.StyleSetName = "TableBigButton"
        Me.cmdTableDiscounts.TabIndex = 573
        Me.cmdTableDiscounts.Text = "Discounts && Charges"
        Me.cmdTableDiscounts.UseAppStyling = False
        Me.cmdTableDiscounts.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTableDiscounts.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdCovers
        '
        Me.cmdCovers.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance9.BackColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Appearance9.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance9.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance9.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance9.ForeColor = System.Drawing.Color.DimGray
        Appearance9.Image = CType(resources.GetObject("Appearance9.Image"), Object)
        Appearance9.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance9.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance9.TextVAlignAsString = "Bottom"
        Me.cmdCovers.Appearance = Appearance9
        Me.cmdCovers.Font = New System.Drawing.Font("Corbel", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdCovers.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdCovers.Location = New System.Drawing.Point(685, 193)
        Me.cmdCovers.Margin = New System.Windows.Forms.Padding(10)
        Me.cmdCovers.Name = "cmdCovers"
        Me.cmdCovers.ShowFocusRect = False
        Me.cmdCovers.ShowOutline = False
        Me.cmdCovers.Size = New System.Drawing.Size(126, 65)
        Me.cmdCovers.StyleSetName = "TableBigButton"
        Me.cmdCovers.TabIndex = 574
        Me.cmdCovers.Text = "Cover"
        Me.cmdCovers.UseAppStyling = False
        Me.cmdCovers.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdCovers.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdTablePayment
        '
        Me.cmdTablePayment.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance10.BackColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Appearance10.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance10.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance10.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance10.ForeColor = System.Drawing.Color.DimGray
        Appearance10.Image = CType(resources.GetObject("Appearance10.Image"), Object)
        Appearance10.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance10.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance10.TextVAlignAsString = "Bottom"
        Me.cmdTablePayment.Appearance = Appearance10
        Me.cmdTablePayment.Font = New System.Drawing.Font("Corbel", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdTablePayment.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdTablePayment.Location = New System.Drawing.Point(685, 335)
        Me.cmdTablePayment.Margin = New System.Windows.Forms.Padding(10)
        Me.cmdTablePayment.Name = "cmdTablePayment"
        Me.cmdTablePayment.ShowFocusRect = False
        Me.cmdTablePayment.ShowOutline = False
        Me.cmdTablePayment.Size = New System.Drawing.Size(126, 65)
        Me.cmdTablePayment.StyleSetName = "TableBigButton"
        Me.cmdTablePayment.TabIndex = 575
        Me.cmdTablePayment.Text = "Payment"
        Me.cmdTablePayment.UseAppStyling = False
        Me.cmdTablePayment.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTablePayment.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdKitchenNote
        '
        Me.cmdKitchenNote.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance11.BackColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Appearance11.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance11.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance11.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance11.ForeColor = System.Drawing.Color.DimGray
        Appearance11.Image = CType(resources.GetObject("Appearance11.Image"), Object)
        Appearance11.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance11.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance11.TextVAlignAsString = "Bottom"
        Me.cmdKitchenNote.Appearance = Appearance11
        Me.cmdKitchenNote.Font = New System.Drawing.Font("Corbel", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdKitchenNote.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdKitchenNote.Location = New System.Drawing.Point(685, 264)
        Me.cmdKitchenNote.Margin = New System.Windows.Forms.Padding(10)
        Me.cmdKitchenNote.Name = "cmdKitchenNote"
        Me.cmdKitchenNote.ShowFocusRect = False
        Me.cmdKitchenNote.ShowOutline = False
        Me.cmdKitchenNote.Size = New System.Drawing.Size(126, 65)
        Me.cmdKitchenNote.StyleSetName = "TableBigButton"
        Me.cmdKitchenNote.TabIndex = 576
        Me.cmdKitchenNote.Text = "Note"
        Me.cmdKitchenNote.UseAppStyling = False
        Me.cmdKitchenNote.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKitchenNote.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdTableKCopy
        '
        Me.cmdTableKCopy.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance12.BackColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Appearance12.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance12.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance12.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance12.ForeColor = System.Drawing.Color.DimGray
        Appearance12.Image = CType(resources.GetObject("Appearance12.Image"), Object)
        Appearance12.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance12.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance12.TextVAlignAsString = "Bottom"
        Me.cmdTableKCopy.Appearance = Appearance12
        Me.cmdTableKCopy.Font = New System.Drawing.Font("Corbel", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdTableKCopy.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdTableKCopy.Location = New System.Drawing.Point(818, 122)
        Me.cmdTableKCopy.Margin = New System.Windows.Forms.Padding(10)
        Me.cmdTableKCopy.Name = "cmdTableKCopy"
        Me.cmdTableKCopy.ShowFocusRect = False
        Me.cmdTableKCopy.ShowOutline = False
        Me.cmdTableKCopy.Size = New System.Drawing.Size(126, 65)
        Me.cmdTableKCopy.StyleSetName = "TableBigButton"
        Me.cmdTableKCopy.TabIndex = 577
        Me.cmdTableKCopy.Text = "Kitchen Copy"
        Me.cmdTableKCopy.UseAppStyling = False
        Me.cmdTableKCopy.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTableKCopy.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdTableClear
        '
        Me.cmdTableClear.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance13.BackColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Appearance13.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance13.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance13.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance13.ForeColor = System.Drawing.Color.DimGray
        Appearance13.Image = CType(resources.GetObject("Appearance13.Image"), Object)
        Appearance13.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance13.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance13.TextVAlignAsString = "Bottom"
        Me.cmdTableClear.Appearance = Appearance13
        Me.cmdTableClear.Font = New System.Drawing.Font("Corbel", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdTableClear.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdTableClear.Location = New System.Drawing.Point(685, 477)
        Me.cmdTableClear.Margin = New System.Windows.Forms.Padding(10)
        Me.cmdTableClear.Name = "cmdTableClear"
        Me.cmdTableClear.ShowFocusRect = False
        Me.cmdTableClear.ShowOutline = False
        Me.cmdTableClear.Size = New System.Drawing.Size(126, 65)
        Me.cmdTableClear.StyleSetName = "TableBigButton"
        Me.cmdTableClear.TabIndex = 578
        Me.cmdTableClear.Text = "Settle"
        Me.cmdTableClear.UseAppStyling = False
        Me.cmdTableClear.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTableClear.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdTableTables
        '
        Me.cmdTableTables.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance14.BackColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Appearance14.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance14.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance14.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance14.ForeColor = System.Drawing.Color.DimGray
        Appearance14.Image = CType(resources.GetObject("Appearance14.Image"), Object)
        Appearance14.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance14.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance14.TextVAlignAsString = "Bottom"
        Me.cmdTableTables.Appearance = Appearance14
        Me.cmdTableTables.Font = New System.Drawing.Font("Corbel", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdTableTables.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdTableTables.Location = New System.Drawing.Point(818, 406)
        Me.cmdTableTables.Margin = New System.Windows.Forms.Padding(10)
        Me.cmdTableTables.Name = "cmdTableTables"
        Me.cmdTableTables.ShowFocusRect = False
        Me.cmdTableTables.ShowOutline = False
        Me.cmdTableTables.Size = New System.Drawing.Size(126, 65)
        Me.cmdTableTables.StyleSetName = "TableBigButton"
        Me.cmdTableTables.TabIndex = 579
        Me.cmdTableTables.Text = "Tables"
        Me.cmdTableTables.UseAppStyling = False
        Me.cmdTableTables.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTableTables.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdTableDrinks
        '
        Me.cmdTableDrinks.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance15.BackColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Appearance15.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance15.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance15.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance15.ForeColor = System.Drawing.Color.DimGray
        Appearance15.Image = CType(resources.GetObject("Appearance15.Image"), Object)
        Appearance15.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance15.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance15.TextVAlignAsString = "Bottom"
        Me.cmdTableDrinks.Appearance = Appearance15
        Me.cmdTableDrinks.Font = New System.Drawing.Font("Corbel", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdTableDrinks.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdTableDrinks.Location = New System.Drawing.Point(818, 51)
        Me.cmdTableDrinks.Margin = New System.Windows.Forms.Padding(10)
        Me.cmdTableDrinks.Name = "cmdTableDrinks"
        Me.cmdTableDrinks.ShowFocusRect = False
        Me.cmdTableDrinks.ShowOutline = False
        Me.cmdTableDrinks.Size = New System.Drawing.Size(126, 65)
        Me.cmdTableDrinks.StyleSetName = "TableBigButton"
        Me.cmdTableDrinks.TabIndex = 580
        Me.cmdTableDrinks.Text = "Drinks"
        Me.cmdTableDrinks.UseAppStyling = False
        Me.cmdTableDrinks.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTableDrinks.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdTablePrint
        '
        Me.cmdTablePrint.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance16.BackColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Appearance16.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance16.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance16.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance16.ForeColor = System.Drawing.Color.DimGray
        Appearance16.Image = CType(resources.GetObject("Appearance16.Image"), Object)
        Appearance16.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance16.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance16.TextVAlignAsString = "Bottom"
        Me.cmdTablePrint.Appearance = Appearance16
        Me.cmdTablePrint.Font = New System.Drawing.Font("Corbel", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdTablePrint.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdTablePrint.Location = New System.Drawing.Point(685, 122)
        Me.cmdTablePrint.Margin = New System.Windows.Forms.Padding(10)
        Me.cmdTablePrint.Name = "cmdTablePrint"
        Me.cmdTablePrint.ShowFocusRect = False
        Me.cmdTablePrint.ShowOutline = False
        Me.cmdTablePrint.Size = New System.Drawing.Size(126, 65)
        Me.cmdTablePrint.StyleSetName = "TableBigButton"
        Me.cmdTablePrint.TabIndex = 581
        Me.cmdTablePrint.Text = "Print"
        Me.cmdTablePrint.UseAppStyling = False
        Me.cmdTablePrint.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTablePrint.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdTableEdit
        '
        Me.cmdTableEdit.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance17.BackColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Appearance17.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance17.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance17.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance17.ForeColor = System.Drawing.Color.DimGray
        Appearance17.Image = CType(resources.GetObject("Appearance17.Image"), Object)
        Appearance17.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance17.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance17.TextVAlignAsString = "Bottom"
        Me.cmdTableEdit.Appearance = Appearance17
        Me.cmdTableEdit.Font = New System.Drawing.Font("Corbel", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdTableEdit.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdTableEdit.Location = New System.Drawing.Point(685, 51)
        Me.cmdTableEdit.Margin = New System.Windows.Forms.Padding(10)
        Me.cmdTableEdit.Name = "cmdTableEdit"
        Me.cmdTableEdit.ShowFocusRect = False
        Me.cmdTableEdit.ShowOutline = False
        Me.cmdTableEdit.Size = New System.Drawing.Size(126, 65)
        Me.cmdTableEdit.StyleSetName = "TableBigButton"
        Me.cmdTableEdit.TabIndex = 582
        Me.cmdTableEdit.Text = "Edit"
        Me.cmdTableEdit.UseAppStyling = False
        Me.cmdTableEdit.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTableEdit.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdTableDiscard
        '
        Me.cmdTableDiscard.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance18.BackColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Appearance18.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance18.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance18.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance18.ForeColor = System.Drawing.Color.DimGray
        Appearance18.Image = CType(resources.GetObject("Appearance18.Image"), Object)
        Appearance18.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance18.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance18.TextVAlignAsString = "Bottom"
        Me.cmdTableDiscard.Appearance = Appearance18
        Me.cmdTableDiscard.Font = New System.Drawing.Font("Corbel", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdTableDiscard.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdTableDiscard.Location = New System.Drawing.Point(818, 477)
        Me.cmdTableDiscard.Margin = New System.Windows.Forms.Padding(10)
        Me.cmdTableDiscard.Name = "cmdTableDiscard"
        Me.cmdTableDiscard.ShowFocusRect = False
        Me.cmdTableDiscard.ShowOutline = False
        Me.cmdTableDiscard.Size = New System.Drawing.Size(126, 65)
        Me.cmdTableDiscard.StyleSetName = "TableBigButton"
        Me.cmdTableDiscard.TabIndex = 584
        Me.cmdTableDiscard.Text = "Discard"
        Me.cmdTableDiscard.UseAppStyling = False
        Me.cmdTableDiscard.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTableDiscard.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblEntryTime
        '
        Me.lblEntryTime.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance19.BackColor = System.Drawing.Color.Transparent
        Appearance19.ForeColor = System.Drawing.Color.DimGray
        Appearance19.TextHAlignAsString = "Center"
        Me.lblEntryTime.Appearance = Appearance19
        Me.lblEntryTime.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEntryTime.Location = New System.Drawing.Point(685, 535)
        Me.lblEntryTime.Name = "lblEntryTime"
        Me.lblEntryTime.Size = New System.Drawing.Size(259, 34)
        Me.lblEntryTime.TabIndex = 569
        Me.lblEntryTime.Text = "<entry_time>"
        Me.lblEntryTime.UseAppStyling = False
        '
        'upnlMiniTables
        '
        Appearance20.BackColor = System.Drawing.Color.Transparent
        Appearance20.BorderColor = System.Drawing.Color.Gray
        Me.upnlMiniTables.Appearance = Appearance20
        '
        'upnlMiniTables.ClientArea
        '
        Me.upnlMiniTables.ClientArea.Controls.Add(Me.lblMiniHilit)
        Me.upnlMiniTables.Location = New System.Drawing.Point(400, 371)
        Me.upnlMiniTables.Name = "upnlMiniTables"
        Me.upnlMiniTables.Size = New System.Drawing.Size(160, 109)
        Me.upnlMiniTables.TabIndex = 547
        '
        'lblMiniHilit
        '
        Appearance21.BackColor = System.Drawing.Color.DarkOrange
        Appearance21.BorderColor = System.Drawing.Color.DarkOrange
        Me.lblMiniHilit.Appearance = Appearance21
        Me.lblMiniHilit.BorderStyleOuter = Infragistics.Win.UIElementBorderStyle.Rounded4Thick
        Me.lblMiniHilit.ImageSize = New System.Drawing.Size(58, 58)
        Me.lblMiniHilit.Location = New System.Drawing.Point(28, 19)
        Me.lblMiniHilit.Name = "lblMiniHilit"
        Me.lblMiniHilit.Size = New System.Drawing.Size(58, 58)
        Me.lblMiniHilit.TabIndex = 1
        Me.lblMiniHilit.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.lblMiniHilit.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        Me.lblMiniHilit.Visible = False
        '
        'lblTipsLabel
        '
        Me.lblTipsLabel.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Appearance22.BackColor = System.Drawing.Color.Transparent
        Appearance22.ForeColor = System.Drawing.Color.DimGray
        Appearance22.TextHAlignAsString = "Right"
        Me.lblTipsLabel.Appearance = Appearance22
        Me.lblTipsLabel.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTipsLabel.Location = New System.Drawing.Point(44, 472)
        Me.lblTipsLabel.Name = "lblTipsLabel"
        Me.lblTipsLabel.Size = New System.Drawing.Size(57, 20)
        Me.lblTipsLabel.TabIndex = 544
        Me.lblTipsLabel.Text = "Tips:"
        Me.lblTipsLabel.UseAppStyling = False
        Me.lblTipsLabel.Visible = False
        '
        'UltraLabel6
        '
        Me.UltraLabel6.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Appearance23.BackColor = System.Drawing.Color.Transparent
        Appearance23.ForeColor = System.Drawing.Color.FromArgb(CType(CType(10, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(130, Byte), Integer))
        Appearance23.TextHAlignAsString = "Right"
        Me.UltraLabel6.Appearance = Appearance23
        Me.UltraLabel6.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UltraLabel6.Location = New System.Drawing.Point(190, 492)
        Me.UltraLabel6.Name = "UltraLabel6"
        Me.UltraLabel6.Size = New System.Drawing.Size(100, 20)
        Me.UltraLabel6.TabIndex = 541
        Me.UltraLabel6.Text = "Drinks:"
        Me.UltraLabel6.UseAppStyling = False
        '
        'ugdTableGrid
        '
        Me.ugdTableGrid.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Appearance24.BackColor = System.Drawing.Color.FromArgb(CType(CType(253, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(253, Byte), Integer))
        Appearance24.BorderColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.ugdTableGrid.DisplayLayout.Appearance = Appearance24
        UltraGridColumn5.AutoCompleteMode = Infragistics.Win.AutoCompleteMode.Append
        UltraGridColumn5.Header.VisiblePosition = 0
        UltraGridColumn5.Hidden = True
        UltraGridColumn5.Width = 50
        UltraGridColumn6.AutoCompleteMode = Infragistics.Win.AutoCompleteMode.Append
        UltraGridColumn6.Header.VisiblePosition = 2
        UltraGridColumn6.Width = 207
        UltraGridColumn7.AutoCompleteMode = Infragistics.Win.AutoCompleteMode.Append
        Appearance25.TextHAlignAsString = "Right"
        UltraGridColumn7.CellAppearance = Appearance25
        UltraGridColumn7.Header.VisiblePosition = 4
        UltraGridColumn7.Hidden = True
        UltraGridColumn7.Width = 60
        UltraGridColumn8.AutoCompleteMode = Infragistics.Win.AutoCompleteMode.Append
        Appearance26.TextHAlignAsString = "Center"
        UltraGridColumn8.CellAppearance = Appearance26
        UltraGridColumn8.Header.VisiblePosition = 1
        UltraGridColumn8.Style = Infragistics.Win.UltraWinGrid.ColumnStyle.DropDown
        UltraGridColumn8.Width = 53
        UltraGridColumn9.AutoCompleteMode = Infragistics.Win.AutoCompleteMode.Append
        Appearance27.TextHAlignAsString = "Right"
        UltraGridColumn9.CellAppearance = Appearance27
        UltraGridColumn9.Header.VisiblePosition = 3
        UltraGridColumn9.Width = 60
        UltraGridColumn10.AutoCompleteMode = Infragistics.Win.AutoCompleteMode.None
        UltraGridColumn10.Header.VisiblePosition = 5
        UltraGridColumn10.Hidden = True
        UltraGridColumn10.Style = Infragistics.Win.UltraWinGrid.ColumnStyle.DropDown
        UltraGridColumn10.Width = 146
        UltraGridColumn11.AutoCompleteMode = Infragistics.Win.AutoCompleteMode.Append
        UltraGridColumn11.DataType = GetType(Short)
        UltraGridColumn11.Header.VisiblePosition = 6
        UltraGridColumn11.Hidden = True
        UltraGridColumn11.Width = 98
        UltraGridColumn12.AutoCompleteMode = Infragistics.Win.AutoCompleteMode.Append
        UltraGridColumn12.Header.VisiblePosition = 7
        UltraGridColumn12.Hidden = True
        UltraGridColumn12.Width = 78
        UltraGridColumn13.AutoCompleteMode = Infragistics.Win.AutoCompleteMode.Append
        UltraGridColumn13.Header.VisiblePosition = 8
        UltraGridColumn13.Hidden = True
        UltraGridColumn13.Width = 66
        UltraGridColumn14.AutoCompleteMode = Infragistics.Win.AutoCompleteMode.Append
        UltraGridColumn14.Header.VisiblePosition = 9
        UltraGridColumn14.Hidden = True
        UltraGridColumn14.Width = 88
        UltraGridColumn15.AutoCompleteMode = Infragistics.Win.AutoCompleteMode.Append
        UltraGridColumn15.Header.VisiblePosition = 10
        UltraGridColumn15.Hidden = True
        UltraGridColumn15.Width = 74
        UltraGridColumn16.DataType = GetType(Short)
        UltraGridColumn16.Header.VisiblePosition = 11
        UltraGridColumn16.Hidden = True
        UltraGridBand1.Columns.AddRange(New Object() {UltraGridColumn5, UltraGridColumn6, UltraGridColumn7, UltraGridColumn8, UltraGridColumn9, UltraGridColumn10, UltraGridColumn11, UltraGridColumn12, UltraGridColumn13, UltraGridColumn14, UltraGridColumn15, UltraGridColumn16})
        Appearance28.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        UltraGridBand1.Header.Appearance = Appearance28
        UltraGridBand1.Override.AllowAddNew = Infragistics.Win.UltraWinGrid.AllowAddNew.Yes
        Me.ugdTableGrid.DisplayLayout.BandsSerializer.Add(UltraGridBand1)
        Me.ugdTableGrid.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Me.ugdTableGrid.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.[False]
        Me.ugdTableGrid.DisplayLayout.DefaultSelectedBackColor = System.Drawing.Color.Empty
        Me.ugdTableGrid.DisplayLayout.DefaultSelectedForeColor = System.Drawing.Color.Empty
        Appearance29.BackColor = System.Drawing.SystemColors.ActiveBorder
        Appearance29.BackColor2 = System.Drawing.SystemColors.ControlDark
        Appearance29.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance29.BorderColor = System.Drawing.SystemColors.Window
        Me.ugdTableGrid.DisplayLayout.GroupByBox.Appearance = Appearance29
        Appearance30.ForeColor = System.Drawing.SystemColors.GrayText
        Me.ugdTableGrid.DisplayLayout.GroupByBox.BandLabelAppearance = Appearance30
        Me.ugdTableGrid.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Appearance31.BackColor = System.Drawing.SystemColors.ControlLightLight
        Appearance31.BackColor2 = System.Drawing.SystemColors.Control
        Appearance31.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal
        Appearance31.ForeColor = System.Drawing.SystemColors.GrayText
        Me.ugdTableGrid.DisplayLayout.GroupByBox.PromptAppearance = Appearance31
        Me.ugdTableGrid.DisplayLayout.MaxColScrollRegions = 1
        Me.ugdTableGrid.DisplayLayout.MaxRowScrollRegions = 1
        Me.ugdTableGrid.DisplayLayout.Override.AllowColMoving = Infragistics.Win.UltraWinGrid.AllowColMoving.NotAllowed
        Me.ugdTableGrid.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.None
        Me.ugdTableGrid.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.None
        Appearance32.BackColor = System.Drawing.SystemColors.Window
        Me.ugdTableGrid.DisplayLayout.Override.CardAreaAppearance = Appearance32
        Appearance33.BorderColor = System.Drawing.Color.Silver
        Appearance33.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter
        Me.ugdTableGrid.DisplayLayout.Override.CellAppearance = Appearance33
        Me.ugdTableGrid.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.EditAndSelectText
        Me.ugdTableGrid.DisplayLayout.Override.CellPadding = 0
        Appearance34.BackColor = System.Drawing.SystemColors.Control
        Appearance34.BackColor2 = System.Drawing.SystemColors.ControlDark
        Appearance34.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element
        Appearance34.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal
        Appearance34.BorderColor = System.Drawing.SystemColors.Window
        Me.ugdTableGrid.DisplayLayout.Override.GroupByRowAppearance = Appearance34
        Appearance35.BackColor = System.Drawing.Color.Gainsboro
        Appearance35.BackColor2 = System.Drawing.Color.Gainsboro
        Appearance35.TextHAlignAsString = "Center"
        Me.ugdTableGrid.DisplayLayout.Override.HeaderAppearance = Appearance35
        Me.ugdTableGrid.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti
        Me.ugdTableGrid.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand
        Appearance36.BackColor = System.Drawing.Color.FromArgb(CType(CType(238, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(238, Byte), Integer))
        Me.ugdTableGrid.DisplayLayout.Override.RowAlternateAppearance = Appearance36
        Appearance37.BackColor = System.Drawing.Color.FromArgb(CType(CType(247, Byte), Integer), CType(CType(247, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.ugdTableGrid.DisplayLayout.Override.RowAppearance = Appearance37
        Me.ugdTableGrid.DisplayLayout.Override.RowSelectorHeaderStyle = Infragistics.Win.UltraWinGrid.RowSelectorHeaderStyle.None
        Me.ugdTableGrid.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.[False]
        Me.ugdTableGrid.DisplayLayout.Override.RowSizing = Infragistics.Win.UltraWinGrid.RowSizing.Sychronized
        Me.ugdTableGrid.DisplayLayout.Override.RowSizingArea = Infragistics.Win.UltraWinGrid.RowSizingArea.RowBordersOnly
        Me.ugdTableGrid.DisplayLayout.Override.SelectTypeCol = Infragistics.Win.UltraWinGrid.SelectType.None
        Me.ugdTableGrid.DisplayLayout.Override.SelectTypeRow = Infragistics.Win.UltraWinGrid.SelectType.[Single]
        Me.ugdTableGrid.DisplayLayout.Override.WrapHeaderText = Infragistics.Win.DefaultableBoolean.[True]
        Me.ugdTableGrid.DisplayLayout.Scrollbars = Infragistics.Win.UltraWinGrid.Scrollbars.None
        Me.ugdTableGrid.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill
        Me.ugdTableGrid.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate
        Me.ugdTableGrid.DisplayLayout.ViewStyle = Infragistics.Win.UltraWinGrid.ViewStyle.SingleBand
        Me.ugdTableGrid.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ugdTableGrid.Location = New System.Drawing.Point(44, 45)
        Me.ugdTableGrid.Name = "ugdTableGrid"
        Me.ugdTableGrid.Size = New System.Drawing.Size(323, 421)
        Me.ugdTableGrid.StyleSetName = "EZGrid"
        Me.ugdTableGrid.TabIndex = 537
        '
        'lblChargesLbl
        '
        Me.lblChargesLbl.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Appearance38.BackColor = System.Drawing.Color.Transparent
        Appearance38.ForeColor = System.Drawing.Color.FromArgb(CType(CType(10, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(130, Byte), Integer))
        Appearance38.TextHAlignAsString = "Right"
        Me.lblChargesLbl.Appearance = Appearance38
        Me.lblChargesLbl.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblChargesLbl.Location = New System.Drawing.Point(59, 532)
        Me.lblChargesLbl.Name = "lblChargesLbl"
        Me.lblChargesLbl.Size = New System.Drawing.Size(231, 20)
        Me.lblChargesLbl.TabIndex = 535
        Me.lblChargesLbl.Text = "Charges:"
        Me.lblChargesLbl.UseAppStyling = False
        '
        'lblBillTotalLbl
        '
        Me.lblBillTotalLbl.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Appearance39.BackColor = System.Drawing.Color.Transparent
        Appearance39.ForeColor = System.Drawing.Color.FromArgb(CType(CType(10, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(130, Byte), Integer))
        Appearance39.TextHAlignAsString = "Right"
        Me.lblBillTotalLbl.Appearance = Appearance39
        Me.lblBillTotalLbl.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBillTotalLbl.Location = New System.Drawing.Point(190, 552)
        Me.lblBillTotalLbl.Name = "lblBillTotalLbl"
        Me.lblBillTotalLbl.Size = New System.Drawing.Size(100, 20)
        Me.lblBillTotalLbl.TabIndex = 534
        Me.lblBillTotalLbl.Text = "Total:"
        Me.lblBillTotalLbl.UseAppStyling = False
        '
        'lblDiscountsLbl
        '
        Me.lblDiscountsLbl.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Appearance40.BackColor = System.Drawing.Color.Transparent
        Appearance40.ForeColor = System.Drawing.Color.FromArgb(CType(CType(10, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(130, Byte), Integer))
        Appearance40.TextHAlignAsString = "Right"
        Me.lblDiscountsLbl.Appearance = Appearance40
        Me.lblDiscountsLbl.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDiscountsLbl.Location = New System.Drawing.Point(59, 512)
        Me.lblDiscountsLbl.Name = "lblDiscountsLbl"
        Me.lblDiscountsLbl.Size = New System.Drawing.Size(231, 20)
        Me.lblDiscountsLbl.TabIndex = 533
        Me.lblDiscountsLbl.Text = "Discounts:"
        Me.lblDiscountsLbl.UseAppStyling = False
        '
        'UltraLabel4
        '
        Me.UltraLabel4.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Appearance41.BackColor = System.Drawing.Color.Transparent
        Appearance41.ForeColor = System.Drawing.Color.FromArgb(CType(CType(10, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(130, Byte), Integer))
        Appearance41.TextHAlignAsString = "Right"
        Me.UltraLabel4.Appearance = Appearance41
        Me.UltraLabel4.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UltraLabel4.Location = New System.Drawing.Point(190, 472)
        Me.UltraLabel4.Name = "UltraLabel4"
        Me.UltraLabel4.Size = New System.Drawing.Size(100, 20)
        Me.UltraLabel4.TabIndex = 532
        Me.UltraLabel4.Text = "Subtotal:"
        Me.UltraLabel4.UseAppStyling = False
        '
        'lblTTips
        '
        Me.lblTTips.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Appearance42.BackColor = System.Drawing.Color.Transparent
        Appearance42.ForeColor = System.Drawing.Color.DimGray
        Appearance42.TextHAlignAsString = "Right"
        Me.lblTTips.Appearance = Appearance42
        Me.lblTTips.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTTips.Location = New System.Drawing.Point(107, 472)
        Me.lblTTips.Name = "lblTTips"
        Me.lblTTips.Size = New System.Drawing.Size(60, 20)
        Me.lblTTips.TabIndex = 543
        Me.lblTTips.Text = "0.00"
        Me.lblTTips.UseAppStyling = False
        Me.lblTTips.Visible = False
        '
        'lblTDrinks
        '
        Me.lblTDrinks.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Appearance43.BackColor = System.Drawing.Color.Transparent
        Appearance43.ForeColor = System.Drawing.Color.FromArgb(CType(CType(10, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(130, Byte), Integer))
        Appearance43.TextHAlignAsString = "Right"
        Me.lblTDrinks.Appearance = Appearance43
        Me.lblTDrinks.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTDrinks.Location = New System.Drawing.Point(284, 492)
        Me.lblTDrinks.Name = "lblTDrinks"
        Me.lblTDrinks.Size = New System.Drawing.Size(60, 20)
        Me.lblTDrinks.TabIndex = 540
        Me.lblTDrinks.Text = "0.00"
        Me.lblTDrinks.UseAppStyling = False
        '
        'lblCharges
        '
        Me.lblCharges.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Appearance44.BackColor = System.Drawing.Color.Transparent
        Appearance44.ForeColor = System.Drawing.Color.FromArgb(CType(CType(10, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(130, Byte), Integer))
        Appearance44.TextHAlignAsString = "Right"
        Me.lblCharges.Appearance = Appearance44
        Me.lblCharges.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCharges.Location = New System.Drawing.Point(284, 532)
        Me.lblCharges.Name = "lblCharges"
        Me.lblCharges.Size = New System.Drawing.Size(60, 20)
        Me.lblCharges.TabIndex = 531
        Me.lblCharges.Text = "0.00"
        Me.lblCharges.UseAppStyling = False
        '
        'lblBillTotal
        '
        Me.lblBillTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Appearance45.BackColor = System.Drawing.Color.Transparent
        Appearance45.ForeColor = System.Drawing.Color.FromArgb(CType(CType(10, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(130, Byte), Integer))
        Appearance45.TextHAlignAsString = "Right"
        Me.lblBillTotal.Appearance = Appearance45
        Me.lblBillTotal.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBillTotal.Location = New System.Drawing.Point(284, 552)
        Me.lblBillTotal.Name = "lblBillTotal"
        Me.lblBillTotal.Size = New System.Drawing.Size(60, 20)
        Me.lblBillTotal.TabIndex = 520
        Me.lblBillTotal.Text = "0.00"
        Me.lblBillTotal.UseAppStyling = False
        '
        'lblDiscounts
        '
        Me.lblDiscounts.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Appearance46.BackColor = System.Drawing.Color.Transparent
        Appearance46.ForeColor = System.Drawing.Color.FromArgb(CType(CType(10, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(130, Byte), Integer))
        Appearance46.TextHAlignAsString = "Right"
        Me.lblDiscounts.Appearance = Appearance46
        Me.lblDiscounts.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDiscounts.Location = New System.Drawing.Point(284, 512)
        Me.lblDiscounts.Name = "lblDiscounts"
        Me.lblDiscounts.Size = New System.Drawing.Size(60, 20)
        Me.lblDiscounts.TabIndex = 519
        Me.lblDiscounts.Text = "0.00"
        Me.lblDiscounts.UseAppStyling = False
        '
        'lblTSubtotal
        '
        Me.lblTSubtotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Appearance47.BackColor = System.Drawing.Color.Transparent
        Appearance47.ForeColor = System.Drawing.Color.FromArgb(CType(CType(10, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(130, Byte), Integer))
        Appearance47.TextHAlignAsString = "Right"
        Me.lblTSubtotal.Appearance = Appearance47
        Me.lblTSubtotal.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTSubtotal.Location = New System.Drawing.Point(284, 472)
        Me.lblTSubtotal.Name = "lblTSubtotal"
        Me.lblTSubtotal.Size = New System.Drawing.Size(60, 20)
        Me.lblTSubtotal.TabIndex = 518
        Me.lblTSubtotal.Text = "0.00"
        Me.lblTSubtotal.UseAppStyling = False
        '
        'UltraTabPageControl2
        '
        Me.UltraTabPageControl2.Controls.Add(Me.pnlDrinks)
        Me.UltraTabPageControl2.Location = New System.Drawing.Point(-10000, -10000)
        Me.UltraTabPageControl2.Name = "UltraTabPageControl2"
        Me.UltraTabPageControl2.Size = New System.Drawing.Size(958, 578)
        '
        'pnlDrinks
        '
        Me.pnlDrinks.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        '
        'pnlDrinks.ClientArea
        '
        Me.pnlDrinks.ClientArea.Controls.Add(Me.UltraPanel2)
        Me.pnlDrinks.ClientArea.Controls.Add(Me.cmdDkPrint)
        Me.pnlDrinks.ClientArea.Controls.Add(Me.cmdDkAddMisc)
        Me.pnlDrinks.ClientArea.Controls.Add(Me.cmdDkClearAll)
        Me.pnlDrinks.ClientArea.Controls.Add(Me.cmdDkDelete)
        Me.pnlDrinks.ClientArea.Controls.Add(Me.cmdDkDeduct)
        Me.pnlDrinks.ClientArea.Controls.Add(Me.cmdDkAdd)
        Me.pnlDrinks.ClientArea.Controls.Add(Me.cmdDkDown)
        Me.pnlDrinks.ClientArea.Controls.Add(Me.cmdDkUp)
        Me.pnlDrinks.ClientArea.Controls.Add(Me.cmdDkClose)
        Me.pnlDrinks.ClientArea.Controls.Add(Me.pnlDrinksContainer)
        Me.pnlDrinks.ClientArea.Controls.Add(Me.UltraLabel5)
        Me.pnlDrinks.ClientArea.Controls.Add(Me.lblDrinksTotal)
        Me.pnlDrinks.ClientArea.Controls.Add(Me.ugdDrinksGrid)
        Me.pnlDrinks.Location = New System.Drawing.Point(3, 3)
        Me.pnlDrinks.Name = "pnlDrinks"
        Me.pnlDrinks.Size = New System.Drawing.Size(1149, 594)
        Me.pnlDrinks.TabIndex = 1
        '
        'UltraPanel2
        '
        Me.UltraPanel2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance48.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.UltraPanel2.Appearance = Appearance48
        '
        'UltraPanel2.ClientArea
        '
        Me.UltraPanel2.ClientArea.Controls.Add(Me.lblDrinksHeader)
        Me.UltraPanel2.Location = New System.Drawing.Point(0, 0)
        Me.UltraPanel2.Name = "UltraPanel2"
        Me.UltraPanel2.Size = New System.Drawing.Size(1150, 42)
        Me.UltraPanel2.StyleSetName = "Reservation"
        Me.UltraPanel2.TabIndex = 586
        Me.UltraPanel2.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblDrinksHeader
        '
        Me.lblDrinksHeader.Anchor = System.Windows.Forms.AnchorStyles.Top
        Appearance49.BackColor = System.Drawing.Color.Transparent
        Appearance49.ForeColor = System.Drawing.Color.Maroon
        Appearance49.TextHAlignAsString = "Center"
        Appearance49.TextVAlignAsString = "Middle"
        Me.lblDrinksHeader.Appearance = Appearance49
        Me.lblDrinksHeader.Font = New System.Drawing.Font("Calibri", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDrinksHeader.Location = New System.Drawing.Point(320, 4)
        Me.lblDrinksHeader.Name = "lblDrinksHeader"
        Me.lblDrinksHeader.Size = New System.Drawing.Size(511, 35)
        Me.lblDrinksHeader.StyleSetName = "Reservation"
        Me.lblDrinksHeader.TabIndex = 460
        Me.lblDrinksHeader.Text = "Drinks for table X"
        Me.lblDrinksHeader.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDkPrint
        '
        Me.cmdDkPrint.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance50.BackColor = System.Drawing.Color.Transparent
        Appearance50.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance50.ForeColor = System.Drawing.Color.Black
        Appearance50.Image = CType(resources.GetObject("Appearance50.Image"), Object)
        Appearance50.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance50.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance50.TextVAlignAsString = "Bottom"
        Me.cmdDkPrint.Appearance = Appearance50
        Me.cmdDkPrint.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdDkPrint.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance51.BackColor = System.Drawing.Color.DarkOrange
        Appearance51.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance51.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance51.BorderColor = System.Drawing.Color.Transparent
        Appearance51.ForeColor = System.Drawing.Color.Black
        Me.cmdDkPrint.HotTrackAppearance = Appearance51
        Me.cmdDkPrint.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdDkPrint.Location = New System.Drawing.Point(1100, 470)
        Me.cmdDkPrint.Name = "cmdDkPrint"
        Appearance52.BackColor = System.Drawing.Color.OrangeRed
        Appearance52.BackColor2 = System.Drawing.Color.Tomato
        Appearance52.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance52.BorderColor = System.Drawing.Color.Transparent
        Me.cmdDkPrint.PressedAppearance = Appearance52
        Me.cmdDkPrint.ShowFocusRect = False
        Me.cmdDkPrint.ShowOutline = False
        Me.cmdDkPrint.Size = New System.Drawing.Size(46, 40)
        Me.cmdDkPrint.StyleSetName = "StatusBar"
        Me.cmdDkPrint.TabIndex = 494
        Me.cmdDkPrint.Tag = "x"
        Me.cmdDkPrint.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDkPrint.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDkPrint.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDkAddMisc
        '
        Me.cmdDkAddMisc.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance53.BackColor = System.Drawing.Color.Transparent
        Appearance53.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance53.ForeColor = System.Drawing.Color.Black
        Appearance53.Image = CType(resources.GetObject("Appearance53.Image"), Object)
        Appearance53.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance53.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance53.TextVAlignAsString = "Bottom"
        Me.cmdDkAddMisc.Appearance = Appearance53
        Me.cmdDkAddMisc.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdDkAddMisc.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance54.BackColor = System.Drawing.Color.DarkOrange
        Appearance54.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance54.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance54.BorderColor = System.Drawing.Color.Transparent
        Appearance54.ForeColor = System.Drawing.Color.Black
        Me.cmdDkAddMisc.HotTrackAppearance = Appearance54
        Me.cmdDkAddMisc.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdDkAddMisc.Location = New System.Drawing.Point(1100, 350)
        Me.cmdDkAddMisc.Name = "cmdDkAddMisc"
        Appearance55.BackColor = System.Drawing.Color.OrangeRed
        Appearance55.BackColor2 = System.Drawing.Color.Tomato
        Appearance55.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance55.BorderColor = System.Drawing.Color.Transparent
        Me.cmdDkAddMisc.PressedAppearance = Appearance55
        Me.cmdDkAddMisc.ShowFocusRect = False
        Me.cmdDkAddMisc.ShowOutline = False
        Me.cmdDkAddMisc.Size = New System.Drawing.Size(46, 40)
        Me.cmdDkAddMisc.StyleSetName = "StatusBar"
        Me.cmdDkAddMisc.TabIndex = 493
        Me.cmdDkAddMisc.Tag = "x"
        Me.cmdDkAddMisc.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDkAddMisc.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDkAddMisc.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDkClearAll
        '
        Me.cmdDkClearAll.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance56.BackColor = System.Drawing.Color.Transparent
        Appearance56.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance56.ForeColor = System.Drawing.Color.Black
        Appearance56.Image = CType(resources.GetObject("Appearance56.Image"), Object)
        Appearance56.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance56.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance56.TextVAlignAsString = "Bottom"
        Me.cmdDkClearAll.Appearance = Appearance56
        Me.cmdDkClearAll.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdDkClearAll.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance57.BackColor = System.Drawing.Color.DarkOrange
        Appearance57.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance57.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance57.BorderColor = System.Drawing.Color.Transparent
        Appearance57.ForeColor = System.Drawing.Color.Black
        Me.cmdDkClearAll.HotTrackAppearance = Appearance57
        Me.cmdDkClearAll.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdDkClearAll.Location = New System.Drawing.Point(1100, 410)
        Me.cmdDkClearAll.Name = "cmdDkClearAll"
        Appearance58.BackColor = System.Drawing.Color.OrangeRed
        Appearance58.BackColor2 = System.Drawing.Color.Tomato
        Appearance58.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance58.BorderColor = System.Drawing.Color.Transparent
        Me.cmdDkClearAll.PressedAppearance = Appearance58
        Me.cmdDkClearAll.ShowFocusRect = False
        Me.cmdDkClearAll.ShowOutline = False
        Me.cmdDkClearAll.Size = New System.Drawing.Size(46, 40)
        Me.cmdDkClearAll.StyleSetName = "StatusBar"
        Me.cmdDkClearAll.TabIndex = 492
        Me.cmdDkClearAll.Tag = "x"
        Me.cmdDkClearAll.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDkClearAll.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDkClearAll.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDkDelete
        '
        Me.cmdDkDelete.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance59.BackColor = System.Drawing.Color.Transparent
        Appearance59.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance59.ForeColor = System.Drawing.Color.Black
        Appearance59.Image = CType(resources.GetObject("Appearance59.Image"), Object)
        Appearance59.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance59.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance59.TextVAlignAsString = "Bottom"
        Me.cmdDkDelete.Appearance = Appearance59
        Me.cmdDkDelete.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdDkDelete.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance60.BackColor = System.Drawing.Color.DarkOrange
        Appearance60.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance60.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance60.BorderColor = System.Drawing.Color.Transparent
        Appearance60.ForeColor = System.Drawing.Color.Black
        Me.cmdDkDelete.HotTrackAppearance = Appearance60
        Me.cmdDkDelete.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdDkDelete.Location = New System.Drawing.Point(1100, 290)
        Me.cmdDkDelete.Name = "cmdDkDelete"
        Appearance61.BackColor = System.Drawing.Color.OrangeRed
        Appearance61.BackColor2 = System.Drawing.Color.Tomato
        Appearance61.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance61.BorderColor = System.Drawing.Color.Transparent
        Me.cmdDkDelete.PressedAppearance = Appearance61
        Me.cmdDkDelete.ShowFocusRect = False
        Me.cmdDkDelete.ShowOutline = False
        Me.cmdDkDelete.Size = New System.Drawing.Size(46, 40)
        Me.cmdDkDelete.StyleSetName = "StatusBar"
        Me.cmdDkDelete.TabIndex = 491
        Me.cmdDkDelete.Tag = "x"
        Me.cmdDkDelete.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDkDelete.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDkDelete.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDkDeduct
        '
        Me.cmdDkDeduct.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance62.BackColor = System.Drawing.Color.Transparent
        Appearance62.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance62.ForeColor = System.Drawing.Color.Black
        Appearance62.Image = CType(resources.GetObject("Appearance62.Image"), Object)
        Appearance62.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance62.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance62.TextVAlignAsString = "Bottom"
        Me.cmdDkDeduct.Appearance = Appearance62
        Me.cmdDkDeduct.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdDkDeduct.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance63.BackColor = System.Drawing.Color.DarkOrange
        Appearance63.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance63.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance63.BorderColor = System.Drawing.Color.Transparent
        Appearance63.ForeColor = System.Drawing.Color.Black
        Me.cmdDkDeduct.HotTrackAppearance = Appearance63
        Me.cmdDkDeduct.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdDkDeduct.Location = New System.Drawing.Point(1100, 230)
        Me.cmdDkDeduct.Name = "cmdDkDeduct"
        Appearance64.BackColor = System.Drawing.Color.OrangeRed
        Appearance64.BackColor2 = System.Drawing.Color.Tomato
        Appearance64.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance64.BorderColor = System.Drawing.Color.Transparent
        Me.cmdDkDeduct.PressedAppearance = Appearance64
        Me.cmdDkDeduct.ShowFocusRect = False
        Me.cmdDkDeduct.ShowOutline = False
        Me.cmdDkDeduct.Size = New System.Drawing.Size(46, 40)
        Me.cmdDkDeduct.StyleSetName = "StatusBar"
        Me.cmdDkDeduct.TabIndex = 490
        Me.cmdDkDeduct.Tag = "-"
        Me.cmdDkDeduct.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDkDeduct.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDkDeduct.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDkAdd
        '
        Me.cmdDkAdd.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance65.BackColor = System.Drawing.Color.Transparent
        Appearance65.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance65.ForeColor = System.Drawing.Color.Black
        Appearance65.Image = CType(resources.GetObject("Appearance65.Image"), Object)
        Appearance65.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance65.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance65.TextVAlignAsString = "Bottom"
        Me.cmdDkAdd.Appearance = Appearance65
        Me.cmdDkAdd.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdDkAdd.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance66.BackColor = System.Drawing.Color.DarkOrange
        Appearance66.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance66.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance66.BorderColor = System.Drawing.Color.Transparent
        Appearance66.ForeColor = System.Drawing.Color.Black
        Me.cmdDkAdd.HotTrackAppearance = Appearance66
        Me.cmdDkAdd.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdDkAdd.Location = New System.Drawing.Point(1100, 170)
        Me.cmdDkAdd.Name = "cmdDkAdd"
        Appearance67.BackColor = System.Drawing.Color.OrangeRed
        Appearance67.BackColor2 = System.Drawing.Color.Tomato
        Appearance67.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance67.BorderColor = System.Drawing.Color.Transparent
        Me.cmdDkAdd.PressedAppearance = Appearance67
        Me.cmdDkAdd.ShowFocusRect = False
        Me.cmdDkAdd.ShowOutline = False
        Me.cmdDkAdd.Size = New System.Drawing.Size(46, 40)
        Me.cmdDkAdd.StyleSetName = "StatusBar"
        Me.cmdDkAdd.TabIndex = 489
        Me.cmdDkAdd.Tag = "+"
        Me.cmdDkAdd.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDkAdd.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDkAdd.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDkDown
        '
        Me.cmdDkDown.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance68.BackColor = System.Drawing.Color.Transparent
        Appearance68.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance68.ForeColor = System.Drawing.Color.Black
        Appearance68.Image = CType(resources.GetObject("Appearance68.Image"), Object)
        Appearance68.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance68.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance68.TextVAlignAsString = "Bottom"
        Me.cmdDkDown.Appearance = Appearance68
        Me.cmdDkDown.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdDkDown.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance69.BackColor = System.Drawing.Color.DarkOrange
        Appearance69.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance69.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance69.BorderColor = System.Drawing.Color.Transparent
        Appearance69.ForeColor = System.Drawing.Color.Black
        Me.cmdDkDown.HotTrackAppearance = Appearance69
        Me.cmdDkDown.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdDkDown.Location = New System.Drawing.Point(1100, 110)
        Me.cmdDkDown.Name = "cmdDkDown"
        Appearance70.BackColor = System.Drawing.Color.OrangeRed
        Appearance70.BackColor2 = System.Drawing.Color.Tomato
        Appearance70.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance70.BorderColor = System.Drawing.Color.Transparent
        Me.cmdDkDown.PressedAppearance = Appearance70
        Me.cmdDkDown.ShowFocusRect = False
        Me.cmdDkDown.ShowOutline = False
        Me.cmdDkDown.Size = New System.Drawing.Size(46, 40)
        Me.cmdDkDown.StyleSetName = "StatusBar"
        Me.cmdDkDown.TabIndex = 488
        Me.cmdDkDown.Tag = "Down"
        Me.cmdDkDown.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDkDown.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDkDown.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDkUp
        '
        Me.cmdDkUp.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance71.BackColor = System.Drawing.Color.Transparent
        Appearance71.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance71.ForeColor = System.Drawing.Color.Black
        Appearance71.Image = CType(resources.GetObject("Appearance71.Image"), Object)
        Appearance71.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance71.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance71.TextVAlignAsString = "Bottom"
        Me.cmdDkUp.Appearance = Appearance71
        Me.cmdDkUp.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdDkUp.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance72.BackColor = System.Drawing.Color.DarkOrange
        Appearance72.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance72.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance72.BorderColor = System.Drawing.Color.Transparent
        Appearance72.ForeColor = System.Drawing.Color.Black
        Me.cmdDkUp.HotTrackAppearance = Appearance72
        Me.cmdDkUp.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdDkUp.Location = New System.Drawing.Point(1100, 50)
        Me.cmdDkUp.Name = "cmdDkUp"
        Appearance73.BackColor = System.Drawing.Color.OrangeRed
        Appearance73.BackColor2 = System.Drawing.Color.Tomato
        Appearance73.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance73.BorderColor = System.Drawing.Color.Transparent
        Me.cmdDkUp.PressedAppearance = Appearance73
        Me.cmdDkUp.ShowFocusRect = False
        Me.cmdDkUp.ShowOutline = False
        Me.cmdDkUp.Size = New System.Drawing.Size(46, 40)
        Me.cmdDkUp.StyleSetName = "StatusBar"
        Me.cmdDkUp.TabIndex = 487
        Me.cmdDkUp.Tag = "Up"
        Me.cmdDkUp.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDkUp.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDkUp.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDkClose
        '
        Me.cmdDkClose.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance74.BackColor = System.Drawing.Color.Transparent
        Appearance74.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance74.ForeColor = System.Drawing.Color.Black
        Appearance74.Image = CType(resources.GetObject("Appearance74.Image"), Object)
        Appearance74.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance74.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance74.TextVAlignAsString = "Bottom"
        Me.cmdDkClose.Appearance = Appearance74
        Me.cmdDkClose.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdDkClose.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance75.BackColor = System.Drawing.Color.DarkOrange
        Appearance75.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance75.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance75.BorderColor = System.Drawing.Color.Transparent
        Appearance75.ForeColor = System.Drawing.Color.Black
        Me.cmdDkClose.HotTrackAppearance = Appearance75
        Me.cmdDkClose.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdDkClose.Location = New System.Drawing.Point(1100, 530)
        Me.cmdDkClose.Name = "cmdDkClose"
        Appearance76.BackColor = System.Drawing.Color.OrangeRed
        Appearance76.BackColor2 = System.Drawing.Color.Tomato
        Appearance76.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance76.BorderColor = System.Drawing.Color.Transparent
        Me.cmdDkClose.PressedAppearance = Appearance76
        Me.cmdDkClose.ShowFocusRect = False
        Me.cmdDkClose.ShowOutline = False
        Me.cmdDkClose.Size = New System.Drawing.Size(46, 40)
        Me.cmdDkClose.StyleSetName = "StatusBar"
        Me.cmdDkClose.TabIndex = 486
        Me.cmdDkClose.Tag = "Return"
        Me.cmdDkClose.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDkClose.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDkClose.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'pnlDrinksContainer
        '
        Me.pnlDrinksContainer.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        '
        'pnlDrinksContainer.ClientArea
        '
        Me.pnlDrinksContainer.ClientArea.Controls.Add(Me.pnlDrinksDrinks)
        Me.pnlDrinksContainer.Location = New System.Drawing.Point(3, 45)
        Me.pnlDrinksContainer.Name = "pnlDrinksContainer"
        Me.pnlDrinksContainer.Size = New System.Drawing.Size(801, 546)
        Me.pnlDrinksContainer.TabIndex = 485
        '
        'pnlDrinksDrinks
        '
        Me.pnlDrinksDrinks.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.pnlDrinksDrinks.AutoSize = True
        Me.pnlDrinksDrinks.BorderStyle = Infragistics.Win.UIElementBorderStyle.None
        Me.pnlDrinksDrinks.Location = New System.Drawing.Point(3, 3)
        Me.pnlDrinksDrinks.Name = "pnlDrinksDrinks"
        Me.pnlDrinksDrinks.Size = New System.Drawing.Size(386, 540)
        Me.pnlDrinksDrinks.TabIndex = 0
        '
        'UltraLabel5
        '
        Me.UltraLabel5.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance77.BackColor = System.Drawing.Color.Transparent
        Appearance77.ForeColor = System.Drawing.Color.FromArgb(CType(CType(10, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(130, Byte), Integer))
        Appearance77.TextHAlignAsString = "Right"
        Me.UltraLabel5.Appearance = Appearance77
        Me.UltraLabel5.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UltraLabel5.Location = New System.Drawing.Point(903, 568)
        Me.UltraLabel5.Name = "UltraLabel5"
        Me.UltraLabel5.Size = New System.Drawing.Size(100, 20)
        Me.UltraLabel5.TabIndex = 473
        Me.UltraLabel5.Text = "Total:"
        Me.UltraLabel5.UseAppStyling = False
        '
        'lblDrinksTotal
        '
        Me.lblDrinksTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance78.BackColor = System.Drawing.Color.Transparent
        Appearance78.ForeColor = System.Drawing.Color.FromArgb(CType(CType(10, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(130, Byte), Integer))
        Appearance78.TextHAlignAsString = "Center"
        Me.lblDrinksTotal.Appearance = Appearance78
        Me.lblDrinksTotal.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDrinksTotal.Location = New System.Drawing.Point(1009, 568)
        Me.lblDrinksTotal.Name = "lblDrinksTotal"
        Me.lblDrinksTotal.Size = New System.Drawing.Size(80, 20)
        Me.lblDrinksTotal.TabIndex = 472
        Me.lblDrinksTotal.Text = "0.00"
        Me.lblDrinksTotal.UseAppStyling = False
        '
        'ugdDrinksGrid
        '
        Me.ugdDrinksGrid.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance79.BackColor = System.Drawing.Color.Transparent
        Appearance79.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Me.ugdDrinksGrid.DisplayLayout.Appearance = Appearance79
        UltraGridColumn1.AutoCompleteMode = Infragistics.Win.AutoCompleteMode.Append
        UltraGridColumn1.Header.Caption = "Name"
        UltraGridColumn1.Header.VisiblePosition = 1
        UltraGridColumn1.Width = 160
        UltraGridColumn2.AutoCompleteMode = Infragistics.Win.AutoCompleteMode.Append
        UltraGridColumn2.Format = ""
        UltraGridColumn2.Header.Caption = "Price"
        UltraGridColumn2.Header.VisiblePosition = 3
        UltraGridColumn2.Hidden = True
        UltraGridColumn2.Width = 60
        UltraGridColumn3.AutoCompleteMode = Infragistics.Win.AutoCompleteMode.Append
        Appearance80.TextHAlignAsString = "Center"
        UltraGridColumn3.CellAppearance = Appearance80
        UltraGridColumn3.Header.Caption = "Qty"
        UltraGridColumn3.Header.VisiblePosition = 0
        UltraGridColumn3.Style = Infragistics.Win.UltraWinGrid.ColumnStyle.DropDown
        UltraGridColumn3.Width = 53
        UltraGridColumn4.AutoCompleteMode = Infragistics.Win.AutoCompleteMode.Append
        Appearance81.TextHAlignAsString = "Right"
        UltraGridColumn4.CellAppearance = Appearance81
        UltraGridColumn4.Format = "#0.00"
        UltraGridColumn4.Header.Caption = "Total"
        UltraGridColumn4.Header.VisiblePosition = 2
        UltraGridColumn4.Width = 60
        UltraGridBand2.Columns.AddRange(New Object() {UltraGridColumn1, UltraGridColumn2, UltraGridColumn3, UltraGridColumn4})
        Appearance82.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        UltraGridBand2.Header.Appearance = Appearance82
        UltraGridBand2.Override.AllowAddNew = Infragistics.Win.UltraWinGrid.AllowAddNew.Yes
        Me.ugdDrinksGrid.DisplayLayout.BandsSerializer.Add(UltraGridBand2)
        Me.ugdDrinksGrid.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Me.ugdDrinksGrid.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.[False]
        Appearance83.BackColor = System.Drawing.SystemColors.ActiveBorder
        Appearance83.BackColor2 = System.Drawing.SystemColors.ControlDark
        Appearance83.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance83.BorderColor = System.Drawing.SystemColors.Window
        Me.ugdDrinksGrid.DisplayLayout.GroupByBox.Appearance = Appearance83
        Appearance84.ForeColor = System.Drawing.SystemColors.GrayText
        Me.ugdDrinksGrid.DisplayLayout.GroupByBox.BandLabelAppearance = Appearance84
        Me.ugdDrinksGrid.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Appearance85.BackColor = System.Drawing.SystemColors.ControlLightLight
        Appearance85.BackColor2 = System.Drawing.SystemColors.Control
        Appearance85.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal
        Appearance85.ForeColor = System.Drawing.SystemColors.GrayText
        Me.ugdDrinksGrid.DisplayLayout.GroupByBox.PromptAppearance = Appearance85
        Me.ugdDrinksGrid.DisplayLayout.MaxColScrollRegions = 1
        Me.ugdDrinksGrid.DisplayLayout.MaxRowScrollRegions = 1
        Appearance86.BackColor = System.Drawing.Color.Orange
        Appearance86.BackColor2 = System.Drawing.Color.DarkOrange
        Appearance86.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ugdDrinksGrid.DisplayLayout.Override.ActiveRowAppearance = Appearance86
        Me.ugdDrinksGrid.DisplayLayout.Override.AllowColMoving = Infragistics.Win.UltraWinGrid.AllowColMoving.NotAllowed
        Me.ugdDrinksGrid.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted
        Me.ugdDrinksGrid.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted
        Appearance87.BackColor = System.Drawing.SystemColors.Window
        Me.ugdDrinksGrid.DisplayLayout.Override.CardAreaAppearance = Appearance87
        Appearance88.BorderColor = System.Drawing.Color.Silver
        Appearance88.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter
        Me.ugdDrinksGrid.DisplayLayout.Override.CellAppearance = Appearance88
        Me.ugdDrinksGrid.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.EditAndSelectText
        Me.ugdDrinksGrid.DisplayLayout.Override.CellPadding = 0
        Appearance89.BackColor = System.Drawing.SystemColors.Control
        Appearance89.BackColor2 = System.Drawing.SystemColors.ControlDark
        Appearance89.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element
        Appearance89.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal
        Appearance89.BorderColor = System.Drawing.SystemColors.Window
        Me.ugdDrinksGrid.DisplayLayout.Override.GroupByRowAppearance = Appearance89
        Appearance90.BackColor = System.Drawing.Color.FromArgb(CType(CType(162, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance90.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(162, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance90.TextHAlignAsString = "Center"
        Me.ugdDrinksGrid.DisplayLayout.Override.HeaderAppearance = Appearance90
        Me.ugdDrinksGrid.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti
        Me.ugdDrinksGrid.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand
        Appearance91.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.ugdDrinksGrid.DisplayLayout.Override.RowAlternateAppearance = Appearance91
        Appearance92.BackColor = System.Drawing.Color.Gainsboro
        Me.ugdDrinksGrid.DisplayLayout.Override.RowAppearance = Appearance92
        Me.ugdDrinksGrid.DisplayLayout.Override.RowSelectorHeaderStyle = Infragistics.Win.UltraWinGrid.RowSelectorHeaderStyle.None
        Me.ugdDrinksGrid.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.[False]
        Me.ugdDrinksGrid.DisplayLayout.Override.RowSizing = Infragistics.Win.UltraWinGrid.RowSizing.Sychronized
        Me.ugdDrinksGrid.DisplayLayout.Override.RowSizingArea = Infragistics.Win.UltraWinGrid.RowSizingArea.RowBordersOnly
        Me.ugdDrinksGrid.DisplayLayout.Override.SelectTypeCol = Infragistics.Win.UltraWinGrid.SelectType.None
        Me.ugdDrinksGrid.DisplayLayout.Override.SelectTypeRow = Infragistics.Win.UltraWinGrid.SelectType.[Single]
        Appearance93.BackColor = System.Drawing.SystemColors.ControlLight
        Me.ugdDrinksGrid.DisplayLayout.Override.TemplateAddRowAppearance = Appearance93
        Me.ugdDrinksGrid.DisplayLayout.Override.WrapHeaderText = Infragistics.Win.DefaultableBoolean.[True]
        Me.ugdDrinksGrid.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill
        Me.ugdDrinksGrid.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate
        Me.ugdDrinksGrid.DisplayLayout.ViewStyle = Infragistics.Win.UltraWinGrid.ViewStyle.SingleBand
        Me.ugdDrinksGrid.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ugdDrinksGrid.Location = New System.Drawing.Point(810, 48)
        Me.ugdDrinksGrid.Name = "ugdDrinksGrid"
        Me.ugdDrinksGrid.Size = New System.Drawing.Size(279, 511)
        Me.ugdDrinksGrid.TabIndex = 474
        '
        'lblStatusbarDivider
        '
        Me.lblStatusbarDivider.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance94.BorderColor = System.Drawing.Color.Silver
        Me.lblStatusbarDivider.Appearance = Appearance94
        Me.lblStatusbarDivider.BorderStyleInner = Infragistics.Win.UIElementBorderStyle.Solid
        Me.lblStatusbarDivider.Location = New System.Drawing.Point(-1, 627)
        Me.lblStatusbarDivider.Name = "lblStatusbarDivider"
        Me.lblStatusbarDivider.Size = New System.Drawing.Size(987, 1)
        Me.lblStatusbarDivider.TabIndex = 549
        '
        'pnlContainer
        '
        Me.pnlContainer.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        '
        'pnlContainer.ClientArea
        '
        Me.pnlContainer.ClientArea.Controls.Add(Me.utcAllPanels)
        Me.pnlContainer.Location = New System.Drawing.Point(0, 0)
        Me.pnlContainer.Name = "pnlContainer"
        Me.pnlContainer.Size = New System.Drawing.Size(984, 621)
        Me.pnlContainer.TabIndex = 550
        '
        'utcAllPanels
        '
        Me.utcAllPanels.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.utcAllPanels.Controls.Add(Me.UltraTabSharedControlsPage1)
        Me.utcAllPanels.Controls.Add(Me.UltraTabPageControl1)
        Me.utcAllPanels.Controls.Add(Me.UltraTabPageControl2)
        Me.utcAllPanels.Controls.Add(Me.UltraTabPageControl3)
        Me.utcAllPanels.Location = New System.Drawing.Point(6, 6)
        Me.utcAllPanels.Name = "utcAllPanels"
        Me.utcAllPanels.SharedControlsPage = Me.UltraTabSharedControlsPage1
        Me.utcAllPanels.Size = New System.Drawing.Size(962, 604)
        Me.utcAllPanels.TabIndex = 551
        Me.utcAllPanels.TabLayoutStyle = Infragistics.Win.UltraWinTabs.TabLayoutStyle.SingleRowSizeToFit
        UltraTab1.Key = "Tables"
        UltraTab1.TabPage = Me.UltraTabPageControl1
        UltraTab1.Text = "Tables"
        UltraTab3.Key = "Bill"
        UltraTab3.TabPage = Me.UltraTabPageControl3
        UltraTab3.Text = "Bill"
        UltraTab2.Key = "Drinks"
        UltraTab2.TabPage = Me.UltraTabPageControl2
        UltraTab2.Text = "Drinks"
        Me.utcAllPanels.Tabs.AddRange(New Infragistics.Win.UltraWinTabControl.UltraTab() {UltraTab1, UltraTab3, UltraTab2})
        Me.utcAllPanels.Visible = False
        '
        'UltraTabSharedControlsPage1
        '
        Me.UltraTabSharedControlsPage1.Location = New System.Drawing.Point(-10000, -10000)
        Me.UltraTabSharedControlsPage1.Name = "UltraTabSharedControlsPage1"
        Me.UltraTabSharedControlsPage1.Size = New System.Drawing.Size(958, 578)
        '
        'uflTables
        '
        Me.uflTables.HorizontalAlignment = Infragistics.Win.Layout.DefaultableFlowLayoutAlignment.Center
        Me.uflTables.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.uflTables.VerticalAlignment = Infragistics.Win.Layout.DefaultableFlowLayoutAlignment.Center
        Me.uflTables.VerticalGap = 30
        Me.uflTables.WrapItems = False
        '
        'uflDinks
        '
        Me.uflDinks.ContainerControl = Me.pnlDrinksDrinks.ClientArea
        Me.uflDinks.HorizontalGap = 1
        Me.uflDinks.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.uflDinks.VerticalAlignment = Infragistics.Win.Layout.DefaultableFlowLayoutAlignment.Near
        Me.uflDinks.VerticalGap = 1
        '
        'udsTableGrid
        '
        UltraDataColumn3.DataType = GetType(Decimal)
        UltraDataColumn5.DataType = GetType(Decimal)
        UltraDataColumn6.DataType = GetType(Short)
        UltraDataColumn7.DataType = GetType(Short)
        UltraDataColumn8.AllowDBNull = Infragistics.Win.DefaultableBoolean.[False]
        UltraDataColumn8.DefaultValue = ""
        UltraDataColumn9.DataType = GetType(Short)
        Me.udsTableGrid.Band.Columns.AddRange(New Object() {UltraDataColumn1, UltraDataColumn2, UltraDataColumn3, UltraDataColumn4, UltraDataColumn5, UltraDataColumn6, UltraDataColumn7, UltraDataColumn8, UltraDataColumn9})
        '
        'DrinksBindingSource
        '
        Me.DrinksBindingSource.DataMember = "Drinks"
        Me.DrinksBindingSource.DataSource = Me.EZMenuDataSet
        '
        'EZMenuDataSet
        '
        Me.EZMenuDataSet.DataSetName = "EZMenuDataSet"
        Me.EZMenuDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'DrinksTableAdapter
        '
        Me.DrinksTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.AltAddressTableAdapter = Nothing
        Me.TableAdapterManager.Alternative_PhoneTableAdapter = Nothing
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.BankingTableAdapter = Nothing
        Me.TableAdapterManager.BankPrintTableAdapter = Nothing
        Me.TableAdapterManager.CallerIDLogTableAdapter = Nothing
        Me.TableAdapterManager.CodesTableAdapter = Nothing
        Me.TableAdapterManager.CollectorTableAdapter = Nothing
        Me.TableAdapterManager.CustomerTableAdapter = Nothing
        Me.TableAdapterManager.DirectionsTableAdapter = Nothing
        Me.TableAdapterManager.DishTableAdapter = Nothing
        Me.TableAdapterManager.DrinksTableAdapter = Me.DrinksTableAdapter
        Me.TableAdapterManager.FreeOffersTableAdapter = Nothing
        Me.TableAdapterManager.GroupsTableAdapter = Nothing
        Me.TableAdapterManager.KitchenNotesTableAdapter = Nothing
        Me.TableAdapterManager.ModifiersTableAdapter = Nothing
        Me.TableAdapterManager.NotesDBTableAdapter = Nothing
        Me.TableAdapterManager.OffersTableAdapter = Nothing
        Me.TableAdapterManager.OrderItemsTableAdapter = Nothing
        Me.TableAdapterManager.OrdersTableAdapter = Nothing
        Me.TableAdapterManager.SetIDTableAdapter = Nothing
        Me.TableAdapterManager.SetMealsTableAdapter = Nothing
        Me.TableAdapterManager.SetSelectedItemsTableAdapter = Nothing
        Me.TableAdapterManager.SetSelectedTableAdapter = Nothing
        Me.TableAdapterManager.SummaryTableAdapter = Nothing
        Me.TableAdapterManager.Table_BillTableAdapter = Nothing
        Me.TableAdapterManager.Table_DrinksTableAdapter = Nothing
        Me.TableAdapterManager.Table_MealTableAdapter = Nothing
        Me.TableAdapterManager.TypicalTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = EZMenu.EZMenuDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        Me.TableAdapterManager.UsersTableAdapter = Nothing
        '
        'cmdClosePanel
        '
        Me.cmdClosePanel.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance95.BackColor = System.Drawing.Color.Transparent
        Appearance95.BackColor2 = System.Drawing.Color.Transparent
        Appearance95.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance95.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance95.BorderColor = System.Drawing.Color.Transparent
        Appearance95.BorderColor2 = System.Drawing.Color.Maroon
        Appearance95.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance95.ForeColor = System.Drawing.Color.White
        Appearance95.Image = CType(resources.GetObject("Appearance95.Image"), Object)
        Appearance95.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance95.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance95.TextVAlignAsString = "Bottom"
        Me.cmdClosePanel.Appearance = Appearance95
        Me.cmdClosePanel.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdClosePanel.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance96.BackColor = System.Drawing.Color.DarkOrange
        Appearance96.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance96.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance96.BorderColor = System.Drawing.Color.Transparent
        Appearance96.ForeColor = System.Drawing.Color.Black
        Me.cmdClosePanel.HotTrackAppearance = Appearance96
        Me.cmdClosePanel.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdClosePanel.Location = New System.Drawing.Point(908, 634)
        Me.cmdClosePanel.Name = "cmdClosePanel"
        Me.cmdClosePanel.Padding = New System.Drawing.Size(15, 0)
        Appearance97.BackColor = System.Drawing.Color.OrangeRed
        Appearance97.BackColor2 = System.Drawing.Color.Tomato
        Appearance97.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance97.BorderColor = System.Drawing.Color.Transparent
        Me.cmdClosePanel.PressedAppearance = Appearance97
        Me.cmdClosePanel.ShowFocusRect = False
        Me.cmdClosePanel.ShowOutline = False
        Me.cmdClosePanel.Size = New System.Drawing.Size(64, 44)
        Me.cmdClosePanel.StyleSetName = "StatusBar"
        Me.cmdClosePanel.TabIndex = 559
        Me.cmdClosePanel.Tag = "Return"
        Me.cmdClosePanel.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdClosePanel.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdClosePanel.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDkPrevious
        '
        Me.cmdDkPrevious.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Appearance98.BackColor = System.Drawing.Color.Transparent
        Appearance98.BackColor2 = System.Drawing.Color.Transparent
        Appearance98.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance98.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance98.BorderColor2 = System.Drawing.Color.Maroon
        Appearance98.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance98.ForeColor = System.Drawing.Color.White
        Appearance98.Image = CType(resources.GetObject("Appearance98.Image"), Object)
        Appearance98.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance98.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance98.TextVAlignAsString = "Bottom"
        Me.cmdDkPrevious.Appearance = Appearance98
        Me.cmdDkPrevious.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdDkPrevious.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance99.BackColor = System.Drawing.Color.DarkOrange
        Appearance99.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance99.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance99.BorderColor = System.Drawing.Color.Transparent
        Appearance99.ForeColor = System.Drawing.Color.Black
        Me.cmdDkPrevious.HotTrackAppearance = Appearance99
        Me.cmdDkPrevious.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdDkPrevious.Location = New System.Drawing.Point(10, 634)
        Me.cmdDkPrevious.Name = "cmdDkPrevious"
        Me.cmdDkPrevious.Padding = New System.Drawing.Size(15, 0)
        Appearance100.BackColor = System.Drawing.Color.OrangeRed
        Appearance100.BackColor2 = System.Drawing.Color.Tomato
        Appearance100.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance100.BorderColor = System.Drawing.Color.Transparent
        Me.cmdDkPrevious.PressedAppearance = Appearance100
        Me.cmdDkPrevious.ShowFocusRect = False
        Me.cmdDkPrevious.ShowOutline = False
        Me.cmdDkPrevious.Size = New System.Drawing.Size(64, 44)
        Me.cmdDkPrevious.StyleSetName = "StatusBar"
        Me.cmdDkPrevious.TabIndex = 579
        Me.cmdDkPrevious.Tag = "Prev dishes"
        Me.cmdDkPrevious.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDkPrevious.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDkPrevious.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdDkPrevious.Visible = False
        '
        'cmdDkNext
        '
        Me.cmdDkNext.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Appearance101.BackColor = System.Drawing.Color.Transparent
        Appearance101.BackColor2 = System.Drawing.Color.Transparent
        Appearance101.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance101.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance101.BorderColor2 = System.Drawing.Color.Maroon
        Appearance101.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance101.ForeColor = System.Drawing.Color.White
        Appearance101.Image = CType(resources.GetObject("Appearance101.Image"), Object)
        Appearance101.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance101.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance101.TextVAlignAsString = "Bottom"
        Me.cmdDkNext.Appearance = Appearance101
        Me.cmdDkNext.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdDkNext.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance102.BackColor = System.Drawing.Color.DarkOrange
        Appearance102.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance102.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance102.BorderColor = System.Drawing.Color.Transparent
        Appearance102.ForeColor = System.Drawing.Color.Black
        Me.cmdDkNext.HotTrackAppearance = Appearance102
        Me.cmdDkNext.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdDkNext.Location = New System.Drawing.Point(80, 634)
        Me.cmdDkNext.Name = "cmdDkNext"
        Me.cmdDkNext.Padding = New System.Drawing.Size(15, 0)
        Appearance103.BackColor = System.Drawing.Color.OrangeRed
        Appearance103.BackColor2 = System.Drawing.Color.Tomato
        Appearance103.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance103.BorderColor = System.Drawing.Color.Transparent
        Me.cmdDkNext.PressedAppearance = Appearance103
        Me.cmdDkNext.ShowFocusRect = False
        Me.cmdDkNext.ShowOutline = False
        Me.cmdDkNext.Size = New System.Drawing.Size(64, 44)
        Me.cmdDkNext.StyleSetName = "StatusBar"
        Me.cmdDkNext.TabIndex = 580
        Me.cmdDkNext.Tag = "Next dishes"
        Me.cmdDkNext.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDkNext.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDkNext.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdDkNext.Visible = False
        '
        'frmTables2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(984, 684)
        Me.ControlBox = False
        Me.Controls.Add(Me.cmdDkPrevious)
        Me.Controls.Add(Me.cmdDkNext)
        Me.Controls.Add(Me.cmdClosePanel)
        Me.Controls.Add(Me.pnlContainer)
        Me.Controls.Add(Me.lblStatusbarDivider)
        Me.DoubleBuffered = True
        Me.MinimumSize = New System.Drawing.Size(1000, 700)
        Me.Name = "frmTables2"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.UltraTabPageControl1.ResumeLayout(False)
        Me.pnlTables.ClientArea.ResumeLayout(False)
        Me.pnlTables.ResumeLayout(False)
        Me.pnlHeader.ClientArea.ResumeLayout(False)
        Me.pnlHeader.ResumeLayout(False)
        Me.UltraTabPageControl3.ResumeLayout(False)
        Me.pnlBill.ClientArea.ResumeLayout(False)
        Me.pnlBill.ResumeLayout(False)
        Me.UltraPanel1.ClientArea.ResumeLayout(False)
        Me.UltraPanel1.ResumeLayout(False)
        Me.upnlMiniTables.ClientArea.ResumeLayout(False)
        Me.upnlMiniTables.ResumeLayout(False)
        CType(Me.ugdTableGrid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.UltraTabPageControl2.ResumeLayout(False)
        Me.pnlDrinks.ClientArea.ResumeLayout(False)
        Me.pnlDrinks.ResumeLayout(False)
        Me.UltraPanel2.ClientArea.ResumeLayout(False)
        Me.UltraPanel2.ResumeLayout(False)
        Me.pnlDrinksContainer.ClientArea.ResumeLayout(False)
        Me.pnlDrinksContainer.ClientArea.PerformLayout()
        Me.pnlDrinksContainer.ResumeLayout(False)
        Me.pnlDrinksDrinks.ResumeLayout(False)
        Me.pnlDrinksDrinks.PerformLayout()
        CType(Me.ugdDrinksGrid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlContainer.ClientArea.ResumeLayout(False)
        Me.pnlContainer.ResumeLayout(False)
        CType(Me.utcAllPanels, System.ComponentModel.ISupportInitialize).EndInit()
        Me.utcAllPanels.ResumeLayout(False)
        CType(Me.uflTables, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.uflDinks, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.udsTableGrid, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.udsDrinks, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DrinksBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EZMenuDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents lblStatusbarDivider As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents pnlContainer As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents utcAllPanels As Infragistics.Win.UltraWinTabControl.UltraTabControl
    Friend WithEvents UltraTabSharedControlsPage1 As Infragistics.Win.UltraWinTabControl.UltraTabSharedControlsPage
    Friend WithEvents UltraTabPageControl1 As Infragistics.Win.UltraWinTabControl.UltraTabPageControl
    Friend WithEvents UltraTabPageControl2 As Infragistics.Win.UltraWinTabControl.UltraTabPageControl
    Friend WithEvents UltraTabPageControl3 As Infragistics.Win.UltraWinTabControl.UltraTabPageControl
    Friend WithEvents pnlTables As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents pnlDrinks As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents pnlBill As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents UltraLabel5 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblDrinksTotal As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents ugdDrinksGrid As Infragistics.Win.UltraWinGrid.UltraGrid
    Friend WithEvents upnlMiniTables As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents lblTipsLabel As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel6 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents ugdTableGrid As Infragistics.Win.UltraWinGrid.UltraGrid
    Friend WithEvents lblChargesLbl As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblBillTotalLbl As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblDiscountsLbl As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel4 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblTTips As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblTDrinks As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblCharges As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblBillTotal As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblDiscounts As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblTSubtotal As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblMiniHilit As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents uflTables As Infragistics.Win.Misc.UltraFlowLayoutManager
    Friend WithEvents tlpTables As TableLayoutPanel
    Friend WithEvents pnlDrinksContainer As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents pnlDrinksDrinks As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents uflDinks As Infragistics.Win.Misc.UltraFlowLayoutManager
    Friend WithEvents cmdDkPrint As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDkAddMisc As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDkClearAll As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDkDelete As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDkDeduct As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDkAdd As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDkDown As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDkUp As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDkClose As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdLightsStatus As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdCAP As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdMoveTable As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdTableDiscounts As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdCovers As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdTablePayment As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdKitchenNote As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdTableKCopy As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdTableClear As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdTableTables As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdTableDrinks As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdTablePrint As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdTableEdit As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdTableDiscard As Infragistics.Win.Misc.UltraButton
    Friend WithEvents lblEntryTime As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents udsTableGrid As Infragistics.Win.UltraWinDataSource.UltraDataSource
    Friend WithEvents udsDrinks As Infragistics.Win.UltraWinDataSource.UltraDataSource
    Friend WithEvents DrinksBindingSource As BindingSource
    Friend WithEvents DrinksTableAdapter As EZMenuDataSetTableAdapters.DrinksTableAdapter
    Friend WithEvents TableAdapterManager As EZMenuDataSetTableAdapters.TableAdapterManager
    Private WithEvents EZMenuDataSet As EZMenuDataSet
    Friend WithEvents cmdClosePanel As Infragistics.Win.Misc.UltraButton
    Friend WithEvents pnlHeader As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents lblHeader As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraPanel1 As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents lblBillHeader As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraPanel2 As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents lblDrinksHeader As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents cmdDkPrevious As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDkNext As Infragistics.Win.Misc.UltraButton
End Class
