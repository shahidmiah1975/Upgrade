﻿Public Class frmAbout

    Private Sub frmAbout_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Try

            Dim strSerial As String = objDB.EZSettingRead("SerialNumber")

            lblVersion.Text = String.Format("Version {0}", Application.ProductVersion) & vbCrLf & My.Application.Info.Copyright

            lblLicensedTo.Text = "Licensed to: " & GetAppSettingCS("BizName", "<your business name is missing>").ToString.Replace("&", "&&")

            tempStr = "<serial number is missing>"
            If strSerial IsNot Nothing Then
                If strSerial <> String.Empty Then tempStr = objSecurity.PadMD5Result(strSerial)
            End If

            lblSerial.Text = "Serial number: " & tempStr

            msg = "Warning: This computer program is protected by copyright law . Unauthorised reproduction or " &
                 "distribution of this program, or any portion of it, may result in severe civil and criminal penalties, " &
                 "and will be prosecuted to the maximum extent possible under law."

            lblDisclaimer.Text = msg

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub cmdOK_Click(sender As Object, e As EventArgs) Handles cmdOK.Click
        Close()
    End Sub

    Private Sub cmdInfo_Click(sender As Object, e As EventArgs) Handles cmdInfo.Click

        strMsgBox = "First run date: " & FormatEZDate(objSecurity.AES_Decrypt(objDB.EZSettingRead("StartupRunTime")))
        strMsgBox &= vbCrLf & "User ID: " & GetSystemIDFromConfig()

        MsgBox(strMsgBox, MsgBoxStyle.OkOnly + MsgBoxStyle.Information, "EZ-Menu Information")

    End Sub

End Class
