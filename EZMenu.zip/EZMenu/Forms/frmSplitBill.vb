﻿Imports EZMenu.Core.Enums
Imports Infragistics.Win.Misc

Public Class frmSplitBill

    'Declare the variables
    Private mousex, mousey As Integer
    Private decTotal, decRemaining, decPaid As Decimal
    Private blnDrag, blnIgnore, blnSplitIsDirty As Boolean
    Private intSplitCovers As Short
    Private _orderType As OrderTypeEnum
    Private _owner As frmPayment

    Public Sub New(objParent As frmPayment, currentOrderType As Object)
        _owner = objParent
        _orderType = currentOrderType
    End Sub

    Private Sub frmSplitBill_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        blnIgnore = True
        decTotal = CDec(_owner.txtBillTotal.Text)
        cmdTipAmount.Enabled = (_orderType = OrderTypeEnum.Table)
        cmdUseTotal.Enabled = cmdTipAmount.Enabled

        If _orderType = OrderTypeEnum.Table Then
            intSplitCovers = Short.Parse(objTables.Covers)
        Else
            intSplitCovers = 1
        End If

        UpdateLabels()
        UpdateTips()

    End Sub

    Private Sub cmdSplitCash_Click(sender As Object, e As EventArgs) Handles cmdSplitCard.Click, cmdSplitCash.Click, cmdSplitOther.Click

        Dim btnSender As UltraButton = CType(sender, UltraButton)
        Dim btnDestination, btnAlternate As UltraButton
        Dim strNumInput As String = String.Empty

        If btnSender.Name.Contains("SplitCash") Then
            btnDestination = cmdSplitCash
            btnAlternate = cmdSplitCard
        ElseIf btnSender.Name.Contains("SplitCard") Then
            btnDestination = cmdSplitCard
            btnAlternate = cmdSplitCash
        Else
            btnDestination = cmdSplitOther
            btnAlternate = Nothing
        End If

        Using objFormQty As New frmQty
            objFormQty.Display("Enter number", "0.00")
            If strNumInput <> "x" Then
                btnDestination.Text = fixCur(strNumInput)
                If GetAppSettingCS("AutoSplitPayment", True) Then
                    If (btnAlternate IsNot Nothing AndAlso cmdBill.Tag = "1") Then btnAlternate.Text = fixCur(decTotal - CDec(strNumInput))
                End If
            End If
        End Using

        UpdateLabels()

    End Sub

    Private Sub cmdSplitCash2_Click(sender As Object, e As EventArgs) Handles cmdSplitCard2.Click, cmdSplitCash2.Click, cmdSplitOther2.Click

        Dim btnSender As UltraButton = CType(sender, UltraButton)
        Dim btnDestination As UltraButton

        If btnSender.Name.Contains("SplitCash") Then
            btnDestination = cmdSplitCash
        ElseIf btnSender.Name.Contains("SplitCard") Then
            btnDestination = cmdSplitCard
        Else
            btnDestination = cmdSplitOther
        End If

        btnDestination.Text = fixCur(Abs(decRemaining))
        UpdateLabels()

    End Sub

    Private Sub UpdateLabels()

        If cmdBill.Tag = "1" Then

            decPaid = CDec(cmdSplitCard.Text) + CDec(cmdSplitCash.Text) + CDec(cmdSplitOther.Text)
            decRemaining = decTotal - decPaid

            tempStr = "Total:" & vbCrLf &
                      "Paid:" & vbCrLf &
                      "Remaining:"
            lblPaymentLabel.Text = tempStr

            tempStr = fixCur(decTotal) & vbCrLf &
                      fixCur(decPaid) & vbCrLf &
                      fixCur(decRemaining)
            lblTotalLabel.Text = tempStr

        End If

        If blnIgnore = True Then blnIgnore = False : Exit Sub

        If _orderType = OrderTypeEnum.Table Then

            If cmdBill.Tag = "1" Then
                SQLQuery = String.Format("UPDATE Table_Bill SET PCash = {0}, PCard = {1}, POther = {2} WHERE TabUniqueID = {3}",
                                         cmdSplitCash.Text, cmdSplitCard.Text, cmdSplitOther.Text, TableInfo(CurTable).Id)
            Else
                SQLQuery = String.Format("UPDATE Table_Bill SET TCash = {0}, TCard = {1}, TOther = {2} WHERE TabUniqueID = {3}",
                                         cmdSplitCash.Text, cmdSplitCard.Text, cmdSplitOther.Text, TableInfo(CurTable).Id)
            End If

            objDB.ExeNonQuery(SQLQuery)

            If _owner.txtTips.Text <> "0.00" Then _owner.txtTips.Text = "0.00"

        End If

        blnSplitIsDirty = True

    End Sub

    Private Sub UpdateTips()

        Dim decTotalTips As Decimal = decTotal * Val(cmdTipAmount.Text.Replace("%", "")) / 100
        Dim decPerHead As Decimal = Math.Round((decTotal + decTotalTips) / intSplitCovers, 2)
        Dim decPerHeadTen As Decimal = fixCurTen(decPerHead)
        Dim tmpStr As String = String.Empty

        tempStr = "Tips:" & vbCrLf &
                  "Bill total:" & vbCrLf &
                  "Per head:"
        lblTipInfo.Text = tempStr

        Dim j = intSplitCovers
        If j > 5 Then j = 5
        For iC = 1 To j
            If iC = j Then tempStr = "Rem: " & fixCur(decTotal - (decPerHeadTen * intSplitCovers) + decPerHeadTen) Else tempStr = fixCur(decPerHeadTen * iC)
            tmpStr &= fixCur((decPerHead)) & " x " & iC & " = " & fixCur(decPerHead * iC) & "    [" & tempStr & "]"
            tmpStr &= vbCrLf
        Next

        tempStr = fixCur(decTotalTips) & vbCrLf &
                  fixCur(decTotal + decTotalTips) & vbCrLf &
                  fixCur(decPerHead)
        lblTipTotals.Text = tempStr
        lblTipsBreakdown.Text = tmpStr
        lblTipsBreakdown.Visible = (intSplitCovers > 1)

        cmdUseTotal.Text = "Use £" & fixCur(decTotal + decTotalTips)
        cmdUseTotal.Tag = decTotal + decTotalTips

    End Sub

    Private Sub cmdBack_Click(sender As Object, e As EventArgs) Handles cmdBack.Click

        If _orderType = OrderTypeEnum.Table AndAlso blnSplitIsDirty = True Then
            ButtonToggle(_owner.cmdTenderCash, cstButTogClr)
            ButtonToggle(_owner.cmdTenderCard, cstButTogClr)
            ButtonToggle(_owner.cmdTenderOther, cstButTogClr)
            SQLQuery = String.Format("UPDATE Table_Bill SET PayMethod = 'Mixed' WHERE TabUniqueID = {0}", TableInfo(CurTable).Id)
            objDB.ExeNonQuery(SQLQuery)
            _owner.cmdSplitPayment.Tag = "Mixed"
        End If

        Dispose()

    End Sub

    Private Sub cmdBill_Click(sender As Object, e As EventArgs) Handles cmdBill.Click, cmdTips.Click

        Dim btnOnButton As UltraButton = CType(sender, UltraButton)
        Dim btnOffButton As UltraButton = CType(sender, UltraButton)

        cmdBill.Tag = 0
        cmdTips.Tag = 0

        If sender.text = "Bill" Then
            btnOnButton = cmdBill
            btnOffButton = cmdTips

            cmdSplitCash.Tag = cmdSplitCash.Text
            cmdSplitCard.Tag = cmdSplitCard.Text
            cmdSplitOther.Tag = cmdSplitOther.Text

            cmdSplitCash.Text = fixCur(cmdSplitCash2.Tag)
            cmdSplitCard.Text = fixCur(cmdSplitCard2.Tag)
            cmdSplitOther.Text = fixCur(cmdSplitOther2.Tag)
        Else
            btnOnButton = cmdTips
            btnOffButton = cmdBill

            cmdSplitCash2.Tag = cmdSplitCash.Text
            cmdSplitCard2.Tag = cmdSplitCard.Text
            cmdSplitOther2.Tag = cmdSplitOther.Text

            cmdSplitCash.Text = fixCur(cmdSplitCash.Tag)
            cmdSplitCard.Text = fixCur(cmdSplitCard.Tag)
            cmdSplitOther.Text = fixCur(cmdSplitOther.Tag)
        End If

        btnOnButton.Appearance.BackColor = Color.Yellow
        btnOnButton.Appearance.BackColor2 = Color.Orange
        btnOnButton.Appearance.ForeColor = Color.Maroon
        btnOnButton.Tag = 1

        btnOffButton.Appearance.ForeColor = Color.White
        btnOffButton.Appearance.BackColor = Color.Maroon
        btnOffButton.Appearance.BackColor2 = Color.Firebrick

    End Sub

    Private Sub cmdTipAmount_Click(sender As Object, e As EventArgs) Handles cmdTipAmount.Click

        Dim strNumInput As String = String.Empty

        Using objForm As New frmQty
            objForm.Display("Enter tip percentage", 0)
        End Using

        If strNumInput <> "x" Then
            cmdTipAmount.Text = strNumInput
        End If

        UpdateTips()

    End Sub

    Private Sub cmdUseTotal_Click(sender As Object, e As EventArgs) Handles cmdUseTotal.Click

        decTotal = cmdUseTotal.Tag
        UpdateLabels()

    End Sub

    Private Sub cmdReset_Click(sender As Object, e As EventArgs) Handles cmdReset.Click

        cmdSplitCash.Text = "0.00"
        cmdSplitCard.Text = "0.00"
        cmdSplitOther.Text = "0.00"

        UpdateLabels()

    End Sub

    Private Sub Form1_MouseDown(sender As Object, e As MouseEventArgs) Handles Me.MouseDown
        blnDrag = True 'Sets the variable drag to true.
        mousex = Cursor.Position.X - Left 'Sets variable mousex
        mousey = Cursor.Position.Y - Top 'Sets variable mousey
    End Sub

    Private Sub Form1_MouseMove(sender As Object, e As MouseEventArgs) Handles Me.MouseMove
        'If drag is set to true then move the form accordingly.
        If blnDrag Then
            Top = Cursor.Position.Y - mousey
            Left = Cursor.Position.X - mousex
        End If
    End Sub

    Private Sub Form1_MouseUp(sender As Object, e As MouseEventArgs) Handles Me.MouseUp
        blnDrag = False 'Sets drag to false, so the form does not move according to the code in MouseMove
    End Sub

    Private Sub cmdSplits_Click(sender As Object, e As EventArgs) Handles cmdSplits.Click

        Dim strNumInput As String

        Using objFormQty As New frmQty
            objFormQty.Display("Enter number of splits", 1)
            strNumInput = objFormQty.ReturnValue
        End Using

        If strNumInput <> "x" Then
            If strNumInput > 5 Then
                Alert("Max splits is 5")
                strNumInput = 5
            End If
            cmdSplits.Text = strNumInput
            intSplitCovers = strNumInput
            UpdateLabels()
            UpdateTips()
        End If

    End Sub

End Class