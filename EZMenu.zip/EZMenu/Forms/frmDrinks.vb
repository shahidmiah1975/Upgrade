﻿Imports System.Configuration
Imports System.IO
Imports EZControls
Imports EZMenu.Core

Public Class frmDrinks

    Dim blnDisposeTablesForm As Boolean = False
    Dim strDrinksFileName As String = "\mydrinks.csv"

    Private Sub frmDrinks_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Try
            MyBase.HeaderText("Drinks Management Screen")
            Size = Owner.Size
            Location = Owner.Location

            DrinksTableAdapter.Connection.ConnectionString = ConfigurationManager.ConnectionStrings(EZConstants.EZDatabaseConnectionString).ConnectionString
            DrinksTableAdapter.Fill(EZMenuDataSet.Drinks)

            GetDrinkGroups()

            lblNumDrinks.Text = "Number of drinks: " & DrinksBindingSource.Count
            optDrinkDisplayMethod.Value = GetAppSettingCS("DrinkDisplayMethod", Nothing)

            cmdLoadFromFile.Enabled = File.Exists(Application.StartupPath & strDrinksFileName)

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub cmdBack_Click(sender As Object, e As EventArgs) Handles cmdBack.Click

        DrinksTableAdapter.Update(EZMenuDataSet.Drinks)
        If blnDisposeTablesForm = True AndAlso objTables IsNot Nothing Then
            objTables = Nothing
        End If

        Close()

    End Sub

    Private Sub cmdAdd_Click(sender As Object, e As EventArgs) Handles cmdAdd.Click

        If txtDrinkName.Text = String.Empty Or txtDrinkPrice.Text = String.Empty Then
            strMsgBox = "Both name and price need to be specified"
            Alert(strMsgBox)
        ElseIf Not IsANumber(txtDrinkPrice.Text) Then
            strMsgBox = "Invalid drink price specified"
            Alert(strMsgBox)
        Else

            'make sure drink is not there already
            SQLQuery = $"SELECT * FROM Drinks WHERE Name = '{txtDrinkName.Text.Trim.Punctuate}'"
            drDataRow = objDB.GetSingleRow(SQLQuery)
            If (drDataRow Is Nothing) Or txtDrinkName.Text = strBlankDrinkField Then

                'insert into db
                Dim myRow As DataRow = EZMenuDataSet.Drinks.NewRow
                myRow.Item("Name") = txtDrinkName.Text
                myRow.Item("Price") = txtDrinkPrice.Text
                myRow.Item("DkGroup") = cmbDrinkGroup.Text
                myRow.Item("Rank") = "1"

                drDataRow = objDB.GetSingleRow("SELECT Max([DkPos]) AS DkPos FROM Drinks")
                Dim DkPos = Val(drDataRow!DkPos.ToString) + 1
                myRow.Item("DkPos") = DkPos

                EZMenuDataSet.Drinks.Rows.Add(myRow)
                DrinksTableAdapter.Update(EZMenuDataSet.Drinks)
                lblNumDrinks.Text = "Number of drinks: " & DrinksBindingSource.Count

                AddGroupToList()

                txtDrinkName.Clear()
                txtDrinkPrice.Clear()
                cmbDrinkGroup.Clear()
                txtDrinkName.Focus()
                blnDisposeTablesForm = True

            Else

                strMsgBox = "That drink already exists in the database."
                Alert(strMsgBox)

            End If

        End If

    End Sub

    Private Sub cmdNew_Click(sender As Object, e As EventArgs) Handles cmdNew.Click

        txtDrinkName.Clear()
        txtDrinkPrice.Clear()
        txtDrinkName.Focus()
        cmbDrinkGroup.Clear()

    End Sub

    Private Sub cmdDelete_Click(sender As Object, e As EventArgs) Handles cmdDelete.Click, cmdDeleteDrink.Click

        Try
            If ugdDrinks.Selected.Rows.Count > 0 Then
                ugdDrinks.DeleteSelectedRows(False)
                DrinksTableAdapter.Update(EZMenuDataSet.Drinks)
                lblNumDrinks.Text = "Number of drinks: " & DrinksBindingSource.Count
                UpdateNumbering()
                blnDisposeTablesForm = True
            Else
                If ugdDrinks.ActiveRow IsNot Nothing Then
                    ugdDrinks.Rows(ugdDrinks.ActiveRow.Index).Selected = True
                    ugdDrinks.ActiveRow.Delete(False)
                    DrinksTableAdapter.Update(EZMenuDataSet.Drinks)
                    lblNumDrinks.Text = "Number of drinks: " & DrinksBindingSource.Count
                    UpdateNumbering()
                    blnDisposeTablesForm = True
                Else
                    strMsgBox = "No item has been selected for deletion"
                    Alert(strMsgBox)
                End If
            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub ugdDrinks_BeforeExitEditMode(sender As Object, e As Infragistics.Win.UltraWinGrid.BeforeExitEditModeEventArgs) Handles ugdDrinks.BeforeExitEditMode

        Dim myCell As Infragistics.Win.UltraWinGrid.UltraGridCell = ugdDrinks.ActiveCell

        Select Case myCell.Column.Key
            Case "Name"
                If myCell.Text.Trim = String.Empty Then
                    strMsgBox = "The drink name must be specified."
                    Alert(strMsgBox)
                    e.Cancel = True
                Else
                    myCell.Value = myCell.Text.Trim
                End If
            Case "Price"
                If Not IsANumber(myCell.Text) Then
                    strMsgBox = "You must specify a valid price."
                    Alert(strMsgBox)
                    e.Cancel = True
                End If
            Case Else
        End Select

    End Sub

    Private Sub txtDrinkName_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtDrinkName.KeyPress

        If e.KeyChar = Chr(Keys.Enter) Then
            If txtDrinkName.Text <> String.Empty Then txtDrinkPrice.Focus()
        End If

    End Sub

    Private Sub txtDrinkPrice_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtDrinkPrice.KeyPress

        If e.KeyChar = Chr(Keys.Enter) Then
            If txtDrinkPrice.Text <> String.Empty Then cmbDrinkGroup.Focus()
        End If

    End Sub

    Private Sub cmdKBPrice_Click(sender As Object, e As EventArgs) Handles cmdKBPrice.Click

        Dim strNumInput As String

        Using objFormQty As New frmQty
            objFormQty.Display("Enter price", txtDrinkPrice.Text)
            strNumInput = objFormQty.ReturnValue
        End Using

        If strNumInput <> "x" Then txtDrinkPrice.Text = fixCur(strNumInput)

    End Sub

    Private Sub cmdDrinkName_Click(sender As Object, e As EventArgs) Handles cmdDrinkName.Click

        strKBInput = EZFullKeyboard.Show(txtDrinkName.Text)
        If strKBInput <> EZKBEscape Then
            txtDrinkName.Text = strKBInput.Trim
        End If

    End Sub

    Private Sub cmdOGUp_Click(sender As Object, e As EventArgs) Handles cmdOGUp.Click, cmdOGDown.Click

        If ugdDrinks.Rows.Count = 0 Then Exit Sub

        If ugdDrinks.ActiveRow Is Nothing Then
            ugdDrinks.ActiveRow = ugdDrinks.Rows(0)
        End If

        If sender.name = "cmdOGUp" Then

            If ugdDrinks.ActiveRow.Index > 0 Then
                ugdDrinks.ActiveRow = ugdDrinks.Rows(ugdDrinks.ActiveRow.Index - 1)
            Else
                ugdDrinks.ActiveRow = ugdDrinks.Rows(ugdDrinks.Rows.Count - 1)
            End If

        Else

            If ugdDrinks.ActiveRow.Index < ugdDrinks.Rows.Count - 1 Then
                ugdDrinks.ActiveRow = ugdDrinks.Rows(ugdDrinks.ActiveRow.Index + 1)
            Else
                ugdDrinks.ActiveRow = ugdDrinks.Rows(0)
            End If

        End If

    End Sub

    Private Sub cmdResetRanks_Click(sender As Object, e As EventArgs) Handles cmdResetRanks.Click

        strMsgBox = "This will reset all drink ranks - are you sure?"
        intMsgBoxResult = EZMsgBox.Show(strMsgBox, MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If intMsgBoxResult = MsgBoxResult.Yes Then
            SQLQuery = "UPDATE Drinks SET Rank = 1"
            objDB.ExeNonQuery(SQLQuery)
            'Alert(strMsgBox, MessageBoxIcon.Information)
            blnDisposeTablesForm = True
        End If

    End Sub

    Private Sub optDrinkDisplayMethod_ValueChanged(sender As Object, e As EventArgs) Handles optDrinkDisplayMethod.ValueChanged

        SaveAppSetting("DrinkDisplayMethod", optDrinkDisplayMethod.Value)
        blnDisposeTablesForm = True

    End Sub

    Private Sub cmbDkGroup_Click(sender As Object, e As EventArgs) Handles cmdDkGroup.Click

        strKBInput = EZFullKeyboard.Show(cmdDkGroup.Text)
        If strKBInput <> EZKBEscape Then
            cmbDrinkGroup.Text = strKBInput.Trim
        End If

    End Sub

    Private Sub AddGroupToList()

        Dim blnFound As Boolean = False

        If cmbDrinkGroup.Items.Count > 0 Then
            For iCntrX As Integer = 0 To cmbDrinkGroup.Items.Count - 1
                If cmbDrinkGroup.Items(iCntrX).ToString.ToUpper = cmbDrinkGroup.Text.ToUpper Then
                    blnFound = True
                    Exit For
                End If
            Next
        End If

        If blnFound = False Then
            cmbDrinkGroup.Items.Add(cmbDrinkGroup.Text)
        End If

    End Sub

    Private Sub cmdDkUp_Click(sender As Object, e As EventArgs) Handles cmdDkUp.Click, cmdDkDown.Click

        If ugdDrinks.ActiveRow IsNot Nothing Then

            Dim acRow As Infragistics.Win.UltraWinGrid.UltraGridRow = ugdDrinks.ActiveRow

            Dim intCode1, intCode2 As Short

            If sender.text = "Up" And ugdDrinks.ActiveRow.Index > 0 Then

                intCode1 = acRow.Cells("DkPos").Value
                intCode2 = ugdDrinks.Rows(ugdDrinks.ActiveRow.Index - 1).Cells("DkPos").Value

                ugdDrinks.Rows.Move(ugdDrinks.ActiveRow, ugdDrinks.ActiveRow.Index - 1)

                acRow.Cells("DkPos").Value = intCode2
                ugdDrinks.Rows(ugdDrinks.ActiveRow.Index + 1).Cells("DkPos").Value = intCode1

            ElseIf sender.text = "Down" And ugdDrinks.ActiveRow.Index < ugdDrinks.Rows.Count - 1 Then

                intCode1 = acRow.Cells("DkPos").Value
                intCode2 = ugdDrinks.Rows(ugdDrinks.ActiveRow.Index + 1).Cells("DkPos").Value

                ugdDrinks.Rows.Move(ugdDrinks.ActiveRow, ugdDrinks.ActiveRow.Index + 1)

                acRow.Cells("DkPos").Value = intCode2
                ugdDrinks.Rows(ugdDrinks.ActiveRow.Index - 1).Cells("DkPos").Value = intCode1

            End If

            ugdDrinks.UpdateData()

        End If

    End Sub

    Private Sub GetDrinkGroups()

        SQLQuery = "SELECT DISTINCT DkGroup FROM Drinks ORDER BY DkGroup"
        drcDatarowCollection = objDB.GetDataRows(SQLQuery)
        If drcDatarowCollection IsNot Nothing Then
            For Each myRow As DataRow In drcDatarowCollection
                tempStr = myRow!DkGroup.ToString()
                cmbDrinkGroup.Items.Add(tempStr)
            Next
        End If

    End Sub

    Private Sub UpdateNumbering()

        SQLQuery = "SELECT * FROM Drinks ORDER BY DkPos"
        drcDatarowCollection = objDB.GetDataRows(SQLQuery)
        If drcDatarowCollection IsNot Nothing Then
            Dim intNewNum As Short = 1
            For Each myRow As DataRow In drcDatarowCollection
                SQLQuery = String.Format("UPDATE Drinks SET DkPos = {0} WHERE DkPos = {1}", intNewNum, Val(myRow!DkPos.ToString()))
                objDB.ExeNonQuery(SQLQuery)
                intNewNum += 1
            Next
            DrinksTableAdapter.FillByNumeric(EZMenuDataSet.Drinks)
            ugdDrinks.Refresh()
        End If

    End Sub

    Private Sub UltraButton1_Click(sender As Object, e As EventArgs)

        UpdateNumbering()

    End Sub

    Private Sub cmbDrinkGroup_KeyPress(sender As Object, e As KeyPressEventArgs) Handles cmbDrinkGroup.KeyPress

        If e.KeyChar = Chr(Keys.Enter) Then cmdAdd_Click(sender, e)

    End Sub

    Private Sub cmdLoadFromFile_Click(sender As Object, e As EventArgs) Handles cmdLoadFromFile.Click

        Dim arrGroups(40), DkName, DkPrice, DkGroup As String
        Dim line = "", strPrevGroup As String = ""
        Dim NItems As Short = 0

        Try

            strMsgBox = "This will delete everything in the drinks table before importing. Are you sure?"
            intResponseBox = EZMsgBox.Show(strMsgBox, MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If intResponseBox = vbYes Then
                SQLQuery = "TRUNCATE TABLE Drinks"
                objDB.ExeNonQuery(SQLQuery)

                Using sr As IO.StreamReader = New IO.StreamReader(Application.StartupPath & strDrinksFileName)
                    line = sr.ReadLine
                    Do While (Not line Is Nothing)
                        Dim arrItems = line.Split(",")
                        DkGroup = arrItems(0).Trim
                        DkName = arrItems(1).Trim
                        DkPrice = arrItems(2).Trim

                        drDataRow = objDB.GetSingleRow("SELECT Max([DkPos]) AS DkPos FROM Drinks")
                        Dim DkPos = Val(drDataRow!DkPos.ToString) + 1

                        'insert drink into the table
                        SQLQuery = String.Format("INSERT INTO Drinks (DkPos, DkGroup, Name, Price, Rank) " &
                                    "VALUES ({0}, '{1}', '{2}', {3}, 1)", DkPos, DkGroup.Punctuate, DkName.Punctuate, DkPrice)
                        objDB.ExeNonQuery(SQLQuery)

                        NItems += 1
                        line = sr.ReadLine
                    Loop
                End Using

                Application.DoEvents()
                strMsgBox = NItems & " drinks have been imported"
                Alert(strMsgBox)

                'load drinks into the grid
                DrinksTableAdapter.FillByNumeric(EZMenuDataSet.Drinks)
                ugdDrinks.Refresh()

                lblNumDrinks.Text = "Number of drinks: " & DrinksBindingSource.Count

            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

End Class