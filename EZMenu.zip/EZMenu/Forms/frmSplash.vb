﻿Public Class frmSplash

    Private Sub frmSplash_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Cursor = Cursors.WaitCursor

        Dim strBizName As String = GetAppSettingCS("BizName", "<name unknown>").ToString.Replace("&", "&&")
        If strBizName = "" Then strBizName = "<name unknown>"
        lblCompany.Text = strBizName
        lblVersion.Text = "Version " & Application.ProductVersion
        lblCopyright.Text = My.Application.Info.Copyright

        Cursor = Cursors.Default

    End Sub

End Class