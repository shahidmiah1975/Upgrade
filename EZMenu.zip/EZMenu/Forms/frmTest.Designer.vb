﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmTest
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim Appearance1 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance2 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance3 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Me.ubtnDC2 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton1 = New Infragistics.Win.Misc.UltraButton()
        Me.SuspendLayout()
        '
        'ubtnDC2
        '
        Appearance1.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(60, Byte), Integer))
        Appearance1.BackColor2 = System.Drawing.Color.IndianRed
        Appearance1.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance1.BorderColor = System.Drawing.Color.SteelBlue
        Appearance1.BorderColor2 = System.Drawing.Color.Brown
        Appearance1.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.ubtnDC2.Appearance = Appearance1
        Me.ubtnDC2.Font = New System.Drawing.Font("Ebrima", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance2.BackColor = System.Drawing.Color.PowderBlue
        Appearance2.BackColor2 = System.Drawing.Color.Aqua
        Appearance2.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance2.ForeColor = System.Drawing.Color.Black
        Me.ubtnDC2.HotTrackAppearance = Appearance2
        Me.ubtnDC2.Location = New System.Drawing.Point(208, 95)
        Me.ubtnDC2.Name = "ubtnDC2"
        Me.ubtnDC2.ShowFocusRect = False
        Me.ubtnDC2.ShowOutline = False
        Me.ubtnDC2.Size = New System.Drawing.Size(188, 50)
        Me.ubtnDC2.TabIndex = 145
        Me.ubtnDC2.Tag = ""
        Me.ubtnDC2.UseAppStyling = False
        Me.ubtnDC2.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnDC2.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.ubtnDC2.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton1
        '
        Appearance3.BorderColor = System.Drawing.Color.FromArgb(CType(CType(190, Byte), Integer), CType(CType(190, Byte), Integer), CType(CType(190, Byte), Integer))
        Me.UltraButton1.Appearance = Appearance3
        Me.UltraButton1.ButtonStyle = Infragistics.Win.UIElementButtonStyle.Flat
        Me.UltraButton1.Location = New System.Drawing.Point(97, 230)
        Me.UltraButton1.Name = "UltraButton1"
        Me.UltraButton1.Size = New System.Drawing.Size(142, 49)
        Me.UltraButton1.TabIndex = 146
        Me.UltraButton1.Text = "UltraButton1"
        Me.UltraButton1.UseAppStyling = False
        Me.UltraButton1.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'frmTest
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(486, 356)
        Me.Controls.Add(Me.UltraButton1)
        Me.Controls.Add(Me.ubtnDC2)
        Me.Name = "frmTest"
        Me.Text = "frmTest"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents ubtnDC2 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton1 As Infragistics.Win.Misc.UltraButton
End Class
