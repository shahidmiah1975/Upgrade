﻿Imports Infragistics.Win.Misc
Imports Infragistics.Win.UltraWinDataSource
Imports System.ComponentModel
Imports System.Configuration
Imports EZControls
Imports EZMenu.Core

Public Class frmCallerIDLog

    Private Sub frmCallerIDLog_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Size = frmOpener.Size
        Location = frmOpener.Location

        CenterToScreen()
        SetupButtons()

        Try

            CallerIDLogTableAdapter.Connection.ConnectionString = ConfigurationManager.ConnectionStrings(EZConstants.EZDatabaseConnectionString).ConnectionString

            SQLQuery = "SELECT CallerIDLog.ID, CallerIDLog.CallTime AS CIDTime, CallerIDLog.Phone, Collector.Name AS Collector, " _
                    & "Customer.Name AS Name, Customer.Address1 + '!' + Customer.Address2 + '!' + Customer.Address3 + ' ' + Customer.Postcode AS Address " _
                    & "FROM (CallerIDLog LEFT JOIN Collector ON CallerIDLog.Phone = Collector.Phone) " _
                    & "LEFT JOIN Customer ON CallerIDLog.Phone = Customer.Phone;"

            drcDatarowCollection = objDB.GetDataRows(SQLQuery)
            If drcDatarowCollection IsNot Nothing Then

                For Each drMyRow As DataRow In drcDatarowCollection
                    Dim udrMyRow As UltraDataRow = udsCallLogs.Rows.Add
                    udrMyRow!ID = drMyRow!ID.ToString
                    udrMyRow!CallTime = drMyRow!CIDTime.ToString
                    udrMyRow!Phone = drMyRow!Phone.ToString
                    udrMyRow!Collector = drMyRow!Collector.ToString
                    udrMyRow!Name = drMyRow!Name.ToString
                    tempStr = drMyRow!Address.ToString.Replace("!!", "!")
                    tempStr = tempStr.Replace("!", vbCrLf)
                    udrMyRow!Address = tempStr
                Next

                ugdCallerIDLog.DataSource = udsCallLogs
                ugdCallerIDLog.DisplayLayout.Override.MinRowHeight = 34
                ugdCallerIDLog.ActiveRow = Nothing

                lblRecords.Text = "Number of calls: " & drcDatarowCollection.Count

            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub SetupButtons()

        For Each myobjx In Controls
            If (TypeName(myobjx) = "UltraButton" And myobjx.width = 126) Then
                Dim myObj As UltraButton = DirectCast(myobjx, UltraButton)
                myObj.Tag = myObj.Text
                myObj.Text = String.Empty
                AddHandler myObj.MouseEnter, AddressOf ButtonMouseEnter
                AddHandler myObj.MouseLeave, AddressOf ButtonMouseLeave
            End If
        Next

    End Sub

    Private Sub ButtonMouseEnter(sender As Object, e As EventArgs)
        sender.text = sender.tag
    End Sub

    Private Sub ButtonMouseLeave(sender As Object, e As EventArgs)
        sender.Text = String.Empty
    End Sub

    Private Sub cmdClose_Click(sender As Object, e As EventArgs) Handles cmdClose.Click

        Close()

    End Sub

    Private Sub wavPlayer_LoadCompleted(sender As Object, e As AsyncCompletedEventArgs)

        Try
            CType(sender, Media.SoundPlayer).Play()
        Catch ex As Exception
            EZMsgBox.Show(ex.Message, MessageBoxButtons.Ok, MessageBoxIcon.Error)
        End Try

    End Sub

    Private Sub cmdOGUp_Click(sender As Object, e As EventArgs) Handles cmdOGUp.Click, cmdOGDown.Click

        If ugdCallerIDLog.Rows.Count = 0 Then Exit Sub

        If ugdCallerIDLog.ActiveRow Is Nothing Then
            ugdCallerIDLog.ActiveRow = ugdCallerIDLog.Rows(0)
        End If

        If sender.name = "cmdOGUp" Then

            If ugdCallerIDLog.ActiveRow.Index > 0 Then
                ugdCallerIDLog.ActiveRow = ugdCallerIDLog.Rows(ugdCallerIDLog.ActiveRow.Index - 1)
            Else
                ugdCallerIDLog.ActiveRow = ugdCallerIDLog.Rows(ugdCallerIDLog.Rows.Count - 1)
            End If

        Else

            If ugdCallerIDLog.ActiveRow.Index < ugdCallerIDLog.Rows.Count - 1 Then
                ugdCallerIDLog.ActiveRow = ugdCallerIDLog.Rows(ugdCallerIDLog.ActiveRow.Index + 1)
            Else
                ugdCallerIDLog.ActiveRow = ugdCallerIDLog.Rows(0)
            End If

        End If

    End Sub

End Class