﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmDrinks
    Inherits EZMenu.frmBaseForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim Appearance1 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraGridBand1 As Infragistics.Win.UltraWinGrid.UltraGridBand = New Infragistics.Win.UltraWinGrid.UltraGridBand("Drinks", -1)
        Dim UltraGridColumn7 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Name")
        Dim UltraGridColumn8 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Price")
        Dim UltraGridColumn9 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Rank")
        Dim UltraGridColumn10 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("DkGroup")
        Dim UltraGridColumn11 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("DkPos")
        Dim UltraGridColumn12 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("ID")
        Dim Appearance2 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance3 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance4 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance5 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance6 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance7 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance8 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance9 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance10 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance11 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance12 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance13 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance14 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance15 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance16 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance17 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance18 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance19 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance20 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance21 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance22 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance23 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance24 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmDrinks))
        Dim Appearance25 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance26 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance27 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance28 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance29 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance30 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance31 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance32 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance33 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance34 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance35 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance36 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance37 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance38 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance39 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance40 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim ValueListItem3 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim ValueListItem4 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim ValueListItem1 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim Appearance41 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance42 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance43 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance44 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance45 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance46 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance47 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance48 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance49 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance50 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance51 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance52 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance53 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance54 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Me.ugdDrinks = New Infragistics.Win.UltraWinGrid.UltraGrid()
        Me.DrinksBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.EZMenuDataSet = New EZMenu.EZMenuDataSet()
        Me.lblShortCode = New Infragistics.Win.Misc.UltraLabel()
        Me.txtDrinkName = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.UltraLabel1 = New Infragistics.Win.Misc.UltraLabel()
        Me.txtDrinkPrice = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.lblNumDrinks = New System.Windows.Forms.Label()
        Me.cmdAdd = New Infragistics.Win.Misc.UltraButton()
        Me.cmdNew = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDelete = New Infragistics.Win.Misc.UltraButton()
        Me.cmdKBPrice = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDrinkName = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDeleteDrink = New Infragistics.Win.Misc.UltraButton()
        Me.cmdOGDown = New Infragistics.Win.Misc.UltraButton()
        Me.cmdOGUp = New Infragistics.Win.Misc.UltraButton()
        Me.cmdResetRanks = New Infragistics.Win.Misc.UltraButton()
        Me.optDrinkDisplayMethod = New Infragistics.Win.UltraWinEditors.UltraOptionSet()
        Me.DrinksTableAdapter = New EZMenu.EZMenuDataSetTableAdapters.DrinksTableAdapter()
        Me.cmdDkGroup = New Infragistics.Win.Misc.UltraButton()
        Me.UltraLabel2 = New Infragistics.Win.Misc.UltraLabel()
        Me.cmbDrinkGroup = New Infragistics.Win.UltraWinEditors.UltraComboEditor()
        Me.cmdDkDown = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDkUp = New Infragistics.Win.Misc.UltraButton()
        Me.cmdLoadFromFile = New Infragistics.Win.Misc.UltraButton()
        Me.cmdBack = New Infragistics.Win.Misc.UltraButton()
        Me.ugbOptions = New Infragistics.Win.Misc.UltraGroupBox()
        Me.uplBasePanel.SuspendLayout()
        CType(Me.ugdDrinks, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DrinksBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EZMenuDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtDrinkName, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtDrinkPrice, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.optDrinkDisplayMethod, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbDrinkGroup, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ugbOptions, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ugbOptions.SuspendLayout()
        Me.SuspendLayout()
        '
        'uplBasePanel
        '
        Me.uplBasePanel.Location = New System.Drawing.Point(0, 772)
        Me.uplBasePanel.Size = New System.Drawing.Size(1000, 50)
        '
        'ugdDrinks
        '
        Me.ugdDrinks.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ugdDrinks.DataSource = Me.DrinksBindingSource
        Appearance1.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance1.BackColor2 = System.Drawing.Color.White
        Appearance1.BackHatchStyle = Infragistics.Win.BackHatchStyle.LightHorizontal
        Appearance1.BorderColor = System.Drawing.Color.Silver
        Me.ugdDrinks.DisplayLayout.Appearance = Appearance1
        UltraGridColumn7.Header.Editor = Nothing
        UltraGridColumn7.Header.VisiblePosition = 1
        UltraGridColumn7.Width = 195
        UltraGridColumn8.Header.Editor = Nothing
        UltraGridColumn8.Header.VisiblePosition = 3
        UltraGridColumn8.Width = 77
        UltraGridColumn9.Header.Editor = Nothing
        UltraGridColumn9.Header.VisiblePosition = 4
        UltraGridColumn9.Hidden = True
        UltraGridColumn10.Header.Caption = "Group"
        UltraGridColumn10.Header.Editor = Nothing
        UltraGridColumn10.Header.VisiblePosition = 2
        UltraGridColumn10.Width = 166
        UltraGridColumn11.Header.Caption = "PID"
        UltraGridColumn11.Header.Editor = Nothing
        UltraGridColumn11.Header.VisiblePosition = 0
        UltraGridColumn12.Header.Editor = Nothing
        UltraGridColumn12.Header.VisiblePosition = 5
        UltraGridColumn12.Hidden = True
        UltraGridBand1.Columns.AddRange(New Object() {UltraGridColumn7, UltraGridColumn8, UltraGridColumn9, UltraGridColumn10, UltraGridColumn11, UltraGridColumn12})
        Appearance2.FontData.SizeInPoints = 11.0!
        UltraGridBand1.Header.Appearance = Appearance2
        UltraGridBand1.Header.Editor = Nothing
        Me.ugdDrinks.DisplayLayout.BandsSerializer.Add(UltraGridBand1)
        Me.ugdDrinks.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Appearance3.FontData.BoldAsString = "True"
        Appearance3.FontData.Name = "Arial"
        Appearance3.FontData.SizeInPoints = 11.0!
        Appearance3.FontData.StrikeoutAsString = "False"
        Appearance3.ForeColor = System.Drawing.Color.MidnightBlue
        Me.ugdDrinks.DisplayLayout.CaptionAppearance = Appearance3
        Me.ugdDrinks.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.[False]
        Appearance4.BackColor = System.Drawing.SystemColors.ActiveBorder
        Appearance4.BackColor2 = System.Drawing.SystemColors.ControlDark
        Appearance4.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance4.BorderColor = System.Drawing.SystemColors.Window
        Me.ugdDrinks.DisplayLayout.GroupByBox.Appearance = Appearance4
        Appearance5.ForeColor = System.Drawing.SystemColors.GrayText
        Me.ugdDrinks.DisplayLayout.GroupByBox.BandLabelAppearance = Appearance5
        Me.ugdDrinks.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Me.ugdDrinks.DisplayLayout.GroupByBox.Hidden = True
        Appearance6.BackColor = System.Drawing.SystemColors.ControlLightLight
        Appearance6.BackColor2 = System.Drawing.SystemColors.Control
        Appearance6.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal
        Appearance6.ForeColor = System.Drawing.SystemColors.GrayText
        Me.ugdDrinks.DisplayLayout.GroupByBox.PromptAppearance = Appearance6
        Me.ugdDrinks.DisplayLayout.MaxColScrollRegions = 1
        Me.ugdDrinks.DisplayLayout.MaxRowScrollRegions = 1
        Appearance7.BackColor = System.Drawing.SystemColors.Window
        Appearance7.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ugdDrinks.DisplayLayout.Override.ActiveCellAppearance = Appearance7
        Appearance8.BackColor = System.Drawing.Color.DarkOrange
        Appearance8.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance8.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ugdDrinks.DisplayLayout.Override.ActiveRowAppearance = Appearance8
        Me.ugdDrinks.DisplayLayout.Override.AllowColMoving = Infragistics.Win.UltraWinGrid.AllowColMoving.NotAllowed
        Me.ugdDrinks.DisplayLayout.Override.AllowColSwapping = Infragistics.Win.UltraWinGrid.AllowColSwapping.NotAllowed
        Me.ugdDrinks.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted
        Me.ugdDrinks.DisplayLayout.Override.BorderStyleHeader = Infragistics.Win.UIElementBorderStyle.Etched
        Me.ugdDrinks.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted
        Appearance9.BackColor = System.Drawing.Color.Transparent
        Me.ugdDrinks.DisplayLayout.Override.CardAreaAppearance = Appearance9
        Appearance10.BackColor = System.Drawing.Color.LightYellow
        Appearance10.BackColor2 = System.Drawing.Color.PaleGoldenrod
        Appearance10.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Me.ugdDrinks.DisplayLayout.Override.CellAppearance = Appearance10
        Me.ugdDrinks.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.EditAndSelectText
        Me.ugdDrinks.DisplayLayout.Override.CellPadding = 0
        Appearance11.BackColor = System.Drawing.SystemColors.Control
        Appearance11.BackColor2 = System.Drawing.SystemColors.ControlDark
        Appearance11.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element
        Appearance11.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal
        Appearance11.BorderColor = System.Drawing.SystemColors.Window
        Me.ugdDrinks.DisplayLayout.Override.GroupByRowAppearance = Appearance11
        Appearance12.BackColor = System.Drawing.Color.CornflowerBlue
        Appearance12.BackColor2 = System.Drawing.Color.RoyalBlue
        Appearance12.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance12.FontData.BoldAsString = "True"
        Appearance12.FontData.SizeInPoints = 9.0!
        Appearance12.ForeColor = System.Drawing.Color.White
        Appearance12.ThemedElementAlpha = Infragistics.Win.Alpha.Transparent
        Me.ugdDrinks.DisplayLayout.Override.HeaderAppearance = Appearance12
        Me.ugdDrinks.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti
        Me.ugdDrinks.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand
        Appearance13.BackColor = System.Drawing.SystemColors.Window
        Appearance13.BorderColor = System.Drawing.Color.Silver
        Me.ugdDrinks.DisplayLayout.Override.RowAppearance = Appearance13
        Appearance14.BackColor = System.Drawing.Color.Transparent
        Appearance14.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ugdDrinks.DisplayLayout.Override.RowSelectorAppearance = Appearance14
        Me.ugdDrinks.DisplayLayout.Override.RowSelectorHeaderStyle = Infragistics.Win.UltraWinGrid.RowSelectorHeaderStyle.SeparateElement
        Me.ugdDrinks.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.[True]
        Me.ugdDrinks.DisplayLayout.Override.RowSelectorWidth = 10
        Me.ugdDrinks.DisplayLayout.Override.RowSizing = Infragistics.Win.UltraWinGrid.RowSizing.AutoFree
        Me.ugdDrinks.DisplayLayout.Override.RowSizingArea = Infragistics.Win.UltraWinGrid.RowSizingArea.RowBordersOnly
        Me.ugdDrinks.DisplayLayout.Override.RowSpacingAfter = 1
        Me.ugdDrinks.DisplayLayout.Override.RowSpacingBefore = 0
        Appearance15.BackColor = System.Drawing.Color.Navy
        Appearance15.BackGradientStyle = Infragistics.Win.GradientStyle.None
        Appearance15.BackHatchStyle = Infragistics.Win.BackHatchStyle.None
        Appearance15.ForeColor = System.Drawing.Color.White
        Me.ugdDrinks.DisplayLayout.Override.SelectedRowAppearance = Appearance15
        Appearance16.BackColor = System.Drawing.SystemColors.ControlLight
        Me.ugdDrinks.DisplayLayout.Override.TemplateAddRowAppearance = Appearance16
        Me.ugdDrinks.DisplayLayout.RowConnectorColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ugdDrinks.DisplayLayout.RowConnectorStyle = Infragistics.Win.UltraWinGrid.RowConnectorStyle.Solid
        Me.ugdDrinks.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill
        Me.ugdDrinks.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate
        Me.ugdDrinks.DisplayLayout.ViewStyle = Infragistics.Win.UltraWinGrid.ViewStyle.SingleBand
        Me.ugdDrinks.DisplayLayout.ViewStyleBand = Infragistics.Win.UltraWinGrid.ViewStyleBand.OutlookGroupBy
        Me.ugdDrinks.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.ugdDrinks.Location = New System.Drawing.Point(109, 62)
        Me.ugdDrinks.Name = "ugdDrinks"
        Me.ugdDrinks.Size = New System.Drawing.Size(523, 687)
        Me.ugdDrinks.TabIndex = 497
        '
        'DrinksBindingSource
        '
        Me.DrinksBindingSource.DataMember = "Drinks"
        Me.DrinksBindingSource.DataSource = Me.EZMenuDataSet
        '
        'EZMenuDataSet
        '
        Me.EZMenuDataSet.DataSetName = "EZMenuDataSet"
        Me.EZMenuDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'lblShortCode
        '
        Appearance17.BackColor = System.Drawing.Color.Transparent
        Appearance17.ForeColor = System.Drawing.Color.SlateGray
        Appearance17.TextHAlignAsString = "Right"
        Me.lblShortCode.Appearance = Appearance17
        Me.lblShortCode.AutoSize = True
        Me.lblShortCode.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblShortCode.Location = New System.Drawing.Point(16, 37)
        Me.lblShortCode.Name = "lblShortCode"
        Me.lblShortCode.Size = New System.Drawing.Size(51, 19)
        Me.lblShortCode.StyleSetName = "TextEntryLabel"
        Me.lblShortCode.TabIndex = 498
        Me.lblShortCode.Text = "Name:"
        '
        'txtDrinkName
        '
        Appearance18.BackColor = System.Drawing.Color.FromArgb(CType(CType(227, Byte), Integer), CType(CType(234, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.txtDrinkName.Appearance = Appearance18
        Me.txtDrinkName.BackColor = System.Drawing.Color.FromArgb(CType(CType(227, Byte), Integer), CType(CType(234, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.txtDrinkName.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDrinkName.Location = New System.Drawing.Point(73, 33)
        Me.txtDrinkName.Name = "txtDrinkName"
        Me.txtDrinkName.Size = New System.Drawing.Size(206, 24)
        Me.txtDrinkName.StyleSetName = "TextEntry"
        Me.txtDrinkName.TabIndex = 499
        Me.txtDrinkName.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtDrinkName.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraLabel1
        '
        Appearance19.BackColor = System.Drawing.Color.Transparent
        Appearance19.ForeColor = System.Drawing.Color.SlateGray
        Appearance19.TextHAlignAsString = "Right"
        Me.UltraLabel1.Appearance = Appearance19
        Me.UltraLabel1.AutoSize = True
        Me.UltraLabel1.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UltraLabel1.Location = New System.Drawing.Point(22, 72)
        Me.UltraLabel1.Name = "UltraLabel1"
        Me.UltraLabel1.Size = New System.Drawing.Size(45, 19)
        Me.UltraLabel1.StyleSetName = "TextEntryLabel"
        Me.UltraLabel1.TabIndex = 506
        Me.UltraLabel1.Text = "Price:"
        '
        'txtDrinkPrice
        '
        Appearance20.BackColor = System.Drawing.Color.FromArgb(CType(CType(227, Byte), Integer), CType(CType(234, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.txtDrinkPrice.Appearance = Appearance20
        Me.txtDrinkPrice.BackColor = System.Drawing.Color.FromArgb(CType(CType(227, Byte), Integer), CType(CType(234, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.txtDrinkPrice.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDrinkPrice.Location = New System.Drawing.Point(73, 68)
        Me.txtDrinkPrice.Name = "txtDrinkPrice"
        Me.txtDrinkPrice.Size = New System.Drawing.Size(77, 24)
        Me.txtDrinkPrice.StyleSetName = "TextEntry"
        Me.txtDrinkPrice.TabIndex = 500
        Me.txtDrinkPrice.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtDrinkPrice.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblNumDrinks
        '
        Me.lblNumDrinks.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblNumDrinks.AutoSize = True
        Me.lblNumDrinks.BackColor = System.Drawing.Color.Transparent
        Me.lblNumDrinks.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNumDrinks.ForeColor = System.Drawing.Color.DimGray
        Me.lblNumDrinks.Location = New System.Drawing.Point(20, 791)
        Me.lblNumDrinks.Name = "lblNumDrinks"
        Me.lblNumDrinks.Size = New System.Drawing.Size(100, 15)
        Me.lblNumDrinks.TabIndex = 512
        Me.lblNumDrinks.Text = "Records founds:"
        '
        'cmdAdd
        '
        Appearance21.BackColor = System.Drawing.Color.Transparent
        Me.cmdAdd.Appearance = Appearance21
        Me.cmdAdd.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdAdd.Location = New System.Drawing.Point(60, 166)
        Me.cmdAdd.Name = "cmdAdd"
        Me.cmdAdd.ShowFocusRect = False
        Me.cmdAdd.ShowOutline = False
        Me.cmdAdd.Size = New System.Drawing.Size(77, 35)
        Me.cmdAdd.StyleSetName = "TextButton"
        Me.cmdAdd.TabIndex = 513
        Me.cmdAdd.Text = "Add"
        Me.cmdAdd.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        '
        'cmdNew
        '
        Appearance22.BackColor = System.Drawing.Color.Transparent
        Me.cmdNew.Appearance = Appearance22
        Me.cmdNew.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdNew.Location = New System.Drawing.Point(143, 166)
        Me.cmdNew.Name = "cmdNew"
        Me.cmdNew.ShowFocusRect = False
        Me.cmdNew.ShowOutline = False
        Me.cmdNew.Size = New System.Drawing.Size(77, 35)
        Me.cmdNew.StyleSetName = "TextButton"
        Me.cmdNew.TabIndex = 515
        Me.cmdNew.Text = "New"
        Me.cmdNew.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        '
        'cmdDelete
        '
        Appearance23.BackColor = System.Drawing.Color.Transparent
        Me.cmdDelete.Appearance = Appearance23
        Me.cmdDelete.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdDelete.Location = New System.Drawing.Point(226, 166)
        Me.cmdDelete.Name = "cmdDelete"
        Me.cmdDelete.ShowFocusRect = False
        Me.cmdDelete.ShowOutline = False
        Me.cmdDelete.Size = New System.Drawing.Size(77, 35)
        Me.cmdDelete.StyleSetName = "TextButton"
        Me.cmdDelete.TabIndex = 516
        Me.cmdDelete.Text = "Delete"
        Me.cmdDelete.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        '
        'cmdKBPrice
        '
        Appearance24.BackColor = System.Drawing.Color.Transparent
        Appearance24.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance24.BackGradientStyle = Infragistics.Win.GradientStyle.None
        Appearance24.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance24.BorderColor = System.Drawing.Color.Transparent
        Appearance24.BorderColor2 = System.Drawing.Color.Transparent
        Appearance24.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance24.ForeColor = System.Drawing.Color.Black
        Appearance24.Image = CType(resources.GetObject("Appearance24.Image"), Object)
        Appearance24.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance24.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance24.TextVAlignAsString = "Bottom"
        Me.cmdKBPrice.Appearance = Appearance24
        Me.cmdKBPrice.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdKBPrice.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance25.BackColor = System.Drawing.Color.DarkOrange
        Appearance25.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance25.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance25.ForeColor = System.Drawing.Color.Black
        Me.cmdKBPrice.HotTrackAppearance = Appearance25
        Me.cmdKBPrice.ImageSize = New System.Drawing.Size(42, 25)
        Me.cmdKBPrice.Location = New System.Drawing.Point(156, 68)
        Me.cmdKBPrice.Name = "cmdKBPrice"
        Appearance26.BackColor = System.Drawing.Color.Transparent
        Appearance26.BackColor2 = System.Drawing.Color.Transparent
        Me.cmdKBPrice.PressedAppearance = Appearance26
        Me.cmdKBPrice.ShowFocusRect = False
        Me.cmdKBPrice.ShowOutline = False
        Me.cmdKBPrice.Size = New System.Drawing.Size(42, 25)
        Me.cmdKBPrice.TabIndex = 546
        Me.cmdKBPrice.Tag = "Keyboard"
        Me.cmdKBPrice.UseAppStyling = False
        Me.cmdKBPrice.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBPrice.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdKBPrice.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDrinkName
        '
        Appearance27.BackColor = System.Drawing.Color.Transparent
        Appearance27.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance27.BackGradientStyle = Infragistics.Win.GradientStyle.None
        Appearance27.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance27.BorderColor = System.Drawing.Color.Transparent
        Appearance27.BorderColor2 = System.Drawing.Color.Transparent
        Appearance27.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance27.ForeColor = System.Drawing.Color.Black
        Appearance27.Image = CType(resources.GetObject("Appearance27.Image"), Object)
        Appearance27.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance27.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance27.TextVAlignAsString = "Bottom"
        Me.cmdDrinkName.Appearance = Appearance27
        Me.cmdDrinkName.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdDrinkName.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance28.BackColor = System.Drawing.Color.DarkOrange
        Appearance28.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance28.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance28.ForeColor = System.Drawing.Color.Black
        Me.cmdDrinkName.HotTrackAppearance = Appearance28
        Me.cmdDrinkName.ImageSize = New System.Drawing.Size(42, 25)
        Me.cmdDrinkName.Location = New System.Drawing.Point(285, 33)
        Me.cmdDrinkName.Name = "cmdDrinkName"
        Appearance29.BackColor = System.Drawing.Color.Transparent
        Appearance29.BackColor2 = System.Drawing.Color.Transparent
        Me.cmdDrinkName.PressedAppearance = Appearance29
        Me.cmdDrinkName.ShowFocusRect = False
        Me.cmdDrinkName.ShowOutline = False
        Me.cmdDrinkName.Size = New System.Drawing.Size(42, 25)
        Me.cmdDrinkName.TabIndex = 547
        Me.cmdDrinkName.Tag = "Keyboard"
        Me.cmdDrinkName.UseAppStyling = False
        Me.cmdDrinkName.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDrinkName.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdDrinkName.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDeleteDrink
        '
        Appearance30.BackColor = System.Drawing.Color.Transparent
        Appearance30.BackColor2 = System.Drawing.Color.Transparent
        Appearance30.ForeColor = System.Drawing.Color.Black
        Appearance30.Image = CType(resources.GetObject("Appearance30.Image"), Object)
        Appearance30.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance30.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance30.TextVAlignAsString = "Bottom"
        Me.cmdDeleteDrink.Appearance = Appearance30
        Me.cmdDeleteDrink.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdDeleteDrink.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance31.BackColor = System.Drawing.Color.DarkOrange
        Appearance31.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance31.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance31.ForeColor = System.Drawing.Color.Black
        Me.cmdDeleteDrink.HotTrackAppearance = Appearance31
        Me.cmdDeleteDrink.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdDeleteDrink.Location = New System.Drawing.Point(16, 216)
        Me.cmdDeleteDrink.Name = "cmdDeleteDrink"
        Appearance32.BackColor = System.Drawing.Color.OrangeRed
        Appearance32.BackColor2 = System.Drawing.Color.Tomato
        Appearance32.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdDeleteDrink.PressedAppearance = Appearance32
        Me.cmdDeleteDrink.ShowFocusRect = False
        Me.cmdDeleteDrink.ShowOutline = False
        Me.cmdDeleteDrink.Size = New System.Drawing.Size(65, 50)
        Me.cmdDeleteDrink.StyleSetName = "StatusBar"
        Me.cmdDeleteDrink.TabIndex = 550
        Me.cmdDeleteDrink.Tag = "x"
        Me.cmdDeleteDrink.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDeleteDrink.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDeleteDrink.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdOGDown
        '
        Appearance33.BackColor = System.Drawing.Color.Transparent
        Appearance33.BackColor2 = System.Drawing.Color.Transparent
        Appearance33.ForeColor = System.Drawing.Color.Black
        Appearance33.Image = CType(resources.GetObject("Appearance33.Image"), Object)
        Appearance33.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance33.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance33.TextVAlignAsString = "Bottom"
        Me.cmdOGDown.Appearance = Appearance33
        Me.cmdOGDown.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdOGDown.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance34.BackColor = System.Drawing.Color.DarkOrange
        Appearance34.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance34.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance34.ForeColor = System.Drawing.Color.Black
        Me.cmdOGDown.HotTrackAppearance = Appearance34
        Me.cmdOGDown.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdOGDown.Location = New System.Drawing.Point(16, 160)
        Me.cmdOGDown.Name = "cmdOGDown"
        Appearance35.BackColor = System.Drawing.Color.OrangeRed
        Appearance35.BackColor2 = System.Drawing.Color.Tomato
        Appearance35.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdOGDown.PressedAppearance = Appearance35
        Me.cmdOGDown.ShowFocusRect = False
        Me.cmdOGDown.ShowOutline = False
        Me.cmdOGDown.Size = New System.Drawing.Size(65, 50)
        Me.cmdOGDown.StyleSetName = "StatusBar"
        Me.cmdOGDown.TabIndex = 549
        Me.cmdOGDown.Tag = "Down"
        Me.cmdOGDown.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOGDown.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOGDown.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdOGUp
        '
        Appearance36.BackColor = System.Drawing.Color.Transparent
        Appearance36.BackColor2 = System.Drawing.Color.Transparent
        Appearance36.ForeColor = System.Drawing.Color.Black
        Appearance36.Image = CType(resources.GetObject("Appearance36.Image"), Object)
        Appearance36.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance36.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance36.TextVAlignAsString = "Bottom"
        Me.cmdOGUp.Appearance = Appearance36
        Me.cmdOGUp.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdOGUp.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance37.BackColor = System.Drawing.Color.DarkOrange
        Appearance37.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance37.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance37.ForeColor = System.Drawing.Color.Black
        Me.cmdOGUp.HotTrackAppearance = Appearance37
        Me.cmdOGUp.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdOGUp.Location = New System.Drawing.Point(16, 104)
        Me.cmdOGUp.Name = "cmdOGUp"
        Appearance38.BackColor = System.Drawing.Color.OrangeRed
        Appearance38.BackColor2 = System.Drawing.Color.Tomato
        Appearance38.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdOGUp.PressedAppearance = Appearance38
        Me.cmdOGUp.ShowFocusRect = False
        Me.cmdOGUp.ShowOutline = False
        Me.cmdOGUp.Size = New System.Drawing.Size(65, 50)
        Me.cmdOGUp.StyleSetName = "StatusBar"
        Me.cmdOGUp.TabIndex = 548
        Me.cmdOGUp.Tag = "Up"
        Me.cmdOGUp.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOGUp.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOGUp.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdResetRanks
        '
        Appearance39.BackColor = System.Drawing.Color.Transparent
        Me.cmdResetRanks.Appearance = Appearance39
        Me.cmdResetRanks.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdResetRanks.Location = New System.Drawing.Point(229, 357)
        Me.cmdResetRanks.Name = "cmdResetRanks"
        Me.cmdResetRanks.ShowFocusRect = False
        Me.cmdResetRanks.ShowOutline = False
        Me.cmdResetRanks.Size = New System.Drawing.Size(90, 35)
        Me.cmdResetRanks.StyleSetName = "TextButton"
        Me.cmdResetRanks.TabIndex = 552
        Me.cmdResetRanks.Text = "Reset ranks"
        Me.cmdResetRanks.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        '
        'optDrinkDisplayMethod
        '
        Appearance40.FontData.Name = "Segoe UI"
        Appearance40.FontData.SizeInPoints = 11.0!
        Appearance40.ForeColor = System.Drawing.Color.SlateGray
        Me.optDrinkDisplayMethod.Appearance = Appearance40
        Me.optDrinkDisplayMethod.BackColor = System.Drawing.Color.Transparent
        Me.optDrinkDisplayMethod.BackColorInternal = System.Drawing.Color.Transparent
        Me.optDrinkDisplayMethod.BorderStyle = Infragistics.Win.UIElementBorderStyle.None
        ValueListItem3.DataValue = "ALPHA"
        ValueListItem3.DisplayText = "Display alphabetically"
        ValueListItem4.DataValue = "RANK"
        ValueListItem4.DisplayText = "Display according to rank"
        ValueListItem1.DataValue = "GROUPED"
        ValueListItem1.DisplayText = "Display grouped"
        Me.optDrinkDisplayMethod.Items.AddRange(New Infragistics.Win.ValueListItem() {ValueListItem3, ValueListItem4, ValueListItem1})
        Me.optDrinkDisplayMethod.Location = New System.Drawing.Point(22, 341)
        Me.optDrinkDisplayMethod.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.optDrinkDisplayMethod.Name = "optDrinkDisplayMethod"
        Me.optDrinkDisplayMethod.Size = New System.Drawing.Size(197, 77)
        Me.optDrinkDisplayMethod.TabIndex = 553
        Me.optDrinkDisplayMethod.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.optDrinkDisplayMethod.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'DrinksTableAdapter
        '
        Me.DrinksTableAdapter.ClearBeforeFill = True
        '
        'cmdDkGroup
        '
        Appearance41.BackColor = System.Drawing.Color.Transparent
        Appearance41.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance41.BackGradientStyle = Infragistics.Win.GradientStyle.None
        Appearance41.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance41.BorderColor = System.Drawing.Color.Transparent
        Appearance41.BorderColor2 = System.Drawing.Color.Transparent
        Appearance41.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance41.ForeColor = System.Drawing.Color.Black
        Appearance41.Image = CType(resources.GetObject("Appearance41.Image"), Object)
        Appearance41.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance41.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance41.TextVAlignAsString = "Bottom"
        Me.cmdDkGroup.Appearance = Appearance41
        Me.cmdDkGroup.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdDkGroup.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance42.BackColor = System.Drawing.Color.DarkOrange
        Appearance42.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance42.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance42.ForeColor = System.Drawing.Color.Black
        Me.cmdDkGroup.HotTrackAppearance = Appearance42
        Me.cmdDkGroup.ImageSize = New System.Drawing.Size(42, 25)
        Me.cmdDkGroup.Location = New System.Drawing.Point(285, 101)
        Me.cmdDkGroup.Name = "cmdDkGroup"
        Appearance43.BackColor = System.Drawing.Color.Transparent
        Appearance43.BackColor2 = System.Drawing.Color.Transparent
        Me.cmdDkGroup.PressedAppearance = Appearance43
        Me.cmdDkGroup.ShowFocusRect = False
        Me.cmdDkGroup.ShowOutline = False
        Me.cmdDkGroup.Size = New System.Drawing.Size(42, 25)
        Me.cmdDkGroup.TabIndex = 556
        Me.cmdDkGroup.Tag = "Keyboard"
        Me.cmdDkGroup.UseAppStyling = False
        Me.cmdDkGroup.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDkGroup.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdDkGroup.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraLabel2
        '
        Appearance44.BackColor = System.Drawing.Color.Transparent
        Appearance44.ForeColor = System.Drawing.Color.SlateGray
        Appearance44.TextHAlignAsString = "Right"
        Me.UltraLabel2.Appearance = Appearance44
        Me.UltraLabel2.AutoSize = True
        Me.UltraLabel2.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UltraLabel2.Location = New System.Drawing.Point(14, 103)
        Me.UltraLabel2.Name = "UltraLabel2"
        Me.UltraLabel2.Size = New System.Drawing.Size(53, 19)
        Me.UltraLabel2.StyleSetName = "TextEntryLabel"
        Me.UltraLabel2.TabIndex = 554
        Me.UltraLabel2.Text = "Group:"
        '
        'cmbDrinkGroup
        '
        Appearance45.BackColor = System.Drawing.Color.FromArgb(CType(CType(227, Byte), Integer), CType(CType(234, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.cmbDrinkGroup.Appearance = Appearance45
        Me.cmbDrinkGroup.BackColor = System.Drawing.Color.FromArgb(CType(CType(227, Byte), Integer), CType(CType(234, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.cmbDrinkGroup.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbDrinkGroup.Location = New System.Drawing.Point(73, 100)
        Me.cmbDrinkGroup.Name = "cmbDrinkGroup"
        Me.cmbDrinkGroup.Size = New System.Drawing.Size(206, 24)
        Me.cmbDrinkGroup.StyleSetName = "TextEntry"
        Me.cmbDrinkGroup.TabIndex = 501
        Me.cmbDrinkGroup.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'cmdDkDown
        '
        Appearance46.BackColor = System.Drawing.Color.Transparent
        Me.cmdDkDown.Appearance = Appearance46
        Me.cmdDkDown.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdDkDown.Location = New System.Drawing.Point(9, 456)
        Me.cmdDkDown.Name = "cmdDkDown"
        Me.cmdDkDown.ShowFocusRect = False
        Me.cmdDkDown.ShowOutline = False
        Me.cmdDkDown.Size = New System.Drawing.Size(86, 45)
        Me.cmdDkDown.StyleSetName = "TextButton"
        Me.cmdDkDown.TabIndex = 559
        Me.cmdDkDown.Text = "Pos Down"
        Me.cmdDkDown.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        '
        'cmdDkUp
        '
        Appearance47.BackColor = System.Drawing.Color.Transparent
        Me.cmdDkUp.Appearance = Appearance47
        Me.cmdDkUp.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdDkUp.Location = New System.Drawing.Point(9, 405)
        Me.cmdDkUp.Name = "cmdDkUp"
        Me.cmdDkUp.ShowFocusRect = False
        Me.cmdDkUp.ShowOutline = False
        Me.cmdDkUp.Size = New System.Drawing.Size(86, 45)
        Me.cmdDkUp.StyleSetName = "TextButton"
        Me.cmdDkUp.TabIndex = 558
        Me.cmdDkUp.Text = "Pos Up"
        Me.cmdDkUp.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        '
        'cmdLoadFromFile
        '
        Appearance48.ForeColor = System.Drawing.Color.Black
        Appearance48.Image = CType(resources.GetObject("Appearance48.Image"), Object)
        Appearance48.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance48.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance48.TextVAlignAsString = "Bottom"
        Me.cmdLoadFromFile.Appearance = Appearance48
        Me.cmdLoadFromFile.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdLoadFromFile.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance49.BackColor = System.Drawing.Color.DarkOrange
        Appearance49.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance49.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance49.ForeColor = System.Drawing.Color.Black
        Me.cmdLoadFromFile.HotTrackAppearance = Appearance49
        Me.cmdLoadFromFile.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdLoadFromFile.Location = New System.Drawing.Point(16, 557)
        Me.cmdLoadFromFile.Name = "cmdLoadFromFile"
        Appearance50.BackColor = System.Drawing.Color.OrangeRed
        Appearance50.BackColor2 = System.Drawing.Color.Tomato
        Appearance50.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdLoadFromFile.PressedAppearance = Appearance50
        Me.cmdLoadFromFile.ShowFocusRect = False
        Me.cmdLoadFromFile.ShowOutline = False
        Me.cmdLoadFromFile.Size = New System.Drawing.Size(65, 50)
        Me.cmdLoadFromFile.StyleSetName = "StatusBar"
        Me.cmdLoadFromFile.TabIndex = 560
        Me.cmdLoadFromFile.Tag = "Back"
        Me.cmdLoadFromFile.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdLoadFromFile.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdLoadFromFile.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdBack
        '
        Me.cmdBack.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Appearance51.BackColor = System.Drawing.Color.Transparent
        Appearance51.BackColor2 = System.Drawing.Color.Transparent
        Appearance51.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance51.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance51.BorderColor = System.Drawing.Color.Transparent
        Appearance51.BorderColor2 = System.Drawing.Color.Maroon
        Appearance51.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance51.ForeColor = System.Drawing.Color.White
        Appearance51.Image = CType(resources.GetObject("Appearance51.Image"), Object)
        Appearance51.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance51.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance51.TextVAlignAsString = "Bottom"
        Me.cmdBack.Appearance = Appearance51
        Me.cmdBack.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance52.BackColor = System.Drawing.Color.DarkOrange
        Appearance52.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance52.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance52.BorderColor = System.Drawing.Color.Transparent
        Appearance52.ForeColor = System.Drawing.Color.Black
        Me.cmdBack.HotTrackAppearance = Appearance52
        Me.cmdBack.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdBack.Location = New System.Drawing.Point(465, 777)
        Me.cmdBack.Name = "cmdBack"
        Appearance53.BackColor = System.Drawing.Color.OrangeRed
        Appearance53.BackColor2 = System.Drawing.Color.Tomato
        Appearance53.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance53.BorderColor = System.Drawing.Color.Transparent
        Me.cmdBack.PressedAppearance = Appearance53
        Me.cmdBack.ShowFocusRect = False
        Me.cmdBack.ShowOutline = False
        Me.cmdBack.Size = New System.Drawing.Size(70, 39)
        Me.cmdBack.StyleSetName = "StatusBar"
        Me.cmdBack.TabIndex = 561
        Me.cmdBack.Tag = "Return"
        Me.cmdBack.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdBack.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdBack.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ugbOptions
        '
        Me.ugbOptions.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance54.BackColor = System.Drawing.Color.Transparent
        Appearance54.BorderColor = System.Drawing.Color.Firebrick
        Me.ugbOptions.Appearance = Appearance54
        Me.ugbOptions.BorderStyle = Infragistics.Win.Misc.GroupBoxBorderStyle.Rectangular3D
        Me.ugbOptions.Controls.Add(Me.txtDrinkName)
        Me.ugbOptions.Controls.Add(Me.lblShortCode)
        Me.ugbOptions.Controls.Add(Me.txtDrinkPrice)
        Me.ugbOptions.Controls.Add(Me.UltraLabel1)
        Me.ugbOptions.Controls.Add(Me.cmdAdd)
        Me.ugbOptions.Controls.Add(Me.optDrinkDisplayMethod)
        Me.ugbOptions.Controls.Add(Me.cmdResetRanks)
        Me.ugbOptions.Controls.Add(Me.cmbDrinkGroup)
        Me.ugbOptions.Controls.Add(Me.cmdNew)
        Me.ugbOptions.Controls.Add(Me.cmdDkGroup)
        Me.ugbOptions.Controls.Add(Me.cmdDelete)
        Me.ugbOptions.Controls.Add(Me.UltraLabel2)
        Me.ugbOptions.Controls.Add(Me.cmdKBPrice)
        Me.ugbOptions.Controls.Add(Me.cmdDrinkName)
        Me.ugbOptions.Location = New System.Drawing.Point(648, 104)
        Me.ugbOptions.Name = "ugbOptions"
        Me.ugbOptions.Size = New System.Drawing.Size(340, 443)
        Me.ugbOptions.TabIndex = 562
        '
        'frmDrinks
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1000, 822)
        Me.Controls.Add(Me.lblNumDrinks)
        Me.Controls.Add(Me.cmdBack)
        Me.Controls.Add(Me.ugbOptions)
        Me.Controls.Add(Me.cmdLoadFromFile)
        Me.Controls.Add(Me.cmdDkDown)
        Me.Controls.Add(Me.cmdDkUp)
        Me.Controls.Add(Me.cmdDeleteDrink)
        Me.Controls.Add(Me.cmdOGDown)
        Me.Controls.Add(Me.cmdOGUp)
        Me.Controls.Add(Me.ugdDrinks)
        Me.Name = "frmDrinks"
        Me.Controls.SetChildIndex(Me.uplBasePanel, 0)
        Me.Controls.SetChildIndex(Me.ugdDrinks, 0)
        Me.Controls.SetChildIndex(Me.cmdOGUp, 0)
        Me.Controls.SetChildIndex(Me.cmdOGDown, 0)
        Me.Controls.SetChildIndex(Me.cmdDeleteDrink, 0)
        Me.Controls.SetChildIndex(Me.cmdDkUp, 0)
        Me.Controls.SetChildIndex(Me.cmdDkDown, 0)
        Me.Controls.SetChildIndex(Me.cmdLoadFromFile, 0)
        Me.Controls.SetChildIndex(Me.ugbOptions, 0)
        Me.Controls.SetChildIndex(Me.cmdBack, 0)
        Me.Controls.SetChildIndex(Me.lblNumDrinks, 0)
        Me.uplBasePanel.ResumeLayout(False)
        CType(Me.ugdDrinks, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DrinksBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EZMenuDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtDrinkName, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtDrinkPrice, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.optDrinkDisplayMethod, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbDrinkGroup, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ugbOptions, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ugbOptions.ResumeLayout(False)
        Me.ugbOptions.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ugdDrinks As Infragistics.Win.UltraWinGrid.UltraGrid
    Friend WithEvents lblShortCode As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents txtDrinkName As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Private WithEvents EZMenuDataSet As EZMenu.EZMenuDataSet
    Friend WithEvents DrinksBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents DrinksTableAdapter As EZMenu.EZMenuDataSetTableAdapters.DrinksTableAdapter
    Friend WithEvents UltraLabel1 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents txtDrinkPrice As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents lblNumDrinks As System.Windows.Forms.Label
    Friend WithEvents cmdAdd As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdNew As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDelete As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdKBPrice As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDrinkName As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDeleteDrink As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdOGDown As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdOGUp As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdResetRanks As Infragistics.Win.Misc.UltraButton
    Friend WithEvents optDrinkDisplayMethod As Infragistics.Win.UltraWinEditors.UltraOptionSet
    Friend WithEvents cmdDkGroup As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraLabel2 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents cmbDrinkGroup As Infragistics.Win.UltraWinEditors.UltraComboEditor
    Friend WithEvents cmdDkDown As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDkUp As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdLoadFromFile As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdBack As Infragistics.Win.Misc.UltraButton
    Private WithEvents ugbOptions As Infragistics.Win.Misc.UltraGroupBox
End Class
