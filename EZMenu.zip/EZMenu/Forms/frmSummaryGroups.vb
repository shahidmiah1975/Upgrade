﻿Imports Infragistics.Win.UltraWinDataSource

Public Class frmSummaryGroups
    Private Sub frmSummaryGroups_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Try

            tempStr = ""
            Dim dblTotal As Double = 0

            'collection's data
            SQLQuery = String.Format("SELECT GroupName AS [Group], Count(*) AS Sold, SUM(Qty * UnitPrice) AS Total " &
                                     "FROM OrderItems JOIN Groups " &
                                     "ON OrderItems.GroupIndex = Groups.GroupIndex " &
                                     "GROUP BY GroupName " &
                                     "ORDER BY GroupName")

            drcDatarowCollection = objDB.GetDataRows(SQLQuery)
            If drcDatarowCollection.Count > 0 Then
                For Each drRow In drcDatarowCollection
                    Dim udrMyRow As UltraDataRow = udsGroupSummary.Rows.Add
                    udrMyRow!Group = drRow!Group.ToString
                    udrMyRow!Sold = drRow!Sold.ToString
                    udrMyRow!Total = drRow!Total.ToString
                    dblTotal += CDbl(drRow!Total)
                Next
            End If

            ugdGroupSummary.DataSource = udsGroupSummary
            ugdGroupSummary.DisplayLayout.Override.MinRowHeight = 34
            ugdGroupSummary.ActiveRow = Nothing

            lblTotal.Text = "Total:  " & dblTotal.ToString("#,0.00")

            cmdPrint.Enabled = (ugdGroupSummary.Rows.Count > 0)

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub cmdBack_Click(sender As Object, e As EventArgs) Handles cmdBack.Click

        Close()

    End Sub

    Private Sub cmdPrint_Click(sender As Object, e As EventArgs) Handles cmdPrint.Click

        PrintSummaryGroups(udsGroupSummary)

    End Sub

End Class