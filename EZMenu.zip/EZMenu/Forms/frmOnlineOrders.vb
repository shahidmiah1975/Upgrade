﻿Imports System.Net
Imports EZMenu.Core.Enums
Imports EZService
Imports EZMenu.Core.Models
Imports EZService.Repository
Imports Infragistics.Win
Imports Infragistics.Win.UltraWinGrid

Public Class frmOnlineOrders

    Private intCheckInterval As Single = 0.25   'number of minutes
    Private SQLQuery As String
    Private intNewOrderRowList As New List(Of Short)
    Private intRowNumber As Short = -1
    Private intCountClick As Short
    Private clrNormBack As Color = Color.PeachPuff
    Private clrNormFore As Color = Color.Black
    Private clrNewBack As Color = Color.Red
    Private clrNewFore As Color = Color.White
    Private onlineServiceManager As OnlineOrderService
    Private orderRepo As New OrderRepository()

    Const strAppTitle As String = "EZ-Menu OMS"

    Public Sub New(objOwnerForm As Form)

        InitializeComponent()

        Size = objOwnerForm.Size
        Location = objOwnerForm.Location
        Refresh()

        Try
            onlineServiceManager = New OnlineOrderService()
            lblLastUpdate.Text = String.Format("Last update: 00:00:00")
            lblNextUpdate.Text = String.Format("Next update: 00:00:00")

            For iC As Short = 1 To 15
                cmbTimeInterval.Items.Add(iC.ToString)
            Next
            cmbTimeInterval.SelectedIndex = GetAppSettingCS("OLUpdateInterval", 0)

            intCheckInterval = cmbTimeInterval.Text
            Dim msecs As Integer = intCheckInterval * 60 * 1000    'number of milliseconds
            tmrCheckOnline.Interval = msecs

            chkAutoPrint.Checked = GetAppSettingCS("OLAutoPrint", 0)

            GetOrdersByDate("2025-02-13")

            StartCheckByTimer()

            Show()

            'SendToBack()

        Catch ex As Exception
            MsgBox(ex.Message, , strAppTitle)
        End Try

        Application.DoEvents()

    End Sub

    Friend Sub Display()
        Show()
        BringToFront()
    End Sub

    Private Sub GetOrders()

        DisplayStatus("Retrieving information...")
        ugdOrders.DataSource = Nothing
        ugdOrderItems.DataSource = Nothing
        Dim orders As List(Of OLOrderModel) = onlineServiceManager.GetAllOrders()
        ugdOrders.DataSource = orders
        DisplayStatus(String.Empty)

    End Sub

    Private Sub GetOrdersByDate(orderDate As String)

        DisplayStatus("Retrieving information...")
        ugdOrders.DataSource = Nothing
        ugdOrderItems.DataSource = Nothing
        Dim orders As List(Of OLOrderModel) = onlineServiceManager.GetOrdersByDate(orderDate)
        ugdOrders.DataSource = orders
        FormatGrid()
        DisplayStatus(String.Empty)

        If ugdOrders.Rows.Count > 0 Then
            ugdOrders.ActiveRow = ugdOrders.Rows(0)
            GetOrderDetails(ugdOrders.ActiveRow.Cells("OrderID").Text)
        End If

        ProcessOrders()

    End Sub

    Private Sub FormatGrid()

        Dim column As UltraGridColumn = ugdOrders.DisplayLayout.Bands(0).Columns("FullAddress")
        column.CellMultiLine = DefaultableBoolean.True
        column.Header.Caption = "Address"
        column.AutoSizeMode = ColumnAutoSizeMode.VisibleRows

        ugdOrders.DisplayLayout.Bands(0).Columns("OrderID").Header.Caption = "Order ID"
        ugdOrders.DisplayLayout.Bands(0).Columns("OrderID").Width = 50

        ugdOrders.DisplayLayout.Bands(0).Columns("CustomerName").Header.Caption = "Name"
        ugdOrders.DisplayLayout.Bands(0).Columns("EmailAddress").Header.Caption = "Email"
        ugdOrders.DisplayLayout.Bands(0).Columns("Phone").Width = 80

        ugdOrders.DisplayLayout.Bands(0).Columns("BillTotal").Header.Caption = "Total"
        ugdOrders.DisplayLayout.Bands(0).Columns("BillTotal").Width = 60

        ugdOrders.DisplayLayout.Bands(0).Columns("OrderType").Width = 60
        ugdOrders.DisplayLayout.Bands(0).Columns("PaymentMethod").Header.Caption = "Payment"
        ugdOrders.DisplayLayout.Bands(0).Columns("PaymentMethod").Width = 100

        ugdOrders.DisplayLayout.Bands(0).Columns("OrderNote").Header.Caption = "Note"
        ugdOrders.DisplayLayout.Bands(0).Columns("BillTotal").Format = "C2"

        ugdOrders.DisplayLayout.Bands(0).Override.RowSizing = RowSizing.AutoFree
        ugdOrders.DisplayLayout.Bands(0).Columns("Address1").Hidden = True
        ugdOrders.DisplayLayout.Bands(0).Columns("Address2").Hidden = True
        ugdOrders.DisplayLayout.Bands(0).Columns("Postcode").Hidden = True
        ugdOrders.DisplayLayout.Bands(0).Columns("OrderDate").Hidden = True
        ugdOrders.DisplayLayout.AutoFitStyle = AutoFitStyle.ResizeAllColumns

    End Sub

    Private Sub GetOrderItems(orderId As Short)

        Dim orderItems As List(Of OLOrderDetailsModel) = onlineServiceManager.GetOrderItems(orderId)

        If orderItems IsNot Nothing Then
            ugdOrderItems.DataSource = orderItems
        Else
            ugdOrderItems.DataSource = Nothing
        End If

    End Sub

    Private Sub ProcessOrders()

        Try

            Dim orderIds As List(Of Short) = orderRepo.GetOnlineOrderIds()

            tmrCheckOnline.Enabled = False

            'highlight new orders
            For Each myRow In ugdOrders.Rows
                If orderIds.Contains(myRow.Cells("OrderID").Text) = True Then
                    myRow.Appearance.BackColor = clrNormBack
                    myRow.Appearance.ForeColor = clrNormFore
                Else
                    myRow.Appearance.BackColor = clrNewBack
                    myRow.Appearance.ForeColor = clrNewFore
                    Visible = True
                    If chkBringToFront.Checked = True And chkAutoPrint.Checked = False Then
                        If ActiveForm Is Nothing OrElse TypeOf ActiveForm Is frmOpener Then BringToFront()
                    End If
                End If
            Next

            For Each myRow In ugdOrders.Rows
                If orderIds.Contains(myRow.Cells("OrderID").Text) = False Then
                    PrintOnlineOrder(myRow.Cells("OrderID").Text)
                    myRow.Appearance.BackColor = clrNormBack
                    myRow.Appearance.ForeColor = clrNormFore
                End If
            Next

            cmdStartTimer.Text = "Stop Online Checks"
            DisplayStatus(String.Empty)
            lblLastUpdate.Text = String.Format("Last check:  {0}", Format(Now, "H:mm:ss"))
            lblNextUpdate.Text = String.Format("Next check:  {0}", Format(Now.AddMilliseconds(tmrCheckOnline.Interval), "H:mm:ss"))
            Application.DoEvents()

        Catch webEx As WebException
            MsgBox(webEx.Message, , strAppTitle)
            DisplayStatus($"Last check was unsuccessful: {Format(Now, "H:mm:ss")}")

        Catch ex As Exception
            MsgBox(ex.Message, , strAppTitle)
            DisplayStatus($"Last check was unsuccessful: {Format(Now, "H:mm:ss")}")

        End Try

        tmrCheckOnline.Enabled = True

    End Sub

    Private Sub cmdFetchToday_Click(sender As Object, e As EventArgs) Handles cmdFetchToday.Click

        'get all orders for today
        GetOrdersByDate("2025-02-13")

    End Sub

    Private Sub cmdGetOrderItems_Click(sender As Object, e As EventArgs) Handles cmdGetOrderItems.Click

        Try

            Dim row As UltraGridRow = ugdOrders.ActiveRow
            If (row IsNot Nothing) Then
                'DisplayStatus("Retrieving order details . . .")
                'GetOrderItems(row.Cells("OrderID").Text)
                'cmdPrintOrder.Enabled = (ugdOrderItems.Rows.Count > 0)
                'DisplayStatus(String.Empty)
                GetOrderDetails(row.Cells("OrderID").Text)
            Else
                MsgBox("There are no orders to get details of.", MsgBoxStyle.OkOnly + MsgBoxStyle.Exclamation, strAppTitle)
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub GetOrderDetails(orderId As Short)
        DisplayStatus("Retrieving order details . . .")
        GetOrderItems(orderId)
        cmdPrintOrder.Enabled = (ugdOrderItems.Rows.Count > 0)
        DisplayStatus(String.Empty)
    End Sub

    Private Sub cmdPrintOrder_Click(sender As Object, e As EventArgs) Handles cmdPrintOrder.Click

        If ugdOrders.ActiveRow Is Nothing Then
            If ugdOrders.Rows.Count = 1 Then
                ugdOrders.ActiveRow = ugdOrders.Rows(0)
            Else
                Alert("Select which order you want to print.", MessageBoxIcon.Information)
            End If
        Else
            intRowNumber = ugdOrders.ActiveRow.Index
        End If

        PrintOnlineOrder(ugdOrders.ActiveRow.Cells("OrderID").Text)

    End Sub

    Private Sub PrintOnlineOrder(onlineOrderId As String)

        'save order into Orders table
        Dim orderId As Short = Short.Parse(onlineOrderId)
        Dim order As OLOrderModel = onlineServiceManager.GetOrder(orderId)

        If order IsNot Nothing Then
            Dim orderItems As List(Of OLOrderDetailsModel) = onlineServiceManager.GetOrderItems(orderId)
            'save order into Orders table
            Dim newOrderId As Short = orderRepo.SaveOnlineOrder(order, orderItems)

            'print order
            PrintOrder(newOrderId, PrintDestinationEnum.Both)
        End If

    End Sub

    Private Sub cmdStartTimer_Click(sender As Object, e As EventArgs) Handles cmdStartTimer.Click

        StartCheckByTimer()

    End Sub

    Private Sub StartCheckByTimer()

        If cmdStartTimer.Text = $"Start Online Checks" Then
            GetOrdersByDate("2025-02-13")
            lblLastUpdate.Text = $"Last check:  {Format(Now, "H:mm:ss")}"
            lblNextUpdate.Text = $"Next check:  {Format(Now.AddMilliseconds(tmrCheckOnline.Interval), "H:mm:ss")}"
            cmdStartTimer.Text = $"Stop Online Checks"
            tmrCheckOnline.Enabled = True
        Else
            tmrCheckOnline.Enabled = False
            cmdStartTimer.Text = $"Start Online Checks"
            lblNextUpdate.Text = $"Next check:  <disabled>"
        End If

    End Sub

    Private Sub tmrCheckOnline_Tick(sender As Object, e As EventArgs) Handles tmrCheckOnline.Tick

        'get all orders for today
        GetOrdersByDate("2025-02-13")

        Application.DoEvents()

    End Sub

    <DebuggerStepThrough()>
    Private Sub tmrTimeNow_Tick(sender As Object, e As EventArgs) Handles tmrTimeNow.Tick
        lblClock.Text = $"Time now:  " & Format(Now, "H:mm:ss")
        lblClock.Refresh()
        'Application.DoEvents()
    End Sub

    Private Sub OGUpDownClick(sender As Object, e As EventArgs) Handles cmdUp.Click, cmdDown.Click

        DisablePrintButton()

        If ugdOrders.Rows.Count > 0 Then
            If sender.name = "cmdUp" Then
                If ugdOrders.ActiveRow Is Nothing Then
                    ugdOrders.ActiveRow = ugdOrders.Rows(ugdOrders.Rows.Count - 1)
                ElseIf ugdOrders.ActiveRow.Index > 0 Then
                    ugdOrders.ActiveRow = ugdOrders.Rows(ugdOrders.ActiveRow.Index - 1)
                Else
                    ugdOrders.ActiveRow = ugdOrders.Rows(ugdOrders.Rows.Count - 1)
                End If

            Else
                If ugdOrders.ActiveRow Is Nothing Then
                    ugdOrders.ActiveRow = ugdOrders.Rows(0)
                ElseIf ugdOrders.ActiveRow.Index < ugdOrders.Rows.Count - 1 Then
                    ugdOrders.ActiveRow = ugdOrders.Rows(ugdOrders.ActiveRow.Index + 1)
                Else
                    ugdOrders.ActiveRow = ugdOrders.Rows(0)
                End If

            End If

            intRowNumber = ugdOrders.ActiveRow.Index

            ugdOrderItems.DataSource = Nothing

            GetOrderDetails(ugdOrders.ActiveRow.Cells("OrderID").Text)

        End If

    End Sub

    Private Function GetFromOLOrdersTable(strColumnName As String) As String

        Return ugdOrders.Rows(intRowNumber).Cells(strColumnName).Text

    End Function

    Private Sub cmdClearGrids_Click(sender As Object, e As EventArgs) Handles cmdClearGrids.Click

        Dim bookings = onlineServiceManager.GetBookings()
        Dim a = bookings.Where(Function(b)
                                   Dim parsedDate As DateTime
                                   If DateTime.TryParse(b.Date, parsedDate) Then
                                       Return parsedDate >= DateTime.Today.AddDays(-10)
                                   Else
                                       ' Handle invalid date format, e.g., log an error or skip the entry
                                       Return False
                                   End If
                               End Function).ToList()

        'ugdOrderItems.DataSource = Nothing
        'ugdOrders.DataSource = Nothing
        'DisablePrintButton()

    End Sub

    Private Sub cmbTimeInterval_ValueChanged(sender As Object, e As EventArgs) Handles cmbTimeInterval.ValueChanged

        SaveAppSetting("OLUpdateInterval", cmbTimeInterval.SelectedIndex)
        intCheckInterval = cmbTimeInterval.Text
        tmrCheckOnline.Interval = intCheckInterval * 60 * 1000

    End Sub

    Public Function GetIpV4() As String

        Try
            Dim ipEntry As IPHostEntry = Dns.GetHostEntry(Dns.GetHostName())
            Dim ipv4Address As String = ipEntry.AddressList.
                    FirstOrDefault(Function(ip) ip.AddressFamily = Sockets.AddressFamily.InterNetwork)?.
                    ToString()

            If String.IsNullOrEmpty(ipv4Address) Then
                Return Nothing
            End If

            Return ipv4Address

        Catch ex As Exception
            DisplayError(ex)
            Return Nothing
        End Try

    End Function

    Private Sub DisablePrintButton()

        cmdPrintOrder.Enabled = False

    End Sub

    Private Sub HideSomeColumns(intID)

        Try
            If intID = 1 Then
                'orders grid

                With ugdOrders.DisplayLayout.Bands(0)
                    .Columns("ORDERS_ID").Hidden = True
                    .Columns("IP_ADDRESS").Hidden = True
                    .Columns("CUSTOMERS_ID").Hidden = True
                    .Columns("CUSTOMERS_COMPANY").Hidden = True
                    .Columns("CUSTOMERS_STATE").Hidden = True
                    .Columns("CUSTOMERS_COUNTRY").Hidden = True
                    .Columns("CUSTOMERS_ADDRESS_FORMAT_ID").Hidden = True
                    .Columns("DELIVERY_NAME").Hidden = True
                    .Columns("DELIVERY_COMPANY").Hidden = True
                    .Columns("DELIVERY_STREET_ADDRESS").Hidden = True
                    .Columns("DELIVERY_SUBURB").Hidden = True
                    .Columns("DELIVERY_CITY").Hidden = True
                    .Columns("DELIVERY_POSTCODE").Hidden = True
                    .Columns("DELIVERY_STATE").Hidden = True
                    .Columns("DELIVERY_COUNTRY").Hidden = True
                    .Columns("DELIVERY_ADDRESS_FORMAT_ID").Hidden = True
                    .Columns("BILLING_NAME").Hidden = True
                    .Columns("BILLING_COMPANY").Hidden = True
                    .Columns("BILLING_STREET_ADDRESS").Hidden = True
                    .Columns("BILLING_SUBURB").Hidden = True
                    .Columns("BILLING_CITY").Hidden = True
                    .Columns("BILLING_POSTCODE").Hidden = True
                    .Columns("BILLING_STATE").Hidden = True
                    .Columns("BILLING_COUNTRY").Hidden = True
                    .Columns("BILLING_ADDRESS_FORMAT_ID").Hidden = True
                    .Columns("PAYMENT_MODULE_CODE").Hidden = True
                    .Columns("SHIPPING_MODULE_CODE").Hidden = True
                    .Columns("COUPON_CODE").Hidden = True
                    .Columns("CC_TYPE").Hidden = True
                    .Columns("CC_OWNER").Hidden = True
                    .Columns("CC_NUMBER").Hidden = True
                    .Columns("CC_EXPIRES").Hidden = True
                    .Columns("CC_CVV").Hidden = True
                    .Columns("LAST_MODIFIED").Hidden = True
                    .Columns("ORDERS_STATUS").Hidden = True
                    .Columns("ORDERS_DATE_FINISHED").Hidden = True
                    .Columns("CURRENCY").Hidden = True
                    .Columns("CURRENCY_VALUE").Hidden = True
                    .Columns("ORDER_TAX").Hidden = True
                    .Columns("PAYPAL_IPN_ID").Hidden = True
                    .Columns("SHIPPING_TELEPHONE").Hidden = True
                    .Columns("DROPDOWN").Hidden = True
                    .Columns("GIFT_MESSAGE").Hidden = True
                    .Columns("CHECKBOX").Hidden = True
                    .Columns("COWOA_ORDER").Hidden = True
                    .Columns("SARWAT").Hidden = True

                    .Columns("ORDERS_ID").Header.Caption = "Order ID"
                    .Columns("CUSTOMERS_ID").Header.Caption = "Cust ID"
                    .Columns("COMMENTS").Header.Caption = "Comments"
                    .Columns("ORDER_TIME").Header.Caption = "Due Time"
                    .Columns("ORDER_METHOD").Header.Caption = "Method"
                    .Columns("CUSTOMERS_NAME").Header.Caption = "Name"
                    .Columns("CUSTOMERS_STREET_ADDRESS").Header.Caption = "Address1"
                    .Columns("CUSTOMERS_SUBURB").Header.Caption = "Address2"
                    .Columns("CUSTOMERS_CITY").Header.Caption = "Address3"
                    .Columns("CUSTOMERS_POSTCODE").Header.Caption = "Post code"
                    .Columns("CUSTOMERS_TELEPHONE").Header.Caption = "Telephone"
                    .Columns("CUSTOMERS_EMAIL_ADDRESS").Header.Caption = "e-mail"
                    .Columns("PAYMENT_METHOD").Header.Caption = "Payment"
                    .Columns("SHIPPING_METHOD").Hidden = True
                    .Columns("DATE_PURCHASED").Header.Caption = "Date & Time"
                    .Columns("ORDER_TOTAL").Header.Caption = "Order Total"
                    '.Columns("IP_ADDRESS").Header.Caption = "IP Address"
                    '.Columns("IP_ADDRESS").PerformAutoResize()
                End With

                AutoSizeColumns(ugdOrders)

            ElseIf intID = 2 Then
                'order details grid

                With ugdOrderItems.DisplayLayout.Bands(0)
                    .Columns("ORDERS_PRODUCTS_ID").Hidden = True
                    .Columns("ORDERS_ID").Hidden = True
                    .Columns("PRODUCTS_MODEL").Hidden = True
                    .Columns("PRODUCTS_TAX").Hidden = True
                    .Columns("ONETIME_CHARGES").Hidden = True
                    .Columns("PRODUCTS_PRICED_BY_ATTRIBUTE").Hidden = True
                    .Columns("PRODUCT_IS_FREE").Hidden = True
                    .Columns("PRODUCTS_DISCOUNT_TYPE").Hidden = True
                    .Columns("PRODUCTS_DISCOUNT_TYPE_FROM").Hidden = True
                    .Columns("PRODUCTS_PRID").Hidden = True
                    .Columns("FINAL_PRICE").Hidden = True
                    .Columns("PRODUCTS_ID").Header.Caption = "ID"
                    .Columns("PRODUCTS_NAME").Header.Caption = "Name"
                    .Columns("PRODUCTS_PRICE").Header.Caption = "Price"
                    .Columns("FINAL_PRICE").Header.Caption = "Total"
                    .Columns("PRODUCTS_QUANTITY").Header.Caption = "Qty"
                    .Columns("PRODUCTS_QUANTITY").Header.VisiblePosition = 5
                    .Columns("PRODUCTS_QUANTITY").CellAppearance.TextHAlign = Infragistics.Win.HAlign.Center
                    .Columns("PRODUCTS_PRICE").CellAppearance.TextHAlign = Infragistics.Win.HAlign.Right
                End With

                AutoSizeColumns(ugdOrderItems)

            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub AutoSizeColumns(ugdGridName As Infragistics.Win.UltraWinGrid.UltraGrid)

        For Each x In ugdGridName.DisplayLayout.Bands(0).Columns
            x.PerformAutoResize(Infragistics.Win.UltraWinGrid.PerformAutoSizeType.AllRowsInBand)
        Next

    End Sub

    Private Sub chkAutoPrint_CheckStateChanged(sender As Object, e As EventArgs) Handles chkAutoPrint.CheckStateChanged
        SaveAppSetting("OLAutoPrint", Val(chkAutoPrint.CheckState))
    End Sub

    Private Sub cmdSendToBack_Click(sender As Object, e As EventArgs) Handles cmdSendToBack.Click
        SendToBack()
    End Sub

    Private Sub DisplayStatus(strTextToShow As String)

        lblStatusBar.Text = strTextToShow
        lblStatusBar.Visible = (strTextToShow.Length > 0)

        Application.DoEvents()

    End Sub

    Private Sub cmdHide_Click(sender As Object, e As EventArgs) Handles cmdHide.Click
        Hide()
    End Sub

End Class