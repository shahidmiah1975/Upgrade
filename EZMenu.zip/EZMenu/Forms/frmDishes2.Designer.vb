﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDishes2

    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim Appearance1 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance2 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance3 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance4 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmDishes2))
        Dim Appearance5 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance6 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance7 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance8 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance9 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance10 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance11 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance12 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance13 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance14 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance15 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance16 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance17 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance18 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance19 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance20 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance21 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance22 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance23 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance24 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance25 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance26 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraGridBand1 As Infragistics.Win.UltraWinGrid.UltraGridBand = New Infragistics.Win.UltraWinGrid.UltraGridBand("Dish", -1)
        Dim UltraGridColumn10 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("UniqueID")
        Dim UltraGridColumn11 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Code", -1, Nothing, 0, Infragistics.Win.UltraWinGrid.SortIndicator.Ascending, False)
        Dim UltraGridColumn12 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("DishName")
        Dim UltraGridColumn13 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("PriceIn")
        Dim UltraGridColumn14 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("PriceOut")
        Dim UltraGridColumn15 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("DoButton")
        Dim UltraGridColumn16 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("GroupName")
        Dim UltraGridColumn17 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Discountable")
        Dim UltraGridColumn18 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("PrintLabel")
        Dim Appearance27 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance28 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance29 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance30 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance31 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance32 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance33 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance34 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance35 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance36 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance37 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance38 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance39 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance40 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance41 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance42 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance43 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Me.pnlHeader = New Infragistics.Win.Misc.UltraPanel()
        Me.lblHeader = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel1 = New Infragistics.Win.Misc.UltraLabel()
        Me.cmdBack = New Infragistics.Win.Misc.UltraButton()
        Me.ugbOptions = New Infragistics.Win.Misc.UltraGroupBox()
        Me.txtPriceSmall = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtPriceLarge = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtShortName = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtShortcode = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtSearchString = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.lstShortcode = New Infragistics.Win.UltraWinListView.UltraListView()
        Me.UltraLabel3 = New Infragistics.Win.Misc.UltraLabel()
        Me.cmdSearch = New Infragistics.Win.Misc.UltraButton()
        Me.cmdPriceDelete = New Infragistics.Win.Misc.UltraButton()
        Me.lblShortName = New Infragistics.Win.Misc.UltraLabel()
        Me.cmdPriceSave = New Infragistics.Win.Misc.UltraButton()
        Me.UltraLabel2 = New Infragistics.Win.Misc.UltraLabel()
        Me.lblShortCode = New Infragistics.Win.Misc.UltraLabel()
        Me.cmdSaveShortName = New Infragistics.Win.Misc.UltraButton()
        Me.UltraLabel4 = New Infragistics.Win.Misc.UltraLabel()
        Me.cmdShortcodeAdd = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDeleteShortName = New Infragistics.Win.Misc.UltraButton()
        Me.cmdShortcodeDelete = New Infragistics.Win.Misc.UltraButton()
        Me.cmdConcise = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDishCascade = New Infragistics.Win.Misc.UltraButton()
        Me.cmdLabels = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDishesHistory = New Infragistics.Win.Misc.UltraButton()
        Me.cmdShowSubgroup = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDeleteDish = New Infragistics.Win.Misc.UltraButton()
        Me.cmdAddDish = New Infragistics.Win.Misc.UltraButton()
        Me.ugdDishes = New Infragistics.Win.UltraWinGrid.UltraGrid()
        Me.DishBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.EzMenuDataSet = New EZMenu.EZMenuDataSet()
        Me.DishTableAdapter = New EZMenu.EZMenuDataSetTableAdapters.DishTableAdapter()
        Me.TableAdapterManager = New EZMenu.EZMenuDataSetTableAdapters.TableAdapterManager()
        Me.cmbCuisine = New Infragistics.Win.UltraWinEditors.UltraComboEditor()
        Me.lblCuisine = New Infragistics.Win.Misc.UltraLabel()
        Me.lblNumDishes = New Infragistics.Win.Misc.UltraLabel()
        Me.pnlHeader.ClientArea.SuspendLayout()
        Me.pnlHeader.SuspendLayout()
        CType(Me.ugbOptions, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ugbOptions.SuspendLayout()
        CType(Me.txtPriceSmall, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtPriceLarge, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtShortName, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtShortcode, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtSearchString, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lstShortcode, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ugdDishes, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DishBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EzMenuDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbCuisine, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pnlHeader
        '
        Me.pnlHeader.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance1.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.pnlHeader.Appearance = Appearance1
        '
        'pnlHeader.ClientArea
        '
        Me.pnlHeader.ClientArea.Controls.Add(Me.lblHeader)
        Me.pnlHeader.Location = New System.Drawing.Point(0, 0)
        Me.pnlHeader.Name = "pnlHeader"
        Me.pnlHeader.Size = New System.Drawing.Size(1268, 42)
        Me.pnlHeader.StyleSetName = "Reservation"
        Me.pnlHeader.TabIndex = 548
        Me.pnlHeader.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblHeader
        '
        Appearance2.BackColor = System.Drawing.Color.Transparent
        Appearance2.ForeColor = System.Drawing.Color.Maroon
        Appearance2.TextVAlignAsString = "Middle"
        Me.lblHeader.Appearance = Appearance2
        Me.lblHeader.Font = New System.Drawing.Font("Calibri", 18.0!)
        Me.lblHeader.Location = New System.Drawing.Point(12, 3)
        Me.lblHeader.Name = "lblHeader"
        Me.lblHeader.Size = New System.Drawing.Size(503, 35)
        Me.lblHeader.StyleSetName = "Reservation"
        Me.lblHeader.TabIndex = 460
        Me.lblHeader.Text = "Dish Management Screen"
        Me.lblHeader.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraLabel1
        '
        Me.UltraLabel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance3.BorderColor = System.Drawing.Color.Silver
        Me.UltraLabel1.Appearance = Appearance3
        Me.UltraLabel1.BorderStyleInner = Infragistics.Win.UIElementBorderStyle.Solid
        Me.UltraLabel1.Location = New System.Drawing.Point(-1, 758)
        Me.UltraLabel1.Name = "UltraLabel1"
        Me.UltraLabel1.Size = New System.Drawing.Size(1269, 1)
        Me.UltraLabel1.TabIndex = 549
        '
        'cmdBack
        '
        Me.cmdBack.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Appearance4.BackColor = System.Drawing.Color.Transparent
        Appearance4.BackColor2 = System.Drawing.Color.Transparent
        Appearance4.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance4.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance4.BorderColor = System.Drawing.Color.Transparent
        Appearance4.BorderColor2 = System.Drawing.Color.Maroon
        Appearance4.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance4.ForeColor = System.Drawing.Color.White
        Appearance4.Image = CType(resources.GetObject("Appearance4.Image"), Object)
        Appearance4.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance4.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance4.TextVAlignAsString = "Bottom"
        Me.cmdBack.Appearance = Appearance4
        Me.cmdBack.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance5.BackColor = System.Drawing.Color.DarkOrange
        Appearance5.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance5.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance5.BorderColor = System.Drawing.Color.Transparent
        Appearance5.ForeColor = System.Drawing.Color.Black
        Me.cmdBack.HotTrackAppearance = Appearance5
        Me.cmdBack.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdBack.Location = New System.Drawing.Point(598, 769)
        Me.cmdBack.Name = "cmdBack"
        Appearance6.BackColor = System.Drawing.Color.OrangeRed
        Appearance6.BackColor2 = System.Drawing.Color.Tomato
        Appearance6.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance6.BorderColor = System.Drawing.Color.Transparent
        Me.cmdBack.PressedAppearance = Appearance6
        Me.cmdBack.ShowFocusRect = False
        Me.cmdBack.ShowOutline = False
        Me.cmdBack.Size = New System.Drawing.Size(70, 39)
        Me.cmdBack.StyleSetName = "StatusBar"
        Me.cmdBack.TabIndex = 569
        Me.cmdBack.Tag = "Return"
        Me.cmdBack.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdBack.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdBack.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ugbOptions
        '
        Me.ugbOptions.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance7.BackColor = System.Drawing.Color.Transparent
        Appearance7.BorderColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.ugbOptions.Appearance = Appearance7
        Me.ugbOptions.BorderStyle = Infragistics.Win.Misc.GroupBoxBorderStyle.Rectangular3D
        Me.ugbOptions.Controls.Add(Me.txtPriceSmall)
        Me.ugbOptions.Controls.Add(Me.txtPriceLarge)
        Me.ugbOptions.Controls.Add(Me.txtShortName)
        Me.ugbOptions.Controls.Add(Me.txtShortcode)
        Me.ugbOptions.Controls.Add(Me.txtSearchString)
        Me.ugbOptions.Controls.Add(Me.lstShortcode)
        Me.ugbOptions.Controls.Add(Me.UltraLabel3)
        Me.ugbOptions.Controls.Add(Me.cmdSearch)
        Me.ugbOptions.Controls.Add(Me.cmdPriceDelete)
        Me.ugbOptions.Controls.Add(Me.lblShortName)
        Me.ugbOptions.Controls.Add(Me.cmdPriceSave)
        Me.ugbOptions.Controls.Add(Me.UltraLabel2)
        Me.ugbOptions.Controls.Add(Me.lblShortCode)
        Me.ugbOptions.Controls.Add(Me.cmdSaveShortName)
        Me.ugbOptions.Controls.Add(Me.UltraLabel4)
        Me.ugbOptions.Controls.Add(Me.cmdShortcodeAdd)
        Me.ugbOptions.Controls.Add(Me.cmdDeleteShortName)
        Me.ugbOptions.Controls.Add(Me.cmdShortcodeDelete)
        Me.ugbOptions.Location = New System.Drawing.Point(959, 114)
        Me.ugbOptions.Name = "ugbOptions"
        Me.ugbOptions.Size = New System.Drawing.Size(281, 443)
        Me.ugbOptions.TabIndex = 568
        '
        'txtPriceSmall
        '
        Appearance8.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance8.BorderColor = System.Drawing.Color.LightGray
        Appearance8.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Me.txtPriceSmall.Appearance = Appearance8
        Me.txtPriceSmall.AutoSize = False
        Me.txtPriceSmall.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtPriceSmall.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtPriceSmall.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPriceSmall.Location = New System.Drawing.Point(101, 397)
        Me.txtPriceSmall.MaxLength = 5
        Me.txtPriceSmall.Name = "txtPriceSmall"
        Me.txtPriceSmall.Size = New System.Drawing.Size(79, 28)
        Me.txtPriceSmall.StyleSetName = "TextEntry"
        Me.txtPriceSmall.TabIndex = 680
        Me.txtPriceSmall.UseAppStyling = False
        Me.txtPriceSmall.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtPriceSmall.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtPriceLarge
        '
        Appearance9.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance9.BorderColor = System.Drawing.Color.LightGray
        Appearance9.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Me.txtPriceLarge.Appearance = Appearance9
        Me.txtPriceLarge.AutoSize = False
        Me.txtPriceLarge.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtPriceLarge.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtPriceLarge.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPriceLarge.Location = New System.Drawing.Point(101, 363)
        Me.txtPriceLarge.MaxLength = 5
        Me.txtPriceLarge.Name = "txtPriceLarge"
        Me.txtPriceLarge.Size = New System.Drawing.Size(79, 28)
        Me.txtPriceLarge.StyleSetName = "TextEntry"
        Me.txtPriceLarge.TabIndex = 679
        Me.txtPriceLarge.UseAppStyling = False
        Me.txtPriceLarge.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtPriceLarge.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtShortName
        '
        Appearance10.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance10.BorderColor = System.Drawing.Color.LightGray
        Appearance10.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Me.txtShortName.Appearance = Appearance10
        Me.txtShortName.AutoSize = False
        Me.txtShortName.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtShortName.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtShortName.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtShortName.Location = New System.Drawing.Point(34, 278)
        Me.txtShortName.MaxLength = 0
        Me.txtShortName.Name = "txtShortName"
        Me.txtShortName.Size = New System.Drawing.Size(212, 28)
        Me.txtShortName.StyleSetName = "TextEntry"
        Me.txtShortName.TabIndex = 678
        Me.txtShortName.UseAppStyling = False
        Me.txtShortName.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtShortName.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtShortcode
        '
        Appearance11.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance11.BorderColor = System.Drawing.Color.LightGray
        Appearance11.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Me.txtShortcode.Appearance = Appearance11
        Me.txtShortcode.AutoSize = False
        Me.txtShortcode.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtShortcode.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtShortcode.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtShortcode.Location = New System.Drawing.Point(40, 118)
        Me.txtShortcode.MaxLength = 5
        Me.txtShortcode.Name = "txtShortcode"
        Me.txtShortcode.Size = New System.Drawing.Size(120, 28)
        Me.txtShortcode.StyleSetName = "TextEntry"
        Me.txtShortcode.TabIndex = 677
        Me.txtShortcode.UseAppStyling = False
        Me.txtShortcode.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtShortcode.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtSearchString
        '
        Appearance12.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance12.BorderColor = System.Drawing.Color.LightGray
        Appearance12.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Me.txtSearchString.Appearance = Appearance12
        Me.txtSearchString.AutoSize = False
        Me.txtSearchString.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtSearchString.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtSearchString.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSearchString.Location = New System.Drawing.Point(40, 40)
        Me.txtSearchString.MaxLength = 0
        Me.txtSearchString.Name = "txtSearchString"
        Me.txtSearchString.Size = New System.Drawing.Size(120, 28)
        Me.txtSearchString.StyleSetName = "TextEntry"
        Me.txtSearchString.TabIndex = 676
        Me.txtSearchString.UseAppStyling = False
        Me.txtSearchString.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtSearchString.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lstShortcode
        '
        Appearance13.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance13.BorderColor = System.Drawing.Color.LightGray
        Me.lstShortcode.Appearance = Appearance13
        Me.lstShortcode.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.lstShortcode.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstShortcode.ItemSettings.AllowEdit = Infragistics.Win.DefaultableBoolean.[False]
        Me.lstShortcode.ItemSettings.HideSelection = False
        Me.lstShortcode.Location = New System.Drawing.Point(40, 151)
        Me.lstShortcode.Name = "lstShortcode"
        Me.lstShortcode.ShowGroups = False
        Me.lstShortcode.Size = New System.Drawing.Size(120, 86)
        Me.lstShortcode.TabIndex = 675
        Me.lstShortcode.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.lstShortcode.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        Me.lstShortcode.View = Infragistics.Win.UltraWinListView.UltraListViewStyle.List
        Me.lstShortcode.ViewSettingsList.ImageSize = New System.Drawing.Size(0, 0)
        Me.lstShortcode.ViewSettingsList.MultiColumn = False
        '
        'UltraLabel3
        '
        Appearance14.BackColor = System.Drawing.Color.Transparent
        Appearance14.ForeColor = System.Drawing.Color.DimGray
        Appearance14.TextHAlignAsString = "Center"
        Me.UltraLabel3.Appearance = Appearance14
        Me.UltraLabel3.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UltraLabel3.Location = New System.Drawing.Point(40, 17)
        Me.UltraLabel3.Name = "UltraLabel3"
        Me.UltraLabel3.Size = New System.Drawing.Size(201, 22)
        Me.UltraLabel3.TabIndex = 556
        Me.UltraLabel3.Text = "Search for a dish:"
        Me.UltraLabel3.UseAppStyling = False
        '
        'cmdSearch
        '
        Me.cmdSearch.Font = New System.Drawing.Font("Arial", 10.0!)
        Me.cmdSearch.Location = New System.Drawing.Point(166, 41)
        Me.cmdSearch.Name = "cmdSearch"
        Me.cmdSearch.ShowFocusRect = False
        Me.cmdSearch.ShowOutline = False
        Me.cmdSearch.Size = New System.Drawing.Size(75, 26)
        Me.cmdSearch.StyleSetName = "TextButton"
        Me.cmdSearch.TabIndex = 554
        Me.cmdSearch.Text = "Search"
        Me.cmdSearch.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        '
        'cmdPriceDelete
        '
        Me.cmdPriceDelete.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdPriceDelete.Location = New System.Drawing.Point(186, 396)
        Me.cmdPriceDelete.Name = "cmdPriceDelete"
        Me.cmdPriceDelete.ShowFocusRect = False
        Me.cmdPriceDelete.ShowOutline = False
        Me.cmdPriceDelete.Size = New System.Drawing.Size(75, 26)
        Me.cmdPriceDelete.StyleSetName = "TextButton"
        Me.cmdPriceDelete.TabIndex = 553
        Me.cmdPriceDelete.Text = "Delete"
        Me.cmdPriceDelete.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        '
        'lblShortName
        '
        Appearance15.BackColor = System.Drawing.Color.Transparent
        Appearance15.ForeColor = System.Drawing.Color.DimGray
        Appearance15.TextHAlignAsString = "Center"
        Appearance15.TextVAlignAsString = "Bottom"
        Me.lblShortName.Appearance = Appearance15
        Me.lblShortName.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblShortName.Location = New System.Drawing.Point(37, 234)
        Me.lblShortName.Name = "lblShortName"
        Me.lblShortName.Size = New System.Drawing.Size(209, 43)
        Me.lblShortName.TabIndex = 464
        Me.lblShortName.Text = "Short name"
        Me.lblShortName.UseAppStyling = False
        '
        'cmdPriceSave
        '
        Me.cmdPriceSave.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdPriceSave.Location = New System.Drawing.Point(186, 366)
        Me.cmdPriceSave.Name = "cmdPriceSave"
        Me.cmdPriceSave.ShowFocusRect = False
        Me.cmdPriceSave.ShowOutline = False
        Me.cmdPriceSave.Size = New System.Drawing.Size(75, 26)
        Me.cmdPriceSave.StyleSetName = "TextButton"
        Me.cmdPriceSave.TabIndex = 552
        Me.cmdPriceSave.Text = "Save"
        Me.cmdPriceSave.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        '
        'UltraLabel2
        '
        Appearance16.BackColor = System.Drawing.Color.Transparent
        Appearance16.ForeColor = System.Drawing.Color.DimGray
        Appearance16.TextHAlignAsString = "Center"
        Appearance16.TextVAlignAsString = "Bottom"
        Me.UltraLabel2.Appearance = Appearance16
        Me.UltraLabel2.AutoSize = True
        Me.UltraLabel2.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UltraLabel2.Location = New System.Drawing.Point(19, 404)
        Me.UltraLabel2.Name = "UltraLabel2"
        Me.UltraLabel2.Size = New System.Drawing.Size(75, 17)
        Me.UltraLabel2.TabIndex = 550
        Me.UltraLabel2.Text = "Small price:"
        Me.UltraLabel2.UseAppStyling = False
        '
        'lblShortCode
        '
        Appearance17.BackColor = System.Drawing.Color.Transparent
        Appearance17.ForeColor = System.Drawing.Color.DimGray
        Appearance17.TextHAlignAsString = "Center"
        Appearance17.TextVAlignAsString = "Bottom"
        Me.lblShortCode.Appearance = Appearance17
        Me.lblShortCode.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblShortCode.Location = New System.Drawing.Point(40, 82)
        Me.lblShortCode.Name = "lblShortCode"
        Me.lblShortCode.Size = New System.Drawing.Size(200, 32)
        Me.lblShortCode.TabIndex = 459
        Me.lblShortCode.Text = "Codes for the item"
        Me.lblShortCode.UseAppStyling = False
        '
        'cmdSaveShortName
        '
        Me.cmdSaveShortName.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdSaveShortName.Location = New System.Drawing.Point(65, 312)
        Me.cmdSaveShortName.Name = "cmdSaveShortName"
        Me.cmdSaveShortName.ShowFocusRect = False
        Me.cmdSaveShortName.ShowOutline = False
        Me.cmdSaveShortName.Size = New System.Drawing.Size(75, 26)
        Me.cmdSaveShortName.StyleSetName = "TextButton"
        Me.cmdSaveShortName.TabIndex = 519
        Me.cmdSaveShortName.Text = "Save"
        Me.cmdSaveShortName.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        '
        'UltraLabel4
        '
        Appearance18.BackColor = System.Drawing.Color.Transparent
        Appearance18.ForeColor = System.Drawing.Color.DimGray
        Appearance18.TextHAlignAsString = "Center"
        Appearance18.TextVAlignAsString = "Bottom"
        Me.UltraLabel4.Appearance = Appearance18
        Me.UltraLabel4.AutoSize = True
        Me.UltraLabel4.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UltraLabel4.Location = New System.Drawing.Point(19, 370)
        Me.UltraLabel4.Name = "UltraLabel4"
        Me.UltraLabel4.Size = New System.Drawing.Size(76, 17)
        Me.UltraLabel4.TabIndex = 548
        Me.UltraLabel4.Text = "Large price:"
        Me.UltraLabel4.UseAppStyling = False
        '
        'cmdShortcodeAdd
        '
        Me.cmdShortcodeAdd.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdShortcodeAdd.Location = New System.Drawing.Point(166, 118)
        Me.cmdShortcodeAdd.Name = "cmdShortcodeAdd"
        Me.cmdShortcodeAdd.ShowFocusRect = False
        Me.cmdShortcodeAdd.ShowOutline = False
        Me.cmdShortcodeAdd.Size = New System.Drawing.Size(75, 26)
        Me.cmdShortcodeAdd.StyleSetName = "TextButton"
        Me.cmdShortcodeAdd.TabIndex = 520
        Me.cmdShortcodeAdd.Text = "Add"
        Me.cmdShortcodeAdd.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        '
        'cmdDeleteShortName
        '
        Me.cmdDeleteShortName.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdDeleteShortName.Location = New System.Drawing.Point(146, 312)
        Me.cmdDeleteShortName.Name = "cmdDeleteShortName"
        Me.cmdDeleteShortName.ShowFocusRect = False
        Me.cmdDeleteShortName.ShowOutline = False
        Me.cmdDeleteShortName.Size = New System.Drawing.Size(75, 26)
        Me.cmdDeleteShortName.StyleSetName = "TextButton"
        Me.cmdDeleteShortName.TabIndex = 547
        Me.cmdDeleteShortName.Text = "Delete"
        Me.cmdDeleteShortName.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        '
        'cmdShortcodeDelete
        '
        Me.cmdShortcodeDelete.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdShortcodeDelete.Location = New System.Drawing.Point(166, 146)
        Me.cmdShortcodeDelete.Name = "cmdShortcodeDelete"
        Me.cmdShortcodeDelete.ShowFocusRect = False
        Me.cmdShortcodeDelete.ShowOutline = False
        Me.cmdShortcodeDelete.Size = New System.Drawing.Size(75, 26)
        Me.cmdShortcodeDelete.StyleSetName = "TextButton"
        Me.cmdShortcodeDelete.TabIndex = 521
        Me.cmdShortcodeDelete.Text = "Delete"
        Me.cmdShortcodeDelete.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        '
        'cmdConcise
        '
        Me.cmdConcise.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance19.BackColor = System.Drawing.Color.Transparent
        Me.cmdConcise.Appearance = Appearance19
        Me.cmdConcise.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdConcise.Location = New System.Drawing.Point(1104, 662)
        Me.cmdConcise.Name = "cmdConcise"
        Me.cmdConcise.ShowFocusRect = False
        Me.cmdConcise.ShowOutline = False
        Me.cmdConcise.Size = New System.Drawing.Size(105, 35)
        Me.cmdConcise.StyleSetName = "TextButton"
        Me.cmdConcise.TabIndex = 567
        Me.cmdConcise.Text = "Merge"
        Me.cmdConcise.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        '
        'cmdDishCascade
        '
        Me.cmdDishCascade.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance20.BackColor = System.Drawing.Color.Transparent
        Me.cmdDishCascade.Appearance = Appearance20
        Me.cmdDishCascade.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdDishCascade.Location = New System.Drawing.Point(993, 662)
        Me.cmdDishCascade.Name = "cmdDishCascade"
        Me.cmdDishCascade.ShowFocusRect = False
        Me.cmdDishCascade.ShowOutline = False
        Me.cmdDishCascade.Size = New System.Drawing.Size(105, 35)
        Me.cmdDishCascade.StyleSetName = "TextButton"
        Me.cmdDishCascade.TabIndex = 566
        Me.cmdDishCascade.Text = "Cascade"
        Me.cmdDishCascade.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        '
        'cmdLabels
        '
        Me.cmdLabels.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance21.BackColor = System.Drawing.Color.Transparent
        Me.cmdLabels.Appearance = Appearance21
        Me.cmdLabels.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdLabels.Location = New System.Drawing.Point(993, 703)
        Me.cmdLabels.Name = "cmdLabels"
        Me.cmdLabels.ShowFocusRect = False
        Me.cmdLabels.ShowOutline = False
        Me.cmdLabels.Size = New System.Drawing.Size(105, 35)
        Me.cmdLabels.StyleSetName = "TextButton"
        Me.cmdLabels.TabIndex = 563
        Me.cmdLabels.Text = "Labels"
        Me.cmdLabels.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        '
        'cmdDishesHistory
        '
        Me.cmdDishesHistory.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance22.BackColor = System.Drawing.Color.Transparent
        Me.cmdDishesHistory.Appearance = Appearance22
        Me.cmdDishesHistory.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdDishesHistory.Location = New System.Drawing.Point(993, 621)
        Me.cmdDishesHistory.Name = "cmdDishesHistory"
        Me.cmdDishesHistory.ShowFocusRect = False
        Me.cmdDishesHistory.ShowOutline = False
        Me.cmdDishesHistory.Size = New System.Drawing.Size(105, 35)
        Me.cmdDishesHistory.StyleSetName = "TextButton"
        Me.cmdDishesHistory.TabIndex = 562
        Me.cmdDishesHistory.Text = "History"
        Me.cmdDishesHistory.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        '
        'cmdShowSubgroup
        '
        Me.cmdShowSubgroup.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance23.BackColor = System.Drawing.Color.Transparent
        Me.cmdShowSubgroup.Appearance = Appearance23
        Me.cmdShowSubgroup.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdShowSubgroup.Location = New System.Drawing.Point(1104, 621)
        Me.cmdShowSubgroup.Name = "cmdShowSubgroup"
        Me.cmdShowSubgroup.ShowFocusRect = False
        Me.cmdShowSubgroup.ShowOutline = False
        Me.cmdShowSubgroup.Size = New System.Drawing.Size(105, 35)
        Me.cmdShowSubgroup.StyleSetName = "TextButton"
        Me.cmdShowSubgroup.TabIndex = 561
        Me.cmdShowSubgroup.Text = "Subgrouping"
        Me.cmdShowSubgroup.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        '
        'cmdDeleteDish
        '
        Me.cmdDeleteDish.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance24.BackColor = System.Drawing.Color.Transparent
        Me.cmdDeleteDish.Appearance = Appearance24
        Me.cmdDeleteDish.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdDeleteDish.Location = New System.Drawing.Point(1104, 580)
        Me.cmdDeleteDish.Name = "cmdDeleteDish"
        Me.cmdDeleteDish.ShowFocusRect = False
        Me.cmdDeleteDish.ShowOutline = False
        Me.cmdDeleteDish.Size = New System.Drawing.Size(105, 35)
        Me.cmdDeleteDish.StyleSetName = "TextButton"
        Me.cmdDeleteDish.TabIndex = 559
        Me.cmdDeleteDish.Text = "Delete dish"
        Me.cmdDeleteDish.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        '
        'cmdAddDish
        '
        Me.cmdAddDish.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance25.BackColor = System.Drawing.Color.Transparent
        Me.cmdAddDish.Appearance = Appearance25
        Me.cmdAddDish.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdAddDish.Location = New System.Drawing.Point(993, 580)
        Me.cmdAddDish.Name = "cmdAddDish"
        Me.cmdAddDish.ShowFocusRect = False
        Me.cmdAddDish.ShowOutline = False
        Me.cmdAddDish.Size = New System.Drawing.Size(105, 35)
        Me.cmdAddDish.StyleSetName = "TextButton"
        Me.cmdAddDish.TabIndex = 558
        Me.cmdAddDish.Text = "Add dish"
        Me.cmdAddDish.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        '
        'ugdDishes
        '
        Me.ugdDishes.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ugdDishes.DataSource = Me.DishBindingSource
        Appearance26.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance26.BackColor2 = System.Drawing.Color.White
        Appearance26.BackHatchStyle = Infragistics.Win.BackHatchStyle.LightHorizontal
        Appearance26.BorderColor = System.Drawing.Color.Silver
        Me.ugdDishes.DisplayLayout.Appearance = Appearance26
        UltraGridColumn10.Header.Editor = Nothing
        UltraGridColumn10.Header.VisiblePosition = 0
        UltraGridColumn10.Hidden = True
        UltraGridColumn11.Header.Editor = Nothing
        UltraGridColumn11.Header.VisiblePosition = 1
        UltraGridColumn11.Width = 53
        UltraGridColumn12.Header.Caption = "Name"
        UltraGridColumn12.Header.Editor = Nothing
        UltraGridColumn12.Header.VisiblePosition = 2
        UltraGridColumn12.Width = 141
        UltraGridColumn13.Format = "#0.00"
        UltraGridColumn13.Header.Caption = "Price In"
        UltraGridColumn13.Header.Editor = Nothing
        UltraGridColumn13.Header.VisiblePosition = 3
        UltraGridColumn13.Width = 72
        UltraGridColumn14.Format = "#0.00"
        UltraGridColumn14.Header.Caption = "Price Out"
        UltraGridColumn14.Header.Editor = Nothing
        UltraGridColumn14.Header.VisiblePosition = 4
        UltraGridColumn15.Header.Editor = Nothing
        UltraGridColumn15.Header.VisiblePosition = 6
        UltraGridColumn15.Hidden = True
        UltraGridColumn16.Header.Caption = "Group"
        UltraGridColumn16.Header.Editor = Nothing
        UltraGridColumn16.Header.VisiblePosition = 5
        UltraGridColumn16.Style = Infragistics.Win.UltraWinGrid.ColumnStyle.DropDownList
        UltraGridColumn16.Width = 118
        UltraGridColumn17.Header.Editor = Nothing
        UltraGridColumn17.Header.VisiblePosition = 7
        UltraGridColumn17.Width = 89
        UltraGridColumn18.Header.Caption = "Print Label"
        UltraGridColumn18.Header.Editor = Nothing
        UltraGridColumn18.Header.VisiblePosition = 8
        UltraGridBand1.Columns.AddRange(New Object() {UltraGridColumn10, UltraGridColumn11, UltraGridColumn12, UltraGridColumn13, UltraGridColumn14, UltraGridColumn15, UltraGridColumn16, UltraGridColumn17, UltraGridColumn18})
        Me.ugdDishes.DisplayLayout.BandsSerializer.Add(UltraGridBand1)
        Me.ugdDishes.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Appearance27.FontData.BoldAsString = "True"
        Appearance27.FontData.Name = "Arial"
        Appearance27.FontData.SizeInPoints = 11.0!
        Appearance27.FontData.StrikeoutAsString = "False"
        Appearance27.ForeColor = System.Drawing.Color.MidnightBlue
        Me.ugdDishes.DisplayLayout.CaptionAppearance = Appearance27
        Me.ugdDishes.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.[False]
        Appearance28.BackColor = System.Drawing.SystemColors.ActiveBorder
        Appearance28.BackColor2 = System.Drawing.SystemColors.ControlDark
        Appearance28.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance28.BorderColor = System.Drawing.SystemColors.Window
        Me.ugdDishes.DisplayLayout.GroupByBox.Appearance = Appearance28
        Appearance29.ForeColor = System.Drawing.SystemColors.GrayText
        Me.ugdDishes.DisplayLayout.GroupByBox.BandLabelAppearance = Appearance29
        Me.ugdDishes.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Me.ugdDishes.DisplayLayout.GroupByBox.Hidden = True
        Appearance30.BackColor = System.Drawing.SystemColors.ControlLightLight
        Appearance30.BackColor2 = System.Drawing.SystemColors.Control
        Appearance30.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal
        Appearance30.ForeColor = System.Drawing.SystemColors.GrayText
        Me.ugdDishes.DisplayLayout.GroupByBox.PromptAppearance = Appearance30
        Me.ugdDishes.DisplayLayout.MaxColScrollRegions = 1
        Me.ugdDishes.DisplayLayout.MaxRowScrollRegions = 1
        Appearance31.BackColor = System.Drawing.SystemColors.Window
        Appearance31.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ugdDishes.DisplayLayout.Override.ActiveCellAppearance = Appearance31
        Appearance32.BackColor = System.Drawing.Color.DarkOrange
        Appearance32.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance32.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ugdDishes.DisplayLayout.Override.ActiveRowAppearance = Appearance32
        Me.ugdDishes.DisplayLayout.Override.AllowColMoving = Infragistics.Win.UltraWinGrid.AllowColMoving.NotAllowed
        Me.ugdDishes.DisplayLayout.Override.AllowColSwapping = Infragistics.Win.UltraWinGrid.AllowColSwapping.NotAllowed
        Me.ugdDishes.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted
        Me.ugdDishes.DisplayLayout.Override.BorderStyleHeader = Infragistics.Win.UIElementBorderStyle.Etched
        Me.ugdDishes.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted
        Appearance33.BackColor = System.Drawing.Color.Transparent
        Me.ugdDishes.DisplayLayout.Override.CardAreaAppearance = Appearance33
        Appearance34.BackColor = System.Drawing.Color.LightYellow
        Appearance34.BackColor2 = System.Drawing.Color.PaleGoldenrod
        Appearance34.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Me.ugdDishes.DisplayLayout.Override.CellAppearance = Appearance34
        Me.ugdDishes.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.EditAndSelectText
        Me.ugdDishes.DisplayLayout.Override.CellPadding = 0
        Appearance35.BackColor = System.Drawing.SystemColors.Control
        Appearance35.BackColor2 = System.Drawing.SystemColors.ControlDark
        Appearance35.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element
        Appearance35.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal
        Appearance35.BorderColor = System.Drawing.SystemColors.Window
        Me.ugdDishes.DisplayLayout.Override.GroupByRowAppearance = Appearance35
        Appearance36.BackColor = System.Drawing.Color.CornflowerBlue
        Appearance36.BackColor2 = System.Drawing.Color.RoyalBlue
        Appearance36.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance36.FontData.BoldAsString = "True"
        Appearance36.FontData.SizeInPoints = 9.0!
        Appearance36.ForeColor = System.Drawing.Color.White
        Appearance36.ThemedElementAlpha = Infragistics.Win.Alpha.Transparent
        Me.ugdDishes.DisplayLayout.Override.HeaderAppearance = Appearance36
        Me.ugdDishes.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti
        Me.ugdDishes.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand
        Appearance37.BackColor = System.Drawing.SystemColors.Window
        Appearance37.BorderColor = System.Drawing.Color.Silver
        Me.ugdDishes.DisplayLayout.Override.RowAppearance = Appearance37
        Appearance38.BackColor = System.Drawing.Color.Transparent
        Appearance38.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ugdDishes.DisplayLayout.Override.RowSelectorAppearance = Appearance38
        Me.ugdDishes.DisplayLayout.Override.RowSelectorHeaderStyle = Infragistics.Win.UltraWinGrid.RowSelectorHeaderStyle.SeparateElement
        Me.ugdDishes.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.[True]
        Me.ugdDishes.DisplayLayout.Override.RowSelectorWidth = 10
        Me.ugdDishes.DisplayLayout.Override.RowSizing = Infragistics.Win.UltraWinGrid.RowSizing.AutoFree
        Me.ugdDishes.DisplayLayout.Override.RowSizingArea = Infragistics.Win.UltraWinGrid.RowSizingArea.RowBordersOnly
        Me.ugdDishes.DisplayLayout.Override.RowSpacingAfter = 1
        Me.ugdDishes.DisplayLayout.Override.RowSpacingBefore = 0
        Appearance39.BackColor = System.Drawing.Color.Navy
        Appearance39.BackGradientStyle = Infragistics.Win.GradientStyle.None
        Appearance39.BackHatchStyle = Infragistics.Win.BackHatchStyle.None
        Appearance39.ForeColor = System.Drawing.Color.White
        Me.ugdDishes.DisplayLayout.Override.SelectedRowAppearance = Appearance39
        Appearance40.BackColor = System.Drawing.SystemColors.ControlLight
        Me.ugdDishes.DisplayLayout.Override.TemplateAddRowAppearance = Appearance40
        Me.ugdDishes.DisplayLayout.RowConnectorColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ugdDishes.DisplayLayout.RowConnectorStyle = Infragistics.Win.UltraWinGrid.RowConnectorStyle.Solid
        Me.ugdDishes.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill
        Me.ugdDishes.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate
        Me.ugdDishes.DisplayLayout.ViewStyle = Infragistics.Win.UltraWinGrid.ViewStyle.SingleBand
        Me.ugdDishes.DisplayLayout.ViewStyleBand = Infragistics.Win.UltraWinGrid.ViewStyleBand.OutlookGroupBy
        Me.ugdDishes.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ugdDishes.Location = New System.Drawing.Point(12, 55)
        Me.ugdDishes.Name = "ugdDishes"
        Me.ugdDishes.Size = New System.Drawing.Size(915, 694)
        Me.ugdDishes.TabIndex = 556
        Me.ugdDishes.Tag = "30,56"
        '
        'DishBindingSource
        '
        Me.DishBindingSource.DataMember = "Dish"
        Me.DishBindingSource.DataSource = Me.EzMenuDataSet
        '
        'EzMenuDataSet
        '
        Me.EzMenuDataSet.DataSetName = "EZMenuDataSet"
        Me.EzMenuDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'DishTableAdapter
        '
        Me.DishTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.AltAddressTableAdapter = Nothing
        Me.TableAdapterManager.Alternative_PhoneTableAdapter = Nothing
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.BankingTableAdapter = Nothing
        Me.TableAdapterManager.BankPrintTableAdapter = Nothing
        Me.TableAdapterManager.CallerIDLogTableAdapter = Nothing
        Me.TableAdapterManager.CodesTableAdapter = Nothing
        Me.TableAdapterManager.CollectorTableAdapter = Nothing
        Me.TableAdapterManager.CustomerTableAdapter = Nothing
        Me.TableAdapterManager.DirectionsTableAdapter = Nothing
        Me.TableAdapterManager.DishTableAdapter = Me.DishTableAdapter
        Me.TableAdapterManager.DrinksTableAdapter = Nothing
        Me.TableAdapterManager.FreeOffersTableAdapter = Nothing
        Me.TableAdapterManager.GroupsTableAdapter = Nothing
        Me.TableAdapterManager.KitchenNotesTableAdapter = Nothing
        Me.TableAdapterManager.ModifiersTableAdapter = Nothing
        Me.TableAdapterManager.NotesDBTableAdapter = Nothing
        Me.TableAdapterManager.OffersTableAdapter = Nothing
        Me.TableAdapterManager.OrderItemsTableAdapter = Nothing
        Me.TableAdapterManager.OrdersTableAdapter = Nothing
        Me.TableAdapterManager.SetIDTableAdapter = Nothing
        Me.TableAdapterManager.SetMealsTableAdapter = Nothing
        Me.TableAdapterManager.SetSelectedItemsTableAdapter = Nothing
        Me.TableAdapterManager.SetSelectedTableAdapter = Nothing
        Me.TableAdapterManager.SummaryTableAdapter = Nothing
        Me.TableAdapterManager.Table_BillTableAdapter = Nothing
        Me.TableAdapterManager.Table_DrinksTableAdapter = Nothing
        Me.TableAdapterManager.Table_MealTableAdapter = Nothing
        Me.TableAdapterManager.TypicalTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = EZMenu.EZMenuDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        Me.TableAdapterManager.UsersTableAdapter = Nothing
        '
        'cmbCuisine
        '
        Me.cmbCuisine.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance41.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance41.BorderColor = System.Drawing.Color.LightGray
        Me.cmbCuisine.Appearance = Appearance41
        Me.cmbCuisine.BackColor = System.Drawing.Color.WhiteSmoke
        Me.cmbCuisine.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList
        Me.cmbCuisine.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbCuisine.Location = New System.Drawing.Point(1034, 70)
        Me.cmbCuisine.Name = "cmbCuisine"
        Me.cmbCuisine.Size = New System.Drawing.Size(166, 22)
        Me.cmbCuisine.TabIndex = 677
        Me.cmbCuisine.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmbCuisine.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblCuisine
        '
        Me.lblCuisine.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance42.BackColor = System.Drawing.Color.Transparent
        Appearance42.ForeColor = System.Drawing.Color.DimGray
        Appearance42.TextHAlignAsString = "Center"
        Appearance42.TextVAlignAsString = "Bottom"
        Me.lblCuisine.Appearance = Appearance42
        Me.lblCuisine.AutoSize = True
        Me.lblCuisine.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCuisine.Location = New System.Drawing.Point(975, 74)
        Me.lblCuisine.Name = "lblCuisine"
        Me.lblCuisine.Size = New System.Drawing.Size(53, 17)
        Me.lblCuisine.TabIndex = 678
        Me.lblCuisine.Text = "Cuisine:"
        Me.lblCuisine.UseAppStyling = False
        '
        'lblNumDishes
        '
        Me.lblNumDishes.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Appearance43.BackColor = System.Drawing.Color.Transparent
        Appearance43.ForeColor = System.Drawing.Color.DimGray
        Appearance43.TextHAlignAsString = "Center"
        Appearance43.TextVAlignAsString = "Bottom"
        Me.lblNumDishes.Appearance = Appearance43
        Me.lblNumDishes.AutoSize = True
        Me.lblNumDishes.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNumDishes.Location = New System.Drawing.Point(12, 786)
        Me.lblNumDishes.Name = "lblNumDishes"
        Me.lblNumDishes.Size = New System.Drawing.Size(115, 17)
        Me.lblNumDishes.TabIndex = 679
        Me.lblNumDishes.Text = "Number of items:"
        Me.lblNumDishes.UseAppStyling = False
        '
        'frmDishes2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(1266, 815)
        Me.ControlBox = False
        Me.Controls.Add(Me.lblNumDishes)
        Me.Controls.Add(Me.lblCuisine)
        Me.Controls.Add(Me.cmbCuisine)
        Me.Controls.Add(Me.cmdBack)
        Me.Controls.Add(Me.ugbOptions)
        Me.Controls.Add(Me.cmdConcise)
        Me.Controls.Add(Me.cmdDishCascade)
        Me.Controls.Add(Me.cmdLabels)
        Me.Controls.Add(Me.cmdDishesHistory)
        Me.Controls.Add(Me.cmdShowSubgroup)
        Me.Controls.Add(Me.cmdDeleteDish)
        Me.Controls.Add(Me.cmdAddDish)
        Me.Controls.Add(Me.ugdDishes)
        Me.Controls.Add(Me.UltraLabel1)
        Me.Controls.Add(Me.pnlHeader)
        Me.DoubleBuffered = True
        Me.MinimumSize = New System.Drawing.Size(1000, 770)
        Me.Name = "frmDishes2"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.pnlHeader.ClientArea.ResumeLayout(False)
        Me.pnlHeader.ResumeLayout(False)
        CType(Me.ugbOptions, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ugbOptions.ResumeLayout(False)
        Me.ugbOptions.PerformLayout()
        CType(Me.txtPriceSmall, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtPriceLarge, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtShortName, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtShortcode, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtSearchString, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lstShortcode, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ugdDishes, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DishBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EzMenuDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbCuisine, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents tmrCallPhone As System.Windows.Forms.Timer
    Friend WithEvents tmrTimer As System.Windows.Forms.Timer
    Friend WithEvents pnlHeader As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents lblHeader As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel1 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents cmdBack As Infragistics.Win.Misc.UltraButton
    Private WithEvents ugbOptions As Infragistics.Win.Misc.UltraGroupBox
    Friend WithEvents UltraLabel3 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents cmdSearch As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdPriceDelete As Infragistics.Win.Misc.UltraButton
    Friend WithEvents lblShortName As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents cmdPriceSave As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraLabel2 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblShortCode As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents cmdSaveShortName As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraLabel4 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents cmdShortcodeAdd As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDeleteShortName As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdShortcodeDelete As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdConcise As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDishCascade As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdLabels As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDishesHistory As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdShowSubgroup As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDeleteDish As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdAddDish As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ugdDishes As Infragistics.Win.UltraWinGrid.UltraGrid
    Friend WithEvents DishTableAdapter As EZMenuDataSetTableAdapters.DishTableAdapter
    Private WithEvents EzMenuDataSet As EZMenuDataSet
    Friend WithEvents DishBindingSource As BindingSource
    Friend WithEvents TableAdapterManager As EZMenuDataSetTableAdapters.TableAdapterManager
    Friend WithEvents cmbCuisine As Infragistics.Win.UltraWinEditors.UltraComboEditor
    Friend WithEvents lstShortcode As Infragistics.Win.UltraWinListView.UltraListView
    Friend WithEvents lblCuisine As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblNumDishes As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents txtPriceSmall As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtPriceLarge As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtShortName As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtShortcode As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtSearchString As Infragistics.Win.UltraWinEditors.UltraTextEditor
End Class
