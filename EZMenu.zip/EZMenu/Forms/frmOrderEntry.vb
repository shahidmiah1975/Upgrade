﻿Imports System.Configuration
Imports Infragistics.Win
Imports Infragistics.Win.Misc
Imports Infragistics.Win.UltraWinGrid
Imports Infragistics.Win.UltraWinDataSource
Imports EZControls
Imports EZMenu.Core.Enums
Imports EZMenu.Core.Models
Imports EZService.Repository
Imports EZMenu.Core

Public Class frmOrderEntry

    Private WithEvents DishKBCtrl As DishKBControl
    'Private drcGroups As DataRowCollection
    Private dttDataTable As DataTable
    Private i, j, intNumDishes, intDQty, intDishesPosition As Short
    Private strMyDishName As String
    Private blnSetMode As Boolean
    Private intCurPosition, intMaxGrpButs, intFirstIndex, intLastIndex As Short
    Private gridRowIndex As Integer
    Private intGroupFontSizeNormal As Short = GetAppSettingCS("FontSizeGroups", 10)
    Private fontDishButtons = New Font("Franklin Gothic Medium", intGroupFontSizeNormal, FontStyle.Regular, GraphicsUnit.Point, 0)
    Private GroupButtonSize As Size = New Size(137, 41)
    Private DishButtonSize As Size = New Size(152, 41)
    Private DishInfo As DishModel
    Private Const strIsModRow As String = "ismodrow"
    Private totalsAdjustmentsDiscounts As PriceAdjustmentsModel
    Private totalsAdjustmentsCharges As PriceAdjustmentsModel
    Private dishRepo As DishRepository
    Private groupsCollection As List(Of GroupModel)
    Private objTablesForDrinks As frmTables2

    Public Sub New()

        MyBase.New

        ' This call is required by the designer.
        InitializeComponent()

        If objPayment Is Nothing Then objPayment = New frmPayment
        If objOrders Is Nothing Then objOrders = New frmOrders

        DishInfo = New DishModel
        dishRepo = New DishRepository()

    End Sub

    Private _cancelButtonPressed As Boolean
    Public ReadOnly Property CancelPressed() As Boolean
        Get
            Return _cancelButtonPressed
        End Get
    End Property

    Public Property CurrentOrderType As OrderTypeEnum

    Private Sub frmOrderEntry_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Try
            Size = Owner.Size
            Location = Owner.Location

            DishTableAdapter.Connection.ConnectionString = ConfigurationManager.ConnectionStrings(EZConstants.EZDatabaseConnectionString).ConnectionString
            GroupsTableAdapter.Connection.ConnectionString = ConfigurationManager.ConnectionStrings(EZConstants.EZDatabaseConnectionString).ConnectionString

            GroupsTableAdapter.Fill(EZMenuDataSet.Groups)
            DishTableAdapter.Fill(EZMenuDataSet.Dish)

            ShowOrHideCuisineButton()

            CreateGroupButtons("Menu")

            SetButtonAttributes(cmdTypical)

            ugdOrderGrid.DisplayLayout.Bands(0).Columns("DCode").CellActivation = Activation.Disabled
            ugdOrderGrid.DisplayLayout.Override.RowAppearance.BorderColor = ugdOrderGrid.DisplayLayout.Override.RowAppearance.BackColor
            ugdOrderGrid.DisplayLayout.Override.CellAppearance.BorderColor = ugdOrderGrid.DisplayLayout.Override.RowAppearance.BackColor

            _cancelButtonPressed = False
            totalsAdjustmentsDiscounts = New PriceAdjustmentsModel
            totalsAdjustmentsCharges = New PriceAdjustmentsModel

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub ShowOrHideCuisineButton()

        Dim blnShowCuisineButton As Boolean = False

        If GetAppSettingCS("MultiCuisines", True) = True Then
            Dim cuisines As List(Of CuisineModel) = dishRepo.GetCuisines()
            If cuisines IsNot Nothing AndAlso cuisines.Count > 0 Then
                blnShowCuisineButton = Not cuisines.Count = 1
                cmdCuisine.Text = GetAppSettingCS("MultiCuisinesDefault", cuisines.Item(0).Name)
            End If
        End If

        If cmdCuisine.Text = "<cuisine>" Then cmdCuisine.Text = GetAppSettingCS("MultiCuisinesDefault", "Indian")
        cmdCuisine.Visible = blnShowCuisineButton
        SetButtonAttributes(cmdCuisine)

    End Sub

    Private Sub DishButtonClick(btnDish As UltraButton, e As EventArgs)

        Try

            intDQty = 1

            'see if in concise menu
            If GetAppSettingCS("DishesUseConcise", True) = True Then
                SQLQuery = $"SELECT * FROM Dish 
                             WHERE UniqueID IN (SELECT UniqueID FROM DishConcise WHERE ConciseName = '{ btnDish.Text.ToString.Punctuate }') 
                             ORDER BY DishName"
                drcDatarowCollection = objDB.GetDataRows(SQLQuery)
                If drcDatarowCollection IsNot Nothing AndAlso drcDatarowCollection.Count > 0 Then
                    tempStr = btnDish.Text

                    Using objForm As New frmDishCascadeMenu(drcDatarowCollection, btnDish, True)
                        objForm.Display()
                    End Using

                    If tempStr <> "" Then GetDishDetails(tempStr)
                    Exit Sub
                End If
            End If

            'see if this has cascade items
            SQLQuery = $"SELECT * FROM DishCascade WHERE UniqueID = {btnDish.Tag} ORDER BY BoxNumber"
            drcDatarowCollection = objDB.GetDataRows(SQLQuery)
            If drcDatarowCollection IsNot Nothing AndAlso drcDatarowCollection.Count > 0 Then
                tempStr = btnDish.Text

                Using objForm As New frmDishCascadeMenu(drcDatarowCollection, btnDish, False)
                    objForm.Display()
                End Using

                If tempStr <> "" Then GetDishDetails(btnDish.Tag, tempStr)
            Else
                GetDishDetails(btnDish.Tag)
                MoveCursor()
            End If

        Catch ex As Exception
            WriteToLog(ex)
        End Try

    End Sub

    Private Sub GetDishDetails(sngUniqueID As Single, Optional strQName As String = "")

        drDataRow = clsDish.GetDishDetails(sngUniqueID)

        If drDataRow IsNot Nothing Then
            Dim arrDCM As String() = Nothing

            If strMyDishName = Nothing Then strMyDishName = drDataRow.Item(LNSNOnscreen).ToString
            If strQName <> "" Then
                arrDCM = tempStr.Split("^")
                strMyDishName = arrDCM(0)
            End If

            If blnSetMode = False Then

                'update dish in grid if it exists already
                If UpdateDishInGrid(strMyDishName) = False Then
                    DishInfo = New DishModel
                    With DishInfo
                        .Code = CShort(drDataRow.Item("Code").ToString)
                        .DishName = strMyDishName
                        .Qty = intDQty
                        .PriceIn = CDec(Val(drDataRow.Item("PriceIn")))
                        If strQName <> "" Then .PriceIn = arrDCM(1)
                        .PriceOut = CDec(Val(drDataRow.Item("PriceOut")))
                        If strQName <> "" Then .PriceOut = arrDCM(2)
                        .Discountable = CShort(drDataRow.Item("Discountable"))
                        .GroupName = drDataRow.Item("GroupName").ToString
                        .GroupIndex = CShort(drDataRow.Item("GroupIndex"))
                        .Mods = String.Empty
                        .IsStarter = .GroupName.ToUpper = GetAppSettingCS("StarterGroupName", "STARTER").ToString.ToUpper
                        .ShortName = Nothing
                    End With

                    FillInCellValues(DishInfo)

                End If

                AddUpGridTotals()

            Else
                If ugdOrderGrid.ActiveRow IsNot Nothing Then
                    If UpdateSetItemInGrid(strMyDishName) = False Then
                        AddSetItem(strMyDishName, 0)
                    End If
                Else
                    strMsgBox = "No dish row has been selected. Select a dish or turn off set-meal selection."
                    EZMsgBox.Show(strMsgBox, MessageBoxButtons.OK)
                End If

            End If

        Else
            EZMsgBox.Show("No match found", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End If

        strMyDishName = Nothing

    End Sub

    Private Function UpdateDishInGrid(strDishToUpgrade As String) As Boolean
        'returns True if strDishToUpgrade found in grid and updated

        With ugdOrderGrid
            For Each mRow In .Rows
                gridRowIndex = mRow.Index
                tempStr = .Rows(gridRowIndex).Cells("DName").Value.ToString.Trim
                tempStr = Replace(tempStr, GetAppSettingCS("PortionSmall", "[S]"), "").Trim
                tempStr = Replace(tempStr, GetAppSettingCS("PortionLarge", "[L]"), "").Trim

                If strDishToUpgrade.ToUpper = tempStr.ToUpper Then
                    .Rows(gridRowIndex).Cells("DQty").Value = .Rows(gridRowIndex).Cells("DQty").Value + intDQty
                    .Rows(gridRowIndex).Cells("Total").Value = fixCur(.Rows(gridRowIndex).Cells("DPrice").Value * .Rows(gridRowIndex).Cells("DQty").Value)
                    .Update()
                    .Rows(gridRowIndex).Activate()
                    Return True
                End If
            Next
        End With

        Return False

    End Function

    Private Sub FillInCellValues(dishToUpdate As DishModel)

        Dim intPosition As Short = 0

        ugdOrderGrid.SuspendLayout()

        'find the correct dish position
        If ugdOrderGrid.Rows.Count > 0 Then
            intPosition = DishPosition(dishToUpdate.Code, dishToUpdate.GroupIndex)
        End If

        DeActivateRow()

        Dim myRow As UltraDataRow = udsOrder.Rows.Insert(intPosition)
        myRow.Item("DCode") = dishToUpdate.Code
        myRow.Item("DName") = dishToUpdate.DishName
        myRow.Item("DPrice") = fixCur(InOutPrice(dishToUpdate, CurrentOrderType))
        myRow.Item("DQty") = dishToUpdate.Qty
        myRow.Item("Total") = fixCur(dishToUpdate.Qty * myRow.Item("DPrice"))
        myRow.Item("Mods") = dishToUpdate.Mods
        myRow.Item("Discountable") = dishToUpdate.Discountable
        myRow.Item("IsStarter") = dishToUpdate.IsStarter
        myRow.Item("OriPrice") = fixCur(InOutPrice(dishToUpdate, CurrentOrderType))
        myRow.Item("PriceIn") = dishToUpdate.PriceIn
        myRow.Item("PriceOut") = dishToUpdate.PriceOut
        myRow.Item("GroupIndex") = dishToUpdate.GroupIndex
        myRow.Item("HiLite") = "1"

        ugdOrderGrid.DataSource = udsOrder
        ActivateRow()
        ugdOrderGrid.ResumeLayout()
        ugdOrderGrid.Refresh()

    End Sub

    Public Sub AddNewDish(dishToAdd As DishModel)

        ugdOrderGrid.SuspendLayout()

        DeActivateRow()

        Dim myRow As UltraDataRow = udsOrder.Rows.Add
        myRow.Item("DCode") = dishToAdd.Code
        myRow.Item("DName") = dishToAdd.DishName
        myRow.Item("DPrice") = fixCur(InOutPrice(dishToAdd, CurrentOrderType))
        myRow.Item("DQty") = dishToAdd.Qty
        myRow.Item("Total") = fixCur(dishToAdd.Qty * InOutPrice(dishToAdd, CurrentOrderType))
        myRow.Item("Mods") = String.Empty
        myRow.Item("IsStarter") = dishToAdd.IsStarter
        myRow.Item("Discountable") = dishToAdd.Discountable
        myRow.Item("OriPrice") = dishToAdd.PriceIn
        myRow.Item("PriceIn") = dishToAdd.PriceIn
        myRow.Item("PriceOut") = dishToAdd.PriceOut
        myRow.Item("GroupIndex") = dishToAdd.GroupIndex
        myRow.Item("HiLite") = "1"

        ugdOrderGrid.DataSource = udsOrder
        ActivateRow()
        ugdOrderGrid.ResumeLayout()
        ugdOrderGrid.Refresh()

        AddUpGridTotals()

    End Sub

    Private Function InOutPrice(dish As DishModel, orderType As OrderTypeEnum) As Decimal

        Return If(orderType = OrderTypeEnum.Table, dish.PriceIn, dish.PriceOut)

    End Function

    Private Sub ActivateRow()

        With ugdOrderGrid
            For Each mrow In .Rows
                gridRowIndex = mrow.Index
                If .Rows(gridRowIndex).Cells("HiLite").Value() = 1 Then .Rows(gridRowIndex).Activate()
            Next
        End With

    End Sub

    Private Sub DeActivateRow()

        With ugdOrderGrid
            For Each mrow In .Rows
                gridRowIndex = mrow.Index
                .Rows(gridRowIndex).Cells("HiLite").Value() = 0
            Next
        End With

    End Sub

    Public Function CreateGroupButtons(strMainORTypical As String) As Boolean

        Dim ubtnTemp As UltraButton

        Try
            If cmdCuisine.Text = "<cuisine>" Then cmdCuisine.Text = GetAppSettingCS("MultiCuisinesDefault", "Indian")

            groupsCollection = dishRepo.GetGroups(strMainORTypical, cmdCuisine.Text)
            If groupsCollection.Any Then
                pnlGroup.ClientArea.Controls.Clear()
                pnlGroup.Height = GroupButtonSize.Height
                pnlGroup.Top = 0

                For Each grp In groupsCollection
                    ubtnTemp = New UltraButton
                    With ubtnTemp
                        .Name = IIf(InStr(SQLQuery, "Typical"), "btnTypical", "btnGroups")
                        .Text = grp.GroupName
                        .StyleSetName = "OEGroupButton"
                        .Size = GroupButtonSize
                        SetButtonAttributes(ubtnTemp)
                        .Visible = True
                    End With
                    AddHandler ubtnTemp.Click, AddressOf GroupButtonClick
                    pnlGroup.ClientArea.Controls.Add(ubtnTemp)
                Next

                'do we need the nav buttons
                Dim blnGroupNavs As Boolean = pnlGroup.Height > pnlGroupMain.Height
                cmdGroupUp.Size = GroupButtonSize
                cmdGroupDown.Size = GroupButtonSize
                SetButtonAttributes(cmdGroupUp)
                SetButtonAttributes(cmdGroupDown)
                cmdGroupUp.Visible = blnGroupNavs
                cmdGroupDown.Visible = blnGroupNavs

                If blnGroupNavs = False Then
                    pnlGroupMain.Top = cmdGroupUp.Top
                Else
                    pnlGroupMain.Top = cmdGroupUp.Top + cmdGroupUp.Height
                End If

                Return True

            Else
                strMsgBox = "No dish groups have been found in the database. If this is the first time you are running this application, then go to Settings and enter group names there."
                EZMsgBox.Show(strMsgBox, MessageBoxButtons.OK)
                Return False

            End If

        Catch ex As Exception
            strMsgBox = ex.Message
            EZMsgBox.Show(strMsgBox, MessageBoxIcon.Error)
            Return False

        End Try

    End Function

    Private Sub CreateDishesArray(param As String)

        Dim ubtnTemp As New UltraButton

        Try
            If param = "" Then Exit Sub

            'get values from the DB
            EZMenuDataSet.EnforceConstraints = False
            If cmdTypical.Text = "Typical" Then
                If GetAppSettingCS("DishesUseConcise", 0) = 0 Then
                    DishTableAdapter.FillByGroupName(EZMenuDataSet.Dish, param)
                Else
                    DishTableAdapter.FillByGroupNameConcise(EZMenuDataSet.Dish, param)
                End If
            Else
                DishTableAdapter.FillByTypical(EZMenuDataSet.Dish, param)
            End If

            cmdDishesBack.Enabled = False
            cmdDishesNext.Enabled = False

            'clear the dishes grid
            'pnlDishes.ClientArea.SuspendLayout()
            pnlDishes.ClientArea.Controls.Clear()
            pnlDishes.Left = 2
            pnlDishes.Width = DishButtonSize.Width

            intNumDishes = DishBindingSource.Count
            If intNumDishes > 0 Then
                dttDataTable = EZMenuDataSet.Dish
                DishBindingSource.MoveFirst()
                For iCnt As Short = 1 To intNumDishes
                    ubtnTemp = New UltraButton
                    With ubtnTemp
                        .Name = "DishName"
                        .Text = dttDataTable.Rows(iCnt - 1).Item(LNSNOnscreen)
                        .Tag = dttDataTable.Rows(iCnt - 1).Item("UniqueID")
                        .StyleSetName = "OEDishButton"
                        .Size = DishButtonSize
                        SetButtonAttributes(ubtnTemp)
                        .Visible = True
                    End With
                    AddHandler ubtnTemp.Click, AddressOf DishButtonClick
                    pnlDishes.ClientArea.Controls.Add(ubtnTemp)
                    DishBindingSource.MoveNext()
                Next

                'pnlDishes.ClientArea.ResumeLayout()
                pnlDishes.Visible = True
                cmdDishesNext.Enabled = pnlDishes.Width > pnlDishesMain.Width
                cmdDishesBack.Enabled = cmdDishesNext.Enabled
                intDishesPosition = DishBindingSource.Position

            Else
                strMsgBox = "No item found belonging to this group"
                EZMsgBox.Show(strMsgBox, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            End If

        Catch ex As Exception
            WriteToLog(ex)
        End Try

    End Sub

    Private Sub GroupButtonClick(sender As Object, e As EventArgs)

        HideVirtualKB()

        Dim ubtnGPressed As UltraButton = DirectCast(sender, UltraButton)

        If ubtnGPressed.Tag = "1" Then Exit Sub

        GroupButtonHilitOff()

        'hilit on
        ubtnGPressed.StyleSetName = "OEGroupButtonPressed"
        ubtnGPressed.Tag = "1"

        CreateDishesArray(sender.text)

        MoveCursor()

    End Sub

    Private Sub UpDownButtonsAppearance(btnName As UltraButton)

        With btnName
            .StyleSetName = "OEGroupButton"
            .Size = GroupButtonSize
            .ShowFocusRect = False
            .ShowOutline = False
            .UseAppStyling = True
            .UseMnemonic = False
            .UseHotTracking = DefaultableBoolean.[True]
            .UseOsThemes = DefaultableBoolean.[False]
            .UseFlatMode = DefaultableBoolean.[True]
        End With

    End Sub

    Private Sub DishScroll(sender As Object, e As EventArgs) Handles cmdDishesBack.Click, cmdDishesNext.Click

        Try
            Dim p As Integer = 0

            Select Case sender.name
                Case "cmdDishesNext"
                    p = pnlDishes.Left - (pnlDishesMain.Width * 0.9)
                    If p <= pnlDishesMain.Width - pnlDishes.Width - 4 Then p = pnlDishesMain.Width - pnlDishes.Width - 4

                Case "cmdDishesBack"
                    p = pnlDishes.Left + (pnlDishesMain.Width * 0.9)
                    If p > 2 Then p = 2

            End Select

            pnlDishes.Left = p

        Catch ex As Exception
        End Try

    End Sub

    Private Sub OGUpDown(sender As Object, e As EventArgs) Handles cmdOGUp.Click, cmdOGDown.Click

        If ugdOrderGrid.Rows.Count = 0 Then Exit Sub

        upnlChoices.Visible = False

        If ugdOrderGrid.ActiveRow Is Nothing Then
            ugdOrderGrid.ActiveRow = ugdOrderGrid.Rows(0)
        End If

        If sender.name = "cmdOGUp" Then
            If ugdOrderGrid.ActiveRow.Index > 0 Then
                ugdOrderGrid.ActiveRow = ugdOrderGrid.Rows(ugdOrderGrid.ActiveRow.Index - 1)
            Else
                ugdOrderGrid.ActiveRow = ugdOrderGrid.Rows(ugdOrderGrid.Rows.Count - 1)
            End If

        Else
            If ugdOrderGrid.ActiveRow.Index < ugdOrderGrid.Rows.Count - 1 Then
                ugdOrderGrid.ActiveRow = ugdOrderGrid.Rows(ugdOrderGrid.ActiveRow.Index + 1)
            Else
                ugdOrderGrid.ActiveRow = ugdOrderGrid.Rows(0)
            End If

        End If

    End Sub

    Private Sub cmdEditDish_Click(sender As Object, e As EventArgs) Handles cmdEditDish.Click

        Try
            If ugdOrderGrid.Rows.Count > 0 AndAlso ugdOrderGrid.ActiveRow IsNot Nothing Then

                HideVirtualKB()

                Dim objModifyForm As New frmModify(Me, CurrentOrderType)

                If RowIsNotModOrSet(ugdOrderGrid.ActiveRow.Index) Then
                    'edit a dish
                    objModifyForm.Edit(ugdOrderGrid.ActiveRow)

                ElseIf RowIsNotSet() = False Then
                    'edit a set item
                    objModifyForm.EditSetItem(ugdOrderGrid.ActiveRow)

                Else
                    'on a modifier row
                    objModifyForm.EditModifier(ugdOrderGrid.ActiveRow,
                                               GetDishRowValue("DName"),
                                               GetDishRowValue("DPrice"),
                                               GetDishRowValue("DQty"))
                End If

                objModifyForm.ShowDialog()
                objModifyForm.Dispose()

            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub cmdDeleteDish_Click(sender As Object, e As EventArgs) Handles cmdDeleteDish.Click

        Try
            With ugdOrderGrid

                If .ActiveRow IsNot Nothing Then
                    Dim intRowIndex = .ActiveRow.Index
                    Dim blnCheckForMore As Boolean
                    Dim urDishRow As UltraGridRow

                    upnlChoices.Visible = False

                    If RowIsNotModOrSet(.ActiveRow.Index) Then

                        'delete any mod/set item rows beneath
                        Do
                            blnCheckForMore = False
                            If intRowIndex + 1 < .Rows.Count AndAlso RowIsNotModOrSet(intRowIndex + 1) = False Then
                                'delete this row
                                .Rows(intRowIndex + 1).Delete(False)
                                blnCheckForMore = True
                            End If
                        Loop While blnCheckForMore
                        'then delete the main row itself
                        .ActiveRow.Delete(False)
                        'hilit row above/below
                        If .Rows.Count > 0 Then
                            If intRowIndex < .Rows.Count Then
                                .ActiveRow = .Rows(intRowIndex)
                            ElseIf intRowIndex = .Rows.Count Then
                                .ActiveRow = .Rows(intRowIndex - 1)
                            End If
                        End If
                    Else
                        'this is a mod/set item row, so just delete it
                        Dim intDishRowIndex = -1
                        urDishRow = DishRow()
                        If urDishRow IsNot Nothing Then intDishRowIndex = urDishRow.Index
                        .ActiveRow.Delete(False)
                        If intDishRowIndex <> -1 Then .ActiveRow = .Rows(intDishRowIndex)
                    End If

                    AddUpGridTotals()

                End If
            End With

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub GroupUpDown(sender As UltraButton, e As EventArgs)

        GroupButtonHilitOff()

        Select Case sender.Text

            Case "Up"   'move up
                intFirstIndex -= 13
                intCurPosition = intFirstIndex
                If intCurPosition < 0 Then intCurPosition = 0

                For Each myObj As Control In pnlGroup.ClientArea.Controls
                    If (myObj.Text <> "Up") And (myObj.Text <> "Down") Then
                        If intCurPosition < groupsCollection.Count Then
                            myObj.Text = groupsCollection(intCurPosition).GroupName
                            myObj.Visible = True
                            intLastIndex = intCurPosition
                            intCurPosition += 1
                        End If
                    End If
                Next

            Case "Down" 'move down
                intFirstIndex = intLastIndex + 1
                intCurPosition = intFirstIndex

                For Each myObj As Control In pnlGroup.ClientArea.Controls
                    If (myObj.Text <> "Up") And (myObj.Text <> "Down") Then
                        If intCurPosition < groupsCollection.Count Then
                            myObj.Text = groupsCollection(intCurPosition).GroupName
                            myObj.Visible = True
                            intLastIndex = intCurPosition
                            intCurPosition += 1
                        Else
                            myObj.Text = String.Empty
                            myObj.Visible = False
                        End If
                    End If
                Next

            Case Else

        End Select

        For Each myObj As Control In pnlGroup.ClientArea.Controls
            If myObj.Text = "Up" Then myObj.Enabled = intFirstIndex <> 0
            If myObj.Text = "Down" Then myObj.Enabled = intLastIndex + 1 < groupsCollection.Count
        Next

    End Sub

    Private Function DishPosition(ByRef CurDishCode, ByRef CurGroupCode)

        Dim tempCode, tempGroup, tempPos As Integer
        Dim mrow As UltraGridRow

        tempPos = ugdOrderGrid.Rows.Count

        If CStr(CurDishCode) <> String.Empty Then
            'find position with group index
            With ugdOrderGrid
                For Each mrow In .Rows
                    gridRowIndex = mrow.Index
                    If RowIsNotModOrSet(gridRowIndex) Then
                        tempGroup = .Rows(gridRowIndex).Cells("GroupIndex").Value()
                        If .Rows(gridRowIndex).Cells("DName").Value().ToString.ToUpper Like strPapadom = False Then
                            If tempGroup = CurGroupCode AndAlso .Rows(gridRowIndex).Cells("DCode").Value() <> String.Empty Then
                                'find position within its group now, according to dish code
                                tempCode = .Rows(gridRowIndex).Cells("DCode").Value()
                                If tempCode > Val(CurDishCode) Then
                                    Return gridRowIndex
                                End If
                            ElseIf tempGroup > CurGroupCode Then
                                Return gridRowIndex
                            End If
                        End If
                    End If
                Next
            End With
        End If

        Return tempPos

    End Function

    Private Sub cmdLastItemQty_Click(sender As Object, e As EventArgs) Handles cmdLastItemQty.Click

        If ugdOrderGrid.ActiveRow IsNot Nothing Then
            If RowIsNotModifier() Then
                upnlChoices.Visible = False

                Dim strNumInput As String

                Using objFormQty As New frmQty
                    objFormQty.Display("Enter quantity", 0)
                    strNumInput = objFormQty.ReturnValue
                End Using

                If strNumInput <> "x" Then
                    If CShort(strNumInput) > 0 And CShort(strNumInput) < 101 Then
                        ugdOrderGrid.ActiveRow.Cells("DQty").Value = CShort(strNumInput)
                        UpdateRowPrice(ugdOrderGrid.ActiveRow)
                        AddUpGridTotals()
                    Else
                        strMsgBox = "Quantity must be between 1 and 100"
                        EZMsgBox.Show(strMsgBox, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    End If
                End If
            Else
                'DisplayErrorMessage("This option is not available for a modifier.")
            End If
        End If

    End Sub

    Private Sub cmdOEBack_Click(sender As Object, e As EventArgs) Handles cmdOEBack.Click

        'if in edit mode
        If objOrders.Tag = "EditMode" Then
            objDelivColn.cmdBackScreen.Enabled = False
            Hide()
            objDelivColn.Show()
        Else
            Hide()
        End If

    End Sub

    Private Sub cmdOEDiscounts_Click(sender As Object, e As EventArgs) Handles cmdOEDiscounts.Click

        Using objPriceAdjustments As New frmPriceAdjustments
            objPriceAdjustments.Display(CurrentOrderType, totalsAdjustmentsDiscounts, totalsAdjustmentsCharges)
            Dim ret As PriceAdjustmentsModel = objPriceAdjustments.ReturnValue
            If ret.Cancelled = False Then
                AddUpGridTotals()
            End If
        End Using

    End Sub

    Public Sub AddUpGridTotals()
        'Calculates the total price of the selected dishes
        'Also takes into account the delivery charge or collection discount

        Try
            Dim sumDishes, ToPay As Decimal
            Dim decCharges, decDiscounts, decGlobalCharge, decGlobalDiscount As Decimal

            sumDishes = SumOfDishes("A")    'total price of dishes ordered

            If CurrentOrderType = OrderTypeEnum.Collection Then
                decGlobalDiscount = fixCurFive(CalcGlobalDiscount(sumDishes))
            ElseIf CurrentOrderType = OrderTypeEnum.Delivery Then
                decGlobalCharge = fixCurFive(CalcDelivery(sumDishes))
            End If

            Application.DoEvents()

            If CurrentOrderType <> OrderTypeEnum.Table Then
                If totalsAdjustmentsDiscounts.GlobalIsOff = True Then decGlobalDiscount = 0
                If totalsAdjustmentsCharges.GlobalIsOff = True Then decGlobalCharge = 0

                decDiscounts = UpdatePriceAdjustments(totalsAdjustmentsDiscounts, sumDishes)
                decCharges = UpdatePriceAdjustments(totalsAdjustmentsCharges, sumDishes)
            End If

            ToPay = sumDishes + (decCharges + decGlobalCharge) - (decDiscounts + decGlobalDiscount)

            If lblDrinksOE.Visible Then
                ToPay += CDec(lblDrinksOE.Text)
            End If

            lblNumItems.Text = "Items: " & NumberOfItems()
            lblSubtotal.Text = fixCurFive(sumDishes)

            lblPriceAdjDiscounts.Text = "-" + fixCur(decDiscounts)
            lblPriceAdjCharges.Text = fixCur(decCharges)
            lblGDiscounts.Text = "-" + fixCur(decGlobalDiscount)
            lblGCharges.Text = fixCur(decGlobalCharge)
            lblToPay.Text = fixCur(ToPay)

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Function UpdatePriceAdjustments(ByRef priceAdjustment As PriceAdjustmentsModel, subTotal As Decimal) As Decimal

        If priceAdjustment.Reset = True Then
            priceAdjustment.CalculatedTotal = 0
        Else
            priceAdjustment.CalculatedTotal = CalculateSelectedDC(priceAdjustment, subTotal)
            If priceAdjustment.DiscountOrCharge = DiscountOrChargeEnum.Discount Then
                lblPriceAdjDiscountsLbl.Text = IIf(priceAdjustment.Name = "", "Discounts:", priceAdjustment.Name + ":")
            ElseIf priceAdjustment.DiscountOrCharge = DiscountOrChargeEnum.Charge Then
                lblPriceAdjChargesLbl.Text = IIf(priceAdjustment.Name = "", "Charges:", priceAdjustment.Name + ":")
            End If
        End If

        Return priceAdjustment.CalculatedTotal

    End Function

    Private Sub cmdOEHome_Click(sender As Object, e As EventArgs) Handles cmdOEHome.Click

        _cancelButtonPressed = True

        strMsgBox = "Do you wish to cancel and return?"
        intMsgBoxResult = EZMsgBox.Show(strMsgBox, MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        If CurrentOrderType = OrderTypeEnum.Table Then
            If intMsgBoxResult = MsgBoxResult.Yes Then
                Close()
            End If

        Else
            'cancel if in edit mode
            If objOrders.Tag = "EditMode" Then
                If intMsgBoxResult = MsgBoxResult.Yes Then
                    CurrentOrderType = Nothing
                    objDelivColn.SetScreen(OrderTypeEnum.EditOff)
                    objOrders.BringToFront()
                End If
            Else
                If intMsgBoxResult = MsgBoxResult.Yes Then
                    ShowHomeScreen()
                End If
            End If
        End If

    End Sub

    Private Sub cmdDishClearAll_Click(sender As Object, e As EventArgs) Handles cmdDishClearAll.Click

        strMsgBox = "This will clear all the items in the grid." & vbCrLf & "Are you sure?"
        intMsgBoxResult = EZMsgBox.Show(strMsgBox, MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If intMsgBoxResult = MsgBoxResult.Yes Then
            udsOrder.Rows.Clear()
            ugdOrderGrid.Update()
            AddUpGridTotals()
        End If

    End Sub

    Private Sub cmdIncDecDish_Click(sender As Object, e As EventArgs) Handles cmdIncDish.Click, cmdDecDish.Click

        Try
            If ugdOrderGrid.ActiveRow IsNot Nothing Then

                If RowIsNotModifier() AndAlso IsANumber(ugdOrderGrid.ActiveRow.Cells("DQty").Value) Then

                    Dim intCurQty As Short = ugdOrderGrid.ActiveRow.Cells("DQty").Text
                    upnlChoices.Visible = False

                    If sender Is cmdIncDish Then
                        intCurQty += 1
                    Else
                        If intCurQty > 1 Then intCurQty -= 1
                    End If

                    ugdOrderGrid.ActiveRow.Cells("DQty").Value = intCurQty
                    ugdOrderGrid.ActiveRow.Cells("Total").Value = ugdOrderGrid.ActiveRow.Cells("DQty").Value * ugdOrderGrid.ActiveRow.Cells("DPrice").Value

                    ModRowAction("DishQtyChange")
                    AddUpGridTotals()

                End If

            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub cmdShowKeyboard_Click(sender As Object, e As EventArgs) Handles cmdShowKeyboard.Click

        Try

            If DishKBCtrl Is Nothing Then
                DishKBCtrl = New DishKBControl

                pnlDishes.Visible = False
                GroupButtonHilitOff()
                txtKBCode.Clear()

                With DishKBCtrl
                    .Location = New Point(5, lblStatusBarDiv.Top - .Height)
                    .Parent = Me
                    .EZConnectionString = ConfigurationManager.ConnectionStrings(EZConstants.EZDatabaseConnectionString).ConnectionString
                    .ctrlName = txtKBCode
                    .upnlDishChoices = upnlChoices
                    .BorderStyle = BorderStyle.None
                    .Visible = True
                    .BringToFront()
                End With

            Else
                HideVirtualKB()

            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub cmdManualEntry_Click(sender As Object, e As EventArgs) Handles cmdManualEntry.Click

        Dim objModifyForm As New frmModify(Me, CurrentOrderType)
        objModifyForm.ManualEntry()
        objModifyForm.ShowDialog()
        objModifyForm.Dispose()

    End Sub

    Private Sub cmdOENext_Click(sender As Object, e As EventArgs) Handles cmdOENext.Click

        If CurrentOrderType = OrderTypeEnum.Table Then
            GroupButtonHilitOff()
            SaveTableOrder()
            cmdOEDiscounts.Enabled = True
            cmdPrintLabels.Enabled = True
            cmdAddDrink.Enabled = True
            objTables.GetTableInfo(CurTable)
            objTables.Show()
            Hide()

        Else
            If ugdOrderGrid.Rows.Count > 0 Then

                Dim blnDoProceedNow As Boolean = False
                Dim blnDTOk As Boolean = True
                Dim decMinDelivAmount As Decimal = GetAppSettingCS("MinDeliveryAmount", 0)

                If CurrentOrderType = OrderTypeEnum.Delivery Then
                    If GetAppSettingCS("MinDeliveryChecked", True) Then
                        If decMinDelivAmount > CDec(lblToPay.Text) Then
                            strMsgBox = "Minimum order amount (£" & fixCur(decMinDelivAmount) & ") not reached." & vbCrLf & "Do you wish to continue?"
                            intMsgBoxResult = EZMsgBox.Show(strMsgBox, MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                            If intMsgBoxResult = MsgBoxResult.Yes Then blnDoProceedNow = True
                        Else
                            blnDoProceedNow = True
                        End If
                    Else
                        blnDoProceedNow = True
                    End If

                    'If blnDoProceedNow = True Then blnDTOk = DeliveryCutOffTimeProceed()

                Else
                    blnDoProceedNow = True
                    blnDTOk = True

                End If

                If blnDoProceedNow = True And blnDTOk = True Then
                    GroupButtonHilitOff()

                    With objPayment
                        .cmdBack.Enabled = True
                        .cmdKitchenCopy.Enabled = objOrders.Tag <> "EditMode"
                        .cmdShopCopy.Enabled = objOrders.Tag <> "EditMode"
                        .cmdPrintOrder.Enabled = objOrders.Tag <> "EditMode"
                        .cmdSaveOrder.Enabled = True
                        .txtBillTotal.Text = lblToPay.Text
                        .txtTips.Enabled = False
                        .ubtnTips.Enabled = False
                        .CurrentOrderType = CurrentOrderType
                        .Tag = "DC"
                        '.ShowDialog()
                        .Show(Me)
                    End With
                End If

            Else
                strMsgBox = "There are no items selected."
                EZMsgBox.Show(strMsgBox, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            End If

        End If

    End Sub

    Private Sub SaveTableOrder()

        Try

            If CurTable > 0 Then

                'delete all from the Table_Meal about this table
                SQLQuery = "DELETE FROM Table_Meal WHERE TabUniqueID = " & TableInfo(CurTable).Id
                objDB.ExeNonQuery(SQLQuery)

                SQLQuery = "DELETE FROM Table_Mods WHERE TabUniqueID = " & TableInfo(CurTable).Id
                objDB.ExeNonQuery(SQLQuery)

                SQLQuery = "DELETE FROM SetItems WHERE OrderID = " & TableInfo(CurTable).Id
                objDB.ExeNonQuery(SQLQuery)

                CollateOrderInformation(OrderTypeEnum.Table, PrintDestinationEnum.SaveOnly, TableInfo(CurTable).Id)

                If ugdOrderGrid.Rows.Count > 0 Then
                    If TableInfo(CurTable).Status = TStatusEnum.Clean Then SetTableStatus(CurTable, TStatusEnum.InUse)
                End If

            Else
                strMsgBox = "A table has not been assigned to this order."
                EZMsgBox.Show(strMsgBox, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub cmdPrintLabels_Click(sender As Object, e As EventArgs) Handles cmdPrintLabels.Click

        If ugdOrderGrid.Rows.Count > 0 Then
            strMsgBox = "This will print labels for the selected dishes. Do you wish to proceed?"
            intMsgBoxResult = EZMsgBox.Show(strMsgBox, MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If intMsgBoxResult = MsgBoxResult.Yes Then PrintLabels()
        Else
            strMsgBox = "There are no dishes in the grid above -" & vbCrLf & " nothing to print!"
            EZMsgBox.Show(strMsgBox, MessageBoxIcon.Information)
        End If

    End Sub

    Private Sub cmdTypical_Click(sender As Object, e As EventArgs) Handles cmdTypical.Click

        If cmdTypical.Text = "Typical" Then
            If CreateGroupButtons("Typical") = True Then cmdTypical.Text = "Menu"
        Else
            If CreateGroupButtons("Menu") = True Then cmdTypical.Text = "Typical"
        End If

    End Sub

    Private Sub txtKBCode_TextChanged(sender As Object, e As EventArgs) Handles txtKBCode.TextChanged

        If txtKBCode.Text <> String.Empty Then

            If txtKBCode.Text.Substring(0, 2) = "##" Then

                If txtKBCode.Text.IndexOf("*") = -1 Then
                    DishTableAdapter.FillByCode(EZMenuDataSet.Dish, txtKBCode.Text.Substring(2), cmdCuisine.Text)
                Else
                    DishTableAdapter.FillByCascade(EZMenuDataSet.Dish, txtKBCode.Text.Substring(txtKBCode.Text.IndexOf("*") + 1), cmdCuisine.Text)
                End If

                If EZMenuDataSet.Dish.Rows.Count > 0 Then
                    drcDatarowCollection = EZMenuDataSet.Dish.Rows
                    upnlChoices.SuspendLayout()
                    For Each myObj In upnlChoices.ClientArea.Controls
                        If TypeName(myObj) = "UltraButton" Then
                            myObj.text = String.Empty
                            myObj.tag = String.Empty
                            myObj.visible = False
                        End If
                    Next
                    i = 0
                    For Each myRow As DataRow In drcDatarowCollection
                        For Each myObj In upnlChoices.ClientArea.Controls
                            If TypeName(myObj) = "UltraButton" AndAlso myObj.text = String.Empty AndAlso i < 7 Then
                                myObj.font = fontDishButtons
                                myObj.text = myRow.Item(LNSNOnscreen).ToString
                                myObj.tag = myRow!UniqueID
                                myObj.visible = True
                                i += 1
                                Exit For
                            End If
                        Next
                    Next
                    upnlChoices.Parent = pnlDishesMain.ClientArea
                    upnlChoices.Location = pnlDishes.Location + New Point(-2, -1)
                    upnlChoices.ResumeLayout()
                    upnlChoices.Visible = True
                End If

            Else

                tempStr = txtKBCode.Text    '--> sngUniqueID & ";" & strDCode & ";" & strDQty & ";" & strDName
                Dim arrDetails() As String = tempStr.Split(";")
                If Val(arrDetails(2)) < 100 Then
                    intDQty = Short.Parse(arrDetails(2))
                    strMyDishName = arrDetails(3)
                    GetDishDetails(Single.Parse(arrDetails(0)))
                    txtKBCode.Clear()
                Else
                    strMyDishName = "Dish quantity must be less than 100"
                    EZMsgBox.Show(strMyDishName, MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
            End If

        End If

        txtKBCode.Text = String.Empty

    End Sub

    Private Sub GroupButtonHilitOff()

        For Each myBut In pnlGroup.ClientArea.Controls
            If TypeName(myBut) = "UltraButton" Then
                If myBut.Tag = "1" Then
                    'hilit off
                    myBut.StyleSetName = "OEGroupButton"
                    myBut.Tag = "0"
                    Exit For
                End If
            End If
        Next

    End Sub

    Private Sub cmdAddDrink_Click(sender As Object, e As EventArgs) Handles cmdAddDrink.Click

        ShowHourGlass()

        If objTablesForDrinks Is Nothing Then
            objTablesForDrinks = New frmTables2("DrinksOut")
            objTablesForDrinks.Display(Me)
        Else
            objTablesForDrinks.ShowDialog()
        End If

    End Sub

    Private Sub MoveCursor()
        If GetAppSettingCS("DisableCursor", True) Then Cursor.Position = New Point(txtKBCode.Left, txtKBCode.Top)
    End Sub

    Private Sub ChoiceButtonsHandler(sender As Object, e As EventArgs) Handles cmdChoice1.Click, cmdChoice2.Click, cmdChoice3.Click, cmdChoice4.Click, cmdChoice5.Click, cmdChoice6.Click, cmdChoice7.Click

        intDQty = 1
        GetDishDetails(sender.tag)
        If DishKBCtrl IsNot Nothing Then DishKBCtrl.ClearAll()

    End Sub

    Private Sub HideVirtualKB()

        If DishKBCtrl IsNot Nothing Then
            DishKBCtrl.Visible = False
            DishKBCtrl = Nothing
        End If
        upnlChoices.Visible = False

    End Sub

    Public Sub GetCustomerPreviousOrder(intCustID As Short)

        Try

            SQLQuery = "SELECT * FROM CustOrderItems WHERE CustomerID = " & intCustID
            drcDatarowCollection = objDB.GetDataRows(SQLQuery)

            If drcDatarowCollection IsNot Nothing Then
                udsOrder.Rows.Clear()
                ugdOrderGrid.Update()
                For Each myRow As DataRow In drcDatarowCollection

                    strMyDishName = myRow.Item("Dish").ToString

                    'update dish in grid if it exists already
                    If UpdateDishInGrid(strMyDishName) = False Then
                        DishInfo = New DishModel
                        With DishInfo
                            .Code = CShort(myRow.Item("Code").ToString)
                            .DishName = strMyDishName
                            .Qty = CShort(Val(myRow.Item("Qty")))
                            .PriceIn = CDec(Val(myRow.Item("UnitPrice")))
                            .PriceOut = .PriceIn
                            .Discountable = CDec(myRow.Item("Discountable"))
                            .GroupName = String.Empty
                            .GroupIndex = CShort(myRow.Item("GroupIndex"))
                            .Mods = String.Empty
                            .IsStarter = String.Empty
                            .ShortName = String.Empty
                        End With

                        FillInCellValues(DishInfo)

                    End If
                Next

            Else
                Alert("Could not get customer's previous order")
            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

        strMyDishName = Nothing

    End Sub

    Private Sub cmdPrevOrder_Click(sender As Object, e As EventArgs) Handles cmdPrevOrder.Click

        Try
            If CustID > 0 Then
                SQLQuery = "SELECT * FROM CustOrders WHERE CustomerID = " & CustID
                drDataRow = objDB.GetSingleRow(SQLQuery)
                If drDataRow IsNot Nothing Then
                    Dim oTime As String = String.Empty
                    Dim oDate As String = String.Empty
                    Dim strToPay As String = drDataRow!ToPay.ToString

                    If Not IsDBNull(drDataRow!OrderTime) Then oTime = Format(CDate(drDataRow!OrderTime.ToString), "h:mm")
                    If Not IsDBNull(drDataRow!OrderDate) Then oDate = Format(CDate(drDataRow!OrderDate.ToString), "dddd dd MMM yyyy")

                    strMsgBox = "Previous order placed on:" & vbCrLf & oDate & "   @ " & Replace(oTime, ":", ".") & vbCrLf

                    SQLQuery = "SELECT * FROM CustOrderItems WHERE CustomerID = " & CustID
                    drcDatarowCollection = objDB.GetDataRows(SQLQuery)

                    If drcDatarowCollection IsNot Nothing Then
                        tempStr = String.Empty
                        For Each myRow As DataRow In drcDatarowCollection
                            tempStr &= Val(myRow.Item("Qty"))
                            tempStr &= " " & myRow.Item("Dish").ToString()
                            tempStr &= vbCrLf
                        Next
                        If tempStr <> String.Empty Then strMsgBox &= vbCrLf & tempStr & vbCrLf
                        strMsgBox &= "Bill total: £" & strToPay & vbCrLf
                        strMsgBox &= vbCrLf & "Recall order now?" & vbCrLf & "CAUTION: This will delete any items already in the order!"
                        intMsgBoxResult = MsgBox(strMsgBox, MsgBoxStyle.YesNo, "Previous Order")
                        If intMsgBoxResult = MsgBoxResult.Yes Then
                            GetCustomerPreviousOrder(CustID)
                            AddUpGridTotals()
                        End If
                    Else
                        Alert("No information found")
                    End If
                Else
                    Alert("Nothing to display. Recall a customer from the database then try again.")
                End If
            Else
                Alert("Nothing to display. Recall a customer from the database then try again.")
            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Function LNSNOnscreen() As String

        If GetAppSettingCS("LNSNOnscreen", "LN") = "LN" Then
            Return "DishName"
        Else
            Return "ShortName"
        End If

    End Function

    Public Sub AddModifier(strModString As String, decValue As Decimal)

        Try
            If ugdOrderGrid.ActiveRow Is Nothing OrElse String.IsNullOrEmpty(strModString) Then
                strMsgBox = "No dish row has been selected. Select a dish or turn off set-meal selection."
                EZMsgBox.Show(strMsgBox, MessageBoxButtons.OK)
                Return
            End If

            Dim intPosition As Short = ugdOrderGrid.ActiveRow.Index + 1

            ugdOrderGrid.SuspendLayout()
            DeActivateRow()

            Dim myRow As UltraDataRow = udsOrder.Rows.Insert(intPosition)
            myRow.Item("DCode") = ""
            myRow.Item("DName") = "- " & strModString
            myRow.Item("DPrice") = decValue
            myRow.Item("DQty") = String.Empty
            myRow.Item("Total") = fixCur(decValue)
            myRow.Item("Mods") = strIsModRow
            myRow.Item("Discountable") = DishInfo.Discountable
            myRow.Item("IsStarter") = DishInfo.IsStarter
            myRow.Item("OriPrice") = 0
            myRow.Item("PriceIn") = 0
            myRow.Item("PriceOut") = 0
            myRow.Item("GroupIndex") = ugdOrderGrid.ActiveRow.Cells("GroupIndex").Value
            myRow.Item("HiLite") = "0"

            ugdOrderGrid.DataSource = udsOrder
            ActivateRow()
            ugdOrderGrid.ResumeLayout()
            ugdOrderGrid.Refresh()

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub AddSetItem(strSetItemName As String, decValue As Decimal)

        Try
            If ugdOrderGrid.ActiveRow Is Nothing OrElse String.IsNullOrEmpty(strSetItemName) Then
                strMsgBox = "No dish row has been selected. Select a dish or turn off set-meal selection."
                EZMsgBox.Show(strMsgBox, MessageBoxButtons.OK)
                Return
            End If

            Dim intPosition As Short = ugdOrderGrid.ActiveRow.Index + 1

            ugdOrderGrid.SuspendLayout()
            DeActivateRow()

            Dim myRow As UltraDataRow = udsOrder.Rows.Insert(intPosition)
            myRow.Item("DCode") = ""
            myRow.Item("DName") = "- " & strSetItemName
            myRow.Item("DPrice") = decValue
            myRow.Item("DQty") = If(GetAppSettingCS("SetPutQty", True), "1", "")
            myRow.Item("Total") = fixCur(decValue)
            myRow.Item("Mods") = strIsSetItem
            myRow.Item("Discountable") = DishInfo.Discountable
            myRow.Item("IsStarter") = DishInfo.IsStarter
            myRow.Item("OriPrice") = 0
            myRow.Item("PriceIn") = 0
            myRow.Item("PriceOut") = 0
            myRow.Item("GroupIndex") = ugdOrderGrid.ActiveRow.Cells("GroupIndex").Value
            myRow.Item("HiLite") = "0"

            ugdOrderGrid.DataSource = udsOrder
            ActivateRow()

            ' Move to dish row if not already on it
            If Not RowIsNotModOrSet(intPosition) Then
                For iCnt As Short = intPosition - 1 To 0 Step -1
                    If RowIsNotModOrSet(iCnt) Then
                        ugdOrderGrid.ActiveRow = ugdOrderGrid.Rows(iCnt)
                        Exit For
                    End If
                Next
            End If

            ugdOrderGrid.ResumeLayout()
            ugdOrderGrid.Refresh()
        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Function DishRow()

        If (ugdOrderGrid.ActiveRow.Cells("Mods").Value <> strIsModRow) And (ugdOrderGrid.ActiveRow.Cells("Mods").Value <> strIsSetItem) Then
            Return ugdOrderGrid.ActiveRow
        End If

        Dim curIndex As Integer = ugdOrderGrid.ActiveRow.Index

        For iCnt As Short = curIndex - 1 To 0 Step -1
            If RowIsNotModOrSet(iCnt) Then Return ugdOrderGrid.Rows(iCnt)
        Next

        Return Nothing

    End Function

    Private Function GetDishRowValue(strColumnName)

        Dim tmpGridRow As UltraGridRow = DishRow()

        If tmpGridRow IsNot Nothing Then
            Return tmpGridRow.Cells(strColumnName).Value.ToString
        Else
            Return Nothing
        End If

    End Function

    Private Sub cmdGroupUp_Click(sender As Object, e As EventArgs) Handles cmdGroupUp.Click

        Dim a = pnlGroup.Top + (pnlGroupMain.Height * 0.7)

        If a >= 0 Then a = 0
        pnlGroup.Top = a

    End Sub

    Private Sub cmdGroupDown_Click(sender As Object, e As EventArgs) Handles cmdGroupDown.Click

        Dim b = pnlGroupMain.Height - pnlGroup.Height + 3
        Dim a = pnlGroup.Top - (pnlGroupMain.Height * 0.7)

        If (a - b) < 0 Then a = b
        pnlGroup.Top = a

    End Sub

    Public Sub ModRowAction(strAction As String)

        Dim blnCheckForMore As Boolean = False

        If strAction = "DelModRow" Then
            ugdOrderGrid.ActiveRow.Delete(False)
        Else
            If DishRow() IsNot Nothing Then
                Dim intRowIndex = DishRow.Index + 1

                Do
                    blnCheckForMore = False
                    If intRowIndex < ugdOrderGrid.Rows.Count AndAlso ugdOrderGrid.Rows(intRowIndex).Cells("Mods").Value = strIsModRow Then
                        ugdOrderGrid.Rows(intRowIndex).Cells("Total").Value = GetDishRowValue("DQty") * ugdOrderGrid.Rows(intRowIndex).Cells("DPrice").Value
                        intRowIndex += 1
                        blnCheckForMore = True
                    End If
                Loop While blnCheckForMore

            End If
        End If

    End Sub

    Private Sub cmdSetMeals_Click(sender As Object, e As EventArgs) Handles cmdSetMeals.Click

        Dim blnResetButton As Boolean = False

        If ugdOrderGrid.ActiveRow IsNot Nothing Then
            If blnSetMode = True Then
                blnResetButton = True
            ElseIf RowIsNotModOrSet(ugdOrderGrid.ActiveRow.Index) Then
                blnResetButton = True
            Else
                strMsgBox = "This option is not allowed on the selected item."
                Alert(strMsgBox)
            End If
        Else
            blnResetButton = False
            strMsgBox = "Set items can only be added to a set. Select a set first, then add items to it."
            Alert(strMsgBox)
        End If

        If blnResetButton = True Then
            If cmdSetMeals.Appearance.BackColor = Color.Transparent Then
                cmdSetMeals.Appearance.BackColor = Color.Green
                cmdSetMeals.Appearance.BackColor2 = Color.LimeGreen
                blnSetMode = True
            Else
                cmdSetMeals.Appearance.BackColor = Color.Transparent
                cmdSetMeals.Appearance.BackColor2 = Color.Transparent
                blnSetMode = False
            End If
            cmdEditDish.Enabled = Not blnSetMode
        End If

    End Sub

    Private Function UpdateSetItemInGrid(strDishToUpgrade As String) As Boolean
        'returns True if strDishToUpgrade found in grid and updated

        Dim tmpStr As String = String.Empty
        Dim blnCheckForMore As Boolean
        Dim intDishRow, intRowIndex As Short

        Try

            'first move to dish row if not already on it
            If RowIsNotModOrSet(ugdOrderGrid.ActiveRow.Index) Then
                intDishRow = ugdOrderGrid.ActiveRow.Index
            Else
                For iCnt As Short = ugdOrderGrid.ActiveRow.Index - 1 To 0 Step -1
                    If RowIsNotModOrSet(iCnt) Then intDishRow = iCnt
                Next
            End If

            intRowIndex = intDishRow

            Do
                blnCheckForMore = False
                If intRowIndex + 1 < ugdOrderGrid.Rows.Count AndAlso ugdOrderGrid.Rows(intRowIndex + 1).Cells("Mods").Value = strIsSetItem Then
                    tmpStr = ugdOrderGrid.Rows(intRowIndex + 1).Cells("DName").Value.ToString().Trim
                    If tmpStr.Substring(0, 2) = "- " Then tmpStr = tmpStr.Substring(2)
                    If strDishToUpgrade.ToUpper = tmpStr.ToUpper Then
                        If GetAppSettingCS("SetPutQty", False) = False Then
                            strMsgBox = "This item is already selected"
                            EZMsgBox.Show(strMsgBox, MessageBoxButtons.OK)
                        Else
                            With ugdOrderGrid
                                .Rows(intRowIndex + 1).Cells("DQty").Value = .Rows(intRowIndex + 1).Cells("DQty").Value + intDQty
                                .Rows(intRowIndex + 1).Cells("Total").Value = fixCur(.Rows(intRowIndex + 1).Cells("DPrice").Value * .Rows(intRowIndex + 1).Cells("DQty").Value)
                                .Update()
                                .Rows(intDishRow).Activate()
                            End With
                        End If
                        Return True
                    Else
                        intRowIndex += 1
                        blnCheckForMore = True
                    End If
                End If
            Loop While blnCheckForMore

        Catch ex As Exception
            DisplayError(ex)
        End Try

        Return False

    End Function

    Private Sub cmdCuisine_Click(sender As Object, e As EventArgs) Handles cmdCuisine.Click

        Dim cuisines As List(Of CuisineModel) = dishRepo.GetCuisines()

        If cuisines IsNot Nothing AndAlso cuisines.Count > 0 Then

            Dim CuisineList As New List(Of String)()

            For Each cuisine As CuisineModel In cuisines
                CuisineList.Add(cuisine.Name)
            Next

            Dim strResponse As String = CustomList.Show(CuisineList, True)

            If strResponse <> strCustomListBoxCancelString Then
                cmdCuisine.Text = strResponse
                SaveAppSetting("MultiCuisinesDefault", strResponse)
                If cmdTypical.Text = "Typical" Then cmdTypical.Text = "Menu"
                pnlDishes.ClientArea.Controls.Clear()
                pnlGroup.ClientArea.Controls.Clear()
                CreateGroupButtons("Menu")
                cmdTypical.Text = "Typical"
                SQLQuery = $"SELECT ID FROM Cuisine WHERE CuisineName = '{ strResponse }'"
                drcDatarowCollection = objDB.GetDataRows(SQLQuery)
                If drcDatarowCollection IsNot Nothing AndAlso drcDatarowCollection.Count > 0 Then
                    intCurrentCuisine = drcDatarowCollection(0)("ID")
                Else
                    intCurrentCuisine = 1
                End If
            End If
        Else
            strMyDishName = "There are no cuisines specified"
            Alert(strMsgBox)
        End If

    End Sub

    Public Sub UpdateRowPrice(ugrRow As UltraGridRow)

        Try
            With ugrRow
                .Cells("Total").Value = .Cells("DPrice").Value * .Cells("DQty").Value
            End With
        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub SetButtonAttributes(ByRef btnButton As UltraButton)

        With btnButton
            .ShowFocusRect = False
            .ShowOutline = False
            .UseAppStyling = True
            .UseMnemonic = False
            .UseHotTracking = DefaultableBoolean.True
            .UseOsThemes = DefaultableBoolean.False
            .UseFlatMode = DefaultableBoolean.True
        End With

    End Sub

    Private Sub lblDrinksOE_TextChanged(sender As Object, e As EventArgs) Handles lblDrinksOE.TextChanged
        uplSDrinks.Visible = Decimal.Parse(lblDrinksOE.Text) <> 0
        AdjustSummaries()
    End Sub

    Private Sub lblDiscount_TextChanged(sender As Object, e As EventArgs) Handles lblPriceAdjDiscounts.TextChanged
        Dim blnVisible As Boolean = Not Decimal.Parse(lblPriceAdjDiscounts.Text) = 0
        lblPriceAdjDiscounts.Visible = blnVisible
        lblPriceAdjDiscountsLbl.Visible = blnVisible
        uplSDiscounts.Visible = blnVisible
        AdjustSummaries()
    End Sub

    Private Sub lblCharges_TextChanged(sender As Object, e As EventArgs) Handles lblPriceAdjCharges.TextChanged
        Dim blnVisible As Boolean = Not Decimal.Parse(lblPriceAdjCharges.Text) = 0
        lblPriceAdjCharges.Visible = blnVisible
        lblPriceAdjChargesLbl.Visible = blnVisible
        uplSCharges.Visible = blnVisible
        AdjustSummaries()
    End Sub

    Private Sub lblGDiscounts_TextChanged(sender As Object, e As EventArgs) Handles lblGDiscounts.TextChanged
        lblGDiscounts.Visible = Decimal.Parse(lblGDiscounts.Text) <> 0
        uplSGDiscounts.Visible = Decimal.Parse(lblGDiscounts.Text) <> 0
        AdjustSummaries()
    End Sub

    Private Sub lblGCharges_TextChanged(sender As Object, e As EventArgs) Handles lblGCharges.TextChanged
        lblGCharges.Visible = Decimal.Parse(lblGCharges.Text) <> 0
        uplSGCharges.Visible = Decimal.Parse(lblGCharges.Text) <> 0
        AdjustSummaries()
    End Sub

    Private Sub AdjustSummaries()
        uplSSubtotal.Visible = uplSDrinks.Visible Or uplSCharges.Visible Or uplSDiscounts.Visible Or
                                    uplSGCharges.Visible Or uplSGDiscounts.Visible
    End Sub

End Class