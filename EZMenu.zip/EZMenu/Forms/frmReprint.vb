﻿Imports EZMenu.Core.Enums

Public Class frmReprint

    Private _orderType As OrderTypeEnum
    Private _orderId As Integer

    Public Sub New(orderType As OrderTypeEnum, orderId As Integer)

        InitializeComponent()

        CenterToScreen()

        _orderType = orderType
        _orderId = orderId

    End Sub

    Private Sub ShopKitchenBoth(sender As Object, e As EventArgs) Handles cmdShopCopy.Click, cmdKitchenCopy.Click, cmdBothCopies.Click

        'note current cuisine
        Dim intExCuisine As Short = intCurrentCuisine
        Dim printDest As PrintDestinationEnum

        intCurrentCuisine = 1

        If sender Is cmdShopCopy Then
            printDest = PrintDestinationEnum.Shop
        ElseIf sender Is cmdKitchenCopy Then
            printDest = PrintDestinationEnum.Kitchen
        ElseIf sender Is cmdBothCopies Then
            printDest = PrintDestinationEnum.Both
        End If

        If _orderType = OrderTypeEnum.Table Then
            PrintTable(_orderId, printDest)
        Else
            PrintOrder(_orderId, printDest)
        End If

        'reset current cuisine
        intCurrentCuisine = intExCuisine

        Close()

    End Sub

    Private Sub cmdClose_Click(sender As Object, e As EventArgs) Handles cmdClose.Click
        Close()
    End Sub



    'Declare the variables
    Dim drag As Boolean
    Dim mousex As Integer
    Dim mousey As Integer
    Private orderType As OrderTypeEnum

    Private Sub Form1_MouseDown(sender As Object, e As MouseEventArgs) Handles Me.MouseDown
        drag = True 'Sets the variable drag to true.
        mousex = Cursor.Position.X - Left 'Sets variable mousex
        mousey = Cursor.Position.Y - Top 'Sets variable mousey
    End Sub

    Private Sub Form1_MouseMove(sender As Object, e As MouseEventArgs) Handles Me.MouseMove
        'If drag is set to true then move the form accordingly.
        If drag Then
            Top = Cursor.Position.Y - mousey
            Left = Cursor.Position.X - mousex
        End If
    End Sub

    Private Sub Form1_MouseUp(sender As Object, e As MouseEventArgs) Handles Me.MouseUp
        drag = False 'Sets drag to false, so the form does not move according to the code in MouseMove
    End Sub

End Class