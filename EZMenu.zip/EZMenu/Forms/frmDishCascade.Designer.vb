﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDishCascade
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim Appearance1 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmDishCascade))
        Dim Appearance2 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance3 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance4 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance5 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance6 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance7 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance8 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance9 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance10 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance11 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance12 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance13 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance14 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance15 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance16 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance17 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance18 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance19 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance20 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance21 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance22 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance23 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance24 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance25 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance26 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance27 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance28 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance29 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance30 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance31 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance32 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance33 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance34 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance35 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance36 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance37 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance38 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance39 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance40 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance41 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance42 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance43 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance44 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance45 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance46 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance47 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance48 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance49 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance50 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance51 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance52 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance53 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance54 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance55 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance56 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance57 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance58 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance59 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance60 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance61 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance62 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance63 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance64 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance65 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance66 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance67 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance68 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance69 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance70 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance71 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance72 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance73 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance74 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance75 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance76 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance77 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance78 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance79 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance80 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance81 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance82 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance83 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance84 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance85 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance86 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance87 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance88 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance89 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance90 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance91 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance92 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance93 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance94 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance95 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance96 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance97 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance98 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance99 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance100 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance101 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance102 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance103 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance104 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance105 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance106 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance107 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance108 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance109 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance110 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance111 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance112 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance113 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance114 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance115 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance116 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance117 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance118 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance119 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance120 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance121 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance122 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance123 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance124 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance125 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance126 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance127 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance128 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance129 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance130 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance131 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance132 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance133 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance134 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance135 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance136 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance137 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance138 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance139 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance140 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance141 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance142 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance143 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance144 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance145 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance146 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance147 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance148 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance149 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance150 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance151 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance152 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance153 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance154 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance155 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance156 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance157 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance158 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance159 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance160 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance161 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance162 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance163 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance164 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance165 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance166 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance167 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance168 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance169 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance170 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance171 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance172 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance173 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance174 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance175 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance176 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance177 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance178 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance179 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance180 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance181 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance182 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance183 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance184 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance185 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance186 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance187 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance188 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance189 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance190 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance191 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance192 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance193 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance194 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance195 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance196 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance197 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance198 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance199 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance200 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance201 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance202 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance203 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance204 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance205 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance206 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance207 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance208 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance209 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance210 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance211 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance212 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance213 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance214 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance215 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance216 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance217 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance218 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance219 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance220 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance221 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance222 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance223 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance224 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance225 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance226 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance227 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance228 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance229 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance230 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance231 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance232 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance233 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance234 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Me.txtName1 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.cmdOK = New Infragistics.Win.Misc.UltraButton()
        Me.cmdClose = New Infragistics.Win.Misc.UltraButton()
        Me.txtName2 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtName3 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtName4 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtName5 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtName6 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtName7 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtName9 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtName8 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtPriceIn9 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtPriceIn8 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtPriceIn7 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtPriceIn6 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtPriceIn5 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtPriceIn4 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtPriceIn3 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtPriceIn2 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtPriceIn1 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.cmdPrice1 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdPrice2 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdPrice4 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdPrice3 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdPrice8 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdPrice7 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdPrice6 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdPrice5 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdPrice9 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdSwapName = New Infragistics.Win.Misc.UltraButton()
        Me.cmdPriceOut9 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdPriceOut8 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdPriceOut7 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdPriceOut6 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdPriceOut5 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdPriceOut4 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdPriceOut3 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdPriceOut2 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdPriceOut1 = New Infragistics.Win.Misc.UltraButton()
        Me.txtPriceOut9 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtPriceOut8 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtPriceOut7 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtPriceOut6 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtPriceOut5 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtPriceOut4 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtPriceOut3 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtPriceOut2 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtPriceOut1 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.cmdKB9 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdKB8 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdKB7 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdKB6 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdKB5 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdKB4 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdKB3 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdKB2 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdKB1 = New Infragistics.Win.Misc.UltraButton()
        Me.txtShortCode9 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtShortCode8 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtShortCode7 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtShortCode6 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtShortCode5 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtShortCode4 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtShortCode3 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtShortCode2 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtShortCode1 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.cmdDelSC9 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDelSC8 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDelSC7 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDelSC6 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDelSC5 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDelSC4 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDelSC3 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDelSC2 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDelSC1 = New Infragistics.Win.Misc.UltraButton()
        Me.lblCuisine = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblDCHeader = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.cmdDelSN9 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDelSN8 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDelSN7 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDelSN6 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDelSN5 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDelSN4 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDelSN3 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDelSN2 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDelSN1 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdKBSN9 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdKBSN8 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdKBSN7 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdKBSN6 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdKBSN5 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdKBSN4 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdKBSN3 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdKBSN2 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdKBSN1 = New Infragistics.Win.Misc.UltraButton()
        Me.txtShortName9 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtShortName8 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtShortName7 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtShortName6 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtShortName5 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtShortName4 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtShortName3 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtShortName2 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtShortName1 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.cmdKBName9 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdKBName8 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdKBName7 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdKBName6 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdKBName5 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdKBName4 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdKBName3 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdKBName2 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdKBName1 = New Infragistics.Win.Misc.UltraButton()
        CType(Me.txtName1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtName2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtName3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtName4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtName5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtName6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtName7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtName9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtName8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtPriceIn9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtPriceIn8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtPriceIn7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtPriceIn6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtPriceIn5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtPriceIn4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtPriceIn3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtPriceIn2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtPriceIn1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtPriceOut9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtPriceOut8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtPriceOut7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtPriceOut6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtPriceOut5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtPriceOut4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtPriceOut3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtPriceOut2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtPriceOut1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtShortCode9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtShortCode8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtShortCode7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtShortCode6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtShortCode5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtShortCode4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtShortCode3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtShortCode2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtShortCode1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtShortName9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtShortName8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtShortName7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtShortName6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtShortName5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtShortName4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtShortName3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtShortName2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtShortName1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtName1
        '
        Me.txtName1.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName1.Location = New System.Drawing.Point(19, 87)
        Me.txtName1.MaxLength = 50
        Me.txtName1.Name = "txtName1"
        Me.txtName1.Size = New System.Drawing.Size(236, 26)
        Me.txtName1.TabIndex = 536
        Me.txtName1.Tag = ""
        Me.txtName1.Text = "Chicken"
        Me.txtName1.UseAppStyling = False
        '
        'cmdOK
        '
        Me.cmdOK.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance1.BackColor = System.Drawing.Color.Transparent
        Appearance1.BackColor2 = System.Drawing.Color.Transparent
        Appearance1.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance1.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance1.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance1.BorderColor2 = System.Drawing.Color.Maroon
        Appearance1.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance1.ForeColor = System.Drawing.Color.Black
        Appearance1.Image = CType(resources.GetObject("Appearance1.Image"), Object)
        Appearance1.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance1.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance1.TextVAlignAsString = "Bottom"
        Me.cmdOK.Appearance = Appearance1
        Me.cmdOK.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdOK.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance2.BackColor = System.Drawing.Color.DarkOrange
        Appearance2.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance2.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance2.ForeColor = System.Drawing.Color.Black
        Me.cmdOK.HotTrackAppearance = Appearance2
        Me.cmdOK.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdOK.Location = New System.Drawing.Point(804, 478)
        Me.cmdOK.Name = "cmdOK"
        Appearance3.BackColor = System.Drawing.Color.OrangeRed
        Appearance3.BackColor2 = System.Drawing.Color.Tomato
        Appearance3.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdOK.PressedAppearance = Appearance3
        Me.cmdOK.ShowFocusRect = False
        Me.cmdOK.ShowOutline = False
        Me.cmdOK.Size = New System.Drawing.Size(64, 44)
        Me.cmdOK.StyleSetName = "StatusBar"
        Me.cmdOK.TabIndex = 534
        Me.cmdOK.Tag = "OK"
        Me.cmdOK.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOK.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOK.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdClose
        '
        Me.cmdClose.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance4.BackColor = System.Drawing.Color.Transparent
        Appearance4.BackColor2 = System.Drawing.Color.Transparent
        Appearance4.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance4.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance4.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance4.BorderColor2 = System.Drawing.Color.Maroon
        Appearance4.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance4.ForeColor = System.Drawing.Color.Black
        Appearance4.Image = CType(resources.GetObject("Appearance4.Image"), Object)
        Appearance4.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance4.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance4.TextVAlignAsString = "Bottom"
        Me.cmdClose.Appearance = Appearance4
        Me.cmdClose.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdClose.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance5.BackColor = System.Drawing.Color.DarkOrange
        Appearance5.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance5.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance5.ForeColor = System.Drawing.Color.Black
        Me.cmdClose.HotTrackAppearance = Appearance5
        Me.cmdClose.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdClose.Location = New System.Drawing.Point(874, 478)
        Me.cmdClose.Name = "cmdClose"
        Appearance6.BackColor = System.Drawing.Color.OrangeRed
        Appearance6.BackColor2 = System.Drawing.Color.Tomato
        Appearance6.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdClose.PressedAppearance = Appearance6
        Me.cmdClose.ShowFocusRect = False
        Me.cmdClose.ShowOutline = False
        Me.cmdClose.Size = New System.Drawing.Size(64, 44)
        Me.cmdClose.StyleSetName = "StatusBar"
        Me.cmdClose.TabIndex = 535
        Me.cmdClose.Tag = "Back"
        Me.cmdClose.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdClose.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdClose.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtName2
        '
        Me.txtName2.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName2.Location = New System.Drawing.Point(19, 124)
        Me.txtName2.MaxLength = 50
        Me.txtName2.Name = "txtName2"
        Me.txtName2.Size = New System.Drawing.Size(236, 26)
        Me.txtName2.TabIndex = 537
        Me.txtName2.Text = "Chicken Tikka"
        Me.txtName2.UseAppStyling = False
        '
        'txtName3
        '
        Me.txtName3.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName3.Location = New System.Drawing.Point(19, 161)
        Me.txtName3.MaxLength = 50
        Me.txtName3.Name = "txtName3"
        Me.txtName3.Size = New System.Drawing.Size(236, 26)
        Me.txtName3.TabIndex = 538
        Me.txtName3.Text = "Lamb"
        Me.txtName3.UseAppStyling = False
        '
        'txtName4
        '
        Me.txtName4.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName4.Location = New System.Drawing.Point(19, 198)
        Me.txtName4.MaxLength = 50
        Me.txtName4.Name = "txtName4"
        Me.txtName4.Size = New System.Drawing.Size(236, 26)
        Me.txtName4.TabIndex = 539
        Me.txtName4.Text = "Lamb Tikka"
        Me.txtName4.UseAppStyling = False
        '
        'txtName5
        '
        Me.txtName5.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName5.Location = New System.Drawing.Point(19, 235)
        Me.txtName5.MaxLength = 50
        Me.txtName5.Name = "txtName5"
        Me.txtName5.Size = New System.Drawing.Size(236, 26)
        Me.txtName5.TabIndex = 540
        Me.txtName5.Text = "Prawn"
        Me.txtName5.UseAppStyling = False
        '
        'txtName6
        '
        Me.txtName6.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName6.Location = New System.Drawing.Point(19, 272)
        Me.txtName6.MaxLength = 50
        Me.txtName6.Name = "txtName6"
        Me.txtName6.Size = New System.Drawing.Size(236, 26)
        Me.txtName6.TabIndex = 541
        Me.txtName6.Text = "King Prawn"
        Me.txtName6.UseAppStyling = False
        '
        'txtName7
        '
        Me.txtName7.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName7.Location = New System.Drawing.Point(19, 309)
        Me.txtName7.MaxLength = 50
        Me.txtName7.Name = "txtName7"
        Me.txtName7.Size = New System.Drawing.Size(236, 26)
        Me.txtName7.TabIndex = 542
        Me.txtName7.Text = "Vegetable"
        Me.txtName7.UseAppStyling = False
        '
        'txtName9
        '
        Me.txtName9.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName9.Location = New System.Drawing.Point(19, 383)
        Me.txtName9.MaxLength = 50
        Me.txtName9.Name = "txtName9"
        Me.txtName9.Size = New System.Drawing.Size(236, 26)
        Me.txtName9.TabIndex = 544
        Me.txtName9.UseAppStyling = False
        '
        'txtName8
        '
        Me.txtName8.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName8.Location = New System.Drawing.Point(19, 346)
        Me.txtName8.MaxLength = 50
        Me.txtName8.Name = "txtName8"
        Me.txtName8.Size = New System.Drawing.Size(236, 26)
        Me.txtName8.TabIndex = 543
        Me.txtName8.UseAppStyling = False
        '
        'txtPriceIn9
        '
        Appearance7.TextHAlignAsString = "Right"
        Me.txtPriceIn9.Appearance = Appearance7
        Me.txtPriceIn9.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPriceIn9.Location = New System.Drawing.Point(315, 383)
        Me.txtPriceIn9.MaxLength = 50
        Me.txtPriceIn9.Name = "txtPriceIn9"
        Me.txtPriceIn9.Size = New System.Drawing.Size(55, 26)
        Me.txtPriceIn9.TabIndex = 553
        Me.txtPriceIn9.UseAppStyling = False
        '
        'txtPriceIn8
        '
        Appearance8.TextHAlignAsString = "Right"
        Me.txtPriceIn8.Appearance = Appearance8
        Me.txtPriceIn8.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPriceIn8.Location = New System.Drawing.Point(315, 346)
        Me.txtPriceIn8.MaxLength = 50
        Me.txtPriceIn8.Name = "txtPriceIn8"
        Me.txtPriceIn8.Size = New System.Drawing.Size(55, 26)
        Me.txtPriceIn8.TabIndex = 552
        Me.txtPriceIn8.UseAppStyling = False
        '
        'txtPriceIn7
        '
        Appearance9.TextHAlignAsString = "Right"
        Me.txtPriceIn7.Appearance = Appearance9
        Me.txtPriceIn7.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPriceIn7.Location = New System.Drawing.Point(315, 309)
        Me.txtPriceIn7.MaxLength = 50
        Me.txtPriceIn7.Name = "txtPriceIn7"
        Me.txtPriceIn7.Size = New System.Drawing.Size(55, 26)
        Me.txtPriceIn7.TabIndex = 551
        Me.txtPriceIn7.UseAppStyling = False
        '
        'txtPriceIn6
        '
        Appearance10.TextHAlignAsString = "Right"
        Me.txtPriceIn6.Appearance = Appearance10
        Me.txtPriceIn6.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPriceIn6.Location = New System.Drawing.Point(315, 272)
        Me.txtPriceIn6.MaxLength = 50
        Me.txtPriceIn6.Name = "txtPriceIn6"
        Me.txtPriceIn6.Size = New System.Drawing.Size(55, 26)
        Me.txtPriceIn6.TabIndex = 550
        Me.txtPriceIn6.UseAppStyling = False
        '
        'txtPriceIn5
        '
        Appearance11.TextHAlignAsString = "Right"
        Me.txtPriceIn5.Appearance = Appearance11
        Me.txtPriceIn5.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPriceIn5.Location = New System.Drawing.Point(315, 235)
        Me.txtPriceIn5.MaxLength = 50
        Me.txtPriceIn5.Name = "txtPriceIn5"
        Me.txtPriceIn5.Size = New System.Drawing.Size(55, 26)
        Me.txtPriceIn5.TabIndex = 549
        Me.txtPriceIn5.UseAppStyling = False
        '
        'txtPriceIn4
        '
        Appearance12.TextHAlignAsString = "Right"
        Me.txtPriceIn4.Appearance = Appearance12
        Me.txtPriceIn4.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPriceIn4.Location = New System.Drawing.Point(315, 198)
        Me.txtPriceIn4.MaxLength = 50
        Me.txtPriceIn4.Name = "txtPriceIn4"
        Me.txtPriceIn4.Size = New System.Drawing.Size(55, 26)
        Me.txtPriceIn4.TabIndex = 548
        Me.txtPriceIn4.UseAppStyling = False
        '
        'txtPriceIn3
        '
        Appearance13.TextHAlignAsString = "Right"
        Me.txtPriceIn3.Appearance = Appearance13
        Me.txtPriceIn3.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPriceIn3.Location = New System.Drawing.Point(315, 161)
        Me.txtPriceIn3.MaxLength = 50
        Me.txtPriceIn3.Name = "txtPriceIn3"
        Me.txtPriceIn3.Size = New System.Drawing.Size(55, 26)
        Me.txtPriceIn3.TabIndex = 547
        Me.txtPriceIn3.UseAppStyling = False
        '
        'txtPriceIn2
        '
        Appearance14.TextHAlignAsString = "Right"
        Me.txtPriceIn2.Appearance = Appearance14
        Me.txtPriceIn2.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPriceIn2.Location = New System.Drawing.Point(315, 124)
        Me.txtPriceIn2.MaxLength = 50
        Me.txtPriceIn2.Name = "txtPriceIn2"
        Me.txtPriceIn2.Size = New System.Drawing.Size(55, 26)
        Me.txtPriceIn2.TabIndex = 546
        Me.txtPriceIn2.UseAppStyling = False
        '
        'txtPriceIn1
        '
        Appearance15.TextHAlignAsString = "Right"
        Me.txtPriceIn1.Appearance = Appearance15
        Me.txtPriceIn1.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPriceIn1.Location = New System.Drawing.Point(315, 87)
        Me.txtPriceIn1.MaxLength = 50
        Me.txtPriceIn1.Name = "txtPriceIn1"
        Me.txtPriceIn1.Size = New System.Drawing.Size(55, 26)
        Me.txtPriceIn1.TabIndex = 545
        Me.txtPriceIn1.UseAppStyling = False
        '
        'cmdPrice1
        '
        Appearance16.BackColor = System.Drawing.Color.Transparent
        Appearance16.BackColor2 = System.Drawing.Color.Transparent
        Appearance16.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance16.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance16.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance16.ForeColor = System.Drawing.Color.Black
        Appearance16.Image = CType(resources.GetObject("Appearance16.Image"), Object)
        Appearance16.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance16.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance16.TextVAlignAsString = "Bottom"
        Me.cmdPrice1.Appearance = Appearance16
        Me.cmdPrice1.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance17.BackColor = System.Drawing.Color.DarkOrange
        Appearance17.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance17.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance17.ForeColor = System.Drawing.Color.Black
        Me.cmdPrice1.HotTrackAppearance = Appearance17
        Me.cmdPrice1.ImageSize = New System.Drawing.Size(24, 24)
        Me.cmdPrice1.Location = New System.Drawing.Point(376, 85)
        Me.cmdPrice1.Name = "cmdPrice1"
        Appearance18.BackColor = System.Drawing.Color.OrangeRed
        Appearance18.BackColor2 = System.Drawing.Color.Tomato
        Appearance18.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdPrice1.PressedAppearance = Appearance18
        Me.cmdPrice1.ShowFocusRect = False
        Me.cmdPrice1.ShowOutline = False
        Me.cmdPrice1.Size = New System.Drawing.Size(48, 31)
        Me.cmdPrice1.TabIndex = 554
        Me.cmdPrice1.Tag = "Back"
        Me.cmdPrice1.UseAppStyling = False
        Me.cmdPrice1.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPrice1.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPrice1.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdPrice2
        '
        Appearance19.BackColor = System.Drawing.Color.Transparent
        Appearance19.BackColor2 = System.Drawing.Color.Transparent
        Appearance19.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance19.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance19.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance19.ForeColor = System.Drawing.Color.Black
        Appearance19.Image = CType(resources.GetObject("Appearance19.Image"), Object)
        Appearance19.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance19.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance19.TextVAlignAsString = "Bottom"
        Me.cmdPrice2.Appearance = Appearance19
        Me.cmdPrice2.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance20.BackColor = System.Drawing.Color.DarkOrange
        Appearance20.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance20.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance20.ForeColor = System.Drawing.Color.Black
        Me.cmdPrice2.HotTrackAppearance = Appearance20
        Me.cmdPrice2.ImageSize = New System.Drawing.Size(24, 24)
        Me.cmdPrice2.Location = New System.Drawing.Point(376, 122)
        Me.cmdPrice2.Name = "cmdPrice2"
        Appearance21.BackColor = System.Drawing.Color.OrangeRed
        Appearance21.BackColor2 = System.Drawing.Color.Tomato
        Appearance21.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdPrice2.PressedAppearance = Appearance21
        Me.cmdPrice2.ShowFocusRect = False
        Me.cmdPrice2.ShowOutline = False
        Me.cmdPrice2.Size = New System.Drawing.Size(48, 31)
        Me.cmdPrice2.TabIndex = 555
        Me.cmdPrice2.Tag = "Back"
        Me.cmdPrice2.UseAppStyling = False
        Me.cmdPrice2.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPrice2.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPrice2.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdPrice4
        '
        Appearance22.BackColor = System.Drawing.Color.Transparent
        Appearance22.BackColor2 = System.Drawing.Color.Transparent
        Appearance22.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance22.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance22.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance22.ForeColor = System.Drawing.Color.Black
        Appearance22.Image = CType(resources.GetObject("Appearance22.Image"), Object)
        Appearance22.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance22.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance22.TextVAlignAsString = "Bottom"
        Me.cmdPrice4.Appearance = Appearance22
        Me.cmdPrice4.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance23.BackColor = System.Drawing.Color.DarkOrange
        Appearance23.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance23.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance23.ForeColor = System.Drawing.Color.Black
        Me.cmdPrice4.HotTrackAppearance = Appearance23
        Me.cmdPrice4.ImageSize = New System.Drawing.Size(24, 24)
        Me.cmdPrice4.Location = New System.Drawing.Point(376, 196)
        Me.cmdPrice4.Name = "cmdPrice4"
        Appearance24.BackColor = System.Drawing.Color.OrangeRed
        Appearance24.BackColor2 = System.Drawing.Color.Tomato
        Appearance24.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdPrice4.PressedAppearance = Appearance24
        Me.cmdPrice4.ShowFocusRect = False
        Me.cmdPrice4.ShowOutline = False
        Me.cmdPrice4.Size = New System.Drawing.Size(48, 31)
        Me.cmdPrice4.TabIndex = 557
        Me.cmdPrice4.Tag = "Back"
        Me.cmdPrice4.UseAppStyling = False
        Me.cmdPrice4.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPrice4.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPrice4.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdPrice3
        '
        Appearance25.BackColor = System.Drawing.Color.Transparent
        Appearance25.BackColor2 = System.Drawing.Color.Transparent
        Appearance25.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance25.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance25.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance25.ForeColor = System.Drawing.Color.Black
        Appearance25.Image = CType(resources.GetObject("Appearance25.Image"), Object)
        Appearance25.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance25.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance25.TextVAlignAsString = "Bottom"
        Me.cmdPrice3.Appearance = Appearance25
        Me.cmdPrice3.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance26.BackColor = System.Drawing.Color.DarkOrange
        Appearance26.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance26.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance26.ForeColor = System.Drawing.Color.Black
        Me.cmdPrice3.HotTrackAppearance = Appearance26
        Me.cmdPrice3.ImageSize = New System.Drawing.Size(24, 24)
        Me.cmdPrice3.Location = New System.Drawing.Point(376, 159)
        Me.cmdPrice3.Name = "cmdPrice3"
        Appearance27.BackColor = System.Drawing.Color.OrangeRed
        Appearance27.BackColor2 = System.Drawing.Color.Tomato
        Appearance27.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdPrice3.PressedAppearance = Appearance27
        Me.cmdPrice3.ShowFocusRect = False
        Me.cmdPrice3.ShowOutline = False
        Me.cmdPrice3.Size = New System.Drawing.Size(48, 31)
        Me.cmdPrice3.TabIndex = 556
        Me.cmdPrice3.Tag = "Back"
        Me.cmdPrice3.UseAppStyling = False
        Me.cmdPrice3.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPrice3.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPrice3.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdPrice8
        '
        Appearance28.BackColor = System.Drawing.Color.Transparent
        Appearance28.BackColor2 = System.Drawing.Color.Transparent
        Appearance28.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance28.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance28.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance28.ForeColor = System.Drawing.Color.Black
        Appearance28.Image = CType(resources.GetObject("Appearance28.Image"), Object)
        Appearance28.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance28.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance28.TextVAlignAsString = "Bottom"
        Me.cmdPrice8.Appearance = Appearance28
        Me.cmdPrice8.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance29.BackColor = System.Drawing.Color.DarkOrange
        Appearance29.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance29.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance29.ForeColor = System.Drawing.Color.Black
        Me.cmdPrice8.HotTrackAppearance = Appearance29
        Me.cmdPrice8.ImageSize = New System.Drawing.Size(24, 24)
        Me.cmdPrice8.Location = New System.Drawing.Point(376, 344)
        Me.cmdPrice8.Name = "cmdPrice8"
        Appearance30.BackColor = System.Drawing.Color.OrangeRed
        Appearance30.BackColor2 = System.Drawing.Color.Tomato
        Appearance30.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdPrice8.PressedAppearance = Appearance30
        Me.cmdPrice8.ShowFocusRect = False
        Me.cmdPrice8.ShowOutline = False
        Me.cmdPrice8.Size = New System.Drawing.Size(48, 31)
        Me.cmdPrice8.TabIndex = 561
        Me.cmdPrice8.Tag = "Back"
        Me.cmdPrice8.UseAppStyling = False
        Me.cmdPrice8.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPrice8.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPrice8.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdPrice7
        '
        Appearance31.BackColor = System.Drawing.Color.Transparent
        Appearance31.BackColor2 = System.Drawing.Color.Transparent
        Appearance31.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance31.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance31.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance31.ForeColor = System.Drawing.Color.Black
        Appearance31.Image = CType(resources.GetObject("Appearance31.Image"), Object)
        Appearance31.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance31.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance31.TextVAlignAsString = "Bottom"
        Me.cmdPrice7.Appearance = Appearance31
        Me.cmdPrice7.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance32.BackColor = System.Drawing.Color.DarkOrange
        Appearance32.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance32.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance32.ForeColor = System.Drawing.Color.Black
        Me.cmdPrice7.HotTrackAppearance = Appearance32
        Me.cmdPrice7.ImageSize = New System.Drawing.Size(24, 24)
        Me.cmdPrice7.Location = New System.Drawing.Point(376, 307)
        Me.cmdPrice7.Name = "cmdPrice7"
        Appearance33.BackColor = System.Drawing.Color.OrangeRed
        Appearance33.BackColor2 = System.Drawing.Color.Tomato
        Appearance33.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdPrice7.PressedAppearance = Appearance33
        Me.cmdPrice7.ShowFocusRect = False
        Me.cmdPrice7.ShowOutline = False
        Me.cmdPrice7.Size = New System.Drawing.Size(48, 31)
        Me.cmdPrice7.TabIndex = 560
        Me.cmdPrice7.Tag = "Back"
        Me.cmdPrice7.UseAppStyling = False
        Me.cmdPrice7.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPrice7.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPrice7.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdPrice6
        '
        Appearance34.BackColor = System.Drawing.Color.Transparent
        Appearance34.BackColor2 = System.Drawing.Color.Transparent
        Appearance34.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance34.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance34.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance34.ForeColor = System.Drawing.Color.Black
        Appearance34.Image = CType(resources.GetObject("Appearance34.Image"), Object)
        Appearance34.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance34.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance34.TextVAlignAsString = "Bottom"
        Me.cmdPrice6.Appearance = Appearance34
        Me.cmdPrice6.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance35.BackColor = System.Drawing.Color.DarkOrange
        Appearance35.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance35.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance35.ForeColor = System.Drawing.Color.Black
        Me.cmdPrice6.HotTrackAppearance = Appearance35
        Me.cmdPrice6.ImageSize = New System.Drawing.Size(24, 24)
        Me.cmdPrice6.Location = New System.Drawing.Point(376, 270)
        Me.cmdPrice6.Name = "cmdPrice6"
        Appearance36.BackColor = System.Drawing.Color.OrangeRed
        Appearance36.BackColor2 = System.Drawing.Color.Tomato
        Appearance36.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdPrice6.PressedAppearance = Appearance36
        Me.cmdPrice6.ShowFocusRect = False
        Me.cmdPrice6.ShowOutline = False
        Me.cmdPrice6.Size = New System.Drawing.Size(48, 31)
        Me.cmdPrice6.TabIndex = 559
        Me.cmdPrice6.Tag = "Back"
        Me.cmdPrice6.UseAppStyling = False
        Me.cmdPrice6.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPrice6.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPrice6.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdPrice5
        '
        Appearance37.BackColor = System.Drawing.Color.Transparent
        Appearance37.BackColor2 = System.Drawing.Color.Transparent
        Appearance37.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance37.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance37.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance37.ForeColor = System.Drawing.Color.Black
        Appearance37.Image = CType(resources.GetObject("Appearance37.Image"), Object)
        Appearance37.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance37.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance37.TextVAlignAsString = "Bottom"
        Me.cmdPrice5.Appearance = Appearance37
        Me.cmdPrice5.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance38.BackColor = System.Drawing.Color.DarkOrange
        Appearance38.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance38.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance38.ForeColor = System.Drawing.Color.Black
        Me.cmdPrice5.HotTrackAppearance = Appearance38
        Me.cmdPrice5.ImageSize = New System.Drawing.Size(24, 24)
        Me.cmdPrice5.Location = New System.Drawing.Point(376, 233)
        Me.cmdPrice5.Name = "cmdPrice5"
        Appearance39.BackColor = System.Drawing.Color.OrangeRed
        Appearance39.BackColor2 = System.Drawing.Color.Tomato
        Appearance39.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdPrice5.PressedAppearance = Appearance39
        Me.cmdPrice5.ShowFocusRect = False
        Me.cmdPrice5.ShowOutline = False
        Me.cmdPrice5.Size = New System.Drawing.Size(48, 31)
        Me.cmdPrice5.TabIndex = 558
        Me.cmdPrice5.Tag = "Back"
        Me.cmdPrice5.UseAppStyling = False
        Me.cmdPrice5.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPrice5.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPrice5.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdPrice9
        '
        Appearance40.BackColor = System.Drawing.Color.Transparent
        Appearance40.BackColor2 = System.Drawing.Color.Transparent
        Appearance40.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance40.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance40.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance40.ForeColor = System.Drawing.Color.Black
        Appearance40.Image = CType(resources.GetObject("Appearance40.Image"), Object)
        Appearance40.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance40.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance40.TextVAlignAsString = "Bottom"
        Me.cmdPrice9.Appearance = Appearance40
        Me.cmdPrice9.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance41.BackColor = System.Drawing.Color.DarkOrange
        Appearance41.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance41.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance41.ForeColor = System.Drawing.Color.Black
        Me.cmdPrice9.HotTrackAppearance = Appearance41
        Me.cmdPrice9.ImageSize = New System.Drawing.Size(24, 24)
        Me.cmdPrice9.Location = New System.Drawing.Point(376, 381)
        Me.cmdPrice9.Name = "cmdPrice9"
        Appearance42.BackColor = System.Drawing.Color.OrangeRed
        Appearance42.BackColor2 = System.Drawing.Color.Tomato
        Appearance42.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdPrice9.PressedAppearance = Appearance42
        Me.cmdPrice9.ShowFocusRect = False
        Me.cmdPrice9.ShowOutline = False
        Me.cmdPrice9.Size = New System.Drawing.Size(48, 31)
        Me.cmdPrice9.TabIndex = 562
        Me.cmdPrice9.Tag = "Back"
        Me.cmdPrice9.UseAppStyling = False
        Me.cmdPrice9.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPrice9.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPrice9.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdSwapName
        '
        Me.cmdSwapName.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Appearance43.BackColor = System.Drawing.Color.Transparent
        Appearance43.BackColor2 = System.Drawing.Color.Transparent
        Appearance43.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance43.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance43.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance43.BorderColor2 = System.Drawing.Color.Maroon
        Appearance43.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance43.ForeColor = System.Drawing.Color.Black
        Appearance43.Image = CType(resources.GetObject("Appearance43.Image"), Object)
        Appearance43.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance43.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance43.TextVAlignAsString = "Bottom"
        Me.cmdSwapName.Appearance = Appearance43
        Me.cmdSwapName.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdSwapName.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance44.BackColor = System.Drawing.Color.DarkOrange
        Appearance44.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance44.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance44.ForeColor = System.Drawing.Color.Black
        Me.cmdSwapName.HotTrackAppearance = Appearance44
        Me.cmdSwapName.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdSwapName.Location = New System.Drawing.Point(12, 478)
        Me.cmdSwapName.Name = "cmdSwapName"
        Appearance45.BackColor = System.Drawing.Color.OrangeRed
        Appearance45.BackColor2 = System.Drawing.Color.Tomato
        Appearance45.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdSwapName.PressedAppearance = Appearance45
        Me.cmdSwapName.ShowFocusRect = False
        Me.cmdSwapName.ShowOutline = False
        Me.cmdSwapName.Size = New System.Drawing.Size(64, 44)
        Me.cmdSwapName.StyleSetName = "StatusBar"
        Me.cmdSwapName.TabIndex = 563
        Me.cmdSwapName.Tag = "0"
        Me.cmdSwapName.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdSwapName.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdSwapName.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdPriceOut9
        '
        Appearance46.BackColor = System.Drawing.Color.Transparent
        Appearance46.BackColor2 = System.Drawing.Color.Transparent
        Appearance46.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance46.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance46.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance46.ForeColor = System.Drawing.Color.Black
        Appearance46.Image = CType(resources.GetObject("Appearance46.Image"), Object)
        Appearance46.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance46.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance46.TextVAlignAsString = "Bottom"
        Me.cmdPriceOut9.Appearance = Appearance46
        Me.cmdPriceOut9.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance47.BackColor = System.Drawing.Color.DarkOrange
        Appearance47.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance47.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance47.ForeColor = System.Drawing.Color.Black
        Me.cmdPriceOut9.HotTrackAppearance = Appearance47
        Me.cmdPriceOut9.ImageSize = New System.Drawing.Size(24, 24)
        Me.cmdPriceOut9.Location = New System.Drawing.Point(491, 381)
        Me.cmdPriceOut9.Name = "cmdPriceOut9"
        Appearance48.BackColor = System.Drawing.Color.OrangeRed
        Appearance48.BackColor2 = System.Drawing.Color.Tomato
        Appearance48.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdPriceOut9.PressedAppearance = Appearance48
        Me.cmdPriceOut9.ShowFocusRect = False
        Me.cmdPriceOut9.ShowOutline = False
        Me.cmdPriceOut9.Size = New System.Drawing.Size(48, 31)
        Me.cmdPriceOut9.TabIndex = 590
        Me.cmdPriceOut9.Tag = "Back"
        Me.cmdPriceOut9.UseAppStyling = False
        Me.cmdPriceOut9.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPriceOut9.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPriceOut9.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdPriceOut8
        '
        Appearance49.BackColor = System.Drawing.Color.Transparent
        Appearance49.BackColor2 = System.Drawing.Color.Transparent
        Appearance49.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance49.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance49.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance49.ForeColor = System.Drawing.Color.Black
        Appearance49.Image = CType(resources.GetObject("Appearance49.Image"), Object)
        Appearance49.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance49.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance49.TextVAlignAsString = "Bottom"
        Me.cmdPriceOut8.Appearance = Appearance49
        Me.cmdPriceOut8.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance50.BackColor = System.Drawing.Color.DarkOrange
        Appearance50.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance50.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance50.ForeColor = System.Drawing.Color.Black
        Me.cmdPriceOut8.HotTrackAppearance = Appearance50
        Me.cmdPriceOut8.ImageSize = New System.Drawing.Size(24, 24)
        Me.cmdPriceOut8.Location = New System.Drawing.Point(491, 344)
        Me.cmdPriceOut8.Name = "cmdPriceOut8"
        Appearance51.BackColor = System.Drawing.Color.OrangeRed
        Appearance51.BackColor2 = System.Drawing.Color.Tomato
        Appearance51.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdPriceOut8.PressedAppearance = Appearance51
        Me.cmdPriceOut8.ShowFocusRect = False
        Me.cmdPriceOut8.ShowOutline = False
        Me.cmdPriceOut8.Size = New System.Drawing.Size(48, 31)
        Me.cmdPriceOut8.TabIndex = 589
        Me.cmdPriceOut8.Tag = "Back"
        Me.cmdPriceOut8.UseAppStyling = False
        Me.cmdPriceOut8.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPriceOut8.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPriceOut8.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdPriceOut7
        '
        Appearance52.BackColor = System.Drawing.Color.Transparent
        Appearance52.BackColor2 = System.Drawing.Color.Transparent
        Appearance52.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance52.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance52.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance52.ForeColor = System.Drawing.Color.Black
        Appearance52.Image = CType(resources.GetObject("Appearance52.Image"), Object)
        Appearance52.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance52.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance52.TextVAlignAsString = "Bottom"
        Me.cmdPriceOut7.Appearance = Appearance52
        Me.cmdPriceOut7.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance53.BackColor = System.Drawing.Color.DarkOrange
        Appearance53.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance53.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance53.ForeColor = System.Drawing.Color.Black
        Me.cmdPriceOut7.HotTrackAppearance = Appearance53
        Me.cmdPriceOut7.ImageSize = New System.Drawing.Size(24, 24)
        Me.cmdPriceOut7.Location = New System.Drawing.Point(491, 307)
        Me.cmdPriceOut7.Name = "cmdPriceOut7"
        Appearance54.BackColor = System.Drawing.Color.OrangeRed
        Appearance54.BackColor2 = System.Drawing.Color.Tomato
        Appearance54.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdPriceOut7.PressedAppearance = Appearance54
        Me.cmdPriceOut7.ShowFocusRect = False
        Me.cmdPriceOut7.ShowOutline = False
        Me.cmdPriceOut7.Size = New System.Drawing.Size(48, 31)
        Me.cmdPriceOut7.TabIndex = 588
        Me.cmdPriceOut7.Tag = "Back"
        Me.cmdPriceOut7.UseAppStyling = False
        Me.cmdPriceOut7.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPriceOut7.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPriceOut7.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdPriceOut6
        '
        Appearance55.BackColor = System.Drawing.Color.Transparent
        Appearance55.BackColor2 = System.Drawing.Color.Transparent
        Appearance55.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance55.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance55.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance55.ForeColor = System.Drawing.Color.Black
        Appearance55.Image = CType(resources.GetObject("Appearance55.Image"), Object)
        Appearance55.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance55.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance55.TextVAlignAsString = "Bottom"
        Me.cmdPriceOut6.Appearance = Appearance55
        Me.cmdPriceOut6.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance56.BackColor = System.Drawing.Color.DarkOrange
        Appearance56.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance56.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance56.ForeColor = System.Drawing.Color.Black
        Me.cmdPriceOut6.HotTrackAppearance = Appearance56
        Me.cmdPriceOut6.ImageSize = New System.Drawing.Size(24, 24)
        Me.cmdPriceOut6.Location = New System.Drawing.Point(491, 270)
        Me.cmdPriceOut6.Name = "cmdPriceOut6"
        Appearance57.BackColor = System.Drawing.Color.OrangeRed
        Appearance57.BackColor2 = System.Drawing.Color.Tomato
        Appearance57.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdPriceOut6.PressedAppearance = Appearance57
        Me.cmdPriceOut6.ShowFocusRect = False
        Me.cmdPriceOut6.ShowOutline = False
        Me.cmdPriceOut6.Size = New System.Drawing.Size(48, 31)
        Me.cmdPriceOut6.TabIndex = 587
        Me.cmdPriceOut6.Tag = "Back"
        Me.cmdPriceOut6.UseAppStyling = False
        Me.cmdPriceOut6.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPriceOut6.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPriceOut6.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdPriceOut5
        '
        Appearance58.BackColor = System.Drawing.Color.Transparent
        Appearance58.BackColor2 = System.Drawing.Color.Transparent
        Appearance58.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance58.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance58.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance58.ForeColor = System.Drawing.Color.Black
        Appearance58.Image = CType(resources.GetObject("Appearance58.Image"), Object)
        Appearance58.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance58.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance58.TextVAlignAsString = "Bottom"
        Me.cmdPriceOut5.Appearance = Appearance58
        Me.cmdPriceOut5.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance59.BackColor = System.Drawing.Color.DarkOrange
        Appearance59.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance59.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance59.ForeColor = System.Drawing.Color.Black
        Me.cmdPriceOut5.HotTrackAppearance = Appearance59
        Me.cmdPriceOut5.ImageSize = New System.Drawing.Size(24, 24)
        Me.cmdPriceOut5.Location = New System.Drawing.Point(491, 233)
        Me.cmdPriceOut5.Name = "cmdPriceOut5"
        Appearance60.BackColor = System.Drawing.Color.OrangeRed
        Appearance60.BackColor2 = System.Drawing.Color.Tomato
        Appearance60.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdPriceOut5.PressedAppearance = Appearance60
        Me.cmdPriceOut5.ShowFocusRect = False
        Me.cmdPriceOut5.ShowOutline = False
        Me.cmdPriceOut5.Size = New System.Drawing.Size(48, 31)
        Me.cmdPriceOut5.TabIndex = 586
        Me.cmdPriceOut5.Tag = "Back"
        Me.cmdPriceOut5.UseAppStyling = False
        Me.cmdPriceOut5.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPriceOut5.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPriceOut5.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdPriceOut4
        '
        Appearance61.BackColor = System.Drawing.Color.Transparent
        Appearance61.BackColor2 = System.Drawing.Color.Transparent
        Appearance61.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance61.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance61.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance61.ForeColor = System.Drawing.Color.Black
        Appearance61.Image = CType(resources.GetObject("Appearance61.Image"), Object)
        Appearance61.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance61.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance61.TextVAlignAsString = "Bottom"
        Me.cmdPriceOut4.Appearance = Appearance61
        Me.cmdPriceOut4.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance62.BackColor = System.Drawing.Color.DarkOrange
        Appearance62.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance62.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance62.ForeColor = System.Drawing.Color.Black
        Me.cmdPriceOut4.HotTrackAppearance = Appearance62
        Me.cmdPriceOut4.ImageSize = New System.Drawing.Size(24, 24)
        Me.cmdPriceOut4.Location = New System.Drawing.Point(491, 196)
        Me.cmdPriceOut4.Name = "cmdPriceOut4"
        Appearance63.BackColor = System.Drawing.Color.OrangeRed
        Appearance63.BackColor2 = System.Drawing.Color.Tomato
        Appearance63.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdPriceOut4.PressedAppearance = Appearance63
        Me.cmdPriceOut4.ShowFocusRect = False
        Me.cmdPriceOut4.ShowOutline = False
        Me.cmdPriceOut4.Size = New System.Drawing.Size(48, 31)
        Me.cmdPriceOut4.TabIndex = 585
        Me.cmdPriceOut4.Tag = "Back"
        Me.cmdPriceOut4.UseAppStyling = False
        Me.cmdPriceOut4.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPriceOut4.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPriceOut4.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdPriceOut3
        '
        Appearance64.BackColor = System.Drawing.Color.Transparent
        Appearance64.BackColor2 = System.Drawing.Color.Transparent
        Appearance64.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance64.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance64.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance64.ForeColor = System.Drawing.Color.Black
        Appearance64.Image = CType(resources.GetObject("Appearance64.Image"), Object)
        Appearance64.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance64.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance64.TextVAlignAsString = "Bottom"
        Me.cmdPriceOut3.Appearance = Appearance64
        Me.cmdPriceOut3.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance65.BackColor = System.Drawing.Color.DarkOrange
        Appearance65.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance65.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance65.ForeColor = System.Drawing.Color.Black
        Me.cmdPriceOut3.HotTrackAppearance = Appearance65
        Me.cmdPriceOut3.ImageSize = New System.Drawing.Size(24, 24)
        Me.cmdPriceOut3.Location = New System.Drawing.Point(491, 159)
        Me.cmdPriceOut3.Name = "cmdPriceOut3"
        Appearance66.BackColor = System.Drawing.Color.OrangeRed
        Appearance66.BackColor2 = System.Drawing.Color.Tomato
        Appearance66.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdPriceOut3.PressedAppearance = Appearance66
        Me.cmdPriceOut3.ShowFocusRect = False
        Me.cmdPriceOut3.ShowOutline = False
        Me.cmdPriceOut3.Size = New System.Drawing.Size(48, 31)
        Me.cmdPriceOut3.TabIndex = 584
        Me.cmdPriceOut3.Tag = "Back"
        Me.cmdPriceOut3.UseAppStyling = False
        Me.cmdPriceOut3.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPriceOut3.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPriceOut3.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdPriceOut2
        '
        Appearance67.BackColor = System.Drawing.Color.Transparent
        Appearance67.BackColor2 = System.Drawing.Color.Transparent
        Appearance67.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance67.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance67.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance67.ForeColor = System.Drawing.Color.Black
        Appearance67.Image = CType(resources.GetObject("Appearance67.Image"), Object)
        Appearance67.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance67.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance67.TextVAlignAsString = "Bottom"
        Me.cmdPriceOut2.Appearance = Appearance67
        Me.cmdPriceOut2.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance68.BackColor = System.Drawing.Color.DarkOrange
        Appearance68.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance68.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance68.ForeColor = System.Drawing.Color.Black
        Me.cmdPriceOut2.HotTrackAppearance = Appearance68
        Me.cmdPriceOut2.ImageSize = New System.Drawing.Size(24, 24)
        Me.cmdPriceOut2.Location = New System.Drawing.Point(491, 122)
        Me.cmdPriceOut2.Name = "cmdPriceOut2"
        Appearance69.BackColor = System.Drawing.Color.OrangeRed
        Appearance69.BackColor2 = System.Drawing.Color.Tomato
        Appearance69.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdPriceOut2.PressedAppearance = Appearance69
        Me.cmdPriceOut2.ShowFocusRect = False
        Me.cmdPriceOut2.ShowOutline = False
        Me.cmdPriceOut2.Size = New System.Drawing.Size(48, 31)
        Me.cmdPriceOut2.TabIndex = 583
        Me.cmdPriceOut2.Tag = "Back"
        Me.cmdPriceOut2.UseAppStyling = False
        Me.cmdPriceOut2.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPriceOut2.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPriceOut2.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdPriceOut1
        '
        Appearance70.BackColor = System.Drawing.Color.Transparent
        Appearance70.BackColor2 = System.Drawing.Color.Transparent
        Appearance70.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance70.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance70.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance70.ForeColor = System.Drawing.Color.Black
        Appearance70.Image = CType(resources.GetObject("Appearance70.Image"), Object)
        Appearance70.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance70.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance70.TextVAlignAsString = "Bottom"
        Me.cmdPriceOut1.Appearance = Appearance70
        Me.cmdPriceOut1.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance71.BackColor = System.Drawing.Color.DarkOrange
        Appearance71.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance71.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance71.ForeColor = System.Drawing.Color.Black
        Me.cmdPriceOut1.HotTrackAppearance = Appearance71
        Me.cmdPriceOut1.ImageSize = New System.Drawing.Size(24, 24)
        Me.cmdPriceOut1.Location = New System.Drawing.Point(491, 85)
        Me.cmdPriceOut1.Name = "cmdPriceOut1"
        Appearance72.BackColor = System.Drawing.Color.OrangeRed
        Appearance72.BackColor2 = System.Drawing.Color.Tomato
        Appearance72.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdPriceOut1.PressedAppearance = Appearance72
        Me.cmdPriceOut1.ShowFocusRect = False
        Me.cmdPriceOut1.ShowOutline = False
        Me.cmdPriceOut1.Size = New System.Drawing.Size(48, 31)
        Me.cmdPriceOut1.TabIndex = 582
        Me.cmdPriceOut1.Tag = "Back"
        Me.cmdPriceOut1.UseAppStyling = False
        Me.cmdPriceOut1.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPriceOut1.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPriceOut1.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtPriceOut9
        '
        Appearance73.TextHAlignAsString = "Right"
        Me.txtPriceOut9.Appearance = Appearance73
        Me.txtPriceOut9.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPriceOut9.Location = New System.Drawing.Point(430, 383)
        Me.txtPriceOut9.MaxLength = 50
        Me.txtPriceOut9.Name = "txtPriceOut9"
        Me.txtPriceOut9.Size = New System.Drawing.Size(55, 26)
        Me.txtPriceOut9.TabIndex = 581
        Me.txtPriceOut9.UseAppStyling = False
        '
        'txtPriceOut8
        '
        Appearance74.TextHAlignAsString = "Right"
        Me.txtPriceOut8.Appearance = Appearance74
        Me.txtPriceOut8.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPriceOut8.Location = New System.Drawing.Point(430, 346)
        Me.txtPriceOut8.MaxLength = 50
        Me.txtPriceOut8.Name = "txtPriceOut8"
        Me.txtPriceOut8.Size = New System.Drawing.Size(55, 26)
        Me.txtPriceOut8.TabIndex = 580
        Me.txtPriceOut8.UseAppStyling = False
        '
        'txtPriceOut7
        '
        Appearance75.TextHAlignAsString = "Right"
        Me.txtPriceOut7.Appearance = Appearance75
        Me.txtPriceOut7.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPriceOut7.Location = New System.Drawing.Point(430, 309)
        Me.txtPriceOut7.MaxLength = 50
        Me.txtPriceOut7.Name = "txtPriceOut7"
        Me.txtPriceOut7.Size = New System.Drawing.Size(55, 26)
        Me.txtPriceOut7.TabIndex = 579
        Me.txtPriceOut7.UseAppStyling = False
        '
        'txtPriceOut6
        '
        Appearance76.TextHAlignAsString = "Right"
        Me.txtPriceOut6.Appearance = Appearance76
        Me.txtPriceOut6.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPriceOut6.Location = New System.Drawing.Point(430, 272)
        Me.txtPriceOut6.MaxLength = 50
        Me.txtPriceOut6.Name = "txtPriceOut6"
        Me.txtPriceOut6.Size = New System.Drawing.Size(55, 26)
        Me.txtPriceOut6.TabIndex = 578
        Me.txtPriceOut6.UseAppStyling = False
        '
        'txtPriceOut5
        '
        Appearance77.TextHAlignAsString = "Right"
        Me.txtPriceOut5.Appearance = Appearance77
        Me.txtPriceOut5.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPriceOut5.Location = New System.Drawing.Point(430, 235)
        Me.txtPriceOut5.MaxLength = 50
        Me.txtPriceOut5.Name = "txtPriceOut5"
        Me.txtPriceOut5.Size = New System.Drawing.Size(55, 26)
        Me.txtPriceOut5.TabIndex = 577
        Me.txtPriceOut5.UseAppStyling = False
        '
        'txtPriceOut4
        '
        Appearance78.TextHAlignAsString = "Right"
        Me.txtPriceOut4.Appearance = Appearance78
        Me.txtPriceOut4.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPriceOut4.Location = New System.Drawing.Point(430, 198)
        Me.txtPriceOut4.MaxLength = 50
        Me.txtPriceOut4.Name = "txtPriceOut4"
        Me.txtPriceOut4.Size = New System.Drawing.Size(55, 26)
        Me.txtPriceOut4.TabIndex = 576
        Me.txtPriceOut4.UseAppStyling = False
        '
        'txtPriceOut3
        '
        Appearance79.TextHAlignAsString = "Right"
        Me.txtPriceOut3.Appearance = Appearance79
        Me.txtPriceOut3.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPriceOut3.Location = New System.Drawing.Point(430, 161)
        Me.txtPriceOut3.MaxLength = 50
        Me.txtPriceOut3.Name = "txtPriceOut3"
        Me.txtPriceOut3.Size = New System.Drawing.Size(55, 26)
        Me.txtPriceOut3.TabIndex = 575
        Me.txtPriceOut3.UseAppStyling = False
        '
        'txtPriceOut2
        '
        Appearance80.TextHAlignAsString = "Right"
        Me.txtPriceOut2.Appearance = Appearance80
        Me.txtPriceOut2.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPriceOut2.Location = New System.Drawing.Point(430, 124)
        Me.txtPriceOut2.MaxLength = 50
        Me.txtPriceOut2.Name = "txtPriceOut2"
        Me.txtPriceOut2.Size = New System.Drawing.Size(55, 26)
        Me.txtPriceOut2.TabIndex = 574
        Me.txtPriceOut2.UseAppStyling = False
        '
        'txtPriceOut1
        '
        Appearance81.TextHAlignAsString = "Right"
        Me.txtPriceOut1.Appearance = Appearance81
        Me.txtPriceOut1.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPriceOut1.Location = New System.Drawing.Point(430, 87)
        Me.txtPriceOut1.MaxLength = 50
        Me.txtPriceOut1.Name = "txtPriceOut1"
        Me.txtPriceOut1.Size = New System.Drawing.Size(55, 26)
        Me.txtPriceOut1.TabIndex = 573
        Me.txtPriceOut1.UseAppStyling = False
        '
        'cmdKB9
        '
        Appearance82.BackColor = System.Drawing.Color.Transparent
        Appearance82.BackColor2 = System.Drawing.Color.Transparent
        Appearance82.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance82.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance82.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance82.ForeColor = System.Drawing.Color.Black
        Appearance82.Image = CType(resources.GetObject("Appearance82.Image"), Object)
        Appearance82.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance82.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance82.TextVAlignAsString = "Bottom"
        Me.cmdKB9.Appearance = Appearance82
        Me.cmdKB9.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance83.BackColor = System.Drawing.Color.DarkOrange
        Appearance83.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance83.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance83.ForeColor = System.Drawing.Color.Black
        Me.cmdKB9.HotTrackAppearance = Appearance83
        Me.cmdKB9.ImageSize = New System.Drawing.Size(30, 18)
        Me.cmdKB9.Location = New System.Drawing.Point(606, 381)
        Me.cmdKB9.Name = "cmdKB9"
        Appearance84.BackColor = System.Drawing.Color.OrangeRed
        Appearance84.BackColor2 = System.Drawing.Color.Tomato
        Appearance84.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdKB9.PressedAppearance = Appearance84
        Me.cmdKB9.ShowFocusRect = False
        Me.cmdKB9.ShowOutline = False
        Me.cmdKB9.Size = New System.Drawing.Size(48, 31)
        Me.cmdKB9.TabIndex = 608
        Me.cmdKB9.Tag = "Back"
        Me.cmdKB9.UseAppStyling = False
        Me.cmdKB9.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKB9.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKB9.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdKB8
        '
        Appearance85.BackColor = System.Drawing.Color.Transparent
        Appearance85.BackColor2 = System.Drawing.Color.Transparent
        Appearance85.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance85.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance85.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance85.ForeColor = System.Drawing.Color.Black
        Appearance85.Image = CType(resources.GetObject("Appearance85.Image"), Object)
        Appearance85.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance85.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance85.TextVAlignAsString = "Bottom"
        Me.cmdKB8.Appearance = Appearance85
        Me.cmdKB8.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance86.BackColor = System.Drawing.Color.DarkOrange
        Appearance86.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance86.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance86.ForeColor = System.Drawing.Color.Black
        Me.cmdKB8.HotTrackAppearance = Appearance86
        Me.cmdKB8.ImageSize = New System.Drawing.Size(30, 18)
        Me.cmdKB8.Location = New System.Drawing.Point(606, 344)
        Me.cmdKB8.Name = "cmdKB8"
        Appearance87.BackColor = System.Drawing.Color.OrangeRed
        Appearance87.BackColor2 = System.Drawing.Color.Tomato
        Appearance87.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdKB8.PressedAppearance = Appearance87
        Me.cmdKB8.ShowFocusRect = False
        Me.cmdKB8.ShowOutline = False
        Me.cmdKB8.Size = New System.Drawing.Size(48, 31)
        Me.cmdKB8.TabIndex = 607
        Me.cmdKB8.Tag = "Back"
        Me.cmdKB8.UseAppStyling = False
        Me.cmdKB8.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKB8.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKB8.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdKB7
        '
        Appearance88.BackColor = System.Drawing.Color.Transparent
        Appearance88.BackColor2 = System.Drawing.Color.Transparent
        Appearance88.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance88.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance88.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance88.ForeColor = System.Drawing.Color.Black
        Appearance88.Image = CType(resources.GetObject("Appearance88.Image"), Object)
        Appearance88.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance88.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance88.TextVAlignAsString = "Bottom"
        Me.cmdKB7.Appearance = Appearance88
        Me.cmdKB7.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance89.BackColor = System.Drawing.Color.DarkOrange
        Appearance89.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance89.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance89.ForeColor = System.Drawing.Color.Black
        Me.cmdKB7.HotTrackAppearance = Appearance89
        Me.cmdKB7.ImageSize = New System.Drawing.Size(30, 18)
        Me.cmdKB7.Location = New System.Drawing.Point(606, 307)
        Me.cmdKB7.Name = "cmdKB7"
        Appearance90.BackColor = System.Drawing.Color.OrangeRed
        Appearance90.BackColor2 = System.Drawing.Color.Tomato
        Appearance90.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdKB7.PressedAppearance = Appearance90
        Me.cmdKB7.ShowFocusRect = False
        Me.cmdKB7.ShowOutline = False
        Me.cmdKB7.Size = New System.Drawing.Size(48, 31)
        Me.cmdKB7.TabIndex = 606
        Me.cmdKB7.Tag = "Back"
        Me.cmdKB7.UseAppStyling = False
        Me.cmdKB7.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKB7.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKB7.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdKB6
        '
        Appearance91.BackColor = System.Drawing.Color.Transparent
        Appearance91.BackColor2 = System.Drawing.Color.Transparent
        Appearance91.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance91.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance91.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance91.ForeColor = System.Drawing.Color.Black
        Appearance91.Image = CType(resources.GetObject("Appearance91.Image"), Object)
        Appearance91.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance91.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance91.TextVAlignAsString = "Bottom"
        Me.cmdKB6.Appearance = Appearance91
        Me.cmdKB6.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance92.BackColor = System.Drawing.Color.DarkOrange
        Appearance92.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance92.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance92.ForeColor = System.Drawing.Color.Black
        Me.cmdKB6.HotTrackAppearance = Appearance92
        Me.cmdKB6.ImageSize = New System.Drawing.Size(30, 18)
        Me.cmdKB6.Location = New System.Drawing.Point(606, 270)
        Me.cmdKB6.Name = "cmdKB6"
        Appearance93.BackColor = System.Drawing.Color.OrangeRed
        Appearance93.BackColor2 = System.Drawing.Color.Tomato
        Appearance93.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdKB6.PressedAppearance = Appearance93
        Me.cmdKB6.ShowFocusRect = False
        Me.cmdKB6.ShowOutline = False
        Me.cmdKB6.Size = New System.Drawing.Size(48, 31)
        Me.cmdKB6.TabIndex = 605
        Me.cmdKB6.Tag = "Back"
        Me.cmdKB6.UseAppStyling = False
        Me.cmdKB6.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKB6.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKB6.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdKB5
        '
        Appearance94.BackColor = System.Drawing.Color.Transparent
        Appearance94.BackColor2 = System.Drawing.Color.Transparent
        Appearance94.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance94.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance94.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance94.ForeColor = System.Drawing.Color.Black
        Appearance94.Image = CType(resources.GetObject("Appearance94.Image"), Object)
        Appearance94.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance94.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance94.TextVAlignAsString = "Bottom"
        Me.cmdKB5.Appearance = Appearance94
        Me.cmdKB5.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance95.BackColor = System.Drawing.Color.DarkOrange
        Appearance95.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance95.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance95.ForeColor = System.Drawing.Color.Black
        Me.cmdKB5.HotTrackAppearance = Appearance95
        Me.cmdKB5.ImageSize = New System.Drawing.Size(30, 18)
        Me.cmdKB5.Location = New System.Drawing.Point(606, 233)
        Me.cmdKB5.Name = "cmdKB5"
        Appearance96.BackColor = System.Drawing.Color.OrangeRed
        Appearance96.BackColor2 = System.Drawing.Color.Tomato
        Appearance96.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdKB5.PressedAppearance = Appearance96
        Me.cmdKB5.ShowFocusRect = False
        Me.cmdKB5.ShowOutline = False
        Me.cmdKB5.Size = New System.Drawing.Size(48, 31)
        Me.cmdKB5.TabIndex = 604
        Me.cmdKB5.Tag = "Back"
        Me.cmdKB5.UseAppStyling = False
        Me.cmdKB5.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKB5.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKB5.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdKB4
        '
        Appearance97.BackColor = System.Drawing.Color.Transparent
        Appearance97.BackColor2 = System.Drawing.Color.Transparent
        Appearance97.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance97.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance97.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance97.ForeColor = System.Drawing.Color.Black
        Appearance97.Image = CType(resources.GetObject("Appearance97.Image"), Object)
        Appearance97.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance97.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance97.TextVAlignAsString = "Bottom"
        Me.cmdKB4.Appearance = Appearance97
        Me.cmdKB4.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance98.BackColor = System.Drawing.Color.DarkOrange
        Appearance98.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance98.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance98.ForeColor = System.Drawing.Color.Black
        Me.cmdKB4.HotTrackAppearance = Appearance98
        Me.cmdKB4.ImageSize = New System.Drawing.Size(30, 18)
        Me.cmdKB4.Location = New System.Drawing.Point(606, 196)
        Me.cmdKB4.Name = "cmdKB4"
        Appearance99.BackColor = System.Drawing.Color.OrangeRed
        Appearance99.BackColor2 = System.Drawing.Color.Tomato
        Appearance99.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdKB4.PressedAppearance = Appearance99
        Me.cmdKB4.ShowFocusRect = False
        Me.cmdKB4.ShowOutline = False
        Me.cmdKB4.Size = New System.Drawing.Size(48, 31)
        Me.cmdKB4.TabIndex = 603
        Me.cmdKB4.Tag = "Back"
        Me.cmdKB4.UseAppStyling = False
        Me.cmdKB4.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKB4.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKB4.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdKB3
        '
        Appearance100.BackColor = System.Drawing.Color.Transparent
        Appearance100.BackColor2 = System.Drawing.Color.Transparent
        Appearance100.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance100.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance100.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance100.ForeColor = System.Drawing.Color.Black
        Appearance100.Image = CType(resources.GetObject("Appearance100.Image"), Object)
        Appearance100.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance100.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance100.TextVAlignAsString = "Bottom"
        Me.cmdKB3.Appearance = Appearance100
        Me.cmdKB3.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance101.BackColor = System.Drawing.Color.DarkOrange
        Appearance101.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance101.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance101.ForeColor = System.Drawing.Color.Black
        Me.cmdKB3.HotTrackAppearance = Appearance101
        Me.cmdKB3.ImageSize = New System.Drawing.Size(30, 18)
        Me.cmdKB3.Location = New System.Drawing.Point(606, 159)
        Me.cmdKB3.Name = "cmdKB3"
        Appearance102.BackColor = System.Drawing.Color.OrangeRed
        Appearance102.BackColor2 = System.Drawing.Color.Tomato
        Appearance102.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdKB3.PressedAppearance = Appearance102
        Me.cmdKB3.ShowFocusRect = False
        Me.cmdKB3.ShowOutline = False
        Me.cmdKB3.Size = New System.Drawing.Size(48, 31)
        Me.cmdKB3.TabIndex = 602
        Me.cmdKB3.Tag = "Back"
        Me.cmdKB3.UseAppStyling = False
        Me.cmdKB3.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKB3.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKB3.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdKB2
        '
        Appearance103.BackColor = System.Drawing.Color.Transparent
        Appearance103.BackColor2 = System.Drawing.Color.Transparent
        Appearance103.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance103.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance103.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance103.ForeColor = System.Drawing.Color.Black
        Appearance103.Image = CType(resources.GetObject("Appearance103.Image"), Object)
        Appearance103.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance103.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance103.TextVAlignAsString = "Bottom"
        Me.cmdKB2.Appearance = Appearance103
        Me.cmdKB2.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance104.BackColor = System.Drawing.Color.DarkOrange
        Appearance104.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance104.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance104.ForeColor = System.Drawing.Color.Black
        Me.cmdKB2.HotTrackAppearance = Appearance104
        Me.cmdKB2.ImageSize = New System.Drawing.Size(30, 18)
        Me.cmdKB2.Location = New System.Drawing.Point(606, 122)
        Me.cmdKB2.Name = "cmdKB2"
        Appearance105.BackColor = System.Drawing.Color.OrangeRed
        Appearance105.BackColor2 = System.Drawing.Color.Tomato
        Appearance105.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdKB2.PressedAppearance = Appearance105
        Me.cmdKB2.ShowFocusRect = False
        Me.cmdKB2.ShowOutline = False
        Me.cmdKB2.Size = New System.Drawing.Size(48, 31)
        Me.cmdKB2.TabIndex = 601
        Me.cmdKB2.Tag = "Back"
        Me.cmdKB2.UseAppStyling = False
        Me.cmdKB2.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKB2.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKB2.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdKB1
        '
        Appearance106.BackColor = System.Drawing.Color.Transparent
        Appearance106.BackColor2 = System.Drawing.Color.Transparent
        Appearance106.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance106.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance106.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance106.ForeColor = System.Drawing.Color.Black
        Appearance106.Image = CType(resources.GetObject("Appearance106.Image"), Object)
        Appearance106.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance106.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance106.TextVAlignAsString = "Bottom"
        Me.cmdKB1.Appearance = Appearance106
        Me.cmdKB1.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance107.BackColor = System.Drawing.Color.DarkOrange
        Appearance107.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance107.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance107.ForeColor = System.Drawing.Color.Black
        Me.cmdKB1.HotTrackAppearance = Appearance107
        Me.cmdKB1.ImageSize = New System.Drawing.Size(30, 18)
        Me.cmdKB1.Location = New System.Drawing.Point(606, 85)
        Me.cmdKB1.Name = "cmdKB1"
        Appearance108.BackColor = System.Drawing.Color.OrangeRed
        Appearance108.BackColor2 = System.Drawing.Color.Tomato
        Appearance108.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdKB1.PressedAppearance = Appearance108
        Me.cmdKB1.ShowFocusRect = False
        Me.cmdKB1.ShowOutline = False
        Me.cmdKB1.Size = New System.Drawing.Size(48, 31)
        Me.cmdKB1.TabIndex = 600
        Me.cmdKB1.Tag = "Back"
        Me.cmdKB1.UseAppStyling = False
        Me.cmdKB1.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKB1.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKB1.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtShortCode9
        '
        Appearance109.TextHAlignAsString = "Right"
        Me.txtShortCode9.Appearance = Appearance109
        Me.txtShortCode9.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtShortCode9.Location = New System.Drawing.Point(545, 381)
        Me.txtShortCode9.MaxLength = 50
        Me.txtShortCode9.Name = "txtShortCode9"
        Me.txtShortCode9.Size = New System.Drawing.Size(55, 26)
        Me.txtShortCode9.TabIndex = 599
        Me.txtShortCode9.UseAppStyling = False
        '
        'txtShortCode8
        '
        Appearance110.TextHAlignAsString = "Right"
        Me.txtShortCode8.Appearance = Appearance110
        Me.txtShortCode8.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtShortCode8.Location = New System.Drawing.Point(545, 344)
        Me.txtShortCode8.MaxLength = 50
        Me.txtShortCode8.Name = "txtShortCode8"
        Me.txtShortCode8.Size = New System.Drawing.Size(55, 26)
        Me.txtShortCode8.TabIndex = 598
        Me.txtShortCode8.UseAppStyling = False
        '
        'txtShortCode7
        '
        Appearance111.TextHAlignAsString = "Right"
        Me.txtShortCode7.Appearance = Appearance111
        Me.txtShortCode7.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtShortCode7.Location = New System.Drawing.Point(545, 307)
        Me.txtShortCode7.MaxLength = 50
        Me.txtShortCode7.Name = "txtShortCode7"
        Me.txtShortCode7.Size = New System.Drawing.Size(55, 26)
        Me.txtShortCode7.TabIndex = 597
        Me.txtShortCode7.UseAppStyling = False
        '
        'txtShortCode6
        '
        Appearance112.TextHAlignAsString = "Right"
        Me.txtShortCode6.Appearance = Appearance112
        Me.txtShortCode6.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtShortCode6.Location = New System.Drawing.Point(545, 270)
        Me.txtShortCode6.MaxLength = 50
        Me.txtShortCode6.Name = "txtShortCode6"
        Me.txtShortCode6.Size = New System.Drawing.Size(55, 26)
        Me.txtShortCode6.TabIndex = 596
        Me.txtShortCode6.UseAppStyling = False
        '
        'txtShortCode5
        '
        Appearance113.TextHAlignAsString = "Right"
        Me.txtShortCode5.Appearance = Appearance113
        Me.txtShortCode5.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtShortCode5.Location = New System.Drawing.Point(545, 233)
        Me.txtShortCode5.MaxLength = 50
        Me.txtShortCode5.Name = "txtShortCode5"
        Me.txtShortCode5.Size = New System.Drawing.Size(55, 26)
        Me.txtShortCode5.TabIndex = 595
        Me.txtShortCode5.UseAppStyling = False
        '
        'txtShortCode4
        '
        Appearance114.TextHAlignAsString = "Right"
        Me.txtShortCode4.Appearance = Appearance114
        Me.txtShortCode4.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtShortCode4.Location = New System.Drawing.Point(545, 196)
        Me.txtShortCode4.MaxLength = 50
        Me.txtShortCode4.Name = "txtShortCode4"
        Me.txtShortCode4.Size = New System.Drawing.Size(55, 26)
        Me.txtShortCode4.TabIndex = 594
        Me.txtShortCode4.UseAppStyling = False
        '
        'txtShortCode3
        '
        Appearance115.TextHAlignAsString = "Right"
        Me.txtShortCode3.Appearance = Appearance115
        Me.txtShortCode3.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtShortCode3.Location = New System.Drawing.Point(545, 159)
        Me.txtShortCode3.MaxLength = 50
        Me.txtShortCode3.Name = "txtShortCode3"
        Me.txtShortCode3.Size = New System.Drawing.Size(55, 26)
        Me.txtShortCode3.TabIndex = 593
        Me.txtShortCode3.UseAppStyling = False
        '
        'txtShortCode2
        '
        Appearance116.TextHAlignAsString = "Right"
        Me.txtShortCode2.Appearance = Appearance116
        Me.txtShortCode2.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtShortCode2.Location = New System.Drawing.Point(545, 122)
        Me.txtShortCode2.MaxLength = 50
        Me.txtShortCode2.Name = "txtShortCode2"
        Me.txtShortCode2.Size = New System.Drawing.Size(55, 26)
        Me.txtShortCode2.TabIndex = 592
        Me.txtShortCode2.UseAppStyling = False
        '
        'txtShortCode1
        '
        Appearance117.TextHAlignAsString = "Right"
        Me.txtShortCode1.Appearance = Appearance117
        Me.txtShortCode1.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtShortCode1.Location = New System.Drawing.Point(545, 85)
        Me.txtShortCode1.MaxLength = 50
        Me.txtShortCode1.Name = "txtShortCode1"
        Me.txtShortCode1.Size = New System.Drawing.Size(55, 26)
        Me.txtShortCode1.TabIndex = 591
        Me.txtShortCode1.UseAppStyling = False
        '
        'cmdDelSC9
        '
        Appearance118.BackColor = System.Drawing.Color.Transparent
        Appearance118.BackColor2 = System.Drawing.Color.Transparent
        Appearance118.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance118.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance118.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance118.ForeColor = System.Drawing.Color.Black
        Appearance118.Image = CType(resources.GetObject("Appearance118.Image"), Object)
        Appearance118.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance118.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance118.TextVAlignAsString = "Bottom"
        Me.cmdDelSC9.Appearance = Appearance118
        Me.cmdDelSC9.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance119.BackColor = System.Drawing.Color.DarkOrange
        Appearance119.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance119.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance119.ForeColor = System.Drawing.Color.Black
        Me.cmdDelSC9.HotTrackAppearance = Appearance119
        Me.cmdDelSC9.ImageSize = New System.Drawing.Size(20, 20)
        Me.cmdDelSC9.Location = New System.Drawing.Point(660, 381)
        Me.cmdDelSC9.Name = "cmdDelSC9"
        Appearance120.BackColor = System.Drawing.Color.OrangeRed
        Appearance120.BackColor2 = System.Drawing.Color.Tomato
        Appearance120.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdDelSC9.PressedAppearance = Appearance120
        Me.cmdDelSC9.ShowFocusRect = False
        Me.cmdDelSC9.ShowOutline = False
        Me.cmdDelSC9.Size = New System.Drawing.Size(48, 31)
        Me.cmdDelSC9.TabIndex = 617
        Me.cmdDelSC9.Tag = "Back"
        Me.cmdDelSC9.UseAppStyling = False
        Me.cmdDelSC9.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDelSC9.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDelSC9.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDelSC8
        '
        Appearance121.BackColor = System.Drawing.Color.Transparent
        Appearance121.BackColor2 = System.Drawing.Color.Transparent
        Appearance121.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance121.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance121.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance121.ForeColor = System.Drawing.Color.Black
        Appearance121.Image = CType(resources.GetObject("Appearance121.Image"), Object)
        Appearance121.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance121.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance121.TextVAlignAsString = "Bottom"
        Me.cmdDelSC8.Appearance = Appearance121
        Me.cmdDelSC8.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance122.BackColor = System.Drawing.Color.DarkOrange
        Appearance122.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance122.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance122.ForeColor = System.Drawing.Color.Black
        Me.cmdDelSC8.HotTrackAppearance = Appearance122
        Me.cmdDelSC8.ImageSize = New System.Drawing.Size(20, 20)
        Me.cmdDelSC8.Location = New System.Drawing.Point(660, 344)
        Me.cmdDelSC8.Name = "cmdDelSC8"
        Appearance123.BackColor = System.Drawing.Color.OrangeRed
        Appearance123.BackColor2 = System.Drawing.Color.Tomato
        Appearance123.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdDelSC8.PressedAppearance = Appearance123
        Me.cmdDelSC8.ShowFocusRect = False
        Me.cmdDelSC8.ShowOutline = False
        Me.cmdDelSC8.Size = New System.Drawing.Size(48, 31)
        Me.cmdDelSC8.TabIndex = 616
        Me.cmdDelSC8.Tag = "Back"
        Me.cmdDelSC8.UseAppStyling = False
        Me.cmdDelSC8.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDelSC8.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDelSC8.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDelSC7
        '
        Appearance124.BackColor = System.Drawing.Color.Transparent
        Appearance124.BackColor2 = System.Drawing.Color.Transparent
        Appearance124.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance124.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance124.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance124.ForeColor = System.Drawing.Color.Black
        Appearance124.Image = CType(resources.GetObject("Appearance124.Image"), Object)
        Appearance124.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance124.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance124.TextVAlignAsString = "Bottom"
        Me.cmdDelSC7.Appearance = Appearance124
        Me.cmdDelSC7.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance125.BackColor = System.Drawing.Color.DarkOrange
        Appearance125.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance125.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance125.ForeColor = System.Drawing.Color.Black
        Me.cmdDelSC7.HotTrackAppearance = Appearance125
        Me.cmdDelSC7.ImageSize = New System.Drawing.Size(20, 20)
        Me.cmdDelSC7.Location = New System.Drawing.Point(660, 307)
        Me.cmdDelSC7.Name = "cmdDelSC7"
        Appearance126.BackColor = System.Drawing.Color.OrangeRed
        Appearance126.BackColor2 = System.Drawing.Color.Tomato
        Appearance126.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdDelSC7.PressedAppearance = Appearance126
        Me.cmdDelSC7.ShowFocusRect = False
        Me.cmdDelSC7.ShowOutline = False
        Me.cmdDelSC7.Size = New System.Drawing.Size(48, 31)
        Me.cmdDelSC7.TabIndex = 615
        Me.cmdDelSC7.Tag = "Back"
        Me.cmdDelSC7.UseAppStyling = False
        Me.cmdDelSC7.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDelSC7.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDelSC7.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDelSC6
        '
        Appearance127.BackColor = System.Drawing.Color.Transparent
        Appearance127.BackColor2 = System.Drawing.Color.Transparent
        Appearance127.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance127.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance127.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance127.ForeColor = System.Drawing.Color.Black
        Appearance127.Image = CType(resources.GetObject("Appearance127.Image"), Object)
        Appearance127.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance127.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance127.TextVAlignAsString = "Bottom"
        Me.cmdDelSC6.Appearance = Appearance127
        Me.cmdDelSC6.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance128.BackColor = System.Drawing.Color.DarkOrange
        Appearance128.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance128.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance128.ForeColor = System.Drawing.Color.Black
        Me.cmdDelSC6.HotTrackAppearance = Appearance128
        Me.cmdDelSC6.ImageSize = New System.Drawing.Size(20, 20)
        Me.cmdDelSC6.Location = New System.Drawing.Point(660, 270)
        Me.cmdDelSC6.Name = "cmdDelSC6"
        Appearance129.BackColor = System.Drawing.Color.OrangeRed
        Appearance129.BackColor2 = System.Drawing.Color.Tomato
        Appearance129.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdDelSC6.PressedAppearance = Appearance129
        Me.cmdDelSC6.ShowFocusRect = False
        Me.cmdDelSC6.ShowOutline = False
        Me.cmdDelSC6.Size = New System.Drawing.Size(48, 31)
        Me.cmdDelSC6.TabIndex = 614
        Me.cmdDelSC6.Tag = "Back"
        Me.cmdDelSC6.UseAppStyling = False
        Me.cmdDelSC6.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDelSC6.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDelSC6.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDelSC5
        '
        Appearance130.BackColor = System.Drawing.Color.Transparent
        Appearance130.BackColor2 = System.Drawing.Color.Transparent
        Appearance130.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance130.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance130.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance130.ForeColor = System.Drawing.Color.Black
        Appearance130.Image = CType(resources.GetObject("Appearance130.Image"), Object)
        Appearance130.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance130.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance130.TextVAlignAsString = "Bottom"
        Me.cmdDelSC5.Appearance = Appearance130
        Me.cmdDelSC5.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance131.BackColor = System.Drawing.Color.DarkOrange
        Appearance131.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance131.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance131.ForeColor = System.Drawing.Color.Black
        Me.cmdDelSC5.HotTrackAppearance = Appearance131
        Me.cmdDelSC5.ImageSize = New System.Drawing.Size(20, 20)
        Me.cmdDelSC5.Location = New System.Drawing.Point(660, 233)
        Me.cmdDelSC5.Name = "cmdDelSC5"
        Appearance132.BackColor = System.Drawing.Color.OrangeRed
        Appearance132.BackColor2 = System.Drawing.Color.Tomato
        Appearance132.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdDelSC5.PressedAppearance = Appearance132
        Me.cmdDelSC5.ShowFocusRect = False
        Me.cmdDelSC5.ShowOutline = False
        Me.cmdDelSC5.Size = New System.Drawing.Size(48, 31)
        Me.cmdDelSC5.TabIndex = 613
        Me.cmdDelSC5.Tag = "Back"
        Me.cmdDelSC5.UseAppStyling = False
        Me.cmdDelSC5.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDelSC5.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDelSC5.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDelSC4
        '
        Appearance133.BackColor = System.Drawing.Color.Transparent
        Appearance133.BackColor2 = System.Drawing.Color.Transparent
        Appearance133.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance133.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance133.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance133.ForeColor = System.Drawing.Color.Black
        Appearance133.Image = CType(resources.GetObject("Appearance133.Image"), Object)
        Appearance133.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance133.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance133.TextVAlignAsString = "Bottom"
        Me.cmdDelSC4.Appearance = Appearance133
        Me.cmdDelSC4.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance134.BackColor = System.Drawing.Color.DarkOrange
        Appearance134.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance134.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance134.ForeColor = System.Drawing.Color.Black
        Me.cmdDelSC4.HotTrackAppearance = Appearance134
        Me.cmdDelSC4.ImageSize = New System.Drawing.Size(20, 20)
        Me.cmdDelSC4.Location = New System.Drawing.Point(660, 196)
        Me.cmdDelSC4.Name = "cmdDelSC4"
        Appearance135.BackColor = System.Drawing.Color.OrangeRed
        Appearance135.BackColor2 = System.Drawing.Color.Tomato
        Appearance135.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdDelSC4.PressedAppearance = Appearance135
        Me.cmdDelSC4.ShowFocusRect = False
        Me.cmdDelSC4.ShowOutline = False
        Me.cmdDelSC4.Size = New System.Drawing.Size(48, 31)
        Me.cmdDelSC4.TabIndex = 612
        Me.cmdDelSC4.Tag = "Back"
        Me.cmdDelSC4.UseAppStyling = False
        Me.cmdDelSC4.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDelSC4.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDelSC4.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDelSC3
        '
        Appearance136.BackColor = System.Drawing.Color.Transparent
        Appearance136.BackColor2 = System.Drawing.Color.Transparent
        Appearance136.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance136.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance136.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance136.ForeColor = System.Drawing.Color.Black
        Appearance136.Image = CType(resources.GetObject("Appearance136.Image"), Object)
        Appearance136.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance136.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance136.TextVAlignAsString = "Bottom"
        Me.cmdDelSC3.Appearance = Appearance136
        Me.cmdDelSC3.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance137.BackColor = System.Drawing.Color.DarkOrange
        Appearance137.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance137.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance137.ForeColor = System.Drawing.Color.Black
        Me.cmdDelSC3.HotTrackAppearance = Appearance137
        Me.cmdDelSC3.ImageSize = New System.Drawing.Size(20, 20)
        Me.cmdDelSC3.Location = New System.Drawing.Point(660, 159)
        Me.cmdDelSC3.Name = "cmdDelSC3"
        Appearance138.BackColor = System.Drawing.Color.OrangeRed
        Appearance138.BackColor2 = System.Drawing.Color.Tomato
        Appearance138.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdDelSC3.PressedAppearance = Appearance138
        Me.cmdDelSC3.ShowFocusRect = False
        Me.cmdDelSC3.ShowOutline = False
        Me.cmdDelSC3.Size = New System.Drawing.Size(48, 31)
        Me.cmdDelSC3.TabIndex = 611
        Me.cmdDelSC3.Tag = "Back"
        Me.cmdDelSC3.UseAppStyling = False
        Me.cmdDelSC3.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDelSC3.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDelSC3.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDelSC2
        '
        Appearance139.BackColor = System.Drawing.Color.Transparent
        Appearance139.BackColor2 = System.Drawing.Color.Transparent
        Appearance139.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance139.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance139.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance139.ForeColor = System.Drawing.Color.Black
        Appearance139.Image = CType(resources.GetObject("Appearance139.Image"), Object)
        Appearance139.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance139.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance139.TextVAlignAsString = "Bottom"
        Me.cmdDelSC2.Appearance = Appearance139
        Me.cmdDelSC2.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance140.BackColor = System.Drawing.Color.DarkOrange
        Appearance140.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance140.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance140.ForeColor = System.Drawing.Color.Black
        Me.cmdDelSC2.HotTrackAppearance = Appearance140
        Me.cmdDelSC2.ImageSize = New System.Drawing.Size(20, 20)
        Me.cmdDelSC2.Location = New System.Drawing.Point(660, 122)
        Me.cmdDelSC2.Name = "cmdDelSC2"
        Appearance141.BackColor = System.Drawing.Color.OrangeRed
        Appearance141.BackColor2 = System.Drawing.Color.Tomato
        Appearance141.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdDelSC2.PressedAppearance = Appearance141
        Me.cmdDelSC2.ShowFocusRect = False
        Me.cmdDelSC2.ShowOutline = False
        Me.cmdDelSC2.Size = New System.Drawing.Size(48, 31)
        Me.cmdDelSC2.TabIndex = 610
        Me.cmdDelSC2.Tag = "Back"
        Me.cmdDelSC2.UseAppStyling = False
        Me.cmdDelSC2.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDelSC2.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDelSC2.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDelSC1
        '
        Appearance142.BackColor = System.Drawing.Color.Transparent
        Appearance142.BackColor2 = System.Drawing.Color.Transparent
        Appearance142.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance142.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance142.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance142.ForeColor = System.Drawing.Color.Black
        Appearance142.Image = CType(resources.GetObject("Appearance142.Image"), Object)
        Appearance142.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance142.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance142.TextVAlignAsString = "Bottom"
        Me.cmdDelSC1.Appearance = Appearance142
        Me.cmdDelSC1.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance143.BackColor = System.Drawing.Color.DarkOrange
        Appearance143.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance143.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance143.ForeColor = System.Drawing.Color.Black
        Me.cmdDelSC1.HotTrackAppearance = Appearance143
        Me.cmdDelSC1.ImageSize = New System.Drawing.Size(20, 20)
        Me.cmdDelSC1.Location = New System.Drawing.Point(660, 85)
        Me.cmdDelSC1.Name = "cmdDelSC1"
        Appearance144.BackColor = System.Drawing.Color.OrangeRed
        Appearance144.BackColor2 = System.Drawing.Color.Tomato
        Appearance144.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdDelSC1.PressedAppearance = Appearance144
        Me.cmdDelSC1.ShowFocusRect = False
        Me.cmdDelSC1.ShowOutline = False
        Me.cmdDelSC1.Size = New System.Drawing.Size(48, 31)
        Me.cmdDelSC1.TabIndex = 609
        Me.cmdDelSC1.Tag = "Back"
        Me.cmdDelSC1.UseAppStyling = False
        Me.cmdDelSC1.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDelSC1.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDelSC1.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblCuisine
        '
        Me.lblCuisine.BackColor = System.Drawing.Color.Transparent
        Me.lblCuisine.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCuisine.ForeColor = System.Drawing.Color.DimGray
        Me.lblCuisine.Location = New System.Drawing.Point(425, 62)
        Me.lblCuisine.Name = "lblCuisine"
        Me.lblCuisine.Size = New System.Drawing.Size(75, 22)
        Me.lblCuisine.TabIndex = 618
        Me.lblCuisine.Text = "Price Out"
        Me.lblCuisine.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.DimGray
        Me.Label1.Location = New System.Drawing.Point(312, 62)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(75, 22)
        Me.Label1.TabIndex = 619
        Me.Label1.Text = "Price In"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.DimGray
        Me.Label2.Location = New System.Drawing.Point(540, 60)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(75, 22)
        Me.Label2.TabIndex = 620
        Me.Label2.Text = "Short code"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblDCHeader
        '
        Me.lblDCHeader.BackColor = System.Drawing.Color.Transparent
        Me.lblDCHeader.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDCHeader.ForeColor = System.Drawing.Color.DimGray
        Me.lblDCHeader.Location = New System.Drawing.Point(116, 23)
        Me.lblDCHeader.Name = "lblDCHeader"
        Me.lblDCHeader.Size = New System.Drawing.Size(712, 22)
        Me.lblDCHeader.TabIndex = 621
        Me.lblDCHeader.Text = "<header>"
        Me.lblDCHeader.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.DimGray
        Me.Label3.Location = New System.Drawing.Point(714, 62)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(75, 22)
        Me.Label3.TabIndex = 649
        Me.Label3.Text = "Short name"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cmdDelSN9
        '
        Appearance145.BackColor = System.Drawing.Color.Transparent
        Appearance145.BackColor2 = System.Drawing.Color.Transparent
        Appearance145.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance145.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance145.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance145.ForeColor = System.Drawing.Color.Black
        Appearance145.Image = CType(resources.GetObject("Appearance145.Image"), Object)
        Appearance145.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance145.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance145.TextVAlignAsString = "Bottom"
        Me.cmdDelSN9.Appearance = Appearance145
        Me.cmdDelSN9.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance146.BackColor = System.Drawing.Color.DarkOrange
        Appearance146.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance146.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance146.ForeColor = System.Drawing.Color.Black
        Me.cmdDelSN9.HotTrackAppearance = Appearance146
        Me.cmdDelSN9.ImageSize = New System.Drawing.Size(20, 20)
        Me.cmdDelSN9.Location = New System.Drawing.Point(883, 381)
        Me.cmdDelSN9.Name = "cmdDelSN9"
        Appearance147.BackColor = System.Drawing.Color.OrangeRed
        Appearance147.BackColor2 = System.Drawing.Color.Tomato
        Appearance147.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdDelSN9.PressedAppearance = Appearance147
        Me.cmdDelSN9.ShowFocusRect = False
        Me.cmdDelSN9.ShowOutline = False
        Me.cmdDelSN9.Size = New System.Drawing.Size(48, 31)
        Me.cmdDelSN9.TabIndex = 648
        Me.cmdDelSN9.Tag = "Back"
        Me.cmdDelSN9.UseAppStyling = False
        Me.cmdDelSN9.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDelSN9.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDelSN9.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDelSN8
        '
        Appearance148.BackColor = System.Drawing.Color.Transparent
        Appearance148.BackColor2 = System.Drawing.Color.Transparent
        Appearance148.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance148.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance148.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance148.ForeColor = System.Drawing.Color.Black
        Appearance148.Image = CType(resources.GetObject("Appearance148.Image"), Object)
        Appearance148.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance148.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance148.TextVAlignAsString = "Bottom"
        Me.cmdDelSN8.Appearance = Appearance148
        Me.cmdDelSN8.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance149.BackColor = System.Drawing.Color.DarkOrange
        Appearance149.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance149.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance149.ForeColor = System.Drawing.Color.Black
        Me.cmdDelSN8.HotTrackAppearance = Appearance149
        Me.cmdDelSN8.ImageSize = New System.Drawing.Size(20, 20)
        Me.cmdDelSN8.Location = New System.Drawing.Point(883, 344)
        Me.cmdDelSN8.Name = "cmdDelSN8"
        Appearance150.BackColor = System.Drawing.Color.OrangeRed
        Appearance150.BackColor2 = System.Drawing.Color.Tomato
        Appearance150.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdDelSN8.PressedAppearance = Appearance150
        Me.cmdDelSN8.ShowFocusRect = False
        Me.cmdDelSN8.ShowOutline = False
        Me.cmdDelSN8.Size = New System.Drawing.Size(48, 31)
        Me.cmdDelSN8.TabIndex = 647
        Me.cmdDelSN8.Tag = "Back"
        Me.cmdDelSN8.UseAppStyling = False
        Me.cmdDelSN8.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDelSN8.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDelSN8.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDelSN7
        '
        Appearance151.BackColor = System.Drawing.Color.Transparent
        Appearance151.BackColor2 = System.Drawing.Color.Transparent
        Appearance151.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance151.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance151.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance151.ForeColor = System.Drawing.Color.Black
        Appearance151.Image = CType(resources.GetObject("Appearance151.Image"), Object)
        Appearance151.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance151.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance151.TextVAlignAsString = "Bottom"
        Me.cmdDelSN7.Appearance = Appearance151
        Me.cmdDelSN7.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance152.BackColor = System.Drawing.Color.DarkOrange
        Appearance152.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance152.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance152.ForeColor = System.Drawing.Color.Black
        Me.cmdDelSN7.HotTrackAppearance = Appearance152
        Me.cmdDelSN7.ImageSize = New System.Drawing.Size(20, 20)
        Me.cmdDelSN7.Location = New System.Drawing.Point(883, 307)
        Me.cmdDelSN7.Name = "cmdDelSN7"
        Appearance153.BackColor = System.Drawing.Color.OrangeRed
        Appearance153.BackColor2 = System.Drawing.Color.Tomato
        Appearance153.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdDelSN7.PressedAppearance = Appearance153
        Me.cmdDelSN7.ShowFocusRect = False
        Me.cmdDelSN7.ShowOutline = False
        Me.cmdDelSN7.Size = New System.Drawing.Size(48, 31)
        Me.cmdDelSN7.TabIndex = 646
        Me.cmdDelSN7.Tag = "Back"
        Me.cmdDelSN7.UseAppStyling = False
        Me.cmdDelSN7.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDelSN7.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDelSN7.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDelSN6
        '
        Appearance154.BackColor = System.Drawing.Color.Transparent
        Appearance154.BackColor2 = System.Drawing.Color.Transparent
        Appearance154.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance154.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance154.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance154.ForeColor = System.Drawing.Color.Black
        Appearance154.Image = CType(resources.GetObject("Appearance154.Image"), Object)
        Appearance154.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance154.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance154.TextVAlignAsString = "Bottom"
        Me.cmdDelSN6.Appearance = Appearance154
        Me.cmdDelSN6.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance155.BackColor = System.Drawing.Color.DarkOrange
        Appearance155.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance155.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance155.ForeColor = System.Drawing.Color.Black
        Me.cmdDelSN6.HotTrackAppearance = Appearance155
        Me.cmdDelSN6.ImageSize = New System.Drawing.Size(20, 20)
        Me.cmdDelSN6.Location = New System.Drawing.Point(883, 270)
        Me.cmdDelSN6.Name = "cmdDelSN6"
        Appearance156.BackColor = System.Drawing.Color.OrangeRed
        Appearance156.BackColor2 = System.Drawing.Color.Tomato
        Appearance156.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdDelSN6.PressedAppearance = Appearance156
        Me.cmdDelSN6.ShowFocusRect = False
        Me.cmdDelSN6.ShowOutline = False
        Me.cmdDelSN6.Size = New System.Drawing.Size(48, 31)
        Me.cmdDelSN6.TabIndex = 645
        Me.cmdDelSN6.Tag = "Back"
        Me.cmdDelSN6.UseAppStyling = False
        Me.cmdDelSN6.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDelSN6.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDelSN6.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDelSN5
        '
        Appearance157.BackColor = System.Drawing.Color.Transparent
        Appearance157.BackColor2 = System.Drawing.Color.Transparent
        Appearance157.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance157.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance157.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance157.ForeColor = System.Drawing.Color.Black
        Appearance157.Image = CType(resources.GetObject("Appearance157.Image"), Object)
        Appearance157.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance157.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance157.TextVAlignAsString = "Bottom"
        Me.cmdDelSN5.Appearance = Appearance157
        Me.cmdDelSN5.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance158.BackColor = System.Drawing.Color.DarkOrange
        Appearance158.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance158.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance158.ForeColor = System.Drawing.Color.Black
        Me.cmdDelSN5.HotTrackAppearance = Appearance158
        Me.cmdDelSN5.ImageSize = New System.Drawing.Size(20, 20)
        Me.cmdDelSN5.Location = New System.Drawing.Point(883, 233)
        Me.cmdDelSN5.Name = "cmdDelSN5"
        Appearance159.BackColor = System.Drawing.Color.OrangeRed
        Appearance159.BackColor2 = System.Drawing.Color.Tomato
        Appearance159.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdDelSN5.PressedAppearance = Appearance159
        Me.cmdDelSN5.ShowFocusRect = False
        Me.cmdDelSN5.ShowOutline = False
        Me.cmdDelSN5.Size = New System.Drawing.Size(48, 31)
        Me.cmdDelSN5.TabIndex = 644
        Me.cmdDelSN5.Tag = "Back"
        Me.cmdDelSN5.UseAppStyling = False
        Me.cmdDelSN5.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDelSN5.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDelSN5.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDelSN4
        '
        Appearance160.BackColor = System.Drawing.Color.Transparent
        Appearance160.BackColor2 = System.Drawing.Color.Transparent
        Appearance160.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance160.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance160.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance160.ForeColor = System.Drawing.Color.Black
        Appearance160.Image = CType(resources.GetObject("Appearance160.Image"), Object)
        Appearance160.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance160.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance160.TextVAlignAsString = "Bottom"
        Me.cmdDelSN4.Appearance = Appearance160
        Me.cmdDelSN4.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance161.BackColor = System.Drawing.Color.DarkOrange
        Appearance161.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance161.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance161.ForeColor = System.Drawing.Color.Black
        Me.cmdDelSN4.HotTrackAppearance = Appearance161
        Me.cmdDelSN4.ImageSize = New System.Drawing.Size(20, 20)
        Me.cmdDelSN4.Location = New System.Drawing.Point(883, 196)
        Me.cmdDelSN4.Name = "cmdDelSN4"
        Appearance162.BackColor = System.Drawing.Color.OrangeRed
        Appearance162.BackColor2 = System.Drawing.Color.Tomato
        Appearance162.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdDelSN4.PressedAppearance = Appearance162
        Me.cmdDelSN4.ShowFocusRect = False
        Me.cmdDelSN4.ShowOutline = False
        Me.cmdDelSN4.Size = New System.Drawing.Size(48, 31)
        Me.cmdDelSN4.TabIndex = 643
        Me.cmdDelSN4.Tag = "Back"
        Me.cmdDelSN4.UseAppStyling = False
        Me.cmdDelSN4.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDelSN4.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDelSN4.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDelSN3
        '
        Appearance163.BackColor = System.Drawing.Color.Transparent
        Appearance163.BackColor2 = System.Drawing.Color.Transparent
        Appearance163.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance163.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance163.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance163.ForeColor = System.Drawing.Color.Black
        Appearance163.Image = CType(resources.GetObject("Appearance163.Image"), Object)
        Appearance163.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance163.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance163.TextVAlignAsString = "Bottom"
        Me.cmdDelSN3.Appearance = Appearance163
        Me.cmdDelSN3.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance164.BackColor = System.Drawing.Color.DarkOrange
        Appearance164.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance164.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance164.ForeColor = System.Drawing.Color.Black
        Me.cmdDelSN3.HotTrackAppearance = Appearance164
        Me.cmdDelSN3.ImageSize = New System.Drawing.Size(20, 20)
        Me.cmdDelSN3.Location = New System.Drawing.Point(883, 159)
        Me.cmdDelSN3.Name = "cmdDelSN3"
        Appearance165.BackColor = System.Drawing.Color.OrangeRed
        Appearance165.BackColor2 = System.Drawing.Color.Tomato
        Appearance165.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdDelSN3.PressedAppearance = Appearance165
        Me.cmdDelSN3.ShowFocusRect = False
        Me.cmdDelSN3.ShowOutline = False
        Me.cmdDelSN3.Size = New System.Drawing.Size(48, 31)
        Me.cmdDelSN3.TabIndex = 642
        Me.cmdDelSN3.Tag = "Back"
        Me.cmdDelSN3.UseAppStyling = False
        Me.cmdDelSN3.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDelSN3.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDelSN3.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDelSN2
        '
        Appearance166.BackColor = System.Drawing.Color.Transparent
        Appearance166.BackColor2 = System.Drawing.Color.Transparent
        Appearance166.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance166.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance166.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance166.ForeColor = System.Drawing.Color.Black
        Appearance166.Image = CType(resources.GetObject("Appearance166.Image"), Object)
        Appearance166.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance166.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance166.TextVAlignAsString = "Bottom"
        Me.cmdDelSN2.Appearance = Appearance166
        Me.cmdDelSN2.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance167.BackColor = System.Drawing.Color.DarkOrange
        Appearance167.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance167.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance167.ForeColor = System.Drawing.Color.Black
        Me.cmdDelSN2.HotTrackAppearance = Appearance167
        Me.cmdDelSN2.ImageSize = New System.Drawing.Size(20, 20)
        Me.cmdDelSN2.Location = New System.Drawing.Point(883, 122)
        Me.cmdDelSN2.Name = "cmdDelSN2"
        Appearance168.BackColor = System.Drawing.Color.OrangeRed
        Appearance168.BackColor2 = System.Drawing.Color.Tomato
        Appearance168.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdDelSN2.PressedAppearance = Appearance168
        Me.cmdDelSN2.ShowFocusRect = False
        Me.cmdDelSN2.ShowOutline = False
        Me.cmdDelSN2.Size = New System.Drawing.Size(48, 31)
        Me.cmdDelSN2.TabIndex = 641
        Me.cmdDelSN2.Tag = "Back"
        Me.cmdDelSN2.UseAppStyling = False
        Me.cmdDelSN2.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDelSN2.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDelSN2.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDelSN1
        '
        Appearance169.BackColor = System.Drawing.Color.Transparent
        Appearance169.BackColor2 = System.Drawing.Color.Transparent
        Appearance169.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance169.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance169.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance169.ForeColor = System.Drawing.Color.Black
        Appearance169.Image = CType(resources.GetObject("Appearance169.Image"), Object)
        Appearance169.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance169.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance169.TextVAlignAsString = "Bottom"
        Me.cmdDelSN1.Appearance = Appearance169
        Me.cmdDelSN1.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance170.BackColor = System.Drawing.Color.DarkOrange
        Appearance170.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance170.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance170.ForeColor = System.Drawing.Color.Black
        Me.cmdDelSN1.HotTrackAppearance = Appearance170
        Me.cmdDelSN1.ImageSize = New System.Drawing.Size(20, 20)
        Me.cmdDelSN1.Location = New System.Drawing.Point(883, 85)
        Me.cmdDelSN1.Name = "cmdDelSN1"
        Appearance171.BackColor = System.Drawing.Color.OrangeRed
        Appearance171.BackColor2 = System.Drawing.Color.Tomato
        Appearance171.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdDelSN1.PressedAppearance = Appearance171
        Me.cmdDelSN1.ShowFocusRect = False
        Me.cmdDelSN1.ShowOutline = False
        Me.cmdDelSN1.Size = New System.Drawing.Size(48, 31)
        Me.cmdDelSN1.TabIndex = 640
        Me.cmdDelSN1.Tag = "Back"
        Me.cmdDelSN1.UseAppStyling = False
        Me.cmdDelSN1.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDelSN1.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDelSN1.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdKBSN9
        '
        Appearance172.BackColor = System.Drawing.Color.Transparent
        Appearance172.BackColor2 = System.Drawing.Color.Transparent
        Appearance172.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance172.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance172.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance172.ForeColor = System.Drawing.Color.Black
        Appearance172.Image = CType(resources.GetObject("Appearance172.Image"), Object)
        Appearance172.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance172.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance172.TextVAlignAsString = "Bottom"
        Me.cmdKBSN9.Appearance = Appearance172
        Me.cmdKBSN9.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance173.BackColor = System.Drawing.Color.DarkOrange
        Appearance173.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance173.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance173.ForeColor = System.Drawing.Color.Black
        Me.cmdKBSN9.HotTrackAppearance = Appearance173
        Me.cmdKBSN9.ImageSize = New System.Drawing.Size(30, 18)
        Me.cmdKBSN9.Location = New System.Drawing.Point(829, 381)
        Me.cmdKBSN9.Name = "cmdKBSN9"
        Appearance174.BackColor = System.Drawing.Color.OrangeRed
        Appearance174.BackColor2 = System.Drawing.Color.Tomato
        Appearance174.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdKBSN9.PressedAppearance = Appearance174
        Me.cmdKBSN9.ShowFocusRect = False
        Me.cmdKBSN9.ShowOutline = False
        Me.cmdKBSN9.Size = New System.Drawing.Size(48, 31)
        Me.cmdKBSN9.TabIndex = 639
        Me.cmdKBSN9.Tag = "Back"
        Me.cmdKBSN9.UseAppStyling = False
        Me.cmdKBSN9.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBSN9.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBSN9.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdKBSN8
        '
        Appearance175.BackColor = System.Drawing.Color.Transparent
        Appearance175.BackColor2 = System.Drawing.Color.Transparent
        Appearance175.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance175.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance175.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance175.ForeColor = System.Drawing.Color.Black
        Appearance175.Image = CType(resources.GetObject("Appearance175.Image"), Object)
        Appearance175.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance175.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance175.TextVAlignAsString = "Bottom"
        Me.cmdKBSN8.Appearance = Appearance175
        Me.cmdKBSN8.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance176.BackColor = System.Drawing.Color.DarkOrange
        Appearance176.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance176.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance176.ForeColor = System.Drawing.Color.Black
        Me.cmdKBSN8.HotTrackAppearance = Appearance176
        Me.cmdKBSN8.ImageSize = New System.Drawing.Size(30, 18)
        Me.cmdKBSN8.Location = New System.Drawing.Point(829, 344)
        Me.cmdKBSN8.Name = "cmdKBSN8"
        Appearance177.BackColor = System.Drawing.Color.OrangeRed
        Appearance177.BackColor2 = System.Drawing.Color.Tomato
        Appearance177.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdKBSN8.PressedAppearance = Appearance177
        Me.cmdKBSN8.ShowFocusRect = False
        Me.cmdKBSN8.ShowOutline = False
        Me.cmdKBSN8.Size = New System.Drawing.Size(48, 31)
        Me.cmdKBSN8.TabIndex = 638
        Me.cmdKBSN8.Tag = "Back"
        Me.cmdKBSN8.UseAppStyling = False
        Me.cmdKBSN8.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBSN8.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBSN8.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdKBSN7
        '
        Appearance178.BackColor = System.Drawing.Color.Transparent
        Appearance178.BackColor2 = System.Drawing.Color.Transparent
        Appearance178.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance178.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance178.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance178.ForeColor = System.Drawing.Color.Black
        Appearance178.Image = CType(resources.GetObject("Appearance178.Image"), Object)
        Appearance178.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance178.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance178.TextVAlignAsString = "Bottom"
        Me.cmdKBSN7.Appearance = Appearance178
        Me.cmdKBSN7.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance179.BackColor = System.Drawing.Color.DarkOrange
        Appearance179.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance179.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance179.ForeColor = System.Drawing.Color.Black
        Me.cmdKBSN7.HotTrackAppearance = Appearance179
        Me.cmdKBSN7.ImageSize = New System.Drawing.Size(30, 18)
        Me.cmdKBSN7.Location = New System.Drawing.Point(829, 307)
        Me.cmdKBSN7.Name = "cmdKBSN7"
        Appearance180.BackColor = System.Drawing.Color.OrangeRed
        Appearance180.BackColor2 = System.Drawing.Color.Tomato
        Appearance180.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdKBSN7.PressedAppearance = Appearance180
        Me.cmdKBSN7.ShowFocusRect = False
        Me.cmdKBSN7.ShowOutline = False
        Me.cmdKBSN7.Size = New System.Drawing.Size(48, 31)
        Me.cmdKBSN7.TabIndex = 637
        Me.cmdKBSN7.Tag = "Back"
        Me.cmdKBSN7.UseAppStyling = False
        Me.cmdKBSN7.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBSN7.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBSN7.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdKBSN6
        '
        Appearance181.BackColor = System.Drawing.Color.Transparent
        Appearance181.BackColor2 = System.Drawing.Color.Transparent
        Appearance181.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance181.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance181.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance181.ForeColor = System.Drawing.Color.Black
        Appearance181.Image = CType(resources.GetObject("Appearance181.Image"), Object)
        Appearance181.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance181.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance181.TextVAlignAsString = "Bottom"
        Me.cmdKBSN6.Appearance = Appearance181
        Me.cmdKBSN6.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance182.BackColor = System.Drawing.Color.DarkOrange
        Appearance182.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance182.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance182.ForeColor = System.Drawing.Color.Black
        Me.cmdKBSN6.HotTrackAppearance = Appearance182
        Me.cmdKBSN6.ImageSize = New System.Drawing.Size(30, 18)
        Me.cmdKBSN6.Location = New System.Drawing.Point(829, 270)
        Me.cmdKBSN6.Name = "cmdKBSN6"
        Appearance183.BackColor = System.Drawing.Color.OrangeRed
        Appearance183.BackColor2 = System.Drawing.Color.Tomato
        Appearance183.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdKBSN6.PressedAppearance = Appearance183
        Me.cmdKBSN6.ShowFocusRect = False
        Me.cmdKBSN6.ShowOutline = False
        Me.cmdKBSN6.Size = New System.Drawing.Size(48, 31)
        Me.cmdKBSN6.TabIndex = 636
        Me.cmdKBSN6.Tag = "Back"
        Me.cmdKBSN6.UseAppStyling = False
        Me.cmdKBSN6.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBSN6.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBSN6.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdKBSN5
        '
        Appearance184.BackColor = System.Drawing.Color.Transparent
        Appearance184.BackColor2 = System.Drawing.Color.Transparent
        Appearance184.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance184.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance184.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance184.ForeColor = System.Drawing.Color.Black
        Appearance184.Image = CType(resources.GetObject("Appearance184.Image"), Object)
        Appearance184.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance184.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance184.TextVAlignAsString = "Bottom"
        Me.cmdKBSN5.Appearance = Appearance184
        Me.cmdKBSN5.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance185.BackColor = System.Drawing.Color.DarkOrange
        Appearance185.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance185.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance185.ForeColor = System.Drawing.Color.Black
        Me.cmdKBSN5.HotTrackAppearance = Appearance185
        Me.cmdKBSN5.ImageSize = New System.Drawing.Size(30, 18)
        Me.cmdKBSN5.Location = New System.Drawing.Point(829, 233)
        Me.cmdKBSN5.Name = "cmdKBSN5"
        Appearance186.BackColor = System.Drawing.Color.OrangeRed
        Appearance186.BackColor2 = System.Drawing.Color.Tomato
        Appearance186.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdKBSN5.PressedAppearance = Appearance186
        Me.cmdKBSN5.ShowFocusRect = False
        Me.cmdKBSN5.ShowOutline = False
        Me.cmdKBSN5.Size = New System.Drawing.Size(48, 31)
        Me.cmdKBSN5.TabIndex = 635
        Me.cmdKBSN5.Tag = "Back"
        Me.cmdKBSN5.UseAppStyling = False
        Me.cmdKBSN5.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBSN5.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBSN5.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdKBSN4
        '
        Appearance187.BackColor = System.Drawing.Color.Transparent
        Appearance187.BackColor2 = System.Drawing.Color.Transparent
        Appearance187.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance187.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance187.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance187.ForeColor = System.Drawing.Color.Black
        Appearance187.Image = CType(resources.GetObject("Appearance187.Image"), Object)
        Appearance187.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance187.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance187.TextVAlignAsString = "Bottom"
        Me.cmdKBSN4.Appearance = Appearance187
        Me.cmdKBSN4.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance188.BackColor = System.Drawing.Color.DarkOrange
        Appearance188.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance188.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance188.ForeColor = System.Drawing.Color.Black
        Me.cmdKBSN4.HotTrackAppearance = Appearance188
        Me.cmdKBSN4.ImageSize = New System.Drawing.Size(30, 18)
        Me.cmdKBSN4.Location = New System.Drawing.Point(829, 196)
        Me.cmdKBSN4.Name = "cmdKBSN4"
        Appearance189.BackColor = System.Drawing.Color.OrangeRed
        Appearance189.BackColor2 = System.Drawing.Color.Tomato
        Appearance189.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdKBSN4.PressedAppearance = Appearance189
        Me.cmdKBSN4.ShowFocusRect = False
        Me.cmdKBSN4.ShowOutline = False
        Me.cmdKBSN4.Size = New System.Drawing.Size(48, 31)
        Me.cmdKBSN4.TabIndex = 634
        Me.cmdKBSN4.Tag = "Back"
        Me.cmdKBSN4.UseAppStyling = False
        Me.cmdKBSN4.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBSN4.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBSN4.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdKBSN3
        '
        Appearance190.BackColor = System.Drawing.Color.Transparent
        Appearance190.BackColor2 = System.Drawing.Color.Transparent
        Appearance190.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance190.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance190.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance190.ForeColor = System.Drawing.Color.Black
        Appearance190.Image = CType(resources.GetObject("Appearance190.Image"), Object)
        Appearance190.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance190.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance190.TextVAlignAsString = "Bottom"
        Me.cmdKBSN3.Appearance = Appearance190
        Me.cmdKBSN3.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance191.BackColor = System.Drawing.Color.DarkOrange
        Appearance191.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance191.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance191.ForeColor = System.Drawing.Color.Black
        Me.cmdKBSN3.HotTrackAppearance = Appearance191
        Me.cmdKBSN3.ImageSize = New System.Drawing.Size(30, 18)
        Me.cmdKBSN3.Location = New System.Drawing.Point(829, 159)
        Me.cmdKBSN3.Name = "cmdKBSN3"
        Appearance192.BackColor = System.Drawing.Color.OrangeRed
        Appearance192.BackColor2 = System.Drawing.Color.Tomato
        Appearance192.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdKBSN3.PressedAppearance = Appearance192
        Me.cmdKBSN3.ShowFocusRect = False
        Me.cmdKBSN3.ShowOutline = False
        Me.cmdKBSN3.Size = New System.Drawing.Size(48, 31)
        Me.cmdKBSN3.TabIndex = 633
        Me.cmdKBSN3.Tag = "Back"
        Me.cmdKBSN3.UseAppStyling = False
        Me.cmdKBSN3.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBSN3.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBSN3.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdKBSN2
        '
        Appearance193.BackColor = System.Drawing.Color.Transparent
        Appearance193.BackColor2 = System.Drawing.Color.Transparent
        Appearance193.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance193.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance193.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance193.ForeColor = System.Drawing.Color.Black
        Appearance193.Image = CType(resources.GetObject("Appearance193.Image"), Object)
        Appearance193.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance193.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance193.TextVAlignAsString = "Bottom"
        Me.cmdKBSN2.Appearance = Appearance193
        Me.cmdKBSN2.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance194.BackColor = System.Drawing.Color.DarkOrange
        Appearance194.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance194.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance194.ForeColor = System.Drawing.Color.Black
        Me.cmdKBSN2.HotTrackAppearance = Appearance194
        Me.cmdKBSN2.ImageSize = New System.Drawing.Size(30, 18)
        Me.cmdKBSN2.Location = New System.Drawing.Point(829, 122)
        Me.cmdKBSN2.Name = "cmdKBSN2"
        Appearance195.BackColor = System.Drawing.Color.OrangeRed
        Appearance195.BackColor2 = System.Drawing.Color.Tomato
        Appearance195.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdKBSN2.PressedAppearance = Appearance195
        Me.cmdKBSN2.ShowFocusRect = False
        Me.cmdKBSN2.ShowOutline = False
        Me.cmdKBSN2.Size = New System.Drawing.Size(48, 31)
        Me.cmdKBSN2.TabIndex = 632
        Me.cmdKBSN2.Tag = "Back"
        Me.cmdKBSN2.UseAppStyling = False
        Me.cmdKBSN2.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBSN2.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBSN2.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdKBSN1
        '
        Appearance196.BackColor = System.Drawing.Color.Transparent
        Appearance196.BackColor2 = System.Drawing.Color.Transparent
        Appearance196.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance196.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance196.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance196.ForeColor = System.Drawing.Color.Black
        Appearance196.Image = CType(resources.GetObject("Appearance196.Image"), Object)
        Appearance196.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance196.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance196.TextVAlignAsString = "Bottom"
        Me.cmdKBSN1.Appearance = Appearance196
        Me.cmdKBSN1.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance197.BackColor = System.Drawing.Color.DarkOrange
        Appearance197.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance197.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance197.ForeColor = System.Drawing.Color.Black
        Me.cmdKBSN1.HotTrackAppearance = Appearance197
        Me.cmdKBSN1.ImageSize = New System.Drawing.Size(30, 18)
        Me.cmdKBSN1.Location = New System.Drawing.Point(829, 85)
        Me.cmdKBSN1.Name = "cmdKBSN1"
        Appearance198.BackColor = System.Drawing.Color.OrangeRed
        Appearance198.BackColor2 = System.Drawing.Color.Tomato
        Appearance198.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdKBSN1.PressedAppearance = Appearance198
        Me.cmdKBSN1.ShowFocusRect = False
        Me.cmdKBSN1.ShowOutline = False
        Me.cmdKBSN1.Size = New System.Drawing.Size(48, 31)
        Me.cmdKBSN1.TabIndex = 631
        Me.cmdKBSN1.Tag = "Back"
        Me.cmdKBSN1.UseAppStyling = False
        Me.cmdKBSN1.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBSN1.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBSN1.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtShortName9
        '
        Appearance199.TextHAlignAsString = "Right"
        Me.txtShortName9.Appearance = Appearance199
        Me.txtShortName9.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtShortName9.Location = New System.Drawing.Point(714, 383)
        Me.txtShortName9.MaxLength = 50
        Me.txtShortName9.Name = "txtShortName9"
        Me.txtShortName9.Size = New System.Drawing.Size(109, 26)
        Me.txtShortName9.TabIndex = 630
        Me.txtShortName9.UseAppStyling = False
        '
        'txtShortName8
        '
        Appearance200.TextHAlignAsString = "Right"
        Me.txtShortName8.Appearance = Appearance200
        Me.txtShortName8.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtShortName8.Location = New System.Drawing.Point(714, 346)
        Me.txtShortName8.MaxLength = 50
        Me.txtShortName8.Name = "txtShortName8"
        Me.txtShortName8.Size = New System.Drawing.Size(109, 26)
        Me.txtShortName8.TabIndex = 629
        Me.txtShortName8.UseAppStyling = False
        '
        'txtShortName7
        '
        Appearance201.TextHAlignAsString = "Right"
        Me.txtShortName7.Appearance = Appearance201
        Me.txtShortName7.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtShortName7.Location = New System.Drawing.Point(714, 309)
        Me.txtShortName7.MaxLength = 50
        Me.txtShortName7.Name = "txtShortName7"
        Me.txtShortName7.Size = New System.Drawing.Size(109, 26)
        Me.txtShortName7.TabIndex = 628
        Me.txtShortName7.UseAppStyling = False
        '
        'txtShortName6
        '
        Appearance202.TextHAlignAsString = "Right"
        Me.txtShortName6.Appearance = Appearance202
        Me.txtShortName6.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtShortName6.Location = New System.Drawing.Point(714, 272)
        Me.txtShortName6.MaxLength = 50
        Me.txtShortName6.Name = "txtShortName6"
        Me.txtShortName6.Size = New System.Drawing.Size(109, 26)
        Me.txtShortName6.TabIndex = 627
        Me.txtShortName6.UseAppStyling = False
        '
        'txtShortName5
        '
        Appearance203.TextHAlignAsString = "Right"
        Me.txtShortName5.Appearance = Appearance203
        Me.txtShortName5.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtShortName5.Location = New System.Drawing.Point(714, 235)
        Me.txtShortName5.MaxLength = 50
        Me.txtShortName5.Name = "txtShortName5"
        Me.txtShortName5.Size = New System.Drawing.Size(109, 26)
        Me.txtShortName5.TabIndex = 626
        Me.txtShortName5.UseAppStyling = False
        '
        'txtShortName4
        '
        Appearance204.TextHAlignAsString = "Right"
        Me.txtShortName4.Appearance = Appearance204
        Me.txtShortName4.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtShortName4.Location = New System.Drawing.Point(714, 198)
        Me.txtShortName4.MaxLength = 50
        Me.txtShortName4.Name = "txtShortName4"
        Me.txtShortName4.Size = New System.Drawing.Size(109, 26)
        Me.txtShortName4.TabIndex = 625
        Me.txtShortName4.UseAppStyling = False
        '
        'txtShortName3
        '
        Appearance205.TextHAlignAsString = "Right"
        Me.txtShortName3.Appearance = Appearance205
        Me.txtShortName3.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtShortName3.Location = New System.Drawing.Point(714, 161)
        Me.txtShortName3.MaxLength = 50
        Me.txtShortName3.Name = "txtShortName3"
        Me.txtShortName3.Size = New System.Drawing.Size(109, 26)
        Me.txtShortName3.TabIndex = 624
        Me.txtShortName3.UseAppStyling = False
        '
        'txtShortName2
        '
        Appearance206.TextHAlignAsString = "Right"
        Me.txtShortName2.Appearance = Appearance206
        Me.txtShortName2.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtShortName2.Location = New System.Drawing.Point(714, 124)
        Me.txtShortName2.MaxLength = 50
        Me.txtShortName2.Name = "txtShortName2"
        Me.txtShortName2.Size = New System.Drawing.Size(109, 26)
        Me.txtShortName2.TabIndex = 623
        Me.txtShortName2.UseAppStyling = False
        '
        'txtShortName1
        '
        Appearance207.TextHAlignAsString = "Right"
        Me.txtShortName1.Appearance = Appearance207
        Me.txtShortName1.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtShortName1.Location = New System.Drawing.Point(714, 87)
        Me.txtShortName1.MaxLength = 50
        Me.txtShortName1.Name = "txtShortName1"
        Me.txtShortName1.Size = New System.Drawing.Size(109, 26)
        Me.txtShortName1.TabIndex = 622
        Me.txtShortName1.UseAppStyling = False
        '
        'cmdKBName9
        '
        Appearance208.BackColor = System.Drawing.Color.Transparent
        Appearance208.BackColor2 = System.Drawing.Color.Transparent
        Appearance208.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance208.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance208.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance208.BorderColor2 = System.Drawing.Color.Maroon
        Appearance208.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance208.ForeColor = System.Drawing.Color.Black
        Appearance208.Image = CType(resources.GetObject("Appearance208.Image"), Object)
        Appearance208.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance208.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance208.TextVAlignAsString = "Bottom"
        Me.cmdKBName9.Appearance = Appearance208
        Me.cmdKBName9.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance209.BackColor = System.Drawing.Color.DarkOrange
        Appearance209.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance209.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance209.ForeColor = System.Drawing.Color.Black
        Me.cmdKBName9.HotTrackAppearance = Appearance209
        Me.cmdKBName9.ImageSize = New System.Drawing.Size(30, 18)
        Me.cmdKBName9.Location = New System.Drawing.Point(261, 381)
        Me.cmdKBName9.Name = "cmdKBName9"
        Appearance210.BackColor = System.Drawing.Color.OrangeRed
        Appearance210.BackColor2 = System.Drawing.Color.Tomato
        Appearance210.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdKBName9.PressedAppearance = Appearance210
        Me.cmdKBName9.ShowFocusRect = False
        Me.cmdKBName9.ShowOutline = False
        Me.cmdKBName9.Size = New System.Drawing.Size(48, 31)
        Me.cmdKBName9.TabIndex = 658
        Me.cmdKBName9.Tag = "Back"
        Me.cmdKBName9.UseAppStyling = False
        Me.cmdKBName9.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBName9.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBName9.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdKBName8
        '
        Appearance211.BackColor = System.Drawing.Color.Transparent
        Appearance211.BackColor2 = System.Drawing.Color.Transparent
        Appearance211.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance211.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance211.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance211.BorderColor2 = System.Drawing.Color.Maroon
        Appearance211.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance211.ForeColor = System.Drawing.Color.Black
        Appearance211.Image = CType(resources.GetObject("Appearance211.Image"), Object)
        Appearance211.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance211.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance211.TextVAlignAsString = "Bottom"
        Me.cmdKBName8.Appearance = Appearance211
        Me.cmdKBName8.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance212.BackColor = System.Drawing.Color.DarkOrange
        Appearance212.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance212.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance212.ForeColor = System.Drawing.Color.Black
        Me.cmdKBName8.HotTrackAppearance = Appearance212
        Me.cmdKBName8.ImageSize = New System.Drawing.Size(30, 18)
        Me.cmdKBName8.Location = New System.Drawing.Point(261, 344)
        Me.cmdKBName8.Name = "cmdKBName8"
        Appearance213.BackColor = System.Drawing.Color.OrangeRed
        Appearance213.BackColor2 = System.Drawing.Color.Tomato
        Appearance213.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdKBName8.PressedAppearance = Appearance213
        Me.cmdKBName8.ShowFocusRect = False
        Me.cmdKBName8.ShowOutline = False
        Me.cmdKBName8.Size = New System.Drawing.Size(48, 31)
        Me.cmdKBName8.TabIndex = 657
        Me.cmdKBName8.Tag = "Back"
        Me.cmdKBName8.UseAppStyling = False
        Me.cmdKBName8.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBName8.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBName8.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdKBName7
        '
        Appearance214.BackColor = System.Drawing.Color.Transparent
        Appearance214.BackColor2 = System.Drawing.Color.Transparent
        Appearance214.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance214.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance214.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance214.BorderColor2 = System.Drawing.Color.Maroon
        Appearance214.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance214.ForeColor = System.Drawing.Color.Black
        Appearance214.Image = CType(resources.GetObject("Appearance214.Image"), Object)
        Appearance214.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance214.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance214.TextVAlignAsString = "Bottom"
        Me.cmdKBName7.Appearance = Appearance214
        Me.cmdKBName7.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance215.BackColor = System.Drawing.Color.DarkOrange
        Appearance215.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance215.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance215.ForeColor = System.Drawing.Color.Black
        Me.cmdKBName7.HotTrackAppearance = Appearance215
        Me.cmdKBName7.ImageSize = New System.Drawing.Size(30, 18)
        Me.cmdKBName7.Location = New System.Drawing.Point(261, 307)
        Me.cmdKBName7.Name = "cmdKBName7"
        Appearance216.BackColor = System.Drawing.Color.OrangeRed
        Appearance216.BackColor2 = System.Drawing.Color.Tomato
        Appearance216.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdKBName7.PressedAppearance = Appearance216
        Me.cmdKBName7.ShowFocusRect = False
        Me.cmdKBName7.ShowOutline = False
        Me.cmdKBName7.Size = New System.Drawing.Size(48, 31)
        Me.cmdKBName7.TabIndex = 656
        Me.cmdKBName7.Tag = "Back"
        Me.cmdKBName7.UseAppStyling = False
        Me.cmdKBName7.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBName7.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBName7.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdKBName6
        '
        Appearance217.BackColor = System.Drawing.Color.Transparent
        Appearance217.BackColor2 = System.Drawing.Color.Transparent
        Appearance217.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance217.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance217.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance217.BorderColor2 = System.Drawing.Color.Maroon
        Appearance217.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance217.ForeColor = System.Drawing.Color.Black
        Appearance217.Image = CType(resources.GetObject("Appearance217.Image"), Object)
        Appearance217.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance217.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance217.TextVAlignAsString = "Bottom"
        Me.cmdKBName6.Appearance = Appearance217
        Me.cmdKBName6.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance218.BackColor = System.Drawing.Color.DarkOrange
        Appearance218.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance218.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance218.ForeColor = System.Drawing.Color.Black
        Me.cmdKBName6.HotTrackAppearance = Appearance218
        Me.cmdKBName6.ImageSize = New System.Drawing.Size(30, 18)
        Me.cmdKBName6.Location = New System.Drawing.Point(261, 270)
        Me.cmdKBName6.Name = "cmdKBName6"
        Appearance219.BackColor = System.Drawing.Color.OrangeRed
        Appearance219.BackColor2 = System.Drawing.Color.Tomato
        Appearance219.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdKBName6.PressedAppearance = Appearance219
        Me.cmdKBName6.ShowFocusRect = False
        Me.cmdKBName6.ShowOutline = False
        Me.cmdKBName6.Size = New System.Drawing.Size(48, 31)
        Me.cmdKBName6.TabIndex = 655
        Me.cmdKBName6.Tag = "Back"
        Me.cmdKBName6.UseAppStyling = False
        Me.cmdKBName6.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBName6.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBName6.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdKBName5
        '
        Appearance220.BackColor = System.Drawing.Color.Transparent
        Appearance220.BackColor2 = System.Drawing.Color.Transparent
        Appearance220.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance220.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance220.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance220.BorderColor2 = System.Drawing.Color.Maroon
        Appearance220.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance220.ForeColor = System.Drawing.Color.Black
        Appearance220.Image = CType(resources.GetObject("Appearance220.Image"), Object)
        Appearance220.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance220.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance220.TextVAlignAsString = "Bottom"
        Me.cmdKBName5.Appearance = Appearance220
        Me.cmdKBName5.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance221.BackColor = System.Drawing.Color.DarkOrange
        Appearance221.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance221.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance221.ForeColor = System.Drawing.Color.Black
        Me.cmdKBName5.HotTrackAppearance = Appearance221
        Me.cmdKBName5.ImageSize = New System.Drawing.Size(30, 18)
        Me.cmdKBName5.Location = New System.Drawing.Point(261, 233)
        Me.cmdKBName5.Name = "cmdKBName5"
        Appearance222.BackColor = System.Drawing.Color.OrangeRed
        Appearance222.BackColor2 = System.Drawing.Color.Tomato
        Appearance222.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdKBName5.PressedAppearance = Appearance222
        Me.cmdKBName5.ShowFocusRect = False
        Me.cmdKBName5.ShowOutline = False
        Me.cmdKBName5.Size = New System.Drawing.Size(48, 31)
        Me.cmdKBName5.TabIndex = 654
        Me.cmdKBName5.Tag = "Back"
        Me.cmdKBName5.UseAppStyling = False
        Me.cmdKBName5.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBName5.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBName5.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdKBName4
        '
        Appearance223.BackColor = System.Drawing.Color.Transparent
        Appearance223.BackColor2 = System.Drawing.Color.Transparent
        Appearance223.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance223.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance223.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance223.BorderColor2 = System.Drawing.Color.Maroon
        Appearance223.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance223.ForeColor = System.Drawing.Color.Black
        Appearance223.Image = CType(resources.GetObject("Appearance223.Image"), Object)
        Appearance223.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance223.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance223.TextVAlignAsString = "Bottom"
        Me.cmdKBName4.Appearance = Appearance223
        Me.cmdKBName4.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance224.BackColor = System.Drawing.Color.DarkOrange
        Appearance224.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance224.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance224.ForeColor = System.Drawing.Color.Black
        Me.cmdKBName4.HotTrackAppearance = Appearance224
        Me.cmdKBName4.ImageSize = New System.Drawing.Size(30, 18)
        Me.cmdKBName4.Location = New System.Drawing.Point(261, 196)
        Me.cmdKBName4.Name = "cmdKBName4"
        Appearance225.BackColor = System.Drawing.Color.OrangeRed
        Appearance225.BackColor2 = System.Drawing.Color.Tomato
        Appearance225.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdKBName4.PressedAppearance = Appearance225
        Me.cmdKBName4.ShowFocusRect = False
        Me.cmdKBName4.ShowOutline = False
        Me.cmdKBName4.Size = New System.Drawing.Size(48, 31)
        Me.cmdKBName4.TabIndex = 653
        Me.cmdKBName4.Tag = "Back"
        Me.cmdKBName4.UseAppStyling = False
        Me.cmdKBName4.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBName4.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBName4.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdKBName3
        '
        Appearance226.BackColor = System.Drawing.Color.Transparent
        Appearance226.BackColor2 = System.Drawing.Color.Transparent
        Appearance226.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance226.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance226.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance226.BorderColor2 = System.Drawing.Color.Maroon
        Appearance226.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance226.ForeColor = System.Drawing.Color.Black
        Appearance226.Image = CType(resources.GetObject("Appearance226.Image"), Object)
        Appearance226.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance226.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance226.TextVAlignAsString = "Bottom"
        Me.cmdKBName3.Appearance = Appearance226
        Me.cmdKBName3.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance227.BackColor = System.Drawing.Color.DarkOrange
        Appearance227.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance227.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance227.ForeColor = System.Drawing.Color.Black
        Me.cmdKBName3.HotTrackAppearance = Appearance227
        Me.cmdKBName3.ImageSize = New System.Drawing.Size(30, 18)
        Me.cmdKBName3.Location = New System.Drawing.Point(261, 159)
        Me.cmdKBName3.Name = "cmdKBName3"
        Appearance228.BackColor = System.Drawing.Color.OrangeRed
        Appearance228.BackColor2 = System.Drawing.Color.Tomato
        Appearance228.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdKBName3.PressedAppearance = Appearance228
        Me.cmdKBName3.ShowFocusRect = False
        Me.cmdKBName3.ShowOutline = False
        Me.cmdKBName3.Size = New System.Drawing.Size(48, 31)
        Me.cmdKBName3.TabIndex = 652
        Me.cmdKBName3.Tag = "Back"
        Me.cmdKBName3.UseAppStyling = False
        Me.cmdKBName3.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBName3.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBName3.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdKBName2
        '
        Appearance229.BackColor = System.Drawing.Color.Transparent
        Appearance229.BackColor2 = System.Drawing.Color.Transparent
        Appearance229.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance229.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance229.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance229.ForeColor = System.Drawing.Color.Black
        Appearance229.Image = CType(resources.GetObject("Appearance229.Image"), Object)
        Appearance229.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance229.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance229.TextVAlignAsString = "Bottom"
        Me.cmdKBName2.Appearance = Appearance229
        Me.cmdKBName2.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance230.BackColor = System.Drawing.Color.DarkOrange
        Appearance230.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance230.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance230.ForeColor = System.Drawing.Color.Black
        Me.cmdKBName2.HotTrackAppearance = Appearance230
        Me.cmdKBName2.ImageSize = New System.Drawing.Size(30, 18)
        Me.cmdKBName2.Location = New System.Drawing.Point(261, 122)
        Me.cmdKBName2.Name = "cmdKBName2"
        Appearance231.BackColor = System.Drawing.Color.OrangeRed
        Appearance231.BackColor2 = System.Drawing.Color.Tomato
        Appearance231.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdKBName2.PressedAppearance = Appearance231
        Me.cmdKBName2.ShowFocusRect = False
        Me.cmdKBName2.ShowOutline = False
        Me.cmdKBName2.Size = New System.Drawing.Size(48, 31)
        Me.cmdKBName2.TabIndex = 651
        Me.cmdKBName2.Tag = "Back"
        Me.cmdKBName2.UseAppStyling = False
        Me.cmdKBName2.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBName2.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBName2.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdKBName1
        '
        Appearance232.BackColor = System.Drawing.Color.Transparent
        Appearance232.BackColor2 = System.Drawing.Color.Transparent
        Appearance232.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance232.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance232.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance232.ForeColor = System.Drawing.Color.Black
        Appearance232.Image = CType(resources.GetObject("Appearance232.Image"), Object)
        Appearance232.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance232.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance232.TextVAlignAsString = "Bottom"
        Me.cmdKBName1.Appearance = Appearance232
        Me.cmdKBName1.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance233.BackColor = System.Drawing.Color.DarkOrange
        Appearance233.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance233.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance233.ForeColor = System.Drawing.Color.Black
        Me.cmdKBName1.HotTrackAppearance = Appearance233
        Me.cmdKBName1.ImageSize = New System.Drawing.Size(30, 18)
        Me.cmdKBName1.Location = New System.Drawing.Point(261, 85)
        Me.cmdKBName1.Name = "cmdKBName1"
        Appearance234.BackColor = System.Drawing.Color.OrangeRed
        Appearance234.BackColor2 = System.Drawing.Color.Tomato
        Appearance234.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdKBName1.PressedAppearance = Appearance234
        Me.cmdKBName1.ShowFocusRect = False
        Me.cmdKBName1.ShowOutline = False
        Me.cmdKBName1.Size = New System.Drawing.Size(48, 31)
        Me.cmdKBName1.TabIndex = 650
        Me.cmdKBName1.Tag = "Back"
        Me.cmdKBName1.UseAppStyling = False
        Me.cmdKBName1.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBName1.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBName1.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'frmDishCascade
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(951, 534)
        Me.ControlBox = False
        Me.Controls.Add(Me.cmdKBName9)
        Me.Controls.Add(Me.cmdKBName8)
        Me.Controls.Add(Me.cmdKBName7)
        Me.Controls.Add(Me.cmdKBName6)
        Me.Controls.Add(Me.cmdKBName5)
        Me.Controls.Add(Me.cmdKBName4)
        Me.Controls.Add(Me.cmdKBName3)
        Me.Controls.Add(Me.cmdKBName2)
        Me.Controls.Add(Me.cmdKBName1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.cmdDelSN9)
        Me.Controls.Add(Me.cmdDelSN8)
        Me.Controls.Add(Me.cmdDelSN7)
        Me.Controls.Add(Me.cmdDelSN6)
        Me.Controls.Add(Me.cmdDelSN5)
        Me.Controls.Add(Me.cmdDelSN4)
        Me.Controls.Add(Me.cmdDelSN3)
        Me.Controls.Add(Me.cmdDelSN2)
        Me.Controls.Add(Me.cmdDelSN1)
        Me.Controls.Add(Me.cmdKBSN9)
        Me.Controls.Add(Me.cmdKBSN8)
        Me.Controls.Add(Me.cmdKBSN7)
        Me.Controls.Add(Me.cmdKBSN6)
        Me.Controls.Add(Me.cmdKBSN5)
        Me.Controls.Add(Me.cmdKBSN4)
        Me.Controls.Add(Me.cmdKBSN3)
        Me.Controls.Add(Me.cmdKBSN2)
        Me.Controls.Add(Me.cmdKBSN1)
        Me.Controls.Add(Me.txtShortName9)
        Me.Controls.Add(Me.txtShortName8)
        Me.Controls.Add(Me.txtShortName7)
        Me.Controls.Add(Me.txtShortName6)
        Me.Controls.Add(Me.txtShortName5)
        Me.Controls.Add(Me.txtShortName4)
        Me.Controls.Add(Me.txtShortName3)
        Me.Controls.Add(Me.txtShortName2)
        Me.Controls.Add(Me.txtShortName1)
        Me.Controls.Add(Me.lblDCHeader)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblCuisine)
        Me.Controls.Add(Me.cmdDelSC9)
        Me.Controls.Add(Me.cmdDelSC8)
        Me.Controls.Add(Me.cmdDelSC7)
        Me.Controls.Add(Me.cmdDelSC6)
        Me.Controls.Add(Me.cmdDelSC5)
        Me.Controls.Add(Me.cmdDelSC4)
        Me.Controls.Add(Me.cmdDelSC3)
        Me.Controls.Add(Me.cmdDelSC2)
        Me.Controls.Add(Me.cmdDelSC1)
        Me.Controls.Add(Me.cmdKB9)
        Me.Controls.Add(Me.cmdKB8)
        Me.Controls.Add(Me.cmdKB7)
        Me.Controls.Add(Me.cmdKB6)
        Me.Controls.Add(Me.cmdKB5)
        Me.Controls.Add(Me.cmdKB4)
        Me.Controls.Add(Me.cmdKB3)
        Me.Controls.Add(Me.cmdKB2)
        Me.Controls.Add(Me.cmdKB1)
        Me.Controls.Add(Me.txtShortCode9)
        Me.Controls.Add(Me.txtShortCode8)
        Me.Controls.Add(Me.txtShortCode7)
        Me.Controls.Add(Me.txtShortCode6)
        Me.Controls.Add(Me.txtShortCode5)
        Me.Controls.Add(Me.txtShortCode4)
        Me.Controls.Add(Me.txtShortCode3)
        Me.Controls.Add(Me.txtShortCode2)
        Me.Controls.Add(Me.txtShortCode1)
        Me.Controls.Add(Me.cmdPriceOut9)
        Me.Controls.Add(Me.cmdPriceOut8)
        Me.Controls.Add(Me.cmdPriceOut7)
        Me.Controls.Add(Me.cmdPriceOut6)
        Me.Controls.Add(Me.cmdPriceOut5)
        Me.Controls.Add(Me.cmdPriceOut4)
        Me.Controls.Add(Me.cmdPriceOut3)
        Me.Controls.Add(Me.cmdPriceOut2)
        Me.Controls.Add(Me.cmdPriceOut1)
        Me.Controls.Add(Me.txtPriceOut9)
        Me.Controls.Add(Me.txtPriceOut8)
        Me.Controls.Add(Me.txtPriceOut7)
        Me.Controls.Add(Me.txtPriceOut6)
        Me.Controls.Add(Me.txtPriceOut5)
        Me.Controls.Add(Me.txtPriceOut4)
        Me.Controls.Add(Me.txtPriceOut3)
        Me.Controls.Add(Me.txtPriceOut2)
        Me.Controls.Add(Me.txtPriceOut1)
        Me.Controls.Add(Me.cmdSwapName)
        Me.Controls.Add(Me.cmdPrice9)
        Me.Controls.Add(Me.cmdPrice8)
        Me.Controls.Add(Me.cmdPrice7)
        Me.Controls.Add(Me.cmdPrice6)
        Me.Controls.Add(Me.cmdPrice5)
        Me.Controls.Add(Me.cmdPrice4)
        Me.Controls.Add(Me.cmdPrice3)
        Me.Controls.Add(Me.cmdPrice2)
        Me.Controls.Add(Me.cmdPrice1)
        Me.Controls.Add(Me.txtPriceIn9)
        Me.Controls.Add(Me.txtPriceIn8)
        Me.Controls.Add(Me.txtPriceIn7)
        Me.Controls.Add(Me.txtPriceIn6)
        Me.Controls.Add(Me.txtPriceIn5)
        Me.Controls.Add(Me.txtPriceIn4)
        Me.Controls.Add(Me.txtPriceIn3)
        Me.Controls.Add(Me.txtPriceIn2)
        Me.Controls.Add(Me.txtPriceIn1)
        Me.Controls.Add(Me.txtName9)
        Me.Controls.Add(Me.txtName8)
        Me.Controls.Add(Me.txtName7)
        Me.Controls.Add(Me.txtName6)
        Me.Controls.Add(Me.txtName5)
        Me.Controls.Add(Me.txtName4)
        Me.Controls.Add(Me.txtName3)
        Me.Controls.Add(Me.txtName2)
        Me.Controls.Add(Me.txtName1)
        Me.Controls.Add(Me.cmdOK)
        Me.Controls.Add(Me.cmdClose)
        Me.MinimumSize = New System.Drawing.Size(967, 550)
        Me.Name = "frmDishCascade"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        CType(Me.txtName1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtName2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtName3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtName4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtName5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtName6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtName7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtName9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtName8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtPriceIn9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtPriceIn8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtPriceIn7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtPriceIn6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtPriceIn5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtPriceIn4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtPriceIn3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtPriceIn2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtPriceIn1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtPriceOut9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtPriceOut8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtPriceOut7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtPriceOut6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtPriceOut5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtPriceOut4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtPriceOut3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtPriceOut2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtPriceOut1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtShortCode9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtShortCode8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtShortCode7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtShortCode6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtShortCode5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtShortCode4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtShortCode3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtShortCode2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtShortCode1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtShortName9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtShortName8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtShortName7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtShortName6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtShortName5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtShortName4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtShortName3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtShortName2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtShortName1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtName1 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents cmdOK As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdClose As Infragistics.Win.Misc.UltraButton
    Friend WithEvents txtName2 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtName3 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtName4 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtName5 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtName6 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtName7 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtName9 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtName8 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtPriceIn9 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtPriceIn8 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtPriceIn7 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtPriceIn6 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtPriceIn5 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtPriceIn4 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtPriceIn3 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtPriceIn2 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtPriceIn1 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents cmdPrice1 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdPrice2 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdPrice4 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdPrice3 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdPrice8 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdPrice7 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdPrice6 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdPrice5 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdPrice9 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdSwapName As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdPriceOut9 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdPriceOut8 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdPriceOut7 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdPriceOut6 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdPriceOut5 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdPriceOut4 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdPriceOut3 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdPriceOut2 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdPriceOut1 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents txtPriceOut9 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtPriceOut8 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtPriceOut7 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtPriceOut6 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtPriceOut5 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtPriceOut4 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtPriceOut3 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtPriceOut2 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtPriceOut1 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents cmdKB9 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdKB8 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdKB7 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdKB6 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdKB5 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdKB4 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdKB3 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdKB2 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdKB1 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents txtShortCode9 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtShortCode8 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtShortCode7 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtShortCode6 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtShortCode5 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtShortCode4 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtShortCode3 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtShortCode2 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtShortCode1 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents cmdDelSC9 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDelSC8 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDelSC7 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDelSC6 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDelSC5 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDelSC4 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDelSC3 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDelSC2 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDelSC1 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents lblCuisine As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents lblDCHeader As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents cmdDelSN9 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDelSN8 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDelSN7 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDelSN6 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDelSN5 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDelSN4 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDelSN3 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDelSN2 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDelSN1 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdKBSN9 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdKBSN8 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdKBSN7 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdKBSN6 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdKBSN5 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdKBSN4 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdKBSN3 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdKBSN2 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdKBSN1 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents txtShortName9 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtShortName8 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtShortName7 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtShortName6 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtShortName5 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtShortName4 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtShortName3 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtShortName2 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtShortName1 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents cmdKBName9 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdKBName8 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdKBName7 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdKBName6 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdKBName5 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdKBName4 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdKBName3 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdKBName2 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdKBName1 As Infragistics.Win.Misc.UltraButton



End Class
