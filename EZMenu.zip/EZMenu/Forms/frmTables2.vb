﻿Imports System.Configuration
Imports EZControls
Imports EZMenu.Core
Imports EZMenu.Core.Enums
Imports EZMenu.Core.Models
Imports EZService.Repository
Imports Infragistics.Win.Misc
Imports Infragistics.Win.UltraWinDataSource
Imports Infragistics.Win.UltraWinTabControl

Public Class frmTables2

    Private pnlCurrentMainPanel As UltraPanel = Nothing
    Private blnDrinksDirty As Boolean
    Private CurCusts, intButtonAppn, intArrPos As Short
    Private arrDrinks As ArrayList = New ArrayList
    Private CAPValue As Short
    Private blnDrinksOut As Boolean
    Private _objOwnerForm As Object
    Private tValue As Single
    Private moveModeOn As Boolean = False
    Private Const strIsModRow As String = "ismodrow"
    Private orderDiscounts As PriceAdjustmentsModel
    Private orderCharges As PriceAdjustmentsModel
    Private totalsAdjustmentsDiscounts As PriceAdjustmentsModel
    Private totalsAdjustmentsCharges As PriceAdjustmentsModel
    Private NumberOfTables As Short
    Private tableRepo As TableRepository

    Const constDrinkButtonAppearance = 3
    Const constDrinkButtonAppearanceGrouped = 6

    Enum AllPanels
        Bill = 1
        Tables = 2
        Drinks = 3
    End Enum

    Private TablePanels As AllPanels

    Public ReadOnly Property Covers
        Get
            Return CurCusts
        End Get
    End Property

    Public Sub New()

        InitializeComponent()
        InitializeOther()

        NumberOfTables = GetAppSettingCS("NumberOfTables", 20)

        CreateTables()

        CreateDrinksGrid()

        blnDrinksOut = False

    End Sub

    Public Sub New(strParam As String)

        InitializeComponent()
        InitializeOther()

        blnDrinksOut = True

        If strParam = "DrinksOut" Then
            CreateDrinksGrid()
        End If

    End Sub

    Private Sub InitializeOther()

        tableRepo = New TableRepository()

        DrinksTableAdapter.Connection.ConnectionString = ConfigurationManager.ConnectionStrings(EZConstants.EZDatabaseConnectionString).ConnectionString
        TableAdapterManager.Connection.ConnectionString = ConfigurationManager.ConnectionStrings(EZConstants.EZDatabaseConnectionString).ConnectionString

        udsDrinks.Band.Columns.Add("DkQty", GetType(Short))
        udsDrinks.Band.Columns.Add("DkName", GetType(String))
        udsDrinks.Band.Columns.Add("DkPrice", GetType(Decimal))
        udsDrinks.Band.Columns.Add("DkTotal", GetType(Decimal))

        pnlContainer.Location = New Point(0, 0)
        pnlContainer.Size = New Size(Width - 16, lblStatusbarDivider.Top - 1)

        cmdLightsStatus.Enabled = GetAppSettingCS("TablesExtLights", True)

        totalsAdjustmentsDiscounts = New PriceAdjustmentsModel
        totalsAdjustmentsCharges = New PriceAdjustmentsModel

        GetTableIDs()

    End Sub

    Public Sub Display(objOwnerForm As Form)

        Size = objOwnerForm.Size
        Location = objOwnerForm.Location

        If blnDrinksOut Then
            _objOwnerForm = CType(objOwnerForm, frmOrderEntry)

            lblDrinksHeader.Text = "Select drinks"
            cmdClosePanel.Visible = False
            DisplayPanel(AllPanels.Drinks)

        Else
            _objOwnerForm = CType(objOwnerForm, frmOpener)

            ShowTablesInUse()

            'show the initial panel
            DisplayPanel(AllPanels.Tables)

        End If

        HideHourGlass()

        ShowDialog()

    End Sub

    Private Sub GetTableIDs()

        Try
            'reset tables unique IDs
            For iCntr = 1 To UBound(TableInfo)
                TableInfo(iCntr).Id = 0
                TableInfo(iCntr).Status = TStatusEnum.Clean
            Next

            'get tables' uniqueIds from the DB
            SQLQuery = "SELECT TableNumber, TabUniqueId, TableStatus 
                        FROM Table_Bill 
                        WHERE TableStatus BETWEEN 1 AND 2 
                        ORDER BY TableNumber;"

            drcDatarowCollection = objDB.GetDataRows(SQLQuery)

            If drcDatarowCollection IsNot Nothing Then
                For Each myRow As DataRow In drcDatarowCollection
                    TableInfo(myRow!TableNumber).Id = myRow!TabUniqueID
                    TableInfo(myRow!TableNumber).Status = myRow!TableStatus
                Next
            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub CreateDrinksGrid()

        If GetAppSettingCS("DrinkDisplayMethod", "") = "GROUPED" Then
            CreateDrinksArrayGrouped()
        Else
            CreateDrinksArray()
        End If

    End Sub

    Private Sub DisplayPanel(PanelToShow As AllPanels)

        Try
            Dim pnlPanelToShow As UltraPanel = Nothing
            Dim objSearch As Object
            Dim utcPages As UltraTabsCollection = utcAllPanels.Tabs
            Dim strPanelToShow As String = "pnlTables"

            If PanelToShow = AllPanels.Drinks Then
                strPanelToShow = "pnlDrinks"

            ElseIf PanelToShow = AllPanels.Tables Then
                strPanelToShow = "pnlTables"

            ElseIf PanelToShow = AllPanels.Bill Then
                strPanelToShow = "pnlBill"

            End If

            'if selected panel is the current panel then do nothing
            If pnlCurrentMainPanel IsNot Nothing Then
                If pnlCurrentMainPanel.Name = strPanelToShow Then
                    Exit Sub
                End If
            End If

            'iterate through the tabpages and find the panel to show
            For Each utb As UltraTab In utcPages
                objSearch = utb.TabPage.Controls(strPanelToShow)
                If objSearch IsNot Nothing Then
                    pnlPanelToShow = CType(objSearch, UltraPanel)
                    Exit For
                End If
            Next

            'if there is current main panel then put that back to its original place
            If pnlCurrentMainPanel IsNot Nothing Then
                Dim pnlTarget As UltraPanel = Nothing
                Dim strCurMainPanelName As String = pnlCurrentMainPanel.Name.Substring(3)

                'iterate through the tabpages and find the tab for the panel to go into
                For Each utb As UltraTab In utcPages
                    If utb.TabPage.Tab.Key = strCurMainPanelName Then
                        pnlCurrentMainPanel.Parent = utb.TabPage
                        Exit For
                    End If
                Next

                'reset main panel variable to nothing
                pnlCurrentMainPanel = Nothing
            End If

            If pnlPanelToShow IsNot Nothing Then
                With pnlPanelToShow
                    .Parent = pnlContainer.ClientArea
                    .Location = New Point(0, 0)
                    .Size = pnlContainer.Size
                    .BringToFront()
                End With
                pnlCurrentMainPanel = pnlPanelToShow
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub CreateTables()

        Dim intRow, intCol As Short
        Dim btnEZButton As New EZTableButton
        Dim rScale, cScale As Decimal

        NumberOfTables = 28

        If NumberOfTables = 12 Then         'create 4x3 grid
            intRow = 3
            intCol = 4
            rScale = 1.4
            cScale = 1.6

        ElseIf NumberOfTables = 16 Then     'create 4x4 grid
            intRow = 4
            intCol = 4
            rScale = 1.1
            cScale = 1.7

        ElseIf NumberOfTables = 28 Then     'create 7x4 grid
            intRow = 4
            intCol = 7
            rScale = 1.1
            cScale = 1.5

        Else                                'create 4x3 grid
            intRow = 3
            intCol = 4
            rScale = 1.3
            cScale = 1.6

        End If

        DrawTables(intRow, intCol, "Table", tlpTables)

        With tlpTables
            .AutoSize = False
            '.BorderStyle = BorderStyle.FixedSingle
            .Width = intCol * btnEZButton.Width * cScale
            .Height = intRow * btnEZButton.Height * rScale
            .Left = (pnlTables.Width - .Width) / 2
            .Top = (pnlTables.Height - .Height) / 2
        End With

        Dim styles As TableLayoutRowStyleCollection = tlpTables.RowStyles
        Dim cstyles As TableLayoutColumnStyleCollection = tlpTables.ColumnStyles

        For Each style As RowStyle In styles
            style.SizeType = SizeType.Percent
            style.Height = 100 / tlpTables.RowCount
        Next

        For Each style As ColumnStyle In cstyles
            style.SizeType = SizeType.Percent
            style.Width = 100 / tlpTables.ColumnCount
        Next

        CreateMiniTables()

    End Sub

    Private Sub DrawTables(nRows As Short, nCols As Short, strCtrlName As String, ctrlControl As Control)

        Dim iX As Short = 1

        tlpTables.ColumnCount = nCols
        tlpTables.RowCount = nRows

        For jCol As Short = 0 To (nCols - 1)
            For iRow As Short = 0 To (nRows - 1)
                Dim meBut As New EZTableButton With {
                    .Name = strCtrlName & iX,
                    .TableNumber = iX,
                    .Parent = ctrlControl,
                    .Anchor = AnchorStyles.None
                }

                meBut.ClearTable()
                meBut.Visible = True

                If TypeName(ctrlControl) = "UltraPanel" Then
                    Dim ctrlCArea = DirectCast(ctrlControl, UltraPanel)
                    ctrlCArea.ClientArea.Controls.Add(meBut)
                Else
                    ctrlControl.Controls.Add(meBut)
                End If
                AddHandler meBut.Click, AddressOf TableClickEvent
                iX += 1
            Next
        Next

    End Sub

    Public Sub GetTableInfo(TableNum)

        Try

            ClearTableScreen()

            CurTable = TableNum
            CurCusts = 0
            UpdateTableHeader()
            lblDrinksHeader.Text = "Table: " & CurTable
            lblDiscountsLbl.Text = "Discounts:"
            lblChargesLbl.Text = "Charges:"
            lblEntryTime.Text = String.Empty
            DisplayPanel(AllPanels.Bill)
            SetTableColour(CurTable, False)

            If TableInfo(CurTable).Id = 0 Then  'no unique id means no food/drink added to table

                SQLQuery = $"SELECT TableNumber, TabUniqueId, TableStatus, NumCust, EntryTime, Lights 
                             FROM Table_Bill 
                             WHERE (TableNumber = {TableNum} AND (TableStatus BETWEEN 1 AND 2) AND (BizId BETWEEN 40 AND 60)) 
                             ORDER BY TableNumber;"
                drDataRow = objDB.GetSingleRow(SQLQuery)
                If drDataRow IsNot Nothing Then
                    TableInfo(TableNum).Id = drDataRow!TabUniqueID
                    TableInfo(TableNum).Status = drDataRow!TableStatus
                    SetTableColour(CurTable, True, drDataRow!NumCust, drDataRow!EntryTime.ToString, drDataRow!Lights)
                Else
                    If GetAppSettingCS("TablesAutoCovers", True) = True Then
                        Sleep(300)
                        GetCovers()
                    End If
                End If

            ElseIf TableInfo(CurTable).Id > 0 Then

                'this query gets all info from Table_Bill for subsequent steps below
                SQLQuery = $"SELECT * FROM Table_Bill WHERE TabUniqueID = { TableInfo(CurTable).Id }"
                drDataRow = objDB.GetSingleRow(SQLQuery)
                If drDataRow Is Nothing Then
                    TableInfo(TableNum).Id = 0
                    Exit Sub
                End If

                SetTableColour(CurTable, True, drDataRow!NumCust, drDataRow!EntryTime.ToString, drDataRow!Lights)

                'get the number of customers at the table
                CurCusts = Short.Parse(drDataRow("NumCust").ToString)
                UpdateTableHeader()
                If drDataRow.IsNull("CAPValue") Then CAPValue = 0 Else CAPValue = Short.Parse(drDataRow("CAPValue").ToString)

                'get discount, charges, tips
                lblDiscounts.Text = fixCur(Val(drDataRow("DiscountAmount").ToString))
                lblCharges.Text = fixCur(Val(drDataRow("ChargeAmount").ToString))
                tempStr = drDataRow("DiscountLabelText").ToString
                If tempStr = String.Empty Then tempStr = "Discounts"
                lblDiscountsLbl.Text = tempStr & ":"
                tempStr = drDataRow("ChargeLabelText").ToString
                If tempStr = String.Empty Then tempStr = "Charges"
                lblChargesLbl.Text = tempStr & ":"
                lblTTips.Text = "Tips: " & fixCur(drDataRow("Tips").ToString)
                If drDataRow!EntryTime.ToString <> "00:00:00" Then
                    Dim TSpan As TimeSpan = Now - CDate(drDataRow!EntryTime.ToString)
                    tempStr = String.Format("Time of entry: {0}" & vbCrLf & "({1}h {2}m)",
                                        Format(CDate(drDataRow!EntryTime.ToString), "h:mm"),
                                        TSpan.Hours.ToString("D1"),
                                        TSpan.Minutes.ToString("D2"))
                    lblEntryTime.Text = tempStr
                End If

                'get info from the DB about this table's meal
                SQLQuery = "SELECT * 
                            FROM Table_Meal 
                            WHERE TabUniqueID = " & TableInfo(CurTable).Id
                drcDatarowCollection = objDB.GetDataRows(SQLQuery)
                If drcDatarowCollection IsNot Nothing Then
                    For Each myRow As DataRow In drcDatarowCollection
                        Dim udrRow As UltraDataRow = udsTableGrid.Rows.Add
                        udrRow.Item("Code") = myRow("Code")
                        udrRow.Item("Dish") = myRow("DishName")
                        udrRow.Item("Price") = fixCur(myRow("DishPrice"))
                        udrRow.Item("Qty") = myRow("DishQty")
                        udrRow.Item("Total") = fixCur(myRow("DishQty") * myRow("DishPrice"))
                        udrRow.Item("IsStarter") = myRow("IsStarter")
                        udrRow.Item("Discountable") = myRow("Discountable")
                        udrRow.Item("GroupIndex") = myRow("GroupIndex")

                        'show any mods
                        Dim orderMods As IEnumerable(Of OrderModsModel) = tableRepo.GetTableModsFromDB(TableInfo(CurTable).Id, myRow("DishName"))
                        If orderMods.Any Then
                            For Each om In orderMods
                                Dim udrModRow As UltraDataRow = udsTableGrid.Rows.Add
                                udrModRow.Item("Qty") = String.Empty
                                udrModRow.Item("Dish") = "- " + om.ModName
                                udrModRow.Item("Price") = om.ModCost
                                udrModRow.Item("Total") = myRow("DishQty") * om.ModCost
                                udrModRow.Item("Mods") = strIsModRow
                                udrModRow.Item("Discountable") = 0
                            Next
                        End If


                        'ShowAnySetItems(TableInfo(CurTable).Id, myRow("DishName"), myRow("DishQty"))
                    Next

                    'update papadom price
                    UpdatePapaPrice()

                    ugdTableGrid.DataSource = udsTableGrid

                    'get info from the DB about this table's drinks
                    SQLQuery = $"SELECT * FROM Table_Drinks WHERE TabUniqueID = {TableInfo(CurTable).Id}"
                    drcDatarowCollection = objDB.GetDataRows(SQLQuery)
                    If drcDatarowCollection IsNot Nothing Then
                        For Each myRow As DataRow In drcDatarowCollection
                            Dim udrRow As UltraDataRow = udsDrinks.Rows.Add
                            udrRow.Item("DkQty") = myRow("DkQty")
                            udrRow.Item("DkName") = myRow("DkName")
                            udrRow.Item("DkPrice") = myRow("DkPrice")
                            udrRow.Item("DkTotal") = myRow("DkQty") * myRow("DkPrice")
                        Next
                        ugdDrinksGrid.DataSource = udsDrinks
                        'work out the drinks total
                        lblDrinksTotal.Text = fixCur(CalcDrinksTotal)
                    End If

                    'fill in drinks row in bill if there are drinks selected
                    If CalcDrinksTotal() > 0 Then
                        lblTDrinks.Text = fixCur(CalcDrinksTotal)
                    End If

                    DisplayAllTotals()

                    HighlightStarters()

                    ugdTableGrid.ActiveRow = Nothing

                End If

            End If

        Catch ex As Exception
            WriteToLog(ex)
        End Try

    End Sub

    Private Sub CreateMiniTables()

        If NumberOfTables = 12 Then
            'create the 4x3 grid
            upnlMiniTables.Size = New Size(270, 205)
            'upnlMiniTables.Location = New Point(390, 485)
            MiniTableGrid(4, 3, 60, 60, 5, 5, 6, 6, 14, "MiniTable", upnlMiniTables.ClientArea, 12)

        ElseIf NumberOfTables = 16 Then
            'create the 4x4 grid
            upnlMiniTables.Size = New Size(250, 230)
            'upnlMiniTables.Location = New Point(400, 460)
            MiniTableGrid(4, 4, 54, 50, 5, 5, 6, 6, 14, "MiniTable", upnlMiniTables.ClientArea, 16)

        ElseIf NumberOfTables = 28 Then
            'create 7x4 grid
            upnlMiniTables.Size = New Size(340, 284)
            'upnlMiniTables.Location = New Point(357, 400)
            MiniTableGrid(6, 5, 50, 50, 5, 5, 6, 6, 14, "MiniTable", upnlMiniTables.ClientArea, 28)

        Else
            'create 5x4 grid
            upnlMiniTables.Size = New Size(287, 230)
            'upnlMiniTables.Location = New Point(380, 450)
            MiniTableGrid(5, 4, 50, 50, 5, 5, 6, 6, 14, "MiniTable", upnlMiniTables.ClientArea, 20)
        End If

        Dim x = ugdTableGrid.Left + ugdTableGrid.Width + 40
        Dim y = ugdTableGrid.Top + ugdTableGrid.Height - upnlMiniTables.Height

        upnlMiniTables.Anchor = AnchorStyles.None
        upnlMiniTables.Location = New Point(x, y)
        upnlMiniTables.Anchor = AnchorStyles.Bottom

        Dim i As Short = 1
        For Each myObj As Control In upnlMiniTables.ClientArea.Controls
            If myObj.Name.StartsWith("MiniTable") Then
                AddHandler myObj.Click, AddressOf MiniTableClickEvent
                myObj.Text = i
                i += 1
            End If
        Next

    End Sub

    Public Sub MiniTableGrid(nRows As Short, nCols As Short, bWidth As Short, bHeight As Short, xStart As Short,
                             yStart As Short, xGap As Short, yGap As Short, ftSize As Short, strCtrlName As String,
                             ctrlControl As Control, Optional intMaxButtons As Integer = 0)

        Dim iRow, jCol, xLoc, yLoc, intButtonCntr As Short

        intButtonCntr = 0

        For jCol = 0 To (nCols - 1)
            For iRow = 0 To (nRows - 1)

                Dim meBut As New UltraButton

                With meBut
                    .Font = New Font("Arial", ftSize, FontStyle.Regular, GraphicsUnit.Point, 0)
                    .Name = strCtrlName & (intButtonCntr + 1)
                    .ShowFocusRect = False
                    .ShowOutline = False
                    .Size = New Size(bWidth, bHeight)
                    .UseAppStyling = False
                    .UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
                    .UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
                    .UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
                    With .Appearance
                        .ImageBackground = My.Resources.ezresource.minitable
                        .BackColor = Color.Transparent
                        .BorderColor = Color.Transparent
                        .ForeColor = Color.White
                        .TextVAlign = Infragistics.Win.VAlign.Middle
                    End With
                End With

                xLoc = xStart + (iRow * (bWidth + xGap))
                yLoc = yStart + (jCol * (bHeight + yGap))
                meBut.Location = New Point(xLoc, yLoc)
                intButtonCntr += 1
                If TypeName(ctrlControl) = "UltraPanel" Then
                    Dim ctrlCArea = DirectCast(ctrlControl, UltraPanel)
                    ctrlCArea.ClientArea.Controls.Add(meBut)
                Else
                    ctrlControl.Controls.Add(meBut)
                End If
                If intMaxButtons <> 0 Then
                    If intButtonCntr = intMaxButtons Then
                        Exit For
                    End If
                End If
            Next
        Next

    End Sub

    Private Sub SetupButtons()

        For Each myobjx In pnlBill.ClientArea.Controls
            If (TypeName(myobjx) = "UltraButton" AndAlso myobjx.width = 126) Then
                Dim myObj As UltraButton = DirectCast(myobjx, UltraButton)
                myObj.Tag = myObj.Text
                If GetAppSettingCS("ShowLabelText", 0) = 0 Then myObj.Text = String.Empty
                myObj.Appearance.ImageVAlign = Infragistics.Win.VAlign.Middle
                AddHandler myObj.MouseEnter, AddressOf ButtonMouseEnter
                AddHandler myObj.MouseLeave, AddressOf ButtonMouseLeave
            End If
        Next

        For Each myobjx In pnlDrinksDrinks.ClientArea.Controls
            If (TypeName(myobjx) = "UltraButton" AndAlso myobjx.width = 126) Then
                Dim myObj As UltraButton = DirectCast(myobjx, UltraButton)
                myObj.Tag = myObj.Text
                If GetAppSettingCS("ShowLabelText", 0) = 0 Then myObj.Text = String.Empty
                myObj.Appearance.ImageVAlign = Infragistics.Win.VAlign.Middle
                AddHandler myObj.MouseEnter, AddressOf ButtonMouseEnter
                AddHandler myObj.MouseLeave, AddressOf ButtonMouseLeave
            End If
        Next

        'cmdLightsStatus.Enabled = GetAppSettingCS("TablesExtMode", True)

        'cmdTablesToMain.Tag = cmdTablesToMain.Text
        'If GetAppSettingCS("ShowLabelText", 0) = 0 Then cmdTablesToMain.Text = String.Empty
        'cmdTablesToMain.Appearance.ImageVAlign = Infragistics.Win.VAlign.Middle
        'AddHandler cmdTablesToMain.MouseEnter, AddressOf ButtonMouseEnter
        'AddHandler cmdTablesToMain.MouseLeave, AddressOf ButtonMouseLeave

    End Sub

    Private Sub ButtonMouseEnter(sender As Object, e As EventArgs)
        sender.text = sender.tag
    End Sub

    Private Sub ButtonMouseLeave(sender As Object, e As EventArgs)

        If GetAppSettingCS("ShowLabelText", 0) = 0 Then sender.Text = String.Empty
        sender.Appearance.ImageVAlign = Infragistics.Win.VAlign.Middle

    End Sub

    Private Sub TableClickEvent(sender As EZTableButton, e As EventArgs)
        GetTableInfo(sender.TableNumber)
    End Sub

    Private Sub MiniTableClickEvent(sender As UltraButton, e As EventArgs)

        'If pnlBill.Tag = "MoveModeOn" Then
        If moveModeOn = True Then
            SQLQuery = String.Format("UPDATE Table_Bill SET TableNumber = {0} WHERE TabUniqueID = {1}", sender.Text, TableInfo(CurTable).Id)
            objDB.ExeNonQuery(SQLQuery)

            SetTableColour(CurTable, False)
            SetTableColour(sender.Text, True)

            TableInfo(CShort(sender.Text)).Id = TableInfo(CurTable).Id
            TableInfo(CurTable).Id = 0
            TableInfo(CShort(sender.Text)).Status = TableInfo(CurTable).Status
            TableInfo(CurTable).Status = TStatusEnum.Clean
            CurTable = CShort(sender.Text)
            RestoreTables()
        End If

        GetTableInfo(sender.Text)
        ResetMiniTableBackground()
        MiniHilit(sender)

    End Sub

    Private Sub ResetMiniTableBackground()

        For Each myObj In upnlMiniTables.ClientArea.Controls
            If (TypeOf myObj Is UltraButton) Then
                Dim ubtnTemp As UltraButton = DirectCast(myObj, UltraButton)
                ubtnTemp.Appearance.BackColor = Color.Transparent
            End If
        Next

    End Sub

    Private Sub cmdTableTables_Click(sender As Object, e As EventArgs) Handles cmdTableTables.Click

        DisplayPanel(AllPanels.Tables)

        If GetAppSettingCS("TablesExtMode", True) Then
            Application.DoEvents()
            For Each myObj As Control In tlpTables.Controls
                If (TypeOf myObj Is EZTableButton) Then
                    Dim myObjx As EZTableButton = DirectCast(myObj, EZTableButton)
                    If myObjx.Status <> EZTableButton.StatusType.Clean Then
                        myObjx.UpdateLabel()
                        myObjx.Refresh()
                    End If
                End If
            Next
        End If

    End Sub

    Private Sub cmdTableDrinks_Click(sender As Object, e As EventArgs) Handles cmdTableDrinks.Click

        DisplayPanel(AllPanels.Drinks)
        cmdDkPrevious.Visible = True
        cmdDkNext.Visible = True
        cmdClosePanel.Visible = False

    End Sub

    Private Sub cmdDkClose_Click(sender As Object, e As EventArgs) Handles cmdDkClose.Click
        'update the bill with drinks selected and close this window

        If blnDrinksOut Then
            With _objOwnerForm
                .lblDrinksOE.Text = lblDrinksTotal.Text
                .lblDrinksOE.Visible = (ugdDrinksGrid.Rows.Count > 0)
                .lblDrinksOELbl.Visible = (ugdDrinksGrid.Rows.Count > 0)
            End With
            Hide()

        Else
            'color table
            If udsTableGrid.Rows.Count > 0 Or lblDrinksTotal.Text <> "0.00" Then
                If TableInfo(CurTable).Id = 0 Then AssignUniqueID(CurTable)
                If TableInfo(CurTable).Status = TStatusEnum.Clean Then SetTableStatus(CurTable, TStatusEnum.InUse)
                SetTableColour(CurTable, True)
            Else
                DeleteUniqueID()
                SetTableColour(CurTable, False)
            End If

            InsertDrinksToDB()
            lblTDrinks.Text = lblDrinksTotal.Text
            lblBillTotal.Text = fixCur(CalcFoodTotal)
            DisplayAllTotals()

            If String.IsNullOrEmpty(lblEntryTime.Text) Then
                SQLQuery = $"SELECT EntryTime FROM Table_Bill WHERE TabUniqueID = {TableInfo(CurTable).Id}"
                drDataRow = objDB.GetSingleRow(SQLQuery)
                If drDataRow IsNot Nothing AndAlso drDataRow!EntryTime.ToString <> "00:00:00" Then
                    Dim entryTime As DateTime = CDate(drDataRow!EntryTime.ToString)
                    Dim timeSpan As TimeSpan = Now - entryTime
                    lblEntryTime.Text = $"Time of entry: {entryTime:hh:mm}" & vbCrLf & $"({timeSpan.Hours:D1}:{timeSpan.Minutes:D2})"
                End If
            End If

            DisplayPanel(AllPanels.Bill)
            cmdDkPrevious.Visible = False
            cmdDkNext.Visible = False
            cmdClosePanel.Visible = True
            Application.DoEvents()

            If GetAppSettingCS("DrinkDisplayMethod", "") = "GROUPED" AndAlso cmdDkPrevious.Enabled = True Then
                NavDrinksGrouped("cmdDkPrevious", True, 0)
            End If

        End If

    End Sub

    Private Sub InsertDrinksToDB()

        Dim Dk_Name, Dk_Price, Dk_Qty As String

        If blnDrinksDirty = True Then

            'first delete existing drinks from the table
            SQLQuery = "DELETE FROM Table_Drinks WHERE TabUniqueID = " & TableInfo(CurTable).Id
            objDB.ExeNonQuery(SQLQuery)

            'now insert the drinks in the DB table
            With ugdDrinksGrid
                For Each mrow In .Rows
                    Dk_Name = .Rows(mrow.Index).Cells("DkName").Value().ToString.Punctuate
                    Dk_Qty = .Rows(mrow.Index).Cells("DkQty").Value()
                    Dk_Price = .Rows(mrow.Index).Cells("DkPrice").Value()
                    SQLQuery = $"INSERT INTO Table_Drinks (TabUniqueID, DkName, DkQty, DkPrice) 
                                 VALUES ({TableInfo(CurTable).Id}, '{Dk_Name}', '{Dk_Qty}', '{Dk_Price}')"

                    'execute the SQL command
                    objDB.ExeNonQuery(SQLQuery)
                Next
            End With
            blnDrinksDirty = False
        End If

    End Sub

    Private Sub DrinkClickEvent(sender As UltraButton, e As EventArgs)

        Dim ubtnDrink As UltraButton = sender

        If ubtnDrink.Text = String.Empty Or ubtnDrink.Tag.ToString = "x" Then Exit Sub

        If UpdateDrinkInGrid(ubtnDrink.Text) = True Then
            'nothing to do here
        Else
            Dim myRow As UltraDataRow = udsDrinks.Rows.Add()
            myRow.Item("DkQty") = "1"
            myRow.Item("DkName") = ubtnDrink.Text.Replace("&&", "&").Punctuate
            myRow.Item("DkPrice") = ubtnDrink.Tag
            myRow.Item("DkTotal") = fixCur(ubtnDrink.Tag)
        End If

        ugdDrinksGrid.SuspendLayout()
        ugdDrinksGrid.DataSource = udsDrinks
        If ugdDrinksGrid.Rows.Count > 0 Then
            ugdDrinksGrid.ActiveRow = ugdDrinksGrid.Rows(0)
        Else
            ugdDrinksGrid.ActiveRow = Nothing
        End If
        ugdDrinksGrid.ResumeLayout()
        ugdDrinksGrid.Refresh()

        lblDrinksTotal.Text = fixCur(CalcDrinksTotal)
        UpdateDrinkRank(ubtnDrink.Text)
        blnDrinksDirty = True

    End Sub

    Private Function UpdateDrinkInGrid(strItem As String) As Boolean
        'returns True if item is found in grid and updated

        For Each mRow As UltraDataRow In udsDrinks.Rows
            tempStr = mRow.Item("DkName")
            If strItem.ToUpper = tempStr.ToUpper Then
                mRow.Item("DkQty") += 1
                mRow.Item("DkTotal") = fixCur(mRow.Item("DkQty") * mRow.Item("DkPrice"))
                Return True
            End If
        Next

        Return False

    End Function

    Private Sub UpdateDrinkRank(strDrinkName As String)

        SQLQuery = $"UPDATE Drinks SET Rank = Rank + 1 WHERE Name = '{strDrinkName.Punctuate}'"
        objDB.ExeNonQuery(SQLQuery)

    End Sub

    Private Sub cmdDkUpDown_Click(sender As Object, e As EventArgs) Handles cmdDkUp.Click, cmdDkDown.Click

        If ugdDrinksGrid.Rows.Count > 0 Then
            If ugdDrinksGrid.ActiveRow Is Nothing Then ugdDrinksGrid.ActiveRow = ugdDrinksGrid.Rows(0)
            If sender.name = "cmdDkUp" Then
                If ugdDrinksGrid.ActiveRow.Index > 0 Then
                    ugdDrinksGrid.ActiveRow = ugdDrinksGrid.Rows(ugdDrinksGrid.ActiveRow.Index - 1)
                Else
                    ugdDrinksGrid.ActiveRow = ugdDrinksGrid.Rows(ugdDrinksGrid.Rows.Count - 1)
                End If
            Else
                If ugdDrinksGrid.ActiveRow.Index < ugdDrinksGrid.Rows.Count - 1 Then
                    ugdDrinksGrid.ActiveRow = ugdDrinksGrid.Rows(ugdDrinksGrid.ActiveRow.Index + 1)
                Else
                    ugdDrinksGrid.ActiveRow = ugdDrinksGrid.Rows(0)
                End If
            End If
        End If

    End Sub

    Private Sub cmdDkAddDeductDelete_Click(sender As Object, e As EventArgs) Handles cmdDkAdd.Click, cmdDkDeduct.Click, cmdDkDelete.Click

        If ugdDrinksGrid.ActiveRow Is Nothing Then Exit Sub

        If sender.name = "cmdDkAdd" Then
            ugdDrinksGrid.ActiveRow.Cells("DkQty").Value += 1
            ugdDrinksGrid.ActiveRow.Cells("DkTotal").Value = fixCur(ugdDrinksGrid.ActiveRow.Cells("DkQty").Value * ugdDrinksGrid.ActiveRow.Cells("DkPrice").Value)

        ElseIf sender.name = "cmdDkDeduct" Then
            If ugdDrinksGrid.ActiveRow.Cells("DkQty").Value > 1 Then
                ugdDrinksGrid.ActiveRow.Cells("DkQty").Value -= 1
                ugdDrinksGrid.ActiveRow.Cells("DkTotal").Value = fixCur(ugdDrinksGrid.ActiveRow.Cells("DkQty").Value * ugdDrinksGrid.ActiveRow.Cells("DkPrice").Value)
            End If

        Else
            With ugdDrinksGrid
                If .Rows.Count > 0 AndAlso .ActiveRow IsNot Nothing Then
                    .ActiveRow.Delete(False)
                    lblDrinksTotal.Text = fixCur(CalcDrinksTotal)
                End If
            End With
        End If

        lblDrinksTotal.Text = fixCur(CalcDrinksTotal)

        blnDrinksDirty = True

    End Sub

    Private Sub CreateDrinksArray()

        Dim intNumDrinks, iCnt As Short
        Dim intOpt As Short
        Dim dttDataTable As New DataTable
        Dim ubtnTemp As New UltraButton

        'get values from the DB
        If GetAppSettingCS("DrinkDisplayMethod", "") = "ALPHA" Then
            DrinksTableAdapter.FillByAlpha(EZMenuDataSet.Drinks)

        ElseIf GetAppSettingCS("DrinkDisplayMethod", "") = "RANK" Then
            DrinksTableAdapter.FillByRank(EZMenuDataSet.Drinks)

        Else
            DrinksTableAdapter.FillByNumeric(EZMenuDataSet.Drinks)

        End If

        dttDataTable = EZMenuDataSet.Drinks

        intNumDrinks = DrinksBindingSource.Count
        If intNumDrinks > 0 Then
            DrinksBindingSource.MoveFirst()
            For iCnt = 1 To intNumDrinks
                intOpt = constDrinkButtonAppearance
                ubtnTemp = New UltraButton
                With ubtnTemp
                    tempStr = dttDataTable.Rows(iCnt - 1).Item("Name").ToString.Trim
                    tempStr = Replace(tempStr, "&", "&&")
                    If tempStr.IndexOf(">>") > -1 Then
                        intOpt = constDrinkButtonAppearanceGrouped
                        .Text = tempStr.Substring(2)
                        .Tag = "x"
                    Else
                        .Text = tempStr
                        .Tag = dttDataTable.Rows(iCnt - 1).Item("Price")
                    End If
                    DrinksButtonsAppearance(ubtnTemp, intOpt)
                End With
                AddHandler ubtnTemp.Click, AddressOf DrinkClickEvent
                pnlDrinksDrinks.ClientArea.Controls.Add(ubtnTemp)
                DrinksBindingSource.MoveNext()
            Next

            'cmdDkPrevious.Enabled = False
            'cmdDkNext.Enabled = (intNumDrinks > 56)
            pnlDrinksDrinks.ClientArea.ResumeLayout()

        Else

            DrinksErrMsg()

        End If

    End Sub

    Private Sub CreateDrinksArrayGrouped()

        Dim ubtnTemp As New UltraButton
        Dim intNumDrinks, gridRows, iCnt, maxCols As Short
        Dim leftOffSet, topOffSet As Short

        gridRows = 14
        maxCols = 4
        leftOffSet = 15
        topOffSet = 62

        Dim drcDkGroup As DataRowCollection = objDB.GetDataRows("SELECT DISTINCT DkGroup FROM Drinks ORDER BY DkGroup")
        If drcDkGroup IsNot Nothing Then
            For Each myRow As DataRow In drcDkGroup
                arrDrinks.Add(">>" & myRow!DkGroup)
                'get all drinks from group
                SQLQuery = String.Format("SELECT CASE WHEN [Name] = '<blank>' THEN 'ZZZZ' ELSE [Name] END AS [Name], Price 
                                          FROM Drinks 
                                          WHERE DkGroup = '{0}' 
                                          ORDER BY [Name]", myRow!DkGroup, strBlankDrinkField)

                drcDatarowCollection = objDB.GetDataRows(SQLQuery)
                If drcDatarowCollection IsNot Nothing Then
                    For Each myGroup As DataRow In drcDatarowCollection
                        arrDrinks.Add(myGroup!Name & "~" & myGroup!Price)
                    Next
                End If
            Next
        End If

        intNumDrinks = arrDrinks.Count
        If intNumDrinks > 0 Then
            For iCnt = 0 To intNumDrinks - 1
                intButtonAppn = constDrinkButtonAppearance
                ubtnTemp = New UltraButton
                With ubtnTemp
                    tempStr = arrDrinks(iCnt).ToString.Trim

                    If tempStr.IndexOf(">>") > -1 Then
                        intButtonAppn = constDrinkButtonAppearanceGrouped
                        .Text = tempStr.Substring(2).ToUpper
                        .Tag = "x"

                    ElseIf tempStr.ToUpper.Substring(0, 4) = "ZZZZ" Then
                        .Text = String.Empty
                        .Tag = "x"

                    Else
                        .Text = tempStr.Substring(0, tempStr.IndexOf("~"))
                        .Tag = tempStr.Substring(tempStr.IndexOf("~") + 1)

                    End If

                    DrinksButtonsAppearance(ubtnTemp, intButtonAppn)
                    If .Tag = "x" Then
                        .PressedAppearance = Nothing
                        .HotTrackAppearance = Nothing
                    End If
                End With
                AddHandler ubtnTemp.Click, AddressOf DrinkClickEvent
                pnlDrinksDrinks.ClientArea.Controls.Add(ubtnTemp)

                intArrPos = iCnt + 1

            Next

            'cmdDkPrevious.Enabled = False
            'cmdDkNext.Enabled = (arrDrinks.Count > 56)
            pnlDrinksDrinks.ClientArea.ResumeLayout()

        Else

            DrinksErrMsg()

        End If

    End Sub

    Private Sub DrinksErrMsg()

        Dim lblError As New UltraLabel
        With lblError
            .Text = "No drinks have been found in the database."
            .AutoSize = True
            .Appearance.FontData.SizeInPoints = 12
            .Appearance.ForeColor = Color.White
            .Appearance.BackColor = Color.Transparent
            .Visible = True
            .UseAppStyling = False
            pnlDrinksDrinks.ClientArea.Controls.Add(lblError)
            .Location = New Point(150, (Height - .Height) / 2)
        End With

    End Sub

    Private Sub DrinksButtonsAppearance(btnName As UltraButton, Optional intGroup As Short = 3)

        With btnName

            .Appearance = GetButtonAppearances(intGroup)
            If intGroup = constDrinkButtonAppearance Then
                .Appearance.ImageBackground = My.Resources.ezresource.drinks_button
            Else
                .Appearance.ImageBackground = My.Resources.ezresource.dkbutton_group
            End If
            .HotTrackAppearance = GetButtonAppearances(1)
            .HotTrackAppearance.ForeColor = Color.Wheat
            .HotTrackAppearance.ImageBackground = My.Resources.ezresource.dkbutton_hilit
            .PressedAppearance = GetButtonAppearances(5)
            .PressedAppearance.ImageBackground = My.Resources.ezresource.dkbutton_press

            .Font = New Font("Franklin Gothic Medium", GetAppSettingCS("FontSizeDrinksArray", 10), FontStyle.Regular, GraphicsUnit.Point, 0)
            .Name = "DrinksName"
            .ShowFocusRect = False
            .ShowOutline = False
            .Size = New Size(153, 43)
            .UseAppStyling = False
            .UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
            .UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
            .UseMnemonic = False
            .UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]

        End With

    End Sub

    Private Sub DrinkNextPrevious(sender As Object, e As EventArgs) Handles cmdDkPrevious.Click, cmdDkNext.Click

        If GetAppSettingCS("DrinkDisplayMethod", "") = "GROUPED" Then
            NavDrinksGrouped(sender.name)
        Else
            NavDrinks(sender.name)
        End If

    End Sub

    Private Sub NavDrinks(strButtonText As String)

        Try
            Dim p As Integer = 0

            Select Case strButtonText
                Case "cmdDkNext"
                    p = pnlDrinksDrinks.Left - (pnlDrinksContainer.Width * 0.9)
                    If p <= (pnlDrinksContainer.Width - pnlDrinksDrinks.Width) - 4 Then p = (pnlDrinksContainer.Width - pnlDrinksDrinks.Width) - 4

                Case "cmdDkPrevious"
                    p = pnlDrinksDrinks.Left + (pnlDrinksContainer.Width * 0.9)
                    If p > 2 Then p = 2

            End Select

            pnlDrinksDrinks.Left = p

        Catch ex As Exception
        End Try

        'Dim blnBlankRest, blnExitLoop As Boolean
        'Dim dttDataTable As DataTable = EZMenuDataSet.Drinks

        'If strButtonText = "cmdDkNext" Then

        '    pnlDrinksDrinks.SuspendLayout()

        '    For Each myobjx In pnlDrinksDrinks.ClientArea.Controls
        '        If (myobjx.name = "DrinksName") Then
        '            If blnBlankRest = True Then
        '                myobjx.Visible = False
        '                cmdDkNext.Enabled = False
        '            Else
        '                myobjx.Text = dttDataTable.Rows(DrinksBindingSource.Position).Item("Name")
        '                myobjx.Tag = dttDataTable.Rows(DrinksBindingSource.Position).Item("Price")
        '                myobjx.Visible = True
        '                If DrinksBindingSource.Position + 1 < DrinksBindingSource.Count Then
        '                    DrinksBindingSource.MoveNext()
        '                Else
        '                    blnBlankRest = True
        '                End If
        '            End If
        '        End If
        '    Next

        '    cmdDkPrevious.Enabled = True
        '    cmdDkNext.Enabled = Not blnBlankRest

        '    pnlDrinksDrinks.ResumeLayout()

        'ElseIf strButtonText = "cmdDkPrevious" Then

        '    'move position of the record collection
        '    tValue = DrinksBindingSource.Position Mod 56
        '    If tValue = 0 Then tValue = 56
        '    DrinksBindingSource.Position = DrinksBindingSource.Position - tValue - 56

        '    cmdDkPrevious.Enabled = (DrinksBindingSource.Position > 0)
        '    pnlDrinksDrinks.SuspendLayout()

        '    For Each myobjx In pnlDrinksDrinks.ClientArea.Controls
        '        If blnExitLoop = True Then
        '            Exit For
        '        ElseIf (myobjx.name = "DrinksName") Then
        '            myobjx.Text = dttDataTable.Rows(DrinksBindingSource.Position).Item("Name")
        '            myobjx.Tag = dttDataTable.Rows(DrinksBindingSource.Position).Item("Price")
        '            myobjx.Visible = True
        '            If DrinksBindingSource.Position + 1 < DrinksBindingSource.Count Then
        '                DrinksBindingSource.MoveNext()
        '            Else
        '                blnExitLoop = True
        '            End If
        '        End If
        '    Next

        '    cmdDkNext.Enabled = (DrinksBindingSource.Position < DrinksBindingSource.Count)

        '    pnlDrinksDrinks.ResumeLayout()

        'End If

    End Sub

    Private Sub NavDrinksGrouped(strButtonText As String, Optional blnSuspendLayout As Boolean = True, Optional intStartingPos As Short = -1)

        Dim blnBlankRest, blnExitLoop As Boolean

        Try

            If strButtonText = "cmdDkNext" Then

                If blnSuspendLayout = True Then pnlDrinksDrinks.SuspendLayout()

                For Each myobjx In pnlDrinksDrinks.ClientArea.Controls
                    If (myobjx.name = "DrinksName") Then
                        If blnBlankRest = True Then
                            myobjx.Visible = False
                            cmdDkNext.Enabled = False
                        Else
                            tempStr = arrDrinks(intArrPos).ToString.Trim
                            If tempStr.IndexOf(">>") > -1 Then
                                myobjx.Text = tempStr.Substring(2).ToUpper
                                myobjx.Tag = "x"
                                intButtonAppn = constDrinkButtonAppearanceGrouped
                            Else
                                myobjx.Text = tempStr.Substring(0, tempStr.IndexOf("~"))
                                myobjx.Tag = tempStr.Substring(tempStr.IndexOf("~") + 1)
                                intButtonAppn = constDrinkButtonAppearance
                            End If

                            DrinksButtonsAppearance(myobjx, intButtonAppn)
                            If myobjx.Tag = "x" Then
                                myobjx.PressedAppearance = Nothing
                                myobjx.HotTrackAppearance = Nothing
                            End If
                            myobjx.Visible = True
                            If intArrPos + 1 < arrDrinks.Count Then
                                intArrPos += 1
                            Else
                                blnBlankRest = True
                            End If
                        End If
                    End If
                Next

                cmdDkPrevious.Enabled = True
                cmdDkNext.Enabled = Not blnBlankRest

                If blnSuspendLayout = True Then pnlDrinksDrinks.ResumeLayout()

            ElseIf strButtonText = "cmdDkPrevious" Then

                'move record position backwards
                If intStartingPos = 0 Then
                    intArrPos = 0
                Else
                    tValue = intArrPos Mod 56
                    If tValue = 0 Then tValue = 56
                    intArrPos = intArrPos - tValue - 56
                End If

                cmdDkPrevious.Enabled = (intArrPos > 0)
                If blnSuspendLayout = True Then pnlDrinksDrinks.SuspendLayout()

                For Each myobjx In pnlDrinksDrinks.ClientArea.Controls
                    If blnExitLoop = True Then
                        Exit For
                    ElseIf (myobjx.name = "DrinksName") Then

                        tempStr = arrDrinks(intArrPos).ToString.Trim
                        If tempStr.IndexOf(">>") > -1 Then
                            myobjx.Text = tempStr.Substring(2).ToUpper
                            myobjx.Tag = "x"
                            intButtonAppn = constDrinkButtonAppearanceGrouped
                        Else
                            myobjx.Text = tempStr.Substring(0, tempStr.IndexOf("~"))
                            myobjx.Tag = tempStr.Substring(tempStr.IndexOf("~") + 1)
                            intButtonAppn = constDrinkButtonAppearance
                        End If

                        DrinksButtonsAppearance(myobjx, intButtonAppn)

                        If myobjx.Tag = "x" Then
                            myobjx.PressedAppearance = Nothing
                            myobjx.HotTrackAppearance = Nothing
                        End If
                        myobjx.visible = True
                        If intArrPos + 1 < arrDrinks.Count Then
                            intArrPos += 1
                        Else
                            blnExitLoop = True
                        End If

                    End If
                Next

                cmdDkNext.Enabled = (intArrPos < arrDrinks.Count)
                If blnSuspendLayout = True Then pnlDrinksDrinks.ResumeLayout()

            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub cmdDkClearAll_Click(sender As Object, e As EventArgs) Handles cmdDkClearAll.Click

        strMsgBox = "Clear all drinks in the list?"
        intMsgBoxResult = EZMsgBox.Show(strMsgBox, MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If intMsgBoxResult = MsgBoxResult.Yes Then ClearDrinksGrid()

    End Sub

    Private Sub cmdClosePanel_Click(sender As Object, e As EventArgs) Handles cmdClosePanel.Click

        Try

            If blnDrinksOut Then
                Me.Hide()

            Else
                'if bill or drinks panel showing then show tables panel, else close and show main form
                Dim strCurMainPanelName As String = pnlCurrentMainPanel.Name.Substring(3)

                'if drinks then show bill
                If strCurMainPanelName = "Drinks" Then
                    DisplayPanel(AllPanels.Bill)

                    'if bill then show main tables
                ElseIf strCurMainPanelName = "Bill" Then
                    DisplayPanel(AllPanels.Tables)

                    'if tables then show main form
                ElseIf strCurMainPanelName = "Tables" Then
                    Me.Hide()

                End If
            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub cmdTableClear_Click(sender As Object, e As EventArgs) Handles cmdTableClear.Click

        strMsgBox = "Clear everything and start a new bill?"
        intMsgBoxResult = EZMsgBox.Show(strMsgBox, MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If intMsgBoxResult = MsgBoxResult.Yes Then

            'clear the grid
            udsDrinks.Rows.Clear()
            udsTableGrid.Rows.Clear()
            ugdDrinksGrid.Update()
            ugdTableGrid.Update()

            'remove colour from the button for this table
            SetTableColour(CurTable, False)

            'do not delete from DB if it is printed, save it
            If TableInfo(CurTable).Status = TStatusEnum.Printed Then
                'set saved status
                SetTableStatus(CurTable, TStatusEnum.Saved)

            ElseIf TableInfo(CurTable).Status < 2 Then
                'has not been printed so delete it

                'delete from meals table
                SQLQuery = $"DELETE FROM Table_Meal WHERE TabUniqueID = { TableInfo(CurTable).Id }"
                objDB.ExeNonQuery(SQLQuery)

                'delete from drinks table
                SQLQuery = $"DELETE FROM Table_Drinks WHERE TabUniqueID = { TableInfo(CurTable).Id }"
                objDB.ExeNonQuery(SQLQuery)

                DeleteUniqueID()

            End If

            'reset the Id
            TableInfo(CurTable).Id = 0
            TableInfo(CurTable).Status = TStatusEnum.Clean

            DisplayPanel(AllPanels.Tables)

        End If

    End Sub

    Private Sub cmdTableDiscard_Click(sender As Object, e As EventArgs) Handles cmdTableDiscard.Click

        strMsgBox = "Completely discard this bill?" & vbCrLf & "(You will not be able to recover this info)"
        intMsgBoxResult = EZMsgBox.Show(strMsgBox, MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        If intMsgBoxResult = MsgBoxResult.Yes Then

            'delete everything from the DB about this table
            SQLQuery = $"DELETE FROM Table_Drinks WHERE TabUniqueID = { TableInfo(CurTable).Id }"
            objDB.ExeNonQuery(SQLQuery)

            SQLQuery = $"DELETE FROM Table_Meal WHERE TabUniqueID = { TableInfo(CurTable).Id }"
            objDB.ExeNonQuery(SQLQuery)

            SQLQuery = $"DELETE FROM Table_Bill WHERE TabUniqueID = { TableInfo(CurTable).Id }"
            objDB.ExeNonQuery(SQLQuery)

            SQLQuery = $"DELETE FROM Table_Mods WHERE TabUniqueID = { TableInfo(CurTable).Id }"
            objDB.ExeNonQuery(SQLQuery)

            SetTableColour(CurTable, False)
            DeleteUniqueID()

            DisplayPanel(AllPanels.Tables)

        End If

    End Sub

    Private Sub cmdTableEdit_Click(sender As Object, e As EventArgs) Handles cmdTableEdit.Click

        Try

            'assign unique id if required
            If TableInfo(CurTable).Id = 0 Then AssignUniqueID(CurTable)

            If objOrderEntry IsNot Nothing Then objOrderEntry.Dispose()
            objOrderEntry = New frmOrderEntry

            'clear the main form grid
            objOrderEntry.udsOrder.Rows.Clear()

            'copy all the items in the bill to the editing section
            For Each myRow As UltraDataRow In udsTableGrid.Rows
                If myRow("Mods") <> strIsModRow Then
                    Dim udrRow As UltraDataRow = objOrderEntry.udsOrder.Rows.Add
                    udrRow.Item("DCode") = myRow("Code")
                    udrRow.Item("DName") = myRow("Dish")
                    udrRow.Item("DPrice") = myRow("Price")
                    udrRow.Item("DQty") = myRow("Qty")
                    udrRow.Item("Total") = myRow("Total")
                    udrRow.Item("Mods") = myRow("Mods")
                    udrRow.Item("Discountable") = myRow("Discountable")
                    udrRow.Item("IsStarter") = myRow("IsStarter")
                    udrRow.Item("OriPrice") = myRow("Price")
                    udrRow.Item("GroupIndex") = myRow("GroupIndex")
                    udrRow.Item("HiLite") = "0"

                    'get any mod rows
                    Dim orderMods As IEnumerable(Of OrderModsModel) = tableRepo.GetTableModsFromDB(TableInfo(CurTable).Id, myRow("Dish"))
                    If orderMods.Any Then
                        For Each om In orderMods
                            Dim udrModRow As UltraDataRow = objOrderEntry.udsOrder.Rows.Add
                            udrModRow.Item("DQty") = String.Empty
                            udrModRow.Item("DName") = "- " + om.ModName
                            udrModRow.Item("DPrice") = om.ModCost
                            udrModRow.Item("Total") = fixCur(myRow("Qty") * om.ModCost)
                            udrModRow.Item("Mods") = strIsModRow
                            udrModRow.Item("Discountable") = 0
                        Next
                    End If

                    ''get any set items
                    'Dim strSetItems As String = objDB.GetSetItemsFromDB(TableInfo(CurTable).Id, myRow("Dish"))
                    'If strSetItems <> String.Empty Then
                    '    Dim arrSets = strSetItems.Split("^^")
                    '    For aCnt = arrSets.GetLowerBound(0) To arrSets.GetUpperBound(0)
                    '        If arrSets(aCnt) <> String.Empty Then
                    '            Dim arrSetItems() = arrSets(aCnt).Split("#")
                    '            Dim udrModRow As UltraDataRow = objOrderEntry.udsOrder.Rows.Add
                    '            'udrModRow.Item("DQty") = arrSetItems(0)
                    '            udrModRow.Item("DQty") = IIf(GetAppSettingCS("SetPutQty", True) = True, arrSetItems(0), "")
                    '            udrModRow.Item("DName") = "- " & arrSetItems(1)
                    '            udrModRow.Item("DPrice") = arrSetItems(2)
                    '            udrModRow.Item("Total") = fixCur(arrSetItems(0) * arrSetItems(2))
                    '            udrModRow.Item("Mods") = strIsSetItem
                    '            udrModRow.Item("Discountable") = 0
                    '        End If
                    '    Next
                    'End If

                    'adjust for papadom price
                    If myRow("Dish").ToUpper Like ("*" & strChutney.ToUpper) Then
                        udrRow.Item("DName") = myRow("Dish").ToString.Replace(strChutney, "").Trim
                        udrRow.Item("Total") = myRow("Qty") * myRow("Price")
                    End If
                End If
            Next

            objOrderEntry.ugdOrderGrid.DataSource = objOrderEntry.udsOrder

            With objOrderEntry
                .CurrentOrderType = OrderTypeEnum.Table
                .cmdOEBack.Enabled = False
                .cmdOENext.Appearance.Image = My.Resources.ezresource.tick
                .cmdOEDiscounts.Enabled = False
                .cmdPrintLabels.Enabled = False
                .cmdPrevOrder.Enabled = False
                .cmdAddDrink.Enabled = False
                '.cmdSetMeals.Enabled = False
                .pnlDishes.ClientArea.Controls.Clear()
                .pnlGroup.ClientArea.Controls.Clear()
                .cmdCuisine.Text = GetAppSettingCS("MultiCuisinesDefault", "Indian")
                .CreateGroupButtons("Menu")
                .AddUpGridTotals()
                .ShowDialog(Me)
            End With

            'If Not objOrderEntry.CancelPressed Then AddUpGridTotals()

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub cmdCovers_Click(sender As Object, e As EventArgs) Handles cmdCovers.Click

        GetCovers()

    End Sub

    Private Sub GetCovers()
        'update the database and save number of customers in the DB

        Dim strNumInput As String

        Using objFormQty As New frmQty
            objFormQty.Display("Enter number of customers", "0")
            strNumInput = objFormQty.ReturnValue
        End Using

        If strNumInput <> "x" Then
            Try
                CurCusts = CShort(strNumInput)
                If (CurCusts > 0 And CurCusts < 100) Then
                    UpdateTableHeader()
                    If CAPValue = 0 Then CAPValue = strNumInput
                    If TableInfo(CurTable).Id = 0 Then AssignUniqueID(CurTable)
                    If TableInfo(CurTable).Status = TStatusEnum.Clean Then SetTableStatus(CurTable, TStatusEnum.InUse)

                    'update the number of customers into the DB
                    SQLQuery = $"UPDATE Table_Bill
                                 SET NumCust = { CurCusts }, CAPValue = { CAPValue }
                                 WHERE TabUniqueID = { TableInfo(CurTable).Id }"
                    objDB.ExeNonQuery(SQLQuery)

                    UpdatePapaPrice()

                    DisplayAllTotals()

                    If GetAppSettingCS("TablesExtMode", True) = True Then
                        For Each myObj As Control In tlpTables.Controls
                            If (TypeOf myObj Is EZTableButton) Then
                                Dim myObjx As EZTableButton = DirectCast(myObj, EZTableButton)
                                If myObjx.TableNumber = CurTable Then myObjx.Covers = strNumInput
                            End If
                        Next
                    End If
                    SetTableStatus(CurTable, TStatusEnum.InUse)
                    GetTableInfo(CurTable)
                Else
                    strMsgBox = "Number must between 1 and 99"
                    Alert(strMsgBox, MessageBoxIcon.Exclamation)
                End If

            Catch ex As Exception
                DisplayError(ex)
            End Try
        End If

    End Sub

    Private Sub cmdTableDiscounts_Click(sender As Object, e As EventArgs) Handles cmdTableDiscounts.Click

        If TableInfo(CurTable).Id <> 0 Then

            Using objPriceAdjustments As New frmPriceAdjustments
                objPriceAdjustments.ubtnDCToggleGlobal.Enabled = False
                objPriceAdjustments.Display(OrderTypeEnum.Table, totalsAdjustmentsDiscounts, totalsAdjustmentsCharges)
                Dim returnValue As PriceAdjustmentsModel = objPriceAdjustments.ReturnValue

                If returnValue.Cancelled = False Then
                    If returnValue.Reset = True Then
                        If returnValue.DiscountOrCharge = DiscountOrChargeEnum.Discount Then
                            orderDiscounts = Nothing
                            lblDiscountsLbl.Text = "Discounts:"
                            lblDiscounts.Text = "0.00"
                        ElseIf returnValue.DiscountOrCharge = DiscountOrChargeEnum.Charge Then
                            orderCharges = Nothing
                            lblChargesLbl.Text = "Charges:"
                            lblCharges.Text = "0.00"
                        End If
                    Else
                        returnValue.CalculatedTotal = CalculateTableDiscounts(returnValue, CalcFoodTotal, CalcDrinksTotal)
                        If returnValue.DiscountOrCharge = DiscountOrChargeEnum.Discount Then
                            orderDiscounts = returnValue
                            lblDiscountsLbl.Text = IIf(returnValue.Name = "", "Discounts:", returnValue.Name + ":")
                            lblDiscounts.Text = fixCurFive(returnValue.CalculatedTotal)
                        ElseIf returnValue.DiscountOrCharge = DiscountOrChargeEnum.Charge Then
                            orderCharges = returnValue
                            lblChargesLbl.Text = IIf(returnValue.Name = "", "Charges:", returnValue.Name + ":")
                            lblCharges.Text = fixCurFive(returnValue.CalculatedTotal)
                        End If
                    End If

                    'update the number of customers into the DB
                    SQLQuery = $"UPDATE Table_Bill 
                                 SET DiscountAmount = { lblDiscounts.Text }, 
                                     ChargeAmount = { lblCharges.Text }, 
                                     DiscountLabelText = '{ lblDiscountsLbl.Text.Replace(":", "") }', 
                                     ChargeLabelText = '{ lblChargesLbl.Text.Replace(":", "") }' 
                                 WHERE TabUniqueID = { TableInfo(CurTable).Id }"

                    objDB.ExeNonQuery(SQLQuery)
                    DisplayAllTotals()

                End If

            End Using
        Else
            Alert("Table is empty", MessageBoxIcon.Asterisk)
        End If

    End Sub

    Private Function CalculateTableDiscounts(tableRet As PriceAdjustmentsModel, calcSubTotal As Decimal, calcDrinksTotal As Decimal) As Decimal

        Dim ret
        Dim sourceVal As Decimal

        If tableRet.MealDrinksBoth = AppliesToTableEnum.MealOnly Then
            sourceVal = calcSubTotal
        ElseIf tableRet.MealDrinksBoth = AppliesToTableEnum.DrinksOnly Then
            sourceVal = calcDrinksTotal
        ElseIf tableRet.MealDrinksBoth = AppliesToTableEnum.Both Then
            sourceVal = calcSubTotal + calcDrinksTotal
        End If

        If tableRet.AmountOrPercentage = AmountOrPercentageEnum.Percentage Then
            ret = sourceVal * (tableRet.Value / 100)
        ElseIf tableRet.AmountOrPercentage = AmountOrPercentageEnum.Amount Then
            ret = tableRet.Value
        Else
            ret = 0
        End If

        Dim discount As Decimal = fixCurFive(ret)
        Return discount

    End Function

    Private Sub DeleteUniqueID()
        'if no dish or drink is added to the database then delete this table's
        'unique id from the database

        'delete from DB
        SQLQuery = "DELETE FROM Table_Bill WHERE TabUniqueID = " & TableInfo(CurTable).Id & ";"
        objDB.ExeNonQuery(SQLQuery)

        'reset the Id
        TableInfo(CurTable).Id = 0
        TableInfo(CurTable).Status = TStatusEnum.Clean

    End Sub

    Private Sub ClearTableScreen()
        'clears tables screen - clears grid, initialises labels, etc

        lblTDrinks.Text = "0.00"
        lblTSubtotal.Text = "0.00"
        lblDiscounts.Text = "0.00"
        lblCharges.Text = "0.00"
        lblBillTotal.Text = "0.00"
        lblTTips.Text = "0.00"
        lblDrinksTotal.Text = "0.00"
        CAPValue = 0

        udsTableGrid.Rows.Clear()
        udsDrinks.Rows.Clear()
        ugdTableGrid.DataSource = udsTableGrid
        ugdDrinksGrid.DataSource = udsDrinks

    End Sub

    Public Function CalcDrinksTotal() As Decimal

        Dim decDrinkTotal As Decimal = 0

        For Each mRow As UltraDataRow In udsDrinks.Rows
            decDrinkTotal += mRow!DkTotal
        Next

        Return decDrinkTotal

    End Function

    Private Function CalcFoodTotal() As Decimal

        Dim decSubTotal As Decimal = 0

        For Each udrRow As UltraDataRow In udsTableGrid.Rows
            decSubTotal += udrRow!Total
        Next

        Return decSubTotal

    End Function

    Private Sub DisplayAllTotals()

        lblTSubtotal.Text = fixCur(CalcFoodTotal)
        lblBillTotal.Text = fixCur(CalcFoodTotal() + CalcDrinksTotal() - Val(lblDiscounts.Text) + Val(lblCharges.Text))

    End Sub

    Public Sub ShowTablesInUse()
        'shows tables which are currently being used by customers (1)
        'this includes ones that have been printed but not yet cleared (2)

        Try
            'blank all tables
            If MainOrSubSystem() <> "NOTMULTI" Then
                For xCntr As Short = 1 To NumberOfTables
                    SetTableColour(xCntr, False)
                Next
            End If

            SQLQuery = "SELECT TableNumber, NumCust, EntryTime, Lights 
                    FROM Table_Bill 
                    WHERE TableStatus IN (1, 2) 
                        AND (BizId BETWEEN 40 AND 60)"
            drcDatarowCollection = objDB.GetDataRows(SQLQuery)
            If drcDatarowCollection IsNot Nothing Then
                For Each myRow As DataRow In drcDatarowCollection
                    SetTableColour(myRow!TableNumber, True, myRow!NumCust, myRow!EntryTime.ToString, myRow!Lights)
                Next
            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub PrintBill(sender As Object, e As EventArgs) Handles cmdTablePrint.Click, cmdTableKCopy.Click

        Try

            'validate table is ok
            If ValidateTable() = True Then

                Dim decMealTotal As Decimal = lblTSubtotal.Text
                Dim decDrinksTotal As Decimal = lblTDrinks.Text
                Dim decBillTotal As Decimal = lblBillTotal.Text

                'save/update table details
                tableRepo.UpdateTableBill(TableInfo(CurTable).Id, fixCur(decBillTotal), fixCur(decMealTotal), fixCur((decDrinksTotal)))

                If sender Is cmdTablePrint Then SetTableStatus(CurTable, TStatusEnum.Printed)

                Dim intExCuisine As Short = intCurrentCuisine
                intCurrentCuisine = 1

                If sender Is cmdTableKCopy Then
                    PrintTable(TableInfo(CurTable).Id, PrintDestinationEnum.Kitchen)
                Else
                    PrintTable(TableInfo(CurTable).Id, PrintDestinationEnum.Shop)
                End If
                intCurrentCuisine = intExCuisine

                'SMX
                'If IsTabletPC Then
                '    DisplayMessage("Order has been sent to printer.")
                'End If

            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Function ValidateTable() As Boolean

        'a printer must be installed
        If Printing.PrinterSettings.InstalledPrinters.Count = 0 Then
            strMsgBox = "There are no printers installed on this system. Install a printer first and then try again."
            Alert(strMsgBox)
            Return False
        End If

        'select how many customers there are
        If CurCusts < 1 Then
            strMsgBox = "Select the number of customers at this table before printing."
            Alert(strMsgBox)
            Return False
        End If

        'see that there are some items in the item
        If ugdTableGrid.Rows.Count < 1 Then
            strMsgBox = "There are no items in this bill. Nothing to print."
            Alert(strMsgBox)
            Return False
        End If

        Return True

    End Function

    Private Sub cmdKitchenNote_Click(sender As Object, e As EventArgs) Handles cmdKitchenNote.Click

        If TableInfo(CurTable).Id <> 0 Then

            'get any existing note from the database
            SQLQuery = "SELECT TableNote FROM Table_Bill WHERE TabUniqueID = " & TableInfo(CurTable).Id
            drDataRow = objDB.GetSingleRow(SQLQuery)
            tempStr = "XXX"
            strKBInput = ""
            If drDataRow IsNot Nothing Then
                strKBInput = drDataRow!TableNote.ToString
            End If

            strKBInput = EZFullKeyboard.Show(strKBInput)

            If strKBInput <> EZKBEscape Then
                SQLQuery = $"UPDATE Table_Bill 
                             SET TableNote = '{ strKBInput }' 
                             WHERE TabUniqueID = { TableInfo(CurTable).Id }"
                objDB.ExeNonQuery(SQLQuery)
            End If

        Else
            Alert("Table is empty", MessageBoxIcon.Asterisk)
        End If

    End Sub

    Private Sub cmdTablePayment_Click(sender As Object, e As EventArgs) Handles cmdTablePayment.Click

        Try

            If TableInfo(CurTable).Id <> 0 Then

                'need to have number of covers specified
                If CurCusts < 1 Then
                    strMsgBox = "Select the number of customers at this table first"
                    Alert(strMsgBox, MessageBoxIcon.Information)
                Else
                    If objPayment Is Nothing Then
                        objPayment = New frmPayment
                    End If

                    With objPayment
                        .txtBillTotal.Text = lblBillTotal.Text
                        .Tag = "Tables"
                        .cmdBack.Enabled = False
                        .cmdKitchenCopy.Enabled = False
                        .cmdShopCopy.Enabled = False
                        .cmdPrintOrder.Enabled = False
                        .cmdSaveOrder.Enabled = False
                        .txtTips.Enabled = True
                        .ubtnTips.Enabled = True

                        Try
                            SQLQuery = $"SELECT COALESCE(PayMethod, 'Other') AS PayMethod, 
                                                COALESCE(Tips, 0) AS Tips
                                         FROM Table_Bill WHERE TabUniqueID = { TableInfo(CurTable).Id }"

                            drDataRow = objDB.GetSingleRow(SQLQuery)
                            If drDataRow IsNot Nothing Then
                                ButtonToggle(.cmdTenderCash, cstButTogClr)
                                ButtonToggle(.cmdTenderCard, cstButTogClr)
                                ButtonToggle(.cmdTenderOther, cstButTogClr)

                                If drDataRow("PaymentMethod") = "Cash" Then
                                    ButtonToggle(.cmdTenderCash, cstButTogYes)

                                ElseIf drDataRow("PaymentMethod") = "Card" Then
                                    ButtonToggle(.cmdTenderCard, cstButTogYes)

                                ElseIf drDataRow("PaymentMethod") = "Other" Then
                                    ButtonToggle(.cmdTenderOther, cstButTogYes)

                                End If

                                If drDataRow("PaymentMethod") = "Mixed" Then .cmdSplitPayment.Tag = "Mixed"
                                .txtTips.Text = CDec(drDataRow("Tips"))
                            End If
                        Catch ex As Exception
                            DisplayError(ex)
                        End Try
                        .Show(Me)
                        '.Dispose()
                    End With

                End If

            Else
                Alert("Table is empty", MessageBoxIcon.Asterisk)
            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub UpdatePapaPrice()

        If GetAppSettingCS("CAPStatus", True) = True Then
            Dim tStr As String
            With ugdTableGrid
                For Each mrow In .Rows
                    tStr = .Rows(mrow.Index.ToString).Cells("Dish").Value
                    If tStr.ToUpper Like strPapadom Then
                        tValue = .Rows(mrow.Index.ToString).Cells("Qty").Value * .Rows(mrow.Index.ToString).Cells("Price").Value
                        tValue += (CAPValue * (CDec(GetAppSettingCS("CAPValue", 0)) / 100))
                        .Rows(mrow.Index.ToString).Cells("Total").Value = fixCur(tValue)
                        tStr = Replace(tStr, strChutney, "").Trim
                        .Rows(mrow.Index.ToString).Cells("Dish").Value = tStr & strChutney
                        Exit For
                    End If
                Next
            End With

        End If

    End Sub

    Private Sub cmdMoveTable_Click(sender As Object, e As EventArgs) Handles cmdMoveTable.Click

        Try

            'If pnlBill.Tag = "MoveModeOff" Then
            If moveModeOn = False Then

                'table must not be empty
                If TableInfo(CurTable).Status = TStatusEnum.InUse Or TableInfo(CurTable).Status = TStatusEnum.Printed Then
                    If ugdTableGrid.Rows.Count > 0 Or lblTDrinks.Text <> "0.00" Then
                        'hide any non-empty tables
                        For Each myObj As Control In upnlMiniTables.ClientArea.Controls
                            If myObj.Name.StartsWith("MiniTable") Then
                                Dim myBut As UltraButton = DirectCast(myObj, UltraButton)
                                If myBut.Tag IsNot Nothing AndAlso myBut.Tag.ToString = "1" Then
                                    myBut.Visible = False
                                    lblMiniHilit.Visible = False
                                    'pnlBill.Tag = "MoveModeOn"
                                    moveModeOn = True
                                End If
                            End If
                        Next
                        'If pnlBill.Tag = "MoveModeOn" Then HideButtons()
                        If moveModeOn = True Then HideButtons()
                    Else
                        Alert("Table is empty", MessageBoxIcon.Asterisk)
                    End If
                Else
                    Alert("Table is empty", MessageBoxIcon.Asterisk)
                End If

            Else

                RestoreTables()

            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub HideButtons()

        Try

            'restore the buttons
            For Each myObj As Control In pnlBill.ClientArea.Controls
                If myObj.Size = New Size(126, 65) Then
                    If myObj.Tag <> "Move Table" Then myObj.Enabled = False
                End If
            Next

            Dim appnLabelAppearance As New Infragistics.Win.Appearance With {
                .BackColor = Color.Olive,
                .BorderColor = Color.Khaki,
                .ForeColor = Color.White,
                .TextHAlignAsString = "Center",
                .TextVAlignAsString = "Middle"
            }

            Dim lblMTLabel As New UltraLabel With {
                .Appearance = appnLabelAppearance,
                .BorderStyleInner = Infragistics.Win.UIElementBorderStyle.Solid,
                .BorderStyleOuter = Infragistics.Win.UIElementBorderStyle.Solid,
                .Font = New Font("Arial", 12, FontStyle.Regular, GraphicsUnit.Point, 0),
                .Location = New Point(cmdTableClear.Left, cmdTableClear.Top + (1.2 * cmdTableClear.Height)),
                .Name = "lblMTLabel",
                .Size = New Size(260, 44),
                .Text = "Select destination table",
                .UseAppStyling = False,
                .Visible = True
            }
            pnlBill.ClientArea.Controls.Add(lblMTLabel)

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub RestoreTables()

        Try
            'restore the tables
            For Each myObj As Control In upnlMiniTables.ClientArea.Controls
                If myObj.Name.StartsWith("MiniTable") Then myObj.Visible = True
            Next

            lblMiniHilit.Visible = True

            'restore the buttons
            For Each myObj As Control In pnlBill.ClientArea.Controls
                If myObj.Size = New Size(126, 65) Then myObj.Enabled = True
                If myObj.Name = "lblMTLabel" Then myObj.Hide()
            Next

            cmdLightsStatus.Enabled = GetAppSettingCS("TablesExtLights", True)

            'pnlBill.Tag = "MoveModeOff"
            moveModeOn = False

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub HighlightStarters()

        For Each myRow In ugdTableGrid.Rows
            If myRow.Cells("Mods").Value <> strIsModRow AndAlso myRow.Cells("IsStarter").Value <> 0 Then
                myRow.Appearance.BackColor = Color.FromArgb(195, 220, 195)
            End If
        Next

    End Sub

    Private Sub cmdCAP_Click(sender As Object, e As EventArgs) Handles cmdCAP.Click
        'set CAP value

        Dim intCAP As Short
        Dim strNumInput As String

        Using objFormQty As New frmQty
            objFormQty.Display("Enter chutney tray heads", "0")
            strNumInput = objFormQty.ReturnValue
        End Using

        If strNumInput <> "x" Then
            Try
                intCAP = Short.Parse(strNumInput)
                If (intCAP >= 0 And intCAP < 100) Then
                    CAPValue = intCAP

                    If TableInfo(CurTable).Id = 0 Then AssignUniqueID(CurTable)

                    'update the number of customers into the DB
                    SQLQuery = "UPDATE Table_Bill SET CAPValue = " & intCAP &
                               " WHERE TabUniqueID = " & TableInfo(CurTable).Id & ";"

                    objDB.ExeNonQuery(SQLQuery)
                    UpdatePapaPrice()
                    DisplayAllTotals()

                Else
                    strMsgBox = "Number must between 0 and 99"
                    Alert(strMsgBox)
                End If

            Catch ex As Exception
                DisplayError(ex)
            End Try

        End If

    End Sub

    Private Sub cmdAddMiscDrink_Click(sender As Object, e As EventArgs) Handles cmdDkAddMisc.Click

        Dim strNumInput As String = String.Empty

        Using objFormQty As New frmQty
            objFormQty.Display("Enter amount for misc drink", "0.00")
            strNumInput = objFormQty.ReturnValue
        End Using

        If strNumInput <> "x" Then
            Try
                Dim decDrinkAmt As Decimal = strNumInput
                If (decDrinkAmt > 0 And decDrinkAmt < 1000) Then
                    Dim myRow As UltraDataRow = udsDrinks.Rows.Add()
                    myRow.Item("DkQty") = "1"
                    myRow.Item("DkName") = "Misc Drink"
                    myRow.Item("DkPrice") = decDrinkAmt
                    myRow.Item("DkTotal") = fixCur(decDrinkAmt)

                    ugdDrinksGrid.SuspendLayout()
                    ugdDrinksGrid.DataSource = udsDrinks
                    If ugdDrinksGrid.Rows.Count > 0 Then
                        ugdDrinksGrid.ActiveRow = ugdDrinksGrid.Rows(0)
                    Else
                        ugdDrinksGrid.ActiveRow = Nothing
                    End If
                    ugdDrinksGrid.ResumeLayout()
                    ugdDrinksGrid.Refresh()

                    lblDrinksTotal.Text = fixCur(CalcDrinksTotal)
                    blnDrinksDirty = True
                Else
                    strMsgBox = "Number must between 1 and 1000"
                    Alert(strMsgBox)
                End If

            Catch ex As Exception
                DisplayError(ex)
            End Try

        End If

    End Sub

    Public Sub MiniHilit(MTButton As UltraButton)

        Try
            ResetMiniTableBackground()
            With lblMiniHilit
                .Size = New Size(MTButton.Width + 8, MTButton.Height + 8)
                .Location = New Point(MTButton.Left - 4, MTButton.Top - 4)
                '.BorderStyleOuter = Infragistics.Win.UIElementBorderStyle.Rounded4Thick
                .Visible = True
                .SendToBack()
            End With

            MTButton.Appearance.BackColor = Color.FromArgb(196, 27, 27)

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Public Sub ClearDrinksGrid()

        udsDrinks.Rows.Clear()
        ugdDrinksGrid.DataSource = udsDrinks
        ugdDrinksGrid.Refresh()
        lblDrinksTotal.Text = fixCur(CalcDrinksTotal)
        blnDrinksDirty = True

    End Sub

    Private Sub ShowAnySetItems(sngTUIdSAM As Short, strDNameSAM As String, intDQty As Short)

        Dim strMods As String = objDB.GetSetItemsFromDB(sngTUIdSAM, strDNameSAM)
        If strMods <> String.Empty Then
            Dim arrMods = strMods.Split("^^")
            For aCnt = arrMods.GetLowerBound(0) To arrMods.GetUpperBound(0)
                If arrMods(aCnt) <> String.Empty Then
                    Dim arrModDetails = arrMods(aCnt).Split("#")
                    Dim udrModRow As UltraDataRow = udsTableGrid.Rows.Add
                    udrModRow.Item("Qty") = ""
                    udrModRow.Item("Dish") = "- " & arrModDetails(1)
                    udrModRow.Item("Price") = arrModDetails(2)
                    udrModRow.Item("Total") = fixCur(intDQty * arrModDetails(2))
                    udrModRow.Item("Mods") = strIsModRow
                End If
            Next
        End If

    End Sub

    Public Sub UpdateUsedButtons()

        For iddd As Integer = 1 To 10
            Application.DoEvents()
            ShowTablesInUse()
            Sleep(100)
        Next

    End Sub

    Private Sub cmdPrintDrinks_Click(sender As Object, e As EventArgs) Handles cmdDkPrint.Click

        If ugdDrinksGrid.Rows.Count > 0 Then
            If TableInfo(CurTable).Id = 0 Then AssignUniqueID(CurTable)
            InsertDrinksToDB()
            PrintDrinks(TableInfo(CurTable).Id)

        Else
            strMsgBox = "There are no drinks in the list"
            Alert(strMsgBox)

        End If

    End Sub

    Private Sub cmdLightsStatus_Click(sender As Object, e As EventArgs) Handles cmdLightsStatus.Click

        Dim LightsCustomList As New List(Of String) From {GetAppSettingCS("TablesExtLine1", "Starters served"),
                                                          GetAppSettingCS("TablesExtLine2", "Mains served"),
                                                          GetAppSettingCS("TablesExtLine3", "Bill paid"),
                                                          "Reset"}

        Dim strResponse As String = CustomList.Show(LightsCustomList, False)
        If strResponse <> strCustomListBoxCancelString Then
            For Each myObj As Control In tlpTables.Controls
                If (TypeOf myObj Is EZTableButton) Then
                    Dim myObjx As EZTableButton = DirectCast(myObj, EZTableButton)
                    If myObjx.TableNumber = CurTable Then
                        If strResponse = GetAppSettingCS("TablesExtLine1", "Starters served") Then myObjx.LightsOn(1) : tValue = 1
                        If strResponse = GetAppSettingCS("TablesExtLine2", "Mains served") Then myObjx.LightsOn(2) : tValue = 2
                        If strResponse = GetAppSettingCS("TablesExtLine3", "Bill paid") Then myObjx.LightsOn(3) : tValue = 3
                        If strResponse = "Reset" Then myObjx.LightsAllOff() : tValue = 0
                        Application.DoEvents()
                        SQLQuery = "UPDATE Table_Bill SET Lights = " & tValue & " WHERE TabUniqueID = " & TableInfo(CurTable).Id
                        objDB.ExeNonQuery(SQLQuery)
                    End If
                End If
            Next
        End If

    End Sub

    Public Sub SetTableColour(intBtnNum As Short, blnColorIsOn As Boolean, Optional intNumCust As Short = -1,
                              Optional strEntryTime As String = Nothing, Optional intLights As Short = -1)

        Dim btnButton As New EZTableButton
        Dim btnMiniButton As New UltraButton
        Dim intTag As Short

        Dim appnMiniTableOn As New Infragistics.Win.Appearance
        Dim appnMiniTableOff As New Infragistics.Win.Appearance

        Dim clrMyColor As Color = Color.FromArgb(66, 134, 165)
        Dim clrMyColor2 As Color = clrMyColor
        Dim clrMyBorderColor As Color = Color.FromArgb(66, 138, 181)
        Dim bgsBackGradStyle As Infragistics.Win.GradientStyle = Infragistics.Win.GradientStyle.GlassTop50

        With appnMiniTableOff
            .BorderColor = Color.Transparent
            .ForeColor = Color.White
            .ImageBackground = My.Resources.ezresource.minitable
        End With

        With appnMiniTableOn
            .BorderColor = Color.Transparent
            .ForeColor = Color.Yellow
            .ImageBackground = My.Resources.ezresource.minitable_green
        End With

        'get the button with the correct CurTable
        Dim ctlBut = tlpTables.Controls.Find("Table" & intBtnNum.ToString, False)

        If ctlBut.Length = 0 Then Exit Sub

        btnButton = ctlBut(0)

        'colour mini table as well
        ctlBut = upnlMiniTables.ClientArea.Controls.Find("MiniTable" & intBtnNum.ToString, False)
        btnMiniButton = ctlBut(0)

        If GetAppSettingCS("TablesExtMode", True) = True Then

            If blnColorIsOn = True Then
                intTag = 1
                btnButton.NewEntry()
                If strEntryTime <> Nothing Then btnButton.EntryTime = strEntryTime.ToString
                If intNumCust <> -1 Then btnButton.Covers = intNumCust

                If intLights <> -1 Then
                    If intLights = 0 Then
                        btnButton.LightsAllOff()
                    Else
                        btnButton.LightsOn(intLights)
                    End If
                End If

            Else
                intTag = 0
                btnButton.ClearTable()
            End If

            If GetAppSettingCS("TablesExtLights", True) = False Then
                btnButton.HideBar()
            End If

        Else
            If blnColorIsOn = True Then
                btnButton.NewEntrySimple()
                intTag = 1
            Else
                btnButton.ClearTable()
                intTag = 0
            End If

        End If

        If blnColorIsOn = True Then
            btnMiniButton.Appearance = appnMiniTableOn
        Else
            btnMiniButton.Appearance = appnMiniTableOff
        End If

        btnButton.Refresh()
        btnMiniButton.Refresh()

        btnButton.Tag = intTag
        btnMiniButton.Tag = intTag

        MiniHilit(btnMiniButton)

    End Sub

    Private Sub UpdateTableHeader()
        lblBillHeader.Text = $"Table: {CurTable}    Covers: {CurCusts}"
    End Sub

End Class