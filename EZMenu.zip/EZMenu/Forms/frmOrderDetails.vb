﻿Public Class frmOrderItems

    Private _orderID As Object

    Public Sub New(orderID As Object)

        InitializeComponent()

        _orderID = orderID

        CenterToScreen()
        SetupButtons()

        Try

            Dim SQLQuery As String = $" SELECT		Code, Qty, Dish, UnitPrice AS [Unit Price], Qty * UnitPrice AS Total 
                                        FROM        OrderItems
                                        WHERE       OrderID = {_orderID}
                                        UNION
                                        SELECT		9999 AS Code, 1 AS Qty, 'Drinks' AS Dish, DrinksTotal AS [Unit Price], DrinksTotal AS Total
                                        FROM        Orders
                                        WHERE       (OrderID = {_orderID}) AND (DrinksTotal IS NOT NULL) AND (DrinksTotal > 0)
                                        ORDER BY	Code"

            Dim dtOrderItems As DataTable = objDB.GetDataTable(SQLQuery)
            ugdOrderItems.DataSource = dtOrderItems
            ugdOrderItems.DisplayLayout.PerformAutoResizeColumns(True, Infragistics.Win.UltraWinGrid.PerformAutoSizeType.VisibleRows)
            ugdOrderItems.DisplayLayout.Bands(0).Columns(0).Hidden = True
            ugdOrderItems.DisplayLayout.Bands(0).Columns(1).CellAppearance.TextHAlign = Infragistics.Win.HAlign.Center
            ugdOrderItems.DisplayLayout.Bands(0).Columns(3).CellAppearance.TextHAlign = Infragistics.Win.HAlign.Right
            ugdOrderItems.DisplayLayout.Bands(0).Columns(4).CellAppearance.TextHAlign = Infragistics.Win.HAlign.Right
            ugdOrderItems.Refresh()

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub SetupButtons()

        cmdClose.Tag = cmdClose.Text
        cmdClose.Text = String.Empty
        AddHandler cmdClose.MouseEnter, AddressOf ButtonMouseEnter
        AddHandler cmdClose.MouseLeave, AddressOf ButtonMouseLeave

    End Sub

    Private Sub ButtonMouseEnter(sender As Object, e As EventArgs)
        sender.text = sender.tag
    End Sub

    Private Sub ButtonMouseLeave(sender As Object, e As EventArgs)
        sender.Text = String.Empty
    End Sub

    Private Sub cmdClose_Click(sender As Object, e As EventArgs) Handles cmdClose.Click
        Close()
    End Sub

    Private Sub ugdOrderItems_AfterRowActivate(sender As Object, e As EventArgs) Handles ugdOrderItems.AfterRowActivate
        ugdOrderItems.ActiveRow = Nothing
    End Sub

    Private Sub cmdCardDetails_Click(sender As Object, e As EventArgs) Handles cmdCardDetails.Click

        Try
            SQLQuery = "SELECT CardNumber, CardExpiry, CardIssueNum, CardValid, CardSecurity FROM Orders " &
                        "WHERE OrderID = " & CShort(objOrders.ugdOrderGrid.ActiveRow.Cells("OrderID").Value)

            drDataRow = objDB.GetSingleRow(SQLQuery)
            If drDataRow IsNot Nothing AndAlso drDataRow!CardNumber.ToString <> String.Empty Then
                strMsgBox = "Card number: " & drDataRow!CardNumber & vbCrLf &
                            "Expiry: " & drDataRow!CardExpiry & "   Valid: " & drDataRow!CardValid & vbCrLf &
                            "Issue: " & drDataRow!CardIssueNum & "   CVC: " & drDataRow!CardSecurity
                Alert(strMsgBox)
            Else
                strMsgBox = "Cannot retrieve any card details"
                Alert(strMsgBox, MessageBoxIcon.Error)
            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    'Declare the variables
    Dim drag As Boolean
    Dim mousex As Integer
    Dim mousey As Integer


    Private Sub Form1_MouseDown(sender As Object, e As MouseEventArgs) Handles Me.MouseDown
        drag = True 'Sets the variable drag to true.
        mousex = Cursor.Position.X - Left 'Sets variable mousex
        mousey = Cursor.Position.Y - Top 'Sets variable mousey
    End Sub

    Private Sub Form1_MouseMove(sender As Object, e As MouseEventArgs) Handles Me.MouseMove
        'If drag is set to true then move the form accordingly.
        If drag Then
            Top = Cursor.Position.Y - mousey
            Left = Cursor.Position.X - mousex
        End If
    End Sub

    Private Sub Form1_MouseUp(sender As Object, e As MouseEventArgs) Handles Me.MouseUp
        drag = False 'Sets drag to false, so the form does not move according to the code in MouseMove
    End Sub

End Class