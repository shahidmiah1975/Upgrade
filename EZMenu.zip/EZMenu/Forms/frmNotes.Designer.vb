﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmNotes
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim Appearance1 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance2 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmNotes))
        Dim Appearance3 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance4 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance5 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance6 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance7 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance8 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance9 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance10 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Me.ezkbdKeyboard = New EZControls.EZKeyboard()
        Me.txtNote = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.cmdBack = New Infragistics.Win.Misc.UltraButton()
        Me.cmdOK = New Infragistics.Win.Misc.UltraButton()
        Me.cmdClear = New Infragistics.Win.Misc.UltraButton()
        CType(Me.txtNote, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ezkbdKeyboard
        '
        Me.ezkbdKeyboard.BackColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        Me.ezkbdKeyboard.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ezkbdKeyboard.EZKBBackColor = System.Drawing.Color.Empty
        Me.ezkbdKeyboard.EZKBBorderColor = System.Drawing.Color.Gainsboro
        Me.ezkbdKeyboard.EZKBForeColor = System.Drawing.Color.DimGray
        Me.ezkbdKeyboard.ForeColor = System.Drawing.Color.Black
        Me.ezkbdKeyboard.Location = New System.Drawing.Point(15, 175)
        Me.ezkbdKeyboard.Name = "ezkbdKeyboard"
        Me.ezkbdKeyboard.Size = New System.Drawing.Size(802, 285)
        Me.ezkbdKeyboard.TabIndex = 502
        '
        'txtNote
        '
        Me.txtNote.AlwaysInEditMode = True
        Appearance1.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance1.BorderColor = System.Drawing.Color.Silver
        Appearance1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Appearance1.TextVAlignAsString = "Top"
        Me.txtNote.Appearance = Appearance1
        Me.txtNote.AutoSize = False
        Me.txtNote.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtNote.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtNote.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNote.Location = New System.Drawing.Point(54, 15)
        Me.txtNote.MaxLength = 255
        Me.txtNote.Multiline = True
        Me.txtNote.Name = "txtNote"
        Me.txtNote.Size = New System.Drawing.Size(668, 132)
        Me.txtNote.StyleSetName = "TextEntry"
        Me.txtNote.TabIndex = 520
        Me.txtNote.UseAppStyling = False
        Me.txtNote.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtNote.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdBack
        '
        Me.cmdBack.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Appearance2.BackColor = System.Drawing.Color.Transparent
        Appearance2.BackColor2 = System.Drawing.Color.Transparent
        Appearance2.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance2.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance2.BorderColor = System.Drawing.Color.Transparent
        Appearance2.BorderColor2 = System.Drawing.Color.Maroon
        Appearance2.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance2.ForeColor = System.Drawing.Color.White
        Appearance2.Image = CType(resources.GetObject("Appearance2.Image"), Object)
        Appearance2.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance2.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance2.TextVAlignAsString = "Bottom"
        Me.cmdBack.Appearance = Appearance2
        Me.cmdBack.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdBack.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance3.BackColor = System.Drawing.Color.DarkOrange
        Appearance3.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance3.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance3.BorderColor = System.Drawing.Color.Transparent
        Appearance3.ForeColor = System.Drawing.Color.Black
        Me.cmdBack.HotTrackAppearance = Appearance3
        Me.cmdBack.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdBack.Location = New System.Drawing.Point(733, 107)
        Me.cmdBack.Name = "cmdBack"
        Me.cmdBack.Padding = New System.Drawing.Size(15, 0)
        Appearance4.BackColor = System.Drawing.Color.OrangeRed
        Appearance4.BackColor2 = System.Drawing.Color.Tomato
        Appearance4.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance4.BorderColor = System.Drawing.Color.Transparent
        Me.cmdBack.PressedAppearance = Appearance4
        Me.cmdBack.ShowFocusRect = False
        Me.cmdBack.ShowOutline = False
        Me.cmdBack.Size = New System.Drawing.Size(50, 40)
        Me.cmdBack.StyleSetName = "StatusBar"
        Me.cmdBack.TabIndex = 559
        Me.cmdBack.Tag = "Return"
        Me.cmdBack.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdBack.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdBack.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdOK
        '
        Me.cmdOK.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Appearance5.BackColor = System.Drawing.Color.Transparent
        Appearance5.BackColor2 = System.Drawing.Color.Transparent
        Appearance5.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance5.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance5.BorderColor = System.Drawing.Color.Transparent
        Appearance5.BorderColor2 = System.Drawing.Color.Maroon
        Appearance5.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance5.ForeColor = System.Drawing.Color.White
        Appearance5.Image = CType(resources.GetObject("Appearance5.Image"), Object)
        Appearance5.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance5.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance5.TextVAlignAsString = "Bottom"
        Me.cmdOK.Appearance = Appearance5
        Me.cmdOK.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdOK.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance6.BackColor = System.Drawing.Color.DarkOrange
        Appearance6.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance6.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance6.BorderColor = System.Drawing.Color.Transparent
        Appearance6.ForeColor = System.Drawing.Color.Black
        Me.cmdOK.HotTrackAppearance = Appearance6
        Me.cmdOK.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdOK.Location = New System.Drawing.Point(733, 15)
        Me.cmdOK.Name = "cmdOK"
        Me.cmdOK.Padding = New System.Drawing.Size(15, 0)
        Appearance7.BackColor = System.Drawing.Color.OrangeRed
        Appearance7.BackColor2 = System.Drawing.Color.Tomato
        Appearance7.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance7.BorderColor = System.Drawing.Color.Transparent
        Me.cmdOK.PressedAppearance = Appearance7
        Me.cmdOK.ShowFocusRect = False
        Me.cmdOK.ShowOutline = False
        Me.cmdOK.Size = New System.Drawing.Size(50, 40)
        Me.cmdOK.StyleSetName = "StatusBar"
        Me.cmdOK.TabIndex = 600
        Me.cmdOK.Tag = "Return"
        Me.cmdOK.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOK.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOK.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdClear
        '
        Me.cmdClear.Anchor = System.Windows.Forms.AnchorStyles.Right
        Appearance8.BackColor = System.Drawing.Color.Transparent
        Appearance8.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance8.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance8.BorderColor = System.Drawing.Color.Transparent
        Appearance8.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance8.ForeColor = System.Drawing.Color.Black
        Appearance8.Image = CType(resources.GetObject("Appearance8.Image"), Object)
        Appearance8.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance8.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance8.TextVAlignAsString = "Bottom"
        Me.cmdClear.Appearance = Appearance8
        Me.cmdClear.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance9.BackColor = System.Drawing.Color.DarkOrange
        Appearance9.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance9.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance9.ForeColor = System.Drawing.Color.Black
        Me.cmdClear.HotTrackAppearance = Appearance9
        Me.cmdClear.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdClear.Location = New System.Drawing.Point(733, 61)
        Me.cmdClear.Name = "cmdClear"
        Appearance10.BackColor = System.Drawing.Color.OrangeRed
        Appearance10.BackColor2 = System.Drawing.Color.Tomato
        Appearance10.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdClear.PressedAppearance = Appearance10
        Me.cmdClear.ShowFocusRect = False
        Me.cmdClear.ShowOutline = False
        Me.cmdClear.Size = New System.Drawing.Size(50, 40)
        Me.cmdClear.StyleSetName = "StatusBar"
        Me.cmdClear.TabIndex = 601
        Me.cmdClear.Tag = "Clear"
        Me.cmdClear.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdClear.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdClear.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'frmNotes
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(832, 474)
        Me.ControlBox = False
        Me.Controls.Add(Me.cmdClear)
        Me.Controls.Add(Me.cmdOK)
        Me.Controls.Add(Me.cmdBack)
        Me.Controls.Add(Me.txtNote)
        Me.Controls.Add(Me.ezkbdKeyboard)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximumSize = New System.Drawing.Size(838, 480)
        Me.Name = "frmNotes"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        CType(Me.txtNote, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents ezkbdKeyboard As EZControls.EZKeyboard
    Friend WithEvents txtNote As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents cmdBack As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdOK As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdClear As Infragistics.Win.Misc.UltraButton
End Class
