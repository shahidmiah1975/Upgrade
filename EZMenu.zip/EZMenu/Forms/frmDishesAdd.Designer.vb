﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDishesAdd
    Inherits EZMenu.frmBaseForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim Appearance1 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmDishesAdd))
        Dim Appearance2 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance3 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance4 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance5 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance6 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance7 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance8 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance9 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance10 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance11 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance12 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance13 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance14 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance15 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance16 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance17 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance18 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance19 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance20 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance21 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance22 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance23 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance24 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance25 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance26 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance27 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance28 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance29 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Me.cmdDishAdd = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDishNew = New Infragistics.Win.Misc.UltraButton()
        Me.cmdLoadFromFile = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDishClose = New Infragistics.Win.Misc.UltraButton()
        Me.ezkbdAddDish = New EZControls.EZKeyboard()
        Me.cmbGroup = New Infragistics.Win.UltraWinEditors.UltraComboEditor()
        Me.chkSameOutPrice = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.UltraLabel2 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel3 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel4 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel5 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel6 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel7 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel8 = New Infragistics.Win.Misc.UltraLabel()
        Me.lblDishAdded = New Infragistics.Win.Misc.UltraLabel()
        Me.lblItemsAdded = New Infragistics.Win.Misc.UltraLabel()
        Me.txtDishName = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtCode = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtShortName = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtShortcode = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtPriceIn = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtPriceOut = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.uplBasePanel.SuspendLayout()
        CType(Me.cmbGroup, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkSameOutPrice, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtDishName, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtCode, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtShortName, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtShortcode, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtPriceIn, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtPriceOut, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'uplBasePanel
        '
        Me.uplBasePanel.Location = New System.Drawing.Point(0, 661)
        Me.uplBasePanel.Size = New System.Drawing.Size(1017, 50)
        '
        'cmdDishAdd
        '
        Appearance1.BackColor = System.Drawing.Color.Transparent
        Appearance1.BackColor2 = System.Drawing.Color.Transparent
        Appearance1.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance1.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance1.BorderColor = System.Drawing.Color.Transparent
        Appearance1.BorderColor2 = System.Drawing.Color.Maroon
        Appearance1.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance1.ForeColor = System.Drawing.Color.White
        Appearance1.Image = CType(resources.GetObject("Appearance1.Image"), Object)
        Appearance1.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance1.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance1.TextVAlignAsString = "Bottom"
        Me.cmdDishAdd.Appearance = Appearance1
        Me.cmdDishAdd.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance2.BackColor = System.Drawing.Color.DarkOrange
        Appearance2.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance2.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance2.BorderColor = System.Drawing.Color.Transparent
        Appearance2.ForeColor = System.Drawing.Color.Black
        Me.cmdDishAdd.HotTrackAppearance = Appearance2
        Me.cmdDishAdd.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdDishAdd.Location = New System.Drawing.Point(808, 183)
        Me.cmdDishAdd.Name = "cmdDishAdd"
        Appearance3.BackColor = System.Drawing.Color.OrangeRed
        Appearance3.BackColor2 = System.Drawing.Color.Tomato
        Appearance3.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance3.BorderColor = System.Drawing.Color.Transparent
        Me.cmdDishAdd.PressedAppearance = Appearance3
        Me.cmdDishAdd.ShowFocusRect = False
        Me.cmdDishAdd.ShowOutline = False
        Me.cmdDishAdd.Size = New System.Drawing.Size(70, 40)
        Me.cmdDishAdd.StyleSetName = "StatusBar"
        Me.cmdDishAdd.TabIndex = 10
        Me.cmdDishAdd.Tag = "Return"
        Me.cmdDishAdd.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDishAdd.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDishAdd.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDishNew
        '
        Appearance4.BackColor = System.Drawing.Color.Transparent
        Appearance4.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance4.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance4.Image = CType(resources.GetObject("Appearance4.Image"), Object)
        Appearance4.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance4.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance4.TextVAlignAsString = "Bottom"
        Me.cmdDishNew.Appearance = Appearance4
        Me.cmdDishNew.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdDishNew.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance5.BackColor = System.Drawing.Color.DarkOrange
        Appearance5.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance5.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance5.BorderColor = System.Drawing.Color.Transparent
        Appearance5.ForeColor = System.Drawing.Color.Black
        Me.cmdDishNew.HotTrackAppearance = Appearance5
        Me.cmdDishNew.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdDishNew.Location = New System.Drawing.Point(808, 91)
        Me.cmdDishNew.Name = "cmdDishNew"
        Appearance6.BackColor = System.Drawing.Color.OrangeRed
        Appearance6.BackColor2 = System.Drawing.Color.Tomato
        Appearance6.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance6.BorderColor = System.Drawing.Color.Transparent
        Me.cmdDishNew.PressedAppearance = Appearance6
        Me.cmdDishNew.ShowFocusRect = False
        Me.cmdDishNew.ShowOutline = False
        Me.cmdDishNew.Size = New System.Drawing.Size(70, 40)
        Me.cmdDishNew.StyleSetName = "StatusBar"
        Me.cmdDishNew.TabIndex = 8
        Me.cmdDishNew.Tag = "Back"
        Me.cmdDishNew.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDishNew.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDishNew.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdLoadFromFile
        '
        Appearance7.BackColor = System.Drawing.Color.Transparent
        Appearance7.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance7.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance7.Image = CType(resources.GetObject("Appearance7.Image"), Object)
        Appearance7.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance7.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance7.TextVAlignAsString = "Bottom"
        Me.cmdLoadFromFile.Appearance = Appearance7
        Me.cmdLoadFromFile.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdLoadFromFile.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance8.BackColor = System.Drawing.Color.DarkOrange
        Appearance8.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance8.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance8.BorderColor = System.Drawing.Color.Transparent
        Appearance8.ForeColor = System.Drawing.Color.Black
        Me.cmdLoadFromFile.HotTrackAppearance = Appearance8
        Me.cmdLoadFromFile.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdLoadFromFile.Location = New System.Drawing.Point(808, 137)
        Me.cmdLoadFromFile.Name = "cmdLoadFromFile"
        Appearance9.BackColor = System.Drawing.Color.OrangeRed
        Appearance9.BackColor2 = System.Drawing.Color.Tomato
        Appearance9.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance9.BorderColor = System.Drawing.Color.Transparent
        Me.cmdLoadFromFile.PressedAppearance = Appearance9
        Me.cmdLoadFromFile.ShowFocusRect = False
        Me.cmdLoadFromFile.ShowOutline = False
        Me.cmdLoadFromFile.Size = New System.Drawing.Size(70, 40)
        Me.cmdLoadFromFile.StyleSetName = "StatusBar"
        Me.cmdLoadFromFile.TabIndex = 9
        Me.cmdLoadFromFile.Tag = "OK"
        Me.cmdLoadFromFile.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdLoadFromFile.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdLoadFromFile.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDishClose
        '
        Me.cmdDishClose.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Appearance10.BackColor = System.Drawing.Color.Transparent
        Appearance10.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance10.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance10.Image = CType(resources.GetObject("Appearance10.Image"), Object)
        Appearance10.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance10.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance10.TextVAlignAsString = "Bottom"
        Me.cmdDishClose.Appearance = Appearance10
        Me.cmdDishClose.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdDishClose.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance11.BackColor = System.Drawing.Color.DarkOrange
        Appearance11.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance11.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance11.BorderColor = System.Drawing.Color.Transparent
        Appearance11.ForeColor = System.Drawing.Color.Black
        Me.cmdDishClose.HotTrackAppearance = Appearance11
        Me.cmdDishClose.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdDishClose.Location = New System.Drawing.Point(473, 663)
        Me.cmdDishClose.Name = "cmdDishClose"
        Appearance12.BackColor = System.Drawing.Color.OrangeRed
        Appearance12.BackColor2 = System.Drawing.Color.Tomato
        Appearance12.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance12.BorderColor = System.Drawing.Color.Transparent
        Me.cmdDishClose.PressedAppearance = Appearance12
        Me.cmdDishClose.ShowFocusRect = False
        Me.cmdDishClose.ShowOutline = False
        Me.cmdDishClose.Size = New System.Drawing.Size(70, 40)
        Me.cmdDishClose.StyleSetName = "StatusBar"
        Me.cmdDishClose.TabIndex = 561
        Me.cmdDishClose.Tag = "Clear"
        Me.cmdDishClose.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDishClose.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDishClose.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ezkbdAddDish
        '
        Me.ezkbdAddDish.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.ezkbdAddDish.BackColor = System.Drawing.Color.Transparent
        Me.ezkbdAddDish.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ezkbdAddDish.EZKBBackColor = System.Drawing.Color.Empty
        Me.ezkbdAddDish.EZKBBorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Me.ezkbdAddDish.EZKBForeColor = System.Drawing.Color.SteelBlue
        Me.ezkbdAddDish.Font = New System.Drawing.Font("Arial", 7.5!)
        Me.ezkbdAddDish.ForeColor = System.Drawing.Color.Black
        Me.ezkbdAddDish.Location = New System.Drawing.Point(107, 361)
        Me.ezkbdAddDish.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.ezkbdAddDish.Name = "ezkbdAddDish"
        Me.ezkbdAddDish.Size = New System.Drawing.Size(802, 285)
        Me.ezkbdAddDish.TabIndex = 559
        '
        'cmbGroup
        '
        Appearance13.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance13.BorderColor = System.Drawing.Color.LightGray
        Appearance13.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Me.cmbGroup.Appearance = Appearance13
        Me.cmbGroup.BackColor = System.Drawing.Color.WhiteSmoke
        Me.cmbGroup.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.cmbGroup.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList
        Me.cmbGroup.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbGroup.Location = New System.Drawing.Point(390, 201)
        Me.cmbGroup.Name = "cmbGroup"
        Me.cmbGroup.Size = New System.Drawing.Size(273, 27)
        Me.cmbGroup.StyleSetName = "TextEntry"
        Me.cmbGroup.TabIndex = 5
        Me.cmbGroup.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmbGroup.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'chkSameOutPrice
        '
        Appearance14.FontData.Name = "Segoe UI"
        Appearance14.FontData.SizeInPoints = 9.75!
        Appearance14.ForeColor = System.Drawing.Color.SlateGray
        Me.chkSameOutPrice.Appearance = Appearance14
        Me.chkSameOutPrice.Location = New System.Drawing.Point(473, 274)
        Me.chkSameOutPrice.Name = "chkSameOutPrice"
        Me.chkSameOutPrice.Size = New System.Drawing.Size(120, 20)
        Me.chkSameOutPrice.TabIndex = 8
        Me.chkSameOutPrice.Text = "Same as price in"
        Me.chkSameOutPrice.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.chkSameOutPrice.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraLabel2
        '
        Appearance15.ForeColor = System.Drawing.Color.SlateGray
        Me.UltraLabel2.Appearance = Appearance15
        Me.UltraLabel2.AutoSize = True
        Me.UltraLabel2.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UltraLabel2.Location = New System.Drawing.Point(292, 71)
        Me.UltraLabel2.Name = "UltraLabel2"
        Me.UltraLabel2.Size = New System.Drawing.Size(39, 19)
        Me.UltraLabel2.StyleSetName = "TextEntryLabel"
        Me.UltraLabel2.TabIndex = 680
        Me.UltraLabel2.Text = "Code:"
        Me.UltraLabel2.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraLabel2.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraLabel3
        '
        Appearance16.ForeColor = System.Drawing.Color.SlateGray
        Me.UltraLabel3.Appearance = Appearance16
        Me.UltraLabel3.AutoSize = True
        Me.UltraLabel3.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UltraLabel3.Location = New System.Drawing.Point(292, 105)
        Me.UltraLabel3.Name = "UltraLabel3"
        Me.UltraLabel3.Size = New System.Drawing.Size(70, 19)
        Me.UltraLabel3.StyleSetName = "TextEntryLabel"
        Me.UltraLabel3.TabIndex = 681
        Me.UltraLabel3.Text = "Dish name:"
        Me.UltraLabel3.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraLabel3.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraLabel4
        '
        Appearance17.ForeColor = System.Drawing.Color.SlateGray
        Me.UltraLabel4.Appearance = Appearance17
        Me.UltraLabel4.AutoSize = True
        Me.UltraLabel4.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UltraLabel4.Location = New System.Drawing.Point(292, 139)
        Me.UltraLabel4.Name = "UltraLabel4"
        Me.UltraLabel4.Size = New System.Drawing.Size(76, 19)
        Me.UltraLabel4.StyleSetName = "TextEntryLabel"
        Me.UltraLabel4.TabIndex = 682
        Me.UltraLabel4.Text = "Short name:"
        Me.UltraLabel4.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraLabel4.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraLabel5
        '
        Appearance18.ForeColor = System.Drawing.Color.SlateGray
        Me.UltraLabel5.Appearance = Appearance18
        Me.UltraLabel5.AutoSize = True
        Me.UltraLabel5.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UltraLabel5.Location = New System.Drawing.Point(292, 173)
        Me.UltraLabel5.Name = "UltraLabel5"
        Me.UltraLabel5.Size = New System.Drawing.Size(72, 19)
        Me.UltraLabel5.StyleSetName = "TextEntryLabel"
        Me.UltraLabel5.TabIndex = 683
        Me.UltraLabel5.Text = "Short code:"
        Me.UltraLabel5.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraLabel5.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraLabel6
        '
        Appearance19.ForeColor = System.Drawing.Color.SlateGray
        Me.UltraLabel6.Appearance = Appearance19
        Me.UltraLabel6.AutoSize = True
        Me.UltraLabel6.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UltraLabel6.Location = New System.Drawing.Point(292, 206)
        Me.UltraLabel6.Name = "UltraLabel6"
        Me.UltraLabel6.Size = New System.Drawing.Size(45, 19)
        Me.UltraLabel6.StyleSetName = "TextEntryLabel"
        Me.UltraLabel6.TabIndex = 684
        Me.UltraLabel6.Text = "Group:"
        Me.UltraLabel6.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraLabel6.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraLabel7
        '
        Appearance20.ForeColor = System.Drawing.Color.SlateGray
        Me.UltraLabel7.Appearance = Appearance20
        Me.UltraLabel7.AutoSize = True
        Me.UltraLabel7.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UltraLabel7.Location = New System.Drawing.Point(292, 240)
        Me.UltraLabel7.Name = "UltraLabel7"
        Me.UltraLabel7.Size = New System.Drawing.Size(51, 19)
        Me.UltraLabel7.StyleSetName = "TextEntryLabel"
        Me.UltraLabel7.TabIndex = 685
        Me.UltraLabel7.Text = "Price in:"
        Me.UltraLabel7.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraLabel7.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraLabel8
        '
        Appearance21.ForeColor = System.Drawing.Color.SlateGray
        Me.UltraLabel8.Appearance = Appearance21
        Me.UltraLabel8.AutoSize = True
        Me.UltraLabel8.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UltraLabel8.Location = New System.Drawing.Point(292, 274)
        Me.UltraLabel8.Name = "UltraLabel8"
        Me.UltraLabel8.Size = New System.Drawing.Size(60, 19)
        Me.UltraLabel8.StyleSetName = "TextEntryLabel"
        Me.UltraLabel8.TabIndex = 686
        Me.UltraLabel8.Text = "Price out:"
        Me.UltraLabel8.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraLabel8.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblDishAdded
        '
        Appearance22.ForeColor = System.Drawing.Color.SlateGray
        Appearance22.TextHAlignAsString = "Center"
        Me.lblDishAdded.Appearance = Appearance22
        Me.lblDishAdded.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDishAdded.Location = New System.Drawing.Point(308, 315)
        Me.lblDishAdded.Name = "lblDishAdded"
        Me.lblDishAdded.Size = New System.Drawing.Size(355, 19)
        Me.lblDishAdded.StyleSetName = "TextEntryLabel"
        Me.lblDishAdded.TabIndex = 687
        Me.lblDishAdded.Text = "<lblDishAdded>"
        Me.lblDishAdded.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.lblDishAdded.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblItemsAdded
        '
        Appearance23.ForeColor = System.Drawing.Color.SlateGray
        Appearance23.TextHAlignAsString = "Center"
        Me.lblItemsAdded.Appearance = Appearance23
        Me.lblItemsAdded.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblItemsAdded.Location = New System.Drawing.Point(750, 270)
        Me.lblItemsAdded.Name = "lblItemsAdded"
        Me.lblItemsAdded.Size = New System.Drawing.Size(176, 19)
        Me.lblItemsAdded.StyleSetName = "TextEntryLabel"
        Me.lblItemsAdded.TabIndex = 688
        Me.lblItemsAdded.Text = "lblItemsAdded"
        Me.lblItemsAdded.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.lblItemsAdded.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        Me.lblItemsAdded.Visible = False
        '
        'txtDishName
        '
        Appearance24.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance24.BorderColor = System.Drawing.Color.LightGray
        Appearance24.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Me.txtDishName.Appearance = Appearance24
        Me.txtDishName.AutoSize = False
        Me.txtDishName.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtDishName.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtDishName.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDishName.Location = New System.Drawing.Point(390, 99)
        Me.txtDishName.MaxLength = 50
        Me.txtDishName.Name = "txtDishName"
        Me.txtDishName.Size = New System.Drawing.Size(273, 28)
        Me.txtDishName.StyleSetName = "TextEntry"
        Me.txtDishName.TabIndex = 2
        Me.txtDishName.UseAppStyling = False
        Me.txtDishName.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtDishName.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtCode
        '
        Appearance25.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance25.BorderColor = System.Drawing.Color.LightGray
        Appearance25.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Me.txtCode.Appearance = Appearance25
        Me.txtCode.AutoSize = False
        Me.txtCode.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtCode.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtCode.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCode.Location = New System.Drawing.Point(390, 65)
        Me.txtCode.MaxLength = 5
        Me.txtCode.Name = "txtCode"
        Me.txtCode.Size = New System.Drawing.Size(101, 28)
        Me.txtCode.StyleSetName = "TextEntry"
        Me.txtCode.TabIndex = 1
        Me.txtCode.UseAppStyling = False
        Me.txtCode.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtCode.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtShortName
        '
        Appearance26.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance26.BorderColor = System.Drawing.Color.LightGray
        Appearance26.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Me.txtShortName.Appearance = Appearance26
        Me.txtShortName.AutoSize = False
        Me.txtShortName.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtShortName.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtShortName.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtShortName.Location = New System.Drawing.Point(390, 133)
        Me.txtShortName.MaxLength = 50
        Me.txtShortName.Name = "txtShortName"
        Me.txtShortName.Size = New System.Drawing.Size(273, 28)
        Me.txtShortName.StyleSetName = "TextEntry"
        Me.txtShortName.TabIndex = 3
        Me.txtShortName.UseAppStyling = False
        Me.txtShortName.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtShortName.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtShortcode
        '
        Appearance27.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance27.BorderColor = System.Drawing.Color.LightGray
        Appearance27.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Me.txtShortcode.Appearance = Appearance27
        Me.txtShortcode.AutoSize = False
        Me.txtShortcode.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtShortcode.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtShortcode.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtShortcode.Location = New System.Drawing.Point(390, 167)
        Me.txtShortcode.MaxLength = 50
        Me.txtShortcode.Name = "txtShortcode"
        Me.txtShortcode.Size = New System.Drawing.Size(101, 28)
        Me.txtShortcode.StyleSetName = "TextEntry"
        Me.txtShortcode.TabIndex = 4
        Me.txtShortcode.UseAppStyling = False
        Me.txtShortcode.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtShortcode.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtPriceIn
        '
        Appearance28.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance28.BorderColor = System.Drawing.Color.LightGray
        Appearance28.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Me.txtPriceIn.Appearance = Appearance28
        Me.txtPriceIn.AutoSize = False
        Me.txtPriceIn.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtPriceIn.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtPriceIn.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPriceIn.Location = New System.Drawing.Point(390, 234)
        Me.txtPriceIn.MaxLength = 8
        Me.txtPriceIn.Name = "txtPriceIn"
        Me.txtPriceIn.Size = New System.Drawing.Size(72, 28)
        Me.txtPriceIn.StyleSetName = "TextEntry"
        Me.txtPriceIn.TabIndex = 6
        Me.txtPriceIn.UseAppStyling = False
        Me.txtPriceIn.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtPriceIn.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtPriceOut
        '
        Appearance29.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance29.BorderColor = System.Drawing.Color.LightGray
        Appearance29.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Me.txtPriceOut.Appearance = Appearance29
        Me.txtPriceOut.AutoSize = False
        Me.txtPriceOut.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtPriceOut.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtPriceOut.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPriceOut.Location = New System.Drawing.Point(390, 268)
        Me.txtPriceOut.MaxLength = 8
        Me.txtPriceOut.Name = "txtPriceOut"
        Me.txtPriceOut.Size = New System.Drawing.Size(72, 28)
        Me.txtPriceOut.StyleSetName = "TextEntry"
        Me.txtPriceOut.TabIndex = 7
        Me.txtPriceOut.UseAppStyling = False
        Me.txtPriceOut.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtPriceOut.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'frmDishesAdd
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1017, 711)
        Me.Controls.Add(Me.txtPriceOut)
        Me.Controls.Add(Me.txtPriceIn)
        Me.Controls.Add(Me.txtShortcode)
        Me.Controls.Add(Me.txtShortName)
        Me.Controls.Add(Me.txtCode)
        Me.Controls.Add(Me.txtDishName)
        Me.Controls.Add(Me.lblItemsAdded)
        Me.Controls.Add(Me.lblDishAdded)
        Me.Controls.Add(Me.UltraLabel8)
        Me.Controls.Add(Me.UltraLabel7)
        Me.Controls.Add(Me.UltraLabel6)
        Me.Controls.Add(Me.UltraLabel5)
        Me.Controls.Add(Me.UltraLabel4)
        Me.Controls.Add(Me.UltraLabel3)
        Me.Controls.Add(Me.UltraLabel2)
        Me.Controls.Add(Me.chkSameOutPrice)
        Me.Controls.Add(Me.cmbGroup)
        Me.Controls.Add(Me.cmdDishAdd)
        Me.Controls.Add(Me.cmdDishNew)
        Me.Controls.Add(Me.cmdLoadFromFile)
        Me.Controls.Add(Me.cmdDishClose)
        Me.Controls.Add(Me.ezkbdAddDish)
        Me.Name = "frmDishesAdd"
        Me.ShowInTaskbar = False
        Me.Controls.SetChildIndex(Me.uplBasePanel, 0)
        Me.Controls.SetChildIndex(Me.ezkbdAddDish, 0)
        Me.Controls.SetChildIndex(Me.cmdDishClose, 0)
        Me.Controls.SetChildIndex(Me.cmdLoadFromFile, 0)
        Me.Controls.SetChildIndex(Me.cmdDishNew, 0)
        Me.Controls.SetChildIndex(Me.cmdDishAdd, 0)
        Me.Controls.SetChildIndex(Me.cmbGroup, 0)
        Me.Controls.SetChildIndex(Me.chkSameOutPrice, 0)
        Me.Controls.SetChildIndex(Me.UltraLabel2, 0)
        Me.Controls.SetChildIndex(Me.UltraLabel3, 0)
        Me.Controls.SetChildIndex(Me.UltraLabel4, 0)
        Me.Controls.SetChildIndex(Me.UltraLabel5, 0)
        Me.Controls.SetChildIndex(Me.UltraLabel6, 0)
        Me.Controls.SetChildIndex(Me.UltraLabel7, 0)
        Me.Controls.SetChildIndex(Me.UltraLabel8, 0)
        Me.Controls.SetChildIndex(Me.lblDishAdded, 0)
        Me.Controls.SetChildIndex(Me.lblItemsAdded, 0)
        Me.Controls.SetChildIndex(Me.txtDishName, 0)
        Me.Controls.SetChildIndex(Me.txtCode, 0)
        Me.Controls.SetChildIndex(Me.txtShortName, 0)
        Me.Controls.SetChildIndex(Me.txtShortcode, 0)
        Me.Controls.SetChildIndex(Me.txtPriceIn, 0)
        Me.Controls.SetChildIndex(Me.txtPriceOut, 0)
        Me.uplBasePanel.ResumeLayout(False)
        CType(Me.cmbGroup, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkSameOutPrice, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtDishName, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtCode, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtShortName, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtShortcode, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtPriceIn, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtPriceOut, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents cmdDishAdd As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDishNew As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdLoadFromFile As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDishClose As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ezkbdAddDish As EZControls.EZKeyboard
    Friend WithEvents cmbGroup As Infragistics.Win.UltraWinEditors.UltraComboEditor
    Friend WithEvents chkSameOutPrice As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents UltraLabel2 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel3 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel4 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel5 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel6 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel7 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel8 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblDishAdded As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblItemsAdded As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents txtDishName As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtCode As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtShortName As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtShortcode As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtPriceIn As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtPriceOut As Infragistics.Win.UltraWinEditors.UltraTextEditor
End Class
