﻿Imports System.Configuration
Imports EZMenu.Core
Imports Infragistics.Win

Public Class frmDishes2

    Dim blnColumnResized As Boolean
    Dim CellText, UniqueID As String

    Public Sub UpdateGrid()

        'Me.TableAdapterManager.DishTableAdapter.Fill(Me.EZMenuDataSet.Dish)
        TableAdapterManager.DishTableAdapter.FillByCuisine(EzMenuDataSet.Dish, cmbCuisine.Text)
        ugdDishes.DataSource = EzMenuDataSet.Dish
        ugdDishes.ActiveRow = ugdDishes.GetRow(UltraWinGrid.ChildRow.Last)
        lblNumDishes.Text = "Number of items: " & DishBindingSource.Count

    End Sub

    Private Sub frmDishes_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Try
            'SetScreenTitle(Me, "Dish Management Screen")
            Size = Owner.Size
            Location = Owner.Location

            FillCuisineDropDown(cmbCuisine)
            lblCuisine.Visible = GetAppSettingCS("MultiCuisines", True)
            cmbCuisine.Visible = lblCuisine.Visible
            cmbCuisine.SelectedIndex = 0

            If cmbCuisine.Visible = False Then
                ugbOptions.Top = 90
            End If

            LoadDishesGrid()

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub ButtonMouseEnter(sender As Object, e As EventArgs)
        sender.text = sender.tag
    End Sub

    Private Sub ButtonMouseLeave(sender As Object, e As EventArgs)
        sender.Text = String.Empty
    End Sub

    Private Sub cmdClose_Click(sender As Object, e As EventArgs) Handles cmdBack.Click

        DishTableAdapter.Update(EzMenuDataSet.Dish)

        If blnColumnResized = True Then
            For i = 1 To 6
                SaveAppSetting($"DishColWidth{i}", ugdDishes.DisplayLayout.Bands(0).Columns(i).Width)
            Next
        End If

        Close()

    End Sub

    Private Sub cmdShortcodeDelete_Click(sender As Object, e As EventArgs) Handles cmdShortcodeDelete.Click

        If lstShortcode.SelectedItems.Count > 0 Then
            clsDish.DeleteShortcode(cmbCuisine.Text, lstShortcode.SelectedItems(0).Key)
            lstShortcode.Items.Remove(lstShortcode.SelectedItems(0))
        End If

    End Sub

    Private Sub cmdDeleteDish_Click(sender As Object, e As EventArgs) Handles cmdDeleteDish.Click

        If ugdDishes.Selected.Rows.Count = 0 AndAlso ugdDishes.ActiveRow IsNot Nothing Then
            ugdDishes.Rows(ugdDishes.ActiveRow.Index).Selected = True
        End If

        If ugdDishes.Selected.Rows.Count > 0 Then

            Try
                Dim uniqVal As Short = ugdDishes.ActiveRow.Cells("UniqueID").Value

                'delete any existing short name
                SQLQuery = $"DELETE FROM DishShortName WHERE UniqueID = {uniqVal}"
                objDB.ExeNonQuery(SQLQuery)
                'delete any existing codes
                SQLQuery = $"DELETE FROM Codes WHERE UniqueID = {uniqVal}"
                objDB.ExeNonQuery(SQLQuery)
                ugdDishes.DeleteSelectedRows(False)
                TableAdapterManager.DishTableAdapter.Update(EzMenuDataSet.Dish)
                lblNumDishes.Text = "Number of items: " & DishBindingSource.Count

            Catch exc As Exception
                MessageBox.Show("Error occured during deleting the row.\n" & exc.Message,
                  "Error deleting row", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try

        Else
            MessageBox.Show("There are no rows selected. Select rows first.")

        End If

    End Sub

    Private Sub cmdShortcodeAdd_Click(sender As Object, e As EventArgs) Handles cmdShortcodeAdd.Click
        'add new shortcode to the DB

        Dim strCodeToAdd As String = txtShortcode.Text.Trim.ToUpper

        'if code is blank or DB is empty then exit the sub
        If (String.IsNullOrEmpty(strCodeToAdd) Or (DishBindingSource.Count = 0)) Then
            txtShortcode.Text = String.Empty
            Exit Sub
        End If

        'check if this is already in the listbox
        If lstShortcode.Items.Count > 0 Then
            For iCnt = 0 To (lstShortcode.Items.Count - 1)
                If strCodeToAdd = lstShortcode.Items(iCnt).Value Then
                    strMsgBox = "That is already selected"
                    Alert(strMsgBox, MessageBoxIcon.None)
                    Exit Sub
                End If
            Next
        End If

        'check shortcode does not contain any digits
        If StringContainsNumber(strCodeToAdd) Then
            strMsgBox = "Your input must be only alphabetical characters"
            Alert(strMsgBox, MessageBoxIcon.Asterisk)
            Exit Sub
        End If

        'check that this code is not already in use
        If clsDish.CodeInUse(cmbCuisine.Text, strCodeToAdd) = False Then
            'not in use, so add it to the listbox and DB
            lstShortcode.Items.Add(strCodeToAdd, strCodeToAdd)
            clsDish.CodeInsert(ugdDishes.ActiveRow.Cells("UniqueID").Text, strCodeToAdd)
        Else
            'this code is in use
            strMsgBox = "That code is used by " & drDataRow("DishName") &
                vbCrLf & "Change that code first and retry"
            Alert(strMsgBox, MessageBoxIcon.Error)
            SelectText(txtShortcode)

        End If

        txtShortcode.Clear()

    End Sub

    Private Sub ugdDishes_AfterColPosChanged(sender As Object, e As UltraWinGrid.AfterColPosChangedEventArgs) Handles ugdDishes.AfterColPosChanged
        blnColumnResized = True
    End Sub

    Private Sub ugdDishes_AfterRowActivate(sender As Object, e As EventArgs) Handles ugdDishes.AfterRowActivate

        txtShortName.Clear()
        lstShortcode.Items.Clear()
        txtPriceLarge.Clear()
        txtPriceSmall.Clear()

        lblShortName.Text = "Alternative names for" & vbCrLf & ugdDishes.ActiveRow.Cells("Dishname").Text
        SQLQuery = "SELECT ShortName FROM DishShortName WHERE UniqueID = " & ugdDishes.ActiveRow.Cells("UniqueID").Value
        drDataRow = objDB.GetSingleRow(SQLQuery)
        If drDataRow IsNot Nothing Then
            txtShortName.Text = drDataRow.Item("ShortName").ToString
        End If

        lblShortCode.Text = "Shortcodes for" & vbCrLf & ugdDishes.ActiveRow.Cells("Dishname").Text
        SQLQuery = "SELECT ShortCode FROM Codes WHERE UniqueID = " & ugdDishes.ActiveRow.Cells("UniqueID").Value
        drcDatarowCollection = objDB.GetDataRows(SQLQuery)
        If drcDatarowCollection IsNot Nothing Then
            For Each myRow As DataRow In drcDatarowCollection
                lstShortcode.Items.Add(myRow.Item("ShortCode").ToString, myRow.Item("ShortCode").ToString)
            Next
        End If

        SQLQuery = "SELECT Small, Large FROM DishSmallLarge WHERE UniqueID = " & ugdDishes.ActiveRow.Cells("UniqueID").Value
        drDataRow = objDB.GetSingleRow(SQLQuery)
        If drDataRow IsNot Nothing Then
            If Not IsDBNull(drDataRow.Item("Small")) Then txtPriceSmall.Text = fixCur(drDataRow.Item("Small").ToString)
            If Not IsDBNull(drDataRow.Item("Large")) Then txtPriceLarge.Text = fixCur(drDataRow.Item("Large").ToString)
        End If

    End Sub

    Private Sub ugdDishes_BeforeExitEditMode(sender As Object, e As UltraWinGrid.BeforeExitEditModeEventArgs) Handles ugdDishes.BeforeExitEditMode

        Dim myCell As UltraWinGrid.UltraGridCell = ugdDishes.ActiveCell

        Select Case myCell.Column.Key
            Case "Code"
                If (Not IsANumber(myCell.Text) Or myCell.Text.Trim = String.Empty) Then
                    strMsgBox = "This field must be a number"
                    Alert(strMsgBox, MessageBoxIcon.Asterisk)
                    e.Cancel = True
                End If

            Case "DishName"
                If myCell.Text.Trim = String.Empty Then
                    strMsgBox = "You must specify a dish name"
                    Alert(strMsgBox, MessageBoxIcon.Asterisk)
                    e.Cancel = True
                Else
                    myCell.Value = myCell.Text.Trim
                End If

            Case "PriceIn", "PriceOut"
                If Not IsANumber(myCell.Text) Then
                    strMsgBox = "You must specify a valid price"
                    Alert(strMsgBox, MessageBoxIcon.Asterisk)
                    e.Cancel = True
                End If
            Case Else
        End Select

    End Sub

    Private Sub ugdDishes_ClickCellButton(sender As Object, e As UltraWinGrid.CellEventArgs) Handles ugdDishes.ClickCellButton

        CellText = ugdDishes.ActiveCell.Text.ToString
        lblShortCode.Text = "Shortcodes for" & vbCrLf & ugdDishes.ActiveRow.Cells("Dishname").Text
        lblShortName.Text = "Alternative names for" & vbCrLf & ugdDishes.ActiveRow.Cells("Dishname").Text

        txtShortcode.Clear()
        lstShortcode.Items.Clear()
        txtShortName.Clear()

        UniqueID = ugdDishes.ActiveRow.Cells("UniqueID").Text

        If UniqueID <> "" Then

            'get shortcodes
            SQLQuery = "SELECT * FROM Codes WHERE UniqueID=" & UniqueID
            drcDatarowCollection = objDB.GetDataRows(SQLQuery)
            If drcDatarowCollection IsNot Nothing Then
                For Each myRow As DataRow In drcDatarowCollection
                    lstShortcode.Items.Add(myRow.Item("ShortCode").ToString)
                Next
            End If

            'get printed names
            SQLQuery = "SELECT * FROM DishShortName WHERE UniqueID=" & UniqueID
            drDataRow = objDB.GetSingleRow(SQLQuery)
            If drDataRow IsNot Nothing Then
                txtShortName.Text = drDataRow.Item("ShortName").ToString
            End If
        End If

    End Sub

    Private Sub cmdSaveShortName_Click(sender As Object, e As EventArgs) Handles cmdSaveShortName.Click

        Try
            txtShortName.Text = txtShortName.Text.Trim
            If txtShortName.Text <> "" Then
                If ugdDishes.ActiveRow.Cells("DishName").Text.ToUpper <> txtShortName.Text.ToUpper Then

                    Dim uniqVal As Short = ugdDishes.ActiveRow.Cells("UniqueID").Value

                    'delete any existing short name
                    SQLQuery = $"DELETE FROM DishShortName WHERE UniqueID = { uniqVal }"
                    objDB.ExeNonQuery(SQLQuery)

                    SQLQuery = $"INSERT INTO DishShortName (UniqueID, ShortName) VALUES ({ uniqVal }, '{ txtShortName.Text }')"
                    objDB.ExeNonQuery(SQLQuery)

                Else
                    strMsgBox = "This is same as the item name"
                    Alert(strMsgBox, MessageBoxIcon.Asterisk)
                End If
            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub cmdAddDish_Click(sender As Object, e As EventArgs) Handles cmdAddDish.Click

        DishTableAdapter.Update(EzMenuDataSet.Dish)

        Using objDishesAdd As New frmDishesAdd(Me, cmbCuisine.Text, cmbCuisine.SelectedIndex)
            'objDishesAdd.Show()
        End Using

    End Sub

    Public Sub UpdateMyGrid()

        'Me.TableAdapterManager.DishTableAdapter.Fill(Me.EZMenuDataSet.Dish)
        TableAdapterManager.DishTableAdapter.FillByCuisine(EzMenuDataSet.Dish, cmbCuisine.Text)
        ugdDishes.DataSource = EzMenuDataSet.Dish
        ugdDishes.ActiveRow = ugdDishes.GetRow(UltraWinGrid.ChildRow.Last)
        lblNumDishes.Text = "Number of items: " & DishBindingSource.Count

    End Sub

    Private Sub cmdShowSubgroup_Click(sender As Object, e As EventArgs) Handles cmdShowSubgroup.Click

        If ugdDishes.ActiveRow IsNot Nothing Then
            If ugdDishes.Selected.Rows.Count = 0 Then ugdDishes.Rows(ugdDishes.ActiveRow.Index).Selected = True

            Using objDishesSubgroup As New frmDishesSubgroup(ugdDishes, "Subgroups")
                objDishesSubgroup.ShowDialog()
            End Using

        Else
            Alert("Select a dish from the grid first", MessageBoxIcon.Information)
        End If

    End Sub

    Private Sub cmdDishesHistory_Click(sender As Object, e As EventArgs) Handles cmdDishesHistory.Click

        Using objDishesHistory As New frmDishesHistory
            objDishesHistory.ShowDialog()
        End Using

    End Sub

    Private Sub txtShortcode_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtShortcode.KeyPress

        Select Case UCase(e.KeyChar)
            Case ChrW(Keys.Enter)
                e.Handled = False
                If txtShortcode.Text <> String.Empty Then cmdShortcodeAdd_Click(sender, e)
            Case ChrW(Keys.A) To ChrW(Keys.Z), ChrW(Keys.Back)
                e.Handled = False
            Case Else
                e.Handled = True
        End Select

    End Sub

    Private Sub txtShortName_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtShortName.KeyPress

        Select Case UCase(e.KeyChar)
            Case ChrW(Keys.Enter)
                e.Handled = False
                If txtShortName.Text <> String.Empty Then cmdSaveShortName_Click(sender, e)
            Case ChrW(Keys.A) To ChrW(Keys.Z), ChrW(Keys.Back), ChrW(Keys.Space), "(", ")"
                e.Handled = False
            Case ChrW(22)   'Ctrl + V
                e.Handled = False
            Case Else
                e.Handled = True
        End Select

    End Sub

    Private Sub cmdLabels_Click(sender As Object, e As EventArgs) Handles cmdLabels.Click

        Try
            If ugdDishes.ActiveRow Is Nothing Then Exit Sub

            Using objLabelsForm As New frmDishesSubgroup(ugdDishes, "Labels")
                objLabelsForm.ShowDialog()
            End Using

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Public Sub LoadDishesGrid()

        Dim myList As New ValueList()

        Try
            txtShortcode.Text = ""
            txtShortName.Text = ""
            lstShortcode.Items.Clear()
            lblShortCode.Text = ""
            lblShortName.Text = ""

            EzMenuDataSet.EnforceConstraints = False
            DishTableAdapter.Connection.ConnectionString = ConfigurationManager.ConnectionStrings(EZConstants.EZDatabaseConnectionString).ConnectionString
            TableAdapterManager.DishTableAdapter.FillByCuisine(EzMenuDataSet.Dish, cmbCuisine.Text)

            'retrieve the column widths
            With ugdDishes
                .DisplayLayout.Override.SelectTypeRow = UltraWinGrid.SelectType.ExtendedAutoDrag
                With .DisplayLayout.Bands(0)
                    .Columns(0).Width = 0  'invisible
                    .Columns(1).Width = GetAppSettingCS("DishColWidth1", 60)
                    .Columns(2).Width = GetAppSettingCS("DishColWidth2", 180)
                    .Columns(3).Width = GetAppSettingCS("DishColWidth3", 75)
                    .Columns(4).Width = GetAppSettingCS("DishColWidth4", 75)
                    .Columns(5).Width = GetAppSettingCS("DishColWidth5", 75)
                    .Columns(6).Width = GetAppSettingCS("DishColWidth6", 75)
                    .Columns(0).Hidden = True 'hide the uniqueID column
                End With
            End With

            'fill in the group combo box
            SQLQuery = "SELECT * FROM Groups WHERE CuisineName = '" & cmbCuisine.Text & "'"
            drcDatarowCollection = objDB.GetDataRows(SQLQuery)

            For Each myRow As DataRow In drcDatarowCollection
                myList.ValueListItems.Add(myRow.Item("GroupName").ToString)
            Next

            ugdDishes.DisplayLayout.Bands(0).Columns("GroupName").ValueList = myList

            lblNumDishes.Text = "Number of items: " & DishBindingSource.Count

            cmdAddDish.Enabled = True
            cmdDeleteDish.Enabled = True

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub cmdDishCascade_Click(sender As Object, e As EventArgs) Handles cmdDishCascade.Click

        If ugdDishes.ActiveRow IsNot Nothing Then
            Using objDishCascade As New frmDishCascade(ugdDishes.ActiveRow)
                objDishCascade.ShowDialog()
            End Using
        Else
            strMsgBox = "Select a dish from the grid first"
            Alert(strMsgBox)
        End If

    End Sub

    Private Sub cmdConcise_Click(sender As Object, e As EventArgs) Handles cmdConcise.Click

        If ugdDishes.ActiveRow IsNot Nothing Then
            If ugdDishes.Selected.Rows.Count = 0 Then ugdDishes.Rows(ugdDishes.ActiveRow.Index).Selected = True
            Using objForm As New frmDishMerge(ugdDishes)
                objForm.ShowDialog(Me)
            End Using

        Else
            strMsgBox = "Select one or more dish from the grid first"
            Alert(strMsgBox)
        End If

    End Sub

    Private Sub cmdDeleteShortName_Click(sender As Object, e As EventArgs) Handles cmdDeleteShortName.Click

        Try
            'delete any existing short name
            If txtShortName.Text.Trim <> String.Empty Then
                clsDish.DeleteShortname(ugdDishes.ActiveRow.Cells("UniqueID").Value)
                txtShortName.Clear()
            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub cmdPriceSave_Click(sender As Object, e As EventArgs) Handles cmdPriceSave.Click

        Try
            Dim strSmall As String = ""
            Dim strLarge As String = ""

            'delete any existing prices
            clsDish.DSLDelete(ugdDishes.ActiveRow.Cells("UniqueID").Value)

            If txtPriceLarge.Text = String.Empty Then
                strLarge = "NULL"
            ElseIf IsANumber(txtPriceLarge.Text) Then
                strLarge = txtPriceLarge.Text
            End If

            If txtPriceSmall.Text = String.Empty Then
                strSmall = "NULL"
            ElseIf IsANumber(txtPriceSmall.Text) Then
                strSmall = txtPriceSmall.Text
            End If

            clsDish.DSLInsert(ugdDishes.ActiveRow.Cells("UniqueID").Value, strSmall, strLarge)

            If txtPriceSmall.Text <> String.Empty Then txtPriceSmall.Text = fixCur(txtPriceSmall.Text)
            If txtPriceLarge.Text <> String.Empty Then txtPriceLarge.Text = fixCur(txtPriceLarge.Text)

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub cmdPriceDelete_Click(sender As Object, e As EventArgs) Handles cmdPriceDelete.Click

        Try

            'delete existing prices
            clsDish.DSLDelete(ugdDishes.ActiveRow.Cells("UniqueID").Value)

            txtPriceLarge.Clear()
            txtPriceSmall.Clear()

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub cmdSearch_Click(sender As Object, e As EventArgs) Handles cmdSearch.Click

        Try
            If cmdSearch.Text = "Search" Then
                If txtSearchString.Text <> String.Empty Then
                    DishBindingSource.Filter = "DishName Like '%" & txtSearchString.Text.Trim & "%'"
                    ugdDishes.DataSource = DishBindingSource
                    lblNumDishes.Text = "Number of items: " & DishBindingSource.Count
                    cmdSearch.Text = "Reset"
                Else
                    Alert("Enter search term.")
                End If
            Else
                DishBindingSource.RemoveFilter()
                ugdDishes.DataSource = DishBindingSource
                lblNumDishes.Text = "Number of items: " & DishBindingSource.Count
                cmdSearch.Text = "Search"
                txtSearchString.Text = ""
                txtSearchString.Focus()
            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub cmbCuisine_ValueChanged(sender As Object, e As EventArgs) Handles cmbCuisine.ValueChanged
        LoadDishesGrid()
    End Sub

    Private Sub txtSearchString_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtSearchString.KeyPress

        If e.KeyChar = ChrW(Keys.Enter) Then cmdSearch_Click(Nothing, Nothing)
        e.Handled = False

    End Sub


    'Declare the variables
    Dim drag As Boolean
    Dim mousex As Integer
    Dim mousey As Integer

    Private Sub Form1_MouseDown(sender As Object, e As MouseEventArgs) Handles lblHeader.MouseDown
        drag = True 'Sets the variable drag to true.
        mousex = Cursor.Position.X - Left 'Sets variable mousex
        mousey = Cursor.Position.Y - Top 'Sets variable mousey
    End Sub

    Private Sub Form1_MouseMove(sender As Object, e As MouseEventArgs) Handles lblHeader.MouseMove
        'If drag is set to true then move the form accordingly.
        If drag Then
            Top = Cursor.Position.Y - mousey
            Left = Cursor.Position.X - mousex
        End If
    End Sub

    Private Sub Form1_MouseUp(sender As Object, e As MouseEventArgs) Handles lblHeader.MouseUp
        drag = False 'Sets drag to false, so the form does not move according to the code in MouseMove
    End Sub

End Class