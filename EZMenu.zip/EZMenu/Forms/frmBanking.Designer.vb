﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBanking
    Inherits EZMenu.frmBaseForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim Appearance10 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance11 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance12 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance13 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraGridBand1 As Infragistics.Win.UltraWinGrid.UltraGridBand = New Infragistics.Win.UltraWinGrid.UltraGridBand("Banking", -1)
        Dim UltraGridColumn1 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Date", -1, Nothing, 0, Infragistics.Win.UltraWinGrid.SortIndicator.Descending, False)
        Dim Appearance14 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraGridColumn2 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Tips")
        Dim Appearance15 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraGridColumn3 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Cash")
        Dim Appearance16 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraGridColumn4 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Card")
        Dim Appearance17 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraGridColumn5 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Other")
        Dim Appearance18 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraGridColumn6 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Total")
        Dim Appearance19 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance20 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance21 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance22 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance23 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance24 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance25 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance26 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance27 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance28 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance29 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance30 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance31 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance32 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance33 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance34 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance35 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance7 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance8 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance9 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance4 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance5 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance6 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance36 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance37 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance38 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance39 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance40 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance41 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance42 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance43 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance44 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance45 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance46 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance47 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance48 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance49 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance50 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance51 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance52 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance53 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance54 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance55 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance56 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance57 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance58 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance59 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance60 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance61 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance62 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance63 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance64 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance65 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance66 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance67 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance68 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance69 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance70 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance71 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance72 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance73 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance74 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance75 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance76 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance77 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance78 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance79 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance80 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance81 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance1 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmBanking))
        Dim Appearance2 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance3 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance82 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance83 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance84 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance85 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance86 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance87 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance88 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance89 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance90 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Me.cmdClose = New Infragistics.Win.Misc.UltraButton()
        Me.ugdBanking = New Infragistics.Win.UltraWinGrid.UltraGrid()
        Me.BankingBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.EZMenuDataSet = New EZMenu.EZMenuDataSet()
        Me.UltraCalendarLook1 = New Infragistics.Win.UltraWinSchedule.UltraCalendarLook(Me.components)
        Me.txtTotal = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.cmdKBTotal = New Infragistics.Win.Misc.UltraButton()
        Me.cmdGridDown = New Infragistics.Win.Misc.UltraButton()
        Me.cmdGridUp = New Infragistics.Win.Misc.UltraButton()
        Me.cmdOK = New Infragistics.Win.Misc.UltraButton()
        Me.cmdClear = New Infragistics.Win.Misc.UltraButton()
        Me.cmdKBTips = New Infragistics.Win.Misc.UltraButton()
        Me.txtTips = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.cmdKBPrintEnd = New Infragistics.Win.Misc.UltraButton()
        Me.txtPrintEnd = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.cmdKBPrintStart = New Infragistics.Win.Misc.UltraButton()
        Me.txtPrintStart = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.cmdPrintReport = New Infragistics.Win.Misc.UltraButton()
        Me.cmdKBDate = New Infragistics.Win.Misc.UltraButton()
        Me.txtDate = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.cmdKBCash = New Infragistics.Win.Misc.UltraButton()
        Me.txtCash = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.cmdKBCard = New Infragistics.Win.Misc.UltraButton()
        Me.txtCard = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.cmdKBOther = New Infragistics.Win.Misc.UltraButton()
        Me.txtOther = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.cmdPrintToday = New Infragistics.Win.Misc.UltraButton()
        Me.BankingTableAdapter = New EZMenu.EZMenuDataSetTableAdapters.BankingTableAdapter()
        Me.cmdAdd = New Infragistics.Win.Misc.UltraButton()
        Me.cmdPrintShowAll = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDeleteRow = New Infragistics.Win.Misc.UltraButton()
        Me.lblPostcodeLbl = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel2 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel3 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel4 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel5 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel6 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel10 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel11 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel12 = New Infragistics.Win.Misc.UltraLabel()
        Me.uplBasePanel.ClientArea.SuspendLayout()
        Me.uplBasePanel.SuspendLayout()
        CType(Me.ugdBanking, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BankingBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EZMenuDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTotal, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTips, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtPrintEnd, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtPrintStart, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtDate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtCash, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtCard, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtOther, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'UltraPanel1
        '
        '
        'UltraPanel1.ClientArea
        '
        Me.uplBasePanel.ClientArea.Controls.Add(Me.cmdDeleteRow)
        Me.uplBasePanel.ClientArea.Controls.Add(Me.cmdGridUp)
        Me.uplBasePanel.ClientArea.Controls.Add(Me.cmdGridDown)
        Me.uplBasePanel.ClientArea.Controls.Add(Me.cmdClose)
        '
        'cmdClose
        '
        Me.cmdClose.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance10.ForeColor = System.Drawing.Color.Black
        Appearance10.Image = CType(resources.GetObject("Appearance10.Image"), Object)
        Appearance10.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance10.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance10.TextVAlignAsString = "Bottom"
        Me.cmdClose.Appearance = Appearance10
        Me.cmdClose.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdClose.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance11.BackColor = System.Drawing.Color.DarkOrange
        Appearance11.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance11.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance11.ForeColor = System.Drawing.Color.Black
        Me.cmdClose.HotTrackAppearance = Appearance11
        Me.cmdClose.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdClose.Location = New System.Drawing.Point(908, 3)
        Me.cmdClose.Name = "cmdClose"
        Appearance12.BackColor = System.Drawing.Color.OrangeRed
        Appearance12.BackColor2 = System.Drawing.Color.Tomato
        Appearance12.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdClose.PressedAppearance = Appearance12
        Me.cmdClose.ShowFocusRect = False
        Me.cmdClose.ShowOutline = False
        Me.cmdClose.Size = New System.Drawing.Size(64, 44)
        Me.cmdClose.StyleSetName = "StatusBar"
        Me.cmdClose.TabIndex = 496
        Me.cmdClose.Tag = "Return"
        Me.cmdClose.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdClose.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdClose.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ugdBanking
        '
        Me.ugdBanking.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ugdBanking.DataSource = Me.BankingBindingSource
        Appearance13.BackColor = System.Drawing.Color.Transparent
        Appearance13.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Me.ugdBanking.DisplayLayout.Appearance = Appearance13
        Appearance14.TextHAlignAsString = "Center"
        UltraGridColumn1.CellAppearance = Appearance14
        UltraGridColumn1.Header.Editor = Nothing
        UltraGridColumn1.Header.VisiblePosition = 0
        UltraGridColumn1.Width = 100
        Appearance15.TextHAlignAsString = "Right"
        UltraGridColumn2.CellAppearance = Appearance15
        UltraGridColumn2.Header.Editor = Nothing
        UltraGridColumn2.Header.VisiblePosition = 4
        UltraGridColumn2.Width = 80
        Appearance16.TextHAlignAsString = "Right"
        UltraGridColumn3.CellAppearance = Appearance16
        UltraGridColumn3.Header.Editor = Nothing
        UltraGridColumn3.Header.VisiblePosition = 1
        UltraGridColumn3.Width = 80
        Appearance17.TextHAlignAsString = "Right"
        UltraGridColumn4.CellAppearance = Appearance17
        UltraGridColumn4.Header.Editor = Nothing
        UltraGridColumn4.Header.VisiblePosition = 2
        UltraGridColumn4.Width = 80
        Appearance18.TextHAlignAsString = "Right"
        UltraGridColumn5.CellAppearance = Appearance18
        UltraGridColumn5.Header.Editor = Nothing
        UltraGridColumn5.Header.VisiblePosition = 3
        UltraGridColumn5.Width = 80
        Appearance19.TextHAlignAsString = "Right"
        UltraGridColumn6.CellAppearance = Appearance19
        UltraGridColumn6.Header.Editor = Nothing
        UltraGridColumn6.Header.VisiblePosition = 5
        UltraGridColumn6.Width = 80
        UltraGridBand1.Columns.AddRange(New Object() {UltraGridColumn1, UltraGridColumn2, UltraGridColumn3, UltraGridColumn4, UltraGridColumn5, UltraGridColumn6})
        Appearance20.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        UltraGridBand1.Header.Appearance = Appearance20
        UltraGridBand1.Header.Editor = Nothing
        Appearance21.BackColor = System.Drawing.Color.DarkOrange
        Appearance21.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance21.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        UltraGridBand1.Override.ActiveRowAppearance = Appearance21
        UltraGridBand1.Override.AllowAddNew = Infragistics.Win.UltraWinGrid.AllowAddNew.Yes
        Me.ugdBanking.DisplayLayout.BandsSerializer.Add(UltraGridBand1)
        Me.ugdBanking.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Me.ugdBanking.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.[False]
        Appearance22.BackColor = System.Drawing.SystemColors.ActiveBorder
        Appearance22.BackColor2 = System.Drawing.SystemColors.ControlDark
        Appearance22.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance22.BorderColor = System.Drawing.SystemColors.Window
        Me.ugdBanking.DisplayLayout.GroupByBox.Appearance = Appearance22
        Appearance23.ForeColor = System.Drawing.SystemColors.GrayText
        Me.ugdBanking.DisplayLayout.GroupByBox.BandLabelAppearance = Appearance23
        Me.ugdBanking.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Appearance24.BackColor = System.Drawing.SystemColors.ControlLightLight
        Appearance24.BackColor2 = System.Drawing.SystemColors.Control
        Appearance24.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal
        Appearance24.ForeColor = System.Drawing.SystemColors.GrayText
        Me.ugdBanking.DisplayLayout.GroupByBox.PromptAppearance = Appearance24
        Me.ugdBanking.DisplayLayout.MaxColScrollRegions = 1
        Me.ugdBanking.DisplayLayout.MaxRowScrollRegions = 1
        Me.ugdBanking.DisplayLayout.Override.AllowColMoving = Infragistics.Win.UltraWinGrid.AllowColMoving.NotAllowed
        Me.ugdBanking.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted
        Me.ugdBanking.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted
        Appearance25.BackColor = System.Drawing.SystemColors.Window
        Me.ugdBanking.DisplayLayout.Override.CardAreaAppearance = Appearance25
        Appearance26.BorderColor = System.Drawing.Color.Silver
        Appearance26.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter
        Me.ugdBanking.DisplayLayout.Override.CellAppearance = Appearance26
        Me.ugdBanking.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.EditAndSelectText
        Me.ugdBanking.DisplayLayout.Override.CellPadding = 0
        Appearance27.BackColor = System.Drawing.SystemColors.Control
        Appearance27.BackColor2 = System.Drawing.SystemColors.ControlDark
        Appearance27.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element
        Appearance27.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal
        Appearance27.BorderColor = System.Drawing.SystemColors.Window
        Me.ugdBanking.DisplayLayout.Override.GroupByRowAppearance = Appearance27
        Appearance28.BackColor = System.Drawing.Color.FromArgb(CType(CType(162, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance28.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(162, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance28.TextHAlignAsString = "Center"
        Me.ugdBanking.DisplayLayout.Override.HeaderAppearance = Appearance28
        Me.ugdBanking.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti
        Me.ugdBanking.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand
        Appearance29.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.ugdBanking.DisplayLayout.Override.RowAlternateAppearance = Appearance29
        Appearance30.BackColor = System.Drawing.Color.Gainsboro
        Me.ugdBanking.DisplayLayout.Override.RowAppearance = Appearance30
        Me.ugdBanking.DisplayLayout.Override.RowSelectorHeaderStyle = Infragistics.Win.UltraWinGrid.RowSelectorHeaderStyle.None
        Me.ugdBanking.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.[False]
        Me.ugdBanking.DisplayLayout.Override.RowSizing = Infragistics.Win.UltraWinGrid.RowSizing.Sychronized
        Me.ugdBanking.DisplayLayout.Override.RowSizingArea = Infragistics.Win.UltraWinGrid.RowSizingArea.RowBordersOnly
        Me.ugdBanking.DisplayLayout.Override.SelectTypeCol = Infragistics.Win.UltraWinGrid.SelectType.None
        Me.ugdBanking.DisplayLayout.Override.SelectTypeRow = Infragistics.Win.UltraWinGrid.SelectType.[Single]
        Appearance31.BackColor = System.Drawing.SystemColors.ControlLight
        Me.ugdBanking.DisplayLayout.Override.TemplateAddRowAppearance = Appearance31
        Me.ugdBanking.DisplayLayout.Override.WrapHeaderText = Infragistics.Win.DefaultableBoolean.[True]
        Me.ugdBanking.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill
        Me.ugdBanking.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate
        Me.ugdBanking.DisplayLayout.ViewStyle = Infragistics.Win.UltraWinGrid.ViewStyle.SingleBand
        Me.ugdBanking.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ugdBanking.Location = New System.Drawing.Point(12, 55)
        Me.ugdBanking.Name = "ugdBanking"
        Me.ugdBanking.Size = New System.Drawing.Size(508, 541)
        Me.ugdBanking.TabIndex = 497
        '
        'BankingBindingSource
        '
        Me.BankingBindingSource.DataMember = "Banking"
        Me.BankingBindingSource.DataSource = Me.EZMenuDataSet
        '
        'EZMenuDataSet
        '
        Me.EZMenuDataSet.DataSetName = "EZMenuDataSet"
        Me.EZMenuDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'UltraCalendarLook1
        '
        Me.UltraCalendarLook1.ViewStyle = Infragistics.Win.UltraWinSchedule.ViewStyle.Office2003
        '
        'txtTotal
        '
        Me.txtTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance32.BackColor = System.Drawing.Color.FromArgb(CType(CType(227, Byte), Integer), CType(CType(234, Byte), Integer), CType(CType(241, Byte), Integer))
        Appearance32.TextHAlignAsString = "Right"
        Me.txtTotal.Appearance = Appearance32
        Me.txtTotal.BackColor = System.Drawing.Color.FromArgb(CType(CType(227, Byte), Integer), CType(CType(234, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.txtTotal.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotal.Location = New System.Drawing.Point(676, 257)
        Me.txtTotal.Name = "txtTotal"
        Me.txtTotal.Size = New System.Drawing.Size(84, 27)
        Me.txtTotal.TabIndex = 519
        Me.txtTotal.Text = "0.00"
        Me.txtTotal.UseAppStyling = False
        '
        'cmdKBTotal
        '
        Me.cmdKBTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance33.BackColor = System.Drawing.Color.Transparent
        Appearance33.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance33.BackGradientStyle = Infragistics.Win.GradientStyle.None
        Appearance33.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance33.BorderColor = System.Drawing.Color.Transparent
        Appearance33.BorderColor2 = System.Drawing.Color.Transparent
        Appearance33.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance33.ForeColor = System.Drawing.Color.Black
        Appearance33.Image = CType(resources.GetObject("Appearance33.Image"), Object)
        Appearance33.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance33.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance33.TextVAlignAsString = "Bottom"
        Me.cmdKBTotal.Appearance = Appearance33
        Me.cmdKBTotal.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdKBTotal.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance34.BackColor = System.Drawing.Color.DarkOrange
        Appearance34.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance34.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance34.ForeColor = System.Drawing.Color.Black
        Me.cmdKBTotal.HotTrackAppearance = Appearance34
        Me.cmdKBTotal.ImageSize = New System.Drawing.Size(42, 25)
        Me.cmdKBTotal.Location = New System.Drawing.Point(766, 258)
        Me.cmdKBTotal.Name = "cmdKBTotal"
        Appearance35.BackColor = System.Drawing.Color.Transparent
        Appearance35.BackColor2 = System.Drawing.Color.Transparent
        Me.cmdKBTotal.PressedAppearance = Appearance35
        Me.cmdKBTotal.ShowFocusRect = False
        Me.cmdKBTotal.ShowOutline = False
        Me.cmdKBTotal.Size = New System.Drawing.Size(42, 25)
        Me.cmdKBTotal.TabIndex = 520
        Me.cmdKBTotal.Tag = "Keyboard"
        Me.cmdKBTotal.UseAppStyling = False
        Me.cmdKBTotal.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBTotal.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdKBTotal.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdGridDown
        '
        Me.cmdGridDown.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Appearance7.ForeColor = System.Drawing.Color.Black
        Appearance7.Image = CType(resources.GetObject("Appearance7.Image"), Object)
        Appearance7.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance7.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance7.TextVAlignAsString = "Bottom"
        Me.cmdGridDown.Appearance = Appearance7
        Me.cmdGridDown.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdGridDown.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance8.BackColor = System.Drawing.Color.DarkOrange
        Appearance8.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance8.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance8.ForeColor = System.Drawing.Color.Black
        Me.cmdGridDown.HotTrackAppearance = Appearance8
        Me.cmdGridDown.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdGridDown.Location = New System.Drawing.Point(221, 3)
        Me.cmdGridDown.Name = "cmdGridDown"
        Appearance9.BackColor = System.Drawing.Color.OrangeRed
        Appearance9.BackColor2 = System.Drawing.Color.Tomato
        Appearance9.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdGridDown.PressedAppearance = Appearance9
        Me.cmdGridDown.ShowFocusRect = False
        Me.cmdGridDown.ShowOutline = False
        Me.cmdGridDown.Size = New System.Drawing.Size(64, 44)
        Me.cmdGridDown.StyleSetName = "StatusBar"
        Me.cmdGridDown.TabIndex = 522
        Me.cmdGridDown.Tag = "Down"
        Me.cmdGridDown.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdGridDown.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdGridDown.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdGridUp
        '
        Me.cmdGridUp.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Appearance4.ForeColor = System.Drawing.Color.Black
        Appearance4.Image = CType(resources.GetObject("Appearance4.Image"), Object)
        Appearance4.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance4.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance4.TextVAlignAsString = "Bottom"
        Me.cmdGridUp.Appearance = Appearance4
        Me.cmdGridUp.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdGridUp.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance5.BackColor = System.Drawing.Color.DarkOrange
        Appearance5.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance5.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance5.ForeColor = System.Drawing.Color.Black
        Me.cmdGridUp.HotTrackAppearance = Appearance5
        Me.cmdGridUp.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdGridUp.Location = New System.Drawing.Point(151, 3)
        Me.cmdGridUp.Name = "cmdGridUp"
        Appearance6.BackColor = System.Drawing.Color.OrangeRed
        Appearance6.BackColor2 = System.Drawing.Color.Tomato
        Appearance6.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdGridUp.PressedAppearance = Appearance6
        Me.cmdGridUp.ShowFocusRect = False
        Me.cmdGridUp.ShowOutline = False
        Me.cmdGridUp.Size = New System.Drawing.Size(64, 44)
        Me.cmdGridUp.StyleSetName = "StatusBar"
        Me.cmdGridUp.TabIndex = 521
        Me.cmdGridUp.Tag = "Up"
        Me.cmdGridUp.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdGridUp.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdGridUp.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdOK
        '
        Me.cmdOK.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance36.ForeColor = System.Drawing.Color.Black
        Appearance36.Image = CType(resources.GetObject("Appearance36.Image"), Object)
        Appearance36.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance36.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance36.TextVAlignAsString = "Bottom"
        Me.cmdOK.Appearance = Appearance36
        Me.cmdOK.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdOK.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance37.BackColor = System.Drawing.Color.DarkOrange
        Appearance37.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance37.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance37.ForeColor = System.Drawing.Color.Black
        Me.cmdOK.HotTrackAppearance = Appearance37
        Me.cmdOK.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdOK.Location = New System.Drawing.Point(868, 93)
        Me.cmdOK.Name = "cmdOK"
        Appearance38.BackColor = System.Drawing.Color.OrangeRed
        Appearance38.BackColor2 = System.Drawing.Color.Tomato
        Appearance38.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdOK.PressedAppearance = Appearance38
        Me.cmdOK.ShowFocusRect = False
        Me.cmdOK.ShowOutline = False
        Me.cmdOK.Size = New System.Drawing.Size(64, 44)
        Me.cmdOK.StyleSetName = "StatusBar"
        Me.cmdOK.TabIndex = 524
        Me.cmdOK.Tag = "OK"
        Me.cmdOK.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOK.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOK.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdClear
        '
        Me.cmdClear.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance39.ForeColor = System.Drawing.Color.Black
        Appearance39.Image = CType(resources.GetObject("Appearance39.Image"), Object)
        Appearance39.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance39.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance39.TextVAlignAsString = "Bottom"
        Me.cmdClear.Appearance = Appearance39
        Me.cmdClear.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdClear.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance40.BackColor = System.Drawing.Color.DarkOrange
        Appearance40.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance40.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance40.ForeColor = System.Drawing.Color.Black
        Me.cmdClear.HotTrackAppearance = Appearance40
        Me.cmdClear.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdClear.Location = New System.Drawing.Point(868, 193)
        Me.cmdClear.Name = "cmdClear"
        Appearance41.BackColor = System.Drawing.Color.OrangeRed
        Appearance41.BackColor2 = System.Drawing.Color.Tomato
        Appearance41.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdClear.PressedAppearance = Appearance41
        Me.cmdClear.ShowFocusRect = False
        Me.cmdClear.ShowOutline = False
        Me.cmdClear.Size = New System.Drawing.Size(64, 44)
        Me.cmdClear.StyleSetName = "StatusBar"
        Me.cmdClear.TabIndex = 525
        Me.cmdClear.Tag = "x"
        Me.cmdClear.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdClear.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdClear.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdKBTips
        '
        Me.cmdKBTips.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance42.BackColor = System.Drawing.Color.Transparent
        Appearance42.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance42.BackGradientStyle = Infragistics.Win.GradientStyle.None
        Appearance42.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance42.BorderColor = System.Drawing.Color.Transparent
        Appearance42.BorderColor2 = System.Drawing.Color.Transparent
        Appearance42.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance42.ForeColor = System.Drawing.Color.Black
        Appearance42.Image = CType(resources.GetObject("Appearance42.Image"), Object)
        Appearance42.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance42.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance42.TextVAlignAsString = "Bottom"
        Me.cmdKBTips.Appearance = Appearance42
        Me.cmdKBTips.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdKBTips.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance43.BackColor = System.Drawing.Color.DarkOrange
        Appearance43.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance43.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance43.ForeColor = System.Drawing.Color.Black
        Me.cmdKBTips.HotTrackAppearance = Appearance43
        Me.cmdKBTips.ImageSize = New System.Drawing.Size(42, 25)
        Me.cmdKBTips.Location = New System.Drawing.Point(766, 225)
        Me.cmdKBTips.Name = "cmdKBTips"
        Appearance44.BackColor = System.Drawing.Color.Transparent
        Appearance44.BackColor2 = System.Drawing.Color.Transparent
        Me.cmdKBTips.PressedAppearance = Appearance44
        Me.cmdKBTips.ShowFocusRect = False
        Me.cmdKBTips.ShowOutline = False
        Me.cmdKBTips.Size = New System.Drawing.Size(42, 25)
        Me.cmdKBTips.TabIndex = 528
        Me.cmdKBTips.Tag = "Keyboard"
        Me.cmdKBTips.UseAppStyling = False
        Me.cmdKBTips.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBTips.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdKBTips.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtTips
        '
        Me.txtTips.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance45.BackColor = System.Drawing.Color.FromArgb(CType(CType(227, Byte), Integer), CType(CType(234, Byte), Integer), CType(CType(241, Byte), Integer))
        Appearance45.TextHAlignAsString = "Right"
        Me.txtTips.Appearance = Appearance45
        Me.txtTips.BackColor = System.Drawing.Color.FromArgb(CType(CType(227, Byte), Integer), CType(CType(234, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.txtTips.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTips.Location = New System.Drawing.Point(676, 224)
        Me.txtTips.Name = "txtTips"
        Me.txtTips.Size = New System.Drawing.Size(84, 27)
        Me.txtTips.TabIndex = 527
        Me.txtTips.Text = "0.00"
        Me.txtTips.UseAppStyling = False
        '
        'cmdKBPrintEnd
        '
        Me.cmdKBPrintEnd.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance46.BackColor = System.Drawing.Color.Transparent
        Appearance46.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance46.BackGradientStyle = Infragistics.Win.GradientStyle.None
        Appearance46.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance46.BorderColor = System.Drawing.Color.Transparent
        Appearance46.BorderColor2 = System.Drawing.Color.Transparent
        Appearance46.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance46.ForeColor = System.Drawing.Color.Black
        Appearance46.Image = CType(resources.GetObject("Appearance46.Image"), Object)
        Appearance46.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance46.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance46.TextVAlignAsString = "Bottom"
        Me.cmdKBPrintEnd.Appearance = Appearance46
        Me.cmdKBPrintEnd.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdKBPrintEnd.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance47.BackColor = System.Drawing.Color.DarkOrange
        Appearance47.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance47.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance47.ForeColor = System.Drawing.Color.Black
        Me.cmdKBPrintEnd.HotTrackAppearance = Appearance47
        Me.cmdKBPrintEnd.ImageSize = New System.Drawing.Size(42, 25)
        Me.cmdKBPrintEnd.Location = New System.Drawing.Point(766, 426)
        Me.cmdKBPrintEnd.Name = "cmdKBPrintEnd"
        Appearance48.BackColor = System.Drawing.Color.Transparent
        Appearance48.BackColor2 = System.Drawing.Color.Transparent
        Me.cmdKBPrintEnd.PressedAppearance = Appearance48
        Me.cmdKBPrintEnd.ShowFocusRect = False
        Me.cmdKBPrintEnd.ShowOutline = False
        Me.cmdKBPrintEnd.Size = New System.Drawing.Size(42, 25)
        Me.cmdKBPrintEnd.TabIndex = 534
        Me.cmdKBPrintEnd.Tag = "Keyboard"
        Me.cmdKBPrintEnd.UseAppStyling = False
        Me.cmdKBPrintEnd.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBPrintEnd.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdKBPrintEnd.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtPrintEnd
        '
        Me.txtPrintEnd.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance49.BackColor = System.Drawing.Color.FromArgb(CType(CType(227, Byte), Integer), CType(CType(234, Byte), Integer), CType(CType(241, Byte), Integer))
        Appearance49.TextHAlignAsString = "Right"
        Me.txtPrintEnd.Appearance = Appearance49
        Me.txtPrintEnd.BackColor = System.Drawing.Color.FromArgb(CType(CType(227, Byte), Integer), CType(CType(234, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.txtPrintEnd.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPrintEnd.Location = New System.Drawing.Point(676, 425)
        Me.txtPrintEnd.Name = "txtPrintEnd"
        Me.txtPrintEnd.Size = New System.Drawing.Size(84, 27)
        Me.txtPrintEnd.TabIndex = 533
        Me.txtPrintEnd.Text = "01/11/10"
        Me.txtPrintEnd.UseAppStyling = False
        '
        'cmdKBPrintStart
        '
        Me.cmdKBPrintStart.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance50.BackColor = System.Drawing.Color.Transparent
        Appearance50.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance50.BackGradientStyle = Infragistics.Win.GradientStyle.None
        Appearance50.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance50.BorderColor = System.Drawing.Color.Transparent
        Appearance50.BorderColor2 = System.Drawing.Color.Transparent
        Appearance50.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance50.ForeColor = System.Drawing.Color.Black
        Appearance50.Image = CType(resources.GetObject("Appearance50.Image"), Object)
        Appearance50.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance50.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance50.TextVAlignAsString = "Bottom"
        Me.cmdKBPrintStart.Appearance = Appearance50
        Me.cmdKBPrintStart.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdKBPrintStart.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance51.BackColor = System.Drawing.Color.DarkOrange
        Appearance51.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance51.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance51.ForeColor = System.Drawing.Color.Black
        Me.cmdKBPrintStart.HotTrackAppearance = Appearance51
        Me.cmdKBPrintStart.ImageSize = New System.Drawing.Size(42, 25)
        Me.cmdKBPrintStart.Location = New System.Drawing.Point(766, 393)
        Me.cmdKBPrintStart.Name = "cmdKBPrintStart"
        Appearance52.BackColor = System.Drawing.Color.Transparent
        Appearance52.BackColor2 = System.Drawing.Color.Transparent
        Me.cmdKBPrintStart.PressedAppearance = Appearance52
        Me.cmdKBPrintStart.ShowFocusRect = False
        Me.cmdKBPrintStart.ShowOutline = False
        Me.cmdKBPrintStart.Size = New System.Drawing.Size(42, 25)
        Me.cmdKBPrintStart.TabIndex = 531
        Me.cmdKBPrintStart.Tag = "Keyboard"
        Me.cmdKBPrintStart.UseAppStyling = False
        Me.cmdKBPrintStart.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBPrintStart.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdKBPrintStart.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtPrintStart
        '
        Me.txtPrintStart.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance53.BackColor = System.Drawing.Color.FromArgb(CType(CType(227, Byte), Integer), CType(CType(234, Byte), Integer), CType(CType(241, Byte), Integer))
        Appearance53.TextHAlignAsString = "Right"
        Me.txtPrintStart.Appearance = Appearance53
        Me.txtPrintStart.BackColor = System.Drawing.Color.FromArgb(CType(CType(227, Byte), Integer), CType(CType(234, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.txtPrintStart.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPrintStart.Location = New System.Drawing.Point(676, 392)
        Me.txtPrintStart.Name = "txtPrintStart"
        Me.txtPrintStart.Size = New System.Drawing.Size(84, 27)
        Me.txtPrintStart.TabIndex = 530
        Me.txtPrintStart.Text = "02/04/10"
        Me.txtPrintStart.UseAppStyling = False
        '
        'cmdPrintReport
        '
        Me.cmdPrintReport.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance54.ForeColor = System.Drawing.Color.Black
        Appearance54.Image = CType(resources.GetObject("Appearance54.Image"), Object)
        Appearance54.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance54.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance54.TextVAlignAsString = "Bottom"
        Me.cmdPrintReport.Appearance = Appearance54
        Me.cmdPrintReport.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdPrintReport.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance55.BackColor = System.Drawing.Color.DarkOrange
        Appearance55.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance55.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance55.ForeColor = System.Drawing.Color.Black
        Me.cmdPrintReport.HotTrackAppearance = Appearance55
        Me.cmdPrintReport.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdPrintReport.Location = New System.Drawing.Point(868, 428)
        Me.cmdPrintReport.Name = "cmdPrintReport"
        Appearance56.BackColor = System.Drawing.Color.OrangeRed
        Appearance56.BackColor2 = System.Drawing.Color.Tomato
        Appearance56.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdPrintReport.PressedAppearance = Appearance56
        Me.cmdPrintReport.ShowFocusRect = False
        Me.cmdPrintReport.ShowOutline = False
        Me.cmdPrintReport.Size = New System.Drawing.Size(64, 44)
        Me.cmdPrintReport.StyleSetName = "StatusBar"
        Me.cmdPrintReport.TabIndex = 535
        Me.cmdPrintReport.Tag = "Print"
        Me.cmdPrintReport.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPrintReport.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPrintReport.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdKBDate
        '
        Me.cmdKBDate.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance57.BackColor = System.Drawing.Color.Transparent
        Appearance57.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance57.BackGradientStyle = Infragistics.Win.GradientStyle.None
        Appearance57.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance57.BorderColor = System.Drawing.Color.Transparent
        Appearance57.BorderColor2 = System.Drawing.Color.Transparent
        Appearance57.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance57.ForeColor = System.Drawing.Color.Black
        Appearance57.Image = CType(resources.GetObject("Appearance57.Image"), Object)
        Appearance57.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance57.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance57.TextVAlignAsString = "Bottom"
        Me.cmdKBDate.Appearance = Appearance57
        Me.cmdKBDate.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdKBDate.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance58.BackColor = System.Drawing.Color.DarkOrange
        Appearance58.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance58.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance58.ForeColor = System.Drawing.Color.Black
        Me.cmdKBDate.HotTrackAppearance = Appearance58
        Me.cmdKBDate.ImageSize = New System.Drawing.Size(42, 25)
        Me.cmdKBDate.Location = New System.Drawing.Point(766, 93)
        Me.cmdKBDate.Name = "cmdKBDate"
        Appearance59.BackColor = System.Drawing.Color.Transparent
        Appearance59.BackColor2 = System.Drawing.Color.Transparent
        Me.cmdKBDate.PressedAppearance = Appearance59
        Me.cmdKBDate.ShowFocusRect = False
        Me.cmdKBDate.ShowOutline = False
        Me.cmdKBDate.Size = New System.Drawing.Size(42, 25)
        Me.cmdKBDate.TabIndex = 539
        Me.cmdKBDate.Tag = "Keyboard"
        Me.cmdKBDate.UseAppStyling = False
        Me.cmdKBDate.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBDate.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdKBDate.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtDate
        '
        Me.txtDate.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance60.BackColor = System.Drawing.Color.FromArgb(CType(CType(227, Byte), Integer), CType(CType(234, Byte), Integer), CType(CType(241, Byte), Integer))
        Appearance60.TextHAlignAsString = "Right"
        Me.txtDate.Appearance = Appearance60
        Me.txtDate.BackColor = System.Drawing.Color.FromArgb(CType(CType(227, Byte), Integer), CType(CType(234, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.txtDate.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDate.Location = New System.Drawing.Point(676, 92)
        Me.txtDate.Name = "txtDate"
        Me.txtDate.Size = New System.Drawing.Size(84, 27)
        Me.txtDate.TabIndex = 538
        Me.txtDate.Text = "28/07/11"
        Me.txtDate.UseAppStyling = False
        '
        'cmdKBCash
        '
        Me.cmdKBCash.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance61.BackColor = System.Drawing.Color.Transparent
        Appearance61.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance61.BackGradientStyle = Infragistics.Win.GradientStyle.None
        Appearance61.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance61.BorderColor = System.Drawing.Color.Transparent
        Appearance61.BorderColor2 = System.Drawing.Color.Transparent
        Appearance61.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance61.ForeColor = System.Drawing.Color.Black
        Appearance61.Image = CType(resources.GetObject("Appearance61.Image"), Object)
        Appearance61.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance61.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance61.TextVAlignAsString = "Bottom"
        Me.cmdKBCash.Appearance = Appearance61
        Me.cmdKBCash.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdKBCash.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance62.BackColor = System.Drawing.Color.DarkOrange
        Appearance62.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance62.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance62.ForeColor = System.Drawing.Color.Black
        Me.cmdKBCash.HotTrackAppearance = Appearance62
        Me.cmdKBCash.ImageSize = New System.Drawing.Size(42, 25)
        Me.cmdKBCash.Location = New System.Drawing.Point(766, 126)
        Me.cmdKBCash.Name = "cmdKBCash"
        Appearance63.BackColor = System.Drawing.Color.Transparent
        Appearance63.BackColor2 = System.Drawing.Color.Transparent
        Me.cmdKBCash.PressedAppearance = Appearance63
        Me.cmdKBCash.ShowFocusRect = False
        Me.cmdKBCash.ShowOutline = False
        Me.cmdKBCash.Size = New System.Drawing.Size(42, 25)
        Me.cmdKBCash.TabIndex = 542
        Me.cmdKBCash.Tag = "Keyboard"
        Me.cmdKBCash.UseAppStyling = False
        Me.cmdKBCash.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBCash.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdKBCash.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtCash
        '
        Me.txtCash.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance64.BackColor = System.Drawing.Color.FromArgb(CType(CType(227, Byte), Integer), CType(CType(234, Byte), Integer), CType(CType(241, Byte), Integer))
        Appearance64.TextHAlignAsString = "Right"
        Me.txtCash.Appearance = Appearance64
        Me.txtCash.BackColor = System.Drawing.Color.FromArgb(CType(CType(227, Byte), Integer), CType(CType(234, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.txtCash.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCash.Location = New System.Drawing.Point(676, 125)
        Me.txtCash.Name = "txtCash"
        Me.txtCash.Size = New System.Drawing.Size(84, 27)
        Me.txtCash.TabIndex = 541
        Me.txtCash.Text = "0.00"
        Me.txtCash.UseAppStyling = False
        '
        'cmdKBCard
        '
        Me.cmdKBCard.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance65.BackColor = System.Drawing.Color.Transparent
        Appearance65.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance65.BackGradientStyle = Infragistics.Win.GradientStyle.None
        Appearance65.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance65.BorderColor = System.Drawing.Color.Transparent
        Appearance65.BorderColor2 = System.Drawing.Color.Transparent
        Appearance65.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance65.ForeColor = System.Drawing.Color.Black
        Appearance65.Image = CType(resources.GetObject("Appearance65.Image"), Object)
        Appearance65.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance65.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance65.TextVAlignAsString = "Bottom"
        Me.cmdKBCard.Appearance = Appearance65
        Me.cmdKBCard.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdKBCard.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance66.BackColor = System.Drawing.Color.DarkOrange
        Appearance66.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance66.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance66.ForeColor = System.Drawing.Color.Black
        Me.cmdKBCard.HotTrackAppearance = Appearance66
        Me.cmdKBCard.ImageSize = New System.Drawing.Size(42, 25)
        Me.cmdKBCard.Location = New System.Drawing.Point(766, 159)
        Me.cmdKBCard.Name = "cmdKBCard"
        Appearance67.BackColor = System.Drawing.Color.Transparent
        Appearance67.BackColor2 = System.Drawing.Color.Transparent
        Me.cmdKBCard.PressedAppearance = Appearance67
        Me.cmdKBCard.ShowFocusRect = False
        Me.cmdKBCard.ShowOutline = False
        Me.cmdKBCard.Size = New System.Drawing.Size(42, 25)
        Me.cmdKBCard.TabIndex = 545
        Me.cmdKBCard.Tag = "Keyboard"
        Me.cmdKBCard.UseAppStyling = False
        Me.cmdKBCard.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBCard.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdKBCard.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtCard
        '
        Me.txtCard.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance68.BackColor = System.Drawing.Color.FromArgb(CType(CType(227, Byte), Integer), CType(CType(234, Byte), Integer), CType(CType(241, Byte), Integer))
        Appearance68.TextHAlignAsString = "Right"
        Me.txtCard.Appearance = Appearance68
        Me.txtCard.BackColor = System.Drawing.Color.FromArgb(CType(CType(227, Byte), Integer), CType(CType(234, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.txtCard.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCard.Location = New System.Drawing.Point(676, 158)
        Me.txtCard.Name = "txtCard"
        Me.txtCard.Size = New System.Drawing.Size(84, 27)
        Me.txtCard.TabIndex = 544
        Me.txtCard.Text = "0.00"
        Me.txtCard.UseAppStyling = False
        '
        'cmdKBOther
        '
        Me.cmdKBOther.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance69.BackColor = System.Drawing.Color.Transparent
        Appearance69.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance69.BackGradientStyle = Infragistics.Win.GradientStyle.None
        Appearance69.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance69.BorderColor = System.Drawing.Color.Transparent
        Appearance69.BorderColor2 = System.Drawing.Color.Transparent
        Appearance69.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance69.ForeColor = System.Drawing.Color.Black
        Appearance69.Image = CType(resources.GetObject("Appearance69.Image"), Object)
        Appearance69.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance69.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance69.TextVAlignAsString = "Bottom"
        Me.cmdKBOther.Appearance = Appearance69
        Me.cmdKBOther.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdKBOther.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance70.BackColor = System.Drawing.Color.DarkOrange
        Appearance70.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance70.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance70.ForeColor = System.Drawing.Color.Black
        Me.cmdKBOther.HotTrackAppearance = Appearance70
        Me.cmdKBOther.ImageSize = New System.Drawing.Size(42, 25)
        Me.cmdKBOther.Location = New System.Drawing.Point(766, 192)
        Me.cmdKBOther.Name = "cmdKBOther"
        Appearance71.BackColor = System.Drawing.Color.Transparent
        Appearance71.BackColor2 = System.Drawing.Color.Transparent
        Me.cmdKBOther.PressedAppearance = Appearance71
        Me.cmdKBOther.ShowFocusRect = False
        Me.cmdKBOther.ShowOutline = False
        Me.cmdKBOther.Size = New System.Drawing.Size(42, 25)
        Me.cmdKBOther.TabIndex = 548
        Me.cmdKBOther.Tag = "Keyboard"
        Me.cmdKBOther.UseAppStyling = False
        Me.cmdKBOther.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBOther.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdKBOther.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtOther
        '
        Me.txtOther.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance72.BackColor = System.Drawing.Color.FromArgb(CType(CType(227, Byte), Integer), CType(CType(234, Byte), Integer), CType(CType(241, Byte), Integer))
        Appearance72.TextHAlignAsString = "Right"
        Me.txtOther.Appearance = Appearance72
        Me.txtOther.BackColor = System.Drawing.Color.FromArgb(CType(CType(227, Byte), Integer), CType(CType(234, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.txtOther.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtOther.Location = New System.Drawing.Point(676, 191)
        Me.txtOther.Name = "txtOther"
        Me.txtOther.Size = New System.Drawing.Size(84, 27)
        Me.txtOther.TabIndex = 547
        Me.txtOther.Text = "0.00"
        Me.txtOther.UseAppStyling = False
        '
        'cmdPrintToday
        '
        Me.cmdPrintToday.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance73.ForeColor = System.Drawing.Color.Black
        Appearance73.Image = CType(resources.GetObject("Appearance73.Image"), Object)
        Appearance73.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance73.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance73.TextVAlignAsString = "Bottom"
        Me.cmdPrintToday.Appearance = Appearance73
        Me.cmdPrintToday.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdPrintToday.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance74.BackColor = System.Drawing.Color.DarkOrange
        Appearance74.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance74.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance74.ForeColor = System.Drawing.Color.Black
        Me.cmdPrintToday.HotTrackAppearance = Appearance74
        Me.cmdPrintToday.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdPrintToday.Location = New System.Drawing.Point(868, 143)
        Me.cmdPrintToday.Name = "cmdPrintToday"
        Appearance75.BackColor = System.Drawing.Color.OrangeRed
        Appearance75.BackColor2 = System.Drawing.Color.Tomato
        Appearance75.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdPrintToday.PressedAppearance = Appearance75
        Me.cmdPrintToday.ShowFocusRect = False
        Me.cmdPrintToday.ShowOutline = False
        Me.cmdPrintToday.Size = New System.Drawing.Size(64, 44)
        Me.cmdPrintToday.StyleSetName = "StatusBar"
        Me.cmdPrintToday.TabIndex = 549
        Me.cmdPrintToday.Tag = "Print"
        Me.cmdPrintToday.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPrintToday.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPrintToday.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'BankingTableAdapter
        '
        Me.BankingTableAdapter.ClearBeforeFill = True
        '
        'cmdAdd
        '
        Me.cmdAdd.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance76.ForeColor = System.Drawing.Color.Black
        Appearance76.Image = CType(resources.GetObject("Appearance76.Image"), Object)
        Appearance76.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance76.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance76.TextVAlignAsString = "Bottom"
        Me.cmdAdd.Appearance = Appearance76
        Me.cmdAdd.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdAdd.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance77.BackColor = System.Drawing.Color.DarkOrange
        Appearance77.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance77.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance77.ForeColor = System.Drawing.Color.Black
        Me.cmdAdd.HotTrackAppearance = Appearance77
        Me.cmdAdd.ImageSize = New System.Drawing.Size(24, 24)
        Me.cmdAdd.Location = New System.Drawing.Point(814, 253)
        Me.cmdAdd.Name = "cmdAdd"
        Appearance78.BackColor = System.Drawing.Color.OrangeRed
        Appearance78.BackColor2 = System.Drawing.Color.Tomato
        Appearance78.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdAdd.PressedAppearance = Appearance78
        Me.cmdAdd.ShowFocusRect = False
        Me.cmdAdd.ShowOutline = False
        Me.cmdAdd.Size = New System.Drawing.Size(44, 38)
        Me.cmdAdd.StyleSetName = "StatusBar"
        Me.cmdAdd.TabIndex = 550
        Me.cmdAdd.Tag = "+"
        Me.cmdAdd.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdAdd.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdAdd.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdAdd.Visible = False
        '
        'cmdPrintShowAll
        '
        Me.cmdPrintShowAll.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance79.ForeColor = System.Drawing.Color.Black
        Appearance79.Image = CType(resources.GetObject("Appearance79.Image"), Object)
        Appearance79.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance79.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance79.TextVAlignAsString = "Bottom"
        Me.cmdPrintShowAll.Appearance = Appearance79
        Me.cmdPrintShowAll.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdPrintShowAll.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance80.BackColor = System.Drawing.Color.DarkOrange
        Appearance80.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance80.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance80.ForeColor = System.Drawing.Color.Black
        Me.cmdPrintShowAll.HotTrackAppearance = Appearance80
        Me.cmdPrintShowAll.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdPrintShowAll.Location = New System.Drawing.Point(868, 378)
        Me.cmdPrintShowAll.Name = "cmdPrintShowAll"
        Appearance81.BackColor = System.Drawing.Color.OrangeRed
        Appearance81.BackColor2 = System.Drawing.Color.Tomato
        Appearance81.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdPrintShowAll.PressedAppearance = Appearance81
        Me.cmdPrintShowAll.ShowFocusRect = False
        Me.cmdPrintShowAll.ShowOutline = False
        Me.cmdPrintShowAll.Size = New System.Drawing.Size(64, 44)
        Me.cmdPrintShowAll.StyleSetName = "StatusBar"
        Me.cmdPrintShowAll.TabIndex = 551
        Me.cmdPrintShowAll.Tag = "ShowAll"
        Me.cmdPrintShowAll.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPrintShowAll.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPrintShowAll.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDeleteRow
        '
        Me.cmdDeleteRow.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Appearance1.ForeColor = System.Drawing.Color.Black
        Appearance1.Image = CType(resources.GetObject("Appearance1.Image"), Object)
        Appearance1.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance1.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance1.TextVAlignAsString = "Bottom"
        Me.cmdDeleteRow.Appearance = Appearance1
        Me.cmdDeleteRow.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdDeleteRow.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance2.BackColor = System.Drawing.Color.DarkOrange
        Appearance2.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance2.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance2.ForeColor = System.Drawing.Color.Black
        Me.cmdDeleteRow.HotTrackAppearance = Appearance2
        Me.cmdDeleteRow.ImageSize = New System.Drawing.Size(26, 26)
        Me.cmdDeleteRow.Location = New System.Drawing.Point(291, 3)
        Me.cmdDeleteRow.Name = "cmdDeleteRow"
        Appearance3.BackColor = System.Drawing.Color.OrangeRed
        Appearance3.BackColor2 = System.Drawing.Color.Tomato
        Appearance3.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdDeleteRow.PressedAppearance = Appearance3
        Me.cmdDeleteRow.ShowFocusRect = False
        Me.cmdDeleteRow.ShowOutline = False
        Me.cmdDeleteRow.Size = New System.Drawing.Size(64, 44)
        Me.cmdDeleteRow.StyleSetName = "StatusBar"
        Me.cmdDeleteRow.TabIndex = 553
        Me.cmdDeleteRow.Tag = "x"
        Me.cmdDeleteRow.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDeleteRow.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDeleteRow.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblPostcodeLbl
        '
        Me.lblPostcodeLbl.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance82.BackColor = System.Drawing.Color.Transparent
        Appearance82.ForeColor = System.Drawing.Color.DimGray
        Appearance82.TextHAlignAsString = "Right"
        Me.lblPostcodeLbl.Appearance = Appearance82
        Me.lblPostcodeLbl.AutoSize = True
        Me.lblPostcodeLbl.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPostcodeLbl.Location = New System.Drawing.Point(625, 96)
        Me.lblPostcodeLbl.Name = "lblPostcodeLbl"
        Me.lblPostcodeLbl.Size = New System.Drawing.Size(45, 20)
        Me.lblPostcodeLbl.StyleSetName = "TextEntryLabel"
        Me.lblPostcodeLbl.TabIndex = 554
        Me.lblPostcodeLbl.Text = "Date:"
        Me.lblPostcodeLbl.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraLabel2
        '
        Me.UltraLabel2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance83.BackColor = System.Drawing.Color.Transparent
        Appearance83.ForeColor = System.Drawing.Color.DimGray
        Appearance83.TextHAlignAsString = "Right"
        Me.UltraLabel2.Appearance = Appearance83
        Me.UltraLabel2.AutoSize = True
        Me.UltraLabel2.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UltraLabel2.Location = New System.Drawing.Point(621, 129)
        Me.UltraLabel2.Name = "UltraLabel2"
        Me.UltraLabel2.Size = New System.Drawing.Size(49, 20)
        Me.UltraLabel2.StyleSetName = "TextEntryLabel"
        Me.UltraLabel2.TabIndex = 555
        Me.UltraLabel2.Text = "Cash:"
        Me.UltraLabel2.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraLabel3
        '
        Me.UltraLabel3.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance84.BackColor = System.Drawing.Color.Transparent
        Appearance84.ForeColor = System.Drawing.Color.DimGray
        Appearance84.TextHAlignAsString = "Right"
        Me.UltraLabel3.Appearance = Appearance84
        Me.UltraLabel3.AutoSize = True
        Me.UltraLabel3.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UltraLabel3.Location = New System.Drawing.Point(616, 162)
        Me.UltraLabel3.Name = "UltraLabel3"
        Me.UltraLabel3.Size = New System.Drawing.Size(54, 20)
        Me.UltraLabel3.StyleSetName = "TextEntryLabel"
        Me.UltraLabel3.TabIndex = 556
        Me.UltraLabel3.Text = "Cards:"
        Me.UltraLabel3.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraLabel4
        '
        Me.UltraLabel4.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance85.BackColor = System.Drawing.Color.Transparent
        Appearance85.ForeColor = System.Drawing.Color.DimGray
        Appearance85.TextHAlignAsString = "Right"
        Me.UltraLabel4.Appearance = Appearance85
        Me.UltraLabel4.AutoSize = True
        Me.UltraLabel4.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UltraLabel4.Location = New System.Drawing.Point(623, 261)
        Me.UltraLabel4.Name = "UltraLabel4"
        Me.UltraLabel4.Size = New System.Drawing.Size(47, 20)
        Me.UltraLabel4.StyleSetName = "TextEntryLabel"
        Me.UltraLabel4.TabIndex = 559
        Me.UltraLabel4.Text = "Total:"
        Me.UltraLabel4.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraLabel5
        '
        Me.UltraLabel5.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance86.BackColor = System.Drawing.Color.Transparent
        Appearance86.ForeColor = System.Drawing.Color.DimGray
        Appearance86.TextHAlignAsString = "Right"
        Me.UltraLabel5.Appearance = Appearance86
        Me.UltraLabel5.AutoSize = True
        Me.UltraLabel5.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UltraLabel5.Location = New System.Drawing.Point(628, 228)
        Me.UltraLabel5.Name = "UltraLabel5"
        Me.UltraLabel5.Size = New System.Drawing.Size(42, 20)
        Me.UltraLabel5.StyleSetName = "TextEntryLabel"
        Me.UltraLabel5.TabIndex = 558
        Me.UltraLabel5.Text = "Tips:"
        Me.UltraLabel5.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraLabel6
        '
        Me.UltraLabel6.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance87.BackColor = System.Drawing.Color.Transparent
        Appearance87.ForeColor = System.Drawing.Color.DimGray
        Appearance87.TextHAlignAsString = "Right"
        Me.UltraLabel6.Appearance = Appearance87
        Me.UltraLabel6.AutoSize = True
        Me.UltraLabel6.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UltraLabel6.Location = New System.Drawing.Point(618, 195)
        Me.UltraLabel6.Name = "UltraLabel6"
        Me.UltraLabel6.Size = New System.Drawing.Size(52, 20)
        Me.UltraLabel6.StyleSetName = "TextEntryLabel"
        Me.UltraLabel6.TabIndex = 557
        Me.UltraLabel6.Text = "Other:"
        Me.UltraLabel6.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraLabel10
        '
        Me.UltraLabel10.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance88.BackColor = System.Drawing.Color.Transparent
        Appearance88.ForeColor = System.Drawing.Color.DimGray
        Appearance88.TextHAlignAsString = "Right"
        Me.UltraLabel10.Appearance = Appearance88
        Me.UltraLabel10.AutoSize = True
        Me.UltraLabel10.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UltraLabel10.Location = New System.Drawing.Point(640, 429)
        Me.UltraLabel10.Name = "UltraLabel10"
        Me.UltraLabel10.Size = New System.Drawing.Size(30, 20)
        Me.UltraLabel10.StyleSetName = "TextEntryLabel"
        Me.UltraLabel10.TabIndex = 562
        Me.UltraLabel10.Text = "To:"
        Me.UltraLabel10.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraLabel11
        '
        Me.UltraLabel11.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance89.BackColor = System.Drawing.Color.Transparent
        Appearance89.ForeColor = System.Drawing.Color.DimGray
        Appearance89.TextHAlignAsString = "Right"
        Me.UltraLabel11.Appearance = Appearance89
        Me.UltraLabel11.AutoSize = True
        Me.UltraLabel11.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UltraLabel11.Location = New System.Drawing.Point(621, 396)
        Me.UltraLabel11.Name = "UltraLabel11"
        Me.UltraLabel11.Size = New System.Drawing.Size(49, 20)
        Me.UltraLabel11.StyleSetName = "TextEntryLabel"
        Me.UltraLabel11.TabIndex = 561
        Me.UltraLabel11.Text = "From:"
        Me.UltraLabel11.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraLabel12
        '
        Me.UltraLabel12.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance90.BackColor = System.Drawing.Color.Transparent
        Appearance90.ForeColor = System.Drawing.Color.DimGray
        Appearance90.TextHAlignAsString = "Right"
        Me.UltraLabel12.Appearance = Appearance90
        Me.UltraLabel12.AutoSize = True
        Me.UltraLabel12.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UltraLabel12.Location = New System.Drawing.Point(621, 366)
        Me.UltraLabel12.Name = "UltraLabel12"
        Me.UltraLabel12.Size = New System.Drawing.Size(87, 20)
        Me.UltraLabel12.StyleSetName = "TextEntryLabel"
        Me.UltraLabel12.TabIndex = 560
        Me.UltraLabel12.Text = "Print report"
        Me.UltraLabel12.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'frmBanking
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(984, 684)
        Me.Controls.Add(Me.UltraLabel10)
        Me.Controls.Add(Me.UltraLabel11)
        Me.Controls.Add(Me.UltraLabel12)
        Me.Controls.Add(Me.UltraLabel4)
        Me.Controls.Add(Me.UltraLabel5)
        Me.Controls.Add(Me.UltraLabel6)
        Me.Controls.Add(Me.UltraLabel3)
        Me.Controls.Add(Me.UltraLabel2)
        Me.Controls.Add(Me.lblPostcodeLbl)
        Me.Controls.Add(Me.cmdPrintShowAll)
        Me.Controls.Add(Me.cmdAdd)
        Me.Controls.Add(Me.cmdPrintToday)
        Me.Controls.Add(Me.cmdKBOther)
        Me.Controls.Add(Me.txtOther)
        Me.Controls.Add(Me.cmdKBCard)
        Me.Controls.Add(Me.txtCard)
        Me.Controls.Add(Me.cmdKBCash)
        Me.Controls.Add(Me.txtCash)
        Me.Controls.Add(Me.cmdKBDate)
        Me.Controls.Add(Me.txtDate)
        Me.Controls.Add(Me.cmdPrintReport)
        Me.Controls.Add(Me.cmdKBPrintEnd)
        Me.Controls.Add(Me.txtPrintEnd)
        Me.Controls.Add(Me.cmdKBPrintStart)
        Me.Controls.Add(Me.txtPrintStart)
        Me.Controls.Add(Me.cmdKBTips)
        Me.Controls.Add(Me.txtTips)
        Me.Controls.Add(Me.cmdClear)
        Me.Controls.Add(Me.cmdOK)
        Me.Controls.Add(Me.cmdKBTotal)
        Me.Controls.Add(Me.txtTotal)
        Me.Controls.Add(Me.ugdBanking)
        Me.ForeColor = System.Drawing.Color.DimGray
        Me.Name = "frmBanking"
        Me.ShowInTaskbar = False
        Me.Controls.SetChildIndex(Me.uplBasePanel, 0)
        Me.Controls.SetChildIndex(Me.ugdBanking, 0)
        Me.Controls.SetChildIndex(Me.txtTotal, 0)
        Me.Controls.SetChildIndex(Me.cmdKBTotal, 0)
        Me.Controls.SetChildIndex(Me.cmdOK, 0)
        Me.Controls.SetChildIndex(Me.cmdClear, 0)
        Me.Controls.SetChildIndex(Me.txtTips, 0)
        Me.Controls.SetChildIndex(Me.cmdKBTips, 0)
        Me.Controls.SetChildIndex(Me.txtPrintStart, 0)
        Me.Controls.SetChildIndex(Me.cmdKBPrintStart, 0)
        Me.Controls.SetChildIndex(Me.txtPrintEnd, 0)
        Me.Controls.SetChildIndex(Me.cmdKBPrintEnd, 0)
        Me.Controls.SetChildIndex(Me.cmdPrintReport, 0)
        Me.Controls.SetChildIndex(Me.txtDate, 0)
        Me.Controls.SetChildIndex(Me.cmdKBDate, 0)
        Me.Controls.SetChildIndex(Me.txtCash, 0)
        Me.Controls.SetChildIndex(Me.cmdKBCash, 0)
        Me.Controls.SetChildIndex(Me.txtCard, 0)
        Me.Controls.SetChildIndex(Me.cmdKBCard, 0)
        Me.Controls.SetChildIndex(Me.txtOther, 0)
        Me.Controls.SetChildIndex(Me.cmdKBOther, 0)
        Me.Controls.SetChildIndex(Me.cmdPrintToday, 0)
        Me.Controls.SetChildIndex(Me.cmdAdd, 0)
        Me.Controls.SetChildIndex(Me.cmdPrintShowAll, 0)
        Me.Controls.SetChildIndex(Me.lblPostcodeLbl, 0)
        Me.Controls.SetChildIndex(Me.UltraLabel2, 0)
        Me.Controls.SetChildIndex(Me.UltraLabel3, 0)
        Me.Controls.SetChildIndex(Me.UltraLabel6, 0)
        Me.Controls.SetChildIndex(Me.UltraLabel5, 0)
        Me.Controls.SetChildIndex(Me.UltraLabel4, 0)
        Me.Controls.SetChildIndex(Me.UltraLabel12, 0)
        Me.Controls.SetChildIndex(Me.UltraLabel11, 0)
        Me.Controls.SetChildIndex(Me.UltraLabel10, 0)
        Me.uplBasePanel.ClientArea.ResumeLayout(False)
        Me.uplBasePanel.ResumeLayout(False)
        CType(Me.ugdBanking, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BankingBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EZMenuDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTotal, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTips, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtPrintEnd, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtPrintStart, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtDate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtCash, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtCard, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtOther, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents cmdClose As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ugdBanking As Infragistics.Win.UltraWinGrid.UltraGrid
    Friend WithEvents txtTotal As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents cmdKBTotal As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdGridDown As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdGridUp As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdOK As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdClear As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdKBTips As Infragistics.Win.Misc.UltraButton
    Friend WithEvents txtTips As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents cmdKBPrintEnd As Infragistics.Win.Misc.UltraButton
    Friend WithEvents txtPrintEnd As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents cmdKBPrintStart As Infragistics.Win.Misc.UltraButton
    Friend WithEvents txtPrintStart As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents cmdPrintReport As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdKBDate As Infragistics.Win.Misc.UltraButton
    Friend WithEvents txtDate As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents cmdKBCash As Infragistics.Win.Misc.UltraButton
    Friend WithEvents txtCash As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents cmdKBCard As Infragistics.Win.Misc.UltraButton
    Friend WithEvents txtCard As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents cmdKBOther As Infragistics.Win.Misc.UltraButton
    Friend WithEvents txtOther As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents cmdPrintToday As Infragistics.Win.Misc.UltraButton
    Private WithEvents EZMenuDataSet As EZMenu.EZMenuDataSet
    Friend WithEvents BankingBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents BankingTableAdapter As EZMenu.EZMenuDataSetTableAdapters.BankingTableAdapter
    Friend WithEvents cmdAdd As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdPrintShowAll As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraCalendarLook1 As Infragistics.Win.UltraWinSchedule.UltraCalendarLook
    Friend WithEvents cmdDeleteRow As Infragistics.Win.Misc.UltraButton
    Friend WithEvents lblPostcodeLbl As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel2 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel3 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel4 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel5 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel6 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel10 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel11 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel12 As Infragistics.Win.Misc.UltraLabel
End Class
