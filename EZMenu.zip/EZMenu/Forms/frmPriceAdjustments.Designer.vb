﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPriceAdjustments
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim Appearance1 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance2 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance3 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance4 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance5 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance6 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance7 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance8 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance9 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance10 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance11 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance12 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance13 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance14 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance15 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance16 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance17 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance18 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance19 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance20 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance21 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance22 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance23 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance24 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance25 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance26 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance27 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance28 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance29 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance30 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance31 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance32 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance33 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance34 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance35 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmPriceAdjustments))
        Dim Appearance36 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance37 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance38 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance39 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance40 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance41 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance42 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance43 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance44 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance45 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance46 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance47 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance48 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance49 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance50 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance51 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance52 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance53 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance54 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance55 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance56 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance57 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance58 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance59 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance60 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance61 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance62 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance63 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance64 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance65 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance66 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance67 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance68 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance69 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance70 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance71 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance72 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance73 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance74 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance75 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance76 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance77 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance78 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Me.cmdPercentage = New Infragistics.Win.Misc.UltraButton()
        Me.cmdAmount = New Infragistics.Win.Misc.UltraButton()
        Me.upnlDiscChargeOptions = New Infragistics.Win.Misc.UltraPanel()
        Me.ubtnDC1 = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnDC2 = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnDC3 = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnDC4 = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnDC5 = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnDCNone = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnDCToggleGlobal = New Infragistics.Win.Misc.UltraButton()
        Me.upnlPercPounds = New Infragistics.Win.Misc.UltraPanel()
        Me.upnlAppliesTo = New Infragistics.Win.Misc.UltraPanel()
        Me.cmdAppliesToMealDrinks = New Infragistics.Win.Misc.UltraButton()
        Me.cmdAppliesToBill = New Infragistics.Win.Misc.UltraButton()
        Me.cmdAppliesToItem = New Infragistics.Win.Misc.UltraButton()
        Me.upnlDiscCharges = New Infragistics.Win.Misc.UltraPanel()
        Me.cmdShowCharges = New Infragistics.Win.Misc.UltraButton()
        Me.cmdShowDiscounts = New Infragistics.Win.Misc.UltraButton()
        Me.cmdOK = New Infragistics.Win.Misc.UltraButton()
        Me.cmdCancel = New Infragistics.Win.Misc.UltraButton()
        Me.ubtn7 = New Infragistics.Win.Misc.UltraButton()
        Me.ubtn8 = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnCancel = New Infragistics.Win.Misc.UltraButton()
        Me.ubtn9 = New Infragistics.Win.Misc.UltraButton()
        Me.ubtn0 = New Infragistics.Win.Misc.UltraButton()
        Me.ubtn4 = New Infragistics.Win.Misc.UltraButton()
        Me.ubtn3 = New Infragistics.Win.Misc.UltraButton()
        Me.ubtn5 = New Infragistics.Win.Misc.UltraButton()
        Me.ubtn2 = New Infragistics.Win.Misc.UltraButton()
        Me.ubtn6 = New Infragistics.Win.Misc.UltraButton()
        Me.ubtn1 = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnDot = New Infragistics.Win.Misc.UltraButton()
        Me.UltraPanel1 = New Infragistics.Win.Misc.UltraPanel()
        Me.lblEntryBox = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraPanel2 = New Infragistics.Win.Misc.UltraPanel()
        Me.UltraFlowLayoutManager2 = New Infragistics.Win.Misc.UltraFlowLayoutManager(Me.components)
        Me.upnlDiscChargeOptions.ClientArea.SuspendLayout()
        Me.upnlDiscChargeOptions.SuspendLayout()
        Me.upnlPercPounds.ClientArea.SuspendLayout()
        Me.upnlPercPounds.SuspendLayout()
        Me.upnlAppliesTo.ClientArea.SuspendLayout()
        Me.upnlAppliesTo.SuspendLayout()
        Me.upnlDiscCharges.ClientArea.SuspendLayout()
        Me.upnlDiscCharges.SuspendLayout()
        Me.UltraPanel1.ClientArea.SuspendLayout()
        Me.UltraPanel1.SuspendLayout()
        Me.UltraPanel2.ClientArea.SuspendLayout()
        Me.UltraPanel2.SuspendLayout()
        CType(Me.UltraFlowLayoutManager2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'cmdPercentage
        '
        Appearance1.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance1.ForeColor = System.Drawing.Color.DarkGreen
        Me.cmdPercentage.Appearance = Appearance1
        Me.cmdPercentage.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance2.BackColor = System.Drawing.Color.PowderBlue
        Appearance2.BackColor2 = System.Drawing.Color.Aqua
        Appearance2.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance2.ForeColor = System.Drawing.Color.Black
        Me.cmdPercentage.HotTrackAppearance = Appearance2
        Me.cmdPercentage.Location = New System.Drawing.Point(3, 3)
        Me.cmdPercentage.Name = "cmdPercentage"
        Me.cmdPercentage.ShowFocusRect = False
        Me.cmdPercentage.ShowOutline = False
        Me.cmdPercentage.Size = New System.Drawing.Size(190, 50)
        Me.cmdPercentage.TabIndex = 126
        Me.cmdPercentage.Text = "%"
        Me.cmdPercentage.UseAppStyling = False
        Me.cmdPercentage.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPercentage.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdPercentage.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdAmount
        '
        Appearance3.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance3.ForeColor = System.Drawing.Color.DarkGreen
        Me.cmdAmount.Appearance = Appearance3
        Me.cmdAmount.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance4.BackColor = System.Drawing.Color.PowderBlue
        Appearance4.BackColor2 = System.Drawing.Color.Aqua
        Appearance4.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance4.ForeColor = System.Drawing.Color.Black
        Me.cmdAmount.HotTrackAppearance = Appearance4
        Me.cmdAmount.Location = New System.Drawing.Point(3, 57)
        Me.cmdAmount.Name = "cmdAmount"
        Me.cmdAmount.ShowFocusRect = False
        Me.cmdAmount.ShowOutline = False
        Me.cmdAmount.Size = New System.Drawing.Size(190, 50)
        Me.cmdAmount.TabIndex = 127
        Me.cmdAmount.Text = "£"
        Me.cmdAmount.UseAppStyling = False
        Me.cmdAmount.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdAmount.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdAmount.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'upnlDiscChargeOptions
        '
        Appearance5.BackColor = System.Drawing.Color.Transparent
        Me.upnlDiscChargeOptions.Appearance = Appearance5
        '
        'upnlDiscChargeOptions.ClientArea
        '
        Me.upnlDiscChargeOptions.ClientArea.Controls.Add(Me.ubtnDC1)
        Me.upnlDiscChargeOptions.ClientArea.Controls.Add(Me.ubtnDC2)
        Me.upnlDiscChargeOptions.ClientArea.Controls.Add(Me.ubtnDC3)
        Me.upnlDiscChargeOptions.ClientArea.Controls.Add(Me.ubtnDC4)
        Me.upnlDiscChargeOptions.ClientArea.Controls.Add(Me.ubtnDC5)
        Me.upnlDiscChargeOptions.ClientArea.Controls.Add(Me.ubtnDCNone)
        Me.upnlDiscChargeOptions.ClientArea.Controls.Add(Me.ubtnDCToggleGlobal)
        Me.upnlDiscChargeOptions.ForeColor = System.Drawing.Color.White
        Me.upnlDiscChargeOptions.Location = New System.Drawing.Point(235, 12)
        Me.upnlDiscChargeOptions.Name = "upnlDiscChargeOptions"
        Me.upnlDiscChargeOptions.Size = New System.Drawing.Size(201, 404)
        Me.upnlDiscChargeOptions.TabIndex = 371
        '
        'ubtnDC1
        '
        Appearance6.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance6.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance6.BorderColor = System.Drawing.Color.DarkGreen
        Appearance6.ForeColor = System.Drawing.Color.DarkGreen
        Me.ubtnDC1.Appearance = Appearance6
        Me.ubtnDC1.Font = New System.Drawing.Font("Ebrima", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance7.BackColor = System.Drawing.Color.PowderBlue
        Appearance7.BackColor2 = System.Drawing.Color.Aqua
        Appearance7.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance7.ForeColor = System.Drawing.Color.Black
        Me.ubtnDC1.HotTrackAppearance = Appearance7
        Me.ubtnDC1.Location = New System.Drawing.Point(6, 5)
        Me.ubtnDC1.Name = "ubtnDC1"
        Me.ubtnDC1.ShowFocusRect = False
        Me.ubtnDC1.ShowOutline = False
        Me.ubtnDC1.Size = New System.Drawing.Size(188, 50)
        Me.ubtnDC1.TabIndex = 145
        Me.ubtnDC1.Tag = ""
        Me.ubtnDC1.UseAppStyling = False
        Me.ubtnDC1.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnDC1.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.ubtnDC1.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnDC2
        '
        Appearance8.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance8.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance8.BorderColor = System.Drawing.Color.DarkGreen
        Appearance8.ForeColor = System.Drawing.Color.DarkGreen
        Me.ubtnDC2.Appearance = Appearance8
        Me.ubtnDC2.Font = New System.Drawing.Font("Ebrima", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance9.BackColor = System.Drawing.Color.PowderBlue
        Appearance9.BackColor2 = System.Drawing.Color.Aqua
        Appearance9.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance9.ForeColor = System.Drawing.Color.Black
        Me.ubtnDC2.HotTrackAppearance = Appearance9
        Me.ubtnDC2.Location = New System.Drawing.Point(6, 60)
        Me.ubtnDC2.Name = "ubtnDC2"
        Me.ubtnDC2.ShowFocusRect = False
        Me.ubtnDC2.ShowOutline = False
        Me.ubtnDC2.Size = New System.Drawing.Size(188, 50)
        Me.ubtnDC2.TabIndex = 144
        Me.ubtnDC2.Tag = ""
        Me.ubtnDC2.UseAppStyling = False
        Me.ubtnDC2.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnDC2.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.ubtnDC2.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnDC3
        '
        Appearance10.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance10.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance10.BorderColor = System.Drawing.Color.DarkGreen
        Appearance10.ForeColor = System.Drawing.Color.DarkGreen
        Me.ubtnDC3.Appearance = Appearance10
        Me.ubtnDC3.Font = New System.Drawing.Font("Ebrima", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance11.BackColor = System.Drawing.Color.PowderBlue
        Appearance11.BackColor2 = System.Drawing.Color.Aqua
        Appearance11.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance11.ForeColor = System.Drawing.Color.Black
        Me.ubtnDC3.HotTrackAppearance = Appearance11
        Me.ubtnDC3.Location = New System.Drawing.Point(6, 115)
        Me.ubtnDC3.Name = "ubtnDC3"
        Me.ubtnDC3.ShowFocusRect = False
        Me.ubtnDC3.ShowOutline = False
        Me.ubtnDC3.Size = New System.Drawing.Size(188, 50)
        Me.ubtnDC3.TabIndex = 143
        Me.ubtnDC3.Tag = ""
        Me.ubtnDC3.UseAppStyling = False
        Me.ubtnDC3.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnDC3.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.ubtnDC3.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnDC4
        '
        Appearance12.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance12.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance12.BorderColor = System.Drawing.Color.DarkGreen
        Appearance12.ForeColor = System.Drawing.Color.DarkGreen
        Me.ubtnDC4.Appearance = Appearance12
        Me.ubtnDC4.Font = New System.Drawing.Font("Ebrima", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance13.BackColor = System.Drawing.Color.PowderBlue
        Appearance13.BackColor2 = System.Drawing.Color.Aqua
        Appearance13.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance13.ForeColor = System.Drawing.Color.Black
        Me.ubtnDC4.HotTrackAppearance = Appearance13
        Me.ubtnDC4.Location = New System.Drawing.Point(6, 170)
        Me.ubtnDC4.Name = "ubtnDC4"
        Me.ubtnDC4.ShowFocusRect = False
        Me.ubtnDC4.ShowOutline = False
        Me.ubtnDC4.Size = New System.Drawing.Size(188, 50)
        Me.ubtnDC4.TabIndex = 142
        Me.ubtnDC4.Tag = ""
        Me.ubtnDC4.UseAppStyling = False
        Me.ubtnDC4.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnDC4.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.ubtnDC4.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnDC5
        '
        Appearance14.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance14.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance14.BorderColor = System.Drawing.Color.DarkGreen
        Appearance14.ForeColor = System.Drawing.Color.DarkGreen
        Me.ubtnDC5.Appearance = Appearance14
        Me.ubtnDC5.Font = New System.Drawing.Font("Ebrima", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance15.BackColor = System.Drawing.Color.PowderBlue
        Appearance15.BackColor2 = System.Drawing.Color.Aqua
        Appearance15.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance15.ForeColor = System.Drawing.Color.Black
        Me.ubtnDC5.HotTrackAppearance = Appearance15
        Me.ubtnDC5.Location = New System.Drawing.Point(6, 225)
        Me.ubtnDC5.Name = "ubtnDC5"
        Me.ubtnDC5.ShowFocusRect = False
        Me.ubtnDC5.ShowOutline = False
        Me.ubtnDC5.Size = New System.Drawing.Size(188, 50)
        Me.ubtnDC5.TabIndex = 141
        Me.ubtnDC5.Tag = ""
        Me.ubtnDC5.UseAppStyling = False
        Me.ubtnDC5.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnDC5.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.ubtnDC5.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnDCNone
        '
        Appearance16.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance16.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance16.BorderColor = System.Drawing.Color.DarkGreen
        Appearance16.ForeColor = System.Drawing.Color.DarkGreen
        Me.ubtnDCNone.Appearance = Appearance16
        Me.ubtnDCNone.Font = New System.Drawing.Font("Ebrima", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance17.BackColor = System.Drawing.Color.PowderBlue
        Appearance17.BackColor2 = System.Drawing.Color.Aqua
        Appearance17.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance17.ForeColor = System.Drawing.Color.Black
        Me.ubtnDCNone.HotTrackAppearance = Appearance17
        Me.ubtnDCNone.Location = New System.Drawing.Point(6, 280)
        Me.ubtnDCNone.Name = "ubtnDCNone"
        Me.ubtnDCNone.ShowFocusRect = False
        Me.ubtnDCNone.ShowOutline = False
        Me.ubtnDCNone.Size = New System.Drawing.Size(188, 50)
        Me.ubtnDCNone.TabIndex = 145
        Me.ubtnDCNone.Tag = "0"
        Me.ubtnDCNone.Text = "None"
        Me.ubtnDCNone.UseAppStyling = False
        Me.ubtnDCNone.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnDCNone.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.ubtnDCNone.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnDCToggleGlobal
        '
        Appearance18.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance18.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance18.BorderColor = System.Drawing.Color.DarkGreen
        Appearance18.ForeColor = System.Drawing.Color.DarkGreen
        Me.ubtnDCToggleGlobal.Appearance = Appearance18
        Me.ubtnDCToggleGlobal.Font = New System.Drawing.Font("Ebrima", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance19.BackColor = System.Drawing.Color.PowderBlue
        Appearance19.BackColor2 = System.Drawing.Color.Aqua
        Appearance19.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance19.ForeColor = System.Drawing.Color.Black
        Me.ubtnDCToggleGlobal.HotTrackAppearance = Appearance19
        Me.ubtnDCToggleGlobal.Location = New System.Drawing.Point(6, 335)
        Me.ubtnDCToggleGlobal.Name = "ubtnDCToggleGlobal"
        Me.ubtnDCToggleGlobal.ShowFocusRect = False
        Me.ubtnDCToggleGlobal.ShowOutline = False
        Me.ubtnDCToggleGlobal.Size = New System.Drawing.Size(188, 50)
        Me.ubtnDCToggleGlobal.TabIndex = 375
        Me.ubtnDCToggleGlobal.Tag = "0"
        Me.ubtnDCToggleGlobal.Text = "Off Global Discounts"
        Me.ubtnDCToggleGlobal.UseAppStyling = False
        Me.ubtnDCToggleGlobal.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnDCToggleGlobal.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.ubtnDCToggleGlobal.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'upnlPercPounds
        '
        Appearance20.BackColor = System.Drawing.Color.Transparent
        Me.upnlPercPounds.Appearance = Appearance20
        '
        'upnlPercPounds.ClientArea
        '
        Me.upnlPercPounds.ClientArea.Controls.Add(Me.cmdPercentage)
        Me.upnlPercPounds.ClientArea.Controls.Add(Me.cmdAmount)
        Me.upnlPercPounds.Location = New System.Drawing.Point(686, 19)
        Me.upnlPercPounds.Name = "upnlPercPounds"
        Me.upnlPercPounds.Size = New System.Drawing.Size(197, 110)
        Me.upnlPercPounds.TabIndex = 372
        '
        'upnlAppliesTo
        '
        Appearance21.BackColor = System.Drawing.Color.Transparent
        Me.upnlAppliesTo.Appearance = Appearance21
        '
        'upnlAppliesTo.ClientArea
        '
        Me.upnlAppliesTo.ClientArea.Controls.Add(Me.cmdAppliesToMealDrinks)
        Me.upnlAppliesTo.ClientArea.Controls.Add(Me.cmdAppliesToBill)
        Me.upnlAppliesTo.ClientArea.Controls.Add(Me.cmdAppliesToItem)
        Me.upnlAppliesTo.Location = New System.Drawing.Point(686, 148)
        Me.upnlAppliesTo.Name = "upnlAppliesTo"
        Me.upnlAppliesTo.Size = New System.Drawing.Size(197, 166)
        Me.upnlAppliesTo.TabIndex = 373
        '
        'cmdAppliesToMealDrinks
        '
        Appearance22.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance22.ForeColor = System.Drawing.Color.DarkGreen
        Me.cmdAppliesToMealDrinks.Appearance = Appearance22
        Me.cmdAppliesToMealDrinks.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance23.BackColor = System.Drawing.Color.PowderBlue
        Appearance23.BackColor2 = System.Drawing.Color.Aqua
        Appearance23.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance23.ForeColor = System.Drawing.Color.Black
        Me.cmdAppliesToMealDrinks.HotTrackAppearance = Appearance23
        Me.cmdAppliesToMealDrinks.Location = New System.Drawing.Point(3, 113)
        Me.cmdAppliesToMealDrinks.Name = "cmdAppliesToMealDrinks"
        Me.cmdAppliesToMealDrinks.ShowFocusRect = False
        Me.cmdAppliesToMealDrinks.ShowOutline = False
        Me.cmdAppliesToMealDrinks.Size = New System.Drawing.Size(190, 50)
        Me.cmdAppliesToMealDrinks.TabIndex = 374
        Me.cmdAppliesToMealDrinks.Text = "Meal && Drinks"
        Me.cmdAppliesToMealDrinks.UseAppStyling = False
        Me.cmdAppliesToMealDrinks.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdAppliesToMealDrinks.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdAppliesToMealDrinks.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdAppliesToBill
        '
        Appearance24.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance24.ForeColor = System.Drawing.Color.DarkGreen
        Me.cmdAppliesToBill.Appearance = Appearance24
        Me.cmdAppliesToBill.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance25.BackColor = System.Drawing.Color.PowderBlue
        Appearance25.BackColor2 = System.Drawing.Color.Aqua
        Appearance25.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance25.ForeColor = System.Drawing.Color.Black
        Me.cmdAppliesToBill.HotTrackAppearance = Appearance25
        Me.cmdAppliesToBill.Location = New System.Drawing.Point(3, 58)
        Me.cmdAppliesToBill.Name = "cmdAppliesToBill"
        Me.cmdAppliesToBill.ShowFocusRect = False
        Me.cmdAppliesToBill.ShowOutline = False
        Me.cmdAppliesToBill.Size = New System.Drawing.Size(190, 50)
        Me.cmdAppliesToBill.TabIndex = 373
        Me.cmdAppliesToBill.Text = "Applies To Bill"
        Me.cmdAppliesToBill.UseAppStyling = False
        Me.cmdAppliesToBill.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdAppliesToBill.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdAppliesToBill.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdAppliesToItem
        '
        Appearance26.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance26.ForeColor = System.Drawing.Color.DarkGreen
        Me.cmdAppliesToItem.Appearance = Appearance26
        Me.cmdAppliesToItem.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance27.BackColor = System.Drawing.Color.PowderBlue
        Appearance27.BackColor2 = System.Drawing.Color.Aqua
        Appearance27.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance27.ForeColor = System.Drawing.Color.Black
        Me.cmdAppliesToItem.HotTrackAppearance = Appearance27
        Me.cmdAppliesToItem.Location = New System.Drawing.Point(3, 3)
        Me.cmdAppliesToItem.Name = "cmdAppliesToItem"
        Me.cmdAppliesToItem.ShowFocusRect = False
        Me.cmdAppliesToItem.ShowOutline = False
        Me.cmdAppliesToItem.Size = New System.Drawing.Size(190, 50)
        Me.cmdAppliesToItem.TabIndex = 372
        Me.cmdAppliesToItem.Text = "Applies To Item"
        Me.cmdAppliesToItem.UseAppStyling = False
        Me.cmdAppliesToItem.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdAppliesToItem.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdAppliesToItem.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'upnlDiscCharges
        '
        Appearance28.BackColor = System.Drawing.Color.Transparent
        Me.upnlDiscCharges.Appearance = Appearance28
        '
        'upnlDiscCharges.ClientArea
        '
        Me.upnlDiscCharges.ClientArea.Controls.Add(Me.cmdShowCharges)
        Me.upnlDiscCharges.ClientArea.Controls.Add(Me.cmdShowDiscounts)
        Me.upnlDiscCharges.ForeColor = System.Drawing.Color.White
        Me.upnlDiscCharges.Location = New System.Drawing.Point(10, 12)
        Me.upnlDiscCharges.Name = "upnlDiscCharges"
        Me.upnlDiscCharges.Size = New System.Drawing.Size(213, 288)
        Me.upnlDiscCharges.TabIndex = 374
        '
        'cmdShowCharges
        '
        Appearance29.BackColor = System.Drawing.Color.White
        Appearance29.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Appearance29.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance29.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance29.BorderColor = System.Drawing.Color.DarkGray
        Appearance29.BorderColor2 = System.Drawing.Color.Silver
        Appearance29.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance29.ForeColor = System.Drawing.Color.DimGray
        Appearance29.TextVAlignAsString = "Middle"
        Me.cmdShowCharges.Appearance = Appearance29
        Me.cmdShowCharges.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance30.BackColor = System.Drawing.Color.DarkOrange
        Appearance30.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance30.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance30.ForeColor = System.Drawing.Color.Black
        Me.cmdShowCharges.HotTrackAppearance = Appearance30
        Me.cmdShowCharges.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdShowCharges.Location = New System.Drawing.Point(6, 60)
        Me.cmdShowCharges.Name = "cmdShowCharges"
        Appearance31.BackColor = System.Drawing.Color.OrangeRed
        Appearance31.BackColor2 = System.Drawing.Color.Tomato
        Appearance31.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdShowCharges.PressedAppearance = Appearance31
        Me.cmdShowCharges.ShowFocusRect = False
        Me.cmdShowCharges.ShowOutline = False
        Me.cmdShowCharges.Size = New System.Drawing.Size(204, 50)
        Me.cmdShowCharges.TabIndex = 619
        Me.cmdShowCharges.Tag = ""
        Me.cmdShowCharges.Text = "Charges"
        Me.cmdShowCharges.UseAppStyling = False
        Me.cmdShowCharges.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdShowCharges.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdShowCharges.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdShowDiscounts
        '
        Appearance32.BackColor = System.Drawing.Color.White
        Appearance32.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Appearance32.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance32.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance32.BorderColor = System.Drawing.Color.DarkGray
        Appearance32.BorderColor2 = System.Drawing.Color.Silver
        Appearance32.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance32.ForeColor = System.Drawing.Color.DimGray
        Appearance32.TextVAlignAsString = "Middle"
        Me.cmdShowDiscounts.Appearance = Appearance32
        Me.cmdShowDiscounts.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance33.BackColor = System.Drawing.Color.DarkOrange
        Appearance33.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance33.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance33.ForeColor = System.Drawing.Color.Black
        Me.cmdShowDiscounts.HotTrackAppearance = Appearance33
        Me.cmdShowDiscounts.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdShowDiscounts.Location = New System.Drawing.Point(6, 5)
        Me.cmdShowDiscounts.Name = "cmdShowDiscounts"
        Appearance34.BackColor = System.Drawing.Color.OrangeRed
        Appearance34.BackColor2 = System.Drawing.Color.Tomato
        Appearance34.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdShowDiscounts.PressedAppearance = Appearance34
        Me.cmdShowDiscounts.ShowFocusRect = False
        Me.cmdShowDiscounts.ShowOutline = False
        Me.cmdShowDiscounts.Size = New System.Drawing.Size(204, 50)
        Me.cmdShowDiscounts.TabIndex = 616
        Me.cmdShowDiscounts.Tag = ""
        Me.cmdShowDiscounts.Text = "Discounts"
        Me.cmdShowDiscounts.UseAppStyling = False
        Me.cmdShowDiscounts.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdShowDiscounts.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdShowDiscounts.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdOK
        '
        Me.cmdOK.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance35.BackColor = System.Drawing.Color.Transparent
        Appearance35.BackColor2 = System.Drawing.Color.Transparent
        Appearance35.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance35.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance35.BorderColor = System.Drawing.Color.Transparent
        Appearance35.BorderColor2 = System.Drawing.Color.Maroon
        Appearance35.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance35.ForeColor = System.Drawing.Color.White
        Appearance35.Image = CType(resources.GetObject("Appearance35.Image"), Object)
        Appearance35.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance35.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance35.TextVAlignAsString = "Bottom"
        Me.cmdOK.Appearance = Appearance35
        Me.cmdOK.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdOK.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance36.BackColor = System.Drawing.Color.DarkOrange
        Appearance36.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance36.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance36.BorderColor = System.Drawing.Color.Transparent
        Appearance36.ForeColor = System.Drawing.Color.Black
        Me.cmdOK.HotTrackAppearance = Appearance36
        Me.cmdOK.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdOK.Location = New System.Drawing.Point(767, 381)
        Me.cmdOK.Name = "cmdOK"
        Me.cmdOK.Padding = New System.Drawing.Size(15, 0)
        Appearance37.BackColor = System.Drawing.Color.OrangeRed
        Appearance37.BackColor2 = System.Drawing.Color.Tomato
        Appearance37.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance37.BorderColor = System.Drawing.Color.Transparent
        Me.cmdOK.PressedAppearance = Appearance37
        Me.cmdOK.ShowFocusRect = False
        Me.cmdOK.ShowOutline = False
        Me.cmdOK.Size = New System.Drawing.Size(64, 44)
        Me.cmdOK.StyleSetName = "StatusBar"
        Me.cmdOK.TabIndex = 602
        Me.cmdOK.Tag = "Return"
        Me.cmdOK.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOK.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOK.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdCancel
        '
        Me.cmdCancel.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance38.BackColor = System.Drawing.Color.Transparent
        Appearance38.BackColor2 = System.Drawing.Color.Transparent
        Appearance38.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance38.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance38.BorderColor = System.Drawing.Color.Transparent
        Appearance38.BorderColor2 = System.Drawing.Color.Maroon
        Appearance38.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance38.ForeColor = System.Drawing.Color.White
        Appearance38.Image = CType(resources.GetObject("Appearance38.Image"), Object)
        Appearance38.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance38.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance38.TextVAlignAsString = "Bottom"
        Me.cmdCancel.Appearance = Appearance38
        Me.cmdCancel.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdCancel.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance39.BackColor = System.Drawing.Color.DarkOrange
        Appearance39.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance39.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance39.BorderColor = System.Drawing.Color.Transparent
        Appearance39.ForeColor = System.Drawing.Color.Black
        Me.cmdCancel.HotTrackAppearance = Appearance39
        Me.cmdCancel.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdCancel.Location = New System.Drawing.Point(837, 381)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.Padding = New System.Drawing.Size(15, 0)
        Appearance40.BackColor = System.Drawing.Color.OrangeRed
        Appearance40.BackColor2 = System.Drawing.Color.Tomato
        Appearance40.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance40.BorderColor = System.Drawing.Color.Transparent
        Me.cmdCancel.PressedAppearance = Appearance40
        Me.cmdCancel.ShowFocusRect = False
        Me.cmdCancel.ShowOutline = False
        Me.cmdCancel.Size = New System.Drawing.Size(64, 44)
        Me.cmdCancel.StyleSetName = "StatusBar"
        Me.cmdCancel.TabIndex = 601
        Me.cmdCancel.Tag = "Return"
        Me.cmdCancel.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdCancel.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdCancel.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtn7
        '
        Appearance41.BackColor = System.Drawing.Color.White
        Appearance41.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Appearance41.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance41.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance41.BorderColor = System.Drawing.Color.DarkGray
        Appearance41.BorderColor2 = System.Drawing.Color.Silver
        Appearance41.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance41.ForeColor = System.Drawing.Color.DimGray
        Appearance41.TextVAlignAsString = "Middle"
        Me.ubtn7.Appearance = Appearance41
        Me.ubtn7.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance42.BackColor = System.Drawing.Color.DarkOrange
        Appearance42.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance42.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance42.ForeColor = System.Drawing.Color.Black
        Me.ubtn7.HotTrackAppearance = Appearance42
        Me.ubtn7.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtn7.Location = New System.Drawing.Point(5, 5)
        Me.ubtn7.Name = "ubtn7"
        Appearance43.BackColor = System.Drawing.Color.OrangeRed
        Appearance43.BackColor2 = System.Drawing.Color.Tomato
        Appearance43.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtn7.PressedAppearance = Appearance43
        Me.ubtn7.ShowFocusRect = False
        Me.ubtn7.ShowOutline = False
        Me.ubtn7.Size = New System.Drawing.Size(65, 55)
        Me.ubtn7.TabIndex = 604
        Me.ubtn7.Tag = ""
        Me.ubtn7.Text = "7"
        Me.ubtn7.UseAppStyling = False
        Me.ubtn7.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtn7.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtn7.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtn8
        '
        Appearance44.BackColor = System.Drawing.Color.White
        Appearance44.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Appearance44.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance44.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance44.BorderColor = System.Drawing.Color.DarkGray
        Appearance44.BorderColor2 = System.Drawing.Color.Silver
        Appearance44.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance44.ForeColor = System.Drawing.Color.DimGray
        Appearance44.TextVAlignAsString = "Middle"
        Me.ubtn8.Appearance = Appearance44
        Me.ubtn8.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance45.BackColor = System.Drawing.Color.DarkOrange
        Appearance45.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance45.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance45.ForeColor = System.Drawing.Color.Black
        Me.ubtn8.HotTrackAppearance = Appearance45
        Me.ubtn8.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtn8.Location = New System.Drawing.Point(76, 5)
        Me.ubtn8.Name = "ubtn8"
        Appearance46.BackColor = System.Drawing.Color.OrangeRed
        Appearance46.BackColor2 = System.Drawing.Color.Tomato
        Appearance46.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtn8.PressedAppearance = Appearance46
        Me.ubtn8.ShowFocusRect = False
        Me.ubtn8.ShowOutline = False
        Me.ubtn8.Size = New System.Drawing.Size(65, 55)
        Me.ubtn8.TabIndex = 605
        Me.ubtn8.Tag = ""
        Me.ubtn8.Text = "8"
        Me.ubtn8.UseAppStyling = False
        Me.ubtn8.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtn8.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtn8.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnCancel
        '
        Appearance47.BackColor = System.Drawing.Color.White
        Appearance47.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Appearance47.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance47.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance47.BorderColor = System.Drawing.Color.DarkGray
        Appearance47.BorderColor2 = System.Drawing.Color.Silver
        Appearance47.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance47.ForeColor = System.Drawing.Color.DimGray
        Appearance47.TextVAlignAsString = "Middle"
        Me.ubtnCancel.Appearance = Appearance47
        Me.ubtnCancel.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance48.BackColor = System.Drawing.Color.DarkOrange
        Appearance48.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance48.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance48.ForeColor = System.Drawing.Color.Black
        Me.ubtnCancel.HotTrackAppearance = Appearance48
        Me.ubtnCancel.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnCancel.Location = New System.Drawing.Point(5, 188)
        Me.ubtnCancel.Name = "ubtnCancel"
        Appearance49.BackColor = System.Drawing.Color.OrangeRed
        Appearance49.BackColor2 = System.Drawing.Color.Tomato
        Appearance49.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnCancel.PressedAppearance = Appearance49
        Me.ubtnCancel.ShowFocusRect = False
        Me.ubtnCancel.ShowOutline = False
        Me.ubtnCancel.Size = New System.Drawing.Size(65, 55)
        Me.ubtnCancel.TabIndex = 614
        Me.ubtnCancel.Tag = ""
        Me.ubtnCancel.Text = "C"
        Me.ubtnCancel.UseAppStyling = False
        Me.ubtnCancel.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnCancel.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnCancel.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtn9
        '
        Appearance50.BackColor = System.Drawing.Color.White
        Appearance50.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Appearance50.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance50.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance50.BorderColor = System.Drawing.Color.DarkGray
        Appearance50.BorderColor2 = System.Drawing.Color.Silver
        Appearance50.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance50.ForeColor = System.Drawing.Color.DimGray
        Appearance50.TextVAlignAsString = "Middle"
        Me.ubtn9.Appearance = Appearance50
        Me.ubtn9.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance51.BackColor = System.Drawing.Color.DarkOrange
        Appearance51.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance51.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance51.ForeColor = System.Drawing.Color.Black
        Me.ubtn9.HotTrackAppearance = Appearance51
        Me.ubtn9.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtn9.Location = New System.Drawing.Point(147, 5)
        Me.ubtn9.Name = "ubtn9"
        Appearance52.BackColor = System.Drawing.Color.OrangeRed
        Appearance52.BackColor2 = System.Drawing.Color.Tomato
        Appearance52.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtn9.PressedAppearance = Appearance52
        Me.ubtn9.ShowFocusRect = False
        Me.ubtn9.ShowOutline = False
        Me.ubtn9.Size = New System.Drawing.Size(65, 55)
        Me.ubtn9.TabIndex = 606
        Me.ubtn9.Tag = ""
        Me.ubtn9.Text = "9"
        Me.ubtn9.UseAppStyling = False
        Me.ubtn9.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtn9.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtn9.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtn0
        '
        Appearance53.BackColor = System.Drawing.Color.White
        Appearance53.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Appearance53.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance53.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance53.BorderColor = System.Drawing.Color.DarkGray
        Appearance53.BorderColor2 = System.Drawing.Color.Silver
        Appearance53.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance53.ForeColor = System.Drawing.Color.DimGray
        Appearance53.TextVAlignAsString = "Middle"
        Me.ubtn0.Appearance = Appearance53
        Me.ubtn0.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance54.BackColor = System.Drawing.Color.DarkOrange
        Appearance54.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance54.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance54.ForeColor = System.Drawing.Color.Black
        Me.ubtn0.HotTrackAppearance = Appearance54
        Me.ubtn0.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtn0.Location = New System.Drawing.Point(76, 188)
        Me.ubtn0.Name = "ubtn0"
        Appearance55.BackColor = System.Drawing.Color.OrangeRed
        Appearance55.BackColor2 = System.Drawing.Color.Tomato
        Appearance55.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtn0.PressedAppearance = Appearance55
        Me.ubtn0.ShowFocusRect = False
        Me.ubtn0.ShowOutline = False
        Me.ubtn0.Size = New System.Drawing.Size(65, 55)
        Me.ubtn0.TabIndex = 613
        Me.ubtn0.Tag = ""
        Me.ubtn0.Text = "0"
        Me.ubtn0.UseAppStyling = False
        Me.ubtn0.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtn0.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtn0.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtn4
        '
        Appearance56.BackColor = System.Drawing.Color.White
        Appearance56.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Appearance56.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance56.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance56.BorderColor = System.Drawing.Color.DarkGray
        Appearance56.BorderColor2 = System.Drawing.Color.Silver
        Appearance56.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance56.ForeColor = System.Drawing.Color.DimGray
        Appearance56.TextVAlignAsString = "Middle"
        Me.ubtn4.Appearance = Appearance56
        Me.ubtn4.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance57.BackColor = System.Drawing.Color.DarkOrange
        Appearance57.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance57.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance57.ForeColor = System.Drawing.Color.Black
        Me.ubtn4.HotTrackAppearance = Appearance57
        Me.ubtn4.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtn4.Location = New System.Drawing.Point(5, 66)
        Me.ubtn4.Name = "ubtn4"
        Appearance58.BackColor = System.Drawing.Color.OrangeRed
        Appearance58.BackColor2 = System.Drawing.Color.Tomato
        Appearance58.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtn4.PressedAppearance = Appearance58
        Me.ubtn4.ShowFocusRect = False
        Me.ubtn4.ShowOutline = False
        Me.ubtn4.Size = New System.Drawing.Size(65, 55)
        Me.ubtn4.TabIndex = 607
        Me.ubtn4.Tag = ""
        Me.ubtn4.Text = "4"
        Me.ubtn4.UseAppStyling = False
        Me.ubtn4.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtn4.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtn4.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtn3
        '
        Appearance59.BackColor = System.Drawing.Color.White
        Appearance59.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Appearance59.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance59.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance59.BorderColor = System.Drawing.Color.DarkGray
        Appearance59.BorderColor2 = System.Drawing.Color.Silver
        Appearance59.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance59.ForeColor = System.Drawing.Color.DimGray
        Appearance59.TextVAlignAsString = "Middle"
        Me.ubtn3.Appearance = Appearance59
        Me.ubtn3.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance60.BackColor = System.Drawing.Color.DarkOrange
        Appearance60.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance60.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance60.ForeColor = System.Drawing.Color.Black
        Me.ubtn3.HotTrackAppearance = Appearance60
        Me.ubtn3.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtn3.Location = New System.Drawing.Point(147, 127)
        Me.ubtn3.Name = "ubtn3"
        Appearance61.BackColor = System.Drawing.Color.OrangeRed
        Appearance61.BackColor2 = System.Drawing.Color.Tomato
        Appearance61.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtn3.PressedAppearance = Appearance61
        Me.ubtn3.ShowFocusRect = False
        Me.ubtn3.ShowOutline = False
        Me.ubtn3.Size = New System.Drawing.Size(65, 55)
        Me.ubtn3.TabIndex = 612
        Me.ubtn3.Tag = ""
        Me.ubtn3.Text = "3"
        Me.ubtn3.UseAppStyling = False
        Me.ubtn3.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtn3.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtn3.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtn5
        '
        Appearance62.BackColor = System.Drawing.Color.White
        Appearance62.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Appearance62.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance62.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance62.BorderColor = System.Drawing.Color.DarkGray
        Appearance62.BorderColor2 = System.Drawing.Color.Silver
        Appearance62.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance62.ForeColor = System.Drawing.Color.DimGray
        Appearance62.TextVAlignAsString = "Middle"
        Me.ubtn5.Appearance = Appearance62
        Me.ubtn5.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance63.BackColor = System.Drawing.Color.DarkOrange
        Appearance63.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance63.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance63.ForeColor = System.Drawing.Color.Black
        Me.ubtn5.HotTrackAppearance = Appearance63
        Me.ubtn5.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtn5.Location = New System.Drawing.Point(76, 66)
        Me.ubtn5.Name = "ubtn5"
        Appearance64.BackColor = System.Drawing.Color.OrangeRed
        Appearance64.BackColor2 = System.Drawing.Color.Tomato
        Appearance64.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtn5.PressedAppearance = Appearance64
        Me.ubtn5.ShowFocusRect = False
        Me.ubtn5.ShowOutline = False
        Me.ubtn5.Size = New System.Drawing.Size(65, 55)
        Me.ubtn5.TabIndex = 608
        Me.ubtn5.Tag = ""
        Me.ubtn5.Text = "5"
        Me.ubtn5.UseAppStyling = False
        Me.ubtn5.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtn5.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtn5.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtn2
        '
        Appearance65.BackColor = System.Drawing.Color.White
        Appearance65.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Appearance65.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance65.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance65.BorderColor = System.Drawing.Color.DarkGray
        Appearance65.BorderColor2 = System.Drawing.Color.Silver
        Appearance65.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance65.ForeColor = System.Drawing.Color.DimGray
        Appearance65.TextVAlignAsString = "Middle"
        Me.ubtn2.Appearance = Appearance65
        Me.ubtn2.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance66.BackColor = System.Drawing.Color.DarkOrange
        Appearance66.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance66.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance66.ForeColor = System.Drawing.Color.Black
        Me.ubtn2.HotTrackAppearance = Appearance66
        Me.ubtn2.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtn2.Location = New System.Drawing.Point(76, 127)
        Me.ubtn2.Name = "ubtn2"
        Appearance67.BackColor = System.Drawing.Color.OrangeRed
        Appearance67.BackColor2 = System.Drawing.Color.Tomato
        Appearance67.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtn2.PressedAppearance = Appearance67
        Me.ubtn2.ShowFocusRect = False
        Me.ubtn2.ShowOutline = False
        Me.ubtn2.Size = New System.Drawing.Size(65, 55)
        Me.ubtn2.TabIndex = 611
        Me.ubtn2.Tag = ""
        Me.ubtn2.Text = "2"
        Me.ubtn2.UseAppStyling = False
        Me.ubtn2.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtn2.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtn2.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtn6
        '
        Appearance68.BackColor = System.Drawing.Color.White
        Appearance68.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Appearance68.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance68.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance68.BorderColor = System.Drawing.Color.DarkGray
        Appearance68.BorderColor2 = System.Drawing.Color.Silver
        Appearance68.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance68.ForeColor = System.Drawing.Color.DimGray
        Appearance68.TextVAlignAsString = "Middle"
        Me.ubtn6.Appearance = Appearance68
        Me.ubtn6.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance69.BackColor = System.Drawing.Color.DarkOrange
        Appearance69.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance69.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance69.ForeColor = System.Drawing.Color.Black
        Me.ubtn6.HotTrackAppearance = Appearance69
        Me.ubtn6.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtn6.Location = New System.Drawing.Point(147, 66)
        Me.ubtn6.Name = "ubtn6"
        Appearance70.BackColor = System.Drawing.Color.OrangeRed
        Appearance70.BackColor2 = System.Drawing.Color.Tomato
        Appearance70.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtn6.PressedAppearance = Appearance70
        Me.ubtn6.ShowFocusRect = False
        Me.ubtn6.ShowOutline = False
        Me.ubtn6.Size = New System.Drawing.Size(65, 55)
        Me.ubtn6.TabIndex = 609
        Me.ubtn6.Tag = ""
        Me.ubtn6.Text = "6"
        Me.ubtn6.UseAppStyling = False
        Me.ubtn6.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtn6.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtn6.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtn1
        '
        Appearance71.BackColor = System.Drawing.Color.White
        Appearance71.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Appearance71.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance71.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance71.BorderColor = System.Drawing.Color.DarkGray
        Appearance71.BorderColor2 = System.Drawing.Color.Silver
        Appearance71.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance71.ForeColor = System.Drawing.Color.DimGray
        Appearance71.TextVAlignAsString = "Middle"
        Me.ubtn1.Appearance = Appearance71
        Me.ubtn1.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance72.BackColor = System.Drawing.Color.DarkOrange
        Appearance72.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance72.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance72.ForeColor = System.Drawing.Color.Black
        Me.ubtn1.HotTrackAppearance = Appearance72
        Me.ubtn1.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtn1.Location = New System.Drawing.Point(5, 127)
        Me.ubtn1.Name = "ubtn1"
        Appearance73.BackColor = System.Drawing.Color.OrangeRed
        Appearance73.BackColor2 = System.Drawing.Color.Tomato
        Appearance73.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtn1.PressedAppearance = Appearance73
        Me.ubtn1.ShowFocusRect = False
        Me.ubtn1.ShowOutline = False
        Me.ubtn1.Size = New System.Drawing.Size(65, 55)
        Me.ubtn1.TabIndex = 610
        Me.ubtn1.Tag = ""
        Me.ubtn1.Text = "1"
        Me.ubtn1.UseAppStyling = False
        Me.ubtn1.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtn1.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtn1.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnDot
        '
        Appearance74.BackColor = System.Drawing.Color.White
        Appearance74.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Appearance74.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance74.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance74.BorderColor = System.Drawing.Color.DarkGray
        Appearance74.BorderColor2 = System.Drawing.Color.Silver
        Appearance74.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance74.ForeColor = System.Drawing.Color.DimGray
        Appearance74.TextVAlignAsString = "Middle"
        Me.ubtnDot.Appearance = Appearance74
        Me.ubtnDot.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance75.BackColor = System.Drawing.Color.DarkOrange
        Appearance75.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance75.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance75.ForeColor = System.Drawing.Color.Black
        Me.ubtnDot.HotTrackAppearance = Appearance75
        Me.ubtnDot.ImageSize = New System.Drawing.Size(32, 32)
        Me.ubtnDot.Location = New System.Drawing.Point(147, 188)
        Me.ubtnDot.Name = "ubtnDot"
        Appearance76.BackColor = System.Drawing.Color.OrangeRed
        Appearance76.BackColor2 = System.Drawing.Color.Tomato
        Appearance76.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnDot.PressedAppearance = Appearance76
        Me.ubtnDot.ShowFocusRect = False
        Me.ubtnDot.ShowOutline = False
        Me.ubtnDot.Size = New System.Drawing.Size(65, 55)
        Me.ubtnDot.TabIndex = 615
        Me.ubtnDot.Tag = ""
        Me.ubtnDot.Text = "."
        Me.ubtnDot.UseAppStyling = False
        Me.ubtnDot.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnDot.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnDot.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraPanel1
        '
        Me.UltraPanel1.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        '
        'UltraPanel1.ClientArea
        '
        Me.UltraPanel1.ClientArea.Controls.Add(Me.ubtn7)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.ubtn1)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.ubtnDot)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.ubtn6)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.ubtn2)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.ubtn8)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.ubtn5)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.ubtnCancel)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.ubtn3)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.ubtn9)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.ubtn4)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.ubtn0)
        Me.UltraPanel1.ForeColor = System.Drawing.Color.White
        Me.UltraPanel1.Location = New System.Drawing.Point(451, 61)
        Me.UltraPanel1.Name = "UltraPanel1"
        Me.UltraPanel1.Size = New System.Drawing.Size(220, 252)
        Me.UltraPanel1.TabIndex = 617
        '
        'lblEntryBox
        '
        Appearance77.BorderColor = System.Drawing.Color.Silver
        Appearance77.ForeColor = System.Drawing.Color.DimGray
        Appearance77.TextHAlignAsString = "Right"
        Me.lblEntryBox.Appearance = Appearance77
        Me.lblEntryBox.BorderStyleInner = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.lblEntryBox.BorderStyleOuter = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.lblEntryBox.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEntryBox.Location = New System.Drawing.Point(451, 19)
        Me.lblEntryBox.Name = "lblEntryBox"
        Me.lblEntryBox.Size = New System.Drawing.Size(220, 36)
        Me.lblEntryBox.TabIndex = 618
        Me.lblEntryBox.UseAppStyling = False
        '
        'UltraPanel2
        '
        Me.UltraPanel2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance78.BackColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        Me.UltraPanel2.Appearance = Appearance78
        Me.UltraPanel2.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded4
        '
        'UltraPanel2.ClientArea
        '
        Me.UltraPanel2.ClientArea.Controls.Add(Me.upnlDiscCharges)
        Me.UltraPanel2.ClientArea.Controls.Add(Me.cmdOK)
        Me.UltraPanel2.ClientArea.Controls.Add(Me.lblEntryBox)
        Me.UltraPanel2.ClientArea.Controls.Add(Me.cmdCancel)
        Me.UltraPanel2.ClientArea.Controls.Add(Me.upnlDiscChargeOptions)
        Me.UltraPanel2.ClientArea.Controls.Add(Me.UltraPanel1)
        Me.UltraPanel2.ClientArea.Controls.Add(Me.upnlPercPounds)
        Me.UltraPanel2.ClientArea.Controls.Add(Me.upnlAppliesTo)
        Me.UltraPanel2.ForeColor = System.Drawing.Color.White
        Me.UltraPanel2.Location = New System.Drawing.Point(12, 12)
        Me.UltraPanel2.Name = "UltraPanel2"
        Me.UltraPanel2.Size = New System.Drawing.Size(906, 430)
        Me.UltraPanel2.TabIndex = 619
        '
        'UltraFlowLayoutManager2
        '
        Me.UltraFlowLayoutManager2.ContainerControl = Me.upnlDiscChargeOptions.ClientArea
        '
        'frmDiscounts
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(930, 454)
        Me.ControlBox = False
        Me.Controls.Add(Me.UltraPanel2)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmDiscounts"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.upnlDiscChargeOptions.ClientArea.ResumeLayout(False)
        Me.upnlDiscChargeOptions.ResumeLayout(False)
        Me.upnlPercPounds.ClientArea.ResumeLayout(False)
        Me.upnlPercPounds.ResumeLayout(False)
        Me.upnlAppliesTo.ClientArea.ResumeLayout(False)
        Me.upnlAppliesTo.ResumeLayout(False)
        Me.upnlDiscCharges.ClientArea.ResumeLayout(False)
        Me.upnlDiscCharges.ResumeLayout(False)
        Me.UltraPanel1.ClientArea.ResumeLayout(False)
        Me.UltraPanel1.ResumeLayout(False)
        Me.UltraPanel2.ClientArea.ResumeLayout(False)
        Me.UltraPanel2.ResumeLayout(False)
        CType(Me.UltraFlowLayoutManager2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents cmdPercentage As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdAmount As Infragistics.Win.Misc.UltraButton
    Friend WithEvents upnlDiscChargeOptions As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents upnlPercPounds As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents upnlAppliesTo As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents upnlDiscCharges As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents ubtnDC1 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnDC2 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnDC3 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnDC4 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnDC5 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnDCNone As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnDCToggleGlobal As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdOK As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdCancel As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtn7 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtn8 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnCancel As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtn9 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtn0 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtn4 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtn3 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtn5 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtn2 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtn6 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtn1 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnDot As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraPanel1 As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents lblEntryBox As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents cmdShowCharges As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdShowDiscounts As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraPanel2 As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents UltraFlowLayoutManager2 As Infragistics.Win.Misc.UltraFlowLayoutManager
    Friend WithEvents cmdAppliesToBill As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdAppliesToItem As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdAppliesToMealDrinks As Infragistics.Win.Misc.UltraButton
End Class
