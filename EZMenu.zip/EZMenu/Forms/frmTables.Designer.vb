﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmTables
	Inherits System.Windows.Forms.Form

	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		Try
			If disposing AndAlso components IsNot Nothing Then
				components.Dispose()
			End If
		Finally
			MyBase.Dispose(disposing)
		End Try
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim Appearance1 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmTables))
        Dim Appearance2 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance3 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance4 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance5 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance6 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance7 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance8 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance9 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance10 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance11 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance12 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance13 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance14 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance15 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance16 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance17 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance18 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance19 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance20 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance21 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance22 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance23 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance24 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance25 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance26 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance27 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance28 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance29 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance30 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance31 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance32 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance33 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance34 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance35 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance36 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance37 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance38 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraGridBand1 As Infragistics.Win.UltraWinGrid.UltraGridBand = New Infragistics.Win.UltraWinGrid.UltraGridBand("Band 0", -1)
        Dim UltraGridColumn1 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("DkName", 0)
        Dim UltraGridColumn2 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("DkPrice", 1)
        Dim UltraGridColumn3 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("DkQty", 2)
        Dim Appearance39 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraGridColumn4 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("DkTotal", 3)
        Dim Appearance40 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance41 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance42 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance43 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance44 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance45 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance46 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance47 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance48 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance49 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance50 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance51 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance52 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance53 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance54 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance55 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance56 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance57 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance58 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance59 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance60 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance61 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance62 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance63 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance64 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance65 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance66 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance67 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance68 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance69 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance70 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance71 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance72 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance73 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance74 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraGridBand2 As Infragistics.Win.UltraWinGrid.UltraGridBand = New Infragistics.Win.UltraWinGrid.UltraGridBand("Band 0", -1)
        Dim UltraGridColumn5 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Code", 0)
        Dim UltraGridColumn6 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Dish", 1)
        Dim UltraGridColumn7 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Price", 2)
        Dim Appearance75 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraGridColumn8 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Qty", 3)
        Dim Appearance76 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraGridColumn9 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Total", 4)
        Dim Appearance77 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraGridColumn10 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Notes", 5)
        Dim UltraGridColumn11 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("IsStarter", 6)
        Dim UltraGridColumn12 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("OriPrice", 7)
        Dim UltraGridColumn13 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("PriceIn", 8)
        Dim UltraGridColumn14 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("GroupIndex", 9)
        Dim UltraGridColumn15 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Mods", 10)
        Dim UltraGridColumn16 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Discountable", 11)
        Dim Appearance78 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance79 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance80 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance81 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance82 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance83 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance84 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance85 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance86 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance87 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance88 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance89 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance90 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance91 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance92 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance93 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance94 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance95 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance96 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance97 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance98 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance99 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance100 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance101 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance102 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance103 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance104 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance105 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance106 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance107 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance108 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance109 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance110 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance111 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance112 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance113 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance114 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance115 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance116 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance117 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance118 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance119 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance120 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance121 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance122 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance123 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance124 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance125 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance126 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance127 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance128 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance129 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance130 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance131 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance132 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance133 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance134 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance135 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance136 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Me.upnlTableDrinks = New Infragistics.Win.Misc.UltraPanel()
        Me.cmdDkNext = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDkPrevious = New Infragistics.Win.Misc.UltraButton()
        Me.cmdPrintDrinks = New Infragistics.Win.Misc.UltraButton()
        Me.cmdAddMiscDrink = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDkClearAll = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDkDelete = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDkDeduct = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDkAdd = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDkDown = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDkUp = New Infragistics.Win.Misc.UltraButton()
        Me.UltraLabel5 = New Infragistics.Win.Misc.UltraLabel()
        Me.lblDrinksTotal = New Infragistics.Win.Misc.UltraLabel()
        Me.lblDrinksHeader = New Infragistics.Win.Misc.UltraLabel()
        Me.cmdDkClose = New Infragistics.Win.Misc.UltraButton()
        Me.ugdDrinksGrid = New Infragistics.Win.UltraWinGrid.UltraGrid()
        Me.udsDrinks = New Infragistics.Win.UltraWinDataSource.UltraDataSource(Me.components)
        Me.upnlTableBill = New Infragistics.Win.Misc.UltraPanel()
        Me.cmdLightsStatus = New Infragistics.Win.Misc.UltraButton()
        Me.upnlMiniTables = New Infragistics.Win.Misc.UltraPanel()
        Me.lblMiniHilit = New Infragistics.Win.Misc.UltraLabel()
        Me.cmdCAP = New Infragistics.Win.Misc.UltraButton()
        Me.cmdMoveTable = New Infragistics.Win.Misc.UltraButton()
        Me.lblTipsLabel = New Infragistics.Win.Misc.UltraLabel()
        Me.cmdTableDiscounts = New Infragistics.Win.Misc.UltraButton()
        Me.UltraLabel6 = New Infragistics.Win.Misc.UltraLabel()
        Me.lblCovers = New Infragistics.Win.Misc.UltraLabel()
        Me.cmdCovers = New Infragistics.Win.Misc.UltraButton()
        Me.ugdTableGrid = New Infragistics.Win.UltraWinGrid.UltraGrid()
        Me.udsTableGrid = New Infragistics.Win.UltraWinDataSource.UltraDataSource(Me.components)
        Me.lblBillHeader = New Infragistics.Win.Misc.UltraLabel()
        Me.lblCharges = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel2 = New Infragistics.Win.Misc.UltraLabel()
        Me.lblDiscounts = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel4 = New Infragistics.Win.Misc.UltraLabel()
        Me.cmdTablePayment = New Infragistics.Win.Misc.UltraButton()
        Me.cmdTableKNote = New Infragistics.Win.Misc.UltraButton()
        Me.cmdTableKCopy = New Infragistics.Win.Misc.UltraButton()
        Me.cmdTableClear = New Infragistics.Win.Misc.UltraButton()
        Me.cmdTableTables = New Infragistics.Win.Misc.UltraButton()
        Me.cmdTableDrinks = New Infragistics.Win.Misc.UltraButton()
        Me.cmdTablePrint = New Infragistics.Win.Misc.UltraButton()
        Me.cmdTableEdit = New Infragistics.Win.Misc.UltraButton()
        Me.cmdTableClose = New Infragistics.Win.Misc.UltraButton()
        Me.cmdTableDiscard = New Infragistics.Win.Misc.UltraButton()
        Me.lblTTips = New Infragistics.Win.Misc.UltraLabel()
        Me.lblTDrinks = New Infragistics.Win.Misc.UltraLabel()
        Me.lblTCharges = New Infragistics.Win.Misc.UltraLabel()
        Me.lblBillTotal = New Infragistics.Win.Misc.UltraLabel()
        Me.lblTDiscount = New Infragistics.Win.Misc.UltraLabel()
        Me.lblTSubtotal = New Infragistics.Win.Misc.UltraLabel()
        Me.lblEntryTime = New Infragistics.Win.Misc.UltraLabel()
        Me.EZMenuDataSet = New EZMenu.EZMenuDataSet()
        Me.DrinksBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DrinksTableAdapter = New EZMenu.EZMenuDataSetTableAdapters.DrinksTableAdapter()
        Me.TableAdapterManager = New EZMenu.EZMenuDataSetTableAdapters.TableAdapterManager()
        Me.upnlTables = New Infragistics.Win.Misc.UltraPanel()
        Me.UltraLabel1 = New Infragistics.Win.Misc.UltraLabel()
        Me.cmdCloseTable = New Infragistics.Win.Misc.UltraButton()
        Me.lblStatusBar = New Infragistics.Win.Misc.UltraLabel()
        Me.upnlTableDrinks.ClientArea.SuspendLayout()
        Me.upnlTableDrinks.SuspendLayout()
        CType(Me.ugdDrinksGrid, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.udsDrinks, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.upnlTableBill.ClientArea.SuspendLayout()
        Me.upnlTableBill.SuspendLayout()
        Me.upnlMiniTables.ClientArea.SuspendLayout()
        Me.upnlMiniTables.SuspendLayout()
        CType(Me.ugdTableGrid, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.udsTableGrid, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EZMenuDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DrinksBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.upnlTables.ClientArea.SuspendLayout()
        Me.upnlTables.SuspendLayout()
        Me.SuspendLayout()
        '
        'upnlTableDrinks
        '
        Appearance1.ImageBackground = CType(resources.GetObject("Appearance1.ImageBackground"), System.Drawing.Image)
        Me.upnlTableDrinks.Appearance = Appearance1
        '
        'upnlTableDrinks.ClientArea
        '
        Me.upnlTableDrinks.ClientArea.Controls.Add(Me.cmdDkNext)
        Me.upnlTableDrinks.ClientArea.Controls.Add(Me.cmdDkPrevious)
        Me.upnlTableDrinks.ClientArea.Controls.Add(Me.cmdPrintDrinks)
        Me.upnlTableDrinks.ClientArea.Controls.Add(Me.cmdAddMiscDrink)
        Me.upnlTableDrinks.ClientArea.Controls.Add(Me.cmdDkClearAll)
        Me.upnlTableDrinks.ClientArea.Controls.Add(Me.cmdDkDelete)
        Me.upnlTableDrinks.ClientArea.Controls.Add(Me.cmdDkDeduct)
        Me.upnlTableDrinks.ClientArea.Controls.Add(Me.cmdDkAdd)
        Me.upnlTableDrinks.ClientArea.Controls.Add(Me.cmdDkDown)
        Me.upnlTableDrinks.ClientArea.Controls.Add(Me.cmdDkUp)
        Me.upnlTableDrinks.ClientArea.Controls.Add(Me.UltraLabel5)
        Me.upnlTableDrinks.ClientArea.Controls.Add(Me.lblDrinksTotal)
        Me.upnlTableDrinks.ClientArea.Controls.Add(Me.lblDrinksHeader)
        Me.upnlTableDrinks.ClientArea.Controls.Add(Me.cmdDkClose)
        Me.upnlTableDrinks.ClientArea.Controls.Add(Me.ugdDrinksGrid)
        Me.upnlTableDrinks.Location = New System.Drawing.Point(0, 0)
        Me.upnlTableDrinks.Name = "upnlTableDrinks"
        Me.upnlTableDrinks.Size = New System.Drawing.Size(1000, 730)
        Me.upnlTableDrinks.TabIndex = 117
        Me.upnlTableDrinks.Tag = "2.45"
        '
        'cmdDkNext
        '
        Appearance2.BackColor = System.Drawing.Color.Transparent
        Appearance2.BackColor2 = System.Drawing.Color.Transparent
        Appearance2.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance2.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance2.BorderColor = System.Drawing.Color.Transparent
        Appearance2.BorderColor2 = System.Drawing.Color.Maroon
        Appearance2.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance2.ForeColor = System.Drawing.Color.Black
        Appearance2.Image = CType(resources.GetObject("Appearance2.Image"), Object)
        Appearance2.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance2.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance2.TextVAlignAsString = "Bottom"
        Me.cmdDkNext.Appearance = Appearance2
        Me.cmdDkNext.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance3.BackColor = System.Drawing.Color.DarkOrange
        Appearance3.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance3.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance3.BorderColor = System.Drawing.Color.Transparent
        Appearance3.ForeColor = System.Drawing.Color.Black
        Me.cmdDkNext.HotTrackAppearance = Appearance3
        Me.cmdDkNext.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdDkNext.Location = New System.Drawing.Point(558, 689)
        Me.cmdDkNext.Name = "cmdDkNext"
        Appearance4.BackColor = System.Drawing.Color.OrangeRed
        Appearance4.BackColor2 = System.Drawing.Color.Tomato
        Appearance4.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance4.BorderColor = System.Drawing.Color.Transparent
        Me.cmdDkNext.PressedAppearance = Appearance4
        Me.cmdDkNext.ShowFocusRect = False
        Me.cmdDkNext.ShowOutline = False
        Me.cmdDkNext.Size = New System.Drawing.Size(70, 39)
        Me.cmdDkNext.TabIndex = 454
        Me.cmdDkNext.Tag = "Down"
        Me.cmdDkNext.UseAppStyling = False
        Me.cmdDkNext.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDkNext.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDkNext.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDkPrevious
        '
        Appearance5.BackColor = System.Drawing.Color.Transparent
        Appearance5.BackColor2 = System.Drawing.Color.Transparent
        Appearance5.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance5.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance5.BorderColor = System.Drawing.Color.Transparent
        Appearance5.BorderColor2 = System.Drawing.Color.Maroon
        Appearance5.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance5.ForeColor = System.Drawing.Color.Black
        Appearance5.Image = CType(resources.GetObject("Appearance5.Image"), Object)
        Appearance5.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance5.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance5.TextVAlignAsString = "Bottom"
        Me.cmdDkPrevious.Appearance = Appearance5
        Me.cmdDkPrevious.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance6.BackColor = System.Drawing.Color.DarkOrange
        Appearance6.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance6.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance6.ForeColor = System.Drawing.Color.Black
        Me.cmdDkPrevious.HotTrackAppearance = Appearance6
        Me.cmdDkPrevious.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdDkPrevious.Location = New System.Drawing.Point(13, 689)
        Me.cmdDkPrevious.Name = "cmdDkPrevious"
        Appearance7.BackColor = System.Drawing.Color.OrangeRed
        Appearance7.BackColor2 = System.Drawing.Color.Tomato
        Appearance7.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdDkPrevious.PressedAppearance = Appearance7
        Me.cmdDkPrevious.ShowFocusRect = False
        Me.cmdDkPrevious.ShowOutline = False
        Me.cmdDkPrevious.Size = New System.Drawing.Size(70, 39)
        Me.cmdDkPrevious.TabIndex = 453
        Me.cmdDkPrevious.Tag = "Up"
        Me.cmdDkPrevious.UseAppStyling = False
        Me.cmdDkPrevious.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDkPrevious.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDkPrevious.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdPrintDrinks
        '
        Appearance8.BackColor = System.Drawing.Color.Transparent
        Appearance8.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance8.ForeColor = System.Drawing.Color.Black
        Appearance8.Image = CType(resources.GetObject("Appearance8.Image"), Object)
        Appearance8.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance8.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance8.TextVAlignAsString = "Bottom"
        Me.cmdPrintDrinks.Appearance = Appearance8
        Me.cmdPrintDrinks.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdPrintDrinks.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance9.BackColor = System.Drawing.Color.DarkOrange
        Appearance9.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance9.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance9.BorderColor = System.Drawing.Color.Transparent
        Appearance9.ForeColor = System.Drawing.Color.Black
        Me.cmdPrintDrinks.HotTrackAppearance = Appearance9
        Me.cmdPrintDrinks.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdPrintDrinks.Location = New System.Drawing.Point(947, 543)
        Me.cmdPrintDrinks.Name = "cmdPrintDrinks"
        Appearance10.BackColor = System.Drawing.Color.OrangeRed
        Appearance10.BackColor2 = System.Drawing.Color.Tomato
        Appearance10.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance10.BorderColor = System.Drawing.Color.Transparent
        Me.cmdPrintDrinks.PressedAppearance = Appearance10
        Me.cmdPrintDrinks.ShowFocusRect = False
        Me.cmdPrintDrinks.ShowOutline = False
        Me.cmdPrintDrinks.Size = New System.Drawing.Size(46, 40)
        Me.cmdPrintDrinks.TabIndex = 452
        Me.cmdPrintDrinks.Tag = "x"
        Me.cmdPrintDrinks.UseAppStyling = False
        Me.cmdPrintDrinks.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPrintDrinks.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPrintDrinks.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdAddMiscDrink
        '
        Appearance11.BackColor = System.Drawing.Color.Transparent
        Appearance11.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance11.ForeColor = System.Drawing.Color.Black
        Appearance11.Image = CType(resources.GetObject("Appearance11.Image"), Object)
        Appearance11.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance11.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance11.TextVAlignAsString = "Bottom"
        Me.cmdAddMiscDrink.Appearance = Appearance11
        Me.cmdAddMiscDrink.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdAddMiscDrink.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance12.BackColor = System.Drawing.Color.DarkOrange
        Appearance12.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance12.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance12.BorderColor = System.Drawing.Color.Transparent
        Appearance12.ForeColor = System.Drawing.Color.Black
        Me.cmdAddMiscDrink.HotTrackAppearance = Appearance12
        Me.cmdAddMiscDrink.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdAddMiscDrink.Location = New System.Drawing.Point(947, 411)
        Me.cmdAddMiscDrink.Name = "cmdAddMiscDrink"
        Appearance13.BackColor = System.Drawing.Color.OrangeRed
        Appearance13.BackColor2 = System.Drawing.Color.Tomato
        Appearance13.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance13.BorderColor = System.Drawing.Color.Transparent
        Me.cmdAddMiscDrink.PressedAppearance = Appearance13
        Me.cmdAddMiscDrink.ShowFocusRect = False
        Me.cmdAddMiscDrink.ShowOutline = False
        Me.cmdAddMiscDrink.Size = New System.Drawing.Size(46, 40)
        Me.cmdAddMiscDrink.TabIndex = 451
        Me.cmdAddMiscDrink.Tag = "x"
        Me.cmdAddMiscDrink.UseAppStyling = False
        Me.cmdAddMiscDrink.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdAddMiscDrink.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdAddMiscDrink.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDkClearAll
        '
        Appearance14.BackColor = System.Drawing.Color.Transparent
        Appearance14.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance14.ForeColor = System.Drawing.Color.Black
        Appearance14.Image = CType(resources.GetObject("Appearance14.Image"), Object)
        Appearance14.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance14.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance14.TextVAlignAsString = "Bottom"
        Me.cmdDkClearAll.Appearance = Appearance14
        Me.cmdDkClearAll.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdDkClearAll.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance15.BackColor = System.Drawing.Color.DarkOrange
        Appearance15.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance15.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance15.BorderColor = System.Drawing.Color.Transparent
        Appearance15.ForeColor = System.Drawing.Color.Black
        Me.cmdDkClearAll.HotTrackAppearance = Appearance15
        Me.cmdDkClearAll.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdDkClearAll.Location = New System.Drawing.Point(947, 477)
        Me.cmdDkClearAll.Name = "cmdDkClearAll"
        Appearance16.BackColor = System.Drawing.Color.OrangeRed
        Appearance16.BackColor2 = System.Drawing.Color.Tomato
        Appearance16.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance16.BorderColor = System.Drawing.Color.Transparent
        Me.cmdDkClearAll.PressedAppearance = Appearance16
        Me.cmdDkClearAll.ShowFocusRect = False
        Me.cmdDkClearAll.ShowOutline = False
        Me.cmdDkClearAll.Size = New System.Drawing.Size(46, 40)
        Me.cmdDkClearAll.TabIndex = 450
        Me.cmdDkClearAll.Tag = "x"
        Me.cmdDkClearAll.UseAppStyling = False
        Me.cmdDkClearAll.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDkClearAll.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDkClearAll.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDkDelete
        '
        Appearance17.BackColor = System.Drawing.Color.Transparent
        Appearance17.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance17.ForeColor = System.Drawing.Color.Black
        Appearance17.Image = CType(resources.GetObject("Appearance17.Image"), Object)
        Appearance17.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance17.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance17.TextVAlignAsString = "Bottom"
        Me.cmdDkDelete.Appearance = Appearance17
        Me.cmdDkDelete.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdDkDelete.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance18.BackColor = System.Drawing.Color.DarkOrange
        Appearance18.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance18.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance18.BorderColor = System.Drawing.Color.Transparent
        Appearance18.ForeColor = System.Drawing.Color.Black
        Me.cmdDkDelete.HotTrackAppearance = Appearance18
        Me.cmdDkDelete.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdDkDelete.Location = New System.Drawing.Point(947, 345)
        Me.cmdDkDelete.Name = "cmdDkDelete"
        Appearance19.BackColor = System.Drawing.Color.OrangeRed
        Appearance19.BackColor2 = System.Drawing.Color.Tomato
        Appearance19.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance19.BorderColor = System.Drawing.Color.Transparent
        Me.cmdDkDelete.PressedAppearance = Appearance19
        Me.cmdDkDelete.ShowFocusRect = False
        Me.cmdDkDelete.ShowOutline = False
        Me.cmdDkDelete.Size = New System.Drawing.Size(46, 40)
        Me.cmdDkDelete.TabIndex = 447
        Me.cmdDkDelete.Tag = "x"
        Me.cmdDkDelete.UseAppStyling = False
        Me.cmdDkDelete.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDkDelete.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDkDelete.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDkDeduct
        '
        Appearance20.BackColor = System.Drawing.Color.Transparent
        Appearance20.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance20.ForeColor = System.Drawing.Color.Black
        Appearance20.Image = CType(resources.GetObject("Appearance20.Image"), Object)
        Appearance20.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance20.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance20.TextVAlignAsString = "Bottom"
        Me.cmdDkDeduct.Appearance = Appearance20
        Me.cmdDkDeduct.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdDkDeduct.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance21.BackColor = System.Drawing.Color.DarkOrange
        Appearance21.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance21.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance21.BorderColor = System.Drawing.Color.Transparent
        Appearance21.ForeColor = System.Drawing.Color.Black
        Me.cmdDkDeduct.HotTrackAppearance = Appearance21
        Me.cmdDkDeduct.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdDkDeduct.Location = New System.Drawing.Point(947, 279)
        Me.cmdDkDeduct.Name = "cmdDkDeduct"
        Appearance22.BackColor = System.Drawing.Color.OrangeRed
        Appearance22.BackColor2 = System.Drawing.Color.Tomato
        Appearance22.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance22.BorderColor = System.Drawing.Color.Transparent
        Me.cmdDkDeduct.PressedAppearance = Appearance22
        Me.cmdDkDeduct.ShowFocusRect = False
        Me.cmdDkDeduct.ShowOutline = False
        Me.cmdDkDeduct.Size = New System.Drawing.Size(46, 40)
        Me.cmdDkDeduct.TabIndex = 446
        Me.cmdDkDeduct.Tag = "-"
        Me.cmdDkDeduct.UseAppStyling = False
        Me.cmdDkDeduct.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDkDeduct.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDkDeduct.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDkAdd
        '
        Appearance23.BackColor = System.Drawing.Color.Transparent
        Appearance23.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance23.ForeColor = System.Drawing.Color.Black
        Appearance23.Image = CType(resources.GetObject("Appearance23.Image"), Object)
        Appearance23.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance23.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance23.TextVAlignAsString = "Bottom"
        Me.cmdDkAdd.Appearance = Appearance23
        Me.cmdDkAdd.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdDkAdd.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance24.BackColor = System.Drawing.Color.DarkOrange
        Appearance24.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance24.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance24.BorderColor = System.Drawing.Color.Transparent
        Appearance24.ForeColor = System.Drawing.Color.Black
        Me.cmdDkAdd.HotTrackAppearance = Appearance24
        Me.cmdDkAdd.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdDkAdd.Location = New System.Drawing.Point(947, 213)
        Me.cmdDkAdd.Name = "cmdDkAdd"
        Appearance25.BackColor = System.Drawing.Color.OrangeRed
        Appearance25.BackColor2 = System.Drawing.Color.Tomato
        Appearance25.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance25.BorderColor = System.Drawing.Color.Transparent
        Me.cmdDkAdd.PressedAppearance = Appearance25
        Me.cmdDkAdd.ShowFocusRect = False
        Me.cmdDkAdd.ShowOutline = False
        Me.cmdDkAdd.Size = New System.Drawing.Size(46, 40)
        Me.cmdDkAdd.TabIndex = 445
        Me.cmdDkAdd.Tag = "+"
        Me.cmdDkAdd.UseAppStyling = False
        Me.cmdDkAdd.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDkAdd.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDkAdd.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDkDown
        '
        Appearance26.BackColor = System.Drawing.Color.Transparent
        Appearance26.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance26.ForeColor = System.Drawing.Color.Black
        Appearance26.Image = CType(resources.GetObject("Appearance26.Image"), Object)
        Appearance26.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance26.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance26.TextVAlignAsString = "Bottom"
        Me.cmdDkDown.Appearance = Appearance26
        Me.cmdDkDown.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdDkDown.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance27.BackColor = System.Drawing.Color.DarkOrange
        Appearance27.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance27.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance27.BorderColor = System.Drawing.Color.Transparent
        Appearance27.ForeColor = System.Drawing.Color.Black
        Me.cmdDkDown.HotTrackAppearance = Appearance27
        Me.cmdDkDown.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdDkDown.Location = New System.Drawing.Point(947, 147)
        Me.cmdDkDown.Name = "cmdDkDown"
        Appearance28.BackColor = System.Drawing.Color.OrangeRed
        Appearance28.BackColor2 = System.Drawing.Color.Tomato
        Appearance28.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance28.BorderColor = System.Drawing.Color.Transparent
        Me.cmdDkDown.PressedAppearance = Appearance28
        Me.cmdDkDown.ShowFocusRect = False
        Me.cmdDkDown.ShowOutline = False
        Me.cmdDkDown.Size = New System.Drawing.Size(46, 40)
        Me.cmdDkDown.TabIndex = 444
        Me.cmdDkDown.Tag = "Down"
        Me.cmdDkDown.UseAppStyling = False
        Me.cmdDkDown.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDkDown.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDkDown.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDkUp
        '
        Appearance29.BackColor = System.Drawing.Color.Transparent
        Appearance29.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance29.ForeColor = System.Drawing.Color.Black
        Appearance29.Image = CType(resources.GetObject("Appearance29.Image"), Object)
        Appearance29.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance29.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance29.TextVAlignAsString = "Bottom"
        Me.cmdDkUp.Appearance = Appearance29
        Me.cmdDkUp.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdDkUp.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance30.BackColor = System.Drawing.Color.DarkOrange
        Appearance30.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance30.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance30.BorderColor = System.Drawing.Color.Transparent
        Appearance30.ForeColor = System.Drawing.Color.Black
        Me.cmdDkUp.HotTrackAppearance = Appearance30
        Me.cmdDkUp.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdDkUp.Location = New System.Drawing.Point(947, 81)
        Me.cmdDkUp.Name = "cmdDkUp"
        Appearance31.BackColor = System.Drawing.Color.OrangeRed
        Appearance31.BackColor2 = System.Drawing.Color.Tomato
        Appearance31.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance31.BorderColor = System.Drawing.Color.Transparent
        Me.cmdDkUp.PressedAppearance = Appearance31
        Me.cmdDkUp.ShowFocusRect = False
        Me.cmdDkUp.ShowOutline = False
        Me.cmdDkUp.Size = New System.Drawing.Size(46, 40)
        Me.cmdDkUp.TabIndex = 443
        Me.cmdDkUp.Tag = "Up"
        Me.cmdDkUp.UseAppStyling = False
        Me.cmdDkUp.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDkUp.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDkUp.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraLabel5
        '
        Appearance32.BackColor = System.Drawing.Color.Transparent
        Appearance32.ForeColor = System.Drawing.Color.FromArgb(CType(CType(10, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(130, Byte), Integer))
        Appearance32.TextHAlignAsString = "Right"
        Me.UltraLabel5.Appearance = Appearance32
        Me.UltraLabel5.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UltraLabel5.Location = New System.Drawing.Point(687, 620)
        Me.UltraLabel5.Name = "UltraLabel5"
        Me.UltraLabel5.Size = New System.Drawing.Size(100, 20)
        Me.UltraLabel5.TabIndex = 378
        Me.UltraLabel5.Text = "Total:"
        Me.UltraLabel5.UseAppStyling = False
        '
        'lblDrinksTotal
        '
        Appearance33.BackColor = System.Drawing.Color.Transparent
        Appearance33.ForeColor = System.Drawing.Color.FromArgb(CType(CType(10, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(130, Byte), Integer))
        Appearance33.TextHAlignAsString = "Center"
        Me.lblDrinksTotal.Appearance = Appearance33
        Me.lblDrinksTotal.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDrinksTotal.Location = New System.Drawing.Point(781, 620)
        Me.lblDrinksTotal.Name = "lblDrinksTotal"
        Me.lblDrinksTotal.Size = New System.Drawing.Size(80, 20)
        Me.lblDrinksTotal.TabIndex = 377
        Me.lblDrinksTotal.Text = "0.00"
        Me.lblDrinksTotal.UseAppStyling = False
        '
        'lblDrinksHeader
        '
        Appearance34.BackColor = System.Drawing.Color.Transparent
        Appearance34.ForeColor = System.Drawing.Color.FromArgb(CType(CType(216, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(236, Byte), Integer))
        Appearance34.TextHAlignAsString = "Center"
        Appearance34.TextVAlignAsString = "Middle"
        Me.lblDrinksHeader.Appearance = Appearance34
        Me.lblDrinksHeader.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDrinksHeader.Location = New System.Drawing.Point(653, 70)
        Me.lblDrinksHeader.Name = "lblDrinksHeader"
        Me.lblDrinksHeader.Size = New System.Drawing.Size(276, 26)
        Me.lblDrinksHeader.TabIndex = 374
        Me.lblDrinksHeader.Text = "Table X"
        Me.lblDrinksHeader.UseAppStyling = False
        '
        'cmdDkClose
        '
        Appearance35.BackColor = System.Drawing.Color.Transparent
        Appearance35.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance35.ForeColor = System.Drawing.Color.Black
        Appearance35.Image = CType(resources.GetObject("Appearance35.Image"), Object)
        Appearance35.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance35.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance35.TextVAlignAsString = "Bottom"
        Me.cmdDkClose.Appearance = Appearance35
        Me.cmdDkClose.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdDkClose.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance36.BackColor = System.Drawing.Color.DarkOrange
        Appearance36.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance36.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance36.BorderColor = System.Drawing.Color.Transparent
        Appearance36.ForeColor = System.Drawing.Color.Black
        Me.cmdDkClose.HotTrackAppearance = Appearance36
        Me.cmdDkClose.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdDkClose.Location = New System.Drawing.Point(947, 609)
        Me.cmdDkClose.Name = "cmdDkClose"
        Appearance37.BackColor = System.Drawing.Color.OrangeRed
        Appearance37.BackColor2 = System.Drawing.Color.Tomato
        Appearance37.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance37.BorderColor = System.Drawing.Color.Transparent
        Me.cmdDkClose.PressedAppearance = Appearance37
        Me.cmdDkClose.ShowFocusRect = False
        Me.cmdDkClose.ShowOutline = False
        Me.cmdDkClose.Size = New System.Drawing.Size(46, 40)
        Me.cmdDkClose.TabIndex = 359
        Me.cmdDkClose.Tag = "Return"
        Me.cmdDkClose.UseAppStyling = False
        Me.cmdDkClose.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDkClose.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDkClose.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ugdDrinksGrid
        '
        Me.ugdDrinksGrid.DataSource = Me.udsDrinks
        Appearance38.BackColor = System.Drawing.Color.Transparent
        Appearance38.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Me.ugdDrinksGrid.DisplayLayout.Appearance = Appearance38
        UltraGridColumn1.AutoCompleteMode = Infragistics.Win.AutoCompleteMode.Append
        UltraGridColumn1.Header.Caption = "Name"
        UltraGridColumn1.Header.VisiblePosition = 1
        UltraGridColumn1.Width = 160
        UltraGridColumn2.AutoCompleteMode = Infragistics.Win.AutoCompleteMode.Append
        UltraGridColumn2.Format = ""
        UltraGridColumn2.Header.Caption = "Price"
        UltraGridColumn2.Header.VisiblePosition = 3
        UltraGridColumn2.Hidden = True
        UltraGridColumn2.Width = 60
        UltraGridColumn3.AutoCompleteMode = Infragistics.Win.AutoCompleteMode.Append
        Appearance39.TextHAlignAsString = "Center"
        UltraGridColumn3.CellAppearance = Appearance39
        UltraGridColumn3.Header.Caption = "Qty"
        UltraGridColumn3.Header.VisiblePosition = 0
        UltraGridColumn3.Style = Infragistics.Win.UltraWinGrid.ColumnStyle.DropDown
        UltraGridColumn3.Width = 53
        UltraGridColumn4.AutoCompleteMode = Infragistics.Win.AutoCompleteMode.Append
        Appearance40.TextHAlignAsString = "Right"
        UltraGridColumn4.CellAppearance = Appearance40
        UltraGridColumn4.Format = "#0.00"
        UltraGridColumn4.Header.Caption = "Total"
        UltraGridColumn4.Header.VisiblePosition = 2
        UltraGridColumn4.Width = 60
        UltraGridBand1.Columns.AddRange(New Object() {UltraGridColumn1, UltraGridColumn2, UltraGridColumn3, UltraGridColumn4})
        Appearance41.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        UltraGridBand1.Header.Appearance = Appearance41
        UltraGridBand1.Override.AllowAddNew = Infragistics.Win.UltraWinGrid.AllowAddNew.Yes
        Me.ugdDrinksGrid.DisplayLayout.BandsSerializer.Add(UltraGridBand1)
        Me.ugdDrinksGrid.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Me.ugdDrinksGrid.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.[False]
        Appearance42.BackColor = System.Drawing.SystemColors.ActiveBorder
        Appearance42.BackColor2 = System.Drawing.SystemColors.ControlDark
        Appearance42.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance42.BorderColor = System.Drawing.SystemColors.Window
        Me.ugdDrinksGrid.DisplayLayout.GroupByBox.Appearance = Appearance42
        Appearance43.ForeColor = System.Drawing.SystemColors.GrayText
        Me.ugdDrinksGrid.DisplayLayout.GroupByBox.BandLabelAppearance = Appearance43
        Me.ugdDrinksGrid.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Appearance44.BackColor = System.Drawing.SystemColors.ControlLightLight
        Appearance44.BackColor2 = System.Drawing.SystemColors.Control
        Appearance44.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal
        Appearance44.ForeColor = System.Drawing.SystemColors.GrayText
        Me.ugdDrinksGrid.DisplayLayout.GroupByBox.PromptAppearance = Appearance44
        Me.ugdDrinksGrid.DisplayLayout.MaxColScrollRegions = 1
        Me.ugdDrinksGrid.DisplayLayout.MaxRowScrollRegions = 1
        Appearance45.BackColor = System.Drawing.Color.Orange
        Appearance45.BackColor2 = System.Drawing.Color.DarkOrange
        Appearance45.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ugdDrinksGrid.DisplayLayout.Override.ActiveRowAppearance = Appearance45
        Me.ugdDrinksGrid.DisplayLayout.Override.AllowColMoving = Infragistics.Win.UltraWinGrid.AllowColMoving.NotAllowed
        Me.ugdDrinksGrid.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted
        Me.ugdDrinksGrid.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted
        Appearance46.BackColor = System.Drawing.SystemColors.Window
        Me.ugdDrinksGrid.DisplayLayout.Override.CardAreaAppearance = Appearance46
        Appearance47.BorderColor = System.Drawing.Color.Silver
        Appearance47.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter
        Me.ugdDrinksGrid.DisplayLayout.Override.CellAppearance = Appearance47
        Me.ugdDrinksGrid.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.EditAndSelectText
        Me.ugdDrinksGrid.DisplayLayout.Override.CellPadding = 0
        Appearance48.BackColor = System.Drawing.SystemColors.Control
        Appearance48.BackColor2 = System.Drawing.SystemColors.ControlDark
        Appearance48.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element
        Appearance48.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal
        Appearance48.BorderColor = System.Drawing.SystemColors.Window
        Me.ugdDrinksGrid.DisplayLayout.Override.GroupByRowAppearance = Appearance48
        Appearance49.BackColor = System.Drawing.Color.FromArgb(CType(CType(162, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance49.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(162, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance49.TextHAlignAsString = "Center"
        Me.ugdDrinksGrid.DisplayLayout.Override.HeaderAppearance = Appearance49
        Me.ugdDrinksGrid.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti
        Me.ugdDrinksGrid.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand
        Appearance50.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.ugdDrinksGrid.DisplayLayout.Override.RowAlternateAppearance = Appearance50
        Appearance51.BackColor = System.Drawing.Color.Gainsboro
        Me.ugdDrinksGrid.DisplayLayout.Override.RowAppearance = Appearance51
        Me.ugdDrinksGrid.DisplayLayout.Override.RowSelectorHeaderStyle = Infragistics.Win.UltraWinGrid.RowSelectorHeaderStyle.None
        Me.ugdDrinksGrid.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.[False]
        Me.ugdDrinksGrid.DisplayLayout.Override.RowSizing = Infragistics.Win.UltraWinGrid.RowSizing.Sychronized
        Me.ugdDrinksGrid.DisplayLayout.Override.RowSizingArea = Infragistics.Win.UltraWinGrid.RowSizingArea.RowBordersOnly
        Me.ugdDrinksGrid.DisplayLayout.Override.SelectTypeCol = Infragistics.Win.UltraWinGrid.SelectType.None
        Me.ugdDrinksGrid.DisplayLayout.Override.SelectTypeRow = Infragistics.Win.UltraWinGrid.SelectType.[Single]
        Appearance52.BackColor = System.Drawing.SystemColors.ControlLight
        Me.ugdDrinksGrid.DisplayLayout.Override.TemplateAddRowAppearance = Appearance52
        Me.ugdDrinksGrid.DisplayLayout.Override.WrapHeaderText = Infragistics.Win.DefaultableBoolean.[True]
        Me.ugdDrinksGrid.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill
        Me.ugdDrinksGrid.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate
        Me.ugdDrinksGrid.DisplayLayout.ViewStyle = Infragistics.Win.UltraWinGrid.ViewStyle.SingleBand
        Me.ugdDrinksGrid.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ugdDrinksGrid.Location = New System.Drawing.Point(649, 97)
        Me.ugdDrinksGrid.Name = "ugdDrinksGrid"
        Me.ugdDrinksGrid.Size = New System.Drawing.Size(279, 518)
        Me.ugdDrinksGrid.TabIndex = 442
        '
        'upnlTableBill
        '
        Appearance53.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Appearance53.ImageBackground = CType(resources.GetObject("Appearance53.ImageBackground"), System.Drawing.Image)
        Me.upnlTableBill.Appearance = Appearance53
        '
        'upnlTableBill.ClientArea
        '
        Me.upnlTableBill.ClientArea.Controls.Add(Me.cmdLightsStatus)
        Me.upnlTableBill.ClientArea.Controls.Add(Me.upnlMiniTables)
        Me.upnlTableBill.ClientArea.Controls.Add(Me.cmdCAP)
        Me.upnlTableBill.ClientArea.Controls.Add(Me.cmdMoveTable)
        Me.upnlTableBill.ClientArea.Controls.Add(Me.lblTipsLabel)
        Me.upnlTableBill.ClientArea.Controls.Add(Me.cmdTableDiscounts)
        Me.upnlTableBill.ClientArea.Controls.Add(Me.UltraLabel6)
        Me.upnlTableBill.ClientArea.Controls.Add(Me.lblCovers)
        Me.upnlTableBill.ClientArea.Controls.Add(Me.cmdCovers)
        Me.upnlTableBill.ClientArea.Controls.Add(Me.ugdTableGrid)
        Me.upnlTableBill.ClientArea.Controls.Add(Me.lblBillHeader)
        Me.upnlTableBill.ClientArea.Controls.Add(Me.lblCharges)
        Me.upnlTableBill.ClientArea.Controls.Add(Me.UltraLabel2)
        Me.upnlTableBill.ClientArea.Controls.Add(Me.lblDiscounts)
        Me.upnlTableBill.ClientArea.Controls.Add(Me.UltraLabel4)
        Me.upnlTableBill.ClientArea.Controls.Add(Me.cmdTablePayment)
        Me.upnlTableBill.ClientArea.Controls.Add(Me.cmdTableKNote)
        Me.upnlTableBill.ClientArea.Controls.Add(Me.cmdTableKCopy)
        Me.upnlTableBill.ClientArea.Controls.Add(Me.cmdTableClear)
        Me.upnlTableBill.ClientArea.Controls.Add(Me.cmdTableTables)
        Me.upnlTableBill.ClientArea.Controls.Add(Me.cmdTableDrinks)
        Me.upnlTableBill.ClientArea.Controls.Add(Me.cmdTablePrint)
        Me.upnlTableBill.ClientArea.Controls.Add(Me.cmdTableEdit)
        Me.upnlTableBill.ClientArea.Controls.Add(Me.cmdTableClose)
        Me.upnlTableBill.ClientArea.Controls.Add(Me.cmdTableDiscard)
        Me.upnlTableBill.ClientArea.Controls.Add(Me.lblTTips)
        Me.upnlTableBill.ClientArea.Controls.Add(Me.lblTDrinks)
        Me.upnlTableBill.ClientArea.Controls.Add(Me.lblTCharges)
        Me.upnlTableBill.ClientArea.Controls.Add(Me.lblBillTotal)
        Me.upnlTableBill.ClientArea.Controls.Add(Me.lblTDiscount)
        Me.upnlTableBill.ClientArea.Controls.Add(Me.lblTSubtotal)
        Me.upnlTableBill.ClientArea.Controls.Add(Me.lblEntryTime)
        Me.upnlTableBill.Location = New System.Drawing.Point(0, 0)
        Me.upnlTableBill.Name = "upnlTableBill"
        Me.upnlTableBill.Size = New System.Drawing.Size(1000, 730)
        Me.upnlTableBill.TabIndex = 120
        Me.upnlTableBill.Tag = "MoveModeOff"
        '
        'cmdLightsStatus
        '
        Appearance54.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(130, Byte), Integer), CType(CType(160, Byte), Integer))
        Appearance54.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(160, Byte), Integer))
        Appearance54.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance54.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance54.BorderColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(220, Byte), Integer))
        Appearance54.BorderColor2 = System.Drawing.Color.Maroon
        Appearance54.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance54.ForeColor = System.Drawing.Color.White
        Appearance54.Image = CType(resources.GetObject("Appearance54.Image"), Object)
        Appearance54.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance54.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance54.TextVAlignAsString = "Bottom"
        Me.cmdLightsStatus.Appearance = Appearance54
        Me.cmdLightsStatus.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance55.BackColor = System.Drawing.Color.DarkOrange
        Appearance55.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance55.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance55.ForeColor = System.Drawing.Color.Black
        Me.cmdLightsStatus.HotTrackAppearance = Appearance55
        Me.cmdLightsStatus.ImageSize = New System.Drawing.Size(42, 42)
        Me.cmdLightsStatus.Location = New System.Drawing.Point(704, 443)
        Me.cmdLightsStatus.Name = "cmdLightsStatus"
        Appearance56.BackColor = System.Drawing.Color.OrangeRed
        Appearance56.BackColor2 = System.Drawing.Color.Tomato
        Appearance56.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdLightsStatus.PressedAppearance = Appearance56
        Me.cmdLightsStatus.ShowFocusRect = False
        Me.cmdLightsStatus.ShowOutline = False
        Me.cmdLightsStatus.Size = New System.Drawing.Size(126, 65)
        Me.cmdLightsStatus.TabIndex = 485
        Me.cmdLightsStatus.Tag = "Status"
        Me.cmdLightsStatus.Text = "Status"
        Me.cmdLightsStatus.UseAppStyling = False
        Me.cmdLightsStatus.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdLightsStatus.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdLightsStatus.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'upnlMiniTables
        '
        Appearance57.BackColor = System.Drawing.Color.Transparent
        Appearance57.BorderColor = System.Drawing.Color.White
        Me.upnlMiniTables.Appearance = Appearance57
        Me.upnlMiniTables.BorderStyle = Infragistics.Win.UIElementBorderStyle.None
        '
        'upnlMiniTables.ClientArea
        '
        Me.upnlMiniTables.ClientArea.Controls.Add(Me.lblMiniHilit)
        Me.upnlMiniTables.Location = New System.Drawing.Point(390, 465)
        Me.upnlMiniTables.Name = "upnlMiniTables"
        Me.upnlMiniTables.Size = New System.Drawing.Size(270, 205)
        Me.upnlMiniTables.TabIndex = 482
        '
        'lblMiniHilit
        '
        Appearance58.BackColor = System.Drawing.Color.Transparent
        Appearance58.ImageBackground = Global.EZMenu.My.Resources.ezresource.minitable_hilit
        Me.lblMiniHilit.Appearance = Appearance58
        Me.lblMiniHilit.ImageSize = New System.Drawing.Size(58, 58)
        Me.lblMiniHilit.Location = New System.Drawing.Point(55, 50)
        Me.lblMiniHilit.Name = "lblMiniHilit"
        Me.lblMiniHilit.Size = New System.Drawing.Size(58, 58)
        Me.lblMiniHilit.TabIndex = 0
        Me.lblMiniHilit.Visible = False
        '
        'cmdCAP
        '
        Appearance59.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(130, Byte), Integer), CType(CType(160, Byte), Integer))
        Appearance59.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(160, Byte), Integer))
        Appearance59.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance59.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance59.BorderColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(220, Byte), Integer))
        Appearance59.BorderColor2 = System.Drawing.Color.Maroon
        Appearance59.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance59.ForeColor = System.Drawing.Color.White
        Appearance59.Image = CType(resources.GetObject("Appearance59.Image"), Object)
        Appearance59.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance59.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance59.TextVAlignAsString = "Bottom"
        Me.cmdCAP.Appearance = Appearance59
        Me.cmdCAP.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance60.BackColor = System.Drawing.Color.DarkOrange
        Appearance60.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance60.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance60.ForeColor = System.Drawing.Color.Black
        Me.cmdCAP.HotTrackAppearance = Appearance60
        Me.cmdCAP.ImageSize = New System.Drawing.Size(48, 48)
        Me.cmdCAP.Location = New System.Drawing.Point(834, 230)
        Me.cmdCAP.Name = "cmdCAP"
        Appearance61.BackColor = System.Drawing.Color.OrangeRed
        Appearance61.BackColor2 = System.Drawing.Color.Tomato
        Appearance61.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdCAP.PressedAppearance = Appearance61
        Me.cmdCAP.ShowFocusRect = False
        Me.cmdCAP.ShowOutline = False
        Me.cmdCAP.Size = New System.Drawing.Size(126, 65)
        Me.cmdCAP.TabIndex = 481
        Me.cmdCAP.Tag = "Chutney"
        Me.cmdCAP.Text = "Chutney"
        Me.cmdCAP.UseAppStyling = False
        Me.cmdCAP.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdCAP.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdCAP.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdMoveTable
        '
        Appearance62.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(130, Byte), Integer), CType(CType(160, Byte), Integer))
        Appearance62.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(160, Byte), Integer))
        Appearance62.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance62.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance62.BorderColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(220, Byte), Integer))
        Appearance62.BorderColor2 = System.Drawing.Color.Maroon
        Appearance62.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance62.ForeColor = System.Drawing.Color.White
        Appearance62.Image = CType(resources.GetObject("Appearance62.Image"), Object)
        Appearance62.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance62.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance62.TextVAlignAsString = "Bottom"
        Me.cmdMoveTable.Appearance = Appearance62
        Me.cmdMoveTable.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance63.BackColor = System.Drawing.Color.DarkOrange
        Appearance63.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance63.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance63.ForeColor = System.Drawing.Color.Black
        Me.cmdMoveTable.HotTrackAppearance = Appearance63
        Me.cmdMoveTable.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdMoveTable.Location = New System.Drawing.Point(834, 301)
        Me.cmdMoveTable.Name = "cmdMoveTable"
        Appearance64.BackColor = System.Drawing.Color.OrangeRed
        Appearance64.BackColor2 = System.Drawing.Color.Tomato
        Appearance64.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdMoveTable.PressedAppearance = Appearance64
        Me.cmdMoveTable.ShowFocusRect = False
        Me.cmdMoveTable.ShowOutline = False
        Me.cmdMoveTable.Size = New System.Drawing.Size(126, 65)
        Me.cmdMoveTable.TabIndex = 480
        Me.cmdMoveTable.Tag = "Move Table"
        Me.cmdMoveTable.Text = "Move Table"
        Me.cmdMoveTable.UseAppStyling = False
        Me.cmdMoveTable.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdMoveTable.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdMoveTable.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblTipsLabel
        '
        Appearance65.BackColor = System.Drawing.Color.Transparent
        Appearance65.ForeColor = System.Drawing.Color.White
        Appearance65.TextHAlignAsString = "Right"
        Me.lblTipsLabel.Appearance = Appearance65
        Me.lblTipsLabel.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTipsLabel.Location = New System.Drawing.Point(94, 695)
        Me.lblTipsLabel.Name = "lblTipsLabel"
        Me.lblTipsLabel.Size = New System.Drawing.Size(100, 20)
        Me.lblTipsLabel.TabIndex = 478
        Me.lblTipsLabel.Text = "Tips:"
        Me.lblTipsLabel.UseAppStyling = False
        Me.lblTipsLabel.Visible = False
        '
        'cmdTableDiscounts
        '
        Appearance66.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(130, Byte), Integer), CType(CType(160, Byte), Integer))
        Appearance66.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(160, Byte), Integer))
        Appearance66.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance66.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance66.BorderColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(220, Byte), Integer))
        Appearance66.BorderColor2 = System.Drawing.Color.Maroon
        Appearance66.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance66.ForeColor = System.Drawing.Color.White
        Appearance66.Image = CType(resources.GetObject("Appearance66.Image"), Object)
        Appearance66.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance66.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance66.TextVAlignAsString = "Bottom"
        Me.cmdTableDiscounts.Appearance = Appearance66
        Me.cmdTableDiscounts.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance67.BackColor = System.Drawing.Color.DarkOrange
        Appearance67.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance67.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance67.ForeColor = System.Drawing.Color.Black
        Me.cmdTableDiscounts.HotTrackAppearance = Appearance67
        Me.cmdTableDiscounts.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdTableDiscounts.Location = New System.Drawing.Point(834, 372)
        Me.cmdTableDiscounts.Name = "cmdTableDiscounts"
        Appearance68.BackColor = System.Drawing.Color.OrangeRed
        Appearance68.BackColor2 = System.Drawing.Color.Tomato
        Appearance68.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdTableDiscounts.PressedAppearance = Appearance68
        Me.cmdTableDiscounts.ShowFocusRect = False
        Me.cmdTableDiscounts.ShowOutline = False
        Me.cmdTableDiscounts.Size = New System.Drawing.Size(126, 65)
        Me.cmdTableDiscounts.TabIndex = 476
        Me.cmdTableDiscounts.Tag = "Discounts && Charges"
        Me.cmdTableDiscounts.Text = "Discounts && Charges"
        Me.cmdTableDiscounts.UseAppStyling = False
        Me.cmdTableDiscounts.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTableDiscounts.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTableDiscounts.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraLabel6
        '
        Appearance69.BackColor = System.Drawing.Color.Transparent
        Appearance69.ForeColor = System.Drawing.Color.FromArgb(CType(CType(10, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(130, Byte), Integer))
        Appearance69.TextHAlignAsString = "Right"
        Me.UltraLabel6.Appearance = Appearance69
        Me.UltraLabel6.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UltraLabel6.Location = New System.Drawing.Point(94, 602)
        Me.UltraLabel6.Name = "UltraLabel6"
        Me.UltraLabel6.Size = New System.Drawing.Size(100, 20)
        Me.UltraLabel6.TabIndex = 380
        Me.UltraLabel6.Text = "Drinks:"
        Me.UltraLabel6.UseAppStyling = False
        '
        'lblCovers
        '
        Appearance70.BackColor = System.Drawing.Color.Transparent
        Appearance70.ForeColor = System.Drawing.Color.FromArgb(CType(CType(216, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(236, Byte), Integer))
        Appearance70.TextHAlignAsString = "Right"
        Appearance70.TextVAlignAsString = "Middle"
        Me.lblCovers.Appearance = Appearance70
        Me.lblCovers.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCovers.Location = New System.Drawing.Point(197, 61)
        Me.lblCovers.Name = "lblCovers"
        Me.lblCovers.Size = New System.Drawing.Size(150, 26)
        Me.lblCovers.TabIndex = 378
        Me.lblCovers.Text = "Covers: 0"
        Me.lblCovers.UseAppStyling = False
        '
        'cmdCovers
        '
        Appearance71.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(130, Byte), Integer), CType(CType(160, Byte), Integer))
        Appearance71.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(160, Byte), Integer))
        Appearance71.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance71.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance71.BorderColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(220, Byte), Integer))
        Appearance71.BorderColor2 = System.Drawing.Color.Maroon
        Appearance71.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance71.ForeColor = System.Drawing.Color.White
        Appearance71.Image = CType(resources.GetObject("Appearance71.Image"), Object)
        Appearance71.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance71.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance71.TextVAlignAsString = "Bottom"
        Me.cmdCovers.Appearance = Appearance71
        Me.cmdCovers.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance72.BackColor = System.Drawing.Color.DarkOrange
        Appearance72.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance72.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance72.ForeColor = System.Drawing.Color.Black
        Me.cmdCovers.HotTrackAppearance = Appearance72
        Me.cmdCovers.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdCovers.Location = New System.Drawing.Point(704, 230)
        Me.cmdCovers.Name = "cmdCovers"
        Appearance73.BackColor = System.Drawing.Color.OrangeRed
        Appearance73.BackColor2 = System.Drawing.Color.Tomato
        Appearance73.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdCovers.PressedAppearance = Appearance73
        Me.cmdCovers.ShowFocusRect = False
        Me.cmdCovers.ShowOutline = False
        Me.cmdCovers.Size = New System.Drawing.Size(126, 65)
        Me.cmdCovers.TabIndex = 377
        Me.cmdCovers.Tag = "Cover"
        Me.cmdCovers.Text = "Cover"
        Me.cmdCovers.UseAppStyling = False
        Me.cmdCovers.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdCovers.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdCovers.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ugdTableGrid
        '
        Me.ugdTableGrid.DataSource = Me.udsTableGrid
        Appearance74.BackColor = System.Drawing.Color.Transparent
        Appearance74.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Me.ugdTableGrid.DisplayLayout.Appearance = Appearance74
        UltraGridColumn5.AutoCompleteMode = Infragistics.Win.AutoCompleteMode.Append
        UltraGridColumn5.Header.VisiblePosition = 0
        UltraGridColumn5.Hidden = True
        UltraGridColumn5.Width = 50
        UltraGridColumn6.AutoCompleteMode = Infragistics.Win.AutoCompleteMode.Append
        UltraGridColumn6.Header.VisiblePosition = 2
        UltraGridColumn6.Width = 207
        UltraGridColumn7.AutoCompleteMode = Infragistics.Win.AutoCompleteMode.Append
        Appearance75.TextHAlignAsString = "Right"
        UltraGridColumn7.CellAppearance = Appearance75
        UltraGridColumn7.Header.VisiblePosition = 4
        UltraGridColumn7.Hidden = True
        UltraGridColumn7.Width = 60
        UltraGridColumn8.AutoCompleteMode = Infragistics.Win.AutoCompleteMode.Append
        Appearance76.TextHAlignAsString = "Center"
        UltraGridColumn8.CellAppearance = Appearance76
        UltraGridColumn8.Header.VisiblePosition = 1
        UltraGridColumn8.Style = Infragistics.Win.UltraWinGrid.ColumnStyle.DropDown
        UltraGridColumn8.Width = 53
        UltraGridColumn9.AutoCompleteMode = Infragistics.Win.AutoCompleteMode.Append
        Appearance77.TextHAlignAsString = "Right"
        UltraGridColumn9.CellAppearance = Appearance77
        UltraGridColumn9.Header.VisiblePosition = 3
        UltraGridColumn9.Width = 60
        UltraGridColumn10.AutoCompleteMode = Infragistics.Win.AutoCompleteMode.None
        UltraGridColumn10.Header.VisiblePosition = 5
        UltraGridColumn10.Hidden = True
        UltraGridColumn10.Style = Infragistics.Win.UltraWinGrid.ColumnStyle.DropDown
        UltraGridColumn10.Width = 146
        UltraGridColumn11.AutoCompleteMode = Infragistics.Win.AutoCompleteMode.Append
        UltraGridColumn11.DataType = GetType(Short)
        UltraGridColumn11.Header.VisiblePosition = 6
        UltraGridColumn11.Hidden = True
        UltraGridColumn11.Width = 98
        UltraGridColumn12.AutoCompleteMode = Infragistics.Win.AutoCompleteMode.Append
        UltraGridColumn12.Header.VisiblePosition = 7
        UltraGridColumn12.Hidden = True
        UltraGridColumn12.Width = 78
        UltraGridColumn13.AutoCompleteMode = Infragistics.Win.AutoCompleteMode.Append
        UltraGridColumn13.Header.VisiblePosition = 8
        UltraGridColumn13.Hidden = True
        UltraGridColumn13.Width = 66
        UltraGridColumn14.AutoCompleteMode = Infragistics.Win.AutoCompleteMode.Append
        UltraGridColumn14.Header.VisiblePosition = 9
        UltraGridColumn14.Hidden = True
        UltraGridColumn14.Width = 88
        UltraGridColumn15.AutoCompleteMode = Infragistics.Win.AutoCompleteMode.Append
        UltraGridColumn15.Header.VisiblePosition = 10
        UltraGridColumn15.Hidden = True
        UltraGridColumn15.Width = 74
        UltraGridColumn16.DataType = GetType(Short)
        UltraGridColumn16.Header.VisiblePosition = 11
        UltraGridColumn16.Hidden = True
        UltraGridBand2.Columns.AddRange(New Object() {UltraGridColumn5, UltraGridColumn6, UltraGridColumn7, UltraGridColumn8, UltraGridColumn9, UltraGridColumn10, UltraGridColumn11, UltraGridColumn12, UltraGridColumn13, UltraGridColumn14, UltraGridColumn15, UltraGridColumn16})
        Appearance78.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        UltraGridBand2.Header.Appearance = Appearance78
        UltraGridBand2.Override.AllowAddNew = Infragistics.Win.UltraWinGrid.AllowAddNew.Yes
        Me.ugdTableGrid.DisplayLayout.BandsSerializer.Add(UltraGridBand2)
        Me.ugdTableGrid.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Me.ugdTableGrid.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.[False]
        Appearance79.BackColor = System.Drawing.SystemColors.ActiveBorder
        Appearance79.BackColor2 = System.Drawing.SystemColors.ControlDark
        Appearance79.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance79.BorderColor = System.Drawing.SystemColors.Window
        Me.ugdTableGrid.DisplayLayout.GroupByBox.Appearance = Appearance79
        Appearance80.ForeColor = System.Drawing.SystemColors.GrayText
        Me.ugdTableGrid.DisplayLayout.GroupByBox.BandLabelAppearance = Appearance80
        Me.ugdTableGrid.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Appearance81.BackColor = System.Drawing.SystemColors.ControlLightLight
        Appearance81.BackColor2 = System.Drawing.SystemColors.Control
        Appearance81.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal
        Appearance81.ForeColor = System.Drawing.SystemColors.GrayText
        Me.ugdTableGrid.DisplayLayout.GroupByBox.PromptAppearance = Appearance81
        Me.ugdTableGrid.DisplayLayout.MaxColScrollRegions = 1
        Me.ugdTableGrid.DisplayLayout.MaxRowScrollRegions = 1
        Me.ugdTableGrid.DisplayLayout.Override.AllowColMoving = Infragistics.Win.UltraWinGrid.AllowColMoving.NotAllowed
        Me.ugdTableGrid.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted
        Me.ugdTableGrid.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted
        Appearance82.BackColor = System.Drawing.SystemColors.Window
        Me.ugdTableGrid.DisplayLayout.Override.CardAreaAppearance = Appearance82
        Appearance83.BorderColor = System.Drawing.Color.Silver
        Appearance83.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter
        Me.ugdTableGrid.DisplayLayout.Override.CellAppearance = Appearance83
        Me.ugdTableGrid.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.EditAndSelectText
        Me.ugdTableGrid.DisplayLayout.Override.CellPadding = 0
        Appearance84.BackColor = System.Drawing.SystemColors.Control
        Appearance84.BackColor2 = System.Drawing.SystemColors.ControlDark
        Appearance84.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element
        Appearance84.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal
        Appearance84.BorderColor = System.Drawing.SystemColors.Window
        Me.ugdTableGrid.DisplayLayout.Override.GroupByRowAppearance = Appearance84
        Appearance85.BackColor = System.Drawing.Color.FromArgb(CType(CType(162, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance85.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(162, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance85.TextHAlignAsString = "Center"
        Me.ugdTableGrid.DisplayLayout.Override.HeaderAppearance = Appearance85
        Me.ugdTableGrid.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti
        Me.ugdTableGrid.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand
        Appearance86.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.ugdTableGrid.DisplayLayout.Override.RowAlternateAppearance = Appearance86
        Appearance87.BackColor = System.Drawing.Color.Gainsboro
        Me.ugdTableGrid.DisplayLayout.Override.RowAppearance = Appearance87
        Me.ugdTableGrid.DisplayLayout.Override.RowSelectorHeaderStyle = Infragistics.Win.UltraWinGrid.RowSelectorHeaderStyle.None
        Me.ugdTableGrid.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.[False]
        Me.ugdTableGrid.DisplayLayout.Override.RowSizing = Infragistics.Win.UltraWinGrid.RowSizing.Sychronized
        Me.ugdTableGrid.DisplayLayout.Override.RowSizingArea = Infragistics.Win.UltraWinGrid.RowSizingArea.RowBordersOnly
        Me.ugdTableGrid.DisplayLayout.Override.SelectTypeCol = Infragistics.Win.UltraWinGrid.SelectType.None
        Me.ugdTableGrid.DisplayLayout.Override.SelectTypeRow = Infragistics.Win.UltraWinGrid.SelectType.[Single]
        Appearance88.BackColor = System.Drawing.SystemColors.ControlLight
        Me.ugdTableGrid.DisplayLayout.Override.TemplateAddRowAppearance = Appearance88
        Me.ugdTableGrid.DisplayLayout.Override.WrapHeaderText = Infragistics.Win.DefaultableBoolean.[True]
        Me.ugdTableGrid.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill
        Me.ugdTableGrid.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate
        Me.ugdTableGrid.DisplayLayout.ViewStyle = Infragistics.Win.UltraWinGrid.ViewStyle.SingleBand
        Me.ugdTableGrid.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ugdTableGrid.Location = New System.Drawing.Point(31, 88)
        Me.ugdTableGrid.Name = "ugdTableGrid"
        Me.ugdTableGrid.Size = New System.Drawing.Size(323, 487)
        Me.ugdTableGrid.TabIndex = 376
        '
        'lblBillHeader
        '
        Appearance89.BackColor = System.Drawing.Color.Transparent
        Appearance89.ForeColor = System.Drawing.Color.FromArgb(CType(CType(216, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(236, Byte), Integer))
        Appearance89.TextHAlignAsString = "Left"
        Appearance89.TextVAlignAsString = "Middle"
        Me.lblBillHeader.Appearance = Appearance89
        Me.lblBillHeader.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBillHeader.Location = New System.Drawing.Point(37, 61)
        Me.lblBillHeader.Name = "lblBillHeader"
        Me.lblBillHeader.Size = New System.Drawing.Size(150, 26)
        Me.lblBillHeader.TabIndex = 373
        Me.lblBillHeader.Text = "Table: X"
        Me.lblBillHeader.UseAppStyling = False
        '
        'lblCharges
        '
        Appearance90.BackColor = System.Drawing.Color.Transparent
        Appearance90.ForeColor = System.Drawing.Color.FromArgb(CType(CType(10, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(130, Byte), Integer))
        Appearance90.TextHAlignAsString = "Right"
        Me.lblCharges.Appearance = Appearance90
        Me.lblCharges.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCharges.Location = New System.Drawing.Point(37, 642)
        Me.lblCharges.Name = "lblCharges"
        Me.lblCharges.Size = New System.Drawing.Size(157, 20)
        Me.lblCharges.TabIndex = 372
        Me.lblCharges.Text = "Charges:"
        Me.lblCharges.UseAppStyling = False
        '
        'UltraLabel2
        '
        Appearance91.BackColor = System.Drawing.Color.Transparent
        Appearance91.ForeColor = System.Drawing.Color.FromArgb(CType(CType(10, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(130, Byte), Integer))
        Appearance91.TextHAlignAsString = "Right"
        Me.UltraLabel2.Appearance = Appearance91
        Me.UltraLabel2.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UltraLabel2.Location = New System.Drawing.Point(94, 662)
        Me.UltraLabel2.Name = "UltraLabel2"
        Me.UltraLabel2.Size = New System.Drawing.Size(100, 20)
        Me.UltraLabel2.TabIndex = 371
        Me.UltraLabel2.Text = "Total:"
        Me.UltraLabel2.UseAppStyling = False
        '
        'lblDiscounts
        '
        Appearance92.BackColor = System.Drawing.Color.Transparent
        Appearance92.ForeColor = System.Drawing.Color.FromArgb(CType(CType(10, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(130, Byte), Integer))
        Appearance92.TextHAlignAsString = "Right"
        Me.lblDiscounts.Appearance = Appearance92
        Me.lblDiscounts.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDiscounts.Location = New System.Drawing.Point(43, 622)
        Me.lblDiscounts.Name = "lblDiscounts"
        Me.lblDiscounts.Size = New System.Drawing.Size(151, 20)
        Me.lblDiscounts.TabIndex = 370
        Me.lblDiscounts.Text = "Discounts:"
        Me.lblDiscounts.UseAppStyling = False
        '
        'UltraLabel4
        '
        Appearance93.BackColor = System.Drawing.Color.Transparent
        Appearance93.ForeColor = System.Drawing.Color.FromArgb(CType(CType(10, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(130, Byte), Integer))
        Appearance93.TextHAlignAsString = "Right"
        Me.UltraLabel4.Appearance = Appearance93
        Me.UltraLabel4.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UltraLabel4.Location = New System.Drawing.Point(94, 582)
        Me.UltraLabel4.Name = "UltraLabel4"
        Me.UltraLabel4.Size = New System.Drawing.Size(100, 20)
        Me.UltraLabel4.TabIndex = 369
        Me.UltraLabel4.Text = "Subtotal:"
        Me.UltraLabel4.UseAppStyling = False
        '
        'cmdTablePayment
        '
        Appearance94.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(130, Byte), Integer), CType(CType(160, Byte), Integer))
        Appearance94.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(160, Byte), Integer))
        Appearance94.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance94.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance94.BorderColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(220, Byte), Integer))
        Appearance94.BorderColor2 = System.Drawing.Color.Maroon
        Appearance94.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance94.ForeColor = System.Drawing.Color.White
        Appearance94.Image = CType(resources.GetObject("Appearance94.Image"), Object)
        Appearance94.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance94.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance94.TextVAlignAsString = "Bottom"
        Me.cmdTablePayment.Appearance = Appearance94
        Me.cmdTablePayment.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance95.BackColor = System.Drawing.Color.DarkOrange
        Appearance95.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance95.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance95.ForeColor = System.Drawing.Color.Black
        Me.cmdTablePayment.HotTrackAppearance = Appearance95
        Me.cmdTablePayment.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdTablePayment.Location = New System.Drawing.Point(704, 372)
        Me.cmdTablePayment.Name = "cmdTablePayment"
        Appearance96.BackColor = System.Drawing.Color.OrangeRed
        Appearance96.BackColor2 = System.Drawing.Color.Tomato
        Appearance96.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdTablePayment.PressedAppearance = Appearance96
        Me.cmdTablePayment.ShowFocusRect = False
        Me.cmdTablePayment.ShowOutline = False
        Me.cmdTablePayment.Size = New System.Drawing.Size(126, 65)
        Me.cmdTablePayment.TabIndex = 367
        Me.cmdTablePayment.Tag = "Payment"
        Me.cmdTablePayment.Text = "Payment"
        Me.cmdTablePayment.UseAppStyling = False
        Me.cmdTablePayment.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTablePayment.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTablePayment.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdTableKNote
        '
        Appearance97.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(130, Byte), Integer), CType(CType(160, Byte), Integer))
        Appearance97.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(160, Byte), Integer))
        Appearance97.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance97.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance97.BorderColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(220, Byte), Integer))
        Appearance97.BorderColor2 = System.Drawing.Color.Maroon
        Appearance97.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance97.ForeColor = System.Drawing.Color.White
        Appearance97.Image = CType(resources.GetObject("Appearance97.Image"), Object)
        Appearance97.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance97.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance97.TextVAlignAsString = "Bottom"
        Me.cmdTableKNote.Appearance = Appearance97
        Me.cmdTableKNote.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance98.BackColor = System.Drawing.Color.DarkOrange
        Appearance98.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance98.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance98.ForeColor = System.Drawing.Color.Black
        Me.cmdTableKNote.HotTrackAppearance = Appearance98
        Me.cmdTableKNote.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdTableKNote.Location = New System.Drawing.Point(704, 301)
        Me.cmdTableKNote.Name = "cmdTableKNote"
        Appearance99.BackColor = System.Drawing.Color.OrangeRed
        Appearance99.BackColor2 = System.Drawing.Color.Tomato
        Appearance99.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdTableKNote.PressedAppearance = Appearance99
        Me.cmdTableKNote.ShowFocusRect = False
        Me.cmdTableKNote.ShowOutline = False
        Me.cmdTableKNote.Size = New System.Drawing.Size(126, 65)
        Me.cmdTableKNote.TabIndex = 366
        Me.cmdTableKNote.Tag = "Kitchen Note"
        Me.cmdTableKNote.Text = "Kitchen Note"
        Me.cmdTableKNote.UseAppStyling = False
        Me.cmdTableKNote.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTableKNote.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTableKNote.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdTableKCopy
        '
        Appearance100.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(130, Byte), Integer), CType(CType(160, Byte), Integer))
        Appearance100.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(160, Byte), Integer))
        Appearance100.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance100.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance100.BorderColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(220, Byte), Integer))
        Appearance100.BorderColor2 = System.Drawing.Color.Maroon
        Appearance100.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance100.ForeColor = System.Drawing.Color.White
        Appearance100.Image = CType(resources.GetObject("Appearance100.Image"), Object)
        Appearance100.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance100.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance100.TextVAlignAsString = "Bottom"
        Me.cmdTableKCopy.Appearance = Appearance100
        Me.cmdTableKCopy.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance101.BackColor = System.Drawing.Color.DarkOrange
        Appearance101.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance101.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance101.ForeColor = System.Drawing.Color.Black
        Me.cmdTableKCopy.HotTrackAppearance = Appearance101
        Me.cmdTableKCopy.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdTableKCopy.Location = New System.Drawing.Point(834, 159)
        Me.cmdTableKCopy.Name = "cmdTableKCopy"
        Appearance102.BackColor = System.Drawing.Color.OrangeRed
        Appearance102.BackColor2 = System.Drawing.Color.Tomato
        Appearance102.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdTableKCopy.PressedAppearance = Appearance102
        Me.cmdTableKCopy.ShowFocusRect = False
        Me.cmdTableKCopy.ShowOutline = False
        Me.cmdTableKCopy.Size = New System.Drawing.Size(126, 65)
        Me.cmdTableKCopy.TabIndex = 365
        Me.cmdTableKCopy.Tag = "Kitchen Copy"
        Me.cmdTableKCopy.Text = "Kitchen Copy"
        Me.cmdTableKCopy.UseAppStyling = False
        Me.cmdTableKCopy.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTableKCopy.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTableKCopy.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdTableClear
        '
        Appearance103.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(130, Byte), Integer), CType(CType(160, Byte), Integer))
        Appearance103.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(160, Byte), Integer))
        Appearance103.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance103.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance103.BorderColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(220, Byte), Integer))
        Appearance103.BorderColor2 = System.Drawing.Color.Maroon
        Appearance103.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance103.ForeColor = System.Drawing.Color.White
        Appearance103.Image = CType(resources.GetObject("Appearance103.Image"), Object)
        Appearance103.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance103.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance103.TextVAlignAsString = "Bottom"
        Me.cmdTableClear.Appearance = Appearance103
        Me.cmdTableClear.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance104.BackColor = System.Drawing.Color.DarkOrange
        Appearance104.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance104.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance104.ForeColor = System.Drawing.Color.Black
        Me.cmdTableClear.HotTrackAppearance = Appearance104
        Me.cmdTableClear.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdTableClear.Location = New System.Drawing.Point(704, 514)
        Me.cmdTableClear.Name = "cmdTableClear"
        Appearance105.BackColor = System.Drawing.Color.OrangeRed
        Appearance105.BackColor2 = System.Drawing.Color.Tomato
        Appearance105.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdTableClear.PressedAppearance = Appearance105
        Me.cmdTableClear.ShowFocusRect = False
        Me.cmdTableClear.ShowOutline = False
        Me.cmdTableClear.Size = New System.Drawing.Size(126, 65)
        Me.cmdTableClear.TabIndex = 363
        Me.cmdTableClear.Tag = "Settle"
        Me.cmdTableClear.Text = "Settle"
        Me.cmdTableClear.UseAppStyling = False
        Me.cmdTableClear.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTableClear.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTableClear.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdTableTables
        '
        Appearance106.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(130, Byte), Integer), CType(CType(160, Byte), Integer))
        Appearance106.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(160, Byte), Integer))
        Appearance106.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance106.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance106.BorderColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(220, Byte), Integer))
        Appearance106.BorderColor2 = System.Drawing.Color.Maroon
        Appearance106.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance106.ForeColor = System.Drawing.Color.White
        Appearance106.Image = CType(resources.GetObject("Appearance106.Image"), Object)
        Appearance106.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance106.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance106.TextVAlignAsString = "Bottom"
        Me.cmdTableTables.Appearance = Appearance106
        Me.cmdTableTables.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance107.BackColor = System.Drawing.Color.DarkOrange
        Appearance107.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance107.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance107.ForeColor = System.Drawing.Color.Black
        Me.cmdTableTables.HotTrackAppearance = Appearance107
        Me.cmdTableTables.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdTableTables.Location = New System.Drawing.Point(834, 443)
        Me.cmdTableTables.Name = "cmdTableTables"
        Appearance108.BackColor = System.Drawing.Color.OrangeRed
        Appearance108.BackColor2 = System.Drawing.Color.Tomato
        Appearance108.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdTableTables.PressedAppearance = Appearance108
        Me.cmdTableTables.ShowFocusRect = False
        Me.cmdTableTables.ShowOutline = False
        Me.cmdTableTables.Size = New System.Drawing.Size(126, 65)
        Me.cmdTableTables.TabIndex = 364
        Me.cmdTableTables.Tag = "Tables"
        Me.cmdTableTables.Text = "Tables"
        Me.cmdTableTables.UseAppStyling = False
        Me.cmdTableTables.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTableTables.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTableTables.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdTableDrinks
        '
        Appearance109.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(130, Byte), Integer), CType(CType(160, Byte), Integer))
        Appearance109.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(160, Byte), Integer))
        Appearance109.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance109.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance109.BorderColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(220, Byte), Integer))
        Appearance109.BorderColor2 = System.Drawing.Color.Maroon
        Appearance109.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance109.ForeColor = System.Drawing.Color.White
        Appearance109.Image = CType(resources.GetObject("Appearance109.Image"), Object)
        Appearance109.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance109.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance109.TextVAlignAsString = "Bottom"
        Me.cmdTableDrinks.Appearance = Appearance109
        Me.cmdTableDrinks.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance110.BackColor = System.Drawing.Color.DarkOrange
        Appearance110.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance110.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance110.ForeColor = System.Drawing.Color.Black
        Me.cmdTableDrinks.HotTrackAppearance = Appearance110
        Me.cmdTableDrinks.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdTableDrinks.Location = New System.Drawing.Point(834, 88)
        Me.cmdTableDrinks.Name = "cmdTableDrinks"
        Appearance111.BackColor = System.Drawing.Color.OrangeRed
        Appearance111.BackColor2 = System.Drawing.Color.Tomato
        Appearance111.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdTableDrinks.PressedAppearance = Appearance111
        Me.cmdTableDrinks.ShowFocusRect = False
        Me.cmdTableDrinks.ShowOutline = False
        Me.cmdTableDrinks.Size = New System.Drawing.Size(126, 65)
        Me.cmdTableDrinks.TabIndex = 362
        Me.cmdTableDrinks.Tag = "Drinks"
        Me.cmdTableDrinks.Text = "Drinks"
        Me.cmdTableDrinks.UseAppStyling = False
        Me.cmdTableDrinks.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTableDrinks.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTableDrinks.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdTablePrint
        '
        Appearance112.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(130, Byte), Integer), CType(CType(160, Byte), Integer))
        Appearance112.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(160, Byte), Integer))
        Appearance112.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance112.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance112.BorderColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(220, Byte), Integer))
        Appearance112.BorderColor2 = System.Drawing.Color.Maroon
        Appearance112.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance112.ForeColor = System.Drawing.Color.White
        Appearance112.Image = CType(resources.GetObject("Appearance112.Image"), Object)
        Appearance112.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance112.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance112.TextVAlignAsString = "Bottom"
        Me.cmdTablePrint.Appearance = Appearance112
        Me.cmdTablePrint.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance113.BackColor = System.Drawing.Color.DarkOrange
        Appearance113.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance113.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance113.ForeColor = System.Drawing.Color.Black
        Me.cmdTablePrint.HotTrackAppearance = Appearance113
        Me.cmdTablePrint.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdTablePrint.Location = New System.Drawing.Point(704, 159)
        Me.cmdTablePrint.Name = "cmdTablePrint"
        Appearance114.BackColor = System.Drawing.Color.OrangeRed
        Appearance114.BackColor2 = System.Drawing.Color.Tomato
        Appearance114.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdTablePrint.PressedAppearance = Appearance114
        Me.cmdTablePrint.ShowFocusRect = False
        Me.cmdTablePrint.ShowOutline = False
        Me.cmdTablePrint.Size = New System.Drawing.Size(126, 65)
        Me.cmdTablePrint.TabIndex = 361
        Me.cmdTablePrint.Tag = "Print"
        Me.cmdTablePrint.Text = "Print"
        Me.cmdTablePrint.UseAppStyling = False
        Me.cmdTablePrint.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTablePrint.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTablePrint.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdTableEdit
        '
        Appearance115.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(130, Byte), Integer), CType(CType(160, Byte), Integer))
        Appearance115.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(160, Byte), Integer))
        Appearance115.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance115.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance115.BorderColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(220, Byte), Integer))
        Appearance115.BorderColor2 = System.Drawing.Color.Maroon
        Appearance115.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance115.ForeColor = System.Drawing.Color.White
        Appearance115.Image = CType(resources.GetObject("Appearance115.Image"), Object)
        Appearance115.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance115.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance115.TextVAlignAsString = "Bottom"
        Me.cmdTableEdit.Appearance = Appearance115
        Me.cmdTableEdit.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance116.BackColor = System.Drawing.Color.DarkOrange
        Appearance116.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance116.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance116.ForeColor = System.Drawing.Color.Black
        Me.cmdTableEdit.HotTrackAppearance = Appearance116
        Me.cmdTableEdit.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdTableEdit.Location = New System.Drawing.Point(704, 88)
        Me.cmdTableEdit.Name = "cmdTableEdit"
        Appearance117.BackColor = System.Drawing.Color.OrangeRed
        Appearance117.BackColor2 = System.Drawing.Color.Tomato
        Appearance117.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdTableEdit.PressedAppearance = Appearance117
        Me.cmdTableEdit.ShowFocusRect = False
        Me.cmdTableEdit.ShowOutline = False
        Me.cmdTableEdit.Size = New System.Drawing.Size(126, 65)
        Me.cmdTableEdit.TabIndex = 360
        Me.cmdTableEdit.Tag = "Edit"
        Me.cmdTableEdit.Text = "Edit"
        Me.cmdTableEdit.UseAppStyling = False
        Me.cmdTableEdit.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTableEdit.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTableEdit.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdTableClose
        '
        Appearance118.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(130, Byte), Integer), CType(CType(160, Byte), Integer))
        Appearance118.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(160, Byte), Integer))
        Appearance118.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance118.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance118.BorderColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(220, Byte), Integer))
        Appearance118.BorderColor2 = System.Drawing.Color.Maroon
        Appearance118.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance118.ForeColor = System.Drawing.Color.White
        Appearance118.Image = CType(resources.GetObject("Appearance118.Image"), Object)
        Appearance118.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance118.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance118.TextVAlignAsString = "Bottom"
        Me.cmdTableClose.Appearance = Appearance118
        Me.cmdTableClose.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance119.BackColor = System.Drawing.Color.DarkOrange
        Appearance119.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance119.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance119.ForeColor = System.Drawing.Color.Black
        Me.cmdTableClose.HotTrackAppearance = Appearance119
        Me.cmdTableClose.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdTableClose.Location = New System.Drawing.Point(704, 585)
        Me.cmdTableClose.Name = "cmdTableClose"
        Appearance120.BackColor = System.Drawing.Color.OrangeRed
        Appearance120.BackColor2 = System.Drawing.Color.Tomato
        Appearance120.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdTableClose.PressedAppearance = Appearance120
        Me.cmdTableClose.ShowFocusRect = False
        Me.cmdTableClose.ShowOutline = False
        Me.cmdTableClose.Size = New System.Drawing.Size(256, 65)
        Me.cmdTableClose.TabIndex = 358
        Me.cmdTableClose.Tag = "OK"
        Me.cmdTableClose.Text = "OK"
        Me.cmdTableClose.UseAppStyling = False
        Me.cmdTableClose.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTableClose.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTableClose.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdTableDiscard
        '
        Appearance121.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(130, Byte), Integer), CType(CType(160, Byte), Integer))
        Appearance121.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(160, Byte), Integer))
        Appearance121.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance121.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance121.BorderColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(220, Byte), Integer))
        Appearance121.BorderColor2 = System.Drawing.Color.Maroon
        Appearance121.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance121.ForeColor = System.Drawing.Color.White
        Appearance121.Image = CType(resources.GetObject("Appearance121.Image"), Object)
        Appearance121.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance121.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance121.TextVAlignAsString = "Bottom"
        Me.cmdTableDiscard.Appearance = Appearance121
        Me.cmdTableDiscard.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance122.BackColor = System.Drawing.Color.DarkOrange
        Appearance122.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance122.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance122.ForeColor = System.Drawing.Color.Black
        Me.cmdTableDiscard.HotTrackAppearance = Appearance122
        Me.cmdTableDiscard.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdTableDiscard.Location = New System.Drawing.Point(834, 514)
        Me.cmdTableDiscard.Name = "cmdTableDiscard"
        Appearance123.BackColor = System.Drawing.Color.OrangeRed
        Appearance123.BackColor2 = System.Drawing.Color.Tomato
        Appearance123.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdTableDiscard.PressedAppearance = Appearance123
        Me.cmdTableDiscard.ShowFocusRect = False
        Me.cmdTableDiscard.ShowOutline = False
        Me.cmdTableDiscard.Size = New System.Drawing.Size(126, 65)
        Me.cmdTableDiscard.TabIndex = 359
        Me.cmdTableDiscard.Tag = "Discard"
        Me.cmdTableDiscard.Text = "Discard"
        Me.cmdTableDiscard.UseAppStyling = False
        Me.cmdTableDiscard.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTableDiscard.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTableDiscard.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblTTips
        '
        Appearance124.BackColor = System.Drawing.Color.Transparent
        Appearance124.ForeColor = System.Drawing.Color.White
        Appearance124.TextHAlignAsString = "Right"
        Me.lblTTips.Appearance = Appearance124
        Me.lblTTips.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTTips.Location = New System.Drawing.Point(188, 695)
        Me.lblTTips.Name = "lblTTips"
        Me.lblTTips.Size = New System.Drawing.Size(60, 20)
        Me.lblTTips.TabIndex = 477
        Me.lblTTips.Text = "0.00"
        Me.lblTTips.UseAppStyling = False
        Me.lblTTips.Visible = False
        '
        'lblTDrinks
        '
        Appearance125.BackColor = System.Drawing.Color.Transparent
        Appearance125.ForeColor = System.Drawing.Color.FromArgb(CType(CType(10, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(130, Byte), Integer))
        Appearance125.TextHAlignAsString = "Right"
        Me.lblTDrinks.Appearance = Appearance125
        Me.lblTDrinks.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTDrinks.Location = New System.Drawing.Point(188, 602)
        Me.lblTDrinks.Name = "lblTDrinks"
        Me.lblTDrinks.Size = New System.Drawing.Size(60, 20)
        Me.lblTDrinks.TabIndex = 379
        Me.lblTDrinks.Text = "0.00"
        Me.lblTDrinks.UseAppStyling = False
        '
        'lblTCharges
        '
        Appearance126.BackColor = System.Drawing.Color.Transparent
        Appearance126.ForeColor = System.Drawing.Color.FromArgb(CType(CType(10, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(130, Byte), Integer))
        Appearance126.TextHAlignAsString = "Right"
        Me.lblTCharges.Appearance = Appearance126
        Me.lblTCharges.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTCharges.Location = New System.Drawing.Point(188, 642)
        Me.lblTCharges.Name = "lblTCharges"
        Me.lblTCharges.Size = New System.Drawing.Size(60, 20)
        Me.lblTCharges.TabIndex = 368
        Me.lblTCharges.Text = "0.00"
        Me.lblTCharges.UseAppStyling = False
        '
        'lblBillTotal
        '
        Appearance127.BackColor = System.Drawing.Color.Transparent
        Appearance127.ForeColor = System.Drawing.Color.FromArgb(CType(CType(10, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(130, Byte), Integer))
        Appearance127.TextHAlignAsString = "Right"
        Me.lblBillTotal.Appearance = Appearance127
        Me.lblBillTotal.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBillTotal.Location = New System.Drawing.Point(188, 662)
        Me.lblBillTotal.Name = "lblBillTotal"
        Me.lblBillTotal.Size = New System.Drawing.Size(60, 20)
        Me.lblBillTotal.TabIndex = 119
        Me.lblBillTotal.Text = "0.00"
        Me.lblBillTotal.UseAppStyling = False
        '
        'lblTDiscount
        '
        Appearance128.BackColor = System.Drawing.Color.Transparent
        Appearance128.ForeColor = System.Drawing.Color.FromArgb(CType(CType(10, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(130, Byte), Integer))
        Appearance128.TextHAlignAsString = "Right"
        Me.lblTDiscount.Appearance = Appearance128
        Me.lblTDiscount.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTDiscount.Location = New System.Drawing.Point(188, 622)
        Me.lblTDiscount.Name = "lblTDiscount"
        Me.lblTDiscount.Size = New System.Drawing.Size(60, 20)
        Me.lblTDiscount.TabIndex = 118
        Me.lblTDiscount.Text = "0.00"
        Me.lblTDiscount.UseAppStyling = False
        '
        'lblTSubtotal
        '
        Appearance129.BackColor = System.Drawing.Color.Transparent
        Appearance129.ForeColor = System.Drawing.Color.FromArgb(CType(CType(10, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(130, Byte), Integer))
        Appearance129.TextHAlignAsString = "Right"
        Me.lblTSubtotal.Appearance = Appearance129
        Me.lblTSubtotal.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTSubtotal.Location = New System.Drawing.Point(188, 582)
        Me.lblTSubtotal.Name = "lblTSubtotal"
        Me.lblTSubtotal.Size = New System.Drawing.Size(60, 20)
        Me.lblTSubtotal.TabIndex = 116
        Me.lblTSubtotal.Text = "0.00"
        Me.lblTSubtotal.UseAppStyling = False
        '
        'lblEntryTime
        '
        Appearance130.BackColor = System.Drawing.Color.Transparent
        Appearance130.ForeColor = System.Drawing.Color.LightGray
        Appearance130.TextHAlignAsString = "Center"
        Appearance130.TextVAlignAsString = "Bottom"
        Me.lblEntryTime.Appearance = Appearance130
        Me.lblEntryTime.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEntryTime.Location = New System.Drawing.Point(704, 693)
        Me.lblEntryTime.Name = "lblEntryTime"
        Me.lblEntryTime.Size = New System.Drawing.Size(256, 32)
        Me.lblEntryTime.TabIndex = 483
        Me.lblEntryTime.UseAppStyling = False
        '
        'EZMenuDataSet
        '
        Me.EZMenuDataSet.DataSetName = "EZMenuDataSet"
        Me.EZMenuDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'DrinksBindingSource
        '
        Me.DrinksBindingSource.DataMember = "Drinks"
        Me.DrinksBindingSource.DataSource = Me.EZMenuDataSet
        '
        'DrinksTableAdapter
        '
        Me.DrinksTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.AltAddressTableAdapter = Nothing
        Me.TableAdapterManager.Alternative_PhoneTableAdapter = Nothing
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.BankingTableAdapter = Nothing
        Me.TableAdapterManager.BankPrintTableAdapter = Nothing
        Me.TableAdapterManager.BookingsTableAdapter = Nothing
        Me.TableAdapterManager.CallerIDLogTableAdapter = Nothing
        Me.TableAdapterManager.CodesTableAdapter = Nothing
        Me.TableAdapterManager.CollectorTableAdapter = Nothing
        Me.TableAdapterManager.CustomerTableAdapter = Nothing
        Me.TableAdapterManager.DirectionsTableAdapter = Nothing
        Me.TableAdapterManager.DishTableAdapter = Nothing
        Me.TableAdapterManager.DrinksTableAdapter = Me.DrinksTableAdapter
        Me.TableAdapterManager.DriversTableAdapter = Nothing
        Me.TableAdapterManager.FreeOffersTableAdapter = Nothing
        Me.TableAdapterManager.GroupsTableAdapter = Nothing
        Me.TableAdapterManager.KitchenNotesTableAdapter = Nothing
        Me.TableAdapterManager.ModifiersTableAdapter = Nothing
        Me.TableAdapterManager.NotesDBTableAdapter = Nothing
        Me.TableAdapterManager.OffersTableAdapter = Nothing
        Me.TableAdapterManager.OrderDetailsTableAdapter = Nothing
        Me.TableAdapterManager.OrdersTableAdapter = Nothing
        Me.TableAdapterManager.SetIDTableAdapter = Nothing
        Me.TableAdapterManager.SetMealsTableAdapter = Nothing
        Me.TableAdapterManager.SetSelectedItemsTableAdapter = Nothing
        Me.TableAdapterManager.SetSelectedTableAdapter = Nothing
        Me.TableAdapterManager.SummaryTableAdapter = Nothing
        Me.TableAdapterManager.Table_BillTableAdapter = Nothing
        Me.TableAdapterManager.Table_DrinksTableAdapter = Nothing
        Me.TableAdapterManager.Table_MealTableAdapter = Nothing
        Me.TableAdapterManager.TypicalTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = EZMenu.EZMenuDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        Me.TableAdapterManager.UsersTableAdapter = Nothing
        '
        'upnlTables
        '
        Appearance131.ImageBackground = CType(resources.GetObject("Appearance131.ImageBackground"), System.Drawing.Image)
        Me.upnlTables.Appearance = Appearance131
        '
        'upnlTables.ClientArea
        '
        Me.upnlTables.ClientArea.Controls.Add(Me.UltraLabel1)
        Me.upnlTables.ClientArea.Controls.Add(Me.cmdCloseTable)
        Me.upnlTables.ClientArea.Controls.Add(Me.lblStatusBar)
        Me.upnlTables.Location = New System.Drawing.Point(0, 0)
        Me.upnlTables.Name = "upnlTables"
        Me.upnlTables.Size = New System.Drawing.Size(1000, 730)
        Me.upnlTables.TabIndex = 121
        '
        'UltraLabel1
        '
        Appearance132.BackColor = System.Drawing.Color.Transparent
        Appearance132.ForeColor = System.Drawing.Color.Teal
        Appearance132.TextHAlignAsString = "Center"
        Me.UltraLabel1.Appearance = Appearance132
        Me.UltraLabel1.AutoSize = True
        Me.UltraLabel1.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UltraLabel1.Location = New System.Drawing.Point(413, 74)
        Me.UltraLabel1.Name = "UltraLabel1"
        Me.UltraLabel1.Size = New System.Drawing.Size(174, 24)
        Me.UltraLabel1.TabIndex = 561
        Me.UltraLabel1.Text = "SELECT A TABLE"
        Me.UltraLabel1.UseAppStyling = False
        '
        'cmdCloseTable
        '
        Appearance133.BackColor = System.Drawing.Color.Transparent
        Appearance133.BackColor2 = System.Drawing.Color.Transparent
        Appearance133.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance133.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance133.BorderColor2 = System.Drawing.Color.Maroon
        Appearance133.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance133.ForeColor = System.Drawing.Color.White
        Appearance133.Image = CType(resources.GetObject("Appearance133.Image"), Object)
        Appearance133.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance133.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance133.TextVAlignAsString = "Bottom"
        Me.cmdCloseTable.Appearance = Appearance133
        Me.cmdCloseTable.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdCloseTable.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance134.BackColor = System.Drawing.Color.DarkOrange
        Appearance134.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance134.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance134.BorderColor = System.Drawing.Color.Transparent
        Appearance134.ForeColor = System.Drawing.Color.Black
        Me.cmdCloseTable.HotTrackAppearance = Appearance134
        Me.cmdCloseTable.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdCloseTable.Location = New System.Drawing.Point(928, 689)
        Me.cmdCloseTable.Name = "cmdCloseTable"
        Appearance135.BackColor = System.Drawing.Color.OrangeRed
        Appearance135.BackColor2 = System.Drawing.Color.Tomato
        Appearance135.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance135.BorderColor = System.Drawing.Color.Transparent
        Me.cmdCloseTable.PressedAppearance = Appearance135
        Me.cmdCloseTable.ShowFocusRect = False
        Me.cmdCloseTable.ShowOutline = False
        Me.cmdCloseTable.Size = New System.Drawing.Size(70, 39)
        Me.cmdCloseTable.TabIndex = 560
        Me.cmdCloseTable.Tag = "Return"
        Me.cmdCloseTable.UseAppStyling = False
        Me.cmdCloseTable.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdCloseTable.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdCloseTable.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblStatusBar
        '
        Appearance136.BackColor = System.Drawing.Color.Transparent
        Appearance136.ForeColor = System.Drawing.Color.Silver
        Appearance136.TextHAlignAsString = "Center"
        Appearance136.TextVAlignAsString = "Middle"
        Me.lblStatusBar.Appearance = Appearance136
        Me.lblStatusBar.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStatusBar.Location = New System.Drawing.Point(17, 701)
        Me.lblStatusBar.Name = "lblStatusBar"
        Me.lblStatusBar.Size = New System.Drawing.Size(659, 20)
        Me.lblStatusBar.TabIndex = 559
        Me.lblStatusBar.Tag = "0"
        Me.lblStatusBar.Text = "<status>"
        Me.lblStatusBar.UseAppStyling = False
        '
        'frmTables
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.Color.SteelBlue
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1017, 747)
        Me.ControlBox = False
        Me.Controls.Add(Me.upnlTableBill)
        Me.Controls.Add(Me.upnlTables)
        Me.Controls.Add(Me.upnlTableDrinks)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "frmTables"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.upnlTableDrinks.ClientArea.ResumeLayout(False)
        Me.upnlTableDrinks.ResumeLayout(False)
        CType(Me.ugdDrinksGrid, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.udsDrinks, System.ComponentModel.ISupportInitialize).EndInit()
        Me.upnlTableBill.ClientArea.ResumeLayout(False)
        Me.upnlTableBill.ResumeLayout(False)
        Me.upnlMiniTables.ClientArea.ResumeLayout(False)
        Me.upnlMiniTables.ResumeLayout(False)
        CType(Me.ugdTableGrid, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.udsTableGrid, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EZMenuDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DrinksBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.upnlTables.ClientArea.ResumeLayout(False)
        Me.upnlTables.ClientArea.PerformLayout()
        Me.upnlTables.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents upnlTableDrinks As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents upnlTableBill As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents lblBillHeader As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblCharges As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel2 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblDiscounts As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel4 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblTCharges As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblBillTotal As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblTDiscount As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents cmdTablePayment As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdTableKNote As Infragistics.Win.Misc.UltraButton
    Friend WithEvents lblTSubtotal As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents cmdTableKCopy As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdTableClear As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdTableTables As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdTableDrinks As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdTablePrint As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdTableEdit As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdTableClose As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdTableDiscard As Infragistics.Win.Misc.UltraButton
    Friend WithEvents udsTableGrid As Infragistics.Win.UltraWinDataSource.UltraDataSource
    Friend WithEvents ugdTableGrid As Infragistics.Win.UltraWinGrid.UltraGrid
    Friend WithEvents cmdDkClose As Infragistics.Win.Misc.UltraButton
    Friend WithEvents lblDrinksHeader As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel5 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblDrinksTotal As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents udsDrinks As Infragistics.Win.UltraWinDataSource.UltraDataSource
    Friend WithEvents ugdDrinksGrid As Infragistics.Win.UltraWinGrid.UltraGrid
    Friend WithEvents cmdDkDown As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDkUp As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDkDelete As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDkDeduct As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDkAdd As Infragistics.Win.Misc.UltraButton
    Private WithEvents EZMenuDataSet As EZMenu.EZMenuDataSet
    Friend WithEvents DrinksBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents DrinksTableAdapter As EZMenu.EZMenuDataSetTableAdapters.DrinksTableAdapter
    Friend WithEvents TableAdapterManager As EZMenu.EZMenuDataSetTableAdapters.TableAdapterManager
    Friend WithEvents cmdDkClearAll As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdCovers As Infragistics.Win.Misc.UltraButton
    Friend WithEvents lblCovers As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel6 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblTDrinks As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents cmdTableDiscounts As Infragistics.Win.Misc.UltraButton
    Friend WithEvents lblTipsLabel As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblTTips As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents cmdMoveTable As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdCAP As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdAddMiscDrink As Infragistics.Win.Misc.UltraButton
    Friend WithEvents upnlMiniTables As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents lblMiniHilit As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblEntryTime As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents cmdPrintDrinks As Infragistics.Win.Misc.UltraButton
    Friend WithEvents upnlTables As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents cmdLightsStatus As Infragistics.Win.Misc.UltraButton
    Private WithEvents lblStatusBar As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents cmdCloseTable As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraLabel1 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents cmdDkNext As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDkPrevious As Infragistics.Win.Misc.UltraButton
End Class
