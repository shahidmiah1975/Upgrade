﻿Public Class frmOrderTotals

    Private _ugdOrders As frmOrders

    Private Sub frmOrderTotals_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        _ugdOrders = Owner

        GetOrdersInfo()

    End Sub

    Private Sub GetOrdersInfo()

        Dim intDelvieries, intCollections, intTables, intTableCusts As Short
        Dim decSumCollections, decSumDeliveries, decSumTables As Decimal

        intCollections = 0 : intDelvieries = 0
        decSumCollections = 0 : decSumDeliveries = 0 : decSumTables = 0

        For Each mrow In _ugdOrders.ugdOrderGrid.Rows
            If mrow.Cells("CustomerID").Value >= intMaxCustomerID Then
                intCollections += 1
                decSumCollections += mrow.Cells("BillTotal").Value
            Else
                intDelvieries += 1
                decSumDeliveries += mrow.Cells("BillTotal").Value
            End If
        Next

        For Each mrow In _ugdOrders.ugdTableOrders.Rows
            decSumTables += mrow.Cells("BillTotal").Value
            intTableCusts += mrow.Cells("NumCust").Value
        Next
        intTables = _ugdOrders.ugdTableOrders.Rows.Count

        lblTOrders.Text = "Total orders today:  " & (intCollections + intDelvieries + intTables)
        lblTCLbl.Text = intCollections & " collections:"
        lblTColn.Text = fixCur(decSumCollections)
        lblTDLbl.Text = intDelvieries & " deliveries:"
        lblTDeliv.Text = fixCur(decSumDeliveries)
        lblTTLbl.Text = intTables & " tables (" & intTableCusts & "):"
        lblTTables.Text = fixCur(decSumTables)

        lblTTotal.Text = fixCur(decSumCollections + decSumDeliveries + decSumTables)

    End Sub
    Private Sub cmdClose_Click_1(sender As Object, e As EventArgs) Handles cmdClose.Click
        Close()
    End Sub

    'Declare the variables
    Dim drag As Boolean
    Dim mousex As Integer
    Dim mousey As Integer

    Private Sub Form1_MouseDown(sender As Object, e As MouseEventArgs) Handles Me.MouseDown
        drag = True 'Sets the variable drag to true.
        mousex = Cursor.Position.X - Left 'Sets variable mousex
        mousey = Cursor.Position.Y - Top 'Sets variable mousey
    End Sub

    Private Sub Form1_MouseMove(sender As Object, e As MouseEventArgs) Handles Me.MouseMove
        'If drag is set to true then move the form accordingly.
        If drag Then
            Top = Cursor.Position.Y - mousey
            Left = Cursor.Position.X - mousex
        End If
    End Sub

    Private Sub Form1_MouseUp(sender As Object, e As MouseEventArgs) Handles Me.MouseUp
        drag = False 'Sets drag to false, so the form does not move according to the code in MouseMove
    End Sub

End Class