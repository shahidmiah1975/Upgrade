﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmRegister
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblChallengeCode = New System.Windows.Forms.Label()
        Me.lblResponseCode = New System.Windows.Forms.Label()
        Me.cmdOK = New Infragistics.Win.Misc.UltraButton()
        Me.lblInfo = New System.Windows.Forms.Label()
        Me.txtResponse = New System.Windows.Forms.MaskedTextBox()
        Me.txtChallenge = New System.Windows.Forms.MaskedTextBox()
        Me.txtBizName = New System.Windows.Forms.MaskedTextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cmdQuit = New Infragistics.Win.Misc.UltraButton()
        Me.cmdShowKB = New Infragistics.Win.Misc.UltraButton()
        Me.cmdUpperLowerCase = New Infragistics.Win.Misc.UltraButton()
        Me.cmdUnlockOnline = New Infragistics.Win.Misc.UltraButton()
        Me.SuspendLayout()
        '
        'lblChallengeCode
        '
        Me.lblChallengeCode.AutoSize = True
        Me.lblChallengeCode.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblChallengeCode.Location = New System.Drawing.Point(20, 174)
        Me.lblChallengeCode.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblChallengeCode.Name = "lblChallengeCode"
        Me.lblChallengeCode.Size = New System.Drawing.Size(101, 16)
        Me.lblChallengeCode.TabIndex = 4
        Me.lblChallengeCode.Text = "Challenge code:"
        '
        'lblResponseCode
        '
        Me.lblResponseCode.AutoSize = True
        Me.lblResponseCode.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblResponseCode.Location = New System.Drawing.Point(20, 231)
        Me.lblResponseCode.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblResponseCode.Name = "lblResponseCode"
        Me.lblResponseCode.Size = New System.Drawing.Size(102, 16)
        Me.lblResponseCode.TabIndex = 5
        Me.lblResponseCode.Text = "Response code:"
        '
        'cmdOK
        '
        Me.cmdOK.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdOK.Location = New System.Drawing.Point(343, 290)
        Me.cmdOK.Name = "cmdOK"
        Me.cmdOK.ShowFocusRect = False
        Me.cmdOK.ShowOutline = False
        Me.cmdOK.Size = New System.Drawing.Size(82, 24)
        Me.cmdOK.TabIndex = 6
        Me.cmdOK.Text = "OK"
        '
        'lblInfo
        '
        Me.lblInfo.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblInfo.Location = New System.Drawing.Point(13, 9)
        Me.lblInfo.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblInfo.Name = "lblInfo"
        Me.lblInfo.Size = New System.Drawing.Size(508, 84)
        Me.lblInfo.TabIndex = 8
        Me.lblInfo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtResponse
        '
        Me.txtResponse.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtResponse.Location = New System.Drawing.Point(24, 251)
        Me.txtResponse.Mask = ">AAAA - AAAA - AAAA - AAAA - AAAA - AAAA - AAAA - AAAA - AAAA"
        Me.txtResponse.Name = "txtResponse"
        Me.txtResponse.Size = New System.Drawing.Size(490, 22)
        Me.txtResponse.TabIndex = 29
        '
        'txtChallenge
        '
        Me.txtChallenge.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtChallenge.Location = New System.Drawing.Point(24, 194)
        Me.txtChallenge.Mask = ">AAAA - AAAA - AAAA - AAAA - AAAA - AAAA - AAAA - AAAA"
        Me.txtChallenge.Name = "txtChallenge"
        Me.txtChallenge.ReadOnly = True
        Me.txtChallenge.Size = New System.Drawing.Size(435, 22)
        Me.txtChallenge.TabIndex = 30
        '
        'txtBizName
        '
        Me.txtBizName.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBizName.Location = New System.Drawing.Point(23, 137)
        Me.txtBizName.Name = "txtBizName"
        Me.txtBizName.Size = New System.Drawing.Size(490, 22)
        Me.txtBizName.TabIndex = 33
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(19, 117)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(102, 16)
        Me.Label1.TabIndex = 32
        Me.Label1.Text = "Business name:"
        '
        'cmdQuit
        '
        Me.cmdQuit.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdQuit.Location = New System.Drawing.Point(431, 290)
        Me.cmdQuit.Name = "cmdQuit"
        Me.cmdQuit.ShowFocusRect = False
        Me.cmdQuit.ShowOutline = False
        Me.cmdQuit.Size = New System.Drawing.Size(82, 24)
        Me.cmdQuit.TabIndex = 35
        Me.cmdQuit.Text = "Back"
        '
        'cmdShowKB
        '
        Me.cmdShowKB.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdShowKB.Location = New System.Drawing.Point(24, 290)
        Me.cmdShowKB.Name = "cmdShowKB"
        Me.cmdShowKB.ShowFocusRect = False
        Me.cmdShowKB.ShowOutline = False
        Me.cmdShowKB.Size = New System.Drawing.Size(82, 24)
        Me.cmdShowKB.TabIndex = 36
        Me.cmdShowKB.Text = "Keyboard"
        '
        'cmdUpperLowerCase
        '
        Me.cmdUpperLowerCase.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdUpperLowerCase.Location = New System.Drawing.Point(465, 193)
        Me.cmdUpperLowerCase.Name = "cmdUpperLowerCase"
        Me.cmdUpperLowerCase.ShowFocusRect = False
        Me.cmdUpperLowerCase.ShowOutline = False
        Me.cmdUpperLowerCase.Size = New System.Drawing.Size(48, 24)
        Me.cmdUpperLowerCase.TabIndex = 37
        Me.cmdUpperLowerCase.Text = "UL"
        '
        'cmdUnlockOnline
        '
        Me.cmdUnlockOnline.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdUnlockOnline.Location = New System.Drawing.Point(112, 290)
        Me.cmdUnlockOnline.Name = "cmdUnlockOnline"
        Me.cmdUnlockOnline.ShowFocusRect = False
        Me.cmdUnlockOnline.ShowOutline = False
        Me.cmdUnlockOnline.Size = New System.Drawing.Size(110, 24)
        Me.cmdUnlockOnline.TabIndex = 38
        Me.cmdUnlockOnline.Text = "Unlock Online"
        '
        'frmRegister
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(534, 326)
        Me.Controls.Add(Me.cmdUnlockOnline)
        Me.Controls.Add(Me.cmdUpperLowerCase)
        Me.Controls.Add(Me.cmdShowKB)
        Me.Controls.Add(Me.cmdQuit)
        Me.Controls.Add(Me.txtBizName)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtChallenge)
        Me.Controls.Add(Me.txtResponse)
        Me.Controls.Add(Me.lblInfo)
        Me.Controls.Add(Me.cmdOK)
        Me.Controls.Add(Me.lblResponseCode)
        Me.Controls.Add(Me.lblChallengeCode)
        Me.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Location = New System.Drawing.Point(50, 50)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmRegister"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "EZ-Menu Registration Form"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblChallengeCode As System.Windows.Forms.Label
    Friend WithEvents lblResponseCode As System.Windows.Forms.Label
    Friend WithEvents cmdOK As Infragistics.Win.Misc.UltraButton
    Friend WithEvents lblInfo As System.Windows.Forms.Label
    Friend WithEvents txtResponse As System.Windows.Forms.MaskedTextBox
    Friend WithEvents txtChallenge As System.Windows.Forms.MaskedTextBox
    Friend WithEvents txtBizName As System.Windows.Forms.MaskedTextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cmdQuit As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdShowKB As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdUpperLowerCase As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdUnlockOnline As Infragistics.Win.Misc.UltraButton
End Class
