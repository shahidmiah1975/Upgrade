﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCallerIDLog
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim Appearance13 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraGridBand1 As Infragistics.Win.UltraWinGrid.UltraGridBand = New Infragistics.Win.UltraWinGrid.UltraGridBand("Band 0", -1)
        Dim UltraGridColumn1 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("ID")
        Dim UltraGridColumn2 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("CallTime", -1, Nothing, 0, Infragistics.Win.UltraWinGrid.SortIndicator.Descending, False)
        Dim UltraGridColumn3 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Phone")
        Dim Appearance1 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraGridColumn4 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Collector")
        Dim Appearance2 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraGridColumn5 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Name")
        Dim Appearance3 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraGridColumn6 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Address")
        Dim Appearance14 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance15 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance16 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance17 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance18 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance19 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance20 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance21 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance22 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance7 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance26 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraDataColumn1 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("ID")
        Dim UltraDataColumn2 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("CallTime")
        Dim UltraDataColumn3 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("Phone")
        Dim UltraDataColumn4 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("Collector")
        Dim UltraDataColumn5 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("Name")
        Dim UltraDataColumn6 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("Address")
        Dim Appearance11 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmCallerIDLog))
        Dim Appearance12 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance25 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance62 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance63 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance64 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance33 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance34 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance35 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Me.ugdCallerIDLog = New Infragistics.Win.UltraWinGrid.UltraGrid()
        Me.udsCallLogs = New Infragistics.Win.UltraWinDataSource.UltraDataSource(Me.components)
        Me.CallerIDLogBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.EZMenuDataSet = New EZMenu.EZMenuDataSet()
        Me.cmdClose = New Infragistics.Win.Misc.UltraButton()
        Me.lblRecords = New System.Windows.Forms.Label()
        Me.CallerIDLogTableAdapter = New EZMenu.EZMenuDataSetTableAdapters.CallerIDLogTableAdapter()
        Me.cmdOGDown = New Infragistics.Win.Misc.UltraButton()
        Me.cmdOGUp = New Infragistics.Win.Misc.UltraButton()
        CType(Me.ugdCallerIDLog, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.udsCallLogs, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CallerIDLogBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EZMenuDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ugdCallerIDLog
        '
        Me.ugdCallerIDLog.DataSource = Me.udsCallLogs
        Appearance13.BackColor = System.Drawing.Color.Transparent
        Appearance13.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Me.ugdCallerIDLog.DisplayLayout.Appearance = Appearance13
        UltraGridColumn1.Header.VisiblePosition = 0
        UltraGridColumn1.Hidden = True
        UltraGridColumn2.Header.VisiblePosition = 1
        UltraGridColumn2.Width = 85
        Appearance1.TextHAlignAsString = "Center"
        UltraGridColumn3.CellAppearance = Appearance1
        UltraGridColumn3.Header.VisiblePosition = 2
        UltraGridColumn3.Width = 120
        Appearance2.TextHAlignAsString = "Center"
        UltraGridColumn4.CellAppearance = Appearance2
        UltraGridColumn4.Header.VisiblePosition = 3
        UltraGridColumn4.Width = 110
        Appearance3.TextHAlignAsString = "Center"
        UltraGridColumn5.CellAppearance = Appearance3
        UltraGridColumn5.Header.VisiblePosition = 4
        UltraGridColumn5.Width = 110
        UltraGridColumn6.CellMultiLine = Infragistics.Win.DefaultableBoolean.[True]
        UltraGridColumn6.Header.VisiblePosition = 5
        UltraGridColumn6.Width = 200
        UltraGridBand1.Columns.AddRange(New Object() {UltraGridColumn1, UltraGridColumn2, UltraGridColumn3, UltraGridColumn4, UltraGridColumn5, UltraGridColumn6})
        Me.ugdCallerIDLog.DisplayLayout.BandsSerializer.Add(UltraGridBand1)
        Me.ugdCallerIDLog.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Me.ugdCallerIDLog.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.[False]
        Appearance14.BackColor = System.Drawing.SystemColors.ActiveBorder
        Appearance14.BackColor2 = System.Drawing.SystemColors.ControlDark
        Appearance14.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance14.BorderColor = System.Drawing.SystemColors.Window
        Me.ugdCallerIDLog.DisplayLayout.GroupByBox.Appearance = Appearance14
        Appearance15.ForeColor = System.Drawing.SystemColors.GrayText
        Me.ugdCallerIDLog.DisplayLayout.GroupByBox.BandLabelAppearance = Appearance15
        Me.ugdCallerIDLog.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Appearance16.BackColor = System.Drawing.SystemColors.ControlLightLight
        Appearance16.BackColor2 = System.Drawing.SystemColors.Control
        Appearance16.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal
        Appearance16.ForeColor = System.Drawing.SystemColors.GrayText
        Me.ugdCallerIDLog.DisplayLayout.GroupByBox.PromptAppearance = Appearance16
        Me.ugdCallerIDLog.DisplayLayout.MaxColScrollRegions = 1
        Me.ugdCallerIDLog.DisplayLayout.MaxRowScrollRegions = 1
        Appearance17.BackColor = System.Drawing.Color.Orange
        Appearance17.BackColor2 = System.Drawing.Color.DarkOrange
        Appearance17.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ugdCallerIDLog.DisplayLayout.Override.ActiveRowAppearance = Appearance17
        Me.ugdCallerIDLog.DisplayLayout.Override.AllowColMoving = Infragistics.Win.UltraWinGrid.AllowColMoving.NotAllowed
        Me.ugdCallerIDLog.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted
        Me.ugdCallerIDLog.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted
        Appearance18.BackColor = System.Drawing.SystemColors.Window
        Me.ugdCallerIDLog.DisplayLayout.Override.CardAreaAppearance = Appearance18
        Appearance19.BorderColor = System.Drawing.Color.Silver
        Appearance19.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter
        Me.ugdCallerIDLog.DisplayLayout.Override.CellAppearance = Appearance19
        Me.ugdCallerIDLog.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.EditAndSelectText
        Me.ugdCallerIDLog.DisplayLayout.Override.CellPadding = 0
        Appearance20.BackColor = System.Drawing.SystemColors.Control
        Appearance20.BackColor2 = System.Drawing.SystemColors.ControlDark
        Appearance20.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element
        Appearance20.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal
        Appearance20.BorderColor = System.Drawing.SystemColors.Window
        Me.ugdCallerIDLog.DisplayLayout.Override.GroupByRowAppearance = Appearance20
        Appearance21.BackColor = System.Drawing.Color.FromArgb(CType(CType(162, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance21.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(162, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance21.TextHAlignAsString = "Center"
        Me.ugdCallerIDLog.DisplayLayout.Override.HeaderAppearance = Appearance21
        Me.ugdCallerIDLog.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti
        Me.ugdCallerIDLog.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand
        Appearance22.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.ugdCallerIDLog.DisplayLayout.Override.RowAlternateAppearance = Appearance22
        Appearance7.BackColor = System.Drawing.Color.Gainsboro
        Me.ugdCallerIDLog.DisplayLayout.Override.RowAppearance = Appearance7
        Me.ugdCallerIDLog.DisplayLayout.Override.RowSelectorHeaderStyle = Infragistics.Win.UltraWinGrid.RowSelectorHeaderStyle.SeparateElement
        Me.ugdCallerIDLog.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.[True]
        Me.ugdCallerIDLog.DisplayLayout.Override.RowSizing = Infragistics.Win.UltraWinGrid.RowSizing.Sychronized
        Me.ugdCallerIDLog.DisplayLayout.Override.RowSizingArea = Infragistics.Win.UltraWinGrid.RowSizingArea.RowBordersOnly
        Me.ugdCallerIDLog.DisplayLayout.Override.SelectTypeCol = Infragistics.Win.UltraWinGrid.SelectType.None
        Me.ugdCallerIDLog.DisplayLayout.Override.SelectTypeRow = Infragistics.Win.UltraWinGrid.SelectType.[Single]
        Appearance26.BackColor = System.Drawing.SystemColors.ControlLight
        Me.ugdCallerIDLog.DisplayLayout.Override.TemplateAddRowAppearance = Appearance26
        Me.ugdCallerIDLog.DisplayLayout.Override.WrapHeaderText = Infragistics.Win.DefaultableBoolean.[True]
        Me.ugdCallerIDLog.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill
        Me.ugdCallerIDLog.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate
        Me.ugdCallerIDLog.DisplayLayout.ViewStyle = Infragistics.Win.UltraWinGrid.ViewStyle.SingleBand
        Me.ugdCallerIDLog.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ugdCallerIDLog.Location = New System.Drawing.Point(67, 58)
        Me.ugdCallerIDLog.Name = "ugdCallerIDLog"
        Me.ugdCallerIDLog.Size = New System.Drawing.Size(667, 622)
        Me.ugdCallerIDLog.TabIndex = 361
        '
        'udsCallLogs
        '
        UltraDataColumn1.DefaultValue = ""
        Me.udsCallLogs.Band.Columns.AddRange(New Object() {UltraDataColumn1, UltraDataColumn2, UltraDataColumn3, UltraDataColumn4, UltraDataColumn5, UltraDataColumn6})
        '
        'CallerIDLogBindingSource
        '
        Me.CallerIDLogBindingSource.DataMember = "CallerIDLog"
        Me.CallerIDLogBindingSource.DataSource = Me.EZMenuDataSet
        '
        'EZMenuDataSet
        '
        Me.EZMenuDataSet.DataSetName = "EZMenuDataSet"
        Me.EZMenuDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'cmdClose
        '
        Appearance11.BackColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(120, Byte), Integer), CType(CType(36, Byte), Integer))
        Appearance11.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(30, Byte), Integer))
        Appearance11.BackGradientStyle = Infragistics.Win.GradientStyle.VerticalBump
        Appearance11.BorderColor = System.Drawing.Color.FromArgb(CType(CType(166, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance11.BorderColor2 = System.Drawing.Color.Maroon
        Appearance11.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance11.ForeColor = System.Drawing.Color.Black
        Appearance11.Image = CType(resources.GetObject("Appearance11.Image"), Object)
        Appearance11.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance11.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance11.TextVAlignAsString = "Bottom"
        Me.cmdClose.Appearance = Appearance11
        Me.cmdClose.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance12.BackColor = System.Drawing.Color.DarkOrange
        Appearance12.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance12.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance12.ForeColor = System.Drawing.Color.Black
        Me.cmdClose.HotTrackAppearance = Appearance12
        Me.cmdClose.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdClose.Location = New System.Drawing.Point(839, 603)
        Me.cmdClose.Name = "cmdClose"
        Appearance25.BackColor = System.Drawing.Color.OrangeRed
        Appearance25.BackColor2 = System.Drawing.Color.Tomato
        Appearance25.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdClose.PressedAppearance = Appearance25
        Me.cmdClose.ShowFocusRect = False
        Me.cmdClose.ShowOutline = False
        Me.cmdClose.Size = New System.Drawing.Size(70, 60)
        Me.cmdClose.TabIndex = 493
        Me.cmdClose.Tag = "Return"
        Me.cmdClose.UseAppStyling = False
        Me.cmdClose.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdClose.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdClose.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblRecords
        '
        Me.lblRecords.AutoSize = True
        Me.lblRecords.BackColor = System.Drawing.Color.Transparent
        Me.lblRecords.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRecords.ForeColor = System.Drawing.Color.DarkBlue
        Me.lblRecords.Location = New System.Drawing.Point(65, 703)
        Me.lblRecords.Name = "lblRecords"
        Me.lblRecords.Size = New System.Drawing.Size(109, 15)
        Me.lblRecords.TabIndex = 494
        Me.lblRecords.Text = "Number of calls: 0"
        '
        'CallerIDLogTableAdapter
        '
        Me.CallerIDLogTableAdapter.ClearBeforeFill = True
        '
        'cmdOGDown
        '
        Appearance62.BackColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(120, Byte), Integer), CType(CType(36, Byte), Integer))
        Appearance62.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(30, Byte), Integer))
        Appearance62.BackGradientStyle = Infragistics.Win.GradientStyle.VerticalBump
        Appearance62.BorderColor = System.Drawing.Color.FromArgb(CType(CType(166, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance62.BorderColor2 = System.Drawing.Color.Maroon
        Appearance62.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance62.ForeColor = System.Drawing.Color.Black
        Appearance62.Image = CType(resources.GetObject("Appearance62.Image"), Object)
        Appearance62.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance62.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance62.TextVAlignAsString = "Bottom"
        Me.cmdOGDown.Appearance = Appearance62
        Me.cmdOGDown.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance63.BackColor = System.Drawing.Color.DarkOrange
        Appearance63.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance63.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance63.ForeColor = System.Drawing.Color.Black
        Me.cmdOGDown.HotTrackAppearance = Appearance63
        Me.cmdOGDown.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdOGDown.Location = New System.Drawing.Point(839, 173)
        Me.cmdOGDown.Name = "cmdOGDown"
        Appearance64.BackColor = System.Drawing.Color.OrangeRed
        Appearance64.BackColor2 = System.Drawing.Color.Tomato
        Appearance64.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdOGDown.PressedAppearance = Appearance64
        Me.cmdOGDown.ShowFocusRect = False
        Me.cmdOGDown.ShowOutline = False
        Me.cmdOGDown.Size = New System.Drawing.Size(70, 60)
        Me.cmdOGDown.TabIndex = 498
        Me.cmdOGDown.Tag = "Down"
        Me.cmdOGDown.UseAppStyling = False
        Me.cmdOGDown.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOGDown.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOGDown.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdOGUp
        '
        Appearance33.BackColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(120, Byte), Integer), CType(CType(36, Byte), Integer))
        Appearance33.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(30, Byte), Integer))
        Appearance33.BackGradientStyle = Infragistics.Win.GradientStyle.VerticalBump
        Appearance33.BorderColor = System.Drawing.Color.FromArgb(CType(CType(166, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance33.BorderColor2 = System.Drawing.Color.Maroon
        Appearance33.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance33.ForeColor = System.Drawing.Color.Black
        Appearance33.Image = CType(resources.GetObject("Appearance33.Image"), Object)
        Appearance33.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance33.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance33.TextVAlignAsString = "Bottom"
        Me.cmdOGUp.Appearance = Appearance33
        Me.cmdOGUp.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance34.BackColor = System.Drawing.Color.DarkOrange
        Appearance34.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance34.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance34.ForeColor = System.Drawing.Color.Black
        Me.cmdOGUp.HotTrackAppearance = Appearance34
        Me.cmdOGUp.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdOGUp.Location = New System.Drawing.Point(839, 107)
        Me.cmdOGUp.Name = "cmdOGUp"
        Appearance35.BackColor = System.Drawing.Color.OrangeRed
        Appearance35.BackColor2 = System.Drawing.Color.Tomato
        Appearance35.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdOGUp.PressedAppearance = Appearance35
        Me.cmdOGUp.ShowFocusRect = False
        Me.cmdOGUp.ShowOutline = False
        Me.cmdOGUp.Size = New System.Drawing.Size(70, 60)
        Me.cmdOGUp.TabIndex = 497
        Me.cmdOGUp.Tag = "Up"
        Me.cmdOGUp.UseAppStyling = False
        Me.cmdOGUp.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOGUp.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOGUp.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'frmCallerIDLog
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.Color.SteelBlue
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(1000, 730)
        Me.ControlBox = False
        Me.Controls.Add(Me.cmdOGDown)
        Me.Controls.Add(Me.cmdOGUp)
        Me.Controls.Add(Me.lblRecords)
        Me.Controls.Add(Me.cmdClose)
        Me.Controls.Add(Me.ugdCallerIDLog)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "frmCallerIDLog"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        CType(Me.ugdCallerIDLog, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.udsCallLogs, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CallerIDLogBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EZMenuDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ugdCallerIDLog As Infragistics.Win.UltraWinGrid.UltraGrid
    Friend WithEvents cmdClose As Infragistics.Win.Misc.UltraButton
    Friend WithEvents lblRecords As System.Windows.Forms.Label
    Private WithEvents EZMenuDataSet As EZMenu.EZMenuDataSet
    Friend WithEvents CallerIDLogBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents CallerIDLogTableAdapter As EZMenu.EZMenuDataSetTableAdapters.CallerIDLogTableAdapter
    Friend WithEvents udsCallLogs As Infragistics.Win.UltraWinDataSource.UltraDataSource
    Friend WithEvents cmdOGDown As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdOGUp As Infragistics.Win.Misc.UltraButton
End Class
