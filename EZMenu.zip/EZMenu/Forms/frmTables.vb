﻿Imports Infragistics.Win.Misc
Imports Infragistics.Win.UltraWinDataSource
Imports EZControls
Imports VB = Microsoft.VisualBasic
Imports CustomListBox

Public Class frmTables

    Private i, j, CurCusts, intButtonAppn, intArrPos As Short
    Private arrDrinks As ArrayList = New ArrayList
    Private blnDrinksDirty As Boolean
    Private gridRowIndex As Integer

    Const constDrinkButtonAppearance = 3
    Const constDrinkButtonAppearanceGrouped = 6

    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.

    End Sub

    Private Sub frmTables_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Me.Size = frmOpener.Size
        Me.Location = frmOpener.Location

        Me.DrinksTableAdapter.Connection.ConnectionString = EZServerConnectionString
        Me.TableAdapterManager.Connection.ConnectionString = EZServerConnectionString

        upnlTables.Location = New Point(0, 0)
        upnlTableBill.Location = New Point(0, 0)
        upnlTableDrinks.Location = New Point(0, 0)

        NumberOfTables = GetAppSetting("NumberOfTables", 20)

        CreateTables()

        If GetAppSetting("DrinkDisplayMethod", "") = "GROUPED" Then
            CreateDrinksArrayGrouped()
        Else
            CreateDrinksArray()
        End If

        If Me.Tag = "DrinkAway" Then
            lblDrinksHeader.Text = "Select drinks"
            udsDrinks.Band.Columns.Add("DkQty", GetType(Short))
            udsDrinks.Band.Columns.Add("DkName", GetType(String))
            udsDrinks.Band.Columns.Add("DkPrice", GetType(Decimal))
            udsDrinks.Band.Columns.Add("DkTotal", GetType(Decimal))
            upnlTableDrinks.BringToFront()

        ElseIf Me.Tag = "DrinkAwayEdit" Then
            lblDrinksHeader.Text = "Select drinks"
            upnlTableDrinks.BringToFront()

        Else
            udsDrinks.Band.Columns.Add("DkQty", GetType(Short))
            udsDrinks.Band.Columns.Add("DkName", GetType(String))
            udsDrinks.Band.Columns.Add("DkPrice", GetType(Decimal))
            udsDrinks.Band.Columns.Add("DkTotal", GetType(Decimal))

            udsTableGrid.Band.Columns.Add("Code", GetType(String))
            udsTableGrid.Band.Columns.Add("Dish", GetType(String))
            udsTableGrid.Band.Columns.Add("Price", GetType(Decimal))
            udsTableGrid.Band.Columns.Add("Qty", GetType(String))
            udsTableGrid.Band.Columns.Add("Total", GetType(Decimal))
            udsTableGrid.Band.Columns.Add("IsStarter", GetType(Short))
            udsTableGrid.Band.Columns.Add("Discountable", GetType(Short))
            udsTableGrid.Band.Columns.Add("Mods", GetType(String))
            udsTableGrid.Band.Columns.Add("GroupIndex", GetType(Short))

            SetupButtons()

            ShowTablesInUse()

            upnlTables.BringToFront()

        End If

    End Sub

    Private Sub CreateTables()

        If NumberOfTables = 12 Then
            'create the 4x3 grid
            DrawTables(4, 3, 220, 160, 50, 25, "Tables", Me.upnlTables.ClientArea)
        ElseIf NumberOfTables = 16 Then
            'create 4x4 grid
            DrawTables(4, 4, 190, 120, 70, 20, "Tables", Me.upnlTables.ClientArea)
        ElseIf NumberOfTables = 28 Then
            'create 7x4 grid
            DrawTables(7, 4, 85, 120, 20, 20, "Tables", Me.upnlTables.ClientArea)
        Else
            'create 5x4 grid
            DrawTables(5, 4, 145, 110, 50, 25, "Tables", Me.upnlTables.ClientArea)
        End If

        CreateMiniTables()

    End Sub

    Private Sub CreateMiniTables()

        If NumberOfTables = 12 Then
            'create the 4x3 grid
            upnlMiniTables.Size = New Size(270, 205)
            upnlMiniTables.Location = New Point(390, 485)
            MiniTableGrid(4, 3, 60, 60, 5, 5, 6, 6, 14, "MiniTables", Me.upnlMiniTables.ClientArea, 12)
        ElseIf NumberOfTables = 16 Then
            'create the 4x4 grid
            upnlMiniTables.Size = New Size(250, 230)
            upnlMiniTables.Location = New Point(400, 460)
            MiniTableGrid(4, 4, 54, 50, 5, 5, 6, 6, 14, "MiniTables", Me.upnlMiniTables.ClientArea, 16)
        ElseIf NumberOfTables = 28 Then
            'create 7x4 grid
            upnlMiniTables.Size = New Size(340, 284)
            upnlMiniTables.Location = New Point(357, 400)
            MiniTableGrid(6, 5, 50, 50, 5, 5, 6, 6, 14, "MiniTables", Me.upnlMiniTables.ClientArea, 28)
        Else
            'create 5x4 grid
            upnlMiniTables.Size = New Size(287, 230)
            upnlMiniTables.Location = New Point(380, 450)
            MiniTableGrid(5, 4, 50, 50, 5, 5, 6, 6, 14, "MiniTables", Me.upnlMiniTables.ClientArea, 20)
        End If

        i = 1
        For Each myObj As Control In Me.upnlMiniTables.ClientArea.Controls
            If myObj.Name = "MiniTables" Then
                AddHandler myObj.Click, AddressOf MiniTableClickEvent
                myObj.Text = i
                i += 1
            End If
        Next

    End Sub

    Private Sub DrawTables(ByVal nRows As Short, ByVal nCols As Short, ByVal xStart As Short, ByVal yStart As Short,
                           ByVal xGap As Short, ByVal yGap As Short, ByVal strCtrlName As String, ByVal ctrlControl As Control)

        Dim xLoc, yLoc, iX As Short

        iX = 1
        For jCol As Short = 0 To (nCols - 1)
            For iRow As Short = 0 To (nRows - 1)
                Dim meBut As New EZTableButton.EZTableButton
                xLoc = xStart + (iRow * (meBut.Width + xGap))
                yLoc = yStart + (jCol * (meBut.Height + yGap))
                meBut.Location = New Point(xLoc, yLoc)
                meBut.Name = strCtrlName
                meBut.TableNumber = iX
                If TypeName(ctrlControl) = "UltraPanel" Then
                    Dim ctrlCArea = DirectCast(ctrlControl, UltraPanel)
                    ctrlCArea.ClientArea.Controls.Add(meBut)
                Else
                    ctrlControl.Controls.Add(meBut)
                End If
                meBut.Parent = ctrlControl
                meBut.ClearTable()
                meBut.TopBarVisible = False
                meBut.Visible = True
                AddHandler meBut.Click, AddressOf TableClickEvent
                iX += 1
            Next
        Next

    End Sub

    Public Sub MiniTableGrid(ByVal nRows As Short, ByVal nCols As Short, ByVal bWidth As Short, ByVal bHeight As Short, ByVal xStart As Short,
                             ByVal yStart As Short, ByVal xGap As Short, ByVal yGap As Short, ByVal ftSize As Short, ByVal strCtrlName As String,
                             ByVal ctrlControl As Control, Optional ByVal intMaxButtons As Integer = 0)

        Dim iRow, jCol, xLoc, yLoc, intButtonCntr As Short

        intButtonCntr = 0

        For jCol = 0 To (nCols - 1)
            For iRow = 0 To (nRows - 1)

                Dim meBut As New UltraButton

                With meBut
                    .Font = New System.Drawing.Font("Arial", ftSize, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
                    .Name = strCtrlName
                    .ShowFocusRect = False
                    .ShowOutline = False
                    .Size = New System.Drawing.Size(bWidth, bHeight)
                    .UseAppStyling = False
                    .UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
                    .UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
                    .UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
                    With .Appearance
                        .ImageBackground = My.Resources.ezresource.minitable
                        .BackColor = Color.Transparent
                        .BorderColor = Color.Transparent
                        .ForeColor = Color.White
                        .TextVAlign = Infragistics.Win.VAlign.Middle
                    End With
                End With

                xLoc = xStart + (iRow * (bWidth + xGap))
                yLoc = yStart + (jCol * (bHeight + yGap))
                meBut.Location = New Point(xLoc, yLoc)
                intButtonCntr += 1
                If TypeName(ctrlControl) = "UltraPanel" Then
                    Dim ctrlCArea = DirectCast(ctrlControl, UltraPanel)
                    ctrlCArea.ClientArea.Controls.Add(meBut)
                Else
                    ctrlControl.Controls.Add(meBut)
                End If
                If intMaxButtons <> 0 Then
                    If intButtonCntr = intMaxButtons Then
                        Exit For
                    End If
                End If
            Next
        Next

    End Sub

    Private Sub SetupButtons()

        For Each myobjx In Me.upnlTableBill.ClientArea.Controls
            If (TypeName(myobjx) = "UltraButton" AndAlso myobjx.width = 126) Then
                Dim myObj As UltraButton = DirectCast(myobjx, UltraButton)
                myObj.Tag = myObj.Text
                If GetAppSetting("ShowLabelText", 0) = 0 Then myObj.Text = String.Empty
                myObj.Appearance.ImageVAlign = Infragistics.Win.VAlign.Middle
                AddHandler myObj.MouseEnter, AddressOf ButtonMouseEnter
                AddHandler myObj.MouseLeave, AddressOf ButtonMouseLeave
            End If
        Next

        For Each myobjx In Me.upnlTableDrinks.ClientArea.Controls
            If (TypeName(myobjx) = "UltraButton" AndAlso myobjx.width = 126) Then
                Dim myObj As UltraButton = DirectCast(myobjx, UltraButton)
                myObj.Tag = myObj.Text
                If GetAppSetting("ShowLabelText", 0) = 0 Then myObj.Text = String.Empty
                myObj.Appearance.ImageVAlign = Infragistics.Win.VAlign.Middle
                AddHandler myObj.MouseEnter, AddressOf ButtonMouseEnter
                AddHandler myObj.MouseLeave, AddressOf ButtonMouseLeave
            End If
        Next

        cmdLightsStatus.Enabled = RegistryHasValue("TablesExtMode")

        'cmdTablesToMain.Tag = cmdTablesToMain.Text
        'If GetAppSetting("ShowLabelText", 0) = 0 Then cmdTablesToMain.Text = String.Empty
        'cmdTablesToMain.Appearance.ImageVAlign = Infragistics.Win.VAlign.Middle
        'AddHandler cmdTablesToMain.MouseEnter, AddressOf ButtonMouseEnter
        'AddHandler cmdTablesToMain.MouseLeave, AddressOf ButtonMouseLeave

    End Sub

    Private Sub ButtonMouseEnter(ByVal sender As System.Object, ByVal e As System.EventArgs)
        sender.text = sender.tag
    End Sub

    Private Sub ButtonMouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs)

        If GetAppSetting("ShowLabelText", 0) = 0 Then sender.Text = String.Empty
        sender.Appearance.ImageVAlign = Infragistics.Win.VAlign.Middle

    End Sub

    Private Sub TableClickEvent(ByVal sender As EZTableButton.EZTableButton, ByVal e As System.EventArgs)
        GetTableInfo(sender.TableNumber)
    End Sub

    Private Sub MiniTableClickEvent(ByVal sender As UltraButton, ByVal e As System.EventArgs)

        If upnlTableBill.Tag = "MoveModeOn" Then
            SQLQuery = String.Format("UPDATE Table_Bill SET TableNumber = {0} WHERE TabUniqueID = {1}", sender.Text, TableInfo(CurTable).Id)
            ExeNonQuery(SQLQuery)

            SetTableColour(CurTable, False)
            SetTableColour(CShort(sender.Text), True)

            TableInfo(CShort(sender.Text)).Id = TableInfo(CurTable).Id
            TableInfo(CurTable).Id = 0
            TableInfo(CShort(sender.Text)).Status = TableInfo(CurTable).Status
            TableInfo(CurTable).Status = TStatus.Clean
            CurTable = CShort(sender.Text)
            RestoreTables()
        End If

        GetTableInfo(sender.Text)
        ResetMiniTableBackground()
        MiniHilit(sender)

    End Sub

    Private Sub ResetMiniTableBackground()

        For Each myObj In Me.upnlMiniTables.ClientArea.Controls
            If (TypeOf myObj Is UltraButton) Then
                Dim ubtnTemp As UltraButton = DirectCast(myObj, UltraButton)
                ubtnTemp.Appearance.BackColor = Color.Transparent
            End If
        Next

    End Sub

    Private Sub cmdTableTables_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdTableTables.Click

        upnlTables.BringToFront()

        If RegistryHasValue("TablesExtMode") Then
            Application.DoEvents()
            For Each myObj As Control In upnlTables.ClientArea.Controls
                If myObj.Name.Contains("Tables") Then
                    Dim myObjx As EZTableButton.EZTableButton = DirectCast(myObj, EZTableButton.EZTableButton)
                    If myObjx.Status <> EZTableButton.EZTableButton.StatusType.Clean Then
                        myObjx.UpdateLabel()
                        myObjx.Refresh()
                    End If
                End If
            Next
            UpdateStatusBarText()
        End If

    End Sub

    Private Sub cmdTableDrinks_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdTableDrinks.Click
        upnlTableDrinks.BringToFront()
    End Sub

    Private Sub cmdDkClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdDkClose.Click
        'update the bill with drinks selected and close this window

        If Me.Tag = "DrinkAway" Or Me.Tag = "DrinkAwayEdit" Then

            With objOrderEntry
                .lblDrinksOE.Text = lblDrinksTotal.Text
                .lblDrinksOE.Visible = (ugdDrinksGrid.Rows.Count > 0)
                .lblDrinksOELbl.Visible = (ugdDrinksGrid.Rows.Count > 0)
            End With
            'Me.Tag = Nothing
            Me.Hide()
            AddUpGridTotals()

        Else

            'color table
            If udsTableGrid.Rows.Count > 0 Or lblDrinksTotal.Text <> "0.00" Then
                If TableInfo(CurTable).Id = 0 Then AssignUniqueID(CurTable)
                If TableInfo(CurTable).Status = TStatus.Clean Then SetTableStatus(1)
                SetTableColour(CurTable, True)
            Else
                DeleteUniqueID()
                SetTableColour(CurTable, False)
            End If

            InsertDrinksToDB()
            lblTDrinks.Text = lblDrinksTotal.Text
            lblBillTotal.Text = fixCur(CalcSubTotal)
            DisplayAllTotals()

            If lblEntryTime.Text = String.Empty Then
                SQLQuery = "SELECT EntryTime FROM Table_Bill WHERE TabUniqueID = " & TableInfo(CurTable).Id
                drDataRow = objDB.GetSingleRow(SQLQuery)
                If drDataRow IsNot Nothing AndAlso drDataRow!EntryTime.ToString <> "00:00:00" Then
                    Dim TSpan As TimeSpan = Now - CDate(drDataRow!EntryTime.ToString)
                    tempStr = String.Format("Time of entry: {0}" & vbCrLf & "({1}:{2})",
                                  Format(CDate(drDataRow!EntryTime.ToString), "h:mm"),
                                  TSpan.Hours.ToString("D1"), TSpan.Minutes.ToString("D2"))
                    lblEntryTime.Text = tempStr
                End If
            End If

            upnlTableBill.BringToFront()
            Application.DoEvents()

            If GetAppSetting("DrinkDisplayMethod", "") = "GROUPED" AndAlso cmdDkPrevious.Enabled = True Then
                NavDrinksGrouped("cmdDkPrevious", True, 0)
            End If

        End If

    End Sub

    Private Sub InsertDrinksToDB()

        Dim Dk_Name, Dk_Price, Dk_Qty As String

        If blnDrinksDirty = True Then

            'first delete existing drinks from the table
            SQLQuery = "DELETE FROM Table_Drinks WHERE TabUniqueID = " & TableInfo(CurTable).Id
            ExeNonQuery(SQLQuery)

            'now insert the drinks in the DB table
            With ugdDrinksGrid
                For Each mrow In .Rows
                    gridRowIndex = mrow.Index
                    Dk_Name = .Rows(gridRowIndex).Cells("DkName").Value().ToString.Punctuate
                    Dk_Qty = .Rows(gridRowIndex).Cells("DkQty").Value()
                    Dk_Price = .Rows(gridRowIndex).Cells("DkPrice").Value()
                    SQLQuery = "INSERT INTO Table_Drinks (TabUniqueID, DkName, DkQty, DkPrice) " &
                               "VALUES (" & TableInfo(CurTable).Id & ",'" & Dk_Name & "','" & Dk_Qty & "','" & Dk_Price & "');"

                    'execute the SQL command
                    ExeNonQuery(SQLQuery)
                Next
            End With
            blnDrinksDirty = False
        End If

    End Sub

    Private Sub DrinkClickEvent(ByVal sender As UltraButton, ByVal e As System.EventArgs)

        Dim ubtnDrink As UltraButton = sender

        If ubtnDrink.Text = String.Empty Or ubtnDrink.Tag.ToString = "x" Then Exit Sub

        If UpdateDrinkInGrid(ubtnDrink.Text) = True Then
            'nothing to do here
        Else
            Dim myRow As UltraDataRow = udsDrinks.Rows.Add()
            myRow.Item("DkQty") = "1"
            myRow.Item("DkName") = ubtnDrink.Text.Replace("&&", "&").Punctuate
            myRow.Item("DkPrice") = ubtnDrink.Tag
            myRow.Item("DkTotal") = fixCur(ubtnDrink.Tag)
        End If

        ugdDrinksGrid.SuspendLayout()
        ugdDrinksGrid.DataSource = udsDrinks
        If ugdDrinksGrid.Rows.Count > 0 Then
            ugdDrinksGrid.ActiveRow = ugdDrinksGrid.Rows(0)
        Else
            ugdDrinksGrid.ActiveRow = Nothing
        End If
        ugdDrinksGrid.ResumeLayout()
        ugdDrinksGrid.Refresh()

        AddupDrinksTotal()
        UpdateDrinkRank(ubtnDrink.Text)
        blnDrinksDirty = True

    End Sub

    Private Function UpdateDrinkInGrid(ByVal strItem As String) As Boolean
        'returns True if item is found in grid and updated

        For Each mRow As UltraDataRow In udsDrinks.Rows
            tempStr = mRow.Item("DkName")
            If UCase(strItem) = UCase(tempStr) Then
                mRow.Item("DkQty") += 1
                mRow.Item("DkTotal") = fixCur(mRow.Item("DkQty") * mRow.Item("DkPrice"))
                Return True
            End If
        Next

        Return False

    End Function

    Private Sub AddupDrinksTotal()

        Dim decDkTotal As Decimal = 0

        For Each mRow As UltraDataRow In udsDrinks.Rows
            decDkTotal += mRow.Item("DkTotal")
        Next

        lblDrinksTotal.Text = fixCur(decDkTotal)

    End Sub

    Private Sub UpdateDrinkRank(ByVal strDrinkName As String)

        SQLQuery = String.Format("UPDATE Drinks SET Rank = Rank + 1 WHERE Name = '{0}'", strDrinkName.Punctuate)
        ExeNonQuery(SQLQuery)

    End Sub

    Private Sub cmdDkUpDown_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdDkUp.Click, cmdDkDown.Click

        If ugdDrinksGrid.Rows.Count > 0 Then
            If ugdDrinksGrid.ActiveRow Is Nothing Then ugdDrinksGrid.ActiveRow = ugdDrinksGrid.Rows(0)
            If sender.name = "cmdDkUp" Then
                If ugdDrinksGrid.ActiveRow.Index > 0 Then
                    ugdDrinksGrid.ActiveRow = ugdDrinksGrid.Rows(ugdDrinksGrid.ActiveRow.Index - 1)
                Else
                    ugdDrinksGrid.ActiveRow = ugdDrinksGrid.Rows(ugdDrinksGrid.Rows.Count - 1)
                End If
            Else
                If ugdDrinksGrid.ActiveRow.Index < ugdDrinksGrid.Rows.Count - 1 Then
                    ugdDrinksGrid.ActiveRow = ugdDrinksGrid.Rows(ugdDrinksGrid.ActiveRow.Index + 1)
                Else
                    ugdDrinksGrid.ActiveRow = ugdDrinksGrid.Rows(0)
                End If
            End If
        End If

    End Sub

    Private Sub cmdDkAddDeductDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdDkAdd.Click, cmdDkDeduct.Click, cmdDkDelete.Click

        If ugdDrinksGrid.ActiveRow Is Nothing Then Exit Sub

        If sender.name = "cmdDkAdd" Then
            ugdDrinksGrid.ActiveRow.Cells("DkQty").Value += 1
            ugdDrinksGrid.ActiveRow.Cells("DkTotal").Value = fixCur(ugdDrinksGrid.ActiveRow.Cells("DkQty").Value * ugdDrinksGrid.ActiveRow.Cells("DkPrice").Value)
        ElseIf sender.name = "cmdDkDeduct" Then
            If ugdDrinksGrid.ActiveRow.Cells("DkQty").Value > 1 Then
                ugdDrinksGrid.ActiveRow.Cells("DkQty").Value -= 1
                ugdDrinksGrid.ActiveRow.Cells("DkTotal").Value = fixCur(ugdDrinksGrid.ActiveRow.Cells("DkQty").Value * ugdDrinksGrid.ActiveRow.Cells("DkPrice").Value)
            End If
        Else
            With ugdDrinksGrid
                If .Rows.Count > 0 AndAlso .ActiveRow IsNot Nothing Then
                    .ActiveRow.Delete(False)
                    AddupDrinksTotal()
                End If
            End With
        End If

        AddupDrinksTotal()

        blnDrinksDirty = True

    End Sub

    Private Sub CreateDrinksArray()

        Dim intNumDrinks, gridRows, iCnt, maxCols As Short
        Dim leftOffSet, topOffSet, intOpt As Short
        Dim dttDataTable As New DataTable
        Dim ubtnTemp As New UltraButton

        gridRows = 14
        maxCols = 4
        leftOffSet = 15
        topOffSet = 62

        'get values from the DB
        If GetAppSetting("DrinkDisplayMethod", "") = "ALPHA" Then
            Me.DrinksTableAdapter.FillByAlpha(Me.EZMenuDataSet.Drinks)
        ElseIf GetAppSetting("DrinkDisplayMethod", "") = "RANK" Then
            Me.DrinksTableAdapter.FillByRank(Me.EZMenuDataSet.Drinks)
        Else
            Me.DrinksTableAdapter.FillByNumeric(Me.EZMenuDataSet.Drinks)
        End If

        dttDataTable = Me.EZMenuDataSet.Drinks

        intNumDrinks = Me.DrinksBindingSource.Count
        If intNumDrinks > 0 Then
            i = 0 : j = 1
            DrinksBindingSource.MoveFirst()
            For iCnt = 1 To intNumDrinks
                intOpt = constDrinkButtonAppearance
                ubtnTemp = New UltraButton
                With ubtnTemp
                    tempStr = dttDataTable.Rows(iCnt - 1).Item("Name").ToString.Trim
                    tempStr = Replace(tempStr, "&", "&&")
                    If tempStr.IndexOf(">>") > -1 Then
                        intOpt = constDrinkButtonAppearanceGrouped
                        .Text = tempStr.Substring(2)
                        .Tag = "x"
                    Else
                        .Text = tempStr
                        .Tag = dttDataTable.Rows(iCnt - 1).Item("Price")
                    End If
                    DrinksButtonsAppearance(ubtnTemp, intOpt)
                    .Top = topOffSet + ((j - 1) * (ubtnTemp.Height + 1))
                    .Left = leftOffSet + (i * (ubtnTemp.Width + 1))
                End With
                AddHandler ubtnTemp.Click, AddressOf DrinkClickEvent
                upnlTableDrinks.ClientArea.Controls.Add(ubtnTemp)
                DrinksBindingSource.MoveNext()
                If (j Mod gridRows) = 0 Then
                    i = i + 1
                    j = 0
                    If i >= maxCols Then Exit For
                End If
                j = j + 1
            Next

            cmdDkPrevious.Enabled = False
            cmdDkNext.Enabled = (intNumDrinks > 56)
            upnlTableDrinks.ClientArea.ResumeLayout()

        Else

            DrinksErrMsg()

        End If

    End Sub

    Private Sub CreateDrinksArrayGrouped()

        Dim ubtnTemp As New UltraButton
        Dim intNumDrinks, gridRows, iCnt, maxCols As Short
        Dim leftOffSet, topOffSet As Short

        gridRows = 14
        maxCols = 4
        leftOffSet = 15
        topOffSet = 62

        Dim drcDkGroup As DataRowCollection = objDB.GetDataRows("SELECT DISTINCT DkGroup FROM Drinks ORDER BY DkGroup")
        If drcDkGroup IsNot Nothing Then
            For Each myRow As DataRow In drcDkGroup
                arrDrinks.Add(">>" & myRow!DkGroup)
                'get all drinks from group
                SQLQuery = String.Format("SELECT CASE WHEN [Name] = '<blank>' THEN 'ZZZZ' ELSE [Name] END AS [Name], Price FROM Drinks WHERE DkGroup = '{0}' ORDER BY [Name]", myRow!DkGroup, strBlankDrinkField)
                drcDatarowCollection = objDB.GetDataRows(SQLQuery)
                If drcDatarowCollection IsNot Nothing Then
                    For Each myGroup As DataRow In drcDatarowCollection
                        arrDrinks.Add(myGroup!Name & "~" & myGroup!Price)
                    Next
                End If
            Next
        End If

        intNumDrinks = arrDrinks.Count
        If intNumDrinks > 0 Then
            i = 0 : j = 1
            For iCnt = 0 To intNumDrinks - 1
                intButtonAppn = constDrinkButtonAppearance
                ubtnTemp = New UltraButton
                With ubtnTemp
                    tempStr = arrDrinks(iCnt).ToString.Trim
                    'tempStr = Replace(tempStr, "&", "&&")
                    If tempStr.IndexOf(">>") > -1 Then
                        intButtonAppn = constDrinkButtonAppearanceGrouped
                        .Text = tempStr.Substring(2).ToUpper
                        .Tag = "x"
                    ElseIf tempStr.ToUpper.Substring(0, 4) = "ZZZZ" Then
                        .Text = String.Empty
                        .Tag = "x"
                    Else
                        .Text = tempStr.Substring(0, tempStr.IndexOf("~"))
                        .Tag = tempStr.Substring(tempStr.IndexOf("~") + 1)
                    End If
                    DrinksButtonsAppearance(ubtnTemp, intButtonAppn)
                    If .Tag = "x" Then
                        .PressedAppearance = Nothing
                        .HotTrackAppearance = Nothing
                    End If
                    .Top = topOffSet + ((j - 1) * (ubtnTemp.Height + 1))
                    .Left = leftOffSet + (i * (ubtnTemp.Width + 1))
                End With
                AddHandler ubtnTemp.Click, AddressOf DrinkClickEvent
                upnlTableDrinks.ClientArea.Controls.Add(ubtnTemp)

                intArrPos = iCnt + 1
                If (j Mod gridRows) = 0 Then
                    i = i + 1
                    j = 0
                    If i >= maxCols Then Exit For
                End If
                j = j + 1
            Next

            cmdDkPrevious.Enabled = False
            cmdDkNext.Enabled = (arrDrinks.Count > 56)
            upnlTableDrinks.ClientArea.ResumeLayout()

        Else

            DrinksErrMsg()

        End If

    End Sub

    Private Sub DrinksErrMsg()

        Dim lblError As New UltraLabel
        With lblError
            .Text = "No drinks have been found in the database."
            .AutoSize = True
            .Appearance.FontData.SizeInPoints = 12
            .Appearance.ForeColor = Color.White
            .Appearance.BackColor = Color.Transparent
            .Visible = True
            .UseAppStyling = False
            upnlTableDrinks.ClientArea.Controls.Add(lblError)
            .Location = New Point(150, (Me.Height - .Height) / 2)
        End With

    End Sub

    Private Sub DrinksButtonsAppearance(ByVal btnName As UltraButton, Optional ByVal intGroup As Short = 3)

        With btnName

            .Appearance = GetButtonAppearances(intGroup)
            If intGroup = constDrinkButtonAppearance Then
                .Appearance.ImageBackground = My.Resources.ezresource.dkbutton
            Else
                .Appearance.ImageBackground = My.Resources.ezresource.dkbutton_group
            End If
            .HotTrackAppearance = GetButtonAppearances(1)
            .HotTrackAppearance.ForeColor = Color.Wheat
            .HotTrackAppearance.ImageBackground = My.Resources.ezresource.dkbutton_hilit
            .PressedAppearance = GetButtonAppearances(5)
            .PressedAppearance.ImageBackground = My.Resources.ezresource.dkbutton_press

            .Font = New Font("Franklin Gothic Medium", GetAppSetting("FontSizeDrinksArray", 10), FontStyle.Regular, GraphicsUnit.Point, CType(0, Byte))
            .Name = "DrinksName"
            .ShowFocusRect = False
            .ShowOutline = False
            .Size = New Size(153, 43)
            .UseAppStyling = False
            .UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
            .UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
            .UseMnemonic = False
            .UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]

        End With

    End Sub

    Private Sub DrinkNextPrevious(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdDkPrevious.Click, cmdDkNext.Click

        If GetAppSetting("DrinkDisplayMethod", "") = "GROUPED" Then
            NavDrinksGrouped(sender.name)
        Else
            NavDrinks(sender.name)
        End If

    End Sub

    Private Sub NavDrinks(strButtonText As String)

        Dim blnBlankRest, blnExitLoop As Boolean
        Dim dttDataTable As New DataTable

        blnBlankRest = False
        dttDataTable = Me.EZMenuDataSet.Drinks

        If strButtonText = "cmdDkNext" Then

            upnlTableDrinks.SuspendLayout()

            For Each myobjx In Me.upnlTableDrinks.ClientArea.Controls
                If (myobjx.name = "DrinksName") Then
                    If blnBlankRest = True Then
                        myobjx.Visible = False
                        cmdDkNext.Enabled = False
                    Else
                        myobjx.Text = dttDataTable.Rows(DrinksBindingSource.Position).Item("Name")
                        myobjx.Tag = dttDataTable.Rows(DrinksBindingSource.Position).Item("Price")
                        myobjx.Visible = True
                        If DrinksBindingSource.Position + 1 < DrinksBindingSource.Count Then
                            DrinksBindingSource.MoveNext()
                        Else
                            blnBlankRest = True
                        End If
                    End If
                End If
            Next

            cmdDkPrevious.Enabled = True
            cmdDkNext.Enabled = Not blnBlankRest

            upnlTableDrinks.ResumeLayout()

        ElseIf strButtonText = "cmdDkPrevious" Then

            'move position of the record collection
            tempVal = DrinksBindingSource.Position Mod 56
            If tempVal = 0 Then tempVal = 56
            DrinksBindingSource.Position = DrinksBindingSource.Position - tempVal - 56

            cmdDkPrevious.Enabled = (DrinksBindingSource.Position > 0)
            upnlTableDrinks.SuspendLayout()

            For Each myobjx In Me.upnlTableDrinks.ClientArea.Controls
                If blnExitLoop = True Then
                    Exit For
                ElseIf (myobjx.name = "DrinksName") Then
                    myobjx.Text = dttDataTable.Rows(DrinksBindingSource.Position).Item("Name")
                    myobjx.Tag = dttDataTable.Rows(DrinksBindingSource.Position).Item("Price")
                    myobjx.Visible = True
                    If DrinksBindingSource.Position + 1 < DrinksBindingSource.Count Then
                        DrinksBindingSource.MoveNext()
                    Else
                        blnExitLoop = True
                    End If
                End If
            Next

            cmdDkNext.Enabled = (DrinksBindingSource.Position < DrinksBindingSource.Count)

            upnlTableDrinks.ResumeLayout()

        End If

    End Sub

    Private Sub NavDrinksGrouped(strButtonText As String, Optional blnSuspendLayout As Boolean = True, Optional intStartingPos As Short = -1)

        Dim blnBlankRest, blnExitLoop As Boolean

        If strButtonText = "cmdDkNext" Then

            If blnSuspendLayout = True Then upnlTableDrinks.SuspendLayout()

            For Each myobjx In Me.upnlTableDrinks.ClientArea.Controls
                If (myobjx.name = "DrinksName") Then
                    If blnBlankRest = True Then
                        myobjx.Visible = False
                        cmdDkNext.Enabled = False
                    Else
                        tempStr = arrDrinks(intArrPos).ToString.Trim
                        If tempStr.IndexOf(">>") > -1 Then
                            myobjx.Text = tempStr.Substring(2).ToUpper
                            myobjx.Tag = "x"
                            intButtonAppn = constDrinkButtonAppearanceGrouped
                        Else
                            myobjx.Text = tempStr.Substring(0, tempStr.IndexOf("~"))
                            myobjx.Tag = tempStr.Substring(tempStr.IndexOf("~") + 1)
                            intButtonAppn = constDrinkButtonAppearance
                        End If

                        DrinksButtonsAppearance(myobjx, intButtonAppn)
                        If myobjx.Tag = "x" Then
                            myobjx.PressedAppearance = Nothing
                            myobjx.HotTrackAppearance = Nothing
                        End If
                        myobjx.Visible = True
                        If intArrPos + 1 < arrDrinks.Count Then
                            intArrPos += 1
                        Else
                            blnBlankRest = True
                        End If
                    End If
                End If
            Next

            cmdDkPrevious.Enabled = True
            cmdDkNext.Enabled = Not blnBlankRest

            If blnSuspendLayout = True Then upnlTableDrinks.ResumeLayout()

        ElseIf strButtonText = "cmdDkPrevious" Then

            'move record position backwards
            If intStartingPos = 0 Then
                intArrPos = 0
            Else
                tempVal = intArrPos Mod 56
                If tempVal = 0 Then tempVal = 56
                intArrPos = intArrPos - tempVal - 56
            End If

            cmdDkPrevious.Enabled = (intArrPos > 0)
            If blnSuspendLayout = True Then upnlTableDrinks.SuspendLayout()

            For Each myobjx In Me.upnlTableDrinks.ClientArea.Controls
                If blnExitLoop = True Then
                    Exit For
                ElseIf (myobjx.name = "DrinksName") Then

                    tempStr = arrDrinks(intArrPos).ToString.Trim
                    If tempStr.IndexOf(">>") > -1 Then
                        myobjx.Text = tempStr.Substring(2).ToUpper
                        myobjx.Tag = "x"
                        intButtonAppn = constDrinkButtonAppearanceGrouped
                    Else
                        myobjx.Text = tempStr.Substring(0, tempStr.IndexOf("~"))
                        myobjx.Tag = tempStr.Substring(tempStr.IndexOf("~") + 1)
                        intButtonAppn = constDrinkButtonAppearance
                    End If

                    DrinksButtonsAppearance(myobjx, intButtonAppn)

                    If myobjx.Tag = "x" Then
                        myobjx.PressedAppearance = Nothing
                        myobjx.HotTrackAppearance = Nothing
                    End If
                    myobjx.visible = True
                    If intArrPos + 1 < arrDrinks.Count Then
                        intArrPos += 1
                    Else
                        blnExitLoop = True
                    End If

                End If
            Next

            cmdDkNext.Enabled = (intArrPos < arrDrinks.Count)
            If blnSuspendLayout = True Then upnlTableDrinks.ResumeLayout()

        End If

    End Sub

    Private Sub cmdDkClearAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdDkClearAll.Click

        strMsgBox = "Clear all drinks in the list?"
        intMsgBoxResult = EZMsgBox.Show(strMsgBox, MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If intMsgBoxResult = MsgBoxResult.Yes Then ClearDrinksGrid()

    End Sub

    Private Sub cmdTablesClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdTableClose.Click

        Try
            If blnDisposeOE = True Then
                objOrderEntry.Dispose()
                blnDisposeOE = False
            End If
        Catch ex As Exception
            DisplayError(ex)
        End Try

        Me.Hide()

    End Sub

    Private Sub cmdTableClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdTableClear.Click

        strMsgBox = "Clear everything and start a new bill?"
        intMsgBoxResult = EZMsgBox.Show(strMsgBox, MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If intMsgBoxResult = MsgBoxResult.Yes Then

            'clear the grid
            udsDrinks.Rows.Clear()
            udsTableGrid.Rows.Clear()
            ugdDrinksGrid.Update()
            ugdTableGrid.Update()

            'remove colour from the button for this table
            SetTableColour(CurTable, False)

            'do not delete from DB if it is printed, save it
            If TableInfo(CurTable).Status = TStatus.Printed Then

                'set saved status
                SetTableStatus(3)

                'has not been printed so delete it
            ElseIf TableInfo(CurTable).Status < 2 Then

                'delete from meals table
                SQLQuery = "DELETE FROM Table_Meal WHERE TabUniqueID = " & TableInfo(CurTable).Id & ";"
                ExeNonQuery(SQLQuery)

                'delete from drinks table
                SQLQuery = "DELETE FROM Table_Drinks WHERE TabUniqueID = " & TableInfo(CurTable).Id & ";"
                ExeNonQuery(SQLQuery)

                DeleteUniqueID()

            End If

            'reset the Id
            TableInfo(CurTable).Id = 0
            TableInfo(CurTable).Status = TStatus.Clean

            upnlTables.BringToFront()
            If RegistryHasValue("TablesExtMode") Then UpdateStatusBarText()

        End If

    End Sub

    Private Sub cmdTableDiscard_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdTableDiscard.Click

        strMsgBox = "Completely discard this bill?" & vbCrLf & "(You will not be able to recover this info)"
        intMsgBoxResult = EZMsgBox.Show(strMsgBox, MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        If intMsgBoxResult = MsgBoxResult.Yes Then

            'delete everything from the DB about this table
            SQLQuery = "DELETE FROM Table_Drinks WHERE TabUniqueID = " & TableInfo(CurTable).Id & ";"
            ExeNonQuery(SQLQuery)

            SQLQuery = "DELETE FROM Table_Meal WHERE TabUniqueID = " & TableInfo(CurTable).Id & ";"
            ExeNonQuery(SQLQuery)

            SQLQuery = "DELETE FROM Table_Bill WHERE TabUniqueID = " & TableInfo(CurTable).Id & ";"
            ExeNonQuery(SQLQuery)

            SetTableColour(CurTable, False)
            DeleteUniqueID()

            upnlTables.BringToFront()

        End If

    End Sub

    Private Sub cmdTableEdit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdTableEdit.Click

        Try

            'assign unique id if required
            If TableInfo(CurTable).Id = 0 Then AssignUniqueID(CurTable)

            'clear the main form grid
            objOrderEntry.udsOrder.Rows.Clear()

            'copy all the items in the bill to the editing section
            For Each myRow As UltraDataRow In udsTableGrid.Rows

                If myRow("Mods") <> strIsModRow Then
                    Dim udrRow As UltraDataRow = objOrderEntry.udsOrder.Rows.Add
                    udrRow.Item("DCode") = myRow("Code")
                    udrRow.Item("DName") = myRow("Dish")
                    udrRow.Item("DPrice") = myRow("Price")
                    udrRow.Item("DQty") = myRow("Qty")
                    udrRow.Item("Total") = myRow("Total")
                    udrRow.Item("Mods") = myRow("Mods")
                    udrRow.Item("Discountable") = myRow("Discountable")
                    udrRow.Item("IsStarter") = myRow("IsStarter")
                    udrRow.Item("OriPrice") = myRow("Price")
                    udrRow.Item("GroupIndex") = myRow("GroupIndex")
                    udrRow.Item("HiLite") = "0"

                    'add any mod rows
                    SQLQuery = String.Format("SELECT Table_Mods.TabUniqueID, Table_Mods.DishName, " &
                               "CASE WHEN Table_Mods.ModDesc IS NULL THEN '' ELSE Table_Mods.ModDesc END AS ModDesc, " &
                               "CASE WHEN Table_Mods.ModPrice IS NULL THEN '0' ELSE Table_Mods.ModPrice END AS ModPrice " &
                               "FROM Table_Mods, Table_Meal " &
                               "WHERE (Table_Meal.TabUniqueID=Table_Mods.TabUniqueID AND Table_Meal.DishName=Table_Mods.DishName) " &
                               "AND (Table_Mods.TabUniqueID={0} AND Table_Mods.DishName='{1}')", TableInfo(CurTable).Id, myRow("Dish"))

                    drcDatarowCollection = objDB.GetDataRows(SQLQuery)
                    If drcDatarowCollection IsNot Nothing Then
                        For Each drRow As DataRow In drcDatarowCollection
                            'MsgBox(drRow("ModDesc") & drRow("ModPrice"))
                            Dim udrModRow As UltraDataRow = objOrderEntry.udsOrder.Rows.Add
                            udrModRow.Item("DQty") = String.Empty
                            udrModRow.Item("DName") = "- " & drRow("ModDesc")
                            udrModRow.Item("DPrice") = drRow("ModPrice")
                            udrModRow.Item("Total") = fixCur(myRow("Qty") * udrModRow.Item("DPrice"))
                            udrModRow.Item("Mods") = strIsModRow
                        Next
                    End If

                    'get any set items
                    Dim strSetItems As String = objDB.GetSetItemsFromDB(TableInfo(CurTable).Id, myRow("Dish"))
                    If strSetItems <> String.Empty Then
                        Dim arrSets = strSetItems.Split("^^")
                        For aCnt = arrSets.GetLowerBound(0) To arrSets.GetUpperBound(0)
                            If arrSets(aCnt) <> String.Empty Then
                                Dim arrSetItems() = arrSets(aCnt).Split("#")
                                Dim udrModRow As UltraDataRow = objOrderEntry.udsOrder.Rows.Add
                                'udrModRow.Item("DQty") = arrSetItems(0)
                                udrModRow.Item("DQty") = IIf(RegistryHasValue("SetPutQty"), arrSetItems(0), "")
                                udrModRow.Item("DName") = "- " & arrSetItems(1)
                                udrModRow.Item("DPrice") = arrSetItems(2)
                                udrModRow.Item("Total") = fixCur(arrSetItems(0) * arrSetItems(2))
                                udrModRow.Item("Mods") = strIsSetItem
                                udrModRow.Item("Discountable") = 0
                            End If
                        Next
                    End If

                    'adjust for papadom price
                    If myRow("Dish").ToUpper Like ("*" & strChutney.ToUpper) Then
                        udrRow.Item("DName") = myRow("Dish").ToString.Replace(strChutney, "").Trim
                        udrRow.Item("Total") = myRow("Qty") * myRow("Price")
                    End If
                End If
            Next

            objOrderEntry.ugdOrderGrid.DataSource = objOrderEntry.udsOrder

            With objOrderEntry
                .cmdOEBack.Enabled = False
                .cmdOENext.Appearance.Image = My.Resources.ezresource.tick
                .cmdOENext.Tag = "T"
                .cmdOEDiscounts.Enabled = False
                .cmdPrintLabels.Enabled = False
                .cmdPrevOrder.Enabled = False
                .cmdAddDrink.Enabled = False
                '.cmdSetMeals.Enabled = False
                .pnlDishes.ClientArea.Controls.Clear()
                .pnlGroup.ClientArea.Controls.Clear()
                .cmdCuisine.Text = GetAppSetting("MultiCuisinesDefault", "Indian")
                .CreateGroupButtons("Menu")
                .Show()
            End With

            AddUpGridTotals()

        Catch ex As Exception
            DisplayError(ex)
        End Try

        blnDisposeOE = True

        Me.Hide()

    End Sub

    Private Sub cmdTablesToMain_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdTableClose.Click, cmdCloseTable.Click

        ''save table button positions
        'Dim myWriter As New System.IO.StreamWriter("C:\Temp\Tables.dat")
        'For Each myObj As Control In Me.upnlTables2.ClientArea.Controls
        '    If myObj.Name.Contains("Tables") Then
        '        Dim myObjx As EZTableButton.EZTableButton = DirectCast(myObj, EZTableButton.EZTableButton)
        '        myWriter.WriteLine("12," & myObjx.TableNumber & "," & myObjx.Left & "," & myObjx.Top)
        '    End If
        'Next
        ''Clean up
        'myWriter.Close()

        Try
            If blnDisposeOE = True Then
                objOrderEntry.Dispose()
                blnDisposeOE = False
            End If
        Catch ex As Exception
            DisplayError(ex)
        End Try

        Me.Hide()

    End Sub

    Private Sub cmdCovers_Click(sender As System.Object, e As System.EventArgs) Handles cmdCovers.Click

        GetCovers()

    End Sub

    Private Sub GetCovers()
        'update the database and save number of customers in the DB

        strQtyFormHeader = "Enter number of customers"
        frmQty.ShowDialog()

        If strNumInput <> "x" Then
            Try
                CurCusts = CShort(strNumInput)
                If (CurCusts > 0 And CurCusts < 100) Then
                    lblCovers.Text = "Covers: " & CShort(strNumInput)
                    If lblCovers.Tag = 0 Then lblCovers.Tag = strNumInput
                    If TableInfo(CurTable).Id = 0 Then AssignUniqueID(CurTable)
                    'update the number of customers into the DB
                    SQLQuery = "UPDATE Table_Bill" &
                               " SET NumCust = " & CurCusts & ", CAPValue = " & lblCovers.Tag &
                               " WHERE TabUniqueID = " & TableInfo(CurTable).Id & ";"
                    ExeNonQuery(SQLQuery)
                    UpdatePapaPrice()
                    DisplayAllTotals()
                    If RegistryHasValue("TablesExtMode") Then
                        For Each myObj As Control In Me.upnlTables.ClientArea.Controls
                            If myObj.Name.Contains("Tables") Then
                                Dim myObjx As EZTableButton.EZTableButton = DirectCast(myObj, EZTableButton.EZTableButton)
                                If myObjx.TableNumber = CurTable Then myObjx.Covers = strNumInput
                            End If
                        Next
                    End If
                Else
                    strMsgBox = "Number must between 1 and 99"
                    Alert(strMsgBox, MessageBoxIcon.Exclamation)
                End If

            Catch ex As Exception
                DisplayError(ex)
            End Try
        End If

    End Sub

    Private Sub cmdTableDiscounts_Click(sender As System.Object, e As System.EventArgs) Handles cmdTableDiscounts.Click

        If TableInfo(CurTable).Id <> 0 Then

            frmDiscounts.ShowDialog()
            frmDiscounts.Dispose()

            'update the number of customers into the DB
            SQLQuery = String.Format("UPDATE Table_Bill SET DiscountAmount = {0}, ChargeAmount = {1}, DiscountLabelText = '{2}', " &
                                     "ChargeLabelText = '{3}' WHERE TabUniqueID = {4}", lblTDiscount.Text, lblTCharges.Text,
                                     lblDiscounts.Text.Replace(":", ""), lblCharges.Text.Replace(":", ""), TableInfo(CurTable).Id)

            ExeNonQuery(SQLQuery)
            DisplayAllTotals()

        Else
            Alert("Table is empty", MessageBoxIcon.Asterisk)
        End If

    End Sub

    Private Sub DeleteUniqueID()
        'if no dish or drink is added to the database then delete this table's
        'unique id from the database

        'delete from DB
        SQLQuery = "DELETE FROM Table_Bill WHERE TabUniqueID = " & TableInfo(CurTable).Id & ";"
        ExeNonQuery(SQLQuery)

        'reset the Id
        TableInfo(CurTable).Id = 0
        TableInfo(CurTable).Status = TStatus.Clean

    End Sub

    Sub GetTableInfo(TableNum)

        ClearTableScreen()

        CurTable = TableNum
        CurCusts = 0
        lblBillHeader.Text = "Table: " & CurTable
        lblDrinksHeader.Text = "Table: " & CurTable
        lblDiscounts.Text = "Discounts:"
        lblCharges.Text = "Charges:"
        lblEntryTime.Text = String.Empty
        upnlTableBill.BringToFront()
        SetTableColour(CurTable, False)

        If TableInfo(CurTable).Id = 0 Then  'no unique id means no food/drink added to table

            SQLQuery = "SELECT TableNumber, TabUniqueId, TableStatus, NumCust, EntryTime, Lights FROM Table_Bill WHERE (TableNumber = " & TableNum & " AND (TableStatus BETWEEN 1 AND 2) AND (BizId BETWEEN 40 AND 60)) ORDER BY TableNumber;"
            drDataRow = objDB.GetSingleRow(SQLQuery)
            If drDataRow IsNot Nothing Then
                TableInfo(TableNum).Id = drDataRow!TabUniqueID
                TableInfo(TableNum).Status = drDataRow!TableStatus
                SetTableColour(CurTable, True, drDataRow!NumCust, drDataRow!EntryTime.ToString, drDataRow!Lights)
            Else
                If RegistryHasValue("TablesAutoCovers") Then
                    Sleep(200)
                    GetCovers()
                End If
            End If

        ElseIf TableInfo(CurTable).Id > 0 Then

            'this query gets all info from Table_Bill for subsequent steps below
            SQLQuery = "SELECT * FROM Table_Bill WHERE TabUniqueID = " & TableInfo(CurTable).Id
            drDataRow = objDB.GetSingleRow(SQLQuery)
            If drDataRow Is Nothing Then
                TableInfo(TableNum).Id = 0
                Exit Sub
            End If

            SetTableColour(CurTable, True, drDataRow!NumCust, drDataRow!EntryTime.ToString, drDataRow!Lights)

            'get the number of customers at the table
            CurCusts = CShort(Val(drDataRow("NumCust").ToString))
            lblCovers.Text = "Covers: " & CurCusts
            lblCovers.Tag = Val(drDataRow("CAPValue").ToString)

            'get discount, charges, tips
            lblTDiscount.Text = fixCur(Val(drDataRow("DiscountAmount").ToString))
            lblTCharges.Text = fixCur(Val(drDataRow("ChargeAmount").ToString))
            tempStr = drDataRow("DiscountLabelText").ToString
            If tempStr = String.Empty Then tempStr = "Discounts"
            lblDiscounts.Text = tempStr & ":"
            tempStr = drDataRow("ChargeLabelText").ToString
            If tempStr = String.Empty Then tempStr = "Charges"
            lblCharges.Text = tempStr & ":"
            lblTTips.Text = "Tips: " & fixCur(drDataRow("Tips").ToString)
            If drDataRow!EntryTime.ToString <> "00:00:00" Then
                Dim TSpan As TimeSpan = Now - CDate(drDataRow!EntryTime.ToString)
                tempStr = String.Format("Time of entry: {0}" & vbCrLf & "({1}:{2})",
                                        Format(CDate(drDataRow!EntryTime.ToString), "h:mm"),
                                        TSpan.Hours.ToString("D1"), TSpan.Minutes.ToString("D2"))
                lblEntryTime.Text = tempStr
            End If

            'get info from the DB about this table's meal
            SQLQuery = "SELECT Table_Meal.* FROM Table_Meal WHERE TabUniqueID = " & TableInfo(CurTable).Id
            drcDatarowCollection = objDB.GetDataRows(SQLQuery)
            If drcDatarowCollection IsNot Nothing Then
                For Each myRow As DataRow In drcDatarowCollection
                    Dim udrRow As UltraDataRow = udsTableGrid.Rows.Add
                    udrRow.Item("Code") = myRow("Code")
                    udrRow.Item("Dish") = myRow("DishName")
                    udrRow.Item("Price") = fixCur(myRow("DishPrice"))
                    udrRow.Item("Qty") = myRow("DishQty")
                    udrRow.Item("Total") = fixCur(myRow("DishQty") * myRow("DishPrice"))
                    udrRow.Item("IsStarter") = myRow("IsStarter")
                    udrRow.Item("Discountable") = myRow("Discountable")
                    udrRow.Item("Mods") = myRow("Mods")
                    udrRow.Item("GroupIndex") = myRow("GroupIndex")
                    ShowAnyMods(TableInfo(CurTable).Id, myRow("DishName"), myRow("DishQty"))
                    ShowAnySetItems(TableInfo(CurTable).Id, myRow("DishName"), myRow("DishQty"))
                Next

                'update papadom price
                UpdatePapaPrice()

                ugdTableGrid.DataSource = udsTableGrid

                'get info from the DB about this table's drinks
                SQLQuery = "SELECT * FROM Table_Drinks WHERE TabUniqueID = " & TableInfo(CurTable).Id
                drcDatarowCollection = objDB.GetDataRows(SQLQuery)
                If drcDatarowCollection IsNot Nothing Then
                    For Each myRow As DataRow In drcDatarowCollection
                        Dim udrRow As UltraDataRow = udsDrinks.Rows.Add
                        udrRow.Item("DkQty") = myRow("DkQty")
                        udrRow.Item("DkName") = myRow("DkName")
                        udrRow.Item("DkPrice") = myRow("DkPrice")
                        udrRow.Item("DkTotal") = myRow("DkQty") * myRow("DkPrice")
                    Next
                    ugdDrinksGrid.DataSource = udsDrinks
                    'work out the drinks total
                    lblDrinksTotal.Text = fixCur(CalcDrinksTotal)
                End If

                'fill in drinks row in bill if there are drinks selected
                If CalcDrinksTotal() > 0 Then
                    lblTDrinks.Text = fixCur(CalcDrinksTotal)
                End If

                DisplayAllTotals()

                HighlightStarters()
                ugdTableGrid.ActiveRow = Nothing

            End If

        End If

    End Sub

    Private Sub ClearTableScreen()
        'clears tables screen - clears grid, initialises labels, etc

        lblTDrinks.Text = "0.00"
        lblTSubtotal.Text = "0.00"
        lblTDiscount.Text = "0.00"
        lblTCharges.Text = "0.00"
        lblBillTotal.Text = "0.00"
        lblTTips.Text = "0.00"
        lblCovers.Text = "Covers: 0"
        lblCovers.Tag = 0
        lblDrinksTotal.Text = "0.00"

        udsTableGrid.Rows.Clear()
        udsDrinks.Rows.Clear()
        ugdTableGrid.DataSource = udsTableGrid
        ugdDrinksGrid.DataSource = udsDrinks

    End Sub

    Public Function CalcDrinksTotal()

        Dim decDrinkTotal As Decimal = 0

        For Each mRow As UltraDataRow In udsDrinks.Rows
            decDrinkTotal += mRow!DkTotal
        Next

        Return decDrinkTotal

    End Function

    Private Function CalcSubTotal() As Decimal

        Dim decSubTotal As Decimal = 0

        For Each udrRow As UltraDataRow In udsTableGrid.Rows
            decSubTotal += udrRow!Total
        Next

        Return decSubTotal

    End Function

    Private Sub DisplayAllTotals()

        lblTSubtotal.Text = fixCur(CalcSubTotal)
        lblBillTotal.Text = fixCur(CalcSubTotal() + CalcDrinksTotal() - Val(lblTDiscount.Text) + Val(lblTCharges.Text))

    End Sub

    Public Sub ShowTablesInUse()
        'shows tables which are currently being used by customers (1)
        'this includes ones that have been printed but not yet cleared (2)

        Try
            Dim intXCovers, intXTables As Short

            'blank all tables
            If MainOrSubSystem() <> "NOTMULTI" Then
                For xCntr As Short = 1 To NumberOfTables
                    SetTableColour(xCntr, False)
                Next
            End If

            'create query
            SQLQuery = "SELECT TableNumber, NumCust, EntryTime, Lights FROM Table_Bill WHERE ((TableStatus BETWEEN 1 AND 2) AND (BizId BETWEEN 40 AND 60));"
            drcDatarowCollection = objDB.GetDataRows(SQLQuery)
            If drcDatarowCollection IsNot Nothing Then
                intXTables = drcDatarowCollection.Count
                For Each myRow As DataRow In drcDatarowCollection
                    SetTableColour(myRow!TableNumber, True, myRow!NumCust, myRow!EntryTime.ToString, myRow!Lights)
                    intXCovers += Integer.Parse(myRow!NumCust)
                Next
            End If

            UpdateStatusBarText(intXTables, intXCovers)

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub PrintBill(sender As System.Object, e As System.EventArgs) Handles cmdTablePrint.Click, cmdTableKCopy.Click

        Try

            'validate table is ok
            If ValidateTable() = True Then

                Dim strPrintTime As String
                Dim decMealTotal As Decimal = CDec(lblTSubtotal.Text)
                Dim decDrinksTotal As Decimal = CDec(lblTDrinks.Text)
                Dim decBillTotal As Decimal = CDec(lblBillTotal.Text)

                'Save the bill's total to the DB
                'see if it needs to be updated or new one inserted
                SQLQuery = "SELECT * FROM Table_Bill WHERE TabUniqueId = " & TableInfo(CurTable).Id
                drDataRow = objDB.GetSingleRow(SQLQuery)

                If drDataRow IsNot Nothing Then
                    If drDataRow!PrintedTime.ToString <> "" Then
                        strPrintTime = drDataRow!PrintedTime.ToString
                    Else
                        strPrintTime = "Time: " & Format(Now, "h:mm") & "    Date: " & Format(Now, "dd/MM/yy")
                    End If

                    'update existing record
                    SQLQuery = String.Format("UPDATE Table_Bill SET BillTotal = {0}, MealTotal = {1}, DrinksTotal = {2}, TableStatus = 2, PrintedTime = '{3}' " &
                                             "WHERE TabUniqueId = {4}", fixCur(decBillTotal), fixCur(decMealTotal), fixCur(decDrinksTotal), strPrintTime, TableInfo(CurTable).Id)
                    ExeNonQuery(SQLQuery)

                Else
                    WriteToLog("Error in subroutine PrintBill:" & vbCrLf & "Why is drDataRow nothing?", log4netType.Error)
                    Exit Sub
                End If

                If sender.name = "cmdTablePrint" Then SetTableStatus(2)
                sngTabUniqueID = TableInfo(CurTable).Id
                Dim intExCuisine As Short = intCurrentCuisine
                intCurrentCuisine = 1
                If sender.name = "cmdTableKCopy" Then
                    PrintTable(sngTabUniqueID, "Kitchen")
                Else
                    PrintTable(sngTabUniqueID, "Shop")
                End If
                intCurrentCuisine = intExCuisine

                'SMX
                'If IsTabletPC Then
                '    DisplayMessage("Order has been sent to printer.")
                'End If

            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Function ValidateTable() As Boolean

        'a printer must be installed
        If Printing.PrinterSettings.InstalledPrinters.Count = 0 Then
            strMsgBox = "There are no printers installed on this system. Install a printer first and then try again."
            Alert(strMsgBox)
            Return False
        End If

        'select how many customers there are
        If Short.Parse(lblCovers.Text.Substring(8)) < 1 Then
            strMsgBox = "Select the number of customers at this table before printing."
            Alert(strMsgBox)
            Return False
        End If

        'see that there are some items in the item
        If ugdTableGrid.Rows.Count < 1 Then
            strMsgBox = "There are no items in this bill. Nothing to print."
            Alert(strMsgBox)
            Return False
        End If

        Return True

    End Function

    Private Sub cmdTableKNote_Click(sender As System.Object, e As System.EventArgs) Handles cmdTableKNote.Click

        If TableInfo(CurTable).Id <> 0 Then

            'get any existing note from the database
            SQLQuery = "SELECT TableNote FROM Table_Bill WHERE TabUniqueID = " & TableInfo(CurTable).Id
            drDataRow = objDB.GetSingleRow(SQLQuery)
            tempStr = "XXX"
            strKBInput = ""
            If drDataRow IsNot Nothing Then
                strKBInput = drDataRow!TableNote.ToString
            End If

            strKBInput = EZFullKeyboard.Show(strKBInput)

            If strKBInput <> EZKBEscape Then
                SQLQuery = "UPDATE Table_Bill SET TableNote = '" & strKBInput & "' WHERE TabUniqueID = " & TableInfo(CurTable).Id
                ExeNonQuery(SQLQuery)
            End If

        Else
            Alert("Table is empty", MessageBoxIcon.Asterisk)
        End If

    End Sub

    Private Sub cmdTablePayment_Click(sender As System.Object, e As System.EventArgs) Handles cmdTablePayment.Click

        Try

            If TableInfo(CurTable).Id <> 0 Then

                'need to have number of covers specified
                If Short.Parse(lblCovers.Text.Substring(8)) < 1 Then
                    strMsgBox = "Select the number of customers at this table first"
                    Alert(strMsgBox, MessageBoxIcon.Information)
                Else

                    With objPayment
                        .txtToPay.Text = lblBillTotal.Text
                        .Tag = "Tables"
                        .cmdBack.Enabled = False
                        .cmdKitchenCopy.Enabled = False
                        .cmdShopCopy.Enabled = False
                        .cmdPrintOrder.Enabled = False
                        .cmdSaveOrder.Enabled = False
                        .cmdOrderSource.Enabled = False
                        .cmdOrderSource.Visible = GetAppSetting("OLEnabled", 0)
                        .txtTips.Enabled = True
                        .ubtnTips.Enabled = True

                        Try
                            SQLQuery = "SELECT CASE WHEN PayMethod IS NULL THEN 'Other' ELSE PayMethod END AS PayMethod, " &
                                       "CASE WHEN Tips IS NULL THEN '0' ELSE Tips END AS Tips FROM Table_Bill WHERE TabUniqueID = " & TableInfo(CurTable).Id

                            drDataRow = objDB.GetSingleRow(SQLQuery)
                            If drDataRow IsNot Nothing Then
                                ButtonToggle(.cmdTenderCash, cstButTogClr)
                                ButtonToggle(.cmdTenderCard, cstButTogClr)
                                ButtonToggle(.cmdTenderOther, cstButTogClr)
                                If drDataRow("PayMethod") = "Cash" Then
                                    ButtonToggle(.cmdTenderCash, cstButTogYes)
                                ElseIf drDataRow("PayMethod") = "Card" Then
                                    ButtonToggle(.cmdTenderCard, cstButTogYes)
                                ElseIf drDataRow("PayMethod") = "Other" Then
                                    ButtonToggle(.cmdTenderOther, cstButTogYes)
                                End If
                                If drDataRow("PayMethod") = "Mixed" Then .cmdSplitPayment.Tag = "Mixed"
                                .txtTips.Text = CDec(drDataRow("Tips"))
                            End If
                        Catch ex As Exception
                            DisplayError(ex)
                        End Try
                        .ShowDialog()
                        .Dispose()
                    End With

                End If

            Else
                Alert("Table is empty", MessageBoxIcon.Asterisk)
            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub UpdatePapaPrice()

        '  ---> 45 * qty of Papa  +  30 * no. of persons
        If RegistryHasValue("CAPStatus") Then
            Dim tStr As String
            With ugdTableGrid
                For Each mrow In .Rows
                    tStr = .Rows(mrow.Index.ToString).Cells("Dish").Value
                    If tStr.ToUpper Like strPapadom Then
                        tempVal = .Rows(mrow.Index.ToString).Cells("Qty").Value * .Rows(mrow.Index.ToString).Cells("Price").Value
                        tempVal += (lblCovers.Tag * (CDec(GetAppSetting("CAPValue", 0)) / 100))
                        .Rows(mrow.Index.ToString).Cells("Total").Value = fixCur(tempVal)
                        tStr = Replace(tStr, strChutney, "").Trim
                        .Rows(mrow.Index.ToString).Cells("Dish").Value = tStr & strChutney
                        Exit For
                    End If
                Next
            End With

        End If

    End Sub

    Private Sub cmdMoveTable_Click(sender As System.Object, e As System.EventArgs) Handles cmdMoveTable.Click

        Try

            If upnlTableBill.Tag = "MoveModeOff" Then

                'table must not be empty
                If TableInfo(CurTable).Status = TStatus.InUse Or TableInfo(CurTable).Status = TStatus.Printed Then
                    If ugdTableGrid.Rows.Count > 0 Or lblTDrinks.Text <> "0.00" Then
                        'hide any non-empty tables
                        For Each myObj As Control In Me.upnlMiniTables.ClientArea.Controls
                            If myObj.Name = "MiniTables" Then
                                Dim myBut As UltraButton = DirectCast(myObj, UltraButton)
                                If myBut.Tag IsNot Nothing AndAlso myBut.Tag.ToString = "1" Then
                                    myBut.Visible = False
                                    lblMiniHilit.Visible = False
                                    upnlTableBill.Tag = "MoveModeOn"
                                End If
                            End If
                        Next
                        If upnlTableBill.Tag = "MoveModeOn" Then HideButtons()
                    End If
                Else
                    Alert("Table is empty", MessageBoxIcon.Asterisk)
                End If

            Else

                RestoreTables()

            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub HideButtons()

        Try

            'restore the buttons
            For Each myObj As Control In Me.upnlTableBill.ClientArea.Controls
                If myObj.Size = New Size(126, 65) Then
                    If myObj.Tag <> "Move Table" Then myObj.Enabled = False
                End If
            Next

            Dim lblMTLabel As New UltraLabel
            Dim appnLabelAppearance As New Infragistics.Win.Appearance '= New Infragistics.Win.Appearance()
            appnLabelAppearance.BackColor = Color.Olive
            appnLabelAppearance.BorderColor = Color.Khaki
            appnLabelAppearance.ForeColor = Color.White
            appnLabelAppearance.TextHAlignAsString = "Center"
            appnLabelAppearance.TextVAlignAsString = "Middle"
            lblMTLabel.Appearance = appnLabelAppearance
            lblMTLabel.BorderStyleInner = Infragistics.Win.UIElementBorderStyle.Solid
            lblMTLabel.BorderStyleOuter = Infragistics.Win.UIElementBorderStyle.Solid
            lblMTLabel.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            lblMTLabel.Location = New System.Drawing.Point(364, 329)
            lblMTLabel.Name = "lblMTLabel"
            lblMTLabel.Size = New System.Drawing.Size(325, 44)
            lblMTLabel.TabIndex = 523
            lblMTLabel.Text = "Select destination table"
            lblMTLabel.UseAppStyling = False
            lblMTLabel.Visible = True
            upnlTableBill.ClientArea.Controls.Add(lblMTLabel)

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub RestoreTables()

        Try
            'restore the tables
            For Each myObj As Control In Me.upnlMiniTables.ClientArea.Controls
                If myObj.Name = "MiniTables" Then myObj.Visible = True
            Next

            lblMiniHilit.Visible = True

            'restore the buttons
            For Each myObj As Control In Me.upnlTableBill.ClientArea.Controls
                If myObj.Size = New Size(126, 65) Then myObj.Enabled = True
                If myObj.Name = "lblMTLabel" Then myObj.Hide()
            Next

            upnlTableBill.Tag = "MoveModeOff"

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub HighlightStarters()

        For Each myRow In ugdTableGrid.Rows
            If myRow.Cells("Mods").Value <> strIsModRow AndAlso myRow.Cells("IsStarter").Value <> 0 Then
                myRow.Appearance.BackColor = Color.FromArgb(CType(CType(195, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(195, Byte), Integer))
            End If
        Next

    End Sub

    Private Sub cmdCAP_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCAP.Click
        'set CAP value

        Dim intCAP As Short

        strQtyFormHeader = "Enter chutney tray heads"
        frmQty.ShowDialog()

        If strNumInput <> "x" Then
            Try
                intCAP = CShort(strNumInput)
                If (intCAP >= 0 And intCAP < 100) Then
                    lblCovers.Tag = intCAP

                    If TableInfo(CurTable).Id = 0 Then AssignUniqueID(CurTable)

                    'update the number of customers into the DB
                    SQLQuery = "UPDATE Table_Bill SET CAPValue = " & intCAP &
                               " WHERE TabUniqueID = " & TableInfo(CurTable).Id & ";"

                    ExeNonQuery(SQLQuery)
                    UpdatePapaPrice()
                    DisplayAllTotals()

                Else
                    strMsgBox = "Number must between 0 and 99"
                    Alert(strMsgBox)
                End If

            Catch ex As Exception
                DisplayError(ex)
            End Try

        End If

    End Sub

    Private Sub cmdAddMiscDrink_Click(sender As System.Object, e As System.EventArgs) Handles cmdAddMiscDrink.Click

        strQtyFormHeader = "0.00Enter amount for misc drink"
        frmQty.ShowDialog()

        If strNumInput <> "x" Then
            Try
                Dim decDrinkAmt As Decimal = CDec(strNumInput)
                If (decDrinkAmt > 0 And decDrinkAmt < 1000) Then
                    Dim myRow As UltraDataRow = udsDrinks.Rows.Add()
                    myRow.Item("DkQty") = "1"
                    myRow.Item("DkName") = "Misc Drink"
                    myRow.Item("DkPrice") = decDrinkAmt
                    myRow.Item("DkTotal") = fixCur(decDrinkAmt)

                    ugdDrinksGrid.SuspendLayout()
                    ugdDrinksGrid.DataSource = udsDrinks
                    If ugdDrinksGrid.Rows.Count > 0 Then
                        ugdDrinksGrid.ActiveRow = ugdDrinksGrid.Rows(0)
                    Else
                        ugdDrinksGrid.ActiveRow = Nothing
                    End If
                    ugdDrinksGrid.ResumeLayout()
                    ugdDrinksGrid.Refresh()

                    AddupDrinksTotal()
                    blnDrinksDirty = True
                Else
                    strMsgBox = "Number must between 1 and 1000"
                    Alert(strMsgBox)
                End If

            Catch ex As Exception
                DisplayError(ex)
            End Try

        End If

    End Sub

    Public Sub MiniHilit(MTButton As UltraButton)

        Try
            ResetMiniTableBackground()
            With lblMiniHilit
                .Size = New Size(MTButton.Width + 8, MTButton.Height + 8)
                .Location = New Point(MTButton.Left - 4, MTButton.Top - 4)
                '.BorderStyleOuter = Infragistics.Win.UIElementBorderStyle.Rounded4Thick
                .Visible = True
                .SendToBack()
            End With

            MTButton.Appearance.BackColor = Color.FromArgb(196, 27, 27)

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Public Sub ClearDrinksGrid()

        udsDrinks.Rows.Clear()
        ugdDrinksGrid.DataSource = udsDrinks
        ugdDrinksGrid.Refresh()
        AddupDrinksTotal()
        blnDrinksDirty = True

    End Sub

    Private Sub ShowAnyMods(ByVal sngTUIdSAM As Short, ByVal strDNameSAM As String, ByVal intDQty As Short)

        Dim strMods = objDB.GetTableModsFromDB(sngTUIdSAM, strDNameSAM)
        If strMods <> String.Empty Then
            Dim arrMods = strMods.Split("^^")
            For aCnt = arrMods.GetLowerBound(0) To arrMods.GetUpperBound(0)
                If arrMods(aCnt) <> String.Empty Then
                    strMods = arrMods(aCnt)
                    Dim h As Short = InStr(strMods, "#")
                    Dim mDesc = VB.Left(strMods, h - 1)
                    Dim mPrice = VB.Mid(strMods, h + 1)
                    Dim udrModRow As UltraDataRow = udsTableGrid.Rows.Add
                    udrModRow.Item("Qty") = ""
                    udrModRow.Item("Dish") = "- " & mDesc
                    udrModRow.Item("Price") = mPrice
                    udrModRow.Item("Total") = fixCur(intDQty * mPrice)
                    udrModRow.Item("Mods") = strIsModRow
                End If
            Next
        End If

    End Sub

    Private Sub ShowAnySetItems(ByVal sngTUIdSAM As Short, ByVal strDNameSAM As String, ByVal intDQty As Short)

        Dim strMods As String = objDB.GetSetItemsFromDB(sngTUIdSAM, strDNameSAM)
        If strMods <> String.Empty Then
            Dim arrMods = strMods.Split("^^")
            For aCnt = arrMods.GetLowerBound(0) To arrMods.GetUpperBound(0)
                If arrMods(aCnt) <> String.Empty Then
                    Dim arrModDetails = arrMods(aCnt).Split("#")
                    Dim udrModRow As UltraDataRow = udsTableGrid.Rows.Add
                    udrModRow.Item("Qty") = ""
                    udrModRow.Item("Dish") = "- " & arrModDetails(1)
                    udrModRow.Item("Price") = arrModDetails(2)
                    udrModRow.Item("Total") = fixCur(intDQty * arrModDetails(2))
                    udrModRow.Item("Mods") = strIsModRow
                End If
            Next
        End If

    End Sub

    Public Sub UpdateUsedButtons()

        For iddd As Integer = 1 To 10
            Application.DoEvents()
            ShowTablesInUse()
            Sleep(100)
        Next

    End Sub

    Private Sub cmdPrintDrinks_Click(sender As System.Object, e As System.EventArgs) Handles cmdPrintDrinks.Click

        If ugdDrinksGrid.Rows.Count > 0 Then

            If TableInfo(CurTable).Id = 0 Then AssignUniqueID(CurTable)
            sngTabUniqueID = TableInfo(CurTable).Id
            InsertDrinksToDB()
            PrintDrinks()

        Else

            strMsgBox = "There are no drinks in the list"
            Alert(strMsgBox)

        End If

    End Sub

    Private Sub cmdLightsStatus_Click(sender As System.Object, e As System.EventArgs) Handles cmdLightsStatus.Click

        Dim MyCustomList As New List(Of String)()
        MyCustomList.Add(GetAppSetting("TablesExtLine1", "Starters served"))
        MyCustomList.Add(GetAppSetting("TablesExtLine2", "Mains served"))
        MyCustomList.Add(GetAppSetting("TablesExtLine3", "Bill paid"))
        MyCustomList.Add("Reset")

        Dim strResponse As String = CustomList.Show(MyCustomList, False)
        If strResponse <> strCustomListBoxCancelString Then
            For Each myObj As Control In Me.upnlTables.ClientArea.Controls
                If myObj.Name.Contains("Tables") Then
                    Dim myObjx As EZTableButton.EZTableButton = DirectCast(myObj, EZTableButton.EZTableButton)
                    If myObjx.TableNumber = CurTable Then
                        If strResponse = GetAppSetting("TablesExtLine1", "Starters served") Then myObjx.LightsOn(1) : tempVal = 1
                        If strResponse = GetAppSetting("TablesExtLine2", "Mains served") Then myObjx.LightsOn(2) : tempVal = 2
                        If strResponse = GetAppSetting("TablesExtLine3", "Bill paid") Then myObjx.LightsOn(3) : tempVal = 3
                        If strResponse = "Reset" Then myObjx.LightsAllOff() : tempVal = 0
                        Application.DoEvents()
                        SQLQuery = "UPDATE Table_Bill SET Lights = " & tempVal & " WHERE TabUniqueID = " & TableInfo(CurTable).Id
                        ExeNonQuery(SQLQuery)
                    End If
                End If
            Next
        End If

    End Sub

    Private Sub UpdateStatusBarText(Optional intZTables As Short = -1, Optional intZCovers As Short = -1)

        If intZTables = -1 AndAlso intZCovers = -1 Then
            intZTables = 0
            intZCovers = 0
            SQLQuery = "SELECT TableNumber, NumCust, EntryTime, Lights FROM Table_Bill WHERE ((TableStatus BETWEEN 1 AND 2) AND (BizId BETWEEN 40 AND 60));"
            drcDatarowCollection = objDB.GetDataRows(SQLQuery)
            If drcDatarowCollection IsNot Nothing Then
                intZTables = drcDatarowCollection.Count
                For Each myRow As DataRow In drcDatarowCollection
                    SetTableColour(myRow!TableNumber, True, myRow!NumCust, myRow!EntryTime.ToString, myRow!Lights)
                    intZCovers += Integer.Parse(myRow!NumCust)
                Next
            End If
        End If

        'lblStatusBar.Text = "Tables: " & intZTables & Space(10) & "Customers: " & intZCovers & Space(130) & Format(Now, "dddd d MMMM yyyy    h:mm")
        lblStatusBar.Text = Space(10) & "Tables: " & intZTables & Space(10) & "Customers: " & intZCovers
        lblStatusBar.Appearance.TextHAlign = Infragistics.Win.HAlign.Left
        lblStatusBar.Refresh()

    End Sub

    Public Sub SetTableColour(ByVal intBtnNum As Short, ByVal blnColorIsOn As Boolean, Optional ByVal intNumCust As Short = -1,
                              Optional ByVal strEntryTime As String = Nothing, Optional ByVal intLights As Short = -1)

        Dim btnButton As New EZTableButton.EZTableButton
        Dim btnMiniButton As New UltraButton
        Dim intTag As Short

        Dim appnMiniTableOn As New Infragistics.Win.Appearance
        Dim appnMiniTableOff As New Infragistics.Win.Appearance

        Dim clrMyColor As Color = Color.FromArgb(66, 134, 165)
        Dim clrMyColor2 As Color = clrMyColor
        Dim clrMyBorderColor As Color = Color.FromArgb(66, 138, 181)
        Dim bgsBackGradStyle As Infragistics.Win.GradientStyle = Infragistics.Win.GradientStyle.GlassTop50

        With appnMiniTableOff
            .BorderColor = Color.Transparent
            .ForeColor = Color.White
            .ImageBackground = My.Resources.ezresource.minitable
        End With

        With appnMiniTableOn
            .BorderColor = Color.Transparent
            .ForeColor = Color.Yellow
            .ImageBackground = My.Resources.ezresource.minitable_green
        End With

        'With ubtnButton
        '    .Font = New System.Drawing.Font("Arial", fontSze, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '    .Name = strButtonName
        '    .ShowFocusRect = False
        '    .ShowOutline = False
        '    .Size = New System.Drawing.Size(bWidth, bHeight)
        '    .UseAppStyling = False
        '    .UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '    .UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        '    .UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        'End With

        'get the button with the correct CurTable
        For Each myObj As Control In upnlTables.ClientArea.Controls
            If myObj.Name.Contains("Tables") Then
                Dim myObjx As EZTableButton.EZTableButton = DirectCast(myObj, EZTableButton.EZTableButton)
                If myObjx.TableNumber = intBtnNum.ToString Then
                    btnButton = myObj
                    Exit For
                End If
            End If
        Next

        'colour mini table as well
        For Each myObj In upnlMiniTables.ClientArea.Controls
            If (myObj.Name = "MiniTables" And myObj.Text = intBtnNum.ToString) Then
                btnMiniButton = myObj
                Exit For
            End If
        Next

        If RegistryHasValue("TablesExtMode") Then

            If blnColorIsOn = True Then
                intTag = 1
                btnButton.NewEntry()
                If strEntryTime <> Nothing Then btnButton.EntryTime = strEntryTime.ToString
                If intNumCust <> -1 Then btnButton.Covers = intNumCust
                btnButton.TopBarVisible = Not RegistryHasValue("TablesExtLights")
                If btnButton.TopBarVisible Then
                    If intLights <> -1 Then
                        If intLights = 0 Then
                            btnButton.LightsAllOff()
                        Else
                            btnButton.LightsOn(intLights)
                        End If
                    End If
                End If
            Else
                intTag = 0
                btnButton.ClearTable()
            End If

        Else

            If blnColorIsOn = True Then
                btnButton.NewEntrySimple()
                intTag = 1
            Else
                btnButton.ClearTable()
                intTag = 0
            End If
        End If

        If blnColorIsOn = True Then
            btnMiniButton.Appearance = appnMiniTableOn
        Else
            btnMiniButton.Appearance = appnMiniTableOff
        End If

        btnButton.Refresh()
        btnMiniButton.Refresh()

        btnButton.Tag = intTag
        btnMiniButton.Tag = intTag

        MiniHilit(btnMiniButton)

    End Sub

End Class