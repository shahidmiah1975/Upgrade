﻿Imports Infragistics.Win.Misc
Imports EZControls
Imports EZMenu.Core.Models
Imports EZService
Imports Infragistics.Win.UltraWinEditors
Imports Infragistics.Win.UltraWinGrid

Public Class frmBookings

    Public objPrevTextbox As UltraTextEditor
    Private _customerService As CustomerService

    Private Sub frmBookings_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Try
            _customerService = New CustomerService()

            lblBaseHeader.Text = "Reservations"

            'Size = frmOpener.Size
            'Location = frmOpener.Location

            StartPosition = FormStartPosition.CenterScreen

            SetupButtons()

            cmdUpdate.Tag = Nothing
            txtBookingDate.Text = Format(Date.Now, "dd/MM/yy")
            UpdateLabel()

            ugdBookings.ActiveRow = Nothing

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub SetupButtons()

        For Each myobjx In Controls
            If TypeName(myobjx) = "UltraButton" Then
                Dim myObj As UltraButton = DirectCast(myobjx, UltraButton)
                myObj.Tag = myObj.Text
                If GetAppSettingCS("ShowLabelText", 0) = 0 Then
                    myObj.Text = String.Empty
                    myObj.Appearance.ImageVAlign = Infragistics.Win.VAlign.Middle
                Else
                    myObj.Appearance.ImageVAlign = Infragistics.Win.VAlign.Middle
                End If
                AddHandler myObj.MouseEnter, AddressOf ButtonMouseEnter
                AddHandler myObj.MouseLeave, AddressOf ButtonMouseLeave
            End If
        Next

    End Sub

    Private Sub ButtonMouseEnter(sender As Object, e As EventArgs)

        'If sender.name <> "cmdClearButton" Then sender.text = sender.tag

    End Sub

    Private Sub ButtonMouseLeave(sender As Object, e As EventArgs)

        If GetAppSettingCS("ShowLabelText", 0) = 0 Then
            'sender.Text = String.Empty
            sender.Appearance.ImageVAlign = Infragistics.Win.VAlign.Middle
        Else
            sender.Appearance.ImageVAlign = Infragistics.Win.VAlign.Middle
        End If

    End Sub

    Private Sub cmdClose_Click(sender As Object, e As EventArgs) Handles cmdClose.Click
        Close()
    End Sub

    Private Sub cmdKBName_Click(sender As Object, e As EventArgs) Handles cmdKBName.Click

        strKBInput = EZFullKeyboard.Show(txtName.Text)
        If strKBInput <> EZKBEscape Then
            txtName.Text = strKBInput.Trim
        End If

    End Sub

    Private Sub cmdKBTime_Click(sender As Object, e As EventArgs) Handles cmdKBTime.Click

        Try

            Dim strTimeValue As String = TimesGrid.Show

            If strTimeValue <> String.Empty Then
                If strTimeValue <> "0:00" Then
                    If IsDate(strTimeValue) Then
                        txtTime.Text = strTimeValue
                    Else
                        strMsgBox = "Entered time is invalid"
                        EZMsgBox.Show(strMsgBox, MessageBoxIcon.Error)
                    End If
                End If
            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub cmdKBCovers_Click(sender As Object, e As EventArgs) Handles cmdKBCovers.Click

        Dim strNumInput As String

        Using objFormQty As New frmQty
            objFormQty.Display("Enter covers", 0)
            strNumInput = objFormQty.ReturnValue
        End Using

        If strNumInput <> "x" Then txtCovers.Text = CInt(strNumInput)

    End Sub

    Private Sub cmdKBTelephone_Click(sender As Object, e As EventArgs) Handles cmdKBTelephone.Click

        strKBInput = EZFullKeyboard.Show(txtTelephone.Text)
        If strKBInput <> EZKBEscape Then
            txtTelephone.Text = strKBInput
        End If

    End Sub

    Private Sub cmdKBBookingNote_Click(sender As Object, e As EventArgs) Handles cmdKBBookingNote.Click

        strKBInput = EZFullKeyboard.Show(txtBookingNote.Text)
        If strKBInput <> EZKBEscape Then
            txtBookingNote.Text = strKBInput
        End If

    End Sub

    Private Sub cmdViewCalendar_Click(sender As Object, e As EventArgs) Handles cmdViewCalendar.Click

        Try
            Dim strDate As String = EZDatePicker.SelectedDate
            If strDate <> String.Empty Then
                Dim datMyDate As DateTime
                If DateTime.TryParse(strDate, datMyDate) Then
                    Dim newDate = datMyDate.ToString("dd/MM/yyyy")
                    txtBookingDate.Text = newDate
                    If IsDate(txtBookingDate.Text) Then
                        GetBookings(newDate)
                        UpdateLabel()
                        ugdBookings.ActiveRow = Nothing
                    Else
                        strMsgBox = "Date is not valid"
                        EZMsgBox.Show(strMsgBox, MessageBoxIcon.Error)
                    End If
                Else
                    strMsgBox = "Date is not valid"
                    EZMsgBox.Show(strMsgBox, MessageBoxIcon.Error)
                End If
            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub GetBookings(strBookingDate)

        Try
            Dim data = _customerService.GetBookingsByDate(strBookingDate)
            ugdBookings.DataSource = data
        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub TextBoxesEntered(sender As Object, e As EventArgs) Handles txtBookingDate.Enter, txtBookingNote.Enter, txtCovers.Enter,
                                                                                    txtName.Enter, txtTelephone.Enter, txtTime.Enter, txtTable.Enter

        cmdClearButton.Location = New Point(sender.left + 257, sender.top - 4)
        cmdClearButton.Tag = sender.name
        cmdClearButton.Visible = True

        Dim ctrlSender As UltraTextEditor = CType(sender, UltraTextEditor)

        HiLitBox(ctrlSender)

        If objPrevTextbox IsNot Nothing AndAlso objPrevTextbox.Name <> ctrlSender.Name Then
            HiLitOffBox(objPrevTextbox)
        End If

        ctrlSender.AlwaysInEditMode = True
        objPrevTextbox = ctrlSender

    End Sub

    Private Sub TextBoxesLeave(sender As Object, e As EventArgs) Handles txtBookingDate.Leave, txtBookingNote.Leave, txtCovers.Leave,
                                                                                    txtName.Leave, txtTelephone.Leave, txtTime.Leave, txtTable.Leave

        cmdClearButton.Visible = False

    End Sub

    Private Sub cmdClearButton_Click(sender As Object, e As EventArgs) Handles cmdClearButton.Click

        Select Case cmdClearButton.Tag
            Case "txtBookingDate" : txtBookingDate.Clear()
            Case "txtBookingNote" : txtBookingNote.Clear()
            Case "txtCovers" : txtCovers.Clear()
            Case "txtName" : txtName.Clear()
            Case "txtTelephone" : txtTelephone.Clear()
            Case "txtTime" : txtTime.Clear()
            Case "txtTable" : txtTable.Clear()
            Case Else
        End Select

        cmdClearButton.Visible = False

    End Sub

    Private Sub cmdClearAll_Click(sender As Object, e As EventArgs) Handles cmdClearAll.Click

        txtBookingDate.Clear()
        txtBookingNote.Clear()
        txtCovers.Clear()
        txtName.Clear()
        txtTelephone.Clear()
        txtTime.Clear()
        txtTable.Clear()
        cmdClearButton.Visible = False

    End Sub

    Private Sub cmdOK_Click(sender As Object, e As EventArgs) Handles cmdOK.Click

        If ValidateInputs() = True Then

            'all ok to go ahead
            Try
                Dim model As New BookingModel With {
                    .Name = txtName.Text,
                    .Message = txtBookingNote.Text,
                    .Date = txtBookingDate.Text,
                    .Covers = txtCovers.Text,
                    .Phone = txtTelephone.Text,
                    .Time = txtTime.Text,
                    .Table = txtTable.Text
                }

                _customerService.AddBooking(model)

                cmdClearAll_Click(sender, e)
                UpdateLabel()

            Catch ex As Exception
                EZMsgBox.Show(ex.Message, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try

        End If

    End Sub

    Private Sub cmdViewAll_Click(sender As Object, e As EventArgs) Handles cmdViewAll.Click

        Dim allBookings As List(Of BookingModel) = _customerService.GetAllBookings(True)
        ugdBookings.DataSource = allBookings

        UpdateLabel()

        ugdBookings.ActiveRow = Nothing

        ToggleButtonsForOnlineBookings(False)

        If ugdBookings.Rows.Count = 0 Then
            strMsgBox = "Table Reservations Empty:" & vbCrLf & vbCrLf & "There are no table reservations in the system."
            EZMsgBox.Show(strMsgBox, MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If

    End Sub

    Private Sub cmdDeleteBooking_Click(sender As Object, e As EventArgs) Handles cmdDeleteBooking.Click

        Try
            If ugdBookings.ActiveRow IsNot Nothing Then
                strMsgBox = "Do you wish to delete the selected reservation?"
                intMsgBoxResult = EZMsgBox.Show(strMsgBox, MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                If intMsgBoxResult = MsgBoxResult.Yes Then
                    _customerService.DeleteBooking(ugdBookings.ActiveRow.Cells("ID").Value)
                    RefreshGrid()
                    ugdBookings.ActiveRow.Delete(False)
                    UpdateLabel()
                End If
            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub RefreshGrid()
        Throw New NotImplementedException
    End Sub

    Private Sub cmdGridUpDown_Click(sender As Object, e As EventArgs) Handles cmdGridUp.Click, cmdGridDown.Click

        If ugdBookings.Rows.Count = 0 Then Exit Sub

        Dim intAdjuster As Short = 0

        If ugdBookings.ActiveRow Is Nothing Then
            ugdBookings.ActiveRow = ugdBookings.Rows(0)
            intAdjuster = -1
        End If

        If sender.name = "cmdGridUp" Then
            If ugdBookings.ActiveRow.Index > 0 Then
                ugdBookings.ActiveRow = ugdBookings.Rows(ugdBookings.ActiveRow.Index - 1)
            Else
                ugdBookings.ActiveRow = ugdBookings.Rows(ugdBookings.Rows.Count - 1)
            End If
        Else
            If ugdBookings.ActiveRow.Index < ugdBookings.Rows.Count - 1 Then
                ugdBookings.ActiveRow = ugdBookings.Rows(ugdBookings.ActiveRow.Index + 1 + intAdjuster)
            Else
                ugdBookings.ActiveRow = ugdBookings.Rows(0)
            End If
        End If

    End Sub

    Private Sub UpdateLabel()

        Dim tValue As Short = 0
        For Each row In ugdBookings.Rows
            tValue += row.Cells("Covers").Value
        Next
        lblBookings.Text = "Reservation: " & ugdBookings.Rows.Count & "    Covers: " & tValue

    End Sub

    Private Sub ugdBookings_AfterRowInsert(sender As Object, e As Infragistics.Win.UltraWinGrid.RowEventArgs) Handles ugdBookings.AfterRowInsert
        UpdateLabel()
    End Sub

    Private Sub cmdEditBooking_Click(sender As Object, e As EventArgs) Handles cmdEditBooking.Click

        cmdUpdate.Tag = Nothing

        If ugdBookings.ActiveRow IsNot Nothing Then

            With ugdBookings.ActiveRow
                cmdUpdate.Tag = .Cells("ID").Value
                txtBookingDate.Text = .Cells("Date").Value
                txtTime.Text = .Cells("Time").Value
                txtName.Text = .Cells("Name").Value
                txtCovers.Text = .Cells("Covers").Value
                txtTelephone.Text = .Cells("Phone").Value
                txtBookingNote.Text = .Cells("Message").Value
                txtTable.Text = .Cells("Table").Value
            End With

            cmdOK.Enabled = False
            cmdClearAll.Enabled = False
            cmdUpdate.Enabled = True

            cmdGridUp.Enabled = False
            cmdGridDown.Enabled = False
            cmdEditBooking.Enabled = False
            cmdViewAll.Enabled = False
            cmdViewSameDate.Enabled = False
            cmdDeleteBooking.Enabled = False
            cmdStatus.Enabled = False

        Else
            strMsgBox = "No reservation has been selected"
            EZMsgBox.Show(strMsgBox, MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
        End If

    End Sub

    Private Sub cmdUpdate_Click(sender As Object, e As EventArgs) Handles cmdUpdate.Click

        Try

            If ValidateInputs() = True Then

                If cmdUpdate.Tag IsNot Nothing Then
                    Dim model As New BookingModel With {
                        .ID = cmdUpdate.Tag,
                        .Name = txtName.Text,
                        .Message = txtBookingNote.Text,
                        .Date = txtBookingDate.Text,
                        .Covers = txtCovers.Text,
                        .Phone = txtTelephone.Text,
                        .Time = txtTime.Text,
                        .Table = txtTable.Text
                    }

                    _customerService.UpdateBooking(model)

                End If

                cmdClearAll_Click(sender, e)
                cmdOK.Enabled = True
                cmdClearAll.Enabled = True
                cmdUpdate.Enabled = False

                cmdGridUp.Enabled = True
                cmdGridDown.Enabled = True
                cmdEditBooking.Enabled = True
                cmdViewAll.Enabled = True
                cmdViewSameDate.Enabled = True
                cmdDeleteBooking.Enabled = True
                cmdStatus.Enabled = True

                cmdUpdate.Tag = Nothing
                UpdateLabel()

            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub cmdViewSameDate_Click(sender As Object, e As EventArgs) Handles cmdViewSameDate.Click

        If ugdBookings.ActiveRow IsNot Nothing Then
            tempStr = ugdBookings.ActiveRow.Cells("Date").Value
            If IsDate(tempStr) Then
                GetBookings(tempStr)
            Else
                strMsgBox = "Could not get date from the table"
                EZMsgBox.Show(strMsgBox, MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            End If
        End If

        ugdBookings.ActiveRow = Nothing

    End Sub

    Private Sub cmdKBTable_Click(sender As Object, e As EventArgs) Handles cmdKBTable.Click

        Dim strNumInput As String

        Using objFormQty As New frmQty
            objFormQty.Display("Enter table number", 0)
            strNumInput = objFormQty.ReturnValue
        End Using
        If strNumInput <> "x" Then txtTable.Text = CInt(strNumInput)

    End Sub

    Private Sub cmdStatus_Click(sender As Object, e As EventArgs) Handles cmdStatus.Click

        If ugdBookings.ActiveRow IsNot Nothing Then

            SQLQuery = "SELECT Status FROM Table_Status ORDER BY ID"
            drcDatarowCollection = objDB.GetDataRows(SQLQuery)
            If drcDatarowCollection IsNot Nothing AndAlso drcDatarowCollection.Count > 0 Then
                Dim TableStatusList As New List(Of String)()
                For Each myRow As DataRow In drcDatarowCollection
                    TableStatusList.Add(myRow.Item("Status").ToString())
                Next

                TableStatusList.Add("Reset")

                Dim strResponse As String = CustomList.Show(TableStatusList, False)
                If strResponse = "Reset" Then strResponse = String.Empty

                If strResponse <> strCustomListBoxCancelString Then
                    SQLQuery = $"UPDATE Bookings SET Status = '{strResponse}' 
                                 WHERE ID = {ugdBookings.ActiveRow.Cells("ID").Value}"
                    objDB.ExeNonQuery(SQLQuery)
                    GetBookings(ugdBookings.ActiveRow.Cells("Date").Value)
                    ugdBookings.ActiveRow = Nothing
                    UpdateLabel()
                End If
            Else
                strMsgBox = "There are no status messages saved in the database"
                Alert(strMsgBox)
            End If

        ElseIf ugdBookings.Rows.Count = 0 Then
            strMsgBox = "There are no reservations."
            EZMsgBox.Show(strMsgBox, MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
        Else
            strMsgBox = "No reservation has been selected."
            EZMsgBox.Show(strMsgBox, MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
        End If

    End Sub

    Private Function ValidateInputs() As Boolean

        'some fields must be filled in
        strMsgBox = String.Empty

        txtTime.Text = Replace(txtTime.Text, ".", ":")
        If Not IsDate(txtTime.Text) Then strMsgBox = "Entered time is not valid"
        If Not IsANumber(txtCovers.Text) Then strMsgBox = "Invalid number of covers"
        If txtCovers.Text = String.Empty Then strMsgBox = "You must select number of covers"
        If txtTime.Text = String.Empty Then strMsgBox = "Reservation time is not entered"
        If txtName.Text = String.Empty Then strMsgBox = "Customer name is not entered"
        If txtBookingDate.Text = String.Empty Then strMsgBox = "Reservation date is not entered"
        If (txtTable.Text.Trim <> String.Empty And Not IsANumber(txtTable.Text)) Then strMsgBox = "Invalid table number"
        If txtBookingDate.Text.Trim = String.Empty Then
            strMsgBox = "Date not entered"
        ElseIf IsDate(txtBookingDate.Text) = False Then
            strMsgBox = "Date entered is not valid"
        ElseIf txtBookingDate.Text < CDate(GetDateNow()) Then
            strMsgBox = "Date cannot be in the past"
        End If

        If strMsgBox <> String.Empty Then
            Alert(strMsgBox)
            Return False
        Else
            Return True
        End If

    End Function

    Private Sub ugdBookings_InitializeRow(sender As Object, e As Infragistics.Win.UltraWinGrid.InitializeRowEventArgs) Handles ugdBookings.InitializeRow

        'e.Row.Appearance.BackColor = GetColorFromDB(e.Row.Cells("BookingStatus").Text)

    End Sub

    Private Function GetColorFromDB(strStatus As String) As Color

        SQLQuery = "SELECT Colour FROM Table_Status WHERE Status = '" & strStatus & "'"
        drDataRow = objDB.GetSingleRow(SQLQuery)
        If drDataRow IsNot Nothing Then
            Return Color.FromArgb(drDataRow!Colour)
        End If

    End Function

    Private Sub cmdOnlineBookings_Click(sender As Object, e As EventArgs) Handles cmdOnlineBookings.Click

        Dim onlineServiceManager As New OnlineOrderService()

        Dim allBookings As List(Of BookingModel) = onlineServiceManager.GetBookings()
        Dim currentBookings As List(Of BookingModel) = _customerService.GetAllBookings(False)
        Dim onlineBookings As List(Of BookingModel) = allBookings.Where(Function(b)
                                                                            Dim parsedDate As DateTime
                                                                            If DateTime.TryParse(b.Date, parsedDate) Then
                                                                                Return parsedDate >= DateTime.Today
                                                                            Else
                                                                                Return False
                                                                            End If
                                                                        End Function).ToList()

        Dim newOnlineBookings As List(Of BookingModel) = onlineBookings.Where(Function(ob) Not currentBookings.Any(Function(cb) cb.OnlineID = ob.ID)).ToList()
        If newOnlineBookings.Count = 0 Then
            EZMsgBox.Show("No new online bookings found.", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Return
        End If

        ugdBookings.DataSource = newOnlineBookings
        onlineServiceManager = Nothing

        ToggleButtonsForOnlineBookings(True)

    End Sub

    Private Sub ToggleButtonsForOnlineBookings(onlineMode As Boolean)

        cmdOK.Enabled = Not onlineMode
        cmdClearAll.Enabled = Not onlineMode
        cmdUpdate.Enabled = Not onlineMode
        cmdStatus.Enabled = Not onlineMode
        cmdEditBooking.Enabled = Not onlineMode
        cmdViewSameDate.Enabled = Not onlineMode
        cmdDeleteBooking.Enabled = Not onlineMode

        cmdOnlineBookingAccept.Location = cmdOK.Location
        cmdOnlineBookingAccept.Visible = onlineMode
        cmdOnlineBookingReject.Location = cmdClearAll.Location
        cmdOnlineBookingReject.Visible = onlineMode

        cmdOK.Visible = Not onlineMode

    End Sub

    Private Sub cmdAcceptOnlineBooking_Click(sender As Object, e As EventArgs) Handles cmdOnlineBookingAccept.Click

        HandleOnlineBooking(ugdBookings.ActiveRow, True)

    End Sub

    Private Sub cmdOnlineBookingReject_Click(sender As Object, e As EventArgs) Handles cmdOnlineBookingReject.Click

        HandleOnlineBooking(ugdBookings.ActiveRow, False)

    End Sub

    Private Sub HandleOnlineBooking(row As UltraGridRow, acceptBooking As Boolean)

        If row Is Nothing Then
            EZMsgBox.Show("No booking selected.", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        Dim booking As New BookingModel With {
                    .Name = row.Cells("Name").Value,
                    .Message = row.Cells("Message").Value,
                    .Date = row.Cells("Date").Value,
                    .Covers = row.Cells("Covers").Value,
                    .Phone = row.Cells("Phone").Value,
                    .Time = row.Cells("Time").Value.ToString().Replace("AM", "").Replace("PM", ""),
                    .Table = row.Cells("Table").Value,
                    .OnlineID = row.Cells("ID").Value,
                    .Status = IIf(acceptBooking, "Accepted", "Rejected"),
                    .Email = row.Cells("Email").Value}

        Try
            _customerService.AddBooking(booking)
            ugdBookings.ActiveRow.Delete(False)

            If ugdBookings.Rows.Count > 0 Then
                ugdBookings.ActiveRow = ugdBookings.Rows(0)
            Else
                ugdBookings.ActiveRow = Nothing
            End If

            If acceptBooking Then
                EZMsgBox.Show("Booking accepted and saved.", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                EZMsgBox.Show("Booking rejected and removed from the list.", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If

        Catch ex As Exception
            EZMsgBox.Show("Error saving booking: " & ex.Message, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

End Class