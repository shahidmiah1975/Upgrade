﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCustomers
    Inherits EZMenu.frmBaseForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
   Protected Overrides Sub Dispose(ByVal disposing As Boolean)
      Try
         If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
         End If
      Finally
         MyBase.Dispose(disposing)
      End Try
   End Sub

   'Required by the Windows Form Designer
   Private components As System.ComponentModel.IContainer

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   <System.Diagnostics.DebuggerStepThrough()> _
   Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim Appearance1 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance2 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraGridBand1 As Infragistics.Win.UltraWinGrid.UltraGridBand = New Infragistics.Win.UltraWinGrid.UltraGridBand("Customer", -1)
        Dim UltraGridColumn1 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("CustomerID")
        Dim UltraGridColumn2 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Name")
        Dim UltraGridColumn3 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Phone")
        Dim UltraGridColumn4 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Address1")
        Dim UltraGridColumn5 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Address2")
        Dim UltraGridColumn6 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Address3")
        Dim UltraGridColumn7 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Postcode")
        Dim UltraGridColumn8 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Email")
        Dim Appearance3 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance4 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance5 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance6 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance7 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance8 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance9 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance10 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance11 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance12 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance13 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance14 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance15 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance16 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance17 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance18 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance19 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance20 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance21 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance22 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance23 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance24 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance25 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance26 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance27 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmCustomers))
        Dim Appearance28 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance29 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance30 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Me.CustomerDataSet = New EZMenu.EZMenuDataSet()
        Me.cmbSearchType = New System.Windows.Forms.ComboBox()
        Me.lblNumRecs = New System.Windows.Forms.Label()
        Me.lblAltPhone = New Infragistics.Win.Misc.UltraLabel()
        Me.ugdCustomer = New Infragistics.Win.UltraWinGrid.UltraGrid()
        Me.CustomerBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.txtAltPhone = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.lstAltPhone = New System.Windows.Forms.ListBox()
        Me.cmdClose = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDeleteCustomer = New Infragistics.Win.Misc.UltraButton()
        Me.cmdAddCustomer = New Infragistics.Win.Misc.UltraButton()
        Me.cmdShowAll = New Infragistics.Win.Misc.UltraButton()
        Me.cmdSearch = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDelAltPhone = New Infragistics.Win.Misc.UltraButton()
        Me.cmdAddAltPhone = New Infragistics.Win.Misc.UltraButton()
        Me.txtSearchString = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.UltraLabel1 = New Infragistics.Win.Misc.UltraLabel()
        Me.cmdEditCustomer = New Infragistics.Win.Misc.UltraButton()
        Me.CustomerTableAdapter = New EZMenu.EZMenuDataSetTableAdapters.CustomerTableAdapter()
        Me.cmdMergeCustomer = New Infragistics.Win.Misc.UltraButton()
        Me.cmdBack = New Infragistics.Win.Misc.UltraButton()
        Me.ugbOptions = New Infragistics.Win.Misc.UltraGroupBox()
        Me.uplBasePanel.SuspendLayout()
        CType(Me.CustomerDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ugdCustomer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CustomerBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtAltPhone, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtSearchString, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ugbOptions, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ugbOptions.SuspendLayout()
        Me.SuspendLayout()
        '
        'uplBasePanel
        '
        Me.uplBasePanel.Location = New System.Drawing.Point(0, 665)
        Me.uplBasePanel.Size = New System.Drawing.Size(1029, 50)
        '
        'CustomerDataSet
        '
        Me.CustomerDataSet.DataSetName = "CustomerDataSet"
        Me.CustomerDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'cmbSearchType
        '
        Me.cmbSearchType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbSearchType.Font = New System.Drawing.Font("Arial", 10.0!)
        Me.cmbSearchType.FormattingEnabled = True
        Me.cmbSearchType.Items.AddRange(New Object() {"Name", "Address"})
        Me.cmbSearchType.Location = New System.Drawing.Point(10, 80)
        Me.cmbSearchType.Name = "cmbSearchType"
        Me.cmbSearchType.Size = New System.Drawing.Size(120, 24)
        Me.cmbSearchType.TabIndex = 9
        '
        'lblNumRecs
        '
        Me.lblNumRecs.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblNumRecs.AutoSize = True
        Me.lblNumRecs.BackColor = System.Drawing.Color.Transparent
        Me.lblNumRecs.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNumRecs.ForeColor = System.Drawing.Color.DimGray
        Me.lblNumRecs.Location = New System.Drawing.Point(9, 684)
        Me.lblNumRecs.Name = "lblNumRecs"
        Me.lblNumRecs.Size = New System.Drawing.Size(102, 15)
        Me.lblNumRecs.TabIndex = 10
        Me.lblNumRecs.Text = "Records Founds:"
        '
        'lblAltPhone
        '
        Appearance1.BackColor = System.Drawing.Color.Transparent
        Appearance1.ForeColor = System.Drawing.Color.SlateGray
        Appearance1.TextHAlignAsString = "Center"
        Me.lblAltPhone.Appearance = Appearance1
        Me.lblAltPhone.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAltPhone.Location = New System.Drawing.Point(10, 177)
        Me.lblAltPhone.Name = "lblAltPhone"
        Me.lblAltPhone.Size = New System.Drawing.Size(201, 42)
        Me.lblAltPhone.TabIndex = 72
        Me.lblAltPhone.UseAppStyling = False
        '
        'ugdCustomer
        '
        Me.ugdCustomer.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ugdCustomer.DataSource = Me.CustomerBindingSource
        Appearance2.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance2.BackColor2 = System.Drawing.Color.White
        Appearance2.BackHatchStyle = Infragistics.Win.BackHatchStyle.LightHorizontal
        Appearance2.BorderColor = System.Drawing.Color.Silver
        Me.ugdCustomer.DisplayLayout.Appearance = Appearance2
        UltraGridColumn1.CellActivation = Infragistics.Win.UltraWinGrid.Activation.ActivateOnly
        UltraGridColumn1.Header.Caption = "ID"
        UltraGridColumn1.Header.Editor = Nothing
        UltraGridColumn1.Header.VisiblePosition = 0
        UltraGridColumn1.Width = 40
        UltraGridColumn2.Header.Editor = Nothing
        UltraGridColumn2.Header.VisiblePosition = 1
        UltraGridColumn2.Width = 100
        UltraGridColumn3.Header.Editor = Nothing
        UltraGridColumn3.Header.VisiblePosition = 2
        UltraGridColumn3.Width = 100
        UltraGridColumn4.Header.Editor = Nothing
        UltraGridColumn4.Header.VisiblePosition = 3
        UltraGridColumn5.Header.Editor = Nothing
        UltraGridColumn5.Header.VisiblePosition = 4
        UltraGridColumn6.Header.Editor = Nothing
        UltraGridColumn6.Header.VisiblePosition = 5
        UltraGridColumn7.Header.Editor = Nothing
        UltraGridColumn7.Header.VisiblePosition = 6
        UltraGridColumn8.Header.Editor = Nothing
        UltraGridColumn8.Header.VisiblePosition = 7
        UltraGridBand1.Columns.AddRange(New Object() {UltraGridColumn1, UltraGridColumn2, UltraGridColumn3, UltraGridColumn4, UltraGridColumn5, UltraGridColumn6, UltraGridColumn7, UltraGridColumn8})
        Me.ugdCustomer.DisplayLayout.BandsSerializer.Add(UltraGridBand1)
        Me.ugdCustomer.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Appearance3.FontData.BoldAsString = "True"
        Appearance3.FontData.Name = "Arial"
        Appearance3.FontData.SizeInPoints = 11.0!
        Appearance3.FontData.StrikeoutAsString = "False"
        Appearance3.ForeColor = System.Drawing.Color.MidnightBlue
        Me.ugdCustomer.DisplayLayout.CaptionAppearance = Appearance3
        Me.ugdCustomer.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.[False]
        Appearance4.BackColor = System.Drawing.SystemColors.ActiveBorder
        Appearance4.BackColor2 = System.Drawing.SystemColors.ControlDark
        Appearance4.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance4.BorderColor = System.Drawing.SystemColors.Window
        Me.ugdCustomer.DisplayLayout.GroupByBox.Appearance = Appearance4
        Appearance5.ForeColor = System.Drawing.SystemColors.GrayText
        Me.ugdCustomer.DisplayLayout.GroupByBox.BandLabelAppearance = Appearance5
        Me.ugdCustomer.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Me.ugdCustomer.DisplayLayout.GroupByBox.Hidden = True
        Appearance6.BackColor = System.Drawing.SystemColors.ControlLightLight
        Appearance6.BackColor2 = System.Drawing.SystemColors.Control
        Appearance6.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal
        Appearance6.ForeColor = System.Drawing.SystemColors.GrayText
        Me.ugdCustomer.DisplayLayout.GroupByBox.PromptAppearance = Appearance6
        Me.ugdCustomer.DisplayLayout.MaxColScrollRegions = 1
        Me.ugdCustomer.DisplayLayout.MaxRowScrollRegions = 1
        Appearance7.BackColor = System.Drawing.SystemColors.Window
        Appearance7.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ugdCustomer.DisplayLayout.Override.ActiveCellAppearance = Appearance7
        Appearance8.BackColor = System.Drawing.Color.DarkOrange
        Appearance8.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance8.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ugdCustomer.DisplayLayout.Override.ActiveRowAppearance = Appearance8
        Me.ugdCustomer.DisplayLayout.Override.AllowColMoving = Infragistics.Win.UltraWinGrid.AllowColMoving.NotAllowed
        Me.ugdCustomer.DisplayLayout.Override.AllowColSwapping = Infragistics.Win.UltraWinGrid.AllowColSwapping.NotAllowed
        Me.ugdCustomer.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted
        Me.ugdCustomer.DisplayLayout.Override.BorderStyleHeader = Infragistics.Win.UIElementBorderStyle.Etched
        Me.ugdCustomer.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted
        Appearance9.BackColor = System.Drawing.Color.Transparent
        Me.ugdCustomer.DisplayLayout.Override.CardAreaAppearance = Appearance9
        Appearance10.BackColor = System.Drawing.Color.LightYellow
        Appearance10.BackColor2 = System.Drawing.Color.PaleGoldenrod
        Appearance10.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Me.ugdCustomer.DisplayLayout.Override.CellAppearance = Appearance10
        Me.ugdCustomer.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.EditAndSelectText
        Me.ugdCustomer.DisplayLayout.Override.CellPadding = 0
        Appearance11.BackColor = System.Drawing.SystemColors.Control
        Appearance11.BackColor2 = System.Drawing.SystemColors.ControlDark
        Appearance11.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element
        Appearance11.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal
        Appearance11.BorderColor = System.Drawing.SystemColors.Window
        Me.ugdCustomer.DisplayLayout.Override.GroupByRowAppearance = Appearance11
        Appearance12.BackColor = System.Drawing.Color.CornflowerBlue
        Appearance12.BackColor2 = System.Drawing.Color.RoyalBlue
        Appearance12.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance12.FontData.BoldAsString = "True"
        Appearance12.FontData.SizeInPoints = 9.0!
        Appearance12.ForeColor = System.Drawing.Color.White
        Appearance12.ThemedElementAlpha = Infragistics.Win.Alpha.Transparent
        Me.ugdCustomer.DisplayLayout.Override.HeaderAppearance = Appearance12
        Me.ugdCustomer.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti
        Me.ugdCustomer.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand
        Appearance13.BackColor = System.Drawing.SystemColors.Window
        Appearance13.BorderColor = System.Drawing.Color.Silver
        Me.ugdCustomer.DisplayLayout.Override.RowAppearance = Appearance13
        Appearance14.BackColor = System.Drawing.Color.Transparent
        Appearance14.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ugdCustomer.DisplayLayout.Override.RowSelectorAppearance = Appearance14
        Me.ugdCustomer.DisplayLayout.Override.RowSelectorHeaderStyle = Infragistics.Win.UltraWinGrid.RowSelectorHeaderStyle.SeparateElement
        Me.ugdCustomer.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.[True]
        Me.ugdCustomer.DisplayLayout.Override.RowSelectorWidth = 10
        Me.ugdCustomer.DisplayLayout.Override.RowSizing = Infragistics.Win.UltraWinGrid.RowSizing.AutoFree
        Me.ugdCustomer.DisplayLayout.Override.RowSizingArea = Infragistics.Win.UltraWinGrid.RowSizingArea.RowBordersOnly
        Me.ugdCustomer.DisplayLayout.Override.RowSpacingAfter = 1
        Me.ugdCustomer.DisplayLayout.Override.RowSpacingBefore = 0
        Appearance15.BackColor = System.Drawing.Color.Navy
        Appearance15.BackGradientStyle = Infragistics.Win.GradientStyle.None
        Appearance15.BackHatchStyle = Infragistics.Win.BackHatchStyle.None
        Appearance15.ForeColor = System.Drawing.Color.White
        Me.ugdCustomer.DisplayLayout.Override.SelectedRowAppearance = Appearance15
        Appearance16.BackColor = System.Drawing.SystemColors.ControlLight
        Me.ugdCustomer.DisplayLayout.Override.TemplateAddRowAppearance = Appearance16
        Me.ugdCustomer.DisplayLayout.RowConnectorColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ugdCustomer.DisplayLayout.RowConnectorStyle = Infragistics.Win.UltraWinGrid.RowConnectorStyle.Solid
        Me.ugdCustomer.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill
        Me.ugdCustomer.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate
        Me.ugdCustomer.DisplayLayout.ViewStyle = Infragistics.Win.UltraWinGrid.ViewStyle.SingleBand
        Me.ugdCustomer.DisplayLayout.ViewStyleBand = Infragistics.Win.UltraWinGrid.ViewStyleBand.OutlookGroupBy
        Me.ugdCustomer.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ugdCustomer.Location = New System.Drawing.Point(12, 58)
        Me.ugdCustomer.Name = "ugdCustomer"
        Me.ugdCustomer.Size = New System.Drawing.Size(768, 588)
        Me.ugdCustomer.TabIndex = 459
        '
        'CustomerBindingSource
        '
        Me.CustomerBindingSource.DataMember = "Customer"
        Me.CustomerBindingSource.DataSource = Me.CustomerDataSet
        '
        'txtAltPhone
        '
        Me.txtAltPhone.Font = New System.Drawing.Font("Arial", 10.0!)
        Me.txtAltPhone.Location = New System.Drawing.Point(13, 225)
        Me.txtAltPhone.Name = "txtAltPhone"
        Me.txtAltPhone.Size = New System.Drawing.Size(120, 24)
        Me.txtAltPhone.TabIndex = 478
        '
        'lstAltPhone
        '
        Me.lstAltPhone.Font = New System.Drawing.Font("Arial", 10.0!)
        Me.lstAltPhone.FormattingEnabled = True
        Me.lstAltPhone.ItemHeight = 16
        Me.lstAltPhone.Location = New System.Drawing.Point(13, 255)
        Me.lstAltPhone.Name = "lstAltPhone"
        Me.lstAltPhone.Size = New System.Drawing.Size(120, 68)
        Me.lstAltPhone.TabIndex = 479
        '
        'cmdClose
        '
        Me.cmdClose.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance17.BackColor = System.Drawing.Color.Transparent
        Me.cmdClose.Appearance = Appearance17
        Me.cmdClose.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdClose.Location = New System.Drawing.Point(60, 457)
        Me.cmdClose.Name = "cmdClose"
        Me.cmdClose.ShowFocusRect = False
        Me.cmdClose.ShowOutline = False
        Me.cmdClose.Size = New System.Drawing.Size(105, 35)
        Me.cmdClose.StyleSetName = "TextButton"
        Me.cmdClose.TabIndex = 521
        Me.cmdClose.Text = "Close"
        Me.cmdClose.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        '
        'cmdDeleteCustomer
        '
        Me.cmdDeleteCustomer.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance18.BackColor = System.Drawing.Color.Transparent
        Me.cmdDeleteCustomer.Appearance = Appearance18
        Me.cmdDeleteCustomer.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdDeleteCustomer.Location = New System.Drawing.Point(60, 375)
        Me.cmdDeleteCustomer.Name = "cmdDeleteCustomer"
        Me.cmdDeleteCustomer.ShowFocusRect = False
        Me.cmdDeleteCustomer.ShowOutline = False
        Me.cmdDeleteCustomer.Size = New System.Drawing.Size(105, 35)
        Me.cmdDeleteCustomer.StyleSetName = "TextButton"
        Me.cmdDeleteCustomer.TabIndex = 520
        Me.cmdDeleteCustomer.Text = "Delete"
        Me.cmdDeleteCustomer.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        '
        'cmdAddCustomer
        '
        Me.cmdAddCustomer.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance19.BackColor = System.Drawing.Color.Transparent
        Me.cmdAddCustomer.Appearance = Appearance19
        Me.cmdAddCustomer.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdAddCustomer.Location = New System.Drawing.Point(16, 375)
        Me.cmdAddCustomer.Name = "cmdAddCustomer"
        Me.cmdAddCustomer.ShowFocusRect = False
        Me.cmdAddCustomer.ShowOutline = False
        Me.cmdAddCustomer.Size = New System.Drawing.Size(105, 35)
        Me.cmdAddCustomer.StyleSetName = "TextButton"
        Me.cmdAddCustomer.TabIndex = 519
        Me.cmdAddCustomer.Text = "Add"
        Me.cmdAddCustomer.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdAddCustomer.Visible = False
        '
        'cmdShowAll
        '
        Appearance20.BackColor = System.Drawing.Color.Transparent
        Me.cmdShowAll.Appearance = Appearance20
        Me.cmdShowAll.Font = New System.Drawing.Font("Arial", 10.0!)
        Me.cmdShowAll.Location = New System.Drawing.Point(136, 80)
        Me.cmdShowAll.Name = "cmdShowAll"
        Me.cmdShowAll.ShowFocusRect = False
        Me.cmdShowAll.ShowOutline = False
        Me.cmdShowAll.Size = New System.Drawing.Size(75, 26)
        Me.cmdShowAll.StyleSetName = "TextButton"
        Me.cmdShowAll.TabIndex = 524
        Me.cmdShowAll.Text = "Show All"
        Me.cmdShowAll.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        '
        'cmdSearch
        '
        Appearance21.BackColor = System.Drawing.Color.Transparent
        Me.cmdSearch.Appearance = Appearance21
        Me.cmdSearch.Font = New System.Drawing.Font("Arial", 10.0!)
        Me.cmdSearch.Location = New System.Drawing.Point(136, 48)
        Me.cmdSearch.Name = "cmdSearch"
        Me.cmdSearch.ShowFocusRect = False
        Me.cmdSearch.ShowOutline = False
        Me.cmdSearch.Size = New System.Drawing.Size(75, 26)
        Me.cmdSearch.StyleSetName = "TextButton"
        Me.cmdSearch.TabIndex = 523
        Me.cmdSearch.Text = "Search"
        Me.cmdSearch.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        '
        'cmdDelAltPhone
        '
        Appearance22.BackColor = System.Drawing.Color.Transparent
        Me.cmdDelAltPhone.Appearance = Appearance22
        Me.cmdDelAltPhone.Font = New System.Drawing.Font("Arial", 10.0!)
        Me.cmdDelAltPhone.Location = New System.Drawing.Point(139, 255)
        Me.cmdDelAltPhone.Name = "cmdDelAltPhone"
        Me.cmdDelAltPhone.ShowFocusRect = False
        Me.cmdDelAltPhone.ShowOutline = False
        Me.cmdDelAltPhone.Size = New System.Drawing.Size(75, 26)
        Me.cmdDelAltPhone.StyleSetName = "TextButton"
        Me.cmdDelAltPhone.TabIndex = 526
        Me.cmdDelAltPhone.Text = "Delete"
        Me.cmdDelAltPhone.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        '
        'cmdAddAltPhone
        '
        Appearance23.BackColor = System.Drawing.Color.Transparent
        Me.cmdAddAltPhone.Appearance = Appearance23
        Me.cmdAddAltPhone.Font = New System.Drawing.Font("Arial", 10.0!)
        Me.cmdAddAltPhone.Location = New System.Drawing.Point(139, 225)
        Me.cmdAddAltPhone.Name = "cmdAddAltPhone"
        Me.cmdAddAltPhone.ShowFocusRect = False
        Me.cmdAddAltPhone.ShowOutline = False
        Me.cmdAddAltPhone.Size = New System.Drawing.Size(75, 26)
        Me.cmdAddAltPhone.StyleSetName = "TextButton"
        Me.cmdAddAltPhone.TabIndex = 525
        Me.cmdAddAltPhone.Text = "Add"
        Me.cmdAddAltPhone.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        '
        'txtSearchString
        '
        Me.txtSearchString.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSearchString.Location = New System.Drawing.Point(10, 48)
        Me.txtSearchString.Name = "txtSearchString"
        Me.txtSearchString.Size = New System.Drawing.Size(120, 24)
        Me.txtSearchString.TabIndex = 527
        '
        'UltraLabel1
        '
        Appearance24.BackColor = System.Drawing.Color.Transparent
        Appearance24.ForeColor = System.Drawing.Color.SlateGray
        Appearance24.TextHAlignAsString = "Center"
        Me.UltraLabel1.Appearance = Appearance24
        Me.UltraLabel1.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UltraLabel1.Location = New System.Drawing.Point(10, 18)
        Me.UltraLabel1.Name = "UltraLabel1"
        Me.UltraLabel1.Size = New System.Drawing.Size(201, 24)
        Me.UltraLabel1.TabIndex = 528
        Me.UltraLabel1.Text = "Search customer database:"
        Me.UltraLabel1.UseAppStyling = False
        '
        'cmdEditCustomer
        '
        Me.cmdEditCustomer.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance25.BackColor = System.Drawing.Color.Transparent
        Me.cmdEditCustomer.Appearance = Appearance25
        Me.cmdEditCustomer.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdEditCustomer.Location = New System.Drawing.Point(16, 416)
        Me.cmdEditCustomer.Name = "cmdEditCustomer"
        Me.cmdEditCustomer.ShowFocusRect = False
        Me.cmdEditCustomer.ShowOutline = False
        Me.cmdEditCustomer.Size = New System.Drawing.Size(105, 35)
        Me.cmdEditCustomer.StyleSetName = "TextButton"
        Me.cmdEditCustomer.TabIndex = 529
        Me.cmdEditCustomer.Text = "Edit"
        Me.cmdEditCustomer.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdEditCustomer.Visible = False
        '
        'CustomerTableAdapter
        '
        Me.CustomerTableAdapter.ClearBeforeFill = True
        '
        'cmdMergeCustomer
        '
        Me.cmdMergeCustomer.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance26.BackColor = System.Drawing.Color.Transparent
        Me.cmdMergeCustomer.Appearance = Appearance26
        Me.cmdMergeCustomer.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdMergeCustomer.Location = New System.Drawing.Point(60, 416)
        Me.cmdMergeCustomer.Name = "cmdMergeCustomer"
        Me.cmdMergeCustomer.ShowFocusRect = False
        Me.cmdMergeCustomer.ShowOutline = False
        Me.cmdMergeCustomer.Size = New System.Drawing.Size(105, 35)
        Me.cmdMergeCustomer.StyleSetName = "TextButton"
        Me.cmdMergeCustomer.TabIndex = 530
        Me.cmdMergeCustomer.Text = "Merge"
        Me.cmdMergeCustomer.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        '
        'cmdBack
        '
        Me.cmdBack.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Appearance27.BackColor = System.Drawing.Color.Transparent
        Appearance27.BackColor2 = System.Drawing.Color.Transparent
        Appearance27.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance27.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance27.BorderColor = System.Drawing.Color.Transparent
        Appearance27.BorderColor2 = System.Drawing.Color.Maroon
        Appearance27.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance27.ForeColor = System.Drawing.Color.White
        Appearance27.Image = CType(resources.GetObject("Appearance27.Image"), Object)
        Appearance27.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance27.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance27.TextVAlignAsString = "Bottom"
        Me.cmdBack.Appearance = Appearance27
        Me.cmdBack.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance28.BackColor = System.Drawing.Color.DarkOrange
        Appearance28.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance28.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance28.BorderColor = System.Drawing.Color.Transparent
        Appearance28.ForeColor = System.Drawing.Color.Black
        Me.cmdBack.HotTrackAppearance = Appearance28
        Me.cmdBack.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdBack.Location = New System.Drawing.Point(479, 670)
        Me.cmdBack.Name = "cmdBack"
        Appearance29.BackColor = System.Drawing.Color.OrangeRed
        Appearance29.BackColor2 = System.Drawing.Color.Tomato
        Appearance29.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance29.BorderColor = System.Drawing.Color.Transparent
        Me.cmdBack.PressedAppearance = Appearance29
        Me.cmdBack.ShowFocusRect = False
        Me.cmdBack.ShowOutline = False
        Me.cmdBack.Size = New System.Drawing.Size(70, 39)
        Me.cmdBack.StyleSetName = "StatusBar"
        Me.cmdBack.TabIndex = 556
        Me.cmdBack.Tag = "Return"
        Me.cmdBack.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdBack.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdBack.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ugbOptions
        '
        Me.ugbOptions.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance30.BackColor = System.Drawing.Color.Transparent
        Appearance30.BorderColor = System.Drawing.Color.Firebrick
        Me.ugbOptions.Appearance = Appearance30
        Me.ugbOptions.BorderStyle = Infragistics.Win.Misc.GroupBoxBorderStyle.Rectangular3D
        Me.ugbOptions.Controls.Add(Me.UltraLabel1)
        Me.ugbOptions.Controls.Add(Me.cmbSearchType)
        Me.ugbOptions.Controls.Add(Me.lblAltPhone)
        Me.ugbOptions.Controls.Add(Me.lstAltPhone)
        Me.ugbOptions.Controls.Add(Me.txtAltPhone)
        Me.ugbOptions.Controls.Add(Me.cmdMergeCustomer)
        Me.ugbOptions.Controls.Add(Me.txtSearchString)
        Me.ugbOptions.Controls.Add(Me.cmdEditCustomer)
        Me.ugbOptions.Controls.Add(Me.cmdSearch)
        Me.ugbOptions.Controls.Add(Me.cmdClose)
        Me.ugbOptions.Controls.Add(Me.cmdDelAltPhone)
        Me.ugbOptions.Controls.Add(Me.cmdDeleteCustomer)
        Me.ugbOptions.Controls.Add(Me.cmdAddCustomer)
        Me.ugbOptions.Controls.Add(Me.cmdShowAll)
        Me.ugbOptions.Controls.Add(Me.cmdAddAltPhone)
        Me.ugbOptions.Location = New System.Drawing.Point(796, 103)
        Me.ugbOptions.Name = "ugbOptions"
        Me.ugbOptions.Size = New System.Drawing.Size(225, 533)
        Me.ugbOptions.TabIndex = 557
        '
        'frmCustomers
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1029, 715)
        Me.Controls.Add(Me.lblNumRecs)
        Me.Controls.Add(Me.cmdBack)
        Me.Controls.Add(Me.ugbOptions)
        Me.Controls.Add(Me.ugdCustomer)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmCustomers"
        Me.Controls.SetChildIndex(Me.uplBasePanel, 0)
        Me.Controls.SetChildIndex(Me.ugdCustomer, 0)
        Me.Controls.SetChildIndex(Me.ugbOptions, 0)
        Me.Controls.SetChildIndex(Me.cmdBack, 0)
        Me.Controls.SetChildIndex(Me.lblNumRecs, 0)
        Me.uplBasePanel.ResumeLayout(False)
        CType(Me.CustomerDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ugdCustomer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CustomerBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtAltPhone, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtSearchString, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ugbOptions, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ugbOptions.ResumeLayout(False)
        Me.ugbOptions.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents cmbSearchType As System.Windows.Forms.ComboBox
    Friend WithEvents lblNumRecs As System.Windows.Forms.Label
    Friend WithEvents lblAltPhone As Infragistics.Win.Misc.UltraLabel
    Private WithEvents CustomerDataSet As EZMenu.EZMenuDataSet
    Friend WithEvents ugdCustomer As Infragistics.Win.UltraWinGrid.UltraGrid
    Friend WithEvents txtAltPhone As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents lstAltPhone As System.Windows.Forms.ListBox
    Friend WithEvents cmdClose As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDeleteCustomer As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdAddCustomer As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdShowAll As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdSearch As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDelAltPhone As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdAddAltPhone As Infragistics.Win.Misc.UltraButton
    Friend WithEvents txtSearchString As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents UltraLabel1 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents cmdEditCustomer As Infragistics.Win.Misc.UltraButton
    Friend WithEvents CustomerBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents CustomerTableAdapter As EZMenu.EZMenuDataSetTableAdapters.CustomerTableAdapter
    Friend WithEvents cmdMergeCustomer As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdBack As Infragistics.Win.Misc.UltraButton
    Private WithEvents ugbOptions As Infragistics.Win.Misc.UltraGroupBox

End Class
