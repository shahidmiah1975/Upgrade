﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmDishCascadeMenu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim Appearance1 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance2 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance3 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance4 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance5 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance6 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance7 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance8 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance9 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance10 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmDishCascadeMenu))
        Dim Appearance11 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance12 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Me.cmdDC6 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDC5 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDC7 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDC4 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDC8 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDC3 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDC9 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDC2 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDC1 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdCancel = New Infragistics.Win.Misc.UltraButton()
        Me.SuspendLayout()
        '
        'cmdDC6
        '
        Appearance1.BackColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Appearance1.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance1.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance1.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance1.ForeColor = System.Drawing.Color.DimGray
        Appearance1.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance1.ImageVAlign = Infragistics.Win.VAlign.Top
        Me.cmdDC6.Appearance = Appearance1
        Me.cmdDC6.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdDC6.ImageSize = New System.Drawing.Size(48, 48)
        Me.cmdDC6.Location = New System.Drawing.Point(16, 346)
        Me.cmdDC6.Name = "cmdDC6"
        Me.cmdDC6.ShowFocusRect = False
        Me.cmdDC6.ShowOutline = False
        Me.cmdDC6.Size = New System.Drawing.Size(193, 60)
        Me.cmdDC6.StyleSetName = "OECascadeButton"
        Me.cmdDC6.TabIndex = 571
        Me.cmdDC6.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDC6.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdDC6.Visible = False
        '
        'cmdDC5
        '
        Appearance2.BackColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Appearance2.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance2.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance2.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance2.ForeColor = System.Drawing.Color.DimGray
        Appearance2.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance2.ImageVAlign = Infragistics.Win.VAlign.Top
        Me.cmdDC5.Appearance = Appearance2
        Me.cmdDC5.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdDC5.ImageSize = New System.Drawing.Size(48, 48)
        Me.cmdDC5.Location = New System.Drawing.Point(16, 280)
        Me.cmdDC5.Name = "cmdDC5"
        Me.cmdDC5.ShowFocusRect = False
        Me.cmdDC5.ShowOutline = False
        Me.cmdDC5.Size = New System.Drawing.Size(193, 60)
        Me.cmdDC5.StyleSetName = "OECascadeButton"
        Me.cmdDC5.TabIndex = 570
        Me.cmdDC5.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDC5.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdDC5.Visible = False
        '
        'cmdDC7
        '
        Appearance3.BackColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Appearance3.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance3.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance3.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance3.ForeColor = System.Drawing.Color.DimGray
        Appearance3.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance3.ImageVAlign = Infragistics.Win.VAlign.Top
        Me.cmdDC7.Appearance = Appearance3
        Me.cmdDC7.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdDC7.ImageSize = New System.Drawing.Size(48, 48)
        Me.cmdDC7.Location = New System.Drawing.Point(16, 412)
        Me.cmdDC7.Name = "cmdDC7"
        Me.cmdDC7.ShowFocusRect = False
        Me.cmdDC7.ShowOutline = False
        Me.cmdDC7.Size = New System.Drawing.Size(193, 60)
        Me.cmdDC7.StyleSetName = "OECascadeButton"
        Me.cmdDC7.TabIndex = 572
        Me.cmdDC7.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDC7.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdDC7.Visible = False
        '
        'cmdDC4
        '
        Appearance4.BackColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Appearance4.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance4.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance4.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance4.ForeColor = System.Drawing.Color.DimGray
        Appearance4.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance4.ImageVAlign = Infragistics.Win.VAlign.Top
        Me.cmdDC4.Appearance = Appearance4
        Me.cmdDC4.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdDC4.ImageSize = New System.Drawing.Size(48, 48)
        Me.cmdDC4.Location = New System.Drawing.Point(16, 214)
        Me.cmdDC4.Name = "cmdDC4"
        Me.cmdDC4.ShowFocusRect = False
        Me.cmdDC4.ShowOutline = False
        Me.cmdDC4.Size = New System.Drawing.Size(193, 60)
        Me.cmdDC4.StyleSetName = "OECascadeButton"
        Me.cmdDC4.TabIndex = 569
        Me.cmdDC4.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDC4.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdDC4.Visible = False
        '
        'cmdDC8
        '
        Appearance5.BackColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Appearance5.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance5.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance5.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance5.ForeColor = System.Drawing.Color.DimGray
        Appearance5.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance5.ImageVAlign = Infragistics.Win.VAlign.Top
        Me.cmdDC8.Appearance = Appearance5
        Me.cmdDC8.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdDC8.ImageSize = New System.Drawing.Size(48, 48)
        Me.cmdDC8.Location = New System.Drawing.Point(16, 478)
        Me.cmdDC8.Name = "cmdDC8"
        Me.cmdDC8.ShowFocusRect = False
        Me.cmdDC8.ShowOutline = False
        Me.cmdDC8.Size = New System.Drawing.Size(193, 60)
        Me.cmdDC8.StyleSetName = "OECascadeButton"
        Me.cmdDC8.TabIndex = 573
        Me.cmdDC8.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDC8.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdDC8.Visible = False
        '
        'cmdDC3
        '
        Appearance6.BackColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Appearance6.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance6.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance6.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance6.ForeColor = System.Drawing.Color.DimGray
        Appearance6.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance6.ImageVAlign = Infragistics.Win.VAlign.Top
        Me.cmdDC3.Appearance = Appearance6
        Me.cmdDC3.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdDC3.ImageSize = New System.Drawing.Size(48, 48)
        Me.cmdDC3.Location = New System.Drawing.Point(16, 148)
        Me.cmdDC3.Name = "cmdDC3"
        Me.cmdDC3.ShowFocusRect = False
        Me.cmdDC3.ShowOutline = False
        Me.cmdDC3.Size = New System.Drawing.Size(193, 60)
        Me.cmdDC3.StyleSetName = "OECascadeButton"
        Me.cmdDC3.TabIndex = 568
        Me.cmdDC3.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDC3.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdDC3.Visible = False
        '
        'cmdDC9
        '
        Appearance7.BackColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Appearance7.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance7.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance7.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance7.ForeColor = System.Drawing.Color.DimGray
        Appearance7.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance7.ImageVAlign = Infragistics.Win.VAlign.Top
        Me.cmdDC9.Appearance = Appearance7
        Me.cmdDC9.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdDC9.ImageSize = New System.Drawing.Size(48, 48)
        Me.cmdDC9.Location = New System.Drawing.Point(16, 544)
        Me.cmdDC9.Name = "cmdDC9"
        Me.cmdDC9.ShowFocusRect = False
        Me.cmdDC9.ShowOutline = False
        Me.cmdDC9.Size = New System.Drawing.Size(193, 60)
        Me.cmdDC9.StyleSetName = "OECascadeButton"
        Me.cmdDC9.TabIndex = 574
        Me.cmdDC9.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDC9.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdDC9.Visible = False
        '
        'cmdDC2
        '
        Appearance8.BackColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Appearance8.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance8.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance8.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance8.ForeColor = System.Drawing.Color.DimGray
        Appearance8.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance8.ImageVAlign = Infragistics.Win.VAlign.Top
        Me.cmdDC2.Appearance = Appearance8
        Me.cmdDC2.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdDC2.ImageSize = New System.Drawing.Size(48, 48)
        Me.cmdDC2.Location = New System.Drawing.Point(16, 82)
        Me.cmdDC2.Name = "cmdDC2"
        Me.cmdDC2.ShowFocusRect = False
        Me.cmdDC2.ShowOutline = False
        Me.cmdDC2.Size = New System.Drawing.Size(193, 60)
        Me.cmdDC2.StyleSetName = "OECascadeButton"
        Me.cmdDC2.TabIndex = 567
        Me.cmdDC2.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDC2.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdDC2.Visible = False
        '
        'cmdDC1
        '
        Appearance9.BackColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Appearance9.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance9.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance9.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance9.ForeColor = System.Drawing.Color.DimGray
        Appearance9.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance9.ImageVAlign = Infragistics.Win.VAlign.Top
        Me.cmdDC1.Appearance = Appearance9
        Me.cmdDC1.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdDC1.ImageSize = New System.Drawing.Size(48, 48)
        Me.cmdDC1.Location = New System.Drawing.Point(16, 16)
        Me.cmdDC1.Name = "cmdDC1"
        Me.cmdDC1.ShowFocusRect = False
        Me.cmdDC1.ShowOutline = False
        Me.cmdDC1.Size = New System.Drawing.Size(193, 60)
        Me.cmdDC1.StyleSetName = "OECascadeButton"
        Me.cmdDC1.TabIndex = 566
        Me.cmdDC1.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDC1.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdDC1.Visible = False
        '
        'cmdCancel
        '
        Appearance10.BackColor = System.Drawing.Color.Transparent
        Appearance10.BackColor2 = System.Drawing.Color.Transparent
        Appearance10.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance10.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance10.BorderColor2 = System.Drawing.Color.Maroon
        Appearance10.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance10.ForeColor = System.Drawing.Color.White
        Appearance10.Image = CType(resources.GetObject("Appearance10.Image"), Object)
        Appearance10.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance10.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance10.TextVAlignAsString = "Bottom"
        Me.cmdCancel.Appearance = Appearance10
        Me.cmdCancel.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdCancel.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance11.BackColor = System.Drawing.Color.DarkOrange
        Appearance11.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance11.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance11.BorderColor = System.Drawing.Color.Transparent
        Appearance11.ForeColor = System.Drawing.Color.Black
        Me.cmdCancel.HotTrackAppearance = Appearance11
        Me.cmdCancel.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdCancel.Location = New System.Drawing.Point(72, 612)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.Padding = New System.Drawing.Size(15, 0)
        Appearance12.BackColor = System.Drawing.Color.OrangeRed
        Appearance12.BackColor2 = System.Drawing.Color.Tomato
        Appearance12.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance12.BorderColor = System.Drawing.Color.Transparent
        Me.cmdCancel.PressedAppearance = Appearance12
        Me.cmdCancel.ShowFocusRect = False
        Me.cmdCancel.ShowOutline = False
        Me.cmdCancel.Size = New System.Drawing.Size(80, 52)
        Me.cmdCancel.StyleSetName = "StatusBar"
        Me.cmdCancel.TabIndex = 581
        Me.cmdCancel.Tag = "Return"
        Me.cmdCancel.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdCancel.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdCancel.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'frmDishCascadeMenu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(224, 669)
        Me.ControlBox = False
        Me.Controls.Add(Me.cmdCancel)
        Me.Controls.Add(Me.cmdDC1)
        Me.Controls.Add(Me.cmdDC7)
        Me.Controls.Add(Me.cmdDC2)
        Me.Controls.Add(Me.cmdDC6)
        Me.Controls.Add(Me.cmdDC4)
        Me.Controls.Add(Me.cmdDC3)
        Me.Controls.Add(Me.cmdDC9)
        Me.Controls.Add(Me.cmdDC8)
        Me.Controls.Add(Me.cmdDC5)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "frmDishCascadeMenu"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents cmdDC6 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDC5 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDC7 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDC4 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDC8 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDC3 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDC9 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDC2 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDC1 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdCancel As Infragistics.Win.Misc.UltraButton
End Class
