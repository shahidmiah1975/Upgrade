﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSpare
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim Appearance1 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance2 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance3 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance4 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance5 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance6 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance7 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance8 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance9 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance10 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance11 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance12 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance13 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance14 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance15 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance16 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance17 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance18 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance19 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance20 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance21 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance22 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance23 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance24 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance25 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance26 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance27 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance28 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance29 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance30 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance31 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance32 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance33 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance34 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance35 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance36 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance37 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance38 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance39 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance40 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmSpare))
        Dim Appearance41 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance42 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance43 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance44 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance45 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance46 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance47 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance48 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance49 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance50 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance51 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance52 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance53 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance54 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance55 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance56 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance57 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance58 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance59 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance60 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance61 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance62 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance63 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance64 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance65 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance66 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance67 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance68 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance69 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance70 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance71 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance72 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance73 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraGridBand1 As Infragistics.Win.UltraWinGrid.UltraGridBand = New Infragistics.Win.UltraWinGrid.UltraGridBand("Band 0", -1)
        Dim UltraGridColumn1 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("DCode", 0)
        Dim UltraGridColumn2 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("DName", 1)
        Dim UltraGridColumn3 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("DPrice", 2)
        Dim Appearance74 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraGridColumn4 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("DQty", 3)
        Dim Appearance75 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraGridColumn5 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Total", 4)
        Dim Appearance76 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraGridColumn6 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Notes", 5)
        Dim UltraGridColumn7 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Discount", 6)
        Dim UltraGridColumn8 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("OriPrice", 7)
        Dim UltraGridColumn9 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("PriceIn", 8)
        Dim UltraGridColumn10 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("PriceOut", 9)
        Dim UltraGridColumn11 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("GroupIndex", 10)
        Dim UltraGridColumn12 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Mods", 11)
        Dim Appearance77 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance78 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance79 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance80 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance81 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance82 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance83 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance84 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance85 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance86 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance87 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance88 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance89 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance90 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance91 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance92 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance93 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance94 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance95 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance96 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance97 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance98 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance99 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance100 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance101 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance102 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance103 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance104 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance105 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance106 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance107 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance108 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance109 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance110 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance111 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance112 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance113 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance114 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance115 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance116 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance117 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance118 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance119 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance120 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance121 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance122 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance123 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance124 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance125 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance126 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance127 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance128 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance129 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance130 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance131 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance132 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance133 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance134 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance135 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance136 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance137 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance138 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance139 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance140 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance141 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance142 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance143 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance144 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance145 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance146 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance147 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance148 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance149 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Me.txtName = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.UltraButton17 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton18 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton19 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton20 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton1 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton2 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton3 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton4 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton5 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton6 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton7 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton8 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton9 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton10 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton11 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton12 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton13 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton14 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton15 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton43 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton50 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton60 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraPanel2 = New Infragistics.Win.Misc.UltraPanel()
        Me.cmdLastItemQty = New Infragistics.Win.Misc.UltraButton()
        Me.cmdEditDish = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDishClearAll = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDeleteDish = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDeductDish = New Infragistics.Win.Misc.UltraButton()
        Me.cmdAddDish = New Infragistics.Win.Misc.UltraButton()
        Me.cmdOGDown = New Infragistics.Win.Misc.UltraButton()
        Me.cmdOGUp = New Infragistics.Win.Misc.UltraButton()
        Me.ugdOrderGrid = New Infragistics.Win.UltraWinGrid.UltraGrid()
        Me.UltraButton61 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton62 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton63 = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnTemplate = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton64 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton46 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton66 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton48 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraPanel1 = New Infragistics.Win.Misc.UltraPanel()
        Me.cmdBack = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton44 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton45 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdTender50 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdTender20 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdTender10 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton68 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraLabel1 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraButton70 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton16 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton21 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton22 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton23 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton24 = New Infragistics.Win.Misc.UltraButton()
        Me.ubtn5 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraLabel2 = New Infragistics.Win.Misc.UltraLabel()
        Me.cmdTypical = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton25 = New Infragistics.Win.Misc.UltraButton()
        CType(Me.txtName, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.UltraPanel2.ClientArea.SuspendLayout()
        Me.UltraPanel2.SuspendLayout()
        CType(Me.ugdOrderGrid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.UltraPanel1.ClientArea.SuspendLayout()
        Me.UltraPanel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtName
        '
        Appearance1.BorderColor = System.Drawing.Color.FromArgb(CType(CType(127, Byte), Integer), CType(CType(157, Byte), Integer), CType(CType(185, Byte), Integer))
        Me.txtName.Appearance = Appearance1
        Me.txtName.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName.Location = New System.Drawing.Point(12, 12)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(165, 22)
        Me.txtName.TabIndex = 14
        Me.txtName.UseAppStyling = False
        Me.txtName.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtName.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton17
        '
        Appearance2.BackColor = System.Drawing.Color.Green
        Appearance2.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Appearance2.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance2.BorderAlpha = Infragistics.Win.Alpha.Opaque
        Appearance2.BorderColor = System.Drawing.Color.Green
        Appearance2.BorderColor2 = System.Drawing.Color.Maroon
        Appearance2.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance2.ForeColor = System.Drawing.Color.White
        Me.UltraButton17.Appearance = Appearance2
        Me.UltraButton17.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance3.BackColor = System.Drawing.Color.PowderBlue
        Appearance3.BackColor2 = System.Drawing.Color.Aqua
        Appearance3.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance3.ForeColor = System.Drawing.Color.Black
        Me.UltraButton17.HotTrackAppearance = Appearance3
        Me.UltraButton17.Location = New System.Drawing.Point(419, 11)
        Me.UltraButton17.Name = "UltraButton17"
        Me.UltraButton17.ShowFocusRect = False
        Me.UltraButton17.ShowOutline = False
        Me.UltraButton17.Size = New System.Drawing.Size(110, 40)
        Me.UltraButton17.TabIndex = 110
        Me.UltraButton17.Text = "Vegs"
        Me.UltraButton17.UseAppStyling = False
        Me.UltraButton17.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton17.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.UltraButton17.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton18
        '
        Appearance4.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance4.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Appearance4.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance4.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance4.BorderColor = System.Drawing.Color.Orange
        Appearance4.BorderColor2 = System.Drawing.Color.Maroon
        Appearance4.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance4.ForeColor = System.Drawing.Color.Black
        Me.UltraButton18.Appearance = Appearance4
        Me.UltraButton18.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance5.BackColor = System.Drawing.Color.PowderBlue
        Appearance5.BackColor2 = System.Drawing.Color.Aqua
        Appearance5.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance5.ForeColor = System.Drawing.Color.Black
        Me.UltraButton18.HotTrackAppearance = Appearance5
        Me.UltraButton18.Location = New System.Drawing.Point(303, 11)
        Me.UltraButton18.Name = "UltraButton18"
        Me.UltraButton18.ShowFocusRect = False
        Me.UltraButton18.ShowOutline = False
        Me.UltraButton18.Size = New System.Drawing.Size(110, 40)
        Me.UltraButton18.TabIndex = 109
        Me.UltraButton18.Text = "Prawns"
        Me.UltraButton18.UseAppStyling = False
        Me.UltraButton18.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton18.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.UltraButton18.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton19
        '
        Appearance6.BackColor = System.Drawing.Color.Maroon
        Appearance6.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Appearance6.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance6.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance6.BorderColor = System.Drawing.Color.Brown
        Appearance6.BorderColor2 = System.Drawing.Color.Brown
        Appearance6.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance6.ForeColor = System.Drawing.Color.White
        Me.UltraButton19.Appearance = Appearance6
        Me.UltraButton19.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance7.BackColor = System.Drawing.Color.PowderBlue
        Appearance7.BackColor2 = System.Drawing.Color.Aqua
        Appearance7.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance7.ForeColor = System.Drawing.Color.Black
        Me.UltraButton19.HotTrackAppearance = Appearance7
        Me.UltraButton19.Location = New System.Drawing.Point(536, 12)
        Me.UltraButton19.Name = "UltraButton19"
        Me.UltraButton19.ShowFocusRect = False
        Me.UltraButton19.ShowOutline = False
        Me.UltraButton19.Size = New System.Drawing.Size(140, 40)
        Me.UltraButton19.TabIndex = 108
        Me.UltraButton19.Text = "Lamb"
        Me.UltraButton19.UseAppStyling = False
        Me.UltraButton19.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton19.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.UltraButton19.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton20
        '
        Appearance8.BackColor = System.Drawing.Color.DodgerBlue
        Appearance8.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Appearance8.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance8.BorderColor = System.Drawing.Color.Navy
        Appearance8.BorderColor2 = System.Drawing.Color.Maroon
        Appearance8.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance8.ForeColor = System.Drawing.Color.Navy
        Me.UltraButton20.Appearance = Appearance8
        Me.UltraButton20.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance9.BackColor = System.Drawing.Color.PowderBlue
        Appearance9.BackColor2 = System.Drawing.Color.Aqua
        Appearance9.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance9.ForeColor = System.Drawing.Color.Black
        Me.UltraButton20.HotTrackAppearance = Appearance9
        Me.UltraButton20.Location = New System.Drawing.Point(187, 12)
        Me.UltraButton20.Name = "UltraButton20"
        Me.UltraButton20.ShowFocusRect = False
        Me.UltraButton20.ShowOutline = False
        Me.UltraButton20.Size = New System.Drawing.Size(110, 40)
        Me.UltraButton20.TabIndex = 107
        Me.UltraButton20.Text = "Chicken"
        Me.UltraButton20.UseAppStyling = False
        Me.UltraButton20.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton20.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.UltraButton20.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton1
        '
        Appearance10.BackColor = System.Drawing.Color.Green
        Appearance10.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Appearance10.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance10.BorderAlpha = Infragistics.Win.Alpha.Opaque
        Appearance10.BorderColor = System.Drawing.Color.Green
        Appearance10.BorderColor2 = System.Drawing.Color.Maroon
        Appearance10.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance10.ForeColor = System.Drawing.Color.White
        Me.UltraButton1.Appearance = Appearance10
        Me.UltraButton1.Font = New System.Drawing.Font("Arial", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance11.BackColor = System.Drawing.Color.PowderBlue
        Appearance11.BackColor2 = System.Drawing.Color.Aqua
        Appearance11.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance11.ForeColor = System.Drawing.Color.Black
        Me.UltraButton1.HotTrackAppearance = Appearance11
        Me.UltraButton1.Location = New System.Drawing.Point(23, 167)
        Me.UltraButton1.Name = "UltraButton1"
        Me.UltraButton1.ShowFocusRect = False
        Me.UltraButton1.ShowOutline = False
        Me.UltraButton1.Size = New System.Drawing.Size(50, 50)
        Me.UltraButton1.TabIndex = 111
        Me.UltraButton1.Text = "1"
        Me.UltraButton1.UseAppStyling = False
        Me.UltraButton1.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton1.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.UltraButton1.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton2
        '
        Appearance12.BackColor = System.Drawing.Color.Green
        Appearance12.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Appearance12.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance12.BorderAlpha = Infragistics.Win.Alpha.Opaque
        Appearance12.BorderColor = System.Drawing.Color.Green
        Appearance12.BorderColor2 = System.Drawing.Color.Maroon
        Appearance12.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance12.ForeColor = System.Drawing.Color.White
        Me.UltraButton2.Appearance = Appearance12
        Me.UltraButton2.Font = New System.Drawing.Font("Arial", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance13.BackColor = System.Drawing.Color.PowderBlue
        Appearance13.BackColor2 = System.Drawing.Color.Aqua
        Appearance13.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance13.ForeColor = System.Drawing.Color.Black
        Me.UltraButton2.HotTrackAppearance = Appearance13
        Me.UltraButton2.Location = New System.Drawing.Point(76, 167)
        Me.UltraButton2.Name = "UltraButton2"
        Me.UltraButton2.ShowFocusRect = False
        Me.UltraButton2.ShowOutline = False
        Me.UltraButton2.Size = New System.Drawing.Size(50, 50)
        Me.UltraButton2.TabIndex = 112
        Me.UltraButton2.Text = "2"
        Me.UltraButton2.UseAppStyling = False
        Me.UltraButton2.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton2.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.UltraButton2.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton3
        '
        Appearance14.BackColor = System.Drawing.Color.Green
        Appearance14.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Appearance14.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance14.BorderAlpha = Infragistics.Win.Alpha.Opaque
        Appearance14.BorderColor = System.Drawing.Color.Green
        Appearance14.BorderColor2 = System.Drawing.Color.Maroon
        Appearance14.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance14.ForeColor = System.Drawing.Color.White
        Me.UltraButton3.Appearance = Appearance14
        Me.UltraButton3.Font = New System.Drawing.Font("Arial", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance15.BackColor = System.Drawing.Color.PowderBlue
        Appearance15.BackColor2 = System.Drawing.Color.Aqua
        Appearance15.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance15.ForeColor = System.Drawing.Color.Black
        Me.UltraButton3.HotTrackAppearance = Appearance15
        Me.UltraButton3.Location = New System.Drawing.Point(129, 167)
        Me.UltraButton3.Name = "UltraButton3"
        Me.UltraButton3.ShowFocusRect = False
        Me.UltraButton3.ShowOutline = False
        Me.UltraButton3.Size = New System.Drawing.Size(50, 50)
        Me.UltraButton3.TabIndex = 113
        Me.UltraButton3.Text = "3"
        Me.UltraButton3.UseAppStyling = False
        Me.UltraButton3.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton3.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.UltraButton3.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton4
        '
        Appearance16.BackColor = System.Drawing.Color.Green
        Appearance16.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Appearance16.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance16.BorderAlpha = Infragistics.Win.Alpha.Opaque
        Appearance16.BorderColor = System.Drawing.Color.Green
        Appearance16.BorderColor2 = System.Drawing.Color.Maroon
        Appearance16.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance16.ForeColor = System.Drawing.Color.White
        Me.UltraButton4.Appearance = Appearance16
        Me.UltraButton4.Font = New System.Drawing.Font("Arial", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance17.BackColor = System.Drawing.Color.PowderBlue
        Appearance17.BackColor2 = System.Drawing.Color.Aqua
        Appearance17.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance17.ForeColor = System.Drawing.Color.Black
        Me.UltraButton4.HotTrackAppearance = Appearance17
        Me.UltraButton4.Location = New System.Drawing.Point(129, 114)
        Me.UltraButton4.Name = "UltraButton4"
        Me.UltraButton4.ShowFocusRect = False
        Me.UltraButton4.ShowOutline = False
        Me.UltraButton4.Size = New System.Drawing.Size(50, 50)
        Me.UltraButton4.TabIndex = 116
        Me.UltraButton4.Text = "6"
        Me.UltraButton4.UseAppStyling = False
        Me.UltraButton4.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton4.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.UltraButton4.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton5
        '
        Appearance18.BackColor = System.Drawing.Color.Green
        Appearance18.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Appearance18.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance18.BorderAlpha = Infragistics.Win.Alpha.Opaque
        Appearance18.BorderColor = System.Drawing.Color.Green
        Appearance18.BorderColor2 = System.Drawing.Color.Maroon
        Appearance18.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance18.ForeColor = System.Drawing.Color.White
        Me.UltraButton5.Appearance = Appearance18
        Me.UltraButton5.Font = New System.Drawing.Font("Arial", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance19.BackColor = System.Drawing.Color.PowderBlue
        Appearance19.BackColor2 = System.Drawing.Color.Aqua
        Appearance19.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance19.ForeColor = System.Drawing.Color.Black
        Me.UltraButton5.HotTrackAppearance = Appearance19
        Me.UltraButton5.Location = New System.Drawing.Point(76, 114)
        Me.UltraButton5.Name = "UltraButton5"
        Me.UltraButton5.ShowFocusRect = False
        Me.UltraButton5.ShowOutline = False
        Me.UltraButton5.Size = New System.Drawing.Size(50, 50)
        Me.UltraButton5.TabIndex = 115
        Me.UltraButton5.Text = "5"
        Me.UltraButton5.UseAppStyling = False
        Me.UltraButton5.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton5.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.UltraButton5.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton6
        '
        Appearance20.BackColor = System.Drawing.Color.Green
        Appearance20.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Appearance20.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance20.BorderAlpha = Infragistics.Win.Alpha.Opaque
        Appearance20.BorderColor = System.Drawing.Color.Green
        Appearance20.BorderColor2 = System.Drawing.Color.Maroon
        Appearance20.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance20.ForeColor = System.Drawing.Color.White
        Me.UltraButton6.Appearance = Appearance20
        Me.UltraButton6.Font = New System.Drawing.Font("Arial", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance21.BackColor = System.Drawing.Color.PowderBlue
        Appearance21.BackColor2 = System.Drawing.Color.Aqua
        Appearance21.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance21.ForeColor = System.Drawing.Color.Black
        Me.UltraButton6.HotTrackAppearance = Appearance21
        Me.UltraButton6.Location = New System.Drawing.Point(23, 114)
        Me.UltraButton6.Name = "UltraButton6"
        Me.UltraButton6.ShowFocusRect = False
        Me.UltraButton6.ShowOutline = False
        Me.UltraButton6.Size = New System.Drawing.Size(50, 50)
        Me.UltraButton6.TabIndex = 114
        Me.UltraButton6.Text = "4"
        Me.UltraButton6.UseAppStyling = False
        Me.UltraButton6.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton6.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.UltraButton6.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton7
        '
        Appearance22.BackColor = System.Drawing.Color.Green
        Appearance22.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Appearance22.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance22.BorderAlpha = Infragistics.Win.Alpha.Opaque
        Appearance22.BorderColor = System.Drawing.Color.Green
        Appearance22.BorderColor2 = System.Drawing.Color.Maroon
        Appearance22.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance22.ForeColor = System.Drawing.Color.White
        Me.UltraButton7.Appearance = Appearance22
        Me.UltraButton7.Font = New System.Drawing.Font("Arial", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance23.BackColor = System.Drawing.Color.PowderBlue
        Appearance23.BackColor2 = System.Drawing.Color.Aqua
        Appearance23.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance23.ForeColor = System.Drawing.Color.Black
        Me.UltraButton7.HotTrackAppearance = Appearance23
        Me.UltraButton7.Location = New System.Drawing.Point(129, 61)
        Me.UltraButton7.Name = "UltraButton7"
        Me.UltraButton7.ShowFocusRect = False
        Me.UltraButton7.ShowOutline = False
        Me.UltraButton7.Size = New System.Drawing.Size(50, 50)
        Me.UltraButton7.TabIndex = 119
        Me.UltraButton7.Text = "9"
        Me.UltraButton7.UseAppStyling = False
        Me.UltraButton7.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton7.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.UltraButton7.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton8
        '
        Appearance24.BackColor = System.Drawing.Color.Green
        Appearance24.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Appearance24.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance24.BorderAlpha = Infragistics.Win.Alpha.Opaque
        Appearance24.BorderColor = System.Drawing.Color.Green
        Appearance24.BorderColor2 = System.Drawing.Color.Maroon
        Appearance24.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance24.ForeColor = System.Drawing.Color.White
        Me.UltraButton8.Appearance = Appearance24
        Me.UltraButton8.Font = New System.Drawing.Font("Arial", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance25.BackColor = System.Drawing.Color.PowderBlue
        Appearance25.BackColor2 = System.Drawing.Color.Aqua
        Appearance25.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance25.ForeColor = System.Drawing.Color.Black
        Me.UltraButton8.HotTrackAppearance = Appearance25
        Me.UltraButton8.Location = New System.Drawing.Point(76, 61)
        Me.UltraButton8.Name = "UltraButton8"
        Me.UltraButton8.ShowFocusRect = False
        Me.UltraButton8.ShowOutline = False
        Me.UltraButton8.Size = New System.Drawing.Size(50, 50)
        Me.UltraButton8.TabIndex = 118
        Me.UltraButton8.Text = "8"
        Me.UltraButton8.UseAppStyling = False
        Me.UltraButton8.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton8.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.UltraButton8.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton9
        '
        Appearance26.BackColor = System.Drawing.Color.Green
        Appearance26.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Appearance26.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance26.BorderAlpha = Infragistics.Win.Alpha.Opaque
        Appearance26.BorderColor = System.Drawing.Color.Green
        Appearance26.BorderColor2 = System.Drawing.Color.Maroon
        Appearance26.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance26.ForeColor = System.Drawing.Color.White
        Me.UltraButton9.Appearance = Appearance26
        Me.UltraButton9.Font = New System.Drawing.Font("Arial", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance27.BackColor = System.Drawing.Color.PowderBlue
        Appearance27.BackColor2 = System.Drawing.Color.Aqua
        Appearance27.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance27.ForeColor = System.Drawing.Color.Black
        Me.UltraButton9.HotTrackAppearance = Appearance27
        Me.UltraButton9.Location = New System.Drawing.Point(23, 61)
        Me.UltraButton9.Name = "UltraButton9"
        Me.UltraButton9.ShowFocusRect = False
        Me.UltraButton9.ShowOutline = False
        Me.UltraButton9.Size = New System.Drawing.Size(50, 50)
        Me.UltraButton9.TabIndex = 117
        Me.UltraButton9.Text = "7"
        Me.UltraButton9.UseAppStyling = False
        Me.UltraButton9.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton9.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.UltraButton9.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton10
        '
        Appearance28.BackColor = System.Drawing.Color.Green
        Appearance28.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Appearance28.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance28.BorderAlpha = Infragistics.Win.Alpha.Opaque
        Appearance28.BorderColor = System.Drawing.Color.Green
        Appearance28.BorderColor2 = System.Drawing.Color.Maroon
        Appearance28.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance28.ForeColor = System.Drawing.Color.White
        Me.UltraButton10.Appearance = Appearance28
        Me.UltraButton10.Font = New System.Drawing.Font("Arial", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance29.BackColor = System.Drawing.Color.PowderBlue
        Appearance29.BackColor2 = System.Drawing.Color.Aqua
        Appearance29.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance29.ForeColor = System.Drawing.Color.Black
        Me.UltraButton10.HotTrackAppearance = Appearance29
        Me.UltraButton10.Location = New System.Drawing.Point(129, 220)
        Me.UltraButton10.Name = "UltraButton10"
        Me.UltraButton10.ShowFocusRect = False
        Me.UltraButton10.ShowOutline = False
        Me.UltraButton10.Size = New System.Drawing.Size(50, 50)
        Me.UltraButton10.TabIndex = 122
        Me.UltraButton10.Text = "."
        Me.UltraButton10.UseAppStyling = False
        Me.UltraButton10.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton10.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.UltraButton10.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton11
        '
        Appearance30.BackColor = System.Drawing.Color.Green
        Appearance30.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Appearance30.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance30.BorderAlpha = Infragistics.Win.Alpha.Opaque
        Appearance30.BorderColor = System.Drawing.Color.Green
        Appearance30.BorderColor2 = System.Drawing.Color.Maroon
        Appearance30.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance30.ForeColor = System.Drawing.Color.White
        Me.UltraButton11.Appearance = Appearance30
        Me.UltraButton11.Font = New System.Drawing.Font("Arial", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance31.BackColor = System.Drawing.Color.PowderBlue
        Appearance31.BackColor2 = System.Drawing.Color.Aqua
        Appearance31.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance31.ForeColor = System.Drawing.Color.Black
        Me.UltraButton11.HotTrackAppearance = Appearance31
        Me.UltraButton11.Location = New System.Drawing.Point(23, 220)
        Me.UltraButton11.Name = "UltraButton11"
        Me.UltraButton11.ShowFocusRect = False
        Me.UltraButton11.ShowOutline = False
        Me.UltraButton11.Size = New System.Drawing.Size(103, 50)
        Me.UltraButton11.TabIndex = 121
        Me.UltraButton11.Text = "0"
        Me.UltraButton11.UseAppStyling = False
        Me.UltraButton11.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton11.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.UltraButton11.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton12
        '
        Appearance32.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Appearance32.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Appearance32.BackGradientStyle = Infragistics.Win.GradientStyle.None
        Appearance32.BorderAlpha = Infragistics.Win.Alpha.Opaque
        Appearance32.BorderColor = System.Drawing.Color.Green
        Appearance32.BorderColor2 = System.Drawing.Color.Maroon
        Appearance32.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance32.ForeColor = System.Drawing.Color.White
        Me.UltraButton12.Appearance = Appearance32
        Me.UltraButton12.Font = New System.Drawing.Font("Arial", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance33.BackColor = System.Drawing.Color.PowderBlue
        Appearance33.BackColor2 = System.Drawing.Color.Aqua
        Appearance33.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance33.ForeColor = System.Drawing.Color.Black
        Me.UltraButton12.HotTrackAppearance = Appearance33
        Me.UltraButton12.Location = New System.Drawing.Point(19, 57)
        Me.UltraButton12.Name = "UltraButton12"
        Me.UltraButton12.ShowFocusRect = False
        Me.UltraButton12.ShowOutline = False
        Me.UltraButton12.Size = New System.Drawing.Size(164, 217)
        Me.UltraButton12.TabIndex = 123
        Me.UltraButton12.UseAppStyling = False
        Me.UltraButton12.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton12.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.UltraButton12.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton13
        '
        Appearance34.BackColor = System.Drawing.Color.Maroon
        Appearance34.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Appearance34.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance34.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance34.BorderColor = System.Drawing.Color.Brown
        Appearance34.BorderColor2 = System.Drawing.Color.Brown
        Appearance34.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance34.ForeColor = System.Drawing.Color.White
        Me.UltraButton13.Appearance = Appearance34
        Me.UltraButton13.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance35.BackColor = System.Drawing.Color.PowderBlue
        Appearance35.BackColor2 = System.Drawing.Color.Aqua
        Appearance35.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance35.ForeColor = System.Drawing.Color.Black
        Me.UltraButton13.HotTrackAppearance = Appearance35
        Me.UltraButton13.Location = New System.Drawing.Point(201, 118)
        Me.UltraButton13.Name = "UltraButton13"
        Me.UltraButton13.ShowFocusRect = False
        Me.UltraButton13.ShowOutline = False
        Me.UltraButton13.Size = New System.Drawing.Size(66, 50)
        Me.UltraButton13.TabIndex = 124
        Me.UltraButton13.Text = "Down"
        Me.UltraButton13.UseAppStyling = False
        Me.UltraButton13.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton13.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.UltraButton13.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton14
        '
        Appearance36.BackColor = System.Drawing.Color.Maroon
        Appearance36.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Appearance36.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance36.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance36.BorderColor = System.Drawing.Color.Brown
        Appearance36.BorderColor2 = System.Drawing.Color.Brown
        Appearance36.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance36.ForeColor = System.Drawing.Color.White
        Me.UltraButton14.Appearance = Appearance36
        Me.UltraButton14.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance37.BackColor = System.Drawing.Color.PowderBlue
        Appearance37.BackColor2 = System.Drawing.Color.Aqua
        Appearance37.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance37.ForeColor = System.Drawing.Color.Black
        Me.UltraButton14.HotTrackAppearance = Appearance37
        Me.UltraButton14.Location = New System.Drawing.Point(201, 65)
        Me.UltraButton14.Name = "UltraButton14"
        Me.UltraButton14.ShowFocusRect = False
        Me.UltraButton14.ShowOutline = False
        Me.UltraButton14.Size = New System.Drawing.Size(66, 50)
        Me.UltraButton14.TabIndex = 125
        Me.UltraButton14.Text = "Up"
        Me.UltraButton14.UseAppStyling = False
        Me.UltraButton14.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton14.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.UltraButton14.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton15
        '
        Appearance38.BackColor = System.Drawing.Color.SteelBlue
        Appearance38.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(148, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(196, Byte), Integer))
        Appearance38.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance38.BorderColor = System.Drawing.Color.Navy
        Appearance38.BorderColor2 = System.Drawing.Color.Maroon
        Appearance38.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance38.ForeColor = System.Drawing.Color.White
        Me.UltraButton15.Appearance = Appearance38
        Me.UltraButton15.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance39.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance39.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Appearance39.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance39.BorderColor = System.Drawing.Color.Orange
        Appearance39.ForeColor = System.Drawing.Color.Black
        Me.UltraButton15.HotTrackAppearance = Appearance39
        Me.UltraButton15.Location = New System.Drawing.Point(690, 428)
        Me.UltraButton15.Name = "UltraButton15"
        Me.UltraButton15.ShowFocusRect = False
        Me.UltraButton15.ShowOutline = False
        Me.UltraButton15.Size = New System.Drawing.Size(110, 71)
        Me.UltraButton15.TabIndex = 126
        Me.UltraButton15.Text = "Chicken"
        Me.UltraButton15.UseAppStyling = False
        Me.UltraButton15.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton15.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton15.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton43
        '
        Appearance40.BackColor = System.Drawing.Color.FromArgb(CType(CType(148, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(196, Byte), Integer))
        Appearance40.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(148, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(196, Byte), Integer))
        Appearance40.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance40.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance40.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance40.BorderColor2 = System.Drawing.Color.Maroon
        Appearance40.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance40.ForeColor = System.Drawing.Color.Black
        Appearance40.Image = CType(resources.GetObject("Appearance40.Image"), Object)
        Appearance40.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance40.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance40.TextVAlignAsString = "Bottom"
        Me.UltraButton43.Appearance = Appearance40
        Me.UltraButton43.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance41.BackColor = System.Drawing.Color.DarkOrange
        Appearance41.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance41.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance41.ForeColor = System.Drawing.Color.Black
        Me.UltraButton43.HotTrackAppearance = Appearance41
        Me.UltraButton43.ImageSize = New System.Drawing.Size(32, 32)
        Me.UltraButton43.Location = New System.Drawing.Point(312, 87)
        Me.UltraButton43.Name = "UltraButton43"
        Appearance42.BackColor = System.Drawing.Color.OrangeRed
        Appearance42.BackColor2 = System.Drawing.Color.Tomato
        Appearance42.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.UltraButton43.PressedAppearance = Appearance42
        Me.UltraButton43.ShowFocusRect = False
        Me.UltraButton43.ShowOutline = False
        Me.UltraButton43.Size = New System.Drawing.Size(70, 60)
        Me.UltraButton43.TabIndex = 332
        Me.UltraButton43.Tag = "Delete"
        Me.UltraButton43.Text = "Delete"
        Me.UltraButton43.UseAppStyling = False
        Me.UltraButton43.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton43.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton43.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton50
        '
        Appearance43.BackColor = System.Drawing.Color.FromArgb(CType(CType(148, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(196, Byte), Integer))
        Appearance43.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(148, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(196, Byte), Integer))
        Appearance43.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance43.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance43.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance43.BorderColor2 = System.Drawing.Color.Maroon
        Appearance43.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance43.ForeColor = System.Drawing.Color.Black
        Appearance43.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance43.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance43.TextVAlignAsString = "Middle"
        Me.UltraButton50.Appearance = Appearance43
        Me.UltraButton50.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance44.BackColor = System.Drawing.Color.DarkOrange
        Appearance44.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance44.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance44.ForeColor = System.Drawing.Color.Black
        Me.UltraButton50.HotTrackAppearance = Appearance44
        Me.UltraButton50.ImageSize = New System.Drawing.Size(32, 32)
        Me.UltraButton50.Location = New System.Drawing.Point(189, 229)
        Me.UltraButton50.Name = "UltraButton50"
        Appearance45.BackColor = System.Drawing.Color.OrangeRed
        Appearance45.BackColor2 = System.Drawing.Color.Tomato
        Appearance45.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.UltraButton50.PressedAppearance = Appearance45
        Me.UltraButton50.ShowFocusRect = False
        Me.UltraButton50.ShowOutline = False
        Me.UltraButton50.Size = New System.Drawing.Size(89, 41)
        Me.UltraButton50.TabIndex = 380
        Me.UltraButton50.Tag = "1.50"
        Me.UltraButton50.Text = "Coke"
        Me.UltraButton50.UseAppStyling = False
        Me.UltraButton50.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton50.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton50.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton60
        '
        Appearance46.BackColor = System.Drawing.Color.DarkOrange
        Appearance46.BackColor2 = System.Drawing.Color.Khaki
        Appearance46.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance46.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance46.BorderColor = System.Drawing.Color.DarkOrange
        Appearance46.BorderColor2 = System.Drawing.Color.Maroon
        Appearance46.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance46.ForeColor = System.Drawing.Color.Black
        Me.UltraButton60.Appearance = Appearance46
        Me.UltraButton60.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance47.BackColor = System.Drawing.Color.PowderBlue
        Appearance47.BackColor2 = System.Drawing.Color.Aqua
        Appearance47.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance47.ForeColor = System.Drawing.Color.Black
        Me.UltraButton60.HotTrackAppearance = Appearance47
        Me.UltraButton60.Location = New System.Drawing.Point(312, 153)
        Me.UltraButton60.Name = "UltraButton60"
        Me.UltraButton60.ShowFocusRect = False
        Me.UltraButton60.ShowOutline = False
        Me.UltraButton60.Size = New System.Drawing.Size(110, 40)
        Me.UltraButton60.TabIndex = 381
        Me.UltraButton60.Text = "Prawns"
        Me.UltraButton60.UseAppStyling = False
        Me.UltraButton60.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton60.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.UltraButton60.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraPanel2
        '
        Appearance48.BackColor = System.Drawing.Color.Transparent
        Appearance48.BorderColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(146, Byte), Integer), CType(CType(254, Byte), Integer))
        Me.UltraPanel2.Appearance = Appearance48
        Me.UltraPanel2.AutoScroll = True
        Me.UltraPanel2.BorderStyle = Infragistics.Win.UIElementBorderStyle.None
        '
        'UltraPanel2.ClientArea
        '
        Me.UltraPanel2.ClientArea.Controls.Add(Me.cmdLastItemQty)
        Me.UltraPanel2.ClientArea.Controls.Add(Me.cmdEditDish)
        Me.UltraPanel2.ClientArea.Controls.Add(Me.cmdDishClearAll)
        Me.UltraPanel2.ClientArea.Controls.Add(Me.cmdDeleteDish)
        Me.UltraPanel2.ClientArea.Controls.Add(Me.cmdDeductDish)
        Me.UltraPanel2.ClientArea.Controls.Add(Me.cmdAddDish)
        Me.UltraPanel2.ClientArea.Controls.Add(Me.cmdOGDown)
        Me.UltraPanel2.ClientArea.Controls.Add(Me.cmdOGUp)
        Me.UltraPanel2.Location = New System.Drawing.Point(23, 300)
        Me.UltraPanel2.Name = "UltraPanel2"
        Me.UltraPanel2.Size = New System.Drawing.Size(270, 90)
        Me.UltraPanel2.TabIndex = 450
        '
        'cmdLastItemQty
        '
        Appearance49.BackColor = System.Drawing.Color.FromArgb(CType(CType(148, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(196, Byte), Integer))
        Appearance49.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(148, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(196, Byte), Integer))
        Appearance49.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance49.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance49.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance49.BorderColor2 = System.Drawing.Color.Maroon
        Appearance49.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance49.ForeColor = System.Drawing.Color.Black
        Appearance49.Image = CType(resources.GetObject("Appearance49.Image"), Object)
        Appearance49.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance49.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance49.TextVAlignAsString = "Bottom"
        Me.cmdLastItemQty.Appearance = Appearance49
        Me.cmdLastItemQty.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance50.BackColor = System.Drawing.Color.DarkOrange
        Appearance50.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance50.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance50.ForeColor = System.Drawing.Color.Black
        Me.cmdLastItemQty.HotTrackAppearance = Appearance50
        Me.cmdLastItemQty.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdLastItemQty.Location = New System.Drawing.Point(135, 45)
        Me.cmdLastItemQty.Name = "cmdLastItemQty"
        Appearance51.BackColor = System.Drawing.Color.OrangeRed
        Appearance51.BackColor2 = System.Drawing.Color.Tomato
        Appearance51.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdLastItemQty.PressedAppearance = Appearance51
        Me.cmdLastItemQty.ShowFocusRect = False
        Me.cmdLastItemQty.ShowOutline = False
        Me.cmdLastItemQty.Size = New System.Drawing.Size(65, 40)
        Me.cmdLastItemQty.TabIndex = 460
        Me.cmdLastItemQty.Tag = "New"
        Me.cmdLastItemQty.UseAppStyling = False
        Me.cmdLastItemQty.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdLastItemQty.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdLastItemQty.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdEditDish
        '
        Appearance52.BackColor = System.Drawing.Color.FromArgb(CType(CType(148, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(196, Byte), Integer))
        Appearance52.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(148, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(196, Byte), Integer))
        Appearance52.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance52.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance52.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance52.BorderColor2 = System.Drawing.Color.Maroon
        Appearance52.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance52.ForeColor = System.Drawing.Color.Black
        Appearance52.Image = CType(resources.GetObject("Appearance52.Image"), Object)
        Appearance52.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance52.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance52.TextVAlignAsString = "Bottom"
        Me.cmdEditDish.Appearance = Appearance52
        Me.cmdEditDish.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance53.BackColor = System.Drawing.Color.DarkOrange
        Appearance53.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance53.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance53.ForeColor = System.Drawing.Color.Black
        Me.cmdEditDish.HotTrackAppearance = Appearance53
        Me.cmdEditDish.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdEditDish.Location = New System.Drawing.Point(70, 45)
        Me.cmdEditDish.Name = "cmdEditDish"
        Appearance54.BackColor = System.Drawing.Color.OrangeRed
        Appearance54.BackColor2 = System.Drawing.Color.Tomato
        Appearance54.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdEditDish.PressedAppearance = Appearance54
        Me.cmdEditDish.ShowFocusRect = False
        Me.cmdEditDish.ShowOutline = False
        Me.cmdEditDish.Size = New System.Drawing.Size(65, 40)
        Me.cmdEditDish.TabIndex = 459
        Me.cmdEditDish.Tag = "New"
        Me.cmdEditDish.UseAppStyling = False
        Me.cmdEditDish.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdEditDish.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdEditDish.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDishClearAll
        '
        Appearance55.BackColor = System.Drawing.Color.FromArgb(CType(CType(148, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(196, Byte), Integer))
        Appearance55.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(148, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(196, Byte), Integer))
        Appearance55.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance55.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance55.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance55.BorderColor2 = System.Drawing.Color.Maroon
        Appearance55.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance55.ForeColor = System.Drawing.Color.Black
        Appearance55.Image = CType(resources.GetObject("Appearance55.Image"), Object)
        Appearance55.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance55.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance55.TextVAlignAsString = "Bottom"
        Me.cmdDishClearAll.Appearance = Appearance55
        Me.cmdDishClearAll.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance56.BackColor = System.Drawing.Color.DarkOrange
        Appearance56.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance56.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance56.ForeColor = System.Drawing.Color.Black
        Me.cmdDishClearAll.HotTrackAppearance = Appearance56
        Me.cmdDishClearAll.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdDishClearAll.Location = New System.Drawing.Point(5, 45)
        Me.cmdDishClearAll.Name = "cmdDishClearAll"
        Appearance57.BackColor = System.Drawing.Color.OrangeRed
        Appearance57.BackColor2 = System.Drawing.Color.Tomato
        Appearance57.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdDishClearAll.PressedAppearance = Appearance57
        Me.cmdDishClearAll.ShowFocusRect = False
        Me.cmdDishClearAll.ShowOutline = False
        Me.cmdDishClearAll.Size = New System.Drawing.Size(65, 40)
        Me.cmdDishClearAll.TabIndex = 458
        Me.cmdDishClearAll.Tag = "x"
        Me.cmdDishClearAll.UseAppStyling = False
        Me.cmdDishClearAll.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDishClearAll.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDishClearAll.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDeleteDish
        '
        Appearance58.BackColor = System.Drawing.Color.FromArgb(CType(CType(148, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(196, Byte), Integer))
        Appearance58.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(148, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(196, Byte), Integer))
        Appearance58.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance58.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance58.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance58.BorderColor2 = System.Drawing.Color.Maroon
        Appearance58.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance58.ForeColor = System.Drawing.Color.Black
        Appearance58.Image = CType(resources.GetObject("Appearance58.Image"), Object)
        Appearance58.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance58.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance58.TextVAlignAsString = "Bottom"
        Me.cmdDeleteDish.Appearance = Appearance58
        Me.cmdDeleteDish.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance59.BackColor = System.Drawing.Color.DarkOrange
        Appearance59.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance59.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance59.ForeColor = System.Drawing.Color.Black
        Me.cmdDeleteDish.HotTrackAppearance = Appearance59
        Me.cmdDeleteDish.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdDeleteDish.Location = New System.Drawing.Point(199, 45)
        Me.cmdDeleteDish.Name = "cmdDeleteDish"
        Appearance60.BackColor = System.Drawing.Color.OrangeRed
        Appearance60.BackColor2 = System.Drawing.Color.Tomato
        Appearance60.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdDeleteDish.PressedAppearance = Appearance60
        Me.cmdDeleteDish.ShowFocusRect = False
        Me.cmdDeleteDish.ShowOutline = False
        Me.cmdDeleteDish.Size = New System.Drawing.Size(65, 40)
        Me.cmdDeleteDish.TabIndex = 457
        Me.cmdDeleteDish.Tag = "x"
        Me.cmdDeleteDish.UseAppStyling = False
        Me.cmdDeleteDish.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDeleteDish.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDeleteDish.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDeductDish
        '
        Appearance61.BackColor = System.Drawing.Color.FromArgb(CType(CType(148, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(196, Byte), Integer))
        Appearance61.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(148, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(196, Byte), Integer))
        Appearance61.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance61.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance61.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance61.BorderColor2 = System.Drawing.Color.Maroon
        Appearance61.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance61.ForeColor = System.Drawing.Color.Black
        Appearance61.Image = CType(resources.GetObject("Appearance61.Image"), Object)
        Appearance61.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance61.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance61.TextVAlignAsString = "Bottom"
        Me.cmdDeductDish.Appearance = Appearance61
        Me.cmdDeductDish.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance62.BackColor = System.Drawing.Color.DarkOrange
        Appearance62.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance62.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance62.ForeColor = System.Drawing.Color.Black
        Me.cmdDeductDish.HotTrackAppearance = Appearance62
        Me.cmdDeductDish.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdDeductDish.Location = New System.Drawing.Point(200, 5)
        Me.cmdDeductDish.Name = "cmdDeductDish"
        Appearance63.BackColor = System.Drawing.Color.OrangeRed
        Appearance63.BackColor2 = System.Drawing.Color.Tomato
        Appearance63.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdDeductDish.PressedAppearance = Appearance63
        Me.cmdDeductDish.ShowFocusRect = False
        Me.cmdDeductDish.ShowOutline = False
        Me.cmdDeductDish.Size = New System.Drawing.Size(65, 40)
        Me.cmdDeductDish.TabIndex = 456
        Me.cmdDeductDish.Tag = "-"
        Me.cmdDeductDish.UseAppStyling = False
        Me.cmdDeductDish.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDeductDish.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDeductDish.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdAddDish
        '
        Appearance64.BackColor = System.Drawing.Color.FromArgb(CType(CType(148, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(196, Byte), Integer))
        Appearance64.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(148, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(196, Byte), Integer))
        Appearance64.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance64.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance64.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance64.BorderColor2 = System.Drawing.Color.Maroon
        Appearance64.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance64.ForeColor = System.Drawing.Color.Black
        Appearance64.Image = CType(resources.GetObject("Appearance64.Image"), Object)
        Appearance64.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance64.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance64.TextVAlignAsString = "Bottom"
        Me.cmdAddDish.Appearance = Appearance64
        Me.cmdAddDish.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance65.BackColor = System.Drawing.Color.DarkOrange
        Appearance65.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance65.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance65.ForeColor = System.Drawing.Color.Black
        Me.cmdAddDish.HotTrackAppearance = Appearance65
        Me.cmdAddDish.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdAddDish.Location = New System.Drawing.Point(135, 5)
        Me.cmdAddDish.Name = "cmdAddDish"
        Appearance66.BackColor = System.Drawing.Color.OrangeRed
        Appearance66.BackColor2 = System.Drawing.Color.Tomato
        Appearance66.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdAddDish.PressedAppearance = Appearance66
        Me.cmdAddDish.ShowFocusRect = False
        Me.cmdAddDish.ShowOutline = False
        Me.cmdAddDish.Size = New System.Drawing.Size(65, 40)
        Me.cmdAddDish.TabIndex = 455
        Me.cmdAddDish.Tag = "+"
        Me.cmdAddDish.UseAppStyling = False
        Me.cmdAddDish.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdAddDish.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdAddDish.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdOGDown
        '
        Appearance67.BackColor = System.Drawing.Color.FromArgb(CType(CType(148, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(196, Byte), Integer))
        Appearance67.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(148, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(196, Byte), Integer))
        Appearance67.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance67.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance67.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance67.BorderColor2 = System.Drawing.Color.Maroon
        Appearance67.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance67.ForeColor = System.Drawing.Color.Black
        Appearance67.Image = CType(resources.GetObject("Appearance67.Image"), Object)
        Appearance67.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance67.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance67.TextVAlignAsString = "Bottom"
        Me.cmdOGDown.Appearance = Appearance67
        Me.cmdOGDown.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance68.BackColor = System.Drawing.Color.DarkOrange
        Appearance68.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance68.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance68.ForeColor = System.Drawing.Color.Black
        Me.cmdOGDown.HotTrackAppearance = Appearance68
        Me.cmdOGDown.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdOGDown.Location = New System.Drawing.Point(70, 5)
        Me.cmdOGDown.Name = "cmdOGDown"
        Appearance69.BackColor = System.Drawing.Color.OrangeRed
        Appearance69.BackColor2 = System.Drawing.Color.Tomato
        Appearance69.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdOGDown.PressedAppearance = Appearance69
        Me.cmdOGDown.ShowFocusRect = False
        Me.cmdOGDown.ShowOutline = False
        Me.cmdOGDown.Size = New System.Drawing.Size(65, 40)
        Me.cmdOGDown.TabIndex = 454
        Me.cmdOGDown.Tag = "Down"
        Me.cmdOGDown.UseAppStyling = False
        Me.cmdOGDown.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOGDown.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOGDown.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdOGUp
        '
        Appearance70.BackColor = System.Drawing.Color.FromArgb(CType(CType(148, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(196, Byte), Integer))
        Appearance70.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(148, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(196, Byte), Integer))
        Appearance70.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance70.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance70.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance70.BorderColor2 = System.Drawing.Color.Maroon
        Appearance70.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance70.ForeColor = System.Drawing.Color.Black
        Appearance70.Image = CType(resources.GetObject("Appearance70.Image"), Object)
        Appearance70.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance70.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance70.TextVAlignAsString = "Bottom"
        Me.cmdOGUp.Appearance = Appearance70
        Me.cmdOGUp.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance71.BackColor = System.Drawing.Color.DarkOrange
        Appearance71.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance71.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance71.ForeColor = System.Drawing.Color.Black
        Me.cmdOGUp.HotTrackAppearance = Appearance71
        Me.cmdOGUp.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdOGUp.Location = New System.Drawing.Point(5, 5)
        Me.cmdOGUp.Name = "cmdOGUp"
        Appearance72.BackColor = System.Drawing.Color.OrangeRed
        Appearance72.BackColor2 = System.Drawing.Color.Tomato
        Appearance72.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdOGUp.PressedAppearance = Appearance72
        Me.cmdOGUp.ShowFocusRect = False
        Me.cmdOGUp.ShowOutline = False
        Me.cmdOGUp.Size = New System.Drawing.Size(65, 40)
        Me.cmdOGUp.TabIndex = 453
        Me.cmdOGUp.Tag = "Up"
        Me.cmdOGUp.UseAppStyling = False
        Me.cmdOGUp.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOGUp.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOGUp.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ugdOrderGrid
        '
        Appearance73.BackColor = System.Drawing.Color.FromArgb(CType(CType(162, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance73.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Me.ugdOrderGrid.DisplayLayout.Appearance = Appearance73
        UltraGridColumn1.Header.Caption = "Code"
        UltraGridColumn1.Header.VisiblePosition = 0
        UltraGridColumn1.Width = 48
        UltraGridColumn2.Header.Caption = "Name"
        UltraGridColumn2.Header.VisiblePosition = 2
        UltraGridColumn2.Width = 138
        Appearance74.TextHAlignAsString = "Right"
        UltraGridColumn3.CellAppearance = Appearance74
        UltraGridColumn3.Header.Caption = "Price"
        UltraGridColumn3.Header.VisiblePosition = 3
        UltraGridColumn3.Hidden = True
        Appearance75.TextHAlignAsString = "Center"
        UltraGridColumn4.CellAppearance = Appearance75
        UltraGridColumn4.Header.Caption = "Qty"
        UltraGridColumn4.Header.VisiblePosition = 1
        UltraGridColumn4.Width = 34
        Appearance76.TextHAlignAsString = "Right"
        UltraGridColumn5.CellAppearance = Appearance76
        UltraGridColumn5.Header.VisiblePosition = 4
        UltraGridColumn5.Width = 55
        UltraGridColumn6.Header.VisiblePosition = 5
        UltraGridColumn6.Hidden = True
        UltraGridColumn7.Header.VisiblePosition = 6
        UltraGridColumn7.Hidden = True
        UltraGridColumn8.Header.VisiblePosition = 7
        UltraGridColumn8.Hidden = True
        UltraGridColumn9.Header.VisiblePosition = 8
        UltraGridColumn9.Hidden = True
        UltraGridColumn10.Header.VisiblePosition = 9
        UltraGridColumn10.Hidden = True
        UltraGridColumn11.Header.VisiblePosition = 10
        UltraGridColumn11.Hidden = True
        UltraGridColumn12.Header.VisiblePosition = 11
        UltraGridColumn12.Hidden = True
        UltraGridBand1.Columns.AddRange(New Object() {UltraGridColumn1, UltraGridColumn2, UltraGridColumn3, UltraGridColumn4, UltraGridColumn5, UltraGridColumn6, UltraGridColumn7, UltraGridColumn8, UltraGridColumn9, UltraGridColumn10, UltraGridColumn11, UltraGridColumn12})
        Appearance77.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        UltraGridBand1.Header.Appearance = Appearance77
        Appearance78.BackColor = System.Drawing.Color.DarkOrange
        Appearance78.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance78.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        UltraGridBand1.Override.ActiveRowAppearance = Appearance78
        UltraGridBand1.Override.AllowAddNew = Infragistics.Win.UltraWinGrid.AllowAddNew.Yes
        Me.ugdOrderGrid.DisplayLayout.BandsSerializer.Add(UltraGridBand1)
        Me.ugdOrderGrid.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Me.ugdOrderGrid.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.[False]
        Appearance79.BackColor = System.Drawing.SystemColors.ActiveBorder
        Appearance79.BackColor2 = System.Drawing.SystemColors.ControlDark
        Appearance79.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance79.BorderColor = System.Drawing.SystemColors.Window
        Me.ugdOrderGrid.DisplayLayout.GroupByBox.Appearance = Appearance79
        Appearance80.ForeColor = System.Drawing.SystemColors.GrayText
        Me.ugdOrderGrid.DisplayLayout.GroupByBox.BandLabelAppearance = Appearance80
        Me.ugdOrderGrid.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Appearance81.BackColor = System.Drawing.SystemColors.ControlLightLight
        Appearance81.BackColor2 = System.Drawing.SystemColors.Control
        Appearance81.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal
        Appearance81.ForeColor = System.Drawing.SystemColors.GrayText
        Me.ugdOrderGrid.DisplayLayout.GroupByBox.PromptAppearance = Appearance81
        Me.ugdOrderGrid.DisplayLayout.MaxColScrollRegions = 1
        Me.ugdOrderGrid.DisplayLayout.MaxRowScrollRegions = 1
        Me.ugdOrderGrid.DisplayLayout.Override.AllowColMoving = Infragistics.Win.UltraWinGrid.AllowColMoving.NotAllowed
        Me.ugdOrderGrid.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted
        Me.ugdOrderGrid.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted
        Appearance82.BackColor = System.Drawing.SystemColors.Window
        Me.ugdOrderGrid.DisplayLayout.Override.CardAreaAppearance = Appearance82
        Appearance83.BorderColor = System.Drawing.Color.Silver
        Appearance83.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter
        Me.ugdOrderGrid.DisplayLayout.Override.CellAppearance = Appearance83
        Me.ugdOrderGrid.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.EditAndSelectText
        Me.ugdOrderGrid.DisplayLayout.Override.CellPadding = 0
        Appearance84.BackColor = System.Drawing.SystemColors.Control
        Appearance84.BackColor2 = System.Drawing.SystemColors.ControlDark
        Appearance84.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element
        Appearance84.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal
        Appearance84.BorderColor = System.Drawing.SystemColors.Window
        Me.ugdOrderGrid.DisplayLayout.Override.GroupByRowAppearance = Appearance84
        Appearance85.BackColor = System.Drawing.Color.FromArgb(CType(CType(162, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance85.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(162, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance85.TextHAlignAsString = "Center"
        Me.ugdOrderGrid.DisplayLayout.Override.HeaderAppearance = Appearance85
        Me.ugdOrderGrid.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti
        Me.ugdOrderGrid.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand
        Appearance86.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.ugdOrderGrid.DisplayLayout.Override.RowAlternateAppearance = Appearance86
        Appearance87.BackColor = System.Drawing.Color.Gainsboro
        Me.ugdOrderGrid.DisplayLayout.Override.RowAppearance = Appearance87
        Me.ugdOrderGrid.DisplayLayout.Override.RowSelectorHeaderStyle = Infragistics.Win.UltraWinGrid.RowSelectorHeaderStyle.None
        Me.ugdOrderGrid.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.[False]
        Me.ugdOrderGrid.DisplayLayout.Override.RowSizing = Infragistics.Win.UltraWinGrid.RowSizing.Sychronized
        Me.ugdOrderGrid.DisplayLayout.Override.RowSizingArea = Infragistics.Win.UltraWinGrid.RowSizingArea.RowBordersOnly
        Me.ugdOrderGrid.DisplayLayout.Override.SelectTypeCol = Infragistics.Win.UltraWinGrid.SelectType.None
        Me.ugdOrderGrid.DisplayLayout.Override.SelectTypeRow = Infragistics.Win.UltraWinGrid.SelectType.[Single]
        Appearance88.BackColor = System.Drawing.SystemColors.ControlLight
        Me.ugdOrderGrid.DisplayLayout.Override.TemplateAddRowAppearance = Appearance88
        Me.ugdOrderGrid.DisplayLayout.Override.WrapHeaderText = Infragistics.Win.DefaultableBoolean.[True]
        Me.ugdOrderGrid.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill
        Me.ugdOrderGrid.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate
        Me.ugdOrderGrid.DisplayLayout.ViewStyle = Infragistics.Win.UltraWinGrid.ViewStyle.SingleBand
        Me.ugdOrderGrid.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ugdOrderGrid.Location = New System.Drawing.Point(19, 518)
        Me.ugdOrderGrid.Name = "ugdOrderGrid"
        Me.ugdOrderGrid.Size = New System.Drawing.Size(279, 129)
        Me.ugdOrderGrid.TabIndex = 462
        '
        'UltraButton61
        '
        Appearance89.BackColor = System.Drawing.Color.OrangeRed
        Appearance89.BackColor2 = System.Drawing.Color.Tomato
        Appearance89.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance89.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance89.BorderColor = System.Drawing.Color.Brown
        Appearance89.BorderColor2 = System.Drawing.Color.Brown
        Appearance89.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance89.ForeColor = System.Drawing.Color.White
        Me.UltraButton61.Appearance = Appearance89
        Me.UltraButton61.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance90.BackColor = System.Drawing.Color.PowderBlue
        Appearance90.BackColor2 = System.Drawing.Color.Aqua
        Appearance90.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance90.ForeColor = System.Drawing.Color.Black
        Me.UltraButton61.HotTrackAppearance = Appearance90
        Me.UltraButton61.Location = New System.Drawing.Point(199, 186)
        Me.UltraButton61.Name = "UltraButton61"
        Me.UltraButton61.ShowFocusRect = False
        Me.UltraButton61.ShowOutline = False
        Me.UltraButton61.Size = New System.Drawing.Size(89, 36)
        Me.UltraButton61.TabIndex = 463
        Me.UltraButton61.Text = "Up"
        Me.UltraButton61.UseAppStyling = False
        Me.UltraButton61.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton61.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.UltraButton61.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton62
        '
        Appearance91.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance91.BackColor2 = System.Drawing.Color.ForestGreen
        Appearance91.BackGradientStyle = Infragistics.Win.GradientStyle.VerticalBump
        Appearance91.BorderColor = System.Drawing.Color.Yellow
        Appearance91.BorderColor2 = System.Drawing.Color.Maroon
        Appearance91.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance91.ForeColor = System.Drawing.Color.White
        Me.UltraButton62.Appearance = Appearance91
        Me.UltraButton62.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance92.BackColor = System.Drawing.Color.PowderBlue
        Appearance92.BackColor2 = System.Drawing.Color.Aqua
        Appearance92.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance92.ForeColor = System.Drawing.Color.Black
        Me.UltraButton62.HotTrackAppearance = Appearance92
        Me.UltraButton62.Location = New System.Drawing.Point(428, 153)
        Me.UltraButton62.Name = "UltraButton62"
        Me.UltraButton62.ShowFocusRect = False
        Me.UltraButton62.ShowOutline = False
        Me.UltraButton62.Size = New System.Drawing.Size(110, 40)
        Me.UltraButton62.TabIndex = 482
        Me.UltraButton62.Text = "Prawns"
        Me.UltraButton62.UseAppStyling = False
        Me.UltraButton62.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton62.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.UltraButton62.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton63
        '
        Appearance93.BackColor = System.Drawing.Color.DarkOrange
        Appearance93.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance93.BackGradientStyle = Infragistics.Win.GradientStyle.VerticalBump
        Appearance93.BorderColor = System.Drawing.Color.Yellow
        Appearance93.BorderColor2 = System.Drawing.Color.Maroon
        Appearance93.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance93.ForeColor = System.Drawing.Color.White
        Me.UltraButton63.Appearance = Appearance93
        Me.UltraButton63.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance94.BackColor = System.Drawing.Color.PowderBlue
        Appearance94.BackColor2 = System.Drawing.Color.Aqua
        Appearance94.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance94.ForeColor = System.Drawing.Color.Black
        Me.UltraButton63.HotTrackAppearance = Appearance94
        Me.UltraButton63.Location = New System.Drawing.Point(312, 199)
        Me.UltraButton63.Name = "UltraButton63"
        Me.UltraButton63.ShowFocusRect = False
        Me.UltraButton63.ShowOutline = False
        Me.UltraButton63.Size = New System.Drawing.Size(110, 40)
        Me.UltraButton63.TabIndex = 481
        Me.UltraButton63.Text = "Prawns"
        Me.UltraButton63.UseAppStyling = False
        Me.UltraButton63.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton63.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.UltraButton63.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnTemplate
        '
        Appearance95.BackColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(120, Byte), Integer), CType(CType(36, Byte), Integer))
        Appearance95.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(30, Byte), Integer))
        Appearance95.BackGradientStyle = Infragistics.Win.GradientStyle.VerticalBump
        Appearance95.BorderColor = System.Drawing.Color.FromArgb(CType(CType(166, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance95.BorderColor2 = System.Drawing.Color.Maroon
        Appearance95.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance95.ForeColor = System.Drawing.Color.White
        Me.ubtnTemplate.Appearance = Appearance95
        Me.ubtnTemplate.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance96.BackColor = System.Drawing.Color.PowderBlue
        Appearance96.BackColor2 = System.Drawing.Color.Aqua
        Appearance96.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance96.ForeColor = System.Drawing.Color.Black
        Me.ubtnTemplate.HotTrackAppearance = Appearance96
        Me.ubtnTemplate.Location = New System.Drawing.Point(428, 199)
        Me.ubtnTemplate.Name = "ubtnTemplate"
        Me.ubtnTemplate.ShowFocusRect = False
        Me.ubtnTemplate.ShowOutline = False
        Me.ubtnTemplate.Size = New System.Drawing.Size(132, 40)
        Me.ubtnTemplate.TabIndex = 483
        Me.ubtnTemplate.Text = "Prawns"
        Me.ubtnTemplate.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnTemplate.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.ubtnTemplate.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton64
        '
        Appearance97.BackColor = System.Drawing.Color.DarkSlateBlue
        Appearance97.BackColor2 = System.Drawing.Color.SlateBlue
        Appearance97.BackGradientStyle = Infragistics.Win.GradientStyle.VerticalBump
        Appearance97.BorderColor = System.Drawing.Color.MediumPurple
        Appearance97.BorderColor2 = System.Drawing.Color.Maroon
        Appearance97.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance97.ForeColor = System.Drawing.Color.White
        Me.UltraButton64.Appearance = Appearance97
        Me.UltraButton64.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance98.BackColor = System.Drawing.Color.PowderBlue
        Appearance98.BackColor2 = System.Drawing.Color.Aqua
        Appearance98.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance98.ForeColor = System.Drawing.Color.Black
        Me.UltraButton64.HotTrackAppearance = Appearance98
        Me.UltraButton64.Location = New System.Drawing.Point(566, 199)
        Me.UltraButton64.Name = "UltraButton64"
        Me.UltraButton64.ShowFocusRect = False
        Me.UltraButton64.ShowOutline = False
        Me.UltraButton64.Size = New System.Drawing.Size(110, 40)
        Me.UltraButton64.TabIndex = 484
        Me.UltraButton64.Text = "Prawns"
        Me.UltraButton64.UseAppStyling = False
        Me.UltraButton64.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton64.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.UltraButton64.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton46
        '
        Appearance99.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(120, Byte), Integer), CType(CType(69, Byte), Integer))
        Appearance99.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(70, Byte), Integer))
        Appearance99.BackGradientStyle = Infragistics.Win.GradientStyle.VerticalBump
        Appearance99.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(180, Byte), Integer), CType(CType(70, Byte), Integer))
        Appearance99.BorderColor2 = System.Drawing.Color.Maroon
        Appearance99.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance99.ForeColor = System.Drawing.Color.PaleGreen
        Me.UltraButton46.Appearance = Appearance99
        Me.UltraButton46.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance100.BackColor = System.Drawing.Color.PowderBlue
        Appearance100.BackColor2 = System.Drawing.Color.Aqua
        Appearance100.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance100.ForeColor = System.Drawing.Color.Black
        Me.UltraButton46.HotTrackAppearance = Appearance100
        Me.UltraButton46.Location = New System.Drawing.Point(428, 363)
        Me.UltraButton46.Name = "UltraButton46"
        Me.UltraButton46.ShowFocusRect = False
        Me.UltraButton46.ShowOutline = False
        Me.UltraButton46.Size = New System.Drawing.Size(150, 40)
        Me.UltraButton46.TabIndex = 488
        Me.UltraButton46.Text = "Prawns"
        Me.UltraButton46.UseAppStyling = False
        Me.UltraButton46.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton46.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.UltraButton46.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton66
        '
        Appearance101.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(120, Byte), Integer), CType(CType(70, Byte), Integer))
        Appearance101.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(70, Byte), Integer))
        Appearance101.BackGradientStyle = Infragistics.Win.GradientStyle.VerticalBump
        Appearance101.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(180, Byte), Integer), CType(CType(70, Byte), Integer))
        Appearance101.BorderColor2 = System.Drawing.Color.Maroon
        Appearance101.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance101.ForeColor = System.Drawing.Color.White
        Me.UltraButton66.Appearance = Appearance101
        Me.UltraButton66.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance102.BackColor = System.Drawing.Color.PowderBlue
        Appearance102.BackColor2 = System.Drawing.Color.Aqua
        Appearance102.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance102.ForeColor = System.Drawing.Color.Black
        Me.UltraButton66.HotTrackAppearance = Appearance102
        Me.UltraButton66.Location = New System.Drawing.Point(428, 404)
        Me.UltraButton66.Name = "UltraButton66"
        Me.UltraButton66.ShowFocusRect = False
        Me.UltraButton66.ShowOutline = False
        Me.UltraButton66.Size = New System.Drawing.Size(150, 40)
        Me.UltraButton66.TabIndex = 489
        Me.UltraButton66.Text = "Prawns"
        Me.UltraButton66.UseAppStyling = False
        Me.UltraButton66.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton66.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.UltraButton66.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton48
        '
        Appearance103.BackColor = System.Drawing.Color.DarkOliveGreen
        Appearance103.BackColor2 = System.Drawing.Color.DarkOliveGreen
        Appearance103.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance103.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance103.BorderColor = System.Drawing.Color.Khaki
        Appearance103.BorderColor2 = System.Drawing.Color.Maroon
        Appearance103.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance103.ForeColor = System.Drawing.Color.White
        Appearance103.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance103.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance103.TextVAlignAsString = "Middle"
        Me.UltraButton48.Appearance = Appearance103
        Me.UltraButton48.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance104.BackColor = System.Drawing.Color.DarkOrange
        Appearance104.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance104.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance104.ForeColor = System.Drawing.Color.Black
        Me.UltraButton48.HotTrackAppearance = Appearance104
        Me.UltraButton48.ImageSize = New System.Drawing.Size(40, 40)
        Me.UltraButton48.Location = New System.Drawing.Point(20, 20)
        Me.UltraButton48.Name = "UltraButton48"
        Appearance105.BackColor = System.Drawing.Color.OrangeRed
        Appearance105.BackColor2 = System.Drawing.Color.Tomato
        Appearance105.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.UltraButton48.PressedAppearance = Appearance105
        Me.UltraButton48.ShowFocusRect = False
        Me.UltraButton48.ShowOutline = False
        Me.UltraButton48.Size = New System.Drawing.Size(80, 60)
        Me.UltraButton48.TabIndex = 491
        Me.UltraButton48.Tag = ""
        Me.UltraButton48.Text = "7:00"
        Me.UltraButton48.UseAppStyling = False
        Me.UltraButton48.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton48.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton48.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraPanel1
        '
        Appearance106.BackColor = System.Drawing.Color.Olive
        Me.UltraPanel1.Appearance = Appearance106
        '
        'UltraPanel1.ClientArea
        '
        Me.UltraPanel1.ClientArea.Controls.Add(Me.UltraButton48)
        Me.UltraPanel1.Location = New System.Drawing.Point(428, 252)
        Me.UltraPanel1.Name = "UltraPanel1"
        Me.UltraPanel1.Size = New System.Drawing.Size(120, 100)
        Me.UltraPanel1.TabIndex = 492
        '
        'cmdBack
        '
        Appearance107.BackColor = System.Drawing.Color.IndianRed
        Appearance107.BackColor2 = System.Drawing.Color.DarkRed
        Appearance107.BackGradientStyle = Infragistics.Win.GradientStyle.VerticalBump
        Appearance107.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance107.BorderColor = System.Drawing.Color.Brown
        Appearance107.BorderColor2 = System.Drawing.Color.Brown
        Appearance107.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance107.ForeColor = System.Drawing.Color.White
        Appearance107.Image = CType(resources.GetObject("Appearance107.Image"), Object)
        Me.cmdBack.Appearance = Appearance107
        Me.cmdBack.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance108.BackColor = System.Drawing.Color.PowderBlue
        Appearance108.BackColor2 = System.Drawing.Color.Aqua
        Appearance108.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance108.ForeColor = System.Drawing.Color.Black
        Me.cmdBack.HotTrackAppearance = Appearance108
        Me.cmdBack.ImageSize = New System.Drawing.Size(40, 40)
        Me.cmdBack.Location = New System.Drawing.Point(544, 124)
        Me.cmdBack.Name = "cmdBack"
        Me.cmdBack.ShowFocusRect = False
        Me.cmdBack.ShowOutline = False
        Me.cmdBack.Size = New System.Drawing.Size(140, 56)
        Me.cmdBack.TabIndex = 493
        Me.cmdBack.Text = "Back"
        Me.cmdBack.UseAppStyling = False
        Me.cmdBack.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdBack.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdBack.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton44
        '
        Appearance109.BackColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance109.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(10, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance109.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop20
        Appearance109.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance109.BorderColor = System.Drawing.Color.FromArgb(CType(CType(90, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(200, Byte), Integer))
        Appearance109.BorderColor2 = System.Drawing.Color.Maroon
        Appearance109.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance109.ForeColor = System.Drawing.Color.White
        Appearance109.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance109.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance109.TextVAlignAsString = "Middle"
        Me.UltraButton44.Appearance = Appearance109
        Me.UltraButton44.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance110.BackColor = System.Drawing.Color.DarkOrange
        Appearance110.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance110.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance110.ForeColor = System.Drawing.Color.Black
        Me.UltraButton44.HotTrackAppearance = Appearance110
        Me.UltraButton44.ImageSize = New System.Drawing.Size(40, 40)
        Me.UltraButton44.Location = New System.Drawing.Point(409, 71)
        Me.UltraButton44.Name = "UltraButton44"
        Appearance111.BackColor = System.Drawing.Color.OrangeRed
        Appearance111.BackColor2 = System.Drawing.Color.Tomato
        Appearance111.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.UltraButton44.PressedAppearance = Appearance111
        Me.UltraButton44.ShowFocusRect = False
        Me.UltraButton44.ShowOutline = False
        Me.UltraButton44.Size = New System.Drawing.Size(69, 47)
        Me.UltraButton44.TabIndex = 494
        Me.UltraButton44.Tag = ""
        Me.UltraButton44.Text = "10"
        Me.UltraButton44.UseAppStyling = False
        Me.UltraButton44.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton44.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton44.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton45
        '
        Appearance112.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance112.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer))
        Appearance112.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop20
        Appearance112.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance112.BorderColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance112.BorderColor2 = System.Drawing.Color.Maroon
        Appearance112.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance112.ForeColor = System.Drawing.Color.White
        Appearance112.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance112.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance112.TextVAlignAsString = "Middle"
        Me.UltraButton45.Appearance = Appearance112
        Me.UltraButton45.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance113.BackColor = System.Drawing.Color.DarkOrange
        Appearance113.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance113.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance113.ForeColor = System.Drawing.Color.Black
        Me.UltraButton45.HotTrackAppearance = Appearance113
        Me.UltraButton45.ImageSize = New System.Drawing.Size(40, 40)
        Me.UltraButton45.Location = New System.Drawing.Point(491, 71)
        Me.UltraButton45.Name = "UltraButton45"
        Appearance114.BackColor = System.Drawing.Color.OrangeRed
        Appearance114.BackColor2 = System.Drawing.Color.Tomato
        Appearance114.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.UltraButton45.PressedAppearance = Appearance114
        Me.UltraButton45.ShowFocusRect = False
        Me.UltraButton45.ShowOutline = False
        Me.UltraButton45.Size = New System.Drawing.Size(69, 47)
        Me.UltraButton45.TabIndex = 495
        Me.UltraButton45.Tag = ""
        Me.UltraButton45.Text = "12"
        Me.UltraButton45.UseAppStyling = False
        Me.UltraButton45.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton45.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton45.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdTender50
        '
        Appearance115.BackColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance115.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance115.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance115.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance115.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance115.BorderColor2 = System.Drawing.Color.Maroon
        Appearance115.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance115.ForeColor = System.Drawing.Color.White
        Appearance115.TextVAlignAsString = "Middle"
        Me.cmdTender50.Appearance = Appearance115
        Me.cmdTender50.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance116.BackColor = System.Drawing.Color.DarkOrange
        Appearance116.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance116.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance116.ForeColor = System.Drawing.Color.Black
        Me.cmdTender50.HotTrackAppearance = Appearance116
        Me.cmdTender50.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdTender50.Location = New System.Drawing.Point(313, 351)
        Me.cmdTender50.Name = "cmdTender50"
        Appearance117.BackColor = System.Drawing.Color.OrangeRed
        Appearance117.BackColor2 = System.Drawing.Color.Tomato
        Appearance117.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdTender50.PressedAppearance = Appearance117
        Me.cmdTender50.ShowFocusRect = False
        Me.cmdTender50.ShowOutline = False
        Me.cmdTender50.Size = New System.Drawing.Size(100, 45)
        Me.cmdTender50.TabIndex = 520
        Me.cmdTender50.Tag = "50.00"
        Me.cmdTender50.Text = "£50"
        Me.cmdTender50.UseAppStyling = False
        Me.cmdTender50.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTender50.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTender50.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdTender20
        '
        Appearance118.BackColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance118.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance118.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance118.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance118.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance118.BorderColor2 = System.Drawing.Color.Maroon
        Appearance118.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance118.ForeColor = System.Drawing.Color.White
        Appearance118.TextVAlignAsString = "Middle"
        Me.cmdTender20.Appearance = Appearance118
        Me.cmdTender20.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance119.BackColor = System.Drawing.Color.DarkOrange
        Appearance119.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance119.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance119.ForeColor = System.Drawing.Color.Black
        Me.cmdTender20.HotTrackAppearance = Appearance119
        Me.cmdTender20.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdTender20.Location = New System.Drawing.Point(313, 300)
        Me.cmdTender20.Name = "cmdTender20"
        Appearance120.BackColor = System.Drawing.Color.OrangeRed
        Appearance120.BackColor2 = System.Drawing.Color.Tomato
        Appearance120.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdTender20.PressedAppearance = Appearance120
        Me.cmdTender20.ShowFocusRect = False
        Me.cmdTender20.ShowOutline = False
        Me.cmdTender20.Size = New System.Drawing.Size(100, 45)
        Me.cmdTender20.TabIndex = 519
        Me.cmdTender20.Tag = "20.00"
        Me.cmdTender20.Text = "£20"
        Me.cmdTender20.UseAppStyling = False
        Me.cmdTender20.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTender20.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTender20.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdTender10
        '
        Appearance121.BackColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance121.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance121.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance121.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance121.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance121.BorderColor2 = System.Drawing.Color.Maroon
        Appearance121.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance121.ForeColor = System.Drawing.Color.White
        Appearance121.TextVAlignAsString = "Middle"
        Me.cmdTender10.Appearance = Appearance121
        Me.cmdTender10.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance122.BackColor = System.Drawing.Color.DarkOrange
        Appearance122.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance122.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance122.ForeColor = System.Drawing.Color.Black
        Me.cmdTender10.HotTrackAppearance = Appearance122
        Me.cmdTender10.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdTender10.Location = New System.Drawing.Point(313, 249)
        Me.cmdTender10.Name = "cmdTender10"
        Appearance123.BackColor = System.Drawing.Color.OrangeRed
        Appearance123.BackColor2 = System.Drawing.Color.Tomato
        Appearance123.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdTender10.PressedAppearance = Appearance123
        Me.cmdTender10.ShowFocusRect = False
        Me.cmdTender10.ShowOutline = False
        Me.cmdTender10.Size = New System.Drawing.Size(100, 45)
        Me.cmdTender10.TabIndex = 518
        Me.cmdTender10.Tag = "10.00"
        Me.cmdTender10.Text = "£10"
        Me.cmdTender10.UseAppStyling = False
        Me.cmdTender10.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTender10.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTender10.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton68
        '
        Appearance124.BackColor = System.Drawing.Color.Transparent
        Appearance124.BackColor2 = System.Drawing.Color.Transparent
        Appearance124.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop20
        Appearance124.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance124.BorderColor = System.Drawing.Color.FromArgb(CType(CType(90, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(200, Byte), Integer))
        Appearance124.BorderColor2 = System.Drawing.Color.Maroon
        Appearance124.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance124.ForeColor = System.Drawing.Color.White
        Appearance124.Image = CType(resources.GetObject("Appearance124.Image"), Object)
        Appearance124.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance124.TextVAlignAsString = "Middle"
        Me.UltraButton68.Appearance = Appearance124
        Me.UltraButton68.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance125.BackColor = System.Drawing.Color.DarkOrange
        Appearance125.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance125.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance125.ForeColor = System.Drawing.Color.Black
        Me.UltraButton68.HotTrackAppearance = Appearance125
        Me.UltraButton68.ImageSize = New System.Drawing.Size(45, 45)
        Me.UltraButton68.Location = New System.Drawing.Point(478, 450)
        Me.UltraButton68.Name = "UltraButton68"
        Appearance126.BackColor = System.Drawing.Color.OrangeRed
        Appearance126.BackColor2 = System.Drawing.Color.Tomato
        Appearance126.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.UltraButton68.PressedAppearance = Appearance126
        Me.UltraButton68.ShowFocusRect = False
        Me.UltraButton68.ShowOutline = False
        Me.UltraButton68.Size = New System.Drawing.Size(100, 45)
        Me.UltraButton68.TabIndex = 521
        Me.UltraButton68.Tag = ""
        Me.UltraButton68.UseAppStyling = False
        Me.UltraButton68.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton68.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton68.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraLabel1
        '
        Appearance127.BackColor = System.Drawing.Color.Transparent
        Appearance127.BorderColor = System.Drawing.Color.Transparent
        Appearance127.ForeColor = System.Drawing.Color.Gold
        Appearance127.ImageBackground = CType(resources.GetObject("Appearance127.ImageBackground"), System.Drawing.Image)
        Appearance127.TextHAlignAsString = "Center"
        Appearance127.TextVAlignAsString = "Middle"
        Me.UltraLabel1.Appearance = Appearance127
        Me.UltraLabel1.BorderStyleInner = Infragistics.Win.UIElementBorderStyle.Solid
        Me.UltraLabel1.BorderStyleOuter = Infragistics.Win.UIElementBorderStyle.Solid
        Me.UltraLabel1.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UltraLabel1.Location = New System.Drawing.Point(566, 68)
        Me.UltraLabel1.Name = "UltraLabel1"
        Me.UltraLabel1.Size = New System.Drawing.Size(266, 50)
        Me.UltraLabel1.TabIndex = 522
        Me.UltraLabel1.Text = "Cancel"
        '
        'UltraButton70
        '
        Appearance128.BackColor = System.Drawing.Color.Teal
        Appearance128.BackColor2 = System.Drawing.Color.SteelBlue
        Appearance128.BackGradientStyle = Infragistics.Win.GradientStyle.Elliptical
        Appearance128.BorderAlpha = Infragistics.Win.Alpha.Opaque
        Appearance128.BorderColor = System.Drawing.Color.LightSkyBlue
        Appearance128.BorderColor2 = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance128.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance128.ForeColor = System.Drawing.Color.White
        Appearance128.Image = CType(resources.GetObject("Appearance128.Image"), Object)
        Appearance128.ImageBackgroundStyle = Infragistics.Win.ImageBackgroundStyle.Tiled
        Appearance128.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance128.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance128.TextHAlignAsString = "Center"
        Appearance128.TextVAlignAsString = "Bottom"
        Me.UltraButton70.Appearance = Appearance128
        Me.UltraButton70.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance129.BackColor = System.Drawing.Color.PowderBlue
        Appearance129.BackColor2 = System.Drawing.Color.Aqua
        Appearance129.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance129.ForeColor = System.Drawing.Color.Black
        Me.UltraButton70.HotTrackAppearance = Appearance129
        Me.UltraButton70.ImageSize = New System.Drawing.Size(46, 46)
        Me.UltraButton70.Location = New System.Drawing.Point(308, 498)
        Me.UltraButton70.Name = "UltraButton70"
        Me.UltraButton70.ShowFocusRect = False
        Me.UltraButton70.ShowOutline = False
        Me.UltraButton70.Size = New System.Drawing.Size(160, 80)
        Me.UltraButton70.TabIndex = 525
        Me.UltraButton70.Text = "Delivery"
        Me.UltraButton70.UseAppStyling = False
        Me.UltraButton70.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton70.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton16
        '
        Appearance130.BackColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(120, Byte), Integer), CType(CType(36, Byte), Integer))
        Appearance130.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(30, Byte), Integer))
        Appearance130.BackGradientStyle = Infragistics.Win.GradientStyle.VerticalBump
        Appearance130.BorderColor = System.Drawing.Color.FromArgb(CType(CType(166, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance130.BorderColor2 = System.Drawing.Color.Maroon
        Appearance130.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance130.ForeColor = System.Drawing.Color.White
        Appearance130.ImageBackground = CType(resources.GetObject("Appearance130.ImageBackground"), System.Drawing.Image)
        Me.UltraButton16.Appearance = Appearance130
        Me.UltraButton16.ButtonStyle = Infragistics.Win.UIElementButtonStyle.Flat
        Me.UltraButton16.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance131.BackColor = System.Drawing.Color.PowderBlue
        Appearance131.BackColor2 = System.Drawing.Color.Aqua
        Appearance131.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance131.ForeColor = System.Drawing.Color.Black
        Me.UltraButton16.HotTrackAppearance = Appearance131
        Me.UltraButton16.Location = New System.Drawing.Point(238, 406)
        Me.UltraButton16.Name = "UltraButton16"
        Me.UltraButton16.ShowFocusRect = False
        Me.UltraButton16.ShowOutline = False
        Me.UltraButton16.Size = New System.Drawing.Size(157, 76)
        Me.UltraButton16.TabIndex = 527
        Me.UltraButton16.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton16.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.UltraButton16.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton21
        '
        Appearance132.BackColorAlpha = Infragistics.Win.Alpha.Transparent
        Appearance132.BorderColor = System.Drawing.Color.Transparent
        Appearance132.ForeColor = System.Drawing.Color.Sienna
        Appearance132.ImageBackground = CType(resources.GetObject("Appearance132.ImageBackground"), System.Drawing.Image)
        Me.UltraButton21.Appearance = Appearance132
        Me.UltraButton21.ButtonStyle = Infragistics.Win.UIElementButtonStyle.Flat
        Me.UltraButton21.Font = New System.Drawing.Font("Arial", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance133.BackColorAlpha = Infragistics.Win.Alpha.Transparent
        Appearance133.BorderAlpha = Infragistics.Win.Alpha.Transparent
        Appearance133.ForeColor = System.Drawing.Color.Sienna
        Appearance133.ImageBackground = CType(resources.GetObject("Appearance133.ImageBackground"), System.Drawing.Image)
        Appearance133.ImageBackgroundAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Me.UltraButton21.HotTrackAppearance = Appearance133
        Me.UltraButton21.ImageSize = New System.Drawing.Size(100, 88)
        Me.UltraButton21.Location = New System.Drawing.Point(132, 406)
        Me.UltraButton21.Name = "UltraButton21"
        Appearance134.ImageBackground = CType(resources.GetObject("Appearance134.ImageBackground"), System.Drawing.Image)
        Me.UltraButton21.PressedAppearance = Appearance134
        Me.UltraButton21.ShowFocusRect = False
        Me.UltraButton21.ShowOutline = False
        Me.UltraButton21.Size = New System.Drawing.Size(100, 88)
        Me.UltraButton21.TabIndex = 532
        Me.UltraButton21.Text = "15"
        Me.UltraButton21.UseAppStyling = False
        Me.UltraButton21.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton21.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton21.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        Me.UltraButton21.Visible = False
        '
        'UltraButton22
        '
        Appearance135.BackColor = System.Drawing.Color.LimeGreen
        Appearance135.BackColor2 = System.Drawing.Color.Green
        Appearance135.BackGradientStyle = Infragistics.Win.GradientStyle.VerticalBump
        Appearance135.BorderColor = System.Drawing.Color.MediumPurple
        Appearance135.BorderColor2 = System.Drawing.Color.Maroon
        Appearance135.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance135.ForeColor = System.Drawing.Color.White
        Me.UltraButton22.Appearance = Appearance135
        Me.UltraButton22.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance136.BackColor = System.Drawing.Color.PowderBlue
        Appearance136.BackColor2 = System.Drawing.Color.Aqua
        Appearance136.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance136.ForeColor = System.Drawing.Color.Black
        Me.UltraButton22.HotTrackAppearance = Appearance136
        Me.UltraButton22.Location = New System.Drawing.Point(596, 331)
        Me.UltraButton22.Name = "UltraButton22"
        Me.UltraButton22.ShowFocusRect = False
        Me.UltraButton22.ShowOutline = False
        Me.UltraButton22.Size = New System.Drawing.Size(110, 40)
        Me.UltraButton22.TabIndex = 533
        Me.UltraButton22.Text = "Prawns"
        Me.UltraButton22.UseAppStyling = False
        Me.UltraButton22.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton22.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.UltraButton22.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton23
        '
        Appearance137.BackColor = System.Drawing.Color.DarkGoldenrod
        Appearance137.BackColor2 = System.Drawing.Color.DarkOliveGreen
        Appearance137.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance137.BorderColor = System.Drawing.Color.Khaki
        Appearance137.BorderColor2 = System.Drawing.Color.Maroon
        Appearance137.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance137.ForeColor = System.Drawing.Color.White
        Appearance137.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance137.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance137.TextVAlignAsString = "Middle"
        Me.UltraButton23.Appearance = Appearance137
        Me.UltraButton23.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance138.BackColor = System.Drawing.Color.DarkOrange
        Appearance138.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance138.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance138.ForeColor = System.Drawing.Color.Black
        Me.UltraButton23.HotTrackAppearance = Appearance138
        Me.UltraButton23.ImageSize = New System.Drawing.Size(40, 40)
        Me.UltraButton23.Location = New System.Drawing.Point(596, 252)
        Me.UltraButton23.Name = "UltraButton23"
        Appearance139.BackColor = System.Drawing.Color.OrangeRed
        Appearance139.BackColor2 = System.Drawing.Color.Tomato
        Appearance139.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.UltraButton23.PressedAppearance = Appearance139
        Me.UltraButton23.ShowFocusRect = False
        Me.UltraButton23.ShowOutline = False
        Me.UltraButton23.Size = New System.Drawing.Size(80, 60)
        Me.UltraButton23.TabIndex = 534
        Me.UltraButton23.Tag = ""
        Me.UltraButton23.Text = "7:00"
        Me.UltraButton23.UseAppStyling = False
        Me.UltraButton23.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton23.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton23.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton24
        '
        Appearance140.BackColor = System.Drawing.Color.FromArgb(CType(CType(148, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(196, Byte), Integer))
        Appearance140.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(148, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(196, Byte), Integer))
        Appearance140.BackColorAlpha = Infragistics.Win.Alpha.Transparent
        Appearance140.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance140.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance140.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance140.BorderColor2 = System.Drawing.Color.Maroon
        Appearance140.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance140.ForeColor = System.Drawing.Color.Black
        Appearance140.Image = CType(resources.GetObject("Appearance140.Image"), Object)
        Appearance140.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance140.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance140.TextVAlignAsString = "Middle"
        Me.UltraButton24.Appearance = Appearance140
        Me.UltraButton24.ButtonStyle = Infragistics.Win.UIElementButtonStyle.Borderless
        Me.UltraButton24.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance141.BackColor = System.Drawing.Color.DarkOrange
        Appearance141.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance141.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance141.ForeColor = System.Drawing.Color.Black
        Me.UltraButton24.HotTrackAppearance = Appearance141
        Me.UltraButton24.ImageSize = New System.Drawing.Size(260, 55)
        Me.UltraButton24.Location = New System.Drawing.Point(308, 592)
        Me.UltraButton24.Name = "UltraButton24"
        Appearance142.BackColor = System.Drawing.Color.OrangeRed
        Appearance142.BackColor2 = System.Drawing.Color.Tomato
        Appearance142.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.UltraButton24.PressedAppearance = Appearance142
        Me.UltraButton24.ShowFocusRect = False
        Me.UltraButton24.ShowOutline = False
        Me.UltraButton24.Size = New System.Drawing.Size(260, 55)
        Me.UltraButton24.TabIndex = 538
        Me.UltraButton24.Tag = "1.50"
        Me.UltraButton24.UseAppStyling = False
        Me.UltraButton24.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton24.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton24.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtn5
        '
        Appearance143.BackColor = System.Drawing.Color.Transparent
        Appearance143.BackColor2 = System.Drawing.Color.Transparent
        Appearance143.BackGradientStyle = Infragistics.Win.GradientStyle.None
        Appearance143.BorderAlpha = Infragistics.Win.Alpha.Opaque
        Appearance143.BorderColor = System.Drawing.Color.Transparent
        Appearance143.BorderColor2 = System.Drawing.Color.Transparent
        Appearance143.ForeColor = System.Drawing.Color.White
        Appearance143.ImageBackground = CType(resources.GetObject("Appearance143.ImageBackground"), System.Drawing.Image)
        Appearance143.TextHAlignAsString = "Center"
        Appearance143.TextVAlignAsString = "Middle"
        Me.ubtn5.Appearance = Appearance143
        Me.ubtn5.ButtonStyle = Infragistics.Win.UIElementButtonStyle.Flat
        Me.ubtn5.Font = New System.Drawing.Font("Arial", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance144.BackColor = System.Drawing.Color.PowderBlue
        Appearance144.BackColor2 = System.Drawing.Color.Aqua
        Appearance144.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance144.ForeColor = System.Drawing.Color.Black
        Me.ubtn5.HotTrackAppearance = Appearance144
        Me.ubtn5.ImageSize = New System.Drawing.Size(63, 63)
        Me.ubtn5.Location = New System.Drawing.Point(696, 247)
        Me.ubtn5.Name = "ubtn5"
        Appearance145.BackColor = System.Drawing.Color.Orange
        Appearance145.BackColor2 = System.Drawing.Color.DarkOrange
        Appearance145.ForeColor = System.Drawing.Color.Maroon
        Me.ubtn5.PressedAppearance = Appearance145
        Me.ubtn5.ShowFocusRect = False
        Me.ubtn5.ShowOutline = False
        Me.ubtn5.Size = New System.Drawing.Size(63, 63)
        Me.ubtn5.TabIndex = 539
        Me.ubtn5.Text = "5"
        Me.ubtn5.UseAppStyling = False
        Me.ubtn5.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.ubtn5.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraLabel2
        '
        Appearance146.BackColor = System.Drawing.Color.Transparent
        Appearance146.BorderColor = System.Drawing.Color.Transparent
        Appearance146.ForeColor = System.Drawing.Color.Gold
        Appearance146.ImageBackground = CType(resources.GetObject("Appearance146.ImageBackground"), System.Drawing.Image)
        Appearance146.TextHAlignAsString = "Center"
        Appearance146.TextVAlignAsString = "Middle"
        Me.UltraLabel2.Appearance = Appearance146
        Me.UltraLabel2.BorderStyleInner = Infragistics.Win.UIElementBorderStyle.Solid
        Me.UltraLabel2.BorderStyleOuter = Infragistics.Win.UIElementBorderStyle.Solid
        Me.UltraLabel2.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UltraLabel2.Location = New System.Drawing.Point(517, 518)
        Me.UltraLabel2.Name = "UltraLabel2"
        Me.UltraLabel2.Size = New System.Drawing.Size(323, 55)
        Me.UltraLabel2.TabIndex = 540
        Me.UltraLabel2.Text = "Yes"
        '
        'cmdTypical
        '
        Appearance147.ForeColor = System.Drawing.Color.Gainsboro
        Appearance147.ImageBackground = CType(resources.GetObject("Appearance147.ImageBackground"), System.Drawing.Image)
        Me.cmdTypical.Appearance = Appearance147
        Me.cmdTypical.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdTypical.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdTypical.Location = New System.Drawing.Point(690, 177)
        Me.cmdTypical.Name = "cmdTypical"
        Me.cmdTypical.Size = New System.Drawing.Size(132, 45)
        Me.cmdTypical.TabIndex = 541
        Me.cmdTypical.Text = "UltraButton25"
        Me.cmdTypical.UseAppStyling = False
        Me.cmdTypical.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdTypical.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton25
        '
        Appearance148.BackColor = System.Drawing.Color.Transparent
        Appearance148.BackColor2 = System.Drawing.Color.Transparent
        Appearance148.BackGradientStyle = Infragistics.Win.GradientStyle.VerticalBump
        Appearance148.BorderColor = System.Drawing.Color.LightGray
        Appearance148.BorderColor2 = System.Drawing.Color.Maroon
        Appearance148.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance148.ForeColor = System.Drawing.Color.White
        Appearance148.ImageBackground = Global.EZMenu.My.Resources.ezresource.dkbutton
        Me.UltraButton25.Appearance = Appearance148
        Me.UltraButton25.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.UltraButton25.Font = New System.Drawing.Font("Adobe Heiti Std R", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        Appearance149.BackColor = System.Drawing.Color.PowderBlue
        Appearance149.BackColor2 = System.Drawing.Color.Aqua
        Appearance149.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance149.ForeColor = System.Drawing.Color.Black
        Me.UltraButton25.HotTrackAppearance = Appearance149
        Me.UltraButton25.Location = New System.Drawing.Point(606, 396)
        Me.UltraButton25.Name = "UltraButton25"
        Me.UltraButton25.ShowFocusRect = False
        Me.UltraButton25.ShowOutline = False
        Me.UltraButton25.Size = New System.Drawing.Size(153, 67)
        Me.UltraButton25.TabIndex = 542
        Me.UltraButton25.Text = "8 Aura Court,      163 Peckham Rye"
        Me.UltraButton25.UseAppStyling = False
        Me.UltraButton25.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton25.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.UltraButton25.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'frmSpare
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(16, Byte), Integer), CType(CType(101, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(849, 711)
        Me.Controls.Add(Me.UltraButton15)
        Me.Controls.Add(Me.UltraButton25)
        Me.Controls.Add(Me.cmdTypical)
        Me.Controls.Add(Me.UltraLabel2)
        Me.Controls.Add(Me.ubtn5)
        Me.Controls.Add(Me.UltraButton24)
        Me.Controls.Add(Me.UltraButton23)
        Me.Controls.Add(Me.UltraButton22)
        Me.Controls.Add(Me.UltraButton21)
        Me.Controls.Add(Me.UltraButton16)
        Me.Controls.Add(Me.UltraButton70)
        Me.Controls.Add(Me.UltraLabel1)
        Me.Controls.Add(Me.UltraButton68)
        Me.Controls.Add(Me.cmdTender50)
        Me.Controls.Add(Me.cmdTender20)
        Me.Controls.Add(Me.cmdTender10)
        Me.Controls.Add(Me.UltraButton45)
        Me.Controls.Add(Me.UltraButton44)
        Me.Controls.Add(Me.cmdBack)
        Me.Controls.Add(Me.UltraPanel1)
        Me.Controls.Add(Me.UltraButton66)
        Me.Controls.Add(Me.UltraButton46)
        Me.Controls.Add(Me.UltraButton64)
        Me.Controls.Add(Me.ubtnTemplate)
        Me.Controls.Add(Me.UltraButton62)
        Me.Controls.Add(Me.UltraButton63)
        Me.Controls.Add(Me.UltraButton61)
        Me.Controls.Add(Me.ugdOrderGrid)
        Me.Controls.Add(Me.UltraPanel2)
        Me.Controls.Add(Me.UltraButton60)
        Me.Controls.Add(Me.UltraButton50)
        Me.Controls.Add(Me.UltraButton43)
        Me.Controls.Add(Me.UltraButton14)
        Me.Controls.Add(Me.UltraButton13)
        Me.Controls.Add(Me.UltraButton10)
        Me.Controls.Add(Me.UltraButton11)
        Me.Controls.Add(Me.UltraButton7)
        Me.Controls.Add(Me.UltraButton8)
        Me.Controls.Add(Me.UltraButton9)
        Me.Controls.Add(Me.UltraButton4)
        Me.Controls.Add(Me.UltraButton5)
        Me.Controls.Add(Me.UltraButton6)
        Me.Controls.Add(Me.UltraButton3)
        Me.Controls.Add(Me.UltraButton2)
        Me.Controls.Add(Me.UltraButton1)
        Me.Controls.Add(Me.UltraButton17)
        Me.Controls.Add(Me.UltraButton18)
        Me.Controls.Add(Me.UltraButton19)
        Me.Controls.Add(Me.UltraButton20)
        Me.Controls.Add(Me.txtName)
        Me.Controls.Add(Me.UltraButton12)
        Me.Name = "frmSpare"
        Me.Text = "frmSpare"
        CType(Me.txtName, System.ComponentModel.ISupportInitialize).EndInit()
        Me.UltraPanel2.ClientArea.ResumeLayout(False)
        Me.UltraPanel2.ResumeLayout(False)
        CType(Me.ugdOrderGrid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.UltraPanel1.ClientArea.ResumeLayout(False)
        Me.UltraPanel1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtName As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents UltraButton17 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton18 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton19 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton20 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton1 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton2 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton3 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton4 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton5 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton6 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton7 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton8 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton9 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton10 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton11 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton12 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton13 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton14 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton15 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton43 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton50 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton60 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraPanel2 As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents cmdDeleteDish As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDeductDish As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdAddDish As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdOGDown As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdOGUp As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDishClearAll As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdLastItemQty As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdEditDish As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ugdOrderGrid As Infragistics.Win.UltraWinGrid.UltraGrid
    Friend WithEvents UltraButton61 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton62 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton63 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnTemplate As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton64 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton46 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton66 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton48 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraPanel1 As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents cmdBack As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton44 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton45 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdTender50 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdTender20 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdTender10 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton68 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraLabel1 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraButton70 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton16 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton21 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton22 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton23 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton24 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtn5 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraLabel2 As Infragistics.Win.Misc.UltraLabel
    Private WithEvents cmdTypical As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton25 As Infragistics.Win.Misc.UltraButton
End Class
