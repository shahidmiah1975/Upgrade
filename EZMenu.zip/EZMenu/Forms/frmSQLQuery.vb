﻿Imports EZControls
Imports System.Data.SqlClient

Public Class frmSQLQuery

    Private Sub frmSQLQuery_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        tempStr = "CAUTION: Invalid SQL statements can leave the database in a corrupted state and/or result in missing data. " &
            "Only use this if you know what you are doing!"
        lblQueryLabel.Text = tempStr

    End Sub

    Private Sub frmSQLQuery_Activated(sender As Object, e As EventArgs) Handles Me.Activated

        Try
            txtQuery.Focus()
        Catch ex As Exception

        End Try

    End Sub

    Private Sub cmdCancel_Click(sender As Object, e As EventArgs) Handles cmdCancel.Click

        Close()

    End Sub

    Private Sub cmdOK_Click(sender As Object, e As EventArgs) Handles cmdOK.Click

        Try
            If txtQuery.Text.Length > 0 Then
                strMsgBox = "Are you sure you want to proceed?"
                intMsgBoxResult = EZMsgBox.Show(strMsgBox, MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                If intMsgBoxResult = MsgBoxResult.Yes Then
                    objDB.ExeNonQuery(txtQuery.Text.Trim)
                    strMsgBox = intRowsAffected & " rows were affected"
                    Alert(strMsgBox)
                End If
            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub BackupRestore(strMode As String)

        Dim con As SqlConnection
        Dim cmd As SqlCommand

        Try

            If strMode = "backup" Then
                lblStatus.Text = "Database backup in progress. . ."
                lblStatus.Visible = True
                Application.DoEvents()
                Dim queryString As String = "BACKUP DATABASE [EZMENU_DATA.MDF] TO DISK='" & AppPath() & "ezdb_backup.bak" & "' WITH FORMAT"
                con = New SqlConnection("Data Source=.\SQLEXPRESS;Database=Master;integrated security=SSPI;")
                con.Open()
                cmd = New SqlCommand(queryString, con)
                cmd.ExecuteNonQuery()
                lblStatus.Visible = False
                MsgBox("Database backup complete")
            ElseIf strMode = "restore" Then
                lblStatus.Text = "Restoring database. . ."
                lblStatus.Visible = True
                Application.DoEvents()
                Dim queryString As String = "RESTORE DATABASE [EZMENU_DATA.MDF] FROM DISK='" & AppPath() & "ezdb_backup.bak'"
                con = New SqlConnection("Data Source=.\SQLEXPRESS;Database=Master;integrated security=SSPI;")
                con.Open()
                cmd = New SqlCommand(queryString, con)
                cmd.ExecuteNonQuery()
                lblStatus.Visible = False
                MsgBox("Database restore complete")
            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub cmdDBBackup_Click(sender As Object, e As EventArgs) Handles cmdDBBackup.Click, cmdDBRestore.Click

        If sender.text = "Restore" Then
            BackupRestore("restore")
        Else
            BackupRestore("backup")
        End If

    End Sub

End Class