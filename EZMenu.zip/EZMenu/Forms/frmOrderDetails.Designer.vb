﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmOrderItems
	Inherits System.Windows.Forms.Form

	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		Try
			If disposing AndAlso components IsNot Nothing Then
				components.Dispose()
			End If
		Finally
			MyBase.Dispose(disposing)
		End Try
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim Appearance18 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance19 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance20 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance4 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance5 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance6 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance7 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance8 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance9 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance10 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance11 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance12 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance13 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance14 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance21 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmOrderItems))
        Dim Appearance22 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance23 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Me.OrderItemsBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.OrderItemsTableAdapter = New EZMenu.EZMenuDataSetTableAdapters.OrderItemsTableAdapter()
        Me.TableAdapterManager = New EZMenu.EZMenuDataSetTableAdapters.TableAdapterManager()
        Me.EZMenuDataSet = New EZMenu.EZMenuDataSet()
        Me.lblLabel = New System.Windows.Forms.Label()
        Me.cmdCardDetails = New Infragistics.Win.Misc.UltraButton()
        Me.ugdOrderItems = New Infragistics.Win.UltraWinGrid.UltraGrid()
        Me.cmdClose = New Infragistics.Win.Misc.UltraButton()
        CType(Me.OrderItemsBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EZMenuDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ugdOrderItems, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'OrderItemsBindingSource
        '
        Me.OrderItemsBindingSource.DataMember = "OrderItems"
        '
        'OrderItemsTableAdapter
        '
        Me.OrderItemsTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.AltAddressTableAdapter = Nothing
        Me.TableAdapterManager.Alternative_PhoneTableAdapter = Nothing
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.BankingTableAdapter = Nothing
        Me.TableAdapterManager.BankPrintTableAdapter = Nothing
        Me.TableAdapterManager.CallerIDLogTableAdapter = Nothing
        Me.TableAdapterManager.CodesTableAdapter = Nothing
        Me.TableAdapterManager.CollectorTableAdapter = Nothing
        Me.TableAdapterManager.CustomerTableAdapter = Nothing
        Me.TableAdapterManager.DirectionsTableAdapter = Nothing
        Me.TableAdapterManager.DishTableAdapter = Nothing
        Me.TableAdapterManager.DrinksTableAdapter = Nothing
        Me.TableAdapterManager.FreeOffersTableAdapter = Nothing
        Me.TableAdapterManager.GroupsTableAdapter = Nothing
        Me.TableAdapterManager.KitchenNotesTableAdapter = Nothing
        Me.TableAdapterManager.ModifiersTableAdapter = Nothing
        Me.TableAdapterManager.NotesDBTableAdapter = Nothing
        Me.TableAdapterManager.OffersTableAdapter = Nothing
        Me.TableAdapterManager.OrderItemsTableAdapter = Me.OrderItemsTableAdapter
        Me.TableAdapterManager.OrdersTableAdapter = Nothing
        Me.TableAdapterManager.SetIDTableAdapter = Nothing
        Me.TableAdapterManager.SetMealsTableAdapter = Nothing
        Me.TableAdapterManager.SetSelectedItemsTableAdapter = Nothing
        Me.TableAdapterManager.SetSelectedTableAdapter = Nothing
        Me.TableAdapterManager.SummaryTableAdapter = Nothing
        Me.TableAdapterManager.Table_BillTableAdapter = Nothing
        Me.TableAdapterManager.Table_DrinksTableAdapter = Nothing
        Me.TableAdapterManager.Table_MealTableAdapter = Nothing
        Me.TableAdapterManager.TypicalTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = EZMenu.EZMenuDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        Me.TableAdapterManager.UsersTableAdapter = Nothing
        '
        'EZMenuDataSet
        '
        Me.EZMenuDataSet.DataSetName = "EZMenuDataSet"
        Me.EZMenuDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'lblLabel
        '
        Me.lblLabel.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblLabel.AutoSize = True
        Me.lblLabel.BackColor = System.Drawing.Color.Transparent
        Me.lblLabel.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLabel.ForeColor = System.Drawing.Color.SteelBlue
        Me.lblLabel.Location = New System.Drawing.Point(143, 20)
        Me.lblLabel.Name = "lblLabel"
        Me.lblLabel.Size = New System.Drawing.Size(190, 16)
        Me.lblLabel.TabIndex = 471
        Me.lblLabel.Text = "Details of the selected order:"
        Me.lblLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cmdCardDetails
        '
        Me.cmdCardDetails.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance18.BackColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance18.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance18.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance18.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance18.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance18.BorderColor2 = System.Drawing.Color.Maroon
        Appearance18.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance18.ForeColor = System.Drawing.Color.White
        Appearance18.ImageHAlign = Infragistics.Win.HAlign.Left
        Appearance18.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance18.TextVAlignAsString = "Middle"
        Me.cmdCardDetails.Appearance = Appearance18
        Me.cmdCardDetails.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance19.BackColor = System.Drawing.Color.DarkOrange
        Appearance19.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance19.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance19.ForeColor = System.Drawing.Color.Black
        Me.cmdCardDetails.HotTrackAppearance = Appearance19
        Me.cmdCardDetails.ImageSize = New System.Drawing.Size(24, 24)
        Me.cmdCardDetails.Location = New System.Drawing.Point(394, 427)
        Me.cmdCardDetails.Name = "cmdCardDetails"
        Appearance20.BackColor = System.Drawing.Color.OrangeRed
        Appearance20.BackColor2 = System.Drawing.Color.Tomato
        Appearance20.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdCardDetails.PressedAppearance = Appearance20
        Me.cmdCardDetails.ShowFocusRect = False
        Me.cmdCardDetails.ShowOutline = False
        Me.cmdCardDetails.Size = New System.Drawing.Size(70, 60)
        Me.cmdCardDetails.TabIndex = 521
        Me.cmdCardDetails.Tag = "0"
        Me.cmdCardDetails.Text = "Card details"
        Me.cmdCardDetails.UseAppStyling = False
        Me.cmdCardDetails.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdCardDetails.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdCardDetails.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdCardDetails.Visible = False
        '
        'ugdOrderItems
        '
        Me.ugdOrderItems.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance4.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance4.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Me.ugdOrderItems.DisplayLayout.Appearance = Appearance4
        Me.ugdOrderItems.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Me.ugdOrderItems.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.[False]
        Appearance5.BackColor = System.Drawing.SystemColors.ActiveBorder
        Appearance5.BackColor2 = System.Drawing.SystemColors.ControlDark
        Appearance5.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance5.BorderColor = System.Drawing.SystemColors.Window
        Me.ugdOrderItems.DisplayLayout.GroupByBox.Appearance = Appearance5
        Appearance6.ForeColor = System.Drawing.SystemColors.GrayText
        Me.ugdOrderItems.DisplayLayout.GroupByBox.BandLabelAppearance = Appearance6
        Me.ugdOrderItems.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Appearance7.BackColor = System.Drawing.SystemColors.ControlLightLight
        Appearance7.BackColor2 = System.Drawing.SystemColors.Control
        Appearance7.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal
        Appearance7.ForeColor = System.Drawing.SystemColors.GrayText
        Me.ugdOrderItems.DisplayLayout.GroupByBox.PromptAppearance = Appearance7
        Me.ugdOrderItems.DisplayLayout.MaxColScrollRegions = 1
        Me.ugdOrderItems.DisplayLayout.MaxRowScrollRegions = 1
        Me.ugdOrderItems.DisplayLayout.Override.AllowColMoving = Infragistics.Win.UltraWinGrid.AllowColMoving.NotAllowed
        Me.ugdOrderItems.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted
        Me.ugdOrderItems.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted
        Appearance8.BackColor = System.Drawing.SystemColors.Window
        Me.ugdOrderItems.DisplayLayout.Override.CardAreaAppearance = Appearance8
        Appearance9.BorderColor = System.Drawing.Color.Silver
        Appearance9.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter
        Me.ugdOrderItems.DisplayLayout.Override.CellAppearance = Appearance9
        Me.ugdOrderItems.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.EditAndSelectText
        Me.ugdOrderItems.DisplayLayout.Override.CellPadding = 0
        Appearance10.BackColor = System.Drawing.SystemColors.Control
        Appearance10.BackColor2 = System.Drawing.SystemColors.ControlDark
        Appearance10.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element
        Appearance10.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal
        Appearance10.BorderColor = System.Drawing.SystemColors.Window
        Me.ugdOrderItems.DisplayLayout.Override.GroupByRowAppearance = Appearance10
        Appearance11.BackColor = System.Drawing.Color.FromArgb(CType(CType(162, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance11.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(162, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance11.TextHAlignAsString = "Center"
        Me.ugdOrderItems.DisplayLayout.Override.HeaderAppearance = Appearance11
        Me.ugdOrderItems.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti
        Me.ugdOrderItems.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand
        Appearance12.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.ugdOrderItems.DisplayLayout.Override.RowAlternateAppearance = Appearance12
        Appearance13.BackColor = System.Drawing.Color.Gainsboro
        Me.ugdOrderItems.DisplayLayout.Override.RowAppearance = Appearance13
        Me.ugdOrderItems.DisplayLayout.Override.RowSelectorHeaderStyle = Infragistics.Win.UltraWinGrid.RowSelectorHeaderStyle.SeparateElement
        Me.ugdOrderItems.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.[False]
        Me.ugdOrderItems.DisplayLayout.Override.RowSizing = Infragistics.Win.UltraWinGrid.RowSizing.Sychronized
        Me.ugdOrderItems.DisplayLayout.Override.RowSizingArea = Infragistics.Win.UltraWinGrid.RowSizingArea.RowBordersOnly
        Me.ugdOrderItems.DisplayLayout.Override.SelectTypeCol = Infragistics.Win.UltraWinGrid.SelectType.None
        Me.ugdOrderItems.DisplayLayout.Override.SelectTypeRow = Infragistics.Win.UltraWinGrid.SelectType.[Single]
        Appearance14.BackColor = System.Drawing.SystemColors.ControlLight
        Me.ugdOrderItems.DisplayLayout.Override.TemplateAddRowAppearance = Appearance14
        Me.ugdOrderItems.DisplayLayout.Override.WrapHeaderText = Infragistics.Win.DefaultableBoolean.[True]
        Me.ugdOrderItems.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill
        Me.ugdOrderItems.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate
        Me.ugdOrderItems.DisplayLayout.ViewStyle = Infragistics.Win.UltraWinGrid.ViewStyle.SingleBand
        Me.ugdOrderItems.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ugdOrderItems.Location = New System.Drawing.Point(12, 50)
        Me.ugdOrderItems.Name = "ugdOrderItems"
        Me.ugdOrderItems.Size = New System.Drawing.Size(368, 487)
        Me.ugdOrderItems.TabIndex = 522
        '
        'cmdClose
        '
        Me.cmdClose.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance21.BackColor = System.Drawing.Color.Transparent
        Appearance21.BackColor2 = System.Drawing.Color.Transparent
        Appearance21.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance21.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance21.BorderColor = System.Drawing.Color.Transparent
        Appearance21.BorderColor2 = System.Drawing.Color.Maroon
        Appearance21.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance21.ForeColor = System.Drawing.Color.White
        Appearance21.Image = CType(resources.GetObject("Appearance21.Image"), Object)
        Appearance21.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance21.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance21.TextVAlignAsString = "Bottom"
        Me.cmdClose.Appearance = Appearance21
        Me.cmdClose.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdClose.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance22.BackColor = System.Drawing.Color.DarkOrange
        Appearance22.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance22.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance22.BorderColor = System.Drawing.Color.Transparent
        Appearance22.ForeColor = System.Drawing.Color.Black
        Me.cmdClose.HotTrackAppearance = Appearance22
        Me.cmdClose.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdClose.Location = New System.Drawing.Point(400, 493)
        Me.cmdClose.Name = "cmdClose"
        Me.cmdClose.Padding = New System.Drawing.Size(15, 0)
        Appearance23.BackColor = System.Drawing.Color.OrangeRed
        Appearance23.BackColor2 = System.Drawing.Color.Tomato
        Appearance23.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance23.BorderColor = System.Drawing.Color.Transparent
        Me.cmdClose.PressedAppearance = Appearance23
        Me.cmdClose.ShowFocusRect = False
        Me.cmdClose.ShowOutline = False
        Me.cmdClose.Size = New System.Drawing.Size(64, 44)
        Me.cmdClose.StyleSetName = "StatusBar"
        Me.cmdClose.TabIndex = 559
        Me.cmdClose.Tag = "Return"
        Me.cmdClose.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdClose.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdClose.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'frmOrderItems
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.Color.White
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(476, 549)
        Me.ControlBox = False
        Me.Controls.Add(Me.cmdClose)
        Me.Controls.Add(Me.ugdOrderItems)
        Me.Controls.Add(Me.cmdCardDetails)
        Me.Controls.Add(Me.lblLabel)
        Me.Name = "frmOrderItems"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        CType(Me.OrderItemsBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EZMenuDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ugdOrderItems, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents OrderItemsBindingSource As System.Windows.Forms.BindingSource
	Friend WithEvents OrderItemsTableAdapter As EZMenu.EZMenuDataSetTableAdapters.OrderItemsTableAdapter
	Friend WithEvents TableAdapterManager As EZMenu.EZMenuDataSetTableAdapters.TableAdapterManager
	Private WithEvents EZMenuDataSet As EZMenu.EZMenuDataSet
	Friend WithEvents SetIDBindingSource As System.Windows.Forms.BindingSource
	Friend WithEvents SetIDTableAdapter As EZMenu.EZMenuDataSetTableAdapters.SetIDTableAdapter
    Friend WithEvents lblLabel As System.Windows.Forms.Label
    Friend WithEvents cmdCardDetails As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ugdOrderItems As Infragistics.Win.UltraWinGrid.UltraGrid
    Friend WithEvents cmdClose As Infragistics.Win.Misc.UltraButton
End Class
