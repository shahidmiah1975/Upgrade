﻿Imports System.Configuration
Imports EZControls
Imports Infragistics.Win.Misc
Imports Comet = ActiveCID.Net_Comet_2010.clsMain
Imports Meteor = ActiveCIDctl.ActiveCID
Imports System.IO
Imports EZMenu.Core.Enums
Imports EZMenu.Core.Models
Imports EZService
Imports EZService.Repository

Public Class frmOpener

    Private intMatchFoundIn As CallerIDEnum
    Private intEnableActiveCID As Short
    Private drIncoming As DataRow
    Private tmrBookingFlash As Timer
    Private varUniqueID As Integer = -1
    Private incomingEmail As String
    Private strCustRecallString As String
    Private incomingNumber, incomingCallerName As String

    Private WithEvents tmrOrderChecker As New Timer
    Private WithEvents ActiveCIDMeteor As Meteor
    Private WithEvents ActiveCIDUSBComet As Comet

    Private _customerService As CustomerService

    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        Try
            WriteToLog("EZ-Menu is starting.")

            Cursor = Cursors.Default
            CheckForIllegalCrossThreadCalls = False

            If objDB Is Nothing Then objDB = New clsDatabase
            If objSecurity Is Nothing Then objSecurity = New clsSecurity

            'position the main form
            Size = New Size(GetAppSettingCS("FormSizeW", 1200), GetAppSettingCS("FormSizeH", 800))
            If GetAppSettingCS("CenterMainForm", 0) = 0 Then
                If IsANumber(GetAppSettingCS("FormPosTop", 0)) AndAlso IsANumber(GetAppSettingCS("FormPosLeft", 0)) Then
                    StartPosition = FormStartPosition.Manual
                    Location = New Point(GetAppSettingCS("FormPosLeft", 0), GetAppSettingCS("FormPosTop", 0))
                End If
            Else
                StartPosition = FormStartPosition.CenterScreen
            End If

            If ConfigurationManager.ConnectionStrings("EZConnectionString").ConnectionString = String.Empty Then
                strMsgBox = "SQL Server connection string is not set. Please check and correct this." + vbCrLf +
                            "EZ-Menu will now exit."
                DisplayError(strMsgBox)
                Application.Exit()
            End If

            'set some first time settings
            If objDB.EZSettingRead("StartupRunTime") = objSecurity.AES_Encrypt("14/NOV/1984 12:34:56") Then
                objDB.EZSettingWrite("StartupRunTime", objSecurity.AES_Encrypt(Format(Now, "dd/MM/yyyy HH:mm:ss")))
                objSecurity.SaveHardwareIDs()
            End If

            _customerService = New CustomerService()

            Dim s As Stream = Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream("EZMenu.EZStyle.isl")
            If s IsNot Nothing Then
                Infragistics.Win.AppStyling.StyleManager.Load(s)
            End If

            CheckDirectories()
            GetSavedRegSettings()
            SetActiveCID()
            TurnCapsOff()
            SetCuisines()
            DeletePastBookings()
            DeletePastOrders()
            StartService()
            'TestInternetConnection()

            If GetAppSettingCS("DisableCursor", True) Then Cursor.Hide() Else Cursor.Show()

            lblCallerIDBox1.Text = String.Empty
            lblCallerIDBox2.Text = String.Empty
            cmdMinimise.Visible = GetAppSettingCS("ShowMinimiseButton", 0)
            Tag = Nothing
            pnlCID.Visible = False
            lblBizname.Text = GetAppSettingCS("BizName", "").ToString.Replace("&", "&&")
            cmdBookingsToday.Visible = GotBookingsToday()
            tmrUpdateClock.Enabled = True
            If objSecurity.IsMySystem() Then Button1.Visible = True

            'start timed procedures
            If Not objSecurity.IsMySystem() Then
                EmailErrorLog()
            End If

            tmrOrderChecker = New Timer
            With tmrOrderChecker
                .Interval = 10000
                .Enabled = True
            End With

        Catch ex As Exception
            frmSplash.Hide()
            Application.DoEvents()
            DisplayError(ex)

        End Try

    End Sub

    Private Sub frmOpener_Shown(sender As Object, e As EventArgs) Handles Me.Shown

        StartOnlineCheck()

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click, Button2.Click

        'If GetAppSettingCS("CTIType", "Meteor") = "Comet" Then
        '    ActiveCIDUSBComet.ReplicateIncomingCall()
        'Else
        '    ActiveCIDMeteor.ReplicateInComingCall()
        'End If

        'Exit Sub

        'OrderType =OrderTypeEnum.Delivery

        'If sender.name = "Button2" Then
        '    strIncomingNumber = InputBox("What is the phone number?", "Input number", "07886519251")
        'Else
        '    strIncomingNumber = InputBox("Enter phone number", "Incoming Test", "")
        'End If

        incomingNumber = "07808051213"
        QueryIncomingNumber(incomingNumber)

    End Sub

    Public Sub QueryIncomingNumber(ByRef NumToSearch As String)
        'returns the name and address of the customer with the number provided by CTI Meteor,
        'NumToSearch and displays it as an alert for user to click on

        If NumToSearch = String.Empty Then Exit Sub

        WriteToLog("QueryIncomingNumber: Start of process")

        incomingCallerName = String.Empty
        incomingEmail = String.Empty

        Application.DoEvents()

        Try
            PhoneQuery = FormatPhone(NumToSearch)

            Dim cCustomer As CustomerModel = _customerService.GetCustomerByPhone(PhoneQuery)

            If cCustomer IsNot Nothing Then
                WriteToLog("QueryIncomingNumber: start IncomingAlert(CallerIDEnum.MatchInCustomer)")
                IncomingAlert(cCustomer, CallerIDEnum.MatchInCustomer)
            Else
                'try collection list
                cCustomer = _customerService.GetCollector(PhoneQuery)
                If cCustomer IsNot Nothing Then    'match found in collector table
                    incomingCallerName = cCustomer.Name.ToString
                    incomingEmail = cCustomer.Email.ToString
                Else
                    incomingCallerName = String.Empty
                    incomingEmail = String.Empty
                End If
                WriteToLog("QueryIncomingNumber: start IncomingAlert(CallerIDEnum.MatchInCollector)")
                IncomingAlert(cCustomer, CallerIDEnum.MatchInCollector)
            End If

            CustomerRecall(PhoneQuery)

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Public Sub IncomingAlert(cCustomer As CustomerModel, ByRef stepVal As CallerIDEnum)
        'put the info from the DB to the alert box

        Dim tempAddress As String = String.Empty
        Dim blnShowAlert As Boolean = True

        Try

            WriteToLog("IncomingAlert: Start of process")
            WriteToLog("IncomingAlert: strIncomingNumber = " & incomingNumber & ",  stepVal = " & stepVal)

            msg = String.Empty
            cmdCIDAccept.Enabled = True
            lblCallerIDBox0.Text = "INCOMING CALL"
            lblCallerIDBox1.Text = String.Empty
            lblCallerIDBox2.Text = String.Empty
            lblCallerIDBox2.Tag = incomingNumber
            cmdCIDRecall.Visible = False

            Select Case stepVal

                Case CallerIDEnum.MatchInCustomer   'match found in customer DB
                    incomingCallerName = cCustomer.Name
                    msg = cCustomer.Address1.Trim
                    If msg <> "" Then tempAddress = msg & vbCrLf
                    msg = cCustomer.Address2.ToString.Trim
                    If msg <> "" Then tempAddress &= msg & vbCrLf
                    msg = cCustomer.Address3.ToString.Trim
                    If msg <> "" Then tempAddress &= msg & vbCrLf
                    msg = cCustomer.Postcode.ToString.Trim
                    If msg <> "" Then tempAddress &= msg & vbCrLf
                    lblCallerIDBox2.Text = tempAddress & incomingNumber
                    CustID = CShort(cCustomer.CustomerId)

                Case CallerIDEnum.MatchInCollector      'match in collector DB or is missing
                    lblCallerIDBox2.Text = incomingNumber

                Case CallerIDEnum.NoCallerID        'no CID available
                    cmdCIDAccept.Enabled = False
                    lblCallerIDBox2.Text = "CALLER ID UNAVAILABLE"
                    blnShowAlert = GetAppSettingCS("HideCIDWhenNoCID", True)

                Case Else
                    'jump out of proc
                    Exit Sub

            End Select

            lblCallerIDBox1.Text = incomingCallerName

            intMatchFoundIn = stepVal
            lblCallerIDBox1.Text = Replace(lblCallerIDBox1.Text, "&", "&&")
            ''SetPhonePicture()

            WriteToLog("IncomingAlert: blnShowAlert = " & blnShowAlert)

            'pnlCID.Location = New Point(9, 473)
            pnlCID.Visible = blnShowAlert
            tmrCallPhone.Interval = 600
            tmrCallPhone.Enabled = True

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub CustomerRecall(NumQuery)

        Try
            Dim totalPrice As Decimal = 0

            strCustRecallString = String.Empty
            cmdCIDRecall.Visible = False

            Dim rOrder As Object = _customerService.GetRecalledOrder(PhoneQuery)

            If rOrder IsNot Nothing Then
                cmdCIDRecall.Visible = True
                strCustRecallString = "Order details:" & vbCrLf & vbCrLf
                For Each drow As Object In rOrder
                    strCustRecallString &= drow.Qty & "  " & drow.DishName & vbCrLf
                    totalPrice += Val(drow.UnitPrice & "")
                Next
                strCustRecallString &= vbCrLf & "Total: " & fixCur(totalPrice)
            Else
                strCustRecallString = "No info available!"
            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub cmdTables_Click(sender As Object, e As EventArgs) Handles cmdTables.Click

        If objTables Is Nothing Then objTables = New frmTables2
        objTables.Display(Me)

    End Sub

    Private Sub cmdQuit_Click(sender As Object, e As EventArgs) Handles cmdQuit.Click

        Try
            If MainOrSubSystem() <> "MULTISUB" Then  'this is the main system
                strMsgBox = "Do you wish to clear todays orders before exit?"
                intMsgBoxResult = EZMsgBox.Show(strMsgBox, MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question)
                If intMsgBoxResult <> vbCancel Then
                    If GetAppSettingCS("SaveDishHistory", True) Then clsDish.SaveDishHistory()
                    If intMsgBoxResult = MsgBoxResult.Yes Then
                        objDB.CleanupDB()
                        If GetAppSettingCS("OLDBBackup", True) Then
                            Using objDBBackup As New frmDBBackupRestore
                                objDBBackup.PerformDBBackup()
                            End Using
                        End If
                        WriteToLog("EZ-Menu is shutting down.")
                        WriteToLog("- - - - -  - - - - - - - - -")
                        Application.Exit()
                    Else
                        WriteToLog("EZ-Menu is shutting down.")
                        WriteToLog("- - - - -  - - - - - - - - -")
                        Application.Exit()
                    End If
                End If
            Else    'this is a subsystem
                strMsgBox = "Do you wish to exit?"
                intMsgBoxResult = EZMsgBox.Show(strMsgBox, MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                If intMsgBoxResult = MsgBoxResult.Yes Then
                    WriteToLog("EZ-Menu is shutting down.")
                    WriteToLog("- - - - -  - - - - - - - - -")
                    Application.Exit()
                End If
            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub CIDHandler(sender As Object, e As EventArgs) Handles cmdCIDAccept.Click, cmdCIDHide.Click, cmdCIDLog.Click, cmdCIDRecall.Click

        tmrCallPhone.Enabled = False
        pnlCID.Visible = False
        imgMobile.Visible = True

        Select Case DirectCast(sender, UltraButton).Name

            Case cmdCIDAccept.Name

                If lblCallerIDBox1.Text = String.Empty And lblCallerIDBox2.Text = String.Empty Then Exit Sub

                If (intMatchFoundIn = CallerIDEnum.MatchInCollector And incomingCallerName <> "") Then   'collector & their name is there
                    objDelivColn = New frmDelivColn(OrderTypeEnum.Collection, incomingNumber, incomingCallerName, incomingEmail, True)
                Else
                    objDelivColn = New frmDelivColn(OrderTypeEnum.Delivery, incomingNumber, Nothing, Nothing, True)
                End If

                With objDelivColn
                    .ShowDialog(Me)
                    .HighlightOff()
                    Try
                        If .txtAddress1.Text.Length = 0 Then .txtPostcode.Focus() Else .cmdNextScreen.Focus()
                    Catch ex As Exception
                    End Try
                End With

            Case cmdCIDHide.Name
                pnlCID.Hide()

            Case cmdCIDLog.Name
                frmCallerIDLog.Show()

            Case cmdCIDRecall.Name
                MsgBox(strCustRecallString, MsgBoxStyle.OkOnly, "Order details")

            Case Else

        End Select

    End Sub

    Private Sub DeliveryPickupHandler(sender As Object, e As EventArgs) Handles cmdDelivery.Click, cmdPickup.Click

        ShowHourGlass()

        StartNewOrder()

        objOrderEntry = Nothing
        objPayment = Nothing

        If DirectCast(sender, UltraButton) Is cmdDelivery Then
            objDelivColn = New frmDelivColn(OrderTypeEnum.Delivery, Nothing, Nothing, Nothing, False)
        Else
            objDelivColn = New frmDelivColn(OrderTypeEnum.Collection, Nothing, Nothing, Nothing, False)
        End If
        objDelivColn.ShowDialog(Me)

    End Sub

    Private Sub cmdShowCID_Click(sender As Object, e As EventArgs) Handles cmdShowCID.Click

        Try
            'pnlCID.Location = New Point(9, 473)
            pnlCID.Visible = Not pnlCID.Visible
            If pnlCID.Visible = True Then pnlCID.BringToFront()

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, "Error in cmdShowCID_Click:")
            DisplayError(ex)
        End Try

    End Sub

    Private Sub cmdOrders_Click(sender As Object, e As EventArgs) Handles cmdOrders.Click

        Using objOrders As New frmOrders
            objOrders.ShowDialog(Me)
        End Using

    End Sub

    Private Sub cmdOnline_Click(sender As Object, e As EventArgs) Handles cmdOnline.Click

        If OnlineOrderingAvailable() Then
            If objOnlineOrders Is Nothing Then
                objOnlineOrders = New frmOnlineOrders(Me)
            End If
            objOnlineOrders.Display()
        Else
            strMsgBox = "You do not have online ordering activated on this system."
            Alert(strMsgBox)
        End If

    End Sub

    Private Sub StartOnlineCheck()

        If OnlineOrderingAvailable() Then
            Dim onlineServiceManager As New OnlineOrderService()
            Dim orderRepo As New OrderRepository()
            'Dim onlineIds As List(Of OLOrderModel) = onlineServiceManager.GetOrdersByDate("2025-02-13")
            Dim onlineIds As List(Of OLOrderModel) = onlineServiceManager.GetOrdersByDate(Now.ToString("yyyy-MM-dd"))
            Dim processedIds As List(Of Short) = orderRepo.GetOnlineOrderIds()

            If onlineIds.Any(Function(item) Not processedIds.Contains(item.OrderID)) Then
                If onlineIds IsNot Nothing AndAlso onlineIds.Count > 0 Then
                    If ActiveForm Is Nothing OrElse TypeOf ActiveForm Is frmOpener Then
                        If objOnlineOrders Is Nothing Then
                            objOnlineOrders = New frmOnlineOrders(Me)
                        End If
                    End If
                End If
            End If

            orderRepo = Nothing
            onlineServiceManager = Nothing

        End If

    End Sub

    Private Sub cmdManager_Click(sender As Object, e As EventArgs) Handles cmdManager.Click

        Using objForm As New frmManager
            objForm.ShowDialog(Me)
        End Using

    End Sub

    <DebuggerStepThrough()>
    Private Sub tmrUpdateClock_Tick(sender As Object, e As EventArgs) Handles tmrUpdateClock.Tick
        SetStatusText()
    End Sub

    Private Sub cmdBookings_Click(sender As Object, e As EventArgs) Handles cmdBookings.Click

        Try
            Try
                If tmrBookingFlash IsNot Nothing Then
                    tmrBookingFlash.Enabled = False
                End If
            Catch ex As Exception
            Finally
                cmdBookingsToday.Visible = False
            End Try

            Using objBookings As New frmBookings
                objBookings.ShowDialog()
            End Using

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Public Function GotBookingsToday() As Boolean

        Try
            Dim bookings As List(Of BookingModel) = _customerService.GetBookingsByDate(GetDateNow())

            If bookings IsNot Nothing AndAlso bookings.Count > 0 Then
                cmdBookingsToday.Text = drcDatarowCollection.Count & " reservation" & IIf(drcDatarowCollection.Count > 1, "s", "") & vbCrLf & "today"
                tmrBookingFlash = New Timer
                AddHandler tmrBookingFlash.Tick, AddressOf tmrBookingFlashHandler
                tmrBookingFlash.Interval = 1000
                tmrBookingFlash.Enabled = True
                Return True
            Else
                cmdBookingsToday.Text = "No reservations"
            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

        Return False

    End Function

    Private Sub cmdBookingsToday_Click(sender As Object, e As EventArgs) Handles cmdBookingsToday.Click

        If tmrBookingFlash.Enabled = True Then
            cmdBookingsToday.Show()
        Else
            cmdBookingsToday.Hide()
        End If

        tmrBookingFlash.Enabled = False

    End Sub

    Private Sub DeletePastBookings()

        Try
            _customerService.DeletePastBookings()

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub DeletePastOrders()

        Try
            clsOrder.DeletePastOrders()

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Public Sub SetActiveCID()

        WriteToLog("Start of SetActiveCID")
        Try

            'start ActiveCID
            incomingNumber = String.Empty
            incomingCallerName = String.Empty
            incomingEmail = String.Empty
            lblCallerIDBox1.Text = String.Empty
            lblCallerIDBox2.Text = String.Empty
            lblCallerIDBox2.Tag = "@"   'any char here will do!
            intEnableActiveCID = GetAppSettingCS("EnableActiveCID", 0)
            cmdShowCID.Enabled = intEnableActiveCID <> 0
            If intEnableActiveCID <> 0 Then
                Try
                    Dim CTI_Port As Short = CInt(GetAppSettingCS("ActiveCIDPort", 1))
                    If GetAppSettingCS("CTIType", "Meteor") = "Comet" Then
                        If ActiveCIDUSBComet Is Nothing Then ActiveCIDUSBComet = New Comet
                        ActiveCIDUSBComet.Port = "COM" & CTI_Port.ToString.Trim
                        ActiveCIDUSBComet.Initialise()
                        WriteToLog("USB Comet set to port " & CTI_Port.ToString.Trim)
                    Else
                        If ActiveCIDMeteor Is Nothing Then ActiveCIDMeteor = New Meteor
                        ActiveCIDMeteor.Port = CTI_Port       'set the port
                        ActiveCIDMeteor.Initialise()          'initialise ActiveCID
                        WriteToLog("Meteor set to port " & CTI_Port.ToString.Trim)
                    End If

                Catch ex As Exception
                    DisplayError(ex)
                End Try

            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

        WriteToLog("End of SetActiveCID")

    End Sub

    Private Sub ActiveCID_IncomingCall() Handles ActiveCIDMeteor.IncomingCall
        'ActiveCIDMeteor has detected an incoming call

        Dim strActiveDateTime As String = Date.Now.ToLongTimeString
        strActiveDateTime = Replace(Replace(strActiveDateTime, "PM", ""), "AM", "")
        strActiveDateTime = strActiveDateTime.Trim

        Try

            Select Case ActiveCIDMeteor.CurrentCallStatus

                Case ActiveCIDctl.CallStatus.CidCallWithCID   ' phone ringing, caller CID info. available
                    varUniqueID = CInt(Date.Now.TimeOfDay.TotalSeconds)

                    Select Case ActiveCIDMeteor.ReasonNoNumber

                        Case ActiveCIDctl.CallCodes.CidUnavailable, ActiveCIDctl.CallCodes.CidWithheld
                            incomingNumber = String.Empty
                            incomingCallerName = String.Empty
                            objDB.SaveCallLog(varUniqueID, strActiveDateTime, String.Empty)
                            IncomingAlert(Nothing, 4)

                        Case Else   'number is present
                            incomingNumber = FormatPhone(ActiveCIDMeteor.PhoneNumber)
                            incomingCallerName = String.Empty
                            'display alert with this number
                            QueryIncomingNumber(incomingNumber)
                            objDB.SaveCallLog(varUniqueID, strActiveDateTime, incomingNumber)
                    End Select

                Case ActiveCIDctl.CallStatus.CidCallWithNoCID      'incoming call but CID not available
                    varUniqueID = CInt(Date.Now.TimeOfDay.TotalSeconds)
                    incomingNumber = String.Empty
                    incomingCallerName = String.Empty
                    IncomingAlert(Nothing, 3)

                Case ActiveCIDctl.CallStatus.CidCallAnswered       'phone has been answered
                    'disable flashing timer
                    tmrCallPhone.Enabled = False
                    imgMobile.Visible = True

                Case ActiveCIDctl.CallStatus.CidCallComplete       'end of call
                    'disable flashing timer
                    tmrCallPhone.Enabled = False
                    'cmdShowCID.Text = "Caller ID"
                    If ActiveCIDMeteor.RecordStatus = ActiveCIDctl.RecStatus.vrRecStatusRecording Then ActiveCIDMeteor.RecordEnd()
                    varUniqueID = -1
                    'delay for a moment....
                    Application.DoEvents()
                    Sleep(500)
                    '... then hide alert box
                    pnlCID.Visible = False

            End Select

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub ActiveCIDUSBComet_IncomingCall() Handles ActiveCIDUSBComet.IncomingCall
        'ActiveCIDUSBComet has detected an incoming call

        Dim strActiveDateTime As String = Replace(Replace(Date.Now.ToLongTimeString, "PM", ""), "AM", "").Trim

        Try
            WriteToLog("ActiveCID: Start of Incoming call proc")

            varUniqueID = CInt(Date.Now.TimeOfDay.TotalSeconds)

            Select Case ActiveCIDUSBComet.CurrentCallStatus
                Case Comet.CallStatus.CidCallWithCID  ' phone ringing, caller CID info. available

                    Select Case ActiveCIDUSBComet.ReasonNoNumber
                        Case Comet.CallCodes.CidUnavailable, Comet.CallCodes.CidWithheld
                            WriteToLog("ActiveCID: Number unavailable or withheld")
                            incomingNumber = String.Empty
                            incomingCallerName = String.Empty
                            objDB.SaveCallLog(varUniqueID, strActiveDateTime, String.Empty)
                            IncomingAlert(Nothing, 4)

                        Case Else   'number is present
                            incomingNumber = FormatPhone(ActiveCIDUSBComet.PhoneNumber)
                            WriteToLog("ActiveCID: Number is present: " & incomingNumber)
                            incomingCallerName = String.Empty
                            'display alert with this number
                            QueryIncomingNumber(incomingNumber)
                            objDB.SaveCallLog(varUniqueID, strActiveDateTime, incomingNumber)
                    End Select

                Case Comet.CallStatus.CidCallWithNoCID      'incoming call but CID not available
                    WriteToLog("ActiveCID: Call with no CID")
                    incomingNumber = String.Empty
                    incomingCallerName = String.Empty
                    IncomingAlert(Nothing, 3)

            End Select

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub ActiveCIDUSBComet_OnError(nError As Comet.SystemErrors, sDescription As String) Handles ActiveCIDUSBComet.OnError

        Try
            WriteToLog("Error in ActiveCIDUSBComet: " & sDescription)

        Catch ex As Exception
            DisplayError(ex, "Error in Sub ActiveCIDUSBComet_OnError: could not log error.")
        End Try

    End Sub

    Private Sub ActiveCIDMeteor_OnError(ByRef nError As ActiveCIDctl.SystemErrors, ByRef sDescription As String) Handles ActiveCIDMeteor.OnError

        Try
            WriteToLog("Error in ActiveCIDMeteor: " & sDescription)

        Catch ex As Exception
            DisplayError(ex, "Error in Sub ActiveCIDMeteor_OnError: could not log error.")
        End Try

    End Sub

    Public Sub ActiveCIDProcess(intProc As Short)

        Try
            If intProc = 1 Then
                'close com port
                If GetAppSettingCS("CTIType", "Meteor") = "Comet" Then
                    WriteToLog("ActiveCID: Calling Comet Terminate method")
                    ActiveCIDUSBComet.Terminate()
                Else
                    WriteToLog("ActiveCID: Calling Meteor Terminate method")
                    ActiveCIDMeteor.Terminate()
                End If

            ElseIf intProc = 2 Then
                WriteToLog("ActiveCID: Resetting ActiveCID")

                're-initialise ActiveCID
                ActiveCIDProcess(1) 'close port first
                SetActiveCID()

                strMsgBox = "ActiveCID has been reset"
                Alert(strMsgBox)

                WriteToLog("ActiveCID has been reset")

            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    <DebuggerStepThrough()>
    Private Sub tmrCallPhone_Tick(sender As Object, e As EventArgs) Handles tmrCallPhone.Tick
        imgMobile.Visible = Not imgMobile.Visible
    End Sub

    <DebuggerStepThrough()>
    Private Sub tmrBookingFlashHandler()
        cmdBookingsToday.Visible = Not cmdBookingsToday.Visible
    End Sub

    Private Sub CheckDirectories()

        'set data directory
        tempStr = GetAppSettingCS("EZDataDirectory", String.Empty)
        If tempStr = String.Empty Or Directory.Exists(tempStr) = False Then
            tempStr = Application.StartupPath
        End If

        AppDomain.CurrentDomain.SetData("DataDirectory", tempStr)
        SaveAppSetting("EZDataDirectory", tempStr)

        'set registry entry for filewatcher path
        tempStr = GetAppSettingCS("EZPDAPath", String.Empty)
        If tempStr = String.Empty Then
            SaveAppSetting("EZPDAPath", Application.StartupPath & "\ezpda\")
            tempStr = Application.StartupPath & "\ezpda\"
        End If

        Try
            If Directory.Exists(tempStr) = False Then
                Directory.CreateDirectory(tempStr)
            End If
        Catch ex As Exception
            DisplayError(ex.Message, "Error creating EZPDA path:")
        End Try

        'backup folder
        Try
            If Directory.Exists(Application.StartupPath & "\backup") = False Then
                Directory.CreateDirectory(Application.StartupPath & "\backup")
            End If
        Catch ex As Exception
            DisplayError(ex.Message, "Error creating backup path:")
        End Try

        'call logs directory
        Try
            If Directory.Exists(Application.StartupPath & "\call_logs") = False Then
                Directory.CreateDirectory(Application.StartupPath & "\call_logs")
            End If
        Catch ex As Exception
            DisplayError(ex.Message, "Error creating call logs path:")
        End Try

    End Sub

    <DebuggerStepThrough()>
    Public Sub SetStatusText()
        Try
            lblDateTime.Text = Format(Now, "dddd d MMMM yyyy    h:mm")
        Catch ex As Exception
        End Try
    End Sub

    Private Sub imgMobile_Click(sender As Object, e As EventArgs) Handles imgMobile.Click

        Try
            imgMobile.Tag += 1
            If imgMobile.Tag >= 3 Then
                imgMobile.Tag = 0
                incomingNumber = EZFullKeyboard.Show()
                If incomingNumber <> EZKBEscape Then
                    QueryIncomingNumber(incomingNumber)
                End If
            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub cmdShutdown_Click(sender As Object, e As EventArgs)

        Try
            Dim blnDoShutdown As Boolean = False
            If MainOrSubSystem() <> "MULTISUB" Then  'this is the main system
                strMsgBox = "Do you wish to clear todays orders before shutting down?"
                intMsgBoxResult = EZMsgBox.Show(strMsgBox, MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question)
                If intMsgBoxResult <> vbCancel Then
                    If intMsgBoxResult = MsgBoxResult.Yes Then objDB.CleanupDB()
                    blnDoShutdown = True
                End If
            Else    'this is a subsystem
                strMsgBox = "Do you wish to shut down?"
                intMsgBoxResult = EZMsgBox.Show(strMsgBox, MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                If intMsgBoxResult = MsgBoxResult.Yes Then
                    blnDoShutdown = True
                End If
            End If

            If blnDoShutdown = True Then
                WriteToLog("Call made to system shutdown")
                Using objDBBackup As New frmDBBackupRestore
                    objDBBackup.PerformDBBackup()
                End Using
                Application.DoEvents()
                Dim PSI As New ProcessStartInfo("shutdown.exe") With {
                    .WindowStyle = ProcessWindowStyle.Hidden,
                    .Arguments = "-s -t 00"}
                Process.Start(PSI)
            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub cmdMinimise_Click(sender As Object, e As EventArgs) Handles cmdMinimise.Click
        WindowState = FormWindowState.Minimized
    End Sub

    Private Sub SetCuisines()

        Dim multiCuisine As Short = 0
        Dim cuisineList As New List(Of String)
        Dim dishRepo As New DishRepository()

        Try
            Dim cuisines As List(Of CuisineModel) = dishRepo.GetCuisines()

            If cuisines IsNot Nothing AndAlso cuisines.Count > 0 Then
                multiCuisine = cuisines.Count
                For Each cuisine In cuisines
                    cuisineList.Add(cuisine.Name)
                Next

                If GetAppSettingCS("MultiCuisinesDefault", "") = "" Then
                    SaveAppSetting("MultiCuisinesDefault", cuisineList(0))
                End If
            End If

            SaveAppSetting("MultiCuisines", multiCuisine > 1)

            ' Set current cuisine
            Dim currentCuisine = dishRepo.GetCuisineByName(GetAppSettingCS("MultiCuisinesDefault", "Indian"))

            If currentCuisine IsNot Nothing Then
                intCurrentCuisine = currentCuisine.ID
            Else
                intCurrentCuisine = 1
            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Function OnlineOrderingAvailable() As Boolean

        Return GetAppSettingCS("OLOrderingAvailable", 0) <> 0

    End Function


    'Declare the variables
    Dim drag As Boolean
    Dim mousex As Integer
    Dim mousey As Integer

    Private Sub Form1_MouseDown(sender As Object, e As MouseEventArgs) Handles lblHeader.MouseDown
        drag = True 'Sets the variable drag to true.
        mousex = Cursor.Position.X - Left 'Sets variable mousex
        mousey = Cursor.Position.Y - Top 'Sets variable mousey
    End Sub

    Private Sub Form1_MouseMove(sender As Object, e As MouseEventArgs) Handles lblHeader.MouseMove
        'If drag is set to true then move the form accordingly.
        If drag Then
            Top = Cursor.Position.Y - mousey
            Left = Cursor.Position.X - mousex
        End If
    End Sub

    Private Sub Form1_MouseUp(sender As Object, e As MouseEventArgs) Handles lblHeader.MouseUp
        drag = False 'Sets drag to false, so the form does not move according to the code in MouseMove
        SaveFormPositions()
    End Sub

    Private Sub lblHeader_DoubleClick(sender As Object, e As EventArgs) Handles lblHeader.DoubleClick

        If WindowState = FormWindowState.Maximized Then
            WindowState = FormWindowState.Normal
        Else
            Dim workingArea = Screen.FromHandle(Handle).WorkingArea
            MaximizedBounds = New Rectangle(0, 0, workingArea.Width, workingArea.Height)
            WindowState = FormWindowState.Maximized
        End If

        SaveFormPositions()

    End Sub

    Private Sub frmOpener_ResizeEnd(sender As Object, e As EventArgs) Handles Me.ResizeEnd
        SaveFormPositions()
        Dim workingArea = Screen.FromHandle(Handle).WorkingArea
        Me.Left = (workingArea.Width - Me.Width) / 2
        Me.Top = (workingArea.Height - Me.Height) / 2
    End Sub

    Private Sub SaveFormPositions()
        SaveAppSetting("FormPosTop", Top)
        SaveAppSetting("FormPosLeft", Left)
        SaveAppSetting("FormSizeH", Height)
        SaveAppSetting("FormSizeW", Width)
    End Sub

End Class