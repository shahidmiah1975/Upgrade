﻿Imports System.Configuration
Imports Infragistics.Win.UltraWinGrid
Imports EZControls
Imports EZMenu.Core.Enums
Imports EZService.Repository
Imports EZMenu.Core

Public Class frmCustomers

    Public ugrActiveRow As UltraGridRow

    Private CellText, MyPhone, PhoneToAdd As String
    Private objDelivColn As frmDelivColn
    Private CustomerRepo As CustomerRepository

    Private Sub frmCustomers_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Try
            MyBase.HeaderText("Customers Management Screen")
            'MyBase.HeaderText("Customers")
            Size = Owner.Size
            Location = Owner.Location

            CustomerTableAdapter.Connection.ConnectionString = ConfigurationManager.ConnectionStrings(EZConstants.EZDatabaseConnectionString).ConnectionString
            CustomerTableAdapter.Fill(CustomerDataSet.Customer)
            lblNumRecs.Text = "Number of records: " & Format(CustomerBindingSource.Count, "##,##0")

            CustomerRepo = New CustomerRepository()

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub frmCustomers_Activated(sender As Object, e As EventArgs) Handles Me.Activated

        Try
            cmbSearchType.Text = cmbSearchType.Items.Item(0)
        Catch ex As Exception

        End Try

    End Sub

    Private Sub SearchCustomer(sender As Object, e As EventArgs)

        If txtSearchString.Text = String.Empty Then Exit Sub

        tempStr = Chr(34) & "%" & txtSearchString.Text & "%" & Chr(34)

        If cmbSearchType.SelectedIndex = 0 Then
            SQLQuery = "SELECT CustomerID, Name, Address, Phone FROM Customer WHERE Name LIKE " & tempStr & " ORDER BY Name"

        ElseIf cmbSearchType.SelectedIndex = 1 Then
            SQLQuery = "SELECT CustomerID, Name, Address, Phone FROM Customer WHERE Address LIKE " & tempStr & " ORDER BY Address"

        ElseIf cmbSearchType.SelectedIndex = 2 Then
            'search phone number in Customer and Alternative Phone tables
            SQLQuery = "SELECT * FROM Customer WHERE Phone='" & txtSearchString.Text & "' " &
                        "UNION ALL " &
                        "SELECT * FROM Customer " &
                        "WHERE (((Customer.Phone)=(SELECT TOP 1 Phone FROM AlternativePhone WHERE AlternativePhone.[AltPhone]='" & txtSearchString.Text & "')));"

        Else
            SQLQuery = "SELECT CustomerID, Name, Address, Phone FROM Customer"

        End If

        Dim dtCust As DataTable = objDB.GetDataTable(SQLQuery)

        ugdCustomer.DataSource = dtCust
        lblNumRecs.Text = "Number of records: " & dtCust.Rows.Count

    End Sub

    Private Sub cmdClose_Click(sender As Object, e As EventArgs) Handles cmdClose.Click, cmdBack.Click

        Try
            CustomerTableAdapter.Update(CustomerDataSet)
        Catch ex As Exception
        End Try

        Close()

    End Sub

    Private Sub ugdCustomer_ClickCell(sender As Object, e As ClickCellEventArgs) Handles ugdCustomer.ClickCell

        'call sub proc
        RowColChanged()

    End Sub

    Private Sub cmdAddAltPhone_Click(sender As Object, e As EventArgs) Handles cmdAddAltPhone.Click
        'add new alt phone to the DB

        If ugdCustomer.ActiveRow IsNot Nothing Then

            PhoneToAdd = txtAltPhone.Text
            If PhoneToAdd = "" Then Exit Sub

            MyPhone = ugdCustomer.ActiveRow.Cells("Phone").Text
            If PhoneToAdd = MyPhone Then
                txtAltPhone.Clear()
                Exit Sub
            End If

            'only five other numbers are allowed per number
            If lstAltPhone.Items.Count >= 5 Then
                strMsgBox = "Only five alternative numbers are allowed for each number. Remove a number from the list to add this one."
                Alert(strMsgBox)
                Exit Sub
            End If

            'check if this is already in the listbox
            If lstAltPhone.Items.Count > 0 Then
                For iCnt = 0 To (lstAltPhone.Items.Count - 1)
                    If PhoneToAdd = lstAltPhone.Items.Item(iCnt) Then
                        Alert("That is already selected.")
                        Exit Sub
                    End If
                Next
            End If

            'check that this number is not already in use
            Dim matchfound As Integer = CustomerBindingSource.Find("Phone", PhoneToAdd)

            'no match has been found
            If matchfound = -1 Then

                'search alternative phones list
                SQLQuery = $"SELECT * 
                             FROM AlternativePhone 
                             WHERE AltPhone = '{ PhoneToAdd }'"

                Dim drcPhone As DataRowCollection = objDB.GetDataRows(SQLQuery)

                If drcPhone.Count > 0 Then
                    strMsgBox = "That number is already in use."
                    Alert(strMsgBox, MessageBoxIcon.Asterisk)
                    Exit Sub
                End If

            Else
                'match found, so number in use
                strMsgBox = "That number is already in use."
                Alert(strMsgBox, MessageBoxIcon.Asterisk)
                Exit Sub
            End If

            'not in use, so add it to the listbox and DB
            clsCustomer.InsertAltPhone(MyPhone, PhoneToAdd)

            lstAltPhone.Items.Add(PhoneToAdd)
            txtAltPhone.Clear()

        Else
            strMsgBox = "Select a customer first then add the phone number"
            Alert(strMsgBox, MessageBoxIcon.Information)
        End If

    End Sub

    Private Sub cmdDelete_Click(sender As Object, e As EventArgs) Handles cmdDeleteCustomer.Click

        Try
            If ugdCustomer.ActiveRow IsNot Nothing AndAlso ugdCustomer.Selected.Rows.Count = 0 Then
                ugdCustomer.ActiveRow.Selected = True
            End If

            If ugdCustomer.Selected.Rows.Count > 0 Then
                strMsgBox = "Customer information and ALL orders associated with this customer will be PERMANENTLY deleted from the database. Are you sure?"
                intMsgBoxResult = EZMsgBox.Show(strMsgBox, MessageBoxButtons.YesNo, MessageBoxIcon.Warning)
                If intMsgBoxResult = MsgBoxResult.Yes Then
                    For Each mySelRow As UltraGridRow In ugdCustomer.Selected.Rows
                        CustomerRepo.DeleteCustomer(ugdCustomer.Rows(mySelRow.Index).Cells("CustomerID").Value)
                    Next
                    objDB.ReseedTable("Customer", "Max")
                    CustomerTableAdapter.Update(CustomerDataSet)
                    CustomerTableAdapter.Fill(CustomerDataSet.Customer)
                End If

            Else
                strMsgBox = "No customer selected for deletion. Select a customer from the grid then try again."
                Alert(strMsgBox, MessageBoxIcon.Error)
            End If

        Catch exc As Exception
            DisplayError(exc)
        End Try

    End Sub

    Private Sub cmdShowAll_Click(sender As Object, e As EventArgs) Handles cmdShowAll.Click

        CustomerBindingSource.RemoveFilter()
        ugdCustomer.DataSource = CustomerBindingSource
        lblNumRecs.Text = "Number of records: " & Format(CustomerBindingSource.Count, "##,##0")

    End Sub

    Private Sub cmdDeleteAltPhone_Click(sender As Object, e As EventArgs) Handles cmdDelAltPhone.Click

        If lstAltPhone.SelectedItems.Count > 0 Then
            SQLQuery = "DELETE FROM AlternativePhone WHERE AltPhone='" & lstAltPhone.SelectedItem.ToString & "'"
            objDB.ExeNonQuery(SQLQuery)
            lstAltPhone.Items.Remove(lstAltPhone.SelectedItem)
        End If

    End Sub

    Private Sub ugdCustomer_KeyPress(sender As Object, e As KeyPressEventArgs) Handles ugdCustomer.KeyPress

        If ugdCustomer.ActiveCell IsNot Nothing Then
            If ugdCustomer.ActiveCell.Column.Key = "Phone" Then
                Select Case e.KeyChar
                    Case ChrW(Keys.D0) To ChrW(Keys.D9)
                        e.Handled = False
                    Case Else
                        e.Handled = True
                End Select
            End If
        End If

    End Sub

    Private Sub RowColChanged()

        CellText = ugdCustomer.ActiveRow.Cells("Phone").Text
        MyPhone = CellText
        If MyPhone = "" Then Exit Sub

        lblAltPhone.Text = "Other numbers for " & vbCrLf & MyPhone
        SQLQuery = $"SELECT * FROM AlternativePhone WHERE Phone = '{MyPhone}'"
        Dim dtable As DataTable = objDB.GetDataTable(SQLQuery)

        txtAltPhone.Clear()
        lstAltPhone.Items.Clear()

        If dtable.Rows.Count > 0 Then
            For Each drow As DataRow In dtable.Rows
                lstAltPhone.Items.Add(drow.Item("AltPhone"))
            Next
        End If

    End Sub

    Private Sub txtAltPhone_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtAltPhone.KeyPress

        Select Case e.KeyChar
            Case ChrW(Keys.D0) To ChrW(Keys.D9), ChrW(Keys.Back)
                e.Handled = False
            Case Else
                e.Handled = True
        End Select

    End Sub

    Private Sub ugdCustomer_BeforeExitEditMode(sender As Object, e As BeforeExitEditModeEventArgs) Handles ugdCustomer.BeforeExitEditMode

        If ugdCustomer.ActiveCell Is Nothing Then Return

        Dim curText As String = ugdCustomer.ActiveCell.Text

        Select Case ugdCustomer.ActiveCell.Column.Key

            Case "Name"
                If curText = "" Then ugdCustomer.ActiveCell.Value = "The Occupier"

            Case "Address1"
                If curText = "" Then ugdCustomer.ActiveCell.Value = "<address missing>"

            Case "Phone"
                If curText = "" Then
                    strMsgBox = "You must enter a phone number for this customer or delete the customer"
                    Alert(strMsgBox, MessageBoxIcon.Asterisk)
                    e.Cancel = True
                End If

            Case Else
                'do nothing

        End Select

    End Sub

    Private Sub cmdAddCust_Click(sender As Object, e As EventArgs) Handles cmdAddCustomer.Click

        Alert("Not coded yet!")

    End Sub

    Private Sub cmdSearch_Click(sender As Object, e As EventArgs) Handles cmdSearch.Click

        Try
            If cmbSearchType.Text = "Name" Then
                CustomerBindingSource.Filter = "Name Like '%" & txtSearchString.Text.Trim & "%'"
                ugdCustomer.DataSource = CustomerBindingSource

            ElseIf cmbSearchType.Text = "Address" Then
                tempStr = txtSearchString.Text.Trim
                tempStr = $"(Address1 Like '%{tempStr}%') OR (Address2 Like '%{tempStr}%') OR (Address3 Like '%{tempStr}%') OR (Postcode Like '%{tempStr}%')"
                CustomerBindingSource.Filter = tempStr
                ugdCustomer.DataSource = CustomerBindingSource

            Else
                strMsgBox = "Select search type - Name or Address"
                Alert(strMsgBox, MessageBoxIcon.Asterisk)

            End If

            lblNumRecs.Text = "Number of records: " & Format(CustomerBindingSource.Count, "##,##0")

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub cmdEditCustomer_Click(sender As Object, e As EventArgs) Handles cmdEditCustomer.Click

        Try

            If ugdCustomer.ActiveRow IsNot Nothing Then

                If objDelivColn IsNot Nothing Then objDelivColn.Dispose()

                objDelivColn = New frmDelivColn(OrderTypeEnum.Delivery, Nothing, Nothing, Nothing, False)

                ugrActiveRow = ugdCustomer.ActiveRow
                objDelivColn.txtTelephone.Text = ugdCustomer.ActiveRow.Cells("Phone").Value
                objDelivColn.Show()

                With objDelivColn
                    .cmdCustSearch.PerformClick()
                    .cmdBackScreen.Enabled = False
                    .cmdNextScreen.Enabled = False
                    .cmdPrevOrder.Enabled = False
                    .CustomerEditModeOn = True
                    .BringToFront()
                End With

            Else
                strMsgBox = "No customer row has been selected for editing."
                Alert(strMsgBox)

            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Public Sub UpdateDBRecords()

        Try
            CustomerTableAdapter.Fill(CustomerDataSet.Customer)
            ugdCustomer.DataSource = CustomerBindingSource
            ugdCustomer.Refresh()
            If ugrActiveRow IsNot Nothing Then
                ugdCustomer.ActiveRow = ugrActiveRow
            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub cmdMergeGroup_Click(sender As Object, e As EventArgs) Handles cmdMergeCustomer.Click

        If ugdCustomer.Selected.Rows.Count = ugdCustomer.Rows.Count Then

            'if whole grid is selected, remove dupes (without saving any other info)
            strMsgBox = "You have selected all the rows in the grid. This will merge all duplicate customers. Do you want to proceed?"
            intResponseBox = EZMsgBox.Show(strMsgBox, MessageBoxButtons.YesNo)
            If intResponseBox = vbYes Then
                clsCustomer.MergeGroup()
                CustomerTableAdapter.Update(CustomerDataSet)
                CustomerTableAdapter.Fill(CustomerDataSet.Customer)
                ugdCustomer.Refresh()
                lblNumRecs.Text = "Number of records: " & Format(CustomerBindingSource.Count, "##,##0")
            End If

        ElseIf ugdCustomer.Selected.Rows.Count > 1 Then
            'save info and delete other dupes

            Dim xCustID As Short
            Dim mainCustID As Short = Short.Parse(ugdCustomer.Selected.Rows(0).Cells("CustomerID").Value)

            For iCnt = 1 To ugdCustomer.Selected.Rows.Count - 1

                xCustID = Short.Parse(ugdCustomer.Selected.Rows(iCnt).Cells("CustomerID").Value)

                'if customer name not specified in first row, then take name from one of the other rows
                If ugdCustomer.Selected.Rows(0).Cells("Name").Value = "The Occupier" Then
                    If ugdCustomer.Selected.Rows(iCnt).Cells("Name").Value <> "The Occupier" Then
                        SQLQuery = $"UPDATE Customer 
                                     SET Name = '{ ugdCustomer.Selected.Rows(iCnt).Cells("Name").Value.ToString.Punctuate }' 
                                     WHERE CustomerID = {mainCustID}"
                        objDB.ExeNonQuery(SQLQuery)
                    End If
                End If

                'update alt address
                SQLQuery = $"UPDATE AltAddress SET CustomerID = {mainCustID} WHERE CustomerID = {xCustID}"
                objDB.ExeNonQuery(SQLQuery)

                'update alt phone
                clsCustomer.InsertAltPhone(ugdCustomer.Selected.Rows(0).Cells("Phone").Value, ugdCustomer.Selected.Rows(iCnt).Cells("Phone").Value)

                'update email if it is blank
                tempStr = ugdCustomer.Selected.Rows(iCnt).Cells("Email").Value.ToString.Trim
                If tempStr <> String.Empty Then
                    SQLQuery = "SELECT Email FROM Customer WHERE CustomerID = " & mainCustID
                    drDataRow = objDB.GetSingleRow(SQLQuery)
                    If (drDataRow Is Nothing) Or (drDataRow("Email").ToString.Trim = String.Empty) Then
                        SQLQuery = $"UPDATE Customer SET Email = '{tempStr}' WHERE CustomerID = {xCustID}"
                        objDB.ExeNonQuery(SQLQuery)
                    End If
                End If

                'update number of orders
                SQLQuery = "SELECT NumOrders FROM Customer WHERE CustomerID = " & xCustID
                drDataRow = objDB.GetSingleRow(SQLQuery)
                If drDataRow IsNot Nothing AndAlso Not IsDBNull(drDataRow!NumOrders) Then
                    SQLQuery = "UPDATE Customer SET NumOrders = NumOrders + " & drDataRow!NumOrders & " WHERE CustomerID = " & mainCustID
                    objDB.ExeNonQuery(SQLQuery)
                End If

                'update last order date
                Dim blnUpdateDate As Boolean = False
                SQLQuery = "SELECT LastOrder FROM Customer WHERE CustomerID = " & xCustID
                drDataRow = objDB.GetSingleRow(SQLQuery)
                If drDataRow IsNot Nothing AndAlso Not IsDBNull(drDataRow!LastOrder) Then
                    SQLQuery = "SELECT LastOrder FROM Customer WHERE CustomerID = " & mainCustID
                    Dim drDataRow2 As DataRow = objDB.GetSingleRow(SQLQuery)
                    If drDataRow2 IsNot Nothing AndAlso Not IsDBNull(drDataRow2!LastOrder) Then
                        If IsDate(drDataRow!LastOrder) AndAlso IsDate(drDataRow2!LastOrder) Then
                            If CDate(drDataRow!LastOrder) < CDate(drDataRow2!LastOrder) Then
                                blnUpdateDate = True
                            End If
                        End If
                    Else
                        blnUpdateDate = True
                    End If
                End If

                If blnUpdateDate Then
                    SQLQuery = $"UPDATE Customer SET LastOrder = '{ drDataRow!LastOrder.ToString("dd/MMM/yyyy") }' WHERE CustomerID = { mainCustID }"
                    objDB.ExeNonQuery(SQLQuery)
                End If

                SQLQuery = $"UPDATE Customer SET NumOrders = {mainCustID} WHERE CustomerID = {xCustID}"
                objDB.ExeNonQuery(SQLQuery)

                'update customer orders and order details
                SQLQuery = $"UPDATE CustOrders SET CustomerID = {mainCustID} WHERE CustomerID = {xCustID}"
                objDB.ExeNonQuery(SQLQuery)

                SQLQuery = $"UPDATE CustOrderItems SET CustomerID = {mainCustID} WHERE CustomerID = {xCustID}"
                objDB.ExeNonQuery(SQLQuery)

                'update directions
                SQLQuery = $"UPDATE Directions SET CustomerID = {mainCustID} WHERE CustomerID = {xCustID}"
                objDB.ExeNonQuery(SQLQuery)

                'update notes
                SQLQuery = $"UPDATE NotesDB SET CustomerID = {mainCustID} WHERE CustomerID = {xCustID}"
                objDB.ExeNonQuery(SQLQuery)

                'update orders
                SQLQuery = $"UPDATE Orders SET CustomerID = {mainCustID} WHERE CustomerID = {xCustID}"
                objDB.ExeNonQuery(SQLQuery)

                'delete the unwanted customer entries
                SQLQuery = $"DELETE FROM Customer WHERE CustomerID = {xCustID}"
                objDB.ExeNonQuery(SQLQuery)

            Next

            CustomerTableAdapter.Connection.ConnectionString = ConfigurationManager.ConnectionStrings(EZConstants.EZDatabaseConnectionString).ConnectionString
            CustomerTableAdapter.Fill(CustomerDataSet.Customer)
            ugdCustomer.Refresh()
            lblNumRecs.Text = "Number of records: " & Format(CustomerBindingSource.Count, "##,##0")

        Else

            strMsgBox = "You must select two or more rows to merge."
            Alert(strMsgBox)

        End If

    End Sub

End Class