﻿Imports System.Configuration
Imports EZControls
Imports Infragistics.Win.Misc
Imports System.IO
Imports EZMenu.Core
Imports EZService
Imports MySql.Data.MySqlClient

Public Class frmManager

    Private Sub frmManager_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Size = frmOpener.Size
        Location = frmOpener.Location

        cmdDBBackup.Enabled = Not GetAppSettingCS("DisableDBBackup", True)
        cmdDBRestore.Enabled = Not GetAppSettingCS("DisableDBBackup", True)

        'cmdRegister.Visible = Not objSecurity.AppIsActivated   'Not objSecurity.AppRegistered()

        cmdCleanDB.Enabled = (MainOrSubSystem() <> "MULTISUB")
        cmdDoFakeOrders.Visible = objSecurity.IsMySystem()

        Cursor.Show()

    End Sub

    Private Sub cmdSetupDishes_Click(sender As Object, e As EventArgs) Handles cmdSetupDishes.Click

        Using objDishesForm As New frmDishes2
            objDishesForm.ShowDialog(Me)
        End Using

    End Sub

    Private Sub cmdBack_Click(sender As Object, e As EventArgs) Handles cmdBack.Click

        If GetAppSettingCS("DisableCursor", True) Then Cursor.Hide() Else Cursor.Show()
        Close()

    End Sub

    Private Sub cmdSetupCustomer_Click(sender As Object, e As EventArgs) Handles cmdSetupCustomer.Click

        Using objCustomersForm As New frmCustomers
            objCustomersForm.ShowDialog(Me)
        End Using

    End Sub

    Private Sub cmdCleanDB_Click(sender As Object, e As EventArgs) Handles cmdCleanDB.Click

        If MainOrSubSystem() <> "MULTISUB" Then  'this is the main system

            'If objSecurity.GotAccess("XClearOrders") = True Then
            strMsgBox = "This will delete all of today's orders." & vbCrLf & "Are you sure?"
                intMsgBoxResult = EZMsgBox.Show(strMsgBox, MessageBoxButtons.YesNo, MessageBoxIcon.Error)
                If intMsgBoxResult = MsgBoxResult.Yes Then
                    objDB.CleanupDB()
                    If objTables IsNot Nothing Then objTables.Dispose()
                    strMsgBox = "Clean complete successful."
                    Alert(strMsgBox)
                End If
            'End If
        Else
            strMsgBox = "This system is part of a multi-system. This operation must be done on the main system"
            Alert(strMsgBox)
        End If

    End Sub

    Private Sub cmdBanking_Click(sender As Object, e As EventArgs) Handles cmdBanking.Click

        'If objSecurity.GotAccess("XAccessBanking") = True Then
        Using objBankingForm As New frmBanking
                objBankingForm.ShowDialog(Me)
            End Using
        ' End If

    End Sub

    Private Sub cmdSummary_Click(sender As Object, e As EventArgs) Handles cmdSummary.Click

        'If objSecurity.GotAccess("XAccessSummary") = True Then
        Using objSummaryForm As New frmSummary
            objSummaryForm.ShowDialog(Me)
        End Using
        'End If

    End Sub

    Private Sub cmdSetupDrinks_Click(sender As Object, e As EventArgs) Handles cmdSetupDrinks.Click

        Using objDrinksForm As New frmDrinks
            objDrinksForm.ShowDialog(Me)
        End Using

    End Sub

    Private Sub cmdRegister_Click(sender As Object, e As EventArgs) Handles cmdRegister.Click

        ShowRegisterForm()
        'cmdRegister.Visible = Not objSecurity.AppIsActivated()

    End Sub

    Private Sub cmdAbout_Click(sender As Object, e As EventArgs) Handles cmdAbout.Click

        Using objAboutForm As New frmAbout
            objAboutForm.ShowDialog(Me)
        End Using

    End Sub

    Private Sub cmdSettings_Click(sender As Object, e As EventArgs) Handles cmdSettings.Click

        Using objSettingsForm As New frmSettings
            objSettingsForm.ShowDialog(Me)
        End Using

    End Sub

    Private Sub cmdViewLog_Click(sender As Object, e As EventArgs) Handles cmdViewLog.Click

        'view the error log
        Try
            Dim strLogFile As String = "ezerrorlog.txt"
            If File.Exists(strLogFile) Then
                Dim processProperties As New ProcessStartInfo With {
                    .FileName = "notepad",
                    .Arguments = strLogFile,
                    .WindowStyle = ProcessWindowStyle.Normal
                }
                Process.Start(processProperties)
            Else
                Alert("Log file does not exist.", MessageBoxIcon.Error)
            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub cmdSQLQuery_Click(sender As Object, e As EventArgs) Handles cmdSQLQuery.Click

        Using objSQLQueryForm As New frmSQLQuery
            objSQLQueryForm.ShowDialog(Me)
        End Using

    End Sub

    Private Sub cmdTestWebserviceConn_Click(sender As Object, e As EventArgs) Handles cmdTestWebserviceConn.Click

        Dim hasAccess As Boolean = False

        ShowHourGlass()

        Using connection As New MySqlConnection(SecurityService.Decrypt(ConfigurationManager.ConnectionStrings(EZConstants.WebserverConnectionString).ConnectionString))
            Try
                connection.Open()
                hasAccess = True
                connection.Close()
            Catch ex As MySqlException
                hasAccess = False
            End Try
        End Using

        HideHourGlass()

        If hasAccess Then
            Alert("Connection to remote database successful.", MessageBoxIcon.Information)
        End If

    End Sub

    Private Sub ClearPrintSpooler()

        Try
            strMsgBox = "Select Yes to run internal spool cleaner" &
                vbCrLf & "Select No to run external spool cleaner" &
                vbCrLf & "Select Cancel to return to last screen"
            intResponseBox = EZMsgBox.Show(strMsgBox, MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question)

            If intResponseBox = vbYes Then

                Dim strComputer As String = "."
                Dim objWMIService As Object = GetObject("winmgmts:\\" & strComputer & "\root\cimv2")

                Dim colservicelist As Object
                colservicelist = objWMIService.ExecQuery("Select * from Win32_Service where Name = 'Spooler'")

                For Each objService In colservicelist
                    If objService.State = "Running" And objService.name = "Spooler" Then
                        objService.StopService()
                    End If
                Next

                Dim fileList As Object
                fileList = objWMIService.ExecQuery("ASSOCIATORS OF {Win32_Directory.Name='C:\Windows\system32\spool\printers'} Where " & "ResultClass = CIM_DataFile")

                For Each objFile In fileList
                    objFile.Delete()
                Next

                For Each objService In colservicelist
                    If objService.name = "Spooler" Then
                        objService.StartService()
                    End If
                Next

                Alert("Print spooler cleared")

            ElseIf intResponseBox = vbNo Then
                If File.Exists(Application.StartupPath & "\clearspooler.bat") = False Then
                    Dim twrSpooler As New StreamWriter(Application.StartupPath & "\clearspooler.bat", False)
                    twrSpooler.WriteLine("net stop spooler")
                    twrSpooler.WriteLine("del c:\windows\system32\spool\printers\*.* /q")
                    twrSpooler.WriteLine("net start spooler")
                    twrSpooler.Close()
                    Application.DoEvents()
                    Sleep(1000)
                    Application.DoEvents()
                End If

                Process.Start(Application.StartupPath & "\clearspooler.bat")

            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub cmdClearPrintSpooler_Click(sender As Object, e As EventArgs) Handles cmdClearPrintSpooler.Click

        ClearPrintSpooler()

    End Sub

    Private Sub cmdDoFakeOrders_Click(sender As Object, e As EventArgs) Handles cmdDoFakeOrders.Click

        Try
            tempStr = InputBox("How many orders?", "Input number", "100")
            If tempStr <> String.Empty Then
                Dim intNumberFakes As Short = Short.Parse(tempStr)

                For iC = 1 To intNumberFakes
                    Dim objFakeOrder As New clsFakeOrder
                    objFakeOrder.StartFakeOrder()
                    Sleep(100)
                    sender.text = intNumberFakes - iC
                    Application.DoEvents()
                Next

                objDB.ExeNonQuery("UPDATE Orders SET BizId = 45")

                cmdDoFakeOrders.Text = cmdDoFakeOrders.Tag
            End If

        Catch ex As Exception
            'DisplayError(ex)
        End Try

    End Sub

    Private Sub BackupRestoreDB(sender As Object, e As EventArgs) Handles cmdDBBackup.Click, cmdDBRestore.Click

        Dim btnSender As UltraButton = DirectCast(sender, UltraButton)

        btnSender.Tag = sender.text
        btnSender.Text = "<- wait ->"
        cmdDBBackup.Enabled = False
        cmdDBRestore.Enabled = False

        Using objDBBackup As New frmDBBackupRestore
            If btnSender Is cmdDBBackup Then
                objDBBackup.PerformDBBackup()
            Else
                objDBBackup.PerformDBRestore()
            End If
        End Using

        btnSender.Text = btnSender.Tag
        cmdDBBackup.Enabled = True
        cmdDBRestore.Enabled = True

    End Sub

End Class