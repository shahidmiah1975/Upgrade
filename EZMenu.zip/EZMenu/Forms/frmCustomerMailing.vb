﻿Imports System.Data.OleDb
Imports EZControls
Imports System.IO

Public Class frmCustomerMailing

    Dim drcMailings As DataRowCollection = Nothing

    Private Sub frmCustomerMailing_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Size = frmOpener.Size
        Location = frmOpener.Location

        SetupButtons()

        lblMatchesFound.Text = "0 matches have been found:"
        UpdateCount()

        ezkbdKeyboard.ctrlActive = txtCriteria

    End Sub

    Private Sub SetupButtons()

        'For Each myobjx In Me.upnlTableBill.ClientArea.Controls
        '    If (TypeName(myobjx) = "UltraButton" And myobjx.width = 126) Then
        '        Dim myObj As UltraButton = DirectCast(myobjx, UltraButton)
        '        myObj.Tag = myObj.Text
        '        myObj.Text = ""
        '        AddHandler myObj.MouseEnter, AddressOf ButtonMouseEnter
        '        AddHandler myObj.MouseLeave, AddressOf ButtonMouseLeave
        '    End If
        'Next

    End Sub

    Private Sub ButtonMouseEnter(sender As Object, e As EventArgs)
        sender.text = sender.tag
    End Sub

    Private Sub ButtonMouseLeave(sender As Object, e As EventArgs)
        sender.text = ""
    End Sub

    Private Sub cmdClear_Click(sender As Object, e As EventArgs) Handles cmdClear.Click

        upbSave.Visible = False
        txtCriteria.Clear()
        lstMatches.Items.Clear()
        lblMatchesFound.Text = "0 matches have been found:"

    End Sub

    Private Sub cmdSearch_Click(sender As Object, e As EventArgs) Handles cmdSearch.Click

        '   Fields CustomerName & CustomerAddress FROM Table PostingList IN Database CustomerMailings

        If txtCriteria.Text.Trim <> String.Empty Then

            SQLQuery = String.Format("SELECT DISTINCT Name, Address1, Address2, Address3, Postcode, Phone " &
                        "FROM (SELECT Name AS Name, Address1, Address2, Address3, Postcode, Phone " &
                        "FROM Customer " &
                        "WHERE (Address1 + Address2 + Address3 + Postcode LIKE '%{0}%')) AS NewTable " &
                        "ORDER BY Address1", txtCriteria.Text)

            drcMailings = objDB.GetDataRows(SQLQuery)

            If drcMailings IsNot Nothing AndAlso drcMailings.Count > 0 Then
                lblMatchesFound.Text = drcMailings.Count & " matches have been found (only some are shown below):"
                lstMatches.Items.Clear()
                For Each myRow In drcMailings
                    tempStr = myRow!Address1 & " " & myRow!Address2 & " " & myRow!Address3 & " " & myRow!Postcode
                    lstMatches.Items.Add(tempStr)
                    If lstMatches.Items.Count >= 50 Then Exit For
                Next
            End If

        Else
            strMsgBox = "You need to enter a search term."
            Alert(strMsgBox, MessageBoxIcon.Error)
        End If

    End Sub

    Private Sub txtCriteria_Enter(sender As Object, e As EventArgs) Handles txtCriteria.Enter

        ezkbdKeyboard.ctrlActive = txtCriteria

    End Sub

    Private Sub ExeMailingList(queryString As String)

        Dim strConnString As String = My.Settings.CustomerMailing.ToString

        Using connection As New OleDbConnection(strConnString)

            Try
                Dim command As OleDbCommand = New OleDbCommand(queryString, connection)
                connection.Open()
                command.ExecuteNonQuery()
                Application.DoEvents()
                connection.Close()

            Catch ex As Exception
                DisplayError(ex)
            End Try

        End Using

    End Sub

    Public Function GetCustomerCounts() As Integer

        Dim strConnString As String = My.Settings.CustomerMailing.ToString

        Try
            Dim tmpDataset As New DataSet

            Using connection As New OleDbConnection(strConnString)
                Dim adapter As New OleDbDataAdapter
                adapter.SelectCommand = New OleDbCommand("SELECT * FROM PostingList", connection)
                adapter.Fill(tmpDataset)
                Return tmpDataset.Tables(0).Rows.Count
            End Using
        Catch ex As Exception
            DisplayError(ex)
            Return 0
        End Try

    End Function

    Public Function GetMailingRows(strQryString) As DataRowCollection

        Dim strConnString As String = My.Settings.CustomerMailing.ToString

        Try
            Dim tmpDataset As New DataSet

            Using connection As New OleDbConnection(strConnString)
                Dim adapter As New OleDbDataAdapter
                adapter.SelectCommand = New OleDbCommand(strQryString, connection)
                adapter.Fill(tmpDataset)
                Return tmpDataset.Tables(0).Rows
            End Using
        Catch ex As Exception
            DisplayError(ex)
            Return Nothing
        End Try

    End Function

    Private Sub cmdCleanDB_Click(sender As Object, e As EventArgs) Handles cmdCleanDB.Click

        strMsgBox = "This will delete any records in the mailing database." & vbCrLf & "Are you sure?"
        intMsgBoxResult = EZMsgBox.Show(strMsgBox, MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If intMsgBoxResult = MsgBoxResult.Yes Then
            SQLQuery = "DELETE * FROM PostingList"
            ExeMailingList(SQLQuery)
            UpdateCount()
        End If

    End Sub

    Private Sub UpdateCount()
        lblNumRecords.Text = "There are " & GetCustomerCounts() & " customer records selected for mailing list"
    End Sub

    Private Sub cmdClose_Click(sender As Object, e As EventArgs) Handles cmdClose.Click
        Close()
    End Sub

    Private Sub txtCriteria_KeyDown(sender As Object, e As KeyEventArgs) Handles txtCriteria.KeyDown

        If e.KeyCode = Keys.Enter Then cmdSearch_Click(sender, e)

    End Sub

    Private Sub cmdCustSave_Click(sender As Object, e As EventArgs) Handles cmdCustSave.Click

        Try
            If drcMailings IsNot Nothing Then

                cmdClear.Enabled = False
                cmdClose.Enabled = False
                cmdCustSave.Enabled = False
                cmdCleanDB.Enabled = False
                cmdSearch.Enabled = False

                upbSave.Minimum = 0
                upbSave.Maximum = drcMailings.Count
                upbSave.Value = 0
                upbSave.Visible = True

                For Each myRow In drcMailings
                    tempStr = String.Empty
                    If myRow!Address1.ToString.Trim <> String.Empty Then tempStr = myRow!Address1.ToString.Trim

                    If myRow!Address2.ToString.Trim <> String.Empty Then
                        If tempStr <> String.Empty Then tempStr &= vbCrLf
                        tempStr &= myRow!Address2.ToString.Trim
                    End If

                    If myRow!Address3.ToString.Trim <> String.Empty Then
                        If tempStr <> String.Empty Then tempStr &= vbCrLf
                        tempStr &= myRow!Address3.ToString.Trim
                    End If

                    If myRow!Postcode.ToString.Trim <> String.Empty Then
                        If tempStr <> String.Empty Then tempStr &= vbCrLf
                        tempStr &= myRow!Postcode.ToString.Trim
                    End If

                    SQLQuery = String.Format("INSERT INTO PostingList (CustomerName, CustomerAddress) VALUES ('{0}','{1}')", myRow!Name.ToString.Punctuate, tempStr.Punctuate)
                    ExeMailingList(SQLQuery)
                    If upbSave.Value < upbSave.Maximum Then upbSave.Value += 1
                    Application.DoEvents()
                Next

                UpdateCount()

                strMsgBox = "Addresses have been successfully saved."
                Alert(strMsgBox)

            Else
                strMsgBox = "There are no records to save"
                Alert(strMsgBox)
            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

        cmdClear.Enabled = True
        cmdClose.Enabled = True
        cmdCustSave.Enabled = True
        cmdCleanDB.Enabled = True
        cmdSearch.Enabled = True
        upbSave.Visible = False

    End Sub

    Private Sub ExportDatasetToCSV(MyDataSet As DataSet)

        Dim dt As DataTable
        Dim dr As DataRow
        Dim myString As String = String.Empty
        Dim bFirstRecord As Boolean
        Dim myWriter As New StreamWriter(Application.StartupPath & "\CustomerMailings.csv")

        Try
            For Each dt In MyDataSet.Tables
                For Each dr In dt.Rows
                    bFirstRecord = True
                    For Each field As Object In dr.ItemArray
                        If Not bFirstRecord Then
                            myString &= (",")
                        End If
                        myString &= (field.ToString)
                        bFirstRecord = False
                    Next
                    'New Line to differentiate next row
                    myString &= (Environment.NewLine)
                Next
            Next
        Catch ex As Exception
            DisplayError(ex)
        End Try

        'Write the String to the Csv File
        myWriter.WriteLine(myString)

        'Clean up
        myWriter.Close()

    End Sub

    Private Sub cmdGetAll_Click(sender As Object, e As EventArgs) Handles cmdGetAll.Click

        SQLQuery = "SELECT DISTINCT Name, Address1, Address2, Address3, Postcode, Phone " &
                   "FROM Customer ORDER BY Postcode, Address1"

        drcMailings = objDB.GetDataRows(SQLQuery)

        If drcMailings IsNot Nothing AndAlso drcMailings.Count > 0 Then
            lblMatchesFound.Text = drcMailings.Count & " matches have been found (only some are shown below):"
            lstMatches.Items.Clear()
            For Each myRow In drcMailings
                tempStr = myRow!Address1 & ", " & myRow!Address2 & ", " & myRow!Address3 & " " & myRow!Postcode
                lstMatches.Items.Add(tempStr)
                If lstMatches.Items.Count >= 50 Then Exit For
            Next
        End If

    End Sub

    Private Sub cmdExportToExcel_Click(sender As Object, e As EventArgs) Handles cmdExportToExcel.Click

        If drcMailings IsNot Nothing Then

            upbSave.Minimum = 0
            upbSave.Maximum = drcMailings.Count
            upbSave.Value = 0
            upbSave.Visible = True

            ExportToExcel(drcMailings)

        Else

            Alert("No data to export")

        End If

    End Sub

    Private Sub ExportToExcel(drcTempp As DataRowCollection)

        'Try
        '    Dim strFileName As String = Path.GetPathRoot(My.Application.Info.DirectoryPath) & "ezdata.xlsx"
        '    Dim _excel As New Microsoft.Office.Interop.Excel.Application
        '    Dim wBook As Microsoft.Office.Interop.Excel.Workbook
        '    Dim wSheet As Microsoft.Office.Interop.Excel.Worksheet
        '    Dim colIndex As Integer = 0
        '    Dim rowIndex As Integer = 0

        '    wBook = _excel.Workbooks.Add()
        '    wSheet = wBook.ActiveSheet()

        '    _excel.Cells(1, 1) = "Name"
        '    _excel.Cells(1, 2) = "Address1"
        '    _excel.Cells(1, 3) = "Address2"
        '    _excel.Cells(1, 4) = "Address3"
        '    _excel.Cells(1, 5) = "Postcode"
        '    _excel.Cells(1, 6) = "Phone"

        '    For Each dr As DataRow In drcTempp
        '        rowIndex = rowIndex + 1
        '        For colIndex = 1 To 6
        '            _excel.Cells(rowIndex + 1, colIndex) = "'" & dr.Item(colIndex - 1)
        '        Next
        '        If upbSave.Value < upbSave.Maximum Then upbSave.Value += 1
        '        Application.DoEvents()
        '    Next

        '    wSheet.Columns.AutoFit()
        '    If System.IO.File.Exists(strFileName) Then System.IO.File.Delete(strFileName)

        '    wBook.SaveAs(strFileName)
        '    wBook.Close()
        '    _excel.Quit()

        '    strMsgBox = "Data has been saved to file " & strFileName
        '    Alert(strMsgBox)

        'Catch ex As Exception
        '    DisplayError(ex, "Export to Excel failed")
        'End Try

    End Sub

    Private Sub cmdExportToCSV_Click(sender As Object, e As EventArgs) Handles cmdExportToCSV.Click

        If drcMailings IsNot Nothing Then

            upbSave.Minimum = 0
            upbSave.Maximum = drcMailings.Count
            upbSave.Value = 0
            upbSave.Visible = True

            ExportToCSV(drcMailings)

        Else

            Alert("No data to export")

        End If

    End Sub

    Private Sub ExportToCSV(dtData As DataRowCollection)

        Dim myString As String = ""
        Dim bFirstRecord As Boolean = True
        Dim strXPFile As String = Path.GetPathRoot(My.Application.Info.DirectoryPath) & "ezdata.csv"
        Dim myWriter As New StreamWriter(strXPFile)

        Try
            myWriter.WriteLine("Name, Address1, Address2, Address3, Postcode, Phone")

            For Each dr As DataRow In dtData
                bFirstRecord = True
                For Each field As Object In dr.ItemArray
                    If Not bFirstRecord Then myString &= ","
                    myString &= field.ToString
                    bFirstRecord = False
                Next
                If upbSave.Value < upbSave.Maximum Then upbSave.Value += 1
                Application.DoEvents()
                'New Line to differentiate next row
                myString &= Environment.NewLine
            Next

            myWriter.WriteLine(myString)
            myWriter.Close()

            strMsgBox = "Data has been saved to file " & strXPFile
            Alert(strMsgBox)

        Catch ex As Exception
            DisplayError(ex, "Export to CSV failed")
        End Try

    End Sub

End Class