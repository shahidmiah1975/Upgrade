﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSummary
    Inherits EZMenu.frmBaseForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim Appearance34 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance35 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance36 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance37 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance38 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance39 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance40 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance41 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance42 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance43 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance44 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance45 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance46 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance47 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance48 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance49 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance50 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance51 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance52 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance53 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance54 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance55 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance56 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance57 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance58 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance59 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance60 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance61 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance62 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance63 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance64 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance65 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance66 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance67 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance1 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmSummary))
        Dim Appearance2 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance3 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance7 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance8 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance9 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance68 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance69 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance70 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance71 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance72 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance73 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance74 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance75 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance76 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance77 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance78 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance79 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance80 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance81 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance82 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance83 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance84 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance85 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance86 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance87 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance88 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance89 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance90 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance91 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance92 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance93 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance94 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance95 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance96 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance97 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance98 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance99 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance100 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance101 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance102 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance103 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance104 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance105 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance106 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance107 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance108 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance109 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance110 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance111 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance112 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance113 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance114 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance115 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance116 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance117 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance118 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance119 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance120 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance121 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance122 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance123 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance124 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance125 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance126 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance127 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance128 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance129 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance130 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance131 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance132 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance133 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance134 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance135 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance136 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance137 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance138 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance139 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance140 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance141 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance142 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance143 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance144 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance145 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance146 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance147 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance148 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance149 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance150 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance151 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance152 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance153 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance154 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance155 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance156 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance157 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance13 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance14 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance15 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance19 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance20 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance21 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance25 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance26 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance27 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance31 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance32 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance33 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance28 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance29 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance30 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance22 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance23 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance24 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance16 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance17 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance18 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance10 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance11 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance12 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance4 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance5 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance6 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance158 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Me.UltraPanel3 = New Infragistics.Win.Misc.UltraPanel()
        Me.cmdClear = New Infragistics.Win.Misc.UltraButton()
        Me.cmdNum0 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdNum3 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdNum2 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdNum1 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdNum6 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdNum5 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdNum4 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdNum9 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdNum8 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdNum7 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdClose = New Infragistics.Win.Misc.UltraButton()
        Me.cmdPrintSummary = New Infragistics.Win.Misc.UltraButton()
        Me.upnTextBoxes = New Infragistics.Win.Misc.UltraPanel()
        Me.txtGrandTotalTotal = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtTipsTotal = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtGrandCards = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.lblCTotal = New Infragistics.Win.Misc.UltraLabel()
        Me.txtGrandCash = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtTipsCard = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtGrandOther = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.lblCards = New Infragistics.Win.Misc.UltraLabel()
        Me.txtOLTotalTotal = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtTipsCash = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtOLTotalCards = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.lblOther = New Infragistics.Win.Misc.UltraLabel()
        Me.txtOLTotalCash = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtTipsOther = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtOLTotalOther = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.lblCash = New Infragistics.Win.Misc.UltraLabel()
        Me.txtR5C4 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtBankTotal = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtR5C2 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtCTotal = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtR5C1 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtBankCard = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtR5C3 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtCCards = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtR4C4 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtBankCash = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtR4C2 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtCCash = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtR4C1 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtBankOther = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtR4C3 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtCOther = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtR3C4 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtTotalTotal = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtR3C2 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtDTotal = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtR3C1 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtTotalCards = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtR3C3 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtDCards = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtR2C4 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtTotalCash = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtR2C2 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtTotalOther = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtR2C1 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtDCash = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtR2C3 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtDOther = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtR1C4 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtTTotal = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtR1C2 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtExpenses = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtR1C1 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtR1C3 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtTCards = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.UltraLabel5 = New Infragistics.Win.Misc.UltraLabel()
        Me.txtTCash = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtTOther = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.lblOL5 = New Infragistics.Win.Misc.UltraLabel()
        Me.lblBanking = New Infragistics.Win.Misc.UltraLabel()
        Me.lblOL4 = New Infragistics.Win.Misc.UltraLabel()
        Me.lblRTotal = New Infragistics.Win.Misc.UltraLabel()
        Me.lblOLTotal = New Infragistics.Win.Misc.UltraLabel()
        Me.lblTables = New Infragistics.Win.Misc.UltraLabel()
        Me.lblOL3 = New Infragistics.Win.Misc.UltraLabel()
        Me.lblCollections = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel16 = New Infragistics.Win.Misc.UltraLabel()
        Me.lblDeliveries = New Infragistics.Win.Misc.UltraLabel()
        Me.lblOL2 = New Infragistics.Win.Misc.UltraLabel()
        Me.lblExpenses = New Infragistics.Win.Misc.UltraLabel()
        Me.lblOL1 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraButton2 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdCopyBank = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton1 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDoOLSums = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDoAllGrandTotals = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDoSums = New Infragistics.Win.Misc.UltraButton()
        Me.cmdShowBanking = New Infragistics.Win.Misc.UltraButton()
        Me.cmdSaveBanking = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDateStart = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDateEnd = New Infragistics.Win.Misc.UltraButton()
        Me.cmdSaveTakings = New Infragistics.Win.Misc.UltraButton()
        Me.cmdShowTakings = New Infragistics.Win.Misc.UltraButton()
        Me.cmdWorkingDay = New Infragistics.Win.Misc.UltraButton()
        Me.cmdGetDate = New Infragistics.Win.Misc.UltraButton()
        Me.cmdGroupSummary = New Infragistics.Win.Misc.UltraButton()
        Me.lblStatus = New Infragistics.Win.Misc.UltraLabel()
        Me.uplBasePanel.ClientArea.SuspendLayout()
        Me.uplBasePanel.SuspendLayout()
        Me.UltraPanel3.ClientArea.SuspendLayout()
        Me.UltraPanel3.SuspendLayout()
        Me.upnTextBoxes.ClientArea.SuspendLayout()
        Me.upnTextBoxes.SuspendLayout()
        CType(Me.txtGrandTotalTotal, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTipsTotal, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtGrandCards, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtGrandCash, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTipsCard, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtGrandOther, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtOLTotalTotal, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTipsCash, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtOLTotalCards, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtOLTotalCash, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTipsOther, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtOLTotalOther, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtR5C4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtBankTotal, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtR5C2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtCTotal, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtR5C1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtBankCard, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtR5C3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtCCards, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtR4C4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtBankCash, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtR4C2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtCCash, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtR4C1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtBankOther, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtR4C3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtCOther, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtR3C4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTotalTotal, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtR3C2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtDTotal, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtR3C1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTotalCards, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtR3C3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtDCards, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtR2C4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTotalCash, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtR2C2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTotalOther, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtR2C1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtDCash, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtR2C3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtDOther, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtR1C4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTTotal, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtR1C2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtExpenses, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtR1C1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtR1C3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTCards, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTCash, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTOther, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblHeader
        '
        Me.lblBaseHeader.Text = "Business Summary Screen"
        '
        'UltraPanel1
        '
        '
        'UltraPanel1.ClientArea
        '
        Me.uplBasePanel.ClientArea.Controls.Add(Me.cmdClose)
        Me.uplBasePanel.ClientArea.Controls.Add(Me.cmdGroupSummary)
        Me.uplBasePanel.ClientArea.Controls.Add(Me.cmdPrintSummary)
        Me.uplBasePanel.ClientArea.Controls.Add(Me.cmdGetDate)
        Me.uplBasePanel.ClientArea.Controls.Add(Me.cmdShowBanking)
        Me.uplBasePanel.ClientArea.Controls.Add(Me.cmdWorkingDay)
        Me.uplBasePanel.ClientArea.Controls.Add(Me.cmdSaveBanking)
        Me.uplBasePanel.ClientArea.Controls.Add(Me.cmdShowTakings)
        Me.uplBasePanel.ClientArea.Controls.Add(Me.cmdDateStart)
        Me.uplBasePanel.ClientArea.Controls.Add(Me.cmdSaveTakings)
        Me.uplBasePanel.ClientArea.Controls.Add(Me.cmdDateEnd)
        Me.uplBasePanel.Location = New System.Drawing.Point(0, 723)
        Me.uplBasePanel.Size = New System.Drawing.Size(1003, 72)
        '
        'UltraPanel3
        '
        Appearance34.BackColor = System.Drawing.Color.Transparent
        Me.UltraPanel3.Appearance = Appearance34
        Me.UltraPanel3.BorderStyle = Infragistics.Win.UIElementBorderStyle.Etched
        '
        'UltraPanel3.ClientArea
        '
        Me.UltraPanel3.ClientArea.Controls.Add(Me.cmdClear)
        Me.UltraPanel3.ClientArea.Controls.Add(Me.cmdNum0)
        Me.UltraPanel3.ClientArea.Controls.Add(Me.cmdNum3)
        Me.UltraPanel3.ClientArea.Controls.Add(Me.cmdNum2)
        Me.UltraPanel3.ClientArea.Controls.Add(Me.cmdNum1)
        Me.UltraPanel3.ClientArea.Controls.Add(Me.cmdNum6)
        Me.UltraPanel3.ClientArea.Controls.Add(Me.cmdNum5)
        Me.UltraPanel3.ClientArea.Controls.Add(Me.cmdNum4)
        Me.UltraPanel3.ClientArea.Controls.Add(Me.cmdNum9)
        Me.UltraPanel3.ClientArea.Controls.Add(Me.cmdNum8)
        Me.UltraPanel3.ClientArea.Controls.Add(Me.cmdNum7)
        Me.UltraPanel3.Location = New System.Drawing.Point(707, 229)
        Me.UltraPanel3.Name = "UltraPanel3"
        Me.UltraPanel3.Size = New System.Drawing.Size(221, 213)
        Me.UltraPanel3.TabIndex = 504
        '
        'cmdClear
        '
        Appearance35.BorderColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance35.ForeColor = System.Drawing.Color.DimGray
        Appearance35.TextVAlignAsString = "Middle"
        Me.cmdClear.Appearance = Appearance35
        Me.cmdClear.ButtonStyle = Infragistics.Win.UIElementButtonStyle.Flat
        Me.cmdClear.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance36.BackColor = System.Drawing.Color.DarkOrange
        Appearance36.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance36.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance36.ForeColor = System.Drawing.Color.Black
        Me.cmdClear.HotTrackAppearance = Appearance36
        Me.cmdClear.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdClear.Location = New System.Drawing.Point(76, 158)
        Me.cmdClear.Name = "cmdClear"
        Appearance37.BackColor = System.Drawing.Color.OrangeRed
        Appearance37.BackColor2 = System.Drawing.Color.Tomato
        Appearance37.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdClear.PressedAppearance = Appearance37
        Me.cmdClear.ShowFocusRect = False
        Me.cmdClear.ShowOutline = False
        Me.cmdClear.Size = New System.Drawing.Size(136, 45)
        Me.cmdClear.StyleSetName = "StatusBar"
        Me.cmdClear.TabIndex = 522
        Me.cmdClear.Tag = ""
        Me.cmdClear.Text = "Clear"
        Me.cmdClear.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdClear.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdClear.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdNum0
        '
        Appearance38.BorderColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance38.ForeColor = System.Drawing.Color.DimGray
        Appearance38.TextVAlignAsString = "Middle"
        Me.cmdNum0.Appearance = Appearance38
        Me.cmdNum0.ButtonStyle = Infragistics.Win.UIElementButtonStyle.Flat
        Me.cmdNum0.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance39.BackColor = System.Drawing.Color.DarkOrange
        Appearance39.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance39.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance39.ForeColor = System.Drawing.Color.Black
        Me.cmdNum0.HotTrackAppearance = Appearance39
        Me.cmdNum0.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdNum0.Location = New System.Drawing.Point(5, 158)
        Me.cmdNum0.Name = "cmdNum0"
        Appearance40.BackColor = System.Drawing.Color.OrangeRed
        Appearance40.BackColor2 = System.Drawing.Color.Tomato
        Appearance40.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdNum0.PressedAppearance = Appearance40
        Me.cmdNum0.ShowFocusRect = False
        Me.cmdNum0.ShowOutline = False
        Me.cmdNum0.Size = New System.Drawing.Size(65, 45)
        Me.cmdNum0.StyleSetName = "StatusBar"
        Me.cmdNum0.TabIndex = 513
        Me.cmdNum0.Tag = ""
        Me.cmdNum0.Text = "0"
        Me.cmdNum0.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdNum0.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdNum0.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdNum3
        '
        Appearance41.BorderColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance41.ForeColor = System.Drawing.Color.DimGray
        Appearance41.TextVAlignAsString = "Middle"
        Me.cmdNum3.Appearance = Appearance41
        Me.cmdNum3.ButtonStyle = Infragistics.Win.UIElementButtonStyle.Flat
        Me.cmdNum3.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance42.BackColor = System.Drawing.Color.DarkOrange
        Appearance42.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance42.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance42.ForeColor = System.Drawing.Color.Black
        Me.cmdNum3.HotTrackAppearance = Appearance42
        Me.cmdNum3.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdNum3.Location = New System.Drawing.Point(147, 107)
        Me.cmdNum3.Name = "cmdNum3"
        Appearance43.BackColor = System.Drawing.Color.OrangeRed
        Appearance43.BackColor2 = System.Drawing.Color.Tomato
        Appearance43.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdNum3.PressedAppearance = Appearance43
        Me.cmdNum3.ShowFocusRect = False
        Me.cmdNum3.ShowOutline = False
        Me.cmdNum3.Size = New System.Drawing.Size(65, 45)
        Me.cmdNum3.StyleSetName = "StatusBar"
        Me.cmdNum3.TabIndex = 512
        Me.cmdNum3.Tag = ""
        Me.cmdNum3.Text = "3"
        Me.cmdNum3.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdNum3.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdNum3.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdNum2
        '
        Appearance44.BorderColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance44.ForeColor = System.Drawing.Color.DimGray
        Appearance44.TextVAlignAsString = "Middle"
        Me.cmdNum2.Appearance = Appearance44
        Me.cmdNum2.ButtonStyle = Infragistics.Win.UIElementButtonStyle.Flat
        Me.cmdNum2.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance45.BackColor = System.Drawing.Color.DarkOrange
        Appearance45.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance45.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance45.ForeColor = System.Drawing.Color.Black
        Me.cmdNum2.HotTrackAppearance = Appearance45
        Me.cmdNum2.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdNum2.Location = New System.Drawing.Point(76, 107)
        Me.cmdNum2.Name = "cmdNum2"
        Appearance46.BackColor = System.Drawing.Color.OrangeRed
        Appearance46.BackColor2 = System.Drawing.Color.Tomato
        Appearance46.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdNum2.PressedAppearance = Appearance46
        Me.cmdNum2.ShowFocusRect = False
        Me.cmdNum2.ShowOutline = False
        Me.cmdNum2.Size = New System.Drawing.Size(65, 45)
        Me.cmdNum2.StyleSetName = "StatusBar"
        Me.cmdNum2.TabIndex = 511
        Me.cmdNum2.Tag = ""
        Me.cmdNum2.Text = "2"
        Me.cmdNum2.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdNum2.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdNum2.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdNum1
        '
        Appearance47.BorderColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance47.ForeColor = System.Drawing.Color.DimGray
        Appearance47.TextVAlignAsString = "Middle"
        Me.cmdNum1.Appearance = Appearance47
        Me.cmdNum1.ButtonStyle = Infragistics.Win.UIElementButtonStyle.Flat
        Me.cmdNum1.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance48.BackColor = System.Drawing.Color.DarkOrange
        Appearance48.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance48.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance48.ForeColor = System.Drawing.Color.Black
        Me.cmdNum1.HotTrackAppearance = Appearance48
        Me.cmdNum1.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdNum1.Location = New System.Drawing.Point(5, 107)
        Me.cmdNum1.Name = "cmdNum1"
        Appearance49.BackColor = System.Drawing.Color.OrangeRed
        Appearance49.BackColor2 = System.Drawing.Color.Tomato
        Appearance49.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdNum1.PressedAppearance = Appearance49
        Me.cmdNum1.ShowFocusRect = False
        Me.cmdNum1.ShowOutline = False
        Me.cmdNum1.Size = New System.Drawing.Size(65, 45)
        Me.cmdNum1.StyleSetName = "StatusBar"
        Me.cmdNum1.TabIndex = 510
        Me.cmdNum1.Tag = ""
        Me.cmdNum1.Text = "1"
        Me.cmdNum1.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdNum1.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdNum1.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdNum6
        '
        Appearance50.BorderColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance50.ForeColor = System.Drawing.Color.DimGray
        Appearance50.TextVAlignAsString = "Middle"
        Me.cmdNum6.Appearance = Appearance50
        Me.cmdNum6.ButtonStyle = Infragistics.Win.UIElementButtonStyle.Flat
        Me.cmdNum6.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance51.BackColor = System.Drawing.Color.DarkOrange
        Appearance51.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance51.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance51.ForeColor = System.Drawing.Color.Black
        Me.cmdNum6.HotTrackAppearance = Appearance51
        Me.cmdNum6.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdNum6.Location = New System.Drawing.Point(147, 56)
        Me.cmdNum6.Name = "cmdNum6"
        Appearance52.BackColor = System.Drawing.Color.OrangeRed
        Appearance52.BackColor2 = System.Drawing.Color.Tomato
        Appearance52.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdNum6.PressedAppearance = Appearance52
        Me.cmdNum6.ShowFocusRect = False
        Me.cmdNum6.ShowOutline = False
        Me.cmdNum6.Size = New System.Drawing.Size(65, 45)
        Me.cmdNum6.StyleSetName = "StatusBar"
        Me.cmdNum6.TabIndex = 509
        Me.cmdNum6.Tag = ""
        Me.cmdNum6.Text = "6"
        Me.cmdNum6.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdNum6.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdNum6.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdNum5
        '
        Appearance53.BorderColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance53.ForeColor = System.Drawing.Color.DimGray
        Appearance53.TextVAlignAsString = "Middle"
        Me.cmdNum5.Appearance = Appearance53
        Me.cmdNum5.ButtonStyle = Infragistics.Win.UIElementButtonStyle.Flat
        Me.cmdNum5.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance54.BackColor = System.Drawing.Color.DarkOrange
        Appearance54.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance54.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance54.ForeColor = System.Drawing.Color.Black
        Me.cmdNum5.HotTrackAppearance = Appearance54
        Me.cmdNum5.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdNum5.Location = New System.Drawing.Point(76, 56)
        Me.cmdNum5.Name = "cmdNum5"
        Appearance55.BackColor = System.Drawing.Color.OrangeRed
        Appearance55.BackColor2 = System.Drawing.Color.Tomato
        Appearance55.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdNum5.PressedAppearance = Appearance55
        Me.cmdNum5.ShowFocusRect = False
        Me.cmdNum5.ShowOutline = False
        Me.cmdNum5.Size = New System.Drawing.Size(65, 45)
        Me.cmdNum5.StyleSetName = "StatusBar"
        Me.cmdNum5.TabIndex = 508
        Me.cmdNum5.Tag = ""
        Me.cmdNum5.Text = "5"
        Me.cmdNum5.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdNum5.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdNum5.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdNum4
        '
        Appearance56.BorderColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance56.ForeColor = System.Drawing.Color.DimGray
        Appearance56.TextVAlignAsString = "Middle"
        Me.cmdNum4.Appearance = Appearance56
        Me.cmdNum4.ButtonStyle = Infragistics.Win.UIElementButtonStyle.Flat
        Me.cmdNum4.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance57.BackColor = System.Drawing.Color.DarkOrange
        Appearance57.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance57.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance57.ForeColor = System.Drawing.Color.Black
        Me.cmdNum4.HotTrackAppearance = Appearance57
        Me.cmdNum4.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdNum4.Location = New System.Drawing.Point(5, 56)
        Me.cmdNum4.Name = "cmdNum4"
        Appearance58.BackColor = System.Drawing.Color.OrangeRed
        Appearance58.BackColor2 = System.Drawing.Color.Tomato
        Appearance58.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdNum4.PressedAppearance = Appearance58
        Me.cmdNum4.ShowFocusRect = False
        Me.cmdNum4.ShowOutline = False
        Me.cmdNum4.Size = New System.Drawing.Size(65, 45)
        Me.cmdNum4.StyleSetName = "StatusBar"
        Me.cmdNum4.TabIndex = 507
        Me.cmdNum4.Tag = ""
        Me.cmdNum4.Text = "4"
        Me.cmdNum4.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdNum4.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdNum4.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdNum9
        '
        Appearance59.BorderColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance59.ForeColor = System.Drawing.Color.DimGray
        Appearance59.TextVAlignAsString = "Middle"
        Me.cmdNum9.Appearance = Appearance59
        Me.cmdNum9.ButtonStyle = Infragistics.Win.UIElementButtonStyle.Flat
        Me.cmdNum9.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance60.BackColor = System.Drawing.Color.DarkOrange
        Appearance60.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance60.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance60.ForeColor = System.Drawing.Color.Black
        Me.cmdNum9.HotTrackAppearance = Appearance60
        Me.cmdNum9.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdNum9.Location = New System.Drawing.Point(147, 5)
        Me.cmdNum9.Name = "cmdNum9"
        Appearance61.BackColor = System.Drawing.Color.OrangeRed
        Appearance61.BackColor2 = System.Drawing.Color.Tomato
        Appearance61.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdNum9.PressedAppearance = Appearance61
        Me.cmdNum9.ShowFocusRect = False
        Me.cmdNum9.ShowOutline = False
        Me.cmdNum9.Size = New System.Drawing.Size(65, 45)
        Me.cmdNum9.StyleSetName = "StatusBar"
        Me.cmdNum9.TabIndex = 506
        Me.cmdNum9.Tag = ""
        Me.cmdNum9.Text = "9"
        Me.cmdNum9.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdNum9.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdNum9.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdNum8
        '
        Appearance62.BorderColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance62.ForeColor = System.Drawing.Color.DimGray
        Appearance62.TextVAlignAsString = "Middle"
        Me.cmdNum8.Appearance = Appearance62
        Me.cmdNum8.ButtonStyle = Infragistics.Win.UIElementButtonStyle.Flat
        Me.cmdNum8.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance63.BackColor = System.Drawing.Color.DarkOrange
        Appearance63.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance63.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance63.ForeColor = System.Drawing.Color.Black
        Me.cmdNum8.HotTrackAppearance = Appearance63
        Me.cmdNum8.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdNum8.Location = New System.Drawing.Point(76, 5)
        Me.cmdNum8.Name = "cmdNum8"
        Appearance64.BackColor = System.Drawing.Color.OrangeRed
        Appearance64.BackColor2 = System.Drawing.Color.Tomato
        Appearance64.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdNum8.PressedAppearance = Appearance64
        Me.cmdNum8.ShowFocusRect = False
        Me.cmdNum8.ShowOutline = False
        Me.cmdNum8.Size = New System.Drawing.Size(65, 45)
        Me.cmdNum8.StyleSetName = "StatusBar"
        Me.cmdNum8.TabIndex = 505
        Me.cmdNum8.Tag = ""
        Me.cmdNum8.Text = "8"
        Me.cmdNum8.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdNum8.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdNum8.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdNum7
        '
        Appearance65.BorderColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance65.ForeColor = System.Drawing.Color.DimGray
        Appearance65.TextVAlignAsString = "Middle"
        Me.cmdNum7.Appearance = Appearance65
        Me.cmdNum7.ButtonStyle = Infragistics.Win.UIElementButtonStyle.Flat
        Me.cmdNum7.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance66.BackColor = System.Drawing.Color.DarkOrange
        Appearance66.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance66.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance66.ForeColor = System.Drawing.Color.Black
        Me.cmdNum7.HotTrackAppearance = Appearance66
        Me.cmdNum7.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdNum7.Location = New System.Drawing.Point(5, 5)
        Me.cmdNum7.Name = "cmdNum7"
        Appearance67.BackColor = System.Drawing.Color.OrangeRed
        Appearance67.BackColor2 = System.Drawing.Color.Tomato
        Appearance67.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdNum7.PressedAppearance = Appearance67
        Me.cmdNum7.ShowFocusRect = False
        Me.cmdNum7.ShowOutline = False
        Me.cmdNum7.Size = New System.Drawing.Size(65, 45)
        Me.cmdNum7.StyleSetName = "StatusBar"
        Me.cmdNum7.TabIndex = 504
        Me.cmdNum7.Tag = ""
        Me.cmdNum7.Text = "7"
        Me.cmdNum7.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdNum7.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdNum7.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdClose
        '
        Me.cmdClose.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Appearance1.ForeColor = System.Drawing.Color.DimGray
        Appearance1.Image = CType(resources.GetObject("Appearance1.Image"), Object)
        Appearance1.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance1.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance1.TextVAlignAsString = "Bottom"
        Me.cmdClose.Appearance = Appearance1
        Me.cmdClose.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdClose.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance2.BackColor = System.Drawing.Color.DarkOrange
        Appearance2.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance2.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance2.ForeColor = System.Drawing.Color.Black
        Me.cmdClose.HotTrackAppearance = Appearance2
        Me.cmdClose.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdClose.Location = New System.Drawing.Point(899, 6)
        Me.cmdClose.Name = "cmdClose"
        Appearance3.BackColor = System.Drawing.Color.OrangeRed
        Appearance3.BackColor2 = System.Drawing.Color.Tomato
        Appearance3.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdClose.PressedAppearance = Appearance3
        Me.cmdClose.ShowFocusRect = False
        Me.cmdClose.ShowOutline = False
        Me.cmdClose.Size = New System.Drawing.Size(70, 60)
        Me.cmdClose.StyleSetName = "StatusBar"
        Me.cmdClose.TabIndex = 538
        Me.cmdClose.Tag = "Return"
        Me.cmdClose.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdClose.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdClose.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdPrintSummary
        '
        Me.cmdPrintSummary.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Appearance7.ForeColor = System.Drawing.Color.DimGray
        Appearance7.Image = CType(resources.GetObject("Appearance7.Image"), Object)
        Appearance7.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance7.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance7.TextVAlignAsString = "Bottom"
        Me.cmdPrintSummary.Appearance = Appearance7
        Me.cmdPrintSummary.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdPrintSummary.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance8.BackColor = System.Drawing.Color.DarkOrange
        Appearance8.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance8.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance8.ForeColor = System.Drawing.Color.Black
        Me.cmdPrintSummary.HotTrackAppearance = Appearance8
        Me.cmdPrintSummary.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdPrintSummary.Location = New System.Drawing.Point(823, 6)
        Me.cmdPrintSummary.Name = "cmdPrintSummary"
        Appearance9.BackColor = System.Drawing.Color.OrangeRed
        Appearance9.BackColor2 = System.Drawing.Color.Tomato
        Appearance9.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdPrintSummary.PressedAppearance = Appearance9
        Me.cmdPrintSummary.ShowFocusRect = False
        Me.cmdPrintSummary.ShowOutline = False
        Me.cmdPrintSummary.Size = New System.Drawing.Size(70, 60)
        Me.cmdPrintSummary.StyleSetName = "StatusBar"
        Me.cmdPrintSummary.TabIndex = 539
        Me.cmdPrintSummary.Tag = "Print"
        Me.cmdPrintSummary.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPrintSummary.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPrintSummary.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'upnTextBoxes
        '
        Me.upnTextBoxes.Anchor = System.Windows.Forms.AnchorStyles.Top
        Appearance68.BackColor = System.Drawing.Color.Transparent
        Appearance68.BorderColor = System.Drawing.Color.Silver
        Me.upnTextBoxes.Appearance = Appearance68
        Me.upnTextBoxes.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded4
        '
        'upnTextBoxes.ClientArea
        '
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.txtGrandTotalTotal)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.txtTipsTotal)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.txtGrandCards)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.lblCTotal)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.txtGrandCash)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.txtTipsCard)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.txtGrandOther)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.lblCards)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.txtOLTotalTotal)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.txtTipsCash)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.txtOLTotalCards)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.lblOther)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.txtOLTotalCash)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.txtTipsOther)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.txtOLTotalOther)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.lblCash)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.txtR5C4)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.txtBankTotal)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.txtR5C2)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.txtCTotal)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.txtR5C1)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.txtBankCard)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.txtR5C3)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.txtCCards)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.txtR4C4)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.txtBankCash)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.txtR4C2)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.txtCCash)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.txtR4C1)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.txtBankOther)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.txtR4C3)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.txtCOther)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.txtR3C4)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.txtTotalTotal)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.txtR3C2)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.txtDTotal)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.txtR3C1)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.txtTotalCards)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.txtR3C3)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.txtDCards)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.txtR2C4)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.txtTotalCash)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.txtR2C2)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.txtTotalOther)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.txtR2C1)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.txtDCash)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.txtR2C3)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.txtDOther)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.txtR1C4)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.txtTTotal)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.txtR1C2)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.txtExpenses)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.txtR1C1)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.txtR1C3)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.txtTCards)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.UltraLabel5)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.txtTCash)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.txtTOther)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.lblOL5)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.lblBanking)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.lblOL4)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.lblRTotal)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.lblOLTotal)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.lblTables)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.lblOL3)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.lblCollections)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.UltraLabel16)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.lblDeliveries)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.lblOL2)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.lblExpenses)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.lblOL1)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.UltraButton2)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.cmdCopyBank)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.UltraButton1)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.cmdDoOLSums)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.cmdDoAllGrandTotals)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.UltraPanel3)
        Me.upnTextBoxes.ClientArea.Controls.Add(Me.cmdDoSums)
        Me.upnTextBoxes.ForeColor = System.Drawing.Color.DimGray
        Me.upnTextBoxes.Location = New System.Drawing.Point(12, 106)
        Me.upnTextBoxes.Name = "upnTextBoxes"
        Me.upnTextBoxes.Size = New System.Drawing.Size(979, 611)
        Me.upnTextBoxes.TabIndex = 544
        '
        'txtGrandTotalTotal
        '
        Appearance69.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Appearance69.BorderColor = System.Drawing.Color.LightGray
        Appearance69.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Appearance69.TextHAlignAsString = "Right"
        Me.txtGrandTotalTotal.Appearance = Appearance69
        Me.txtGrandTotalTotal.AutoSize = False
        Me.txtGrandTotalTotal.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.txtGrandTotalTotal.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtGrandTotalTotal.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtGrandTotalTotal.Location = New System.Drawing.Point(507, 527)
        Me.txtGrandTotalTotal.MaxLength = 50
        Me.txtGrandTotalTotal.Name = "txtGrandTotalTotal"
        Me.txtGrandTotalTotal.Size = New System.Drawing.Size(112, 28)
        Me.txtGrandTotalTotal.StyleSetName = "TextEntry"
        Me.txtGrandTotalTotal.TabIndex = 727
        Me.txtGrandTotalTotal.Text = "0.00"
        Me.txtGrandTotalTotal.UseAppStyling = False
        Me.txtGrandTotalTotal.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtGrandTotalTotal.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtTipsTotal
        '
        Appearance70.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Appearance70.BorderColor = System.Drawing.Color.LightGray
        Appearance70.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Appearance70.TextHAlignAsString = "Right"
        Me.txtTipsTotal.Appearance = Appearance70
        Me.txtTipsTotal.AutoSize = False
        Me.txtTipsTotal.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.txtTipsTotal.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtTipsTotal.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTipsTotal.Location = New System.Drawing.Point(507, 211)
        Me.txtTipsTotal.MaxLength = 50
        Me.txtTipsTotal.Name = "txtTipsTotal"
        Me.txtTipsTotal.Size = New System.Drawing.Size(112, 28)
        Me.txtTipsTotal.StyleSetName = "TextEntry"
        Me.txtTipsTotal.TabIndex = 711
        Me.txtTipsTotal.Text = "0.00"
        Me.txtTipsTotal.UseAppStyling = False
        Me.txtTipsTotal.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtTipsTotal.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtGrandCards
        '
        Appearance71.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Appearance71.BorderColor = System.Drawing.Color.LightGray
        Appearance71.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Appearance71.TextHAlignAsString = "Right"
        Me.txtGrandCards.Appearance = Appearance71
        Me.txtGrandCards.AutoSize = False
        Me.txtGrandCards.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.txtGrandCards.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtGrandCards.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtGrandCards.Location = New System.Drawing.Point(271, 527)
        Me.txtGrandCards.MaxLength = 50
        Me.txtGrandCards.Name = "txtGrandCards"
        Me.txtGrandCards.Size = New System.Drawing.Size(112, 28)
        Me.txtGrandCards.StyleSetName = "TextEntry"
        Me.txtGrandCards.TabIndex = 726
        Me.txtGrandCards.Text = "0.00"
        Me.txtGrandCards.UseAppStyling = False
        Me.txtGrandCards.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtGrandCards.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblCTotal
        '
        Appearance72.BackColor = System.Drawing.Color.Transparent
        Appearance72.ForeColor = System.Drawing.Color.DimGray
        Appearance72.TextHAlignAsString = "Right"
        Me.lblCTotal.Appearance = Appearance72
        Me.lblCTotal.AutoSize = True
        Me.lblCTotal.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCTotal.Location = New System.Drawing.Point(572, 15)
        Me.lblCTotal.Name = "lblCTotal"
        Me.lblCTotal.Size = New System.Drawing.Size(47, 20)
        Me.lblCTotal.StyleSetName = "TextEntryLabel"
        Me.lblCTotal.TabIndex = 686
        Me.lblCTotal.Text = "Total:"
        Me.lblCTotal.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtGrandCash
        '
        Appearance73.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Appearance73.BorderColor = System.Drawing.Color.LightGray
        Appearance73.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Appearance73.TextHAlignAsString = "Right"
        Me.txtGrandCash.Appearance = Appearance73
        Me.txtGrandCash.AutoSize = False
        Me.txtGrandCash.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.txtGrandCash.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtGrandCash.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtGrandCash.Location = New System.Drawing.Point(153, 527)
        Me.txtGrandCash.MaxLength = 50
        Me.txtGrandCash.Name = "txtGrandCash"
        Me.txtGrandCash.Size = New System.Drawing.Size(112, 28)
        Me.txtGrandCash.StyleSetName = "TextEntry"
        Me.txtGrandCash.TabIndex = 725
        Me.txtGrandCash.Text = "0.00"
        Me.txtGrandCash.UseAppStyling = False
        Me.txtGrandCash.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtGrandCash.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtTipsCard
        '
        Appearance74.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance74.BorderColor = System.Drawing.Color.LightGray
        Appearance74.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Appearance74.TextHAlignAsString = "Right"
        Me.txtTipsCard.Appearance = Appearance74
        Me.txtTipsCard.AutoSize = False
        Me.txtTipsCard.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtTipsCard.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtTipsCard.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTipsCard.Location = New System.Drawing.Point(271, 211)
        Me.txtTipsCard.MaxLength = 50
        Me.txtTipsCard.Name = "txtTipsCard"
        Me.txtTipsCard.Size = New System.Drawing.Size(112, 28)
        Me.txtTipsCard.StyleSetName = "TextEntry"
        Me.txtTipsCard.TabIndex = 710
        Me.txtTipsCard.Text = "0.00"
        Me.txtTipsCard.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtTipsCard.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtGrandOther
        '
        Appearance75.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Appearance75.BorderColor = System.Drawing.Color.LightGray
        Appearance75.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Appearance75.TextHAlignAsString = "Right"
        Me.txtGrandOther.Appearance = Appearance75
        Me.txtGrandOther.AutoSize = False
        Me.txtGrandOther.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.txtGrandOther.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtGrandOther.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtGrandOther.Location = New System.Drawing.Point(389, 527)
        Me.txtGrandOther.MaxLength = 50
        Me.txtGrandOther.Name = "txtGrandOther"
        Me.txtGrandOther.Size = New System.Drawing.Size(112, 28)
        Me.txtGrandOther.StyleSetName = "TextEntry"
        Me.txtGrandOther.TabIndex = 724
        Me.txtGrandOther.Text = "0.00"
        Me.txtGrandOther.UseAppStyling = False
        Me.txtGrandOther.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtGrandOther.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblCards
        '
        Appearance76.BackColor = System.Drawing.Color.Transparent
        Appearance76.ForeColor = System.Drawing.Color.DimGray
        Appearance76.TextHAlignAsString = "Right"
        Me.lblCards.Appearance = Appearance76
        Me.lblCards.AutoSize = True
        Me.lblCards.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCards.Location = New System.Drawing.Point(329, 15)
        Me.lblCards.Name = "lblCards"
        Me.lblCards.Size = New System.Drawing.Size(54, 20)
        Me.lblCards.StyleSetName = "TextEntryLabel"
        Me.lblCards.TabIndex = 684
        Me.lblCards.Text = "Cards:"
        Me.lblCards.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtOLTotalTotal
        '
        Appearance77.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Appearance77.BorderColor = System.Drawing.Color.LightGray
        Appearance77.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Appearance77.TextHAlignAsString = "Right"
        Me.txtOLTotalTotal.Appearance = Appearance77
        Me.txtOLTotalTotal.AutoSize = False
        Me.txtOLTotalTotal.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.txtOLTotalTotal.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtOLTotalTotal.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtOLTotalTotal.Location = New System.Drawing.Point(507, 455)
        Me.txtOLTotalTotal.MaxLength = 50
        Me.txtOLTotalTotal.Name = "txtOLTotalTotal"
        Me.txtOLTotalTotal.Size = New System.Drawing.Size(112, 28)
        Me.txtOLTotalTotal.StyleSetName = "TextEntry"
        Me.txtOLTotalTotal.TabIndex = 723
        Me.txtOLTotalTotal.Text = "0.00"
        Me.txtOLTotalTotal.UseAppStyling = False
        Me.txtOLTotalTotal.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtOLTotalTotal.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtTipsCash
        '
        Appearance78.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance78.BorderColor = System.Drawing.Color.LightGray
        Appearance78.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Appearance78.TextHAlignAsString = "Right"
        Me.txtTipsCash.Appearance = Appearance78
        Me.txtTipsCash.AutoSize = False
        Me.txtTipsCash.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtTipsCash.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtTipsCash.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTipsCash.Location = New System.Drawing.Point(153, 211)
        Me.txtTipsCash.MaxLength = 50
        Me.txtTipsCash.Name = "txtTipsCash"
        Me.txtTipsCash.Size = New System.Drawing.Size(112, 28)
        Me.txtTipsCash.StyleSetName = "TextEntry"
        Me.txtTipsCash.TabIndex = 709
        Me.txtTipsCash.Text = "0.00"
        Me.txtTipsCash.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtTipsCash.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtOLTotalCards
        '
        Appearance79.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Appearance79.BorderColor = System.Drawing.Color.LightGray
        Appearance79.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Appearance79.TextHAlignAsString = "Right"
        Me.txtOLTotalCards.Appearance = Appearance79
        Me.txtOLTotalCards.AutoSize = False
        Me.txtOLTotalCards.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.txtOLTotalCards.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtOLTotalCards.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtOLTotalCards.Location = New System.Drawing.Point(271, 455)
        Me.txtOLTotalCards.MaxLength = 50
        Me.txtOLTotalCards.Name = "txtOLTotalCards"
        Me.txtOLTotalCards.Size = New System.Drawing.Size(112, 28)
        Me.txtOLTotalCards.StyleSetName = "TextEntry"
        Me.txtOLTotalCards.TabIndex = 722
        Me.txtOLTotalCards.Text = "0.00"
        Me.txtOLTotalCards.UseAppStyling = False
        Me.txtOLTotalCards.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtOLTotalCards.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblOther
        '
        Appearance80.BackColor = System.Drawing.Color.Transparent
        Appearance80.ForeColor = System.Drawing.Color.DimGray
        Appearance80.TextHAlignAsString = "Right"
        Me.lblOther.Appearance = Appearance80
        Me.lblOther.AutoSize = True
        Me.lblOther.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOther.Location = New System.Drawing.Point(449, 15)
        Me.lblOther.Name = "lblOther"
        Me.lblOther.Size = New System.Drawing.Size(52, 20)
        Me.lblOther.StyleSetName = "TextEntryLabel"
        Me.lblOther.TabIndex = 685
        Me.lblOther.Text = "Other:"
        Me.lblOther.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtOLTotalCash
        '
        Appearance81.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Appearance81.BorderColor = System.Drawing.Color.LightGray
        Appearance81.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Appearance81.TextHAlignAsString = "Right"
        Me.txtOLTotalCash.Appearance = Appearance81
        Me.txtOLTotalCash.AutoSize = False
        Me.txtOLTotalCash.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.txtOLTotalCash.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtOLTotalCash.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtOLTotalCash.Location = New System.Drawing.Point(153, 455)
        Me.txtOLTotalCash.MaxLength = 50
        Me.txtOLTotalCash.Name = "txtOLTotalCash"
        Me.txtOLTotalCash.Size = New System.Drawing.Size(112, 28)
        Me.txtOLTotalCash.StyleSetName = "TextEntry"
        Me.txtOLTotalCash.TabIndex = 721
        Me.txtOLTotalCash.Text = "0.00"
        Me.txtOLTotalCash.UseAppStyling = False
        Me.txtOLTotalCash.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtOLTotalCash.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtTipsOther
        '
        Appearance82.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance82.BorderColor = System.Drawing.Color.LightGray
        Appearance82.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Appearance82.TextHAlignAsString = "Right"
        Me.txtTipsOther.Appearance = Appearance82
        Me.txtTipsOther.AutoSize = False
        Me.txtTipsOther.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtTipsOther.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtTipsOther.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTipsOther.Location = New System.Drawing.Point(389, 211)
        Me.txtTipsOther.MaxLength = 50
        Me.txtTipsOther.Name = "txtTipsOther"
        Me.txtTipsOther.Size = New System.Drawing.Size(112, 28)
        Me.txtTipsOther.StyleSetName = "TextEntry"
        Me.txtTipsOther.TabIndex = 708
        Me.txtTipsOther.Text = "0.00"
        Me.txtTipsOther.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtTipsOther.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtOLTotalOther
        '
        Appearance83.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Appearance83.BorderColor = System.Drawing.Color.LightGray
        Appearance83.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Appearance83.TextHAlignAsString = "Right"
        Me.txtOLTotalOther.Appearance = Appearance83
        Me.txtOLTotalOther.AutoSize = False
        Me.txtOLTotalOther.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.txtOLTotalOther.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtOLTotalOther.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtOLTotalOther.Location = New System.Drawing.Point(389, 455)
        Me.txtOLTotalOther.MaxLength = 50
        Me.txtOLTotalOther.Name = "txtOLTotalOther"
        Me.txtOLTotalOther.Size = New System.Drawing.Size(112, 28)
        Me.txtOLTotalOther.StyleSetName = "TextEntry"
        Me.txtOLTotalOther.TabIndex = 720
        Me.txtOLTotalOther.Text = "0.00"
        Me.txtOLTotalOther.UseAppStyling = False
        Me.txtOLTotalOther.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtOLTotalOther.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblCash
        '
        Appearance84.BackColor = System.Drawing.Color.Transparent
        Appearance84.ForeColor = System.Drawing.Color.DimGray
        Appearance84.TextHAlignAsString = "Right"
        Me.lblCash.Appearance = Appearance84
        Me.lblCash.AutoSize = True
        Me.lblCash.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCash.Location = New System.Drawing.Point(216, 15)
        Me.lblCash.Name = "lblCash"
        Me.lblCash.Size = New System.Drawing.Size(49, 20)
        Me.lblCash.StyleSetName = "TextEntryLabel"
        Me.lblCash.TabIndex = 663
        Me.lblCash.Text = "Cash:"
        Me.lblCash.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtR5C4
        '
        Appearance85.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Appearance85.BorderColor = System.Drawing.Color.LightGray
        Appearance85.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Appearance85.TextHAlignAsString = "Right"
        Me.txtR5C4.Appearance = Appearance85
        Me.txtR5C4.AutoSize = False
        Me.txtR5C4.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.txtR5C4.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtR5C4.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtR5C4.Location = New System.Drawing.Point(507, 421)
        Me.txtR5C4.MaxLength = 50
        Me.txtR5C4.Name = "txtR5C4"
        Me.txtR5C4.Size = New System.Drawing.Size(112, 28)
        Me.txtR5C4.StyleSetName = "TextEntry"
        Me.txtR5C4.TabIndex = 719
        Me.txtR5C4.Text = "0.00"
        Me.txtR5C4.UseAppStyling = False
        Me.txtR5C4.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtR5C4.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtBankTotal
        '
        Appearance86.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Appearance86.BorderColor = System.Drawing.Color.LightGray
        Appearance86.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Appearance86.TextHAlignAsString = "Right"
        Me.txtBankTotal.Appearance = Appearance86
        Me.txtBankTotal.AutoSize = False
        Me.txtBankTotal.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.txtBankTotal.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtBankTotal.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBankTotal.Location = New System.Drawing.Point(507, 177)
        Me.txtBankTotal.MaxLength = 50
        Me.txtBankTotal.Name = "txtBankTotal"
        Me.txtBankTotal.Size = New System.Drawing.Size(112, 28)
        Me.txtBankTotal.StyleSetName = "TextEntry"
        Me.txtBankTotal.TabIndex = 707
        Me.txtBankTotal.Text = "0.00"
        Me.txtBankTotal.UseAppStyling = False
        Me.txtBankTotal.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtBankTotal.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtR5C2
        '
        Appearance87.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance87.BorderColor = System.Drawing.Color.LightGray
        Appearance87.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Appearance87.TextHAlignAsString = "Right"
        Me.txtR5C2.Appearance = Appearance87
        Me.txtR5C2.AutoSize = False
        Me.txtR5C2.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtR5C2.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtR5C2.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtR5C2.Location = New System.Drawing.Point(271, 421)
        Me.txtR5C2.MaxLength = 50
        Me.txtR5C2.Name = "txtR5C2"
        Me.txtR5C2.Size = New System.Drawing.Size(112, 28)
        Me.txtR5C2.StyleSetName = "TextEntry"
        Me.txtR5C2.TabIndex = 718
        Me.txtR5C2.Text = "0.00"
        Me.txtR5C2.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtR5C2.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtCTotal
        '
        Appearance88.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Appearance88.BorderColor = System.Drawing.Color.LightGray
        Appearance88.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Appearance88.TextHAlignAsString = "Right"
        Me.txtCTotal.Appearance = Appearance88
        Me.txtCTotal.AutoSize = False
        Me.txtCTotal.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.txtCTotal.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtCTotal.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCTotal.Location = New System.Drawing.Point(507, 75)
        Me.txtCTotal.MaxLength = 50
        Me.txtCTotal.Name = "txtCTotal"
        Me.txtCTotal.Size = New System.Drawing.Size(112, 28)
        Me.txtCTotal.StyleSetName = "TextEntry"
        Me.txtCTotal.TabIndex = 683
        Me.txtCTotal.Text = "0.00"
        Me.txtCTotal.UseAppStyling = False
        Me.txtCTotal.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtCTotal.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtR5C1
        '
        Appearance89.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance89.BorderColor = System.Drawing.Color.LightGray
        Appearance89.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Appearance89.TextHAlignAsString = "Right"
        Me.txtR5C1.Appearance = Appearance89
        Me.txtR5C1.AutoSize = False
        Me.txtR5C1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtR5C1.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtR5C1.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtR5C1.Location = New System.Drawing.Point(153, 421)
        Me.txtR5C1.MaxLength = 50
        Me.txtR5C1.Name = "txtR5C1"
        Me.txtR5C1.Size = New System.Drawing.Size(112, 28)
        Me.txtR5C1.StyleSetName = "TextEntry"
        Me.txtR5C1.TabIndex = 717
        Me.txtR5C1.Text = "0.00"
        Me.txtR5C1.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtR5C1.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtBankCard
        '
        Appearance90.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance90.BorderColor = System.Drawing.Color.LightGray
        Appearance90.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Appearance90.TextHAlignAsString = "Right"
        Me.txtBankCard.Appearance = Appearance90
        Me.txtBankCard.AutoSize = False
        Me.txtBankCard.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtBankCard.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtBankCard.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBankCard.Location = New System.Drawing.Point(271, 177)
        Me.txtBankCard.MaxLength = 50
        Me.txtBankCard.Name = "txtBankCard"
        Me.txtBankCard.Size = New System.Drawing.Size(112, 28)
        Me.txtBankCard.StyleSetName = "TextEntry"
        Me.txtBankCard.TabIndex = 706
        Me.txtBankCard.Text = "0.00"
        Me.txtBankCard.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtBankCard.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtR5C3
        '
        Appearance91.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance91.BorderColor = System.Drawing.Color.LightGray
        Appearance91.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Appearance91.TextHAlignAsString = "Right"
        Me.txtR5C3.Appearance = Appearance91
        Me.txtR5C3.AutoSize = False
        Me.txtR5C3.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtR5C3.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtR5C3.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtR5C3.Location = New System.Drawing.Point(389, 421)
        Me.txtR5C3.MaxLength = 50
        Me.txtR5C3.Name = "txtR5C3"
        Me.txtR5C3.Size = New System.Drawing.Size(112, 28)
        Me.txtR5C3.StyleSetName = "TextEntry"
        Me.txtR5C3.TabIndex = 716
        Me.txtR5C3.Text = "0.00"
        Me.txtR5C3.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtR5C3.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtCCards
        '
        Appearance92.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance92.BorderColor = System.Drawing.Color.LightGray
        Appearance92.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Appearance92.TextHAlignAsString = "Right"
        Me.txtCCards.Appearance = Appearance92
        Me.txtCCards.AutoSize = False
        Me.txtCCards.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtCCards.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtCCards.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCCards.Location = New System.Drawing.Point(271, 75)
        Me.txtCCards.MaxLength = 50
        Me.txtCCards.Name = "txtCCards"
        Me.txtCCards.Size = New System.Drawing.Size(112, 28)
        Me.txtCCards.StyleSetName = "TextEntry"
        Me.txtCCards.TabIndex = 682
        Me.txtCCards.Text = "0.00"
        Me.txtCCards.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtCCards.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtR4C4
        '
        Appearance93.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Appearance93.BorderColor = System.Drawing.Color.LightGray
        Appearance93.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Appearance93.TextHAlignAsString = "Right"
        Me.txtR4C4.Appearance = Appearance93
        Me.txtR4C4.AutoSize = False
        Me.txtR4C4.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.txtR4C4.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtR4C4.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtR4C4.Location = New System.Drawing.Point(507, 387)
        Me.txtR4C4.MaxLength = 50
        Me.txtR4C4.Name = "txtR4C4"
        Me.txtR4C4.Size = New System.Drawing.Size(112, 28)
        Me.txtR4C4.StyleSetName = "TextEntry"
        Me.txtR4C4.TabIndex = 715
        Me.txtR4C4.Text = "0.00"
        Me.txtR4C4.UseAppStyling = False
        Me.txtR4C4.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtR4C4.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtBankCash
        '
        Appearance94.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance94.BorderColor = System.Drawing.Color.LightGray
        Appearance94.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Appearance94.TextHAlignAsString = "Right"
        Me.txtBankCash.Appearance = Appearance94
        Me.txtBankCash.AutoSize = False
        Me.txtBankCash.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtBankCash.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtBankCash.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBankCash.Location = New System.Drawing.Point(153, 177)
        Me.txtBankCash.MaxLength = 50
        Me.txtBankCash.Name = "txtBankCash"
        Me.txtBankCash.Size = New System.Drawing.Size(112, 28)
        Me.txtBankCash.StyleSetName = "TextEntry"
        Me.txtBankCash.TabIndex = 705
        Me.txtBankCash.Text = "0.00"
        Me.txtBankCash.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtBankCash.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtR4C2
        '
        Appearance95.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance95.BorderColor = System.Drawing.Color.LightGray
        Appearance95.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Appearance95.TextHAlignAsString = "Right"
        Me.txtR4C2.Appearance = Appearance95
        Me.txtR4C2.AutoSize = False
        Me.txtR4C2.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtR4C2.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtR4C2.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtR4C2.Location = New System.Drawing.Point(271, 387)
        Me.txtR4C2.MaxLength = 50
        Me.txtR4C2.Name = "txtR4C2"
        Me.txtR4C2.Size = New System.Drawing.Size(112, 28)
        Me.txtR4C2.StyleSetName = "TextEntry"
        Me.txtR4C2.TabIndex = 714
        Me.txtR4C2.Text = "0.00"
        Me.txtR4C2.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtR4C2.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtCCash
        '
        Appearance96.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance96.BorderColor = System.Drawing.Color.LightGray
        Appearance96.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Appearance96.TextHAlignAsString = "Right"
        Me.txtCCash.Appearance = Appearance96
        Me.txtCCash.AutoSize = False
        Me.txtCCash.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtCCash.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtCCash.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCCash.Location = New System.Drawing.Point(153, 75)
        Me.txtCCash.MaxLength = 50
        Me.txtCCash.Name = "txtCCash"
        Me.txtCCash.Size = New System.Drawing.Size(112, 28)
        Me.txtCCash.StyleSetName = "TextEntry"
        Me.txtCCash.TabIndex = 681
        Me.txtCCash.Text = "0.00"
        Me.txtCCash.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtCCash.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtR4C1
        '
        Appearance97.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance97.BorderColor = System.Drawing.Color.LightGray
        Appearance97.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Appearance97.TextHAlignAsString = "Right"
        Me.txtR4C1.Appearance = Appearance97
        Me.txtR4C1.AutoSize = False
        Me.txtR4C1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtR4C1.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtR4C1.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtR4C1.Location = New System.Drawing.Point(153, 387)
        Me.txtR4C1.MaxLength = 50
        Me.txtR4C1.Name = "txtR4C1"
        Me.txtR4C1.Size = New System.Drawing.Size(112, 28)
        Me.txtR4C1.StyleSetName = "TextEntry"
        Me.txtR4C1.TabIndex = 713
        Me.txtR4C1.Text = "0.00"
        Me.txtR4C1.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtR4C1.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtBankOther
        '
        Appearance98.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance98.BorderColor = System.Drawing.Color.LightGray
        Appearance98.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Appearance98.TextHAlignAsString = "Right"
        Me.txtBankOther.Appearance = Appearance98
        Me.txtBankOther.AutoSize = False
        Me.txtBankOther.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtBankOther.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtBankOther.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBankOther.Location = New System.Drawing.Point(389, 177)
        Me.txtBankOther.MaxLength = 50
        Me.txtBankOther.Name = "txtBankOther"
        Me.txtBankOther.Size = New System.Drawing.Size(112, 28)
        Me.txtBankOther.StyleSetName = "TextEntry"
        Me.txtBankOther.TabIndex = 704
        Me.txtBankOther.Text = "0.00"
        Me.txtBankOther.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtBankOther.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtR4C3
        '
        Appearance99.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance99.BorderColor = System.Drawing.Color.LightGray
        Appearance99.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Appearance99.TextHAlignAsString = "Right"
        Me.txtR4C3.Appearance = Appearance99
        Me.txtR4C3.AutoSize = False
        Me.txtR4C3.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtR4C3.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtR4C3.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtR4C3.Location = New System.Drawing.Point(389, 387)
        Me.txtR4C3.MaxLength = 50
        Me.txtR4C3.Name = "txtR4C3"
        Me.txtR4C3.Size = New System.Drawing.Size(112, 28)
        Me.txtR4C3.StyleSetName = "TextEntry"
        Me.txtR4C3.TabIndex = 712
        Me.txtR4C3.Text = "0.00"
        Me.txtR4C3.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtR4C3.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtCOther
        '
        Appearance100.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance100.BorderColor = System.Drawing.Color.LightGray
        Appearance100.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Appearance100.TextHAlignAsString = "Right"
        Me.txtCOther.Appearance = Appearance100
        Me.txtCOther.AutoSize = False
        Me.txtCOther.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtCOther.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtCOther.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCOther.Location = New System.Drawing.Point(389, 75)
        Me.txtCOther.MaxLength = 50
        Me.txtCOther.Name = "txtCOther"
        Me.txtCOther.Size = New System.Drawing.Size(112, 28)
        Me.txtCOther.StyleSetName = "TextEntry"
        Me.txtCOther.TabIndex = 680
        Me.txtCOther.Text = "0.00"
        Me.txtCOther.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtCOther.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtR3C4
        '
        Appearance101.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Appearance101.BorderColor = System.Drawing.Color.LightGray
        Appearance101.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Appearance101.TextHAlignAsString = "Right"
        Me.txtR3C4.Appearance = Appearance101
        Me.txtR3C4.AutoSize = False
        Me.txtR3C4.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.txtR3C4.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtR3C4.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtR3C4.Location = New System.Drawing.Point(507, 353)
        Me.txtR3C4.MaxLength = 50
        Me.txtR3C4.Name = "txtR3C4"
        Me.txtR3C4.Size = New System.Drawing.Size(112, 28)
        Me.txtR3C4.StyleSetName = "TextEntry"
        Me.txtR3C4.TabIndex = 711
        Me.txtR3C4.Text = "0.00"
        Me.txtR3C4.UseAppStyling = False
        Me.txtR3C4.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtR3C4.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtTotalTotal
        '
        Appearance102.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Appearance102.BorderColor = System.Drawing.Color.LightGray
        Appearance102.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Appearance102.TextHAlignAsString = "Right"
        Me.txtTotalTotal.Appearance = Appearance102
        Me.txtTotalTotal.AutoSize = False
        Me.txtTotalTotal.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.txtTotalTotal.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtTotalTotal.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotalTotal.Location = New System.Drawing.Point(507, 143)
        Me.txtTotalTotal.MaxLength = 50
        Me.txtTotalTotal.Name = "txtTotalTotal"
        Me.txtTotalTotal.Size = New System.Drawing.Size(112, 28)
        Me.txtTotalTotal.StyleSetName = "TextEntry"
        Me.txtTotalTotal.TabIndex = 703
        Me.txtTotalTotal.Text = "0.00"
        Me.txtTotalTotal.UseAppStyling = False
        Me.txtTotalTotal.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtTotalTotal.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtR3C2
        '
        Appearance103.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance103.BorderColor = System.Drawing.Color.LightGray
        Appearance103.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Appearance103.TextHAlignAsString = "Right"
        Me.txtR3C2.Appearance = Appearance103
        Me.txtR3C2.AutoSize = False
        Me.txtR3C2.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtR3C2.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtR3C2.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtR3C2.Location = New System.Drawing.Point(271, 353)
        Me.txtR3C2.MaxLength = 50
        Me.txtR3C2.Name = "txtR3C2"
        Me.txtR3C2.Size = New System.Drawing.Size(112, 28)
        Me.txtR3C2.StyleSetName = "TextEntry"
        Me.txtR3C2.TabIndex = 710
        Me.txtR3C2.Text = "0.00"
        Me.txtR3C2.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtR3C2.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtDTotal
        '
        Appearance104.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Appearance104.BorderColor = System.Drawing.Color.LightGray
        Appearance104.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Appearance104.TextHAlignAsString = "Right"
        Me.txtDTotal.Appearance = Appearance104
        Me.txtDTotal.AutoSize = False
        Me.txtDTotal.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.txtDTotal.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtDTotal.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDTotal.Location = New System.Drawing.Point(507, 41)
        Me.txtDTotal.MaxLength = 50
        Me.txtDTotal.Name = "txtDTotal"
        Me.txtDTotal.Size = New System.Drawing.Size(112, 28)
        Me.txtDTotal.StyleSetName = "TextEntry"
        Me.txtDTotal.TabIndex = 679
        Me.txtDTotal.Text = "0.00"
        Me.txtDTotal.UseAppStyling = False
        Me.txtDTotal.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtDTotal.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtR3C1
        '
        Appearance105.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance105.BorderColor = System.Drawing.Color.LightGray
        Appearance105.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Appearance105.TextHAlignAsString = "Right"
        Me.txtR3C1.Appearance = Appearance105
        Me.txtR3C1.AutoSize = False
        Me.txtR3C1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtR3C1.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtR3C1.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtR3C1.Location = New System.Drawing.Point(153, 353)
        Me.txtR3C1.MaxLength = 50
        Me.txtR3C1.Name = "txtR3C1"
        Me.txtR3C1.Size = New System.Drawing.Size(112, 28)
        Me.txtR3C1.StyleSetName = "TextEntry"
        Me.txtR3C1.TabIndex = 709
        Me.txtR3C1.Text = "0.00"
        Me.txtR3C1.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtR3C1.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtTotalCards
        '
        Appearance106.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Appearance106.BorderColor = System.Drawing.Color.LightGray
        Appearance106.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Appearance106.TextHAlignAsString = "Right"
        Me.txtTotalCards.Appearance = Appearance106
        Me.txtTotalCards.AutoSize = False
        Me.txtTotalCards.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.txtTotalCards.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtTotalCards.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotalCards.Location = New System.Drawing.Point(271, 143)
        Me.txtTotalCards.MaxLength = 50
        Me.txtTotalCards.Name = "txtTotalCards"
        Me.txtTotalCards.Size = New System.Drawing.Size(112, 28)
        Me.txtTotalCards.StyleSetName = "TextEntry"
        Me.txtTotalCards.TabIndex = 702
        Me.txtTotalCards.Text = "0.00"
        Me.txtTotalCards.UseAppStyling = False
        Me.txtTotalCards.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtTotalCards.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtR3C3
        '
        Appearance107.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance107.BorderColor = System.Drawing.Color.LightGray
        Appearance107.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Appearance107.TextHAlignAsString = "Right"
        Me.txtR3C3.Appearance = Appearance107
        Me.txtR3C3.AutoSize = False
        Me.txtR3C3.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtR3C3.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtR3C3.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtR3C3.Location = New System.Drawing.Point(389, 353)
        Me.txtR3C3.MaxLength = 50
        Me.txtR3C3.Name = "txtR3C3"
        Me.txtR3C3.Size = New System.Drawing.Size(112, 28)
        Me.txtR3C3.StyleSetName = "TextEntry"
        Me.txtR3C3.TabIndex = 708
        Me.txtR3C3.Text = "0.00"
        Me.txtR3C3.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtR3C3.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtDCards
        '
        Appearance108.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance108.BorderColor = System.Drawing.Color.LightGray
        Appearance108.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Appearance108.TextHAlignAsString = "Right"
        Me.txtDCards.Appearance = Appearance108
        Me.txtDCards.AutoSize = False
        Me.txtDCards.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtDCards.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtDCards.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDCards.Location = New System.Drawing.Point(271, 41)
        Me.txtDCards.MaxLength = 50
        Me.txtDCards.Name = "txtDCards"
        Me.txtDCards.Size = New System.Drawing.Size(112, 28)
        Me.txtDCards.StyleSetName = "TextEntry"
        Me.txtDCards.TabIndex = 678
        Me.txtDCards.Text = "0.00"
        Me.txtDCards.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtDCards.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtR2C4
        '
        Appearance109.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Appearance109.BorderColor = System.Drawing.Color.LightGray
        Appearance109.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Appearance109.TextHAlignAsString = "Right"
        Me.txtR2C4.Appearance = Appearance109
        Me.txtR2C4.AutoSize = False
        Me.txtR2C4.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.txtR2C4.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtR2C4.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtR2C4.Location = New System.Drawing.Point(507, 319)
        Me.txtR2C4.MaxLength = 50
        Me.txtR2C4.Name = "txtR2C4"
        Me.txtR2C4.Size = New System.Drawing.Size(112, 28)
        Me.txtR2C4.StyleSetName = "TextEntry"
        Me.txtR2C4.TabIndex = 707
        Me.txtR2C4.Text = "0.00"
        Me.txtR2C4.UseAppStyling = False
        Me.txtR2C4.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtR2C4.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtTotalCash
        '
        Appearance110.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Appearance110.BorderColor = System.Drawing.Color.LightGray
        Appearance110.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Appearance110.TextHAlignAsString = "Right"
        Me.txtTotalCash.Appearance = Appearance110
        Me.txtTotalCash.AutoSize = False
        Me.txtTotalCash.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.txtTotalCash.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtTotalCash.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotalCash.Location = New System.Drawing.Point(153, 143)
        Me.txtTotalCash.MaxLength = 50
        Me.txtTotalCash.Name = "txtTotalCash"
        Me.txtTotalCash.Size = New System.Drawing.Size(112, 28)
        Me.txtTotalCash.StyleSetName = "TextEntry"
        Me.txtTotalCash.TabIndex = 701
        Me.txtTotalCash.Text = "0.00"
        Me.txtTotalCash.UseAppStyling = False
        Me.txtTotalCash.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtTotalCash.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtR2C2
        '
        Appearance111.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance111.BorderColor = System.Drawing.Color.LightGray
        Appearance111.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Appearance111.TextHAlignAsString = "Right"
        Me.txtR2C2.Appearance = Appearance111
        Me.txtR2C2.AutoSize = False
        Me.txtR2C2.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtR2C2.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtR2C2.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtR2C2.Location = New System.Drawing.Point(271, 319)
        Me.txtR2C2.MaxLength = 50
        Me.txtR2C2.Name = "txtR2C2"
        Me.txtR2C2.Size = New System.Drawing.Size(112, 28)
        Me.txtR2C2.StyleSetName = "TextEntry"
        Me.txtR2C2.TabIndex = 706
        Me.txtR2C2.Text = "0.00"
        Me.txtR2C2.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtR2C2.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtTotalOther
        '
        Appearance112.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Appearance112.BorderColor = System.Drawing.Color.LightGray
        Appearance112.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Appearance112.TextHAlignAsString = "Right"
        Me.txtTotalOther.Appearance = Appearance112
        Me.txtTotalOther.AutoSize = False
        Me.txtTotalOther.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.txtTotalOther.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtTotalOther.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotalOther.Location = New System.Drawing.Point(389, 143)
        Me.txtTotalOther.MaxLength = 50
        Me.txtTotalOther.Name = "txtTotalOther"
        Me.txtTotalOther.Size = New System.Drawing.Size(112, 28)
        Me.txtTotalOther.StyleSetName = "TextEntry"
        Me.txtTotalOther.TabIndex = 700
        Me.txtTotalOther.Text = "0.00"
        Me.txtTotalOther.UseAppStyling = False
        Me.txtTotalOther.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtTotalOther.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtR2C1
        '
        Appearance113.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance113.BorderColor = System.Drawing.Color.LightGray
        Appearance113.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Appearance113.TextHAlignAsString = "Right"
        Me.txtR2C1.Appearance = Appearance113
        Me.txtR2C1.AutoSize = False
        Me.txtR2C1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtR2C1.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtR2C1.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtR2C1.Location = New System.Drawing.Point(153, 319)
        Me.txtR2C1.MaxLength = 50
        Me.txtR2C1.Name = "txtR2C1"
        Me.txtR2C1.Size = New System.Drawing.Size(112, 28)
        Me.txtR2C1.StyleSetName = "TextEntry"
        Me.txtR2C1.TabIndex = 705
        Me.txtR2C1.Text = "0.00"
        Me.txtR2C1.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtR2C1.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtDCash
        '
        Appearance114.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance114.BorderColor = System.Drawing.Color.LightGray
        Appearance114.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Appearance114.TextHAlignAsString = "Right"
        Me.txtDCash.Appearance = Appearance114
        Me.txtDCash.AutoSize = False
        Me.txtDCash.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtDCash.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtDCash.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDCash.Location = New System.Drawing.Point(153, 41)
        Me.txtDCash.MaxLength = 50
        Me.txtDCash.Name = "txtDCash"
        Me.txtDCash.Size = New System.Drawing.Size(112, 28)
        Me.txtDCash.StyleSetName = "TextEntry"
        Me.txtDCash.TabIndex = 677
        Me.txtDCash.Text = "0.00"
        Me.txtDCash.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtDCash.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtR2C3
        '
        Appearance115.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance115.BorderColor = System.Drawing.Color.LightGray
        Appearance115.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Appearance115.TextHAlignAsString = "Right"
        Me.txtR2C3.Appearance = Appearance115
        Me.txtR2C3.AutoSize = False
        Me.txtR2C3.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtR2C3.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtR2C3.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtR2C3.Location = New System.Drawing.Point(389, 319)
        Me.txtR2C3.MaxLength = 50
        Me.txtR2C3.Name = "txtR2C3"
        Me.txtR2C3.Size = New System.Drawing.Size(112, 28)
        Me.txtR2C3.StyleSetName = "TextEntry"
        Me.txtR2C3.TabIndex = 704
        Me.txtR2C3.Text = "0.00"
        Me.txtR2C3.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtR2C3.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtDOther
        '
        Appearance116.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance116.BorderColor = System.Drawing.Color.LightGray
        Appearance116.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Appearance116.TextHAlignAsString = "Right"
        Me.txtDOther.Appearance = Appearance116
        Me.txtDOther.AutoSize = False
        Me.txtDOther.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtDOther.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtDOther.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDOther.Location = New System.Drawing.Point(389, 41)
        Me.txtDOther.MaxLength = 50
        Me.txtDOther.Name = "txtDOther"
        Me.txtDOther.Size = New System.Drawing.Size(112, 28)
        Me.txtDOther.StyleSetName = "TextEntry"
        Me.txtDOther.TabIndex = 676
        Me.txtDOther.Text = "0.00"
        Me.txtDOther.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtDOther.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtR1C4
        '
        Appearance117.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Appearance117.BorderColor = System.Drawing.Color.LightGray
        Appearance117.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Appearance117.TextHAlignAsString = "Right"
        Me.txtR1C4.Appearance = Appearance117
        Me.txtR1C4.AutoSize = False
        Me.txtR1C4.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.txtR1C4.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtR1C4.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtR1C4.Location = New System.Drawing.Point(507, 285)
        Me.txtR1C4.MaxLength = 50
        Me.txtR1C4.Name = "txtR1C4"
        Me.txtR1C4.Size = New System.Drawing.Size(112, 28)
        Me.txtR1C4.StyleSetName = "TextEntry"
        Me.txtR1C4.TabIndex = 703
        Me.txtR1C4.Text = "0.00"
        Me.txtR1C4.UseAppStyling = False
        Me.txtR1C4.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtR1C4.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtTTotal
        '
        Appearance118.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Appearance118.BorderColor = System.Drawing.Color.LightGray
        Appearance118.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Appearance118.TextHAlignAsString = "Right"
        Me.txtTTotal.Appearance = Appearance118
        Me.txtTTotal.AutoSize = False
        Me.txtTTotal.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.txtTTotal.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtTTotal.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTTotal.Location = New System.Drawing.Point(507, 109)
        Me.txtTTotal.MaxLength = 50
        Me.txtTTotal.Name = "txtTTotal"
        Me.txtTTotal.Size = New System.Drawing.Size(112, 28)
        Me.txtTTotal.StyleSetName = "TextEntry"
        Me.txtTTotal.TabIndex = 687
        Me.txtTTotal.Text = "0.00"
        Me.txtTTotal.UseAppStyling = False
        Me.txtTTotal.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtTTotal.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtR1C2
        '
        Appearance119.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance119.BorderColor = System.Drawing.Color.LightGray
        Appearance119.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Appearance119.TextHAlignAsString = "Right"
        Me.txtR1C2.Appearance = Appearance119
        Me.txtR1C2.AutoSize = False
        Me.txtR1C2.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtR1C2.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtR1C2.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtR1C2.Location = New System.Drawing.Point(271, 285)
        Me.txtR1C2.MaxLength = 50
        Me.txtR1C2.Name = "txtR1C2"
        Me.txtR1C2.Size = New System.Drawing.Size(112, 28)
        Me.txtR1C2.StyleSetName = "TextEntry"
        Me.txtR1C2.TabIndex = 702
        Me.txtR1C2.Text = "0.00"
        Me.txtR1C2.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtR1C2.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtExpenses
        '
        Appearance120.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance120.BorderColor = System.Drawing.Color.LightGray
        Appearance120.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Appearance120.TextHAlignAsString = "Right"
        Me.txtExpenses.Appearance = Appearance120
        Me.txtExpenses.AutoSize = False
        Me.txtExpenses.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtExpenses.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtExpenses.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtExpenses.Location = New System.Drawing.Point(785, 75)
        Me.txtExpenses.MaxLength = 50
        Me.txtExpenses.Name = "txtExpenses"
        Me.txtExpenses.Size = New System.Drawing.Size(129, 28)
        Me.txtExpenses.StyleSetName = "TextEntry"
        Me.txtExpenses.TabIndex = 675
        Me.txtExpenses.Text = "0.00"
        Me.txtExpenses.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtExpenses.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtR1C1
        '
        Appearance121.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance121.BorderColor = System.Drawing.Color.LightGray
        Appearance121.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Appearance121.TextHAlignAsString = "Right"
        Me.txtR1C1.Appearance = Appearance121
        Me.txtR1C1.AutoSize = False
        Me.txtR1C1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtR1C1.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtR1C1.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtR1C1.Location = New System.Drawing.Point(153, 285)
        Me.txtR1C1.MaxLength = 50
        Me.txtR1C1.Name = "txtR1C1"
        Me.txtR1C1.Size = New System.Drawing.Size(112, 28)
        Me.txtR1C1.StyleSetName = "TextEntry"
        Me.txtR1C1.TabIndex = 701
        Me.txtR1C1.Text = "0.00"
        Me.txtR1C1.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtR1C1.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtR1C3
        '
        Appearance122.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance122.BorderColor = System.Drawing.Color.LightGray
        Appearance122.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Appearance122.TextHAlignAsString = "Right"
        Me.txtR1C3.Appearance = Appearance122
        Me.txtR1C3.AutoSize = False
        Me.txtR1C3.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtR1C3.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtR1C3.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtR1C3.Location = New System.Drawing.Point(389, 285)
        Me.txtR1C3.MaxLength = 50
        Me.txtR1C3.Name = "txtR1C3"
        Me.txtR1C3.Size = New System.Drawing.Size(112, 28)
        Me.txtR1C3.StyleSetName = "TextEntry"
        Me.txtR1C3.TabIndex = 700
        Me.txtR1C3.Text = "0.00"
        Me.txtR1C3.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtR1C3.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtTCards
        '
        Appearance123.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance123.BorderColor = System.Drawing.Color.LightGray
        Appearance123.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Appearance123.TextHAlignAsString = "Right"
        Me.txtTCards.Appearance = Appearance123
        Me.txtTCards.AutoSize = False
        Me.txtTCards.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtTCards.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtTCards.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTCards.Location = New System.Drawing.Point(271, 109)
        Me.txtTCards.MaxLength = 50
        Me.txtTCards.Name = "txtTCards"
        Me.txtTCards.Size = New System.Drawing.Size(112, 28)
        Me.txtTCards.StyleSetName = "TextEntry"
        Me.txtTCards.TabIndex = 686
        Me.txtTCards.Text = "0.00"
        Me.txtTCards.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtTCards.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraLabel5
        '
        Appearance124.BackColor = System.Drawing.Color.Transparent
        Appearance124.ForeColor = System.Drawing.Color.DimGray
        Appearance124.TextHAlignAsString = "Right"
        Me.UltraLabel5.Appearance = Appearance124
        Me.UltraLabel5.AutoSize = True
        Me.UltraLabel5.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UltraLabel5.Location = New System.Drawing.Point(105, 216)
        Me.UltraLabel5.Name = "UltraLabel5"
        Me.UltraLabel5.Size = New System.Drawing.Size(42, 20)
        Me.UltraLabel5.StyleSetName = "TextEntryLabel"
        Me.UltraLabel5.TabIndex = 667
        Me.UltraLabel5.Text = "Tips:"
        Me.UltraLabel5.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtTCash
        '
        Appearance125.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance125.BorderColor = System.Drawing.Color.LightGray
        Appearance125.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Appearance125.TextHAlignAsString = "Right"
        Me.txtTCash.Appearance = Appearance125
        Me.txtTCash.AutoSize = False
        Me.txtTCash.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtTCash.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtTCash.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTCash.Location = New System.Drawing.Point(153, 109)
        Me.txtTCash.MaxLength = 50
        Me.txtTCash.Name = "txtTCash"
        Me.txtTCash.Size = New System.Drawing.Size(112, 28)
        Me.txtTCash.StyleSetName = "TextEntry"
        Me.txtTCash.TabIndex = 685
        Me.txtTCash.Text = "0.00"
        Me.txtTCash.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtTCash.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtTOther
        '
        Appearance126.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance126.BorderColor = System.Drawing.Color.LightGray
        Appearance126.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Appearance126.TextHAlignAsString = "Right"
        Me.txtTOther.Appearance = Appearance126
        Me.txtTOther.AutoSize = False
        Me.txtTOther.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtTOther.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtTOther.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTOther.Location = New System.Drawing.Point(389, 109)
        Me.txtTOther.MaxLength = 50
        Me.txtTOther.Name = "txtTOther"
        Me.txtTOther.Size = New System.Drawing.Size(112, 28)
        Me.txtTOther.StyleSetName = "TextEntry"
        Me.txtTOther.TabIndex = 684
        Me.txtTOther.Text = "0.00"
        Me.txtTOther.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtTOther.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblOL5
        '
        Appearance127.BackColor = System.Drawing.Color.Transparent
        Appearance127.ForeColor = System.Drawing.Color.DimGray
        Appearance127.TextHAlignAsString = "Right"
        Me.lblOL5.Appearance = Appearance127
        Me.lblOL5.AutoSize = True
        Me.lblOL5.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOL5.Location = New System.Drawing.Point(53, 430)
        Me.lblOL5.Name = "lblOL5"
        Me.lblOL5.Size = New System.Drawing.Size(94, 20)
        Me.lblOL5.StyleSetName = "TextEntryLabel"
        Me.lblOL5.TabIndex = 672
        Me.lblOL5.Text = "unspecified:"
        Me.lblOL5.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblBanking
        '
        Appearance128.BackColor = System.Drawing.Color.Transparent
        Appearance128.ForeColor = System.Drawing.Color.DimGray
        Appearance128.TextHAlignAsString = "Right"
        Me.lblBanking.Appearance = Appearance128
        Me.lblBanking.AutoSize = True
        Me.lblBanking.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBanking.Location = New System.Drawing.Point(77, 182)
        Me.lblBanking.Name = "lblBanking"
        Me.lblBanking.Size = New System.Drawing.Size(70, 20)
        Me.lblBanking.StyleSetName = "TextEntryLabel"
        Me.lblBanking.TabIndex = 666
        Me.lblBanking.Text = "Banking:"
        Me.lblBanking.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblOL4
        '
        Appearance129.BackColor = System.Drawing.Color.Transparent
        Appearance129.ForeColor = System.Drawing.Color.DimGray
        Appearance129.TextHAlignAsString = "Right"
        Me.lblOL4.Appearance = Appearance129
        Me.lblOL4.AutoSize = True
        Me.lblOL4.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOL4.Location = New System.Drawing.Point(53, 395)
        Me.lblOL4.Name = "lblOL4"
        Me.lblOL4.Size = New System.Drawing.Size(94, 20)
        Me.lblOL4.StyleSetName = "TextEntryLabel"
        Me.lblOL4.TabIndex = 671
        Me.lblOL4.Text = "unspecified:"
        Me.lblOL4.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblRTotal
        '
        Appearance130.BackColor = System.Drawing.Color.Transparent
        Appearance130.ForeColor = System.Drawing.Color.DimGray
        Appearance130.TextHAlignAsString = "Right"
        Me.lblRTotal.Appearance = Appearance130
        Me.lblRTotal.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRTotal.Location = New System.Drawing.Point(3, 148)
        Me.lblRTotal.Name = "lblRTotal"
        Me.lblRTotal.Size = New System.Drawing.Size(144, 20)
        Me.lblRTotal.StyleSetName = "TextEntryLabel"
        Me.lblRTotal.TabIndex = 665
        Me.lblRTotal.Text = "Total:"
        Me.lblRTotal.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblOLTotal
        '
        Appearance131.BackColor = System.Drawing.Color.Transparent
        Appearance131.ForeColor = System.Drawing.Color.DimGray
        Appearance131.TextHAlignAsString = "Right"
        Me.lblOLTotal.Appearance = Appearance131
        Me.lblOLTotal.AutoSize = True
        Me.lblOLTotal.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOLTotal.Location = New System.Drawing.Point(99, 462)
        Me.lblOLTotal.Name = "lblOLTotal"
        Me.lblOLTotal.Size = New System.Drawing.Size(47, 20)
        Me.lblOLTotal.StyleSetName = "TextEntryLabel"
        Me.lblOLTotal.TabIndex = 673
        Me.lblOLTotal.Text = "Total:"
        Me.lblOLTotal.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblTables
        '
        Appearance132.BackColor = System.Drawing.Color.Transparent
        Appearance132.ForeColor = System.Drawing.Color.DimGray
        Appearance132.TextHAlignAsString = "Right"
        Me.lblTables.Appearance = Appearance132
        Me.lblTables.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTables.Location = New System.Drawing.Point(3, 114)
        Me.lblTables.Name = "lblTables"
        Me.lblTables.Size = New System.Drawing.Size(144, 20)
        Me.lblTables.StyleSetName = "TextEntryLabel"
        Me.lblTables.TabIndex = 664
        Me.lblTables.Text = "Tables:"
        Me.lblTables.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblOL3
        '
        Appearance133.BackColor = System.Drawing.Color.Transparent
        Appearance133.ForeColor = System.Drawing.Color.DimGray
        Appearance133.TextHAlignAsString = "Right"
        Me.lblOL3.Appearance = Appearance133
        Me.lblOL3.AutoSize = True
        Me.lblOL3.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOL3.Location = New System.Drawing.Point(53, 360)
        Me.lblOL3.Name = "lblOL3"
        Me.lblOL3.Size = New System.Drawing.Size(94, 20)
        Me.lblOL3.StyleSetName = "TextEntryLabel"
        Me.lblOL3.TabIndex = 670
        Me.lblOL3.Text = "unspecified:"
        Me.lblOL3.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblCollections
        '
        Appearance134.BackColor = System.Drawing.Color.Transparent
        Appearance134.ForeColor = System.Drawing.Color.DimGray
        Appearance134.TextHAlignAsString = "Right"
        Me.lblCollections.Appearance = Appearance134
        Me.lblCollections.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCollections.Location = New System.Drawing.Point(3, 80)
        Me.lblCollections.Name = "lblCollections"
        Me.lblCollections.Size = New System.Drawing.Size(144, 20)
        Me.lblCollections.StyleSetName = "TextEntryLabel"
        Me.lblCollections.TabIndex = 663
        Me.lblCollections.Text = "Pickups:"
        Me.lblCollections.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraLabel16
        '
        Appearance135.BackColor = System.Drawing.Color.Transparent
        Appearance135.ForeColor = System.Drawing.Color.DimGray
        Appearance135.TextHAlignAsString = "Right"
        Me.UltraLabel16.Appearance = Appearance135
        Me.UltraLabel16.AutoSize = True
        Me.UltraLabel16.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UltraLabel16.Location = New System.Drawing.Point(74, 532)
        Me.UltraLabel16.Name = "UltraLabel16"
        Me.UltraLabel16.Size = New System.Drawing.Size(73, 20)
        Me.UltraLabel16.StyleSetName = "TextEntryLabel"
        Me.UltraLabel16.TabIndex = 674
        Me.UltraLabel16.Text = "All totals:"
        Me.UltraLabel16.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblDeliveries
        '
        Appearance136.BackColor = System.Drawing.Color.Transparent
        Appearance136.ForeColor = System.Drawing.Color.DimGray
        Appearance136.TextHAlignAsString = "Right"
        Me.lblDeliveries.Appearance = Appearance136
        Me.lblDeliveries.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDeliveries.Location = New System.Drawing.Point(3, 46)
        Me.lblDeliveries.Name = "lblDeliveries"
        Me.lblDeliveries.Size = New System.Drawing.Size(144, 20)
        Me.lblDeliveries.StyleSetName = "TextEntryLabel"
        Me.lblDeliveries.TabIndex = 662
        Me.lblDeliveries.Text = "Deliveries:"
        Me.lblDeliveries.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblOL2
        '
        Appearance137.BackColor = System.Drawing.Color.Transparent
        Appearance137.ForeColor = System.Drawing.Color.DimGray
        Appearance137.TextHAlignAsString = "Right"
        Me.lblOL2.Appearance = Appearance137
        Me.lblOL2.AutoSize = True
        Me.lblOL2.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOL2.Location = New System.Drawing.Point(53, 325)
        Me.lblOL2.Name = "lblOL2"
        Me.lblOL2.Size = New System.Drawing.Size(94, 20)
        Me.lblOL2.StyleSetName = "TextEntryLabel"
        Me.lblOL2.TabIndex = 669
        Me.lblOL2.Text = "unspecified:"
        Me.lblOL2.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblExpenses
        '
        Appearance138.BackColor = System.Drawing.Color.Transparent
        Appearance138.ForeColor = System.Drawing.Color.DimGray
        Appearance138.TextHAlignAsString = "Right"
        Me.lblExpenses.Appearance = Appearance138
        Me.lblExpenses.AutoSize = True
        Me.lblExpenses.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblExpenses.Location = New System.Drawing.Point(696, 80)
        Me.lblExpenses.Name = "lblExpenses"
        Me.lblExpenses.Size = New System.Drawing.Size(83, 20)
        Me.lblExpenses.StyleSetName = "TextEntryLabel"
        Me.lblExpenses.TabIndex = 660
        Me.lblExpenses.Text = "Expenses:"
        Me.lblExpenses.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblOL1
        '
        Appearance139.BackColor = System.Drawing.Color.Transparent
        Appearance139.ForeColor = System.Drawing.Color.DimGray
        Appearance139.TextHAlignAsString = "Right"
        Me.lblOL1.Appearance = Appearance139
        Me.lblOL1.AutoSize = True
        Me.lblOL1.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOL1.Location = New System.Drawing.Point(53, 290)
        Me.lblOL1.Name = "lblOL1"
        Me.lblOL1.Size = New System.Drawing.Size(94, 20)
        Me.lblOL1.StyleSetName = "TextEntryLabel"
        Me.lblOL1.TabIndex = 668
        Me.lblOL1.Text = "unspecified:"
        Me.lblOL1.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton2
        '
        Appearance140.BorderColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance140.ForeColor = System.Drawing.Color.DimGray
        Appearance140.TextVAlignAsString = "Middle"
        Me.UltraButton2.Appearance = Appearance140
        Me.UltraButton2.ButtonStyle = Infragistics.Win.UIElementButtonStyle.Flat
        Me.UltraButton2.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance141.BackColor = System.Drawing.Color.DarkOrange
        Appearance141.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance141.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance141.ForeColor = System.Drawing.Color.Black
        Me.UltraButton2.HotTrackAppearance = Appearance141
        Me.UltraButton2.ImageSize = New System.Drawing.Size(32, 32)
        Me.UltraButton2.Location = New System.Drawing.Point(738, 457)
        Me.UltraButton2.Name = "UltraButton2"
        Appearance142.BackColor = System.Drawing.Color.OrangeRed
        Appearance142.BackColor2 = System.Drawing.Color.Tomato
        Appearance142.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.UltraButton2.PressedAppearance = Appearance142
        Me.UltraButton2.ShowFocusRect = False
        Me.UltraButton2.ShowOutline = False
        Me.UltraButton2.Size = New System.Drawing.Size(90, 60)
        Me.UltraButton2.StyleSetName = "StatusBar"
        Me.UltraButton2.TabIndex = 654
        Me.UltraButton2.Tag = ""
        Me.UltraButton2.Text = "clear all"
        Me.UltraButton2.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton2.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton2.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        Me.UltraButton2.Visible = False
        '
        'cmdCopyBank
        '
        Appearance143.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance143.ForeColor = System.Drawing.Color.Black
        Appearance143.Image = CType(resources.GetObject("Appearance143.Image"), Object)
        Appearance143.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance143.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance143.TextVAlignAsString = "Bottom"
        Me.cmdCopyBank.Appearance = Appearance143
        Me.cmdCopyBank.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdCopyBank.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance144.BackColor = System.Drawing.Color.DarkOrange
        Appearance144.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance144.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance144.ForeColor = System.Drawing.Color.Black
        Me.cmdCopyBank.HotTrackAppearance = Appearance144
        Me.cmdCopyBank.ImageSize = New System.Drawing.Size(24, 24)
        Me.cmdCopyBank.Location = New System.Drawing.Point(671, 143)
        Me.cmdCopyBank.Name = "cmdCopyBank"
        Appearance145.BackColor = System.Drawing.Color.OrangeRed
        Appearance145.BackColor2 = System.Drawing.Color.Tomato
        Appearance145.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdCopyBank.PressedAppearance = Appearance145
        Me.cmdCopyBank.ShowFocusRect = False
        Me.cmdCopyBank.ShowOutline = False
        Me.cmdCopyBank.Size = New System.Drawing.Size(40, 68)
        Me.cmdCopyBank.StyleSetName = "StatusBar"
        Me.cmdCopyBank.TabIndex = 648
        Me.cmdCopyBank.Tag = "+"
        Me.cmdCopyBank.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdCopyBank.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdCopyBank.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdCopyBank.Visible = False
        '
        'UltraButton1
        '
        Appearance146.BorderColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance146.ForeColor = System.Drawing.Color.DimGray
        Appearance146.TextVAlignAsString = "Middle"
        Me.UltraButton1.Appearance = Appearance146
        Me.UltraButton1.ButtonStyle = Infragistics.Win.UIElementButtonStyle.Flat
        Me.UltraButton1.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance147.BackColor = System.Drawing.Color.DarkOrange
        Appearance147.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance147.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance147.ForeColor = System.Drawing.Color.Black
        Me.UltraButton1.HotTrackAppearance = Appearance147
        Me.UltraButton1.ImageSize = New System.Drawing.Size(32, 32)
        Me.UltraButton1.Location = New System.Drawing.Point(851, 458)
        Me.UltraButton1.Name = "UltraButton1"
        Appearance148.BackColor = System.Drawing.Color.OrangeRed
        Appearance148.BackColor2 = System.Drawing.Color.Tomato
        Appearance148.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.UltraButton1.PressedAppearance = Appearance148
        Me.UltraButton1.ShowFocusRect = False
        Me.UltraButton1.ShowOutline = False
        Me.UltraButton1.Size = New System.Drawing.Size(70, 60)
        Me.UltraButton1.StyleSetName = "StatusBar"
        Me.UltraButton1.TabIndex = 649
        Me.UltraButton1.Tag = ""
        Me.UltraButton1.Text = "Demo"
        Me.UltraButton1.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton1.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton1.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        Me.UltraButton1.Visible = False
        '
        'cmdDoOLSums
        '
        Appearance149.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance149.ForeColor = System.Drawing.Color.Black
        Appearance149.Image = CType(resources.GetObject("Appearance149.Image"), Object)
        Appearance149.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance149.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance149.TextVAlignAsString = "Bottom"
        Me.cmdDoOLSums.Appearance = Appearance149
        Me.cmdDoOLSums.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdDoOLSums.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance150.BackColor = System.Drawing.Color.DarkOrange
        Appearance150.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance150.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance150.ForeColor = System.Drawing.Color.Black
        Me.cmdDoOLSums.HotTrackAppearance = Appearance150
        Me.cmdDoOLSums.ImageSize = New System.Drawing.Size(24, 24)
        Me.cmdDoOLSums.Location = New System.Drawing.Point(625, 449)
        Me.cmdDoOLSums.Name = "cmdDoOLSums"
        Appearance151.BackColor = System.Drawing.Color.OrangeRed
        Appearance151.BackColor2 = System.Drawing.Color.Tomato
        Appearance151.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdDoOLSums.PressedAppearance = Appearance151
        Me.cmdDoOLSums.ShowFocusRect = False
        Me.cmdDoOLSums.ShowOutline = False
        Me.cmdDoOLSums.Size = New System.Drawing.Size(40, 40)
        Me.cmdDoOLSums.StyleSetName = "StatusBar"
        Me.cmdDoOLSums.TabIndex = 627
        Me.cmdDoOLSums.Tag = "+"
        Me.cmdDoOLSums.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDoOLSums.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDoOLSums.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDoAllGrandTotals
        '
        Appearance152.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance152.ForeColor = System.Drawing.Color.Black
        Appearance152.Image = CType(resources.GetObject("Appearance152.Image"), Object)
        Appearance152.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance152.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance152.TextVAlignAsString = "Bottom"
        Me.cmdDoAllGrandTotals.Appearance = Appearance152
        Me.cmdDoAllGrandTotals.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdDoAllGrandTotals.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance153.BackColor = System.Drawing.Color.DarkOrange
        Appearance153.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance153.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance153.ForeColor = System.Drawing.Color.Black
        Me.cmdDoAllGrandTotals.HotTrackAppearance = Appearance153
        Me.cmdDoAllGrandTotals.ImageSize = New System.Drawing.Size(24, 24)
        Me.cmdDoAllGrandTotals.Location = New System.Drawing.Point(625, 520)
        Me.cmdDoAllGrandTotals.Name = "cmdDoAllGrandTotals"
        Appearance154.BackColor = System.Drawing.Color.OrangeRed
        Appearance154.BackColor2 = System.Drawing.Color.Tomato
        Appearance154.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdDoAllGrandTotals.PressedAppearance = Appearance154
        Me.cmdDoAllGrandTotals.ShowFocusRect = False
        Me.cmdDoAllGrandTotals.ShowOutline = False
        Me.cmdDoAllGrandTotals.Size = New System.Drawing.Size(40, 40)
        Me.cmdDoAllGrandTotals.StyleSetName = "StatusBar"
        Me.cmdDoAllGrandTotals.TabIndex = 626
        Me.cmdDoAllGrandTotals.Tag = "+"
        Me.cmdDoAllGrandTotals.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDoAllGrandTotals.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDoAllGrandTotals.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDoSums
        '
        Appearance155.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance155.ForeColor = System.Drawing.Color.Black
        Appearance155.Image = CType(resources.GetObject("Appearance155.Image"), Object)
        Appearance155.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance155.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance155.TextVAlignAsString = "Bottom"
        Me.cmdDoSums.Appearance = Appearance155
        Me.cmdDoSums.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdDoSums.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance156.BackColor = System.Drawing.Color.DarkOrange
        Appearance156.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance156.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance156.ForeColor = System.Drawing.Color.Black
        Me.cmdDoSums.HotTrackAppearance = Appearance156
        Me.cmdDoSums.ImageSize = New System.Drawing.Size(24, 24)
        Me.cmdDoSums.Location = New System.Drawing.Point(625, 137)
        Me.cmdDoSums.Name = "cmdDoSums"
        Appearance157.BackColor = System.Drawing.Color.OrangeRed
        Appearance157.BackColor2 = System.Drawing.Color.Tomato
        Appearance157.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdDoSums.PressedAppearance = Appearance157
        Me.cmdDoSums.ShowFocusRect = False
        Me.cmdDoSums.ShowOutline = False
        Me.cmdDoSums.Size = New System.Drawing.Size(40, 40)
        Me.cmdDoSums.StyleSetName = "StatusBar"
        Me.cmdDoSums.TabIndex = 599
        Me.cmdDoSums.Tag = "+"
        Me.cmdDoSums.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDoSums.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDoSums.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdShowBanking
        '
        Me.cmdShowBanking.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Appearance13.ForeColor = System.Drawing.Color.DimGray
        Appearance13.Image = CType(resources.GetObject("Appearance13.Image"), Object)
        Appearance13.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance13.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance13.TextVAlignAsString = "Bottom"
        Me.cmdShowBanking.Appearance = Appearance13
        Me.cmdShowBanking.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdShowBanking.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance14.BackColor = System.Drawing.Color.DarkOrange
        Appearance14.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance14.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance14.ForeColor = System.Drawing.Color.Black
        Me.cmdShowBanking.HotTrackAppearance = Appearance14
        Me.cmdShowBanking.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdShowBanking.Location = New System.Drawing.Point(34, 6)
        Me.cmdShowBanking.Name = "cmdShowBanking"
        Appearance15.BackColor = System.Drawing.Color.OrangeRed
        Appearance15.BackColor2 = System.Drawing.Color.Tomato
        Appearance15.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdShowBanking.PressedAppearance = Appearance15
        Me.cmdShowBanking.ShowFocusRect = False
        Me.cmdShowBanking.ShowOutline = False
        Me.cmdShowBanking.Size = New System.Drawing.Size(56, 60)
        Me.cmdShowBanking.StyleSetName = "StatusBar"
        Me.cmdShowBanking.TabIndex = 545
        Me.cmdShowBanking.Tag = "Print"
        Me.cmdShowBanking.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdShowBanking.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdShowBanking.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdSaveBanking
        '
        Me.cmdSaveBanking.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Appearance19.ForeColor = System.Drawing.Color.DimGray
        Appearance19.Image = CType(resources.GetObject("Appearance19.Image"), Object)
        Appearance19.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance19.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance19.TextVAlignAsString = "Bottom"
        Me.cmdSaveBanking.Appearance = Appearance19
        Me.cmdSaveBanking.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdSaveBanking.Enabled = False
        Me.cmdSaveBanking.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance20.BackColor = System.Drawing.Color.DarkOrange
        Appearance20.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance20.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance20.ForeColor = System.Drawing.Color.Black
        Me.cmdSaveBanking.HotTrackAppearance = Appearance20
        Me.cmdSaveBanking.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdSaveBanking.Location = New System.Drawing.Point(85, 6)
        Me.cmdSaveBanking.Name = "cmdSaveBanking"
        Appearance21.BackColor = System.Drawing.Color.OrangeRed
        Appearance21.BackColor2 = System.Drawing.Color.Tomato
        Appearance21.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdSaveBanking.PressedAppearance = Appearance21
        Me.cmdSaveBanking.ShowFocusRect = False
        Me.cmdSaveBanking.ShowOutline = False
        Me.cmdSaveBanking.Size = New System.Drawing.Size(56, 60)
        Me.cmdSaveBanking.StyleSetName = "StatusBar"
        Me.cmdSaveBanking.TabIndex = 546
        Me.cmdSaveBanking.Tag = "Print"
        Me.cmdSaveBanking.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdSaveBanking.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdSaveBanking.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDateStart
        '
        Me.cmdDateStart.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Appearance25.ForeColor = System.Drawing.Color.DimGray
        Appearance25.Image = CType(resources.GetObject("Appearance25.Image"), Object)
        Appearance25.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance25.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance25.TextVAlignAsString = "Bottom"
        Me.cmdDateStart.Appearance = Appearance25
        Me.cmdDateStart.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdDateStart.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance26.BackColor = System.Drawing.Color.DarkOrange
        Appearance26.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance26.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance26.ForeColor = System.Drawing.Color.Black
        Me.cmdDateStart.HotTrackAppearance = Appearance26
        Me.cmdDateStart.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdDateStart.Location = New System.Drawing.Point(459, 6)
        Me.cmdDateStart.Name = "cmdDateStart"
        Appearance27.BackColor = System.Drawing.Color.OrangeRed
        Appearance27.BackColor2 = System.Drawing.Color.Tomato
        Appearance27.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdDateStart.PressedAppearance = Appearance27
        Me.cmdDateStart.ShowFocusRect = False
        Me.cmdDateStart.ShowOutline = False
        Me.cmdDateStart.Size = New System.Drawing.Size(90, 60)
        Me.cmdDateStart.StyleSetName = "StatusBar"
        Me.cmdDateStart.TabIndex = 650
        Me.cmdDateStart.Tag = "0"
        Me.cmdDateStart.Text = "Start"
        Me.cmdDateStart.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDateStart.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDateStart.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDateEnd
        '
        Me.cmdDateEnd.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Appearance31.ForeColor = System.Drawing.Color.DimGray
        Appearance31.Image = CType(resources.GetObject("Appearance31.Image"), Object)
        Appearance31.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance31.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance31.TextVAlignAsString = "Bottom"
        Me.cmdDateEnd.Appearance = Appearance31
        Me.cmdDateEnd.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdDateEnd.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance32.BackColor = System.Drawing.Color.DarkOrange
        Appearance32.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance32.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance32.ForeColor = System.Drawing.Color.Black
        Me.cmdDateEnd.HotTrackAppearance = Appearance32
        Me.cmdDateEnd.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdDateEnd.Location = New System.Drawing.Point(552, 6)
        Me.cmdDateEnd.Name = "cmdDateEnd"
        Appearance33.BackColor = System.Drawing.Color.OrangeRed
        Appearance33.BackColor2 = System.Drawing.Color.Tomato
        Appearance33.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdDateEnd.PressedAppearance = Appearance33
        Me.cmdDateEnd.ShowFocusRect = False
        Me.cmdDateEnd.ShowOutline = False
        Me.cmdDateEnd.Size = New System.Drawing.Size(90, 60)
        Me.cmdDateEnd.StyleSetName = "StatusBar"
        Me.cmdDateEnd.TabIndex = 651
        Me.cmdDateEnd.Tag = "0"
        Me.cmdDateEnd.Text = "End"
        Me.cmdDateEnd.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDateEnd.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDateEnd.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdSaveTakings
        '
        Me.cmdSaveTakings.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Appearance28.ForeColor = System.Drawing.Color.DimGray
        Appearance28.Image = CType(resources.GetObject("Appearance28.Image"), Object)
        Appearance28.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance28.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance28.TextVAlignAsString = "Bottom"
        Me.cmdSaveTakings.Appearance = Appearance28
        Me.cmdSaveTakings.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdSaveTakings.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance29.BackColor = System.Drawing.Color.DarkOrange
        Appearance29.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance29.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance29.ForeColor = System.Drawing.Color.Black
        Me.cmdSaveTakings.HotTrackAppearance = Appearance29
        Me.cmdSaveTakings.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdSaveTakings.Location = New System.Drawing.Point(747, 6)
        Me.cmdSaveTakings.Name = "cmdSaveTakings"
        Appearance30.BackColor = System.Drawing.Color.OrangeRed
        Appearance30.BackColor2 = System.Drawing.Color.Tomato
        Appearance30.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdSaveTakings.PressedAppearance = Appearance30
        Me.cmdSaveTakings.ShowFocusRect = False
        Me.cmdSaveTakings.ShowOutline = False
        Me.cmdSaveTakings.Size = New System.Drawing.Size(70, 60)
        Me.cmdSaveTakings.StyleSetName = "StatusBar"
        Me.cmdSaveTakings.TabIndex = 652
        Me.cmdSaveTakings.Tag = "Print"
        Me.cmdSaveTakings.Text = "Save Sales"
        Me.cmdSaveTakings.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdSaveTakings.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdSaveTakings.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdShowTakings
        '
        Me.cmdShowTakings.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Appearance22.ForeColor = System.Drawing.Color.DimGray
        Appearance22.Image = CType(resources.GetObject("Appearance22.Image"), Object)
        Appearance22.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance22.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance22.TextVAlignAsString = "Bottom"
        Me.cmdShowTakings.Appearance = Appearance22
        Me.cmdShowTakings.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdShowTakings.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance23.BackColor = System.Drawing.Color.DarkOrange
        Appearance23.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance23.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance23.ForeColor = System.Drawing.Color.Black
        Me.cmdShowTakings.HotTrackAppearance = Appearance23
        Me.cmdShowTakings.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdShowTakings.Location = New System.Drawing.Point(651, 6)
        Me.cmdShowTakings.Name = "cmdShowTakings"
        Appearance24.BackColor = System.Drawing.Color.OrangeRed
        Appearance24.BackColor2 = System.Drawing.Color.Tomato
        Appearance24.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdShowTakings.PressedAppearance = Appearance24
        Me.cmdShowTakings.ShowFocusRect = False
        Me.cmdShowTakings.ShowOutline = False
        Me.cmdShowTakings.Size = New System.Drawing.Size(90, 60)
        Me.cmdShowTakings.StyleSetName = "StatusBar"
        Me.cmdShowTakings.TabIndex = 653
        Me.cmdShowTakings.Tag = ""
        Me.cmdShowTakings.Text = "Show"
        Me.cmdShowTakings.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdShowTakings.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdShowTakings.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdWorkingDay
        '
        Me.cmdWorkingDay.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Appearance16.ForeColor = System.Drawing.Color.DimGray
        Appearance16.Image = CType(resources.GetObject("Appearance16.Image"), Object)
        Appearance16.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance16.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance16.TextVAlignAsString = "Bottom"
        Me.cmdWorkingDay.Appearance = Appearance16
        Me.cmdWorkingDay.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdWorkingDay.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance17.BackColor = System.Drawing.Color.DarkOrange
        Appearance17.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance17.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance17.ForeColor = System.Drawing.Color.Black
        Me.cmdWorkingDay.HotTrackAppearance = Appearance17
        Me.cmdWorkingDay.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdWorkingDay.Location = New System.Drawing.Point(267, 6)
        Me.cmdWorkingDay.Name = "cmdWorkingDay"
        Appearance18.BackColor = System.Drawing.Color.OrangeRed
        Appearance18.BackColor2 = System.Drawing.Color.Tomato
        Appearance18.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdWorkingDay.PressedAppearance = Appearance18
        Me.cmdWorkingDay.ShowFocusRect = False
        Me.cmdWorkingDay.ShowOutline = False
        Me.cmdWorkingDay.Size = New System.Drawing.Size(90, 60)
        Me.cmdWorkingDay.StyleSetName = "StatusBar"
        Me.cmdWorkingDay.TabIndex = 654
        Me.cmdWorkingDay.Tag = "0"
        Me.cmdWorkingDay.Text = "Today"
        Me.cmdWorkingDay.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdWorkingDay.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdWorkingDay.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdGetDate
        '
        Me.cmdGetDate.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Appearance10.ForeColor = System.Drawing.Color.DimGray
        Appearance10.Image = CType(resources.GetObject("Appearance10.Image"), Object)
        Appearance10.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance10.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance10.TextVAlignAsString = "Bottom"
        Me.cmdGetDate.Appearance = Appearance10
        Me.cmdGetDate.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdGetDate.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance11.BackColor = System.Drawing.Color.DarkOrange
        Appearance11.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance11.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance11.ForeColor = System.Drawing.Color.Black
        Me.cmdGetDate.HotTrackAppearance = Appearance11
        Me.cmdGetDate.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdGetDate.Location = New System.Drawing.Point(363, 6)
        Me.cmdGetDate.Name = "cmdGetDate"
        Appearance12.BackColor = System.Drawing.Color.OrangeRed
        Appearance12.BackColor2 = System.Drawing.Color.Tomato
        Appearance12.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdGetDate.PressedAppearance = Appearance12
        Me.cmdGetDate.ShowFocusRect = False
        Me.cmdGetDate.ShowOutline = False
        Me.cmdGetDate.Size = New System.Drawing.Size(90, 60)
        Me.cmdGetDate.StyleSetName = "StatusBar"
        Me.cmdGetDate.TabIndex = 656
        Me.cmdGetDate.Tag = "0"
        Me.cmdGetDate.Text = "Get Date"
        Me.cmdGetDate.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdGetDate.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdGetDate.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdGroupSummary
        '
        Me.cmdGroupSummary.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Appearance4.ForeColor = System.Drawing.Color.DimGray
        Appearance4.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance4.ImageVAlign = Infragistics.Win.VAlign.Top
        Me.cmdGroupSummary.Appearance = Appearance4
        Me.cmdGroupSummary.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdGroupSummary.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance5.BackColor = System.Drawing.Color.DarkOrange
        Appearance5.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance5.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance5.ForeColor = System.Drawing.Color.Black
        Me.cmdGroupSummary.HotTrackAppearance = Appearance5
        Me.cmdGroupSummary.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdGroupSummary.Location = New System.Drawing.Point(160, 6)
        Me.cmdGroupSummary.Name = "cmdGroupSummary"
        Appearance6.BackColor = System.Drawing.Color.OrangeRed
        Appearance6.BackColor2 = System.Drawing.Color.Tomato
        Appearance6.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdGroupSummary.PressedAppearance = Appearance6
        Me.cmdGroupSummary.ShowFocusRect = False
        Me.cmdGroupSummary.ShowOutline = False
        Me.cmdGroupSummary.Size = New System.Drawing.Size(101, 60)
        Me.cmdGroupSummary.StyleSetName = "StatusBar"
        Me.cmdGroupSummary.TabIndex = 657
        Me.cmdGroupSummary.Tag = "0"
        Me.cmdGroupSummary.Text = "Group Summary"
        Me.cmdGroupSummary.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdGroupSummary.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdGroupSummary.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblStatus
        '
        Me.lblStatus.Anchor = System.Windows.Forms.AnchorStyles.Top
        Appearance158.BackColor = System.Drawing.Color.Transparent
        Appearance158.ForeColor = System.Drawing.Color.DimGray
        Appearance158.TextHAlignAsString = "Center"
        Me.lblStatus.Appearance = Appearance158
        Me.lblStatus.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStatus.Location = New System.Drawing.Point(12, 69)
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(979, 20)
        Me.lblStatus.StyleSetName = "TextEntryLabel"
        Me.lblStatus.TabIndex = 661
        Me.lblStatus.Text = "<status>"
        Me.lblStatus.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'frmSummary
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.AutoScroll = True
        Me.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1003, 795)
        Me.Controls.Add(Me.lblStatus)
        Me.Controls.Add(Me.upnTextBoxes)
        Me.Name = "frmSummary"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Controls.SetChildIndex(Me.uplBasePanel, 0)
        Me.Controls.SetChildIndex(Me.upnTextBoxes, 0)
        Me.Controls.SetChildIndex(Me.lblStatus, 0)
        Me.uplBasePanel.ClientArea.ResumeLayout(False)
        Me.uplBasePanel.ResumeLayout(False)
        Me.UltraPanel3.ClientArea.ResumeLayout(False)
        Me.UltraPanel3.ResumeLayout(False)
        Me.upnTextBoxes.ClientArea.ResumeLayout(False)
        Me.upnTextBoxes.ClientArea.PerformLayout()
        Me.upnTextBoxes.ResumeLayout(False)
        CType(Me.txtGrandTotalTotal, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTipsTotal, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtGrandCards, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtGrandCash, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTipsCard, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtGrandOther, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtOLTotalTotal, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTipsCash, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtOLTotalCards, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtOLTotalCash, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTipsOther, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtOLTotalOther, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtR5C4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtBankTotal, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtR5C2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtCTotal, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtR5C1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtBankCard, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtR5C3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtCCards, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtR4C4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtBankCash, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtR4C2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtCCash, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtR4C1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtBankOther, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtR4C3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtCOther, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtR3C4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTotalTotal, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtR3C2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtDTotal, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtR3C1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTotalCards, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtR3C3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtDCards, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtR2C4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTotalCash, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtR2C2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTotalOther, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtR2C1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtDCash, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtR2C3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtDOther, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtR1C4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTTotal, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtR1C2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtExpenses, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtR1C1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtR1C3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTCards, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTCash, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTOther, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents UltraPanel3 As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents cmdClear As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdNum0 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdNum3 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdNum2 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdNum1 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdNum6 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdNum5 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdNum4 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdNum9 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdNum8 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdNum7 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdClose As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdPrintSummary As Infragistics.Win.Misc.UltraButton
    Friend WithEvents upnTextBoxes As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents cmdDoSums As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDoAllGrandTotals As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDoOLSums As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdShowBanking As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdCopyBank As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdSaveBanking As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton1 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDateStart As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDateEnd As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdSaveTakings As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdShowTakings As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton2 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdWorkingDay As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdGetDate As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdGroupSummary As Infragistics.Win.Misc.UltraButton
    Friend WithEvents lblExpenses As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel5 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblOL5 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblBanking As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblOL4 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblRTotal As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblOLTotal As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblTables As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblOL3 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblCollections As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel16 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblDeliveries As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblOL2 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblOL1 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblStatus As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblCTotal As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblCards As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblOther As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblCash As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents txtCTotal As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtCCards As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtCCash As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtCOther As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtDTotal As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtDCards As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtDCash As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtDOther As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtExpenses As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtTTotal As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtTCards As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtTCash As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtTOther As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtTipsTotal As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtTipsCard As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtTipsCash As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtTipsOther As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtBankTotal As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtBankCard As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtBankCash As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtBankOther As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtTotalTotal As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtTotalCards As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtTotalCash As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtTotalOther As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtGrandTotalTotal As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtGrandCards As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtGrandCash As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtGrandOther As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtOLTotalTotal As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtOLTotalCards As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtOLTotalCash As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtOLTotalOther As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtR5C4 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtR5C2 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtR5C1 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtR5C3 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtR4C4 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtR4C2 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtR4C1 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtR4C3 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtR3C4 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtR3C2 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtR3C1 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtR3C3 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtR2C4 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtR2C2 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtR2C1 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtR2C3 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtR1C4 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtR1C2 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtR1C1 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtR1C3 As Infragistics.Win.UltraWinEditors.UltraTextEditor
End Class
