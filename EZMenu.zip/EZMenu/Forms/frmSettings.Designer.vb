﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSettings
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim Appearance1 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance2 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance3 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance4 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance5 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance6 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance7 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance8 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance9 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim ValueListItem5 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim ValueListItem6 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim Appearance10 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance11 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance12 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance13 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance14 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance15 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance16 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance17 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance18 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance19 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance20 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance21 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance22 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim ValueListItem1 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim ValueListItem2 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim Appearance23 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance24 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance25 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance26 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance27 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance28 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim ValueListItem32 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim ValueListItem33 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim Appearance29 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance30 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance31 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim ValueListItem23 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim ValueListItem24 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim ValueListItem31 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim ValueListItem30 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim Appearance32 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance33 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim ValueListItem26 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim ValueListItem27 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim Appearance34 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance35 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim ValueListItem34 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim ValueListItem35 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim ValueListItem36 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim ValueListItem37 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim ValueListItem38 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim ValueListItem39 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim ValueListItem40 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim ValueListItem41 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim ValueListItem42 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim ValueListItem43 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim Appearance36 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance37 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance38 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance39 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance40 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim ValueListItem44 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim ValueListItem45 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim ValueListItem46 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim ValueListItem47 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim ValueListItem48 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim ValueListItem49 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim ValueListItem50 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim ValueListItem51 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim ValueListItem52 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim ValueListItem53 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim Appearance41 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance42 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance43 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance44 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance45 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance46 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance47 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance48 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance49 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance50 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance51 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance52 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance53 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance54 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance55 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance56 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance57 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance58 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance59 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance60 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance61 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance62 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance63 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance64 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance65 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance66 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance67 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance68 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance69 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance70 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance71 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance72 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim ValueListItem8 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim ValueListItem9 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim ValueListItem10 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim ValueListItem25 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim ValueListItem54 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim ValueListItem55 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim Appearance73 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance74 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance75 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance76 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance77 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance78 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance79 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance80 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance81 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance82 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance83 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim ValueListItem14 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim ValueListItem15 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim ValueListItem16 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim Appearance84 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance85 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim ValueListItem3 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim ValueListItem17 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim ValueListItem4 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim ValueListItem22 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim Appearance86 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance87 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance88 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance89 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance90 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance91 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance92 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance93 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance94 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance95 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance96 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance97 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance98 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance99 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance100 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance101 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance102 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance103 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance104 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance105 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance106 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance107 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance108 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance109 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim ValueListItem28 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim ValueListItem7 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim ValueListItem11 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim ValueListItem12 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim ValueListItem13 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim ValueListItem20 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim ValueListItem21 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim ValueListItem29 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim Appearance110 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance111 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraTab25 As Infragistics.Win.UltraWinTabControl.UltraTab = New Infragistics.Win.UltraWinTabControl.UltraTab()
        Dim UltraTab23 As Infragistics.Win.UltraWinTabControl.UltraTab = New Infragistics.Win.UltraWinTabControl.UltraTab()
        Dim UltraTab3 As Infragistics.Win.UltraWinTabControl.UltraTab = New Infragistics.Win.UltraWinTabControl.UltraTab()
        Dim UltraTab26 As Infragistics.Win.UltraWinTabControl.UltraTab = New Infragistics.Win.UltraWinTabControl.UltraTab()
        Dim UltraTab22 As Infragistics.Win.UltraWinTabControl.UltraTab = New Infragistics.Win.UltraWinTabControl.UltraTab()
        Dim UltraTab7 As Infragistics.Win.UltraWinTabControl.UltraTab = New Infragistics.Win.UltraWinTabControl.UltraTab()
        Dim UltraTab34 As Infragistics.Win.UltraWinTabControl.UltraTab = New Infragistics.Win.UltraWinTabControl.UltraTab()
        Dim UltraTab9 As Infragistics.Win.UltraWinTabControl.UltraTab = New Infragistics.Win.UltraWinTabControl.UltraTab()
        Dim UltraTab30 As Infragistics.Win.UltraWinTabControl.UltraTab = New Infragistics.Win.UltraWinTabControl.UltraTab()
        Dim UltraTab32 As Infragistics.Win.UltraWinTabControl.UltraTab = New Infragistics.Win.UltraWinTabControl.UltraTab()
        Dim UltraTab2 As Infragistics.Win.UltraWinTabControl.UltraTab = New Infragistics.Win.UltraWinTabControl.UltraTab()
        Dim UltraTab36 As Infragistics.Win.UltraWinTabControl.UltraTab = New Infragistics.Win.UltraWinTabControl.UltraTab()
        Dim UltraTab8 As Infragistics.Win.UltraWinTabControl.UltraTab = New Infragistics.Win.UltraWinTabControl.UltraTab()
        Dim UltraTab10 As Infragistics.Win.UltraWinTabControl.UltraTab = New Infragistics.Win.UltraWinTabControl.UltraTab()
        Dim UltraTab11 As Infragistics.Win.UltraWinTabControl.UltraTab = New Infragistics.Win.UltraWinTabControl.UltraTab()
        Dim UltraTab4 As Infragistics.Win.UltraWinTabControl.UltraTab = New Infragistics.Win.UltraWinTabControl.UltraTab()
        Dim UltraTab6 As Infragistics.Win.UltraWinTabControl.UltraTab = New Infragistics.Win.UltraWinTabControl.UltraTab()
        Dim UltraTab5 As Infragistics.Win.UltraWinTabControl.UltraTab = New Infragistics.Win.UltraWinTabControl.UltraTab()
        Dim Appearance112 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmSettings))
        Me.UltraTabPageControl3 = New Infragistics.Win.UltraWinTabControl.UltraTabPageControl()
        Me.UltraGroupBox4 = New Infragistics.Win.Misc.UltraGroupBox()
        Me.chkIsTabletPC = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.chkCenterMainForm = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.chkLastOrdered = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.chkNumberOrdered = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.chkAutoDelPastOrders = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.chkAutoCashCard = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.chkAutoMarkAsPaid = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.optMainSubSystem = New Infragistics.Win.UltraWinEditors.UltraOptionSet()
        Me.chkPartOfMultiSystem = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.chkFirstOrdered = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.chkShowMinimise = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.chkSaveCustomerHistory = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.chkShowHomeAfterPrint = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.chkSaveDishHistory = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.chkPasswordTakings = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.chkDisableCursor = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.chkShowLabelText = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.chkCAP = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.txtCAP = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.UltraLabel18 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraTabPageControl1 = New Infragistics.Win.UltraWinTabControl.UltraTabPageControl()
        Me.UltraGroupBox6 = New Infragistics.Win.Misc.UltraGroupBox()
        Me.lblDiscAmtLbl = New Infragistics.Win.Misc.UltraLabel()
        Me.chkGiveDiscount = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.txtDiscountExc = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.optDiscount = New Infragistics.Win.UltraWinEditors.UltraOptionSet()
        Me.UltraLabel4 = New Infragistics.Win.Misc.UltraLabel()
        Me.chkDiscountExc = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.txtDiscount = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.UltraGroupBox5 = New Infragistics.Win.Misc.UltraGroupBox()
        Me.UltraLabel97 = New Infragistics.Win.Misc.UltraLabel()
        Me.txtMyPostcode = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.cmdGetTime = New Infragistics.Win.Misc.UltraButton()
        Me.chkDTime = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.UltraLabel83 = New Infragistics.Win.Misc.UltraLabel()
        Me.txtDTime = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.chkMinOrderAmount = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.UltraLabel82 = New Infragistics.Win.Misc.UltraLabel()
        Me.txtMinOrderAmount = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.lblDelivAmtLbl = New Infragistics.Win.Misc.UltraLabel()
        Me.chkDelivCharge = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.txtDelivUnder = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.optDeliv = New Infragistics.Win.UltraWinEditors.UltraOptionSet()
        Me.UltraLabel1 = New Infragistics.Win.Misc.UltraLabel()
        Me.chkDelivUnder = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.txtDeliv = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.UltraTabPageControl8 = New Infragistics.Win.UltraWinTabControl.UltraTabPageControl()
        Me.UltraGroupBox14 = New Infragistics.Win.Misc.UltraGroupBox()
        Me.chkRoundingMethod = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.cmdDCClear = New Infragistics.Win.Misc.UltraButton()
        Me.lstDiscCharges = New Infragistics.Win.UltraWinListView.UltraListView()
        Me.cmdDCAdd = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDCDelete = New Infragistics.Win.Misc.UltraButton()
        Me.cmbDCAorP = New Infragistics.Win.UltraWinEditors.UltraComboEditor()
        Me.UltraLabel72 = New Infragistics.Win.Misc.UltraLabel()
        Me.cmbDCType = New Infragistics.Win.UltraWinEditors.UltraComboEditor()
        Me.UltraLabel71 = New Infragistics.Win.Misc.UltraLabel()
        Me.txtDCRate = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtLblValue = New Infragistics.Win.Misc.UltraLabel()
        Me.txtDCName = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.UltraLabel70 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraTabPageControl4 = New Infragistics.Win.UltraWinTabControl.UltraTabPageControl()
        Me.UltraGroupBox8 = New Infragistics.Win.Misc.UltraGroupBox()
        Me.cmdReleaseCOMPort = New Infragistics.Win.Misc.UltraButton()
        Me.cmdResetActiveCID = New Infragistics.Win.Misc.UltraButton()
        Me.optCometMeteor = New Infragistics.Win.UltraWinEditors.UltraOptionSet()
        Me.chkDoNotShowCID = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.chkEnableRecording = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.cmbActiveCIDPort = New Infragistics.Win.UltraWinEditors.UltraComboEditor()
        Me.UltraLabel10 = New Infragistics.Win.Misc.UltraLabel()
        Me.chkEnableActiveCID = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.UltraGroupBox3 = New Infragistics.Win.Misc.UltraGroupBox()
        Me.txtPhLen3 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtPhTrim3 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.UltraLabel9 = New Infragistics.Win.Misc.UltraLabel()
        Me.txtPhLen2 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtPhTrim2 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.UltraLabel8 = New Infragistics.Win.Misc.UltraLabel()
        Me.txtPhLen1 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtPhTrim1 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.UltraLabel7 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel6 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraTabPageControl6 = New Infragistics.Win.UltraWinTabControl.UltraTabPageControl()
        Me.UltraGroupBox9 = New Infragistics.Win.Misc.UltraGroupBox()
        Me.UltraLabel79 = New Infragistics.Win.Misc.UltraLabel()
        Me.chkLogoItalic = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.chkLogoBold = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.cmbLogoSize = New Infragistics.Win.UltraWinEditors.UltraComboEditor()
        Me.cmbLogoFont = New Infragistics.Win.UltraWinEditors.UltraComboEditor()
        Me.UltraLabel28 = New Infragistics.Win.Misc.UltraLabel()
        Me.txtFooter = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.UltraLabel49 = New Infragistics.Win.Misc.UltraLabel()
        Me.cmdLogoFontSave = New Infragistics.Win.Misc.UltraButton()
        Me.txtHeader6 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtHeader5 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtHeader4 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtHeader3 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtHeader2 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtHeader1 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.UltraLabel13 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraTabPageControl16 = New Infragistics.Win.UltraWinTabControl.UltraTabPageControl()
        Me.ugbCuisines = New Infragistics.Win.Misc.UltraGroupBox()
        Me.cmdRenameCuisine5 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdRenameCuisine4 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdRenameCuisine3 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdRenameCuisine2 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdRenameCuisine1 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDeleteCuisine5 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDeleteCuisine4 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDeleteCuisine3 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDeleteCuisine2 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDeleteCuisine1 = New Infragistics.Win.Misc.UltraButton()
        Me.txtCuisine5 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtCuisine4 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtCuisine3 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtCuisine2 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtCuisine1 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.UltraLabel91 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel90 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel89 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel88 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel87 = New Infragistics.Win.Misc.UltraLabel()
        Me.cmdCuisineSave = New Infragistics.Win.Misc.UltraButton()
        Me.UltraTabPageControl11 = New Infragistics.Win.UltraWinTabControl.UltraTabPageControl()
        Me.UltraGroupBox11 = New Infragistics.Win.Misc.UltraGroupBox()
        Me.cmdMergeGroup = New Infragistics.Win.Misc.UltraButton()
        Me.cmdRenameGroup = New Infragistics.Win.Misc.UltraButton()
        Me.UltraLabel86 = New Infragistics.Win.Misc.UltraLabel()
        Me.cmdRefreshCuisinesGroups = New Infragistics.Win.Misc.UltraButton()
        Me.cmbCuisineGroups = New Infragistics.Win.UltraWinEditors.UltraComboEditor()
        Me.cmdGroupingMode = New Infragistics.Win.Misc.UltraButton()
        Me.cmdInsertLine = New Infragistics.Win.Misc.UltraButton()
        Me.UltraLabel78 = New Infragistics.Win.Misc.UltraLabel()
        Me.cmdSaveGroups = New Infragistics.Win.Misc.UltraButton()
        Me.cmdMoveUp = New Infragistics.Win.Misc.UltraButton()
        Me.cmdMoveDown = New Infragistics.Win.Misc.UltraButton()
        Me.cmdMainGroup = New Infragistics.Win.Misc.UltraButton()
        Me.cmdSubGroup = New Infragistics.Win.Misc.UltraButton()
        Me.lstGroups = New Infragistics.Win.UltraWinListView.UltraListView()
        Me.cmdAddGroup = New Infragistics.Win.Misc.UltraButton()
        Me.txtGroups = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.cmdDeleteGroup = New Infragistics.Win.Misc.UltraButton()
        Me.UltraTabPageControl18 = New Infragistics.Win.UltraWinTabControl.UltraTabPageControl()
        Me.UltraGroupBox19 = New Infragistics.Win.Misc.UltraGroupBox()
        Me.chkDishesUppercase = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.chkDishesSimpleName = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.UltraLabel104 = New Infragistics.Win.Misc.UltraLabel()
        Me.txtPortionSmall = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.UltraLabel106 = New Infragistics.Win.Misc.UltraLabel()
        Me.txtPortionLarge = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.chkDishesUseConcise = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.UltraTabPageControl7 = New Infragistics.Win.UltraWinTabControl.UltraTabPageControl()
        Me.UltraGroupBox1 = New Infragistics.Win.Misc.UltraGroupBox()
        Me.chkShowModLabelPrinter = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.chkZeroCost = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.chkDisableCostChange = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.lstMods = New Infragistics.Win.UltraWinListView.UltraListView()
        Me.UltraLabel31 = New Infragistics.Win.Misc.UltraLabel()
        Me.txtCost = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.UltraLabel30 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel29 = New Infragistics.Win.Misc.UltraLabel()
        Me.cmdAddMod = New Infragistics.Win.Misc.UltraButton()
        Me.txtMod = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.cmdDeleteMod = New Infragistics.Win.Misc.UltraButton()
        Me.UltraTabPageControl9 = New Infragistics.Win.UltraWinTabControl.UltraTabPageControl()
        Me.UltraGroupBox7 = New Infragistics.Win.Misc.UltraGroupBox()
        Me.cmdSavePrinters = New Infragistics.Win.Misc.UltraButton()
        Me.UltraLabel94 = New Infragistics.Win.Misc.UltraLabel()
        Me.cmdRefreshCuisinesPrinters = New Infragistics.Win.Misc.UltraButton()
        Me.cmbCuisinePrinters = New Infragistics.Win.UltraWinEditors.UltraComboEditor()
        Me.chkHidePrintDialog = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.UltraLabel43 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel44 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel45 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel46 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel47 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel48 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel5 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel40 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel41 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel42 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel39 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel38 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel37 = New Infragistics.Win.Misc.UltraLabel()
        Me.cmbT_SC_Kitchen = New Infragistics.Win.UltraWinEditors.UltraComboEditor()
        Me.cmbT_SC_Shop = New Infragistics.Win.UltraWinEditors.UltraComboEditor()
        Me.cmbD_SC_Kitchen = New Infragistics.Win.UltraWinEditors.UltraComboEditor()
        Me.cmbD_SC_Shop = New Infragistics.Win.UltraWinEditors.UltraComboEditor()
        Me.cmbD_KC_Kitchen = New Infragistics.Win.UltraWinEditors.UltraComboEditor()
        Me.cmbD_KC_Shop = New Infragistics.Win.UltraWinEditors.UltraComboEditor()
        Me.cmbT_KC_Kitchen = New Infragistics.Win.UltraWinEditors.UltraComboEditor()
        Me.cmbT_KC_Shop = New Infragistics.Win.UltraWinEditors.UltraComboEditor()
        Me.cmbC_SC_Kitchen = New Infragistics.Win.UltraWinEditors.UltraComboEditor()
        Me.cmbC_SC_Shop = New Infragistics.Win.UltraWinEditors.UltraComboEditor()
        Me.cmbC_KC_Kitchen = New Infragistics.Win.UltraWinEditors.UltraComboEditor()
        Me.UltraLabel34 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel33 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel32 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel36 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel35 = New Infragistics.Win.Misc.UltraLabel()
        Me.cmbC_KC_Shop = New Infragistics.Win.UltraWinEditors.UltraComboEditor()
        Me.cmbPrinterKitchen = New Infragistics.Win.UltraWinEditors.UltraComboEditor()
        Me.cmbPrinterShop = New Infragistics.Win.UltraWinEditors.UltraComboEditor()
        Me.UltraLabel15 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel14 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraTabPageControl5 = New Infragistics.Win.UltraWinTabControl.UltraTabPageControl()
        Me.UltraGroupBox13 = New Infragistics.Win.Misc.UltraGroupBox()
        Me.UltraLabel108 = New Infragistics.Win.Misc.UltraLabel()
        Me.cmdSaveLabelPrinters = New Infragistics.Win.Misc.UltraButton()
        Me.UltraLabel95 = New Infragistics.Win.Misc.UltraLabel()
        Me.cmdRefreshCuisinesLabel = New Infragistics.Win.Misc.UltraButton()
        Me.cmbCuisineLabelPrinter = New Infragistics.Win.UltraWinEditors.UltraComboEditor()
        Me.cmdDefault = New Infragistics.Win.Misc.UltraButton()
        Me.UltraLabel66 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel67 = New Infragistics.Win.Misc.UltraLabel()
        Me.txtLabelLeftOffset = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtLabelTopOffset = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.UltraLabel68 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel69 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel65 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel64 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel63 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel62 = New Infragistics.Win.Misc.UltraLabel()
        Me.txtLabelHeight = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtLabelWidth = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.UltraLabel60 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel61 = New Infragistics.Win.Misc.UltraLabel()
        Me.chkPrintLabelAny = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.cmbPrinterLabel = New Infragistics.Win.UltraWinEditors.UltraComboEditor()
        Me.txtLabelTopMargin = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtLabelLeftMargin = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.UltraLabel16 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel53 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel52 = New Infragistics.Win.Misc.UltraLabel()
        Me.cmbLabelFontSize = New Infragistics.Win.UltraWinEditors.UltraComboEditor()
        Me.UltraLabel51 = New Infragistics.Win.Misc.UltraLabel()
        Me.chkPrintLabels = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.UltraTabPageControl13 = New Infragistics.Win.UltraWinTabControl.UltraTabPageControl()
        Me.UltraGroupBox10 = New Infragistics.Win.Misc.UltraGroupBox()
        Me.chkSameSKHeader = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.chkSimultaneousPrinting = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.chkKitchenGap = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.chkExtraGap = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.chkDrinksFoodGrouped = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.chkDrinksHeader = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.chkDrinksAndFoodGap = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.chkDrinksFoodSeparatePrice = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.chkDrinksItemise = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.UltraLabel58 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel57 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel56 = New Infragistics.Win.Misc.UltraLabel()
        Me.optKitchen = New Infragistics.Win.UltraWinEditors.UltraOptionSet()
        Me.optCustomer = New Infragistics.Win.UltraWinEditors.UltraOptionSet()
        Me.UltraLabel54 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel55 = New Infragistics.Win.Misc.UltraLabel()
        Me.optOnScreen = New Infragistics.Win.UltraWinEditors.UltraOptionSet()
        Me.chkKitchenDate = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.chkShopDate = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.UltraLabel19 = New Infragistics.Win.Misc.UltraLabel()
        Me.chkKitchenTime = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.chkShopTime = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.UltraLabel17 = New Infragistics.Win.Misc.UltraLabel()
        Me.chkKitchenCard = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.chkShopCard = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.chkKitchenItem = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.chkShopItem = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.UltraLabel23 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel22 = New Infragistics.Win.Misc.UltraLabel()
        Me.chkKitchenTotal = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.chkShopTotal = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.UltraLabel12 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel3 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel2 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraTabPageControl17 = New Infragistics.Win.UltraWinTabControl.UltraTabPageControl()
        Me.UltraGroupBox18 = New Infragistics.Win.Misc.UltraGroupBox()
        Me.UltraLabel115 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel114 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel113 = New Infragistics.Win.Misc.UltraLabel()
        Me.txtCentreOffset = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.UltraLabel112 = New Infragistics.Win.Misc.UltraLabel()
        Me.txtRightOffset = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.UltraLabel109 = New Infragistics.Win.Misc.UltraLabel()
        Me.txtPaperWidth = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.UltraLabel105 = New Infragistics.Win.Misc.UltraLabel()
        Me.txtKitchenHeaderText = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.UltraLabel100 = New Infragistics.Win.Misc.UltraLabel()
        Me.cmbFontSizeKitchenAddress = New Infragistics.Win.UltraWinEditors.UltraComboEditor()
        Me.UltraLabel99 = New Infragistics.Win.Misc.UltraLabel()
        Me.cmbFontSizeKitchen = New Infragistics.Win.UltraWinEditors.UltraComboEditor()
        Me.UltraLabel98 = New Infragistics.Win.Misc.UltraLabel()
        Me.cmbFontSizeShop = New Infragistics.Win.UltraWinEditors.UltraComboEditor()
        Me.txtKitchenTopOffset = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.UltraLabel92 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel93 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel84 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel81 = New Infragistics.Win.Misc.UltraLabel()
        Me.txtMinPaperLengthKitchen = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.UltraLabel80 = New Infragistics.Win.Misc.UltraLabel()
        Me.txtMinPaperLengthShop = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.UltraLabel77 = New Infragistics.Win.Misc.UltraLabel()
        Me.txtShopTopOffset = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.UltraLabel27 = New Infragistics.Win.Misc.UltraLabel()
        Me.txtDrinksLabel = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.UltraLabel26 = New Infragistics.Win.Misc.UltraLabel()
        Me.txtFoodLabel = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.UltraLabel111 = New Infragistics.Win.Misc.UltraLabel()
        Me.cmbPaidLocation = New Infragistics.Win.UltraWinEditors.UltraComboEditor()
        Me.UltraLabel110 = New Infragistics.Win.Misc.UltraLabel()
        Me.cmbPaidFontSize = New Infragistics.Win.UltraWinEditors.UltraComboEditor()
        Me.UltraTabPageControl19 = New Infragistics.Win.UltraWinTabControl.UltraTabPageControl()
        Me.UltraGroupBox20 = New Infragistics.Win.Misc.UltraGroupBox()
        Me.chkServiceCharge = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.ucpTStatus = New Infragistics.Win.UltraWinEditors.UltraColorPicker()
        Me.UltraLabel107 = New Infragistics.Win.Misc.UltraLabel()
        Me.lstTStatus = New Infragistics.Win.UltraWinListView.UltraListView()
        Me.cmdAddTStatus = New Infragistics.Win.Misc.UltraButton()
        Me.txtTStatus = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.cmdDeleteTStatus = New Infragistics.Win.Misc.UltraButton()
        Me.cmbNumTables = New Infragistics.Win.UltraWinEditors.UltraComboEditor()
        Me.UltraLabel11 = New Infragistics.Win.Misc.UltraLabel()
        Me.chkTableAutoCovers = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.chkTableExtLights = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.chkTableExtSave = New Infragistics.Win.Misc.UltraButton()
        Me.chkTableExtDelete = New Infragistics.Win.Misc.UltraButton()
        Me.txtTableExtLine3 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtTableExtLine2 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtTableExtLine1 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.UltraLabel101 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel102 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel103 = New Infragistics.Win.Misc.UltraLabel()
        Me.chkTableExtMode = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.UltraTabPageControl20 = New Infragistics.Win.UltraWinTabControl.UltraTabPageControl()
        Me.UltraGroupBox21 = New Infragistics.Win.Misc.UltraGroupBox()
        Me.chkSummaryCDTTotals = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.chkSummaryPrintDate = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.UltraTabPageControl12 = New Infragistics.Win.UltraWinTabControl.UltraTabPageControl()
        Me.UltraGroupBox15 = New Infragistics.Win.Misc.UltraGroupBox()
        Me.chkXClearOnExit = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.chkRequireLogon = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.chkXClearOrders = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.cmdShowPassword = New Infragistics.Win.Misc.UltraButton()
        Me.chkXAccessBanking = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.chkXAccessSummary = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.chkXOrderTotals = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.chkXAccessManager = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.chkXOrderReprint = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.chkXOrderEdit = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.chkXOrderDelete = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.chkXOrders = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.UltraLabel25 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel73 = New Infragistics.Win.Misc.UltraLabel()
        Me.cmdSetSupervisorPassword = New Infragistics.Win.Misc.UltraButton()
        Me.UltraLabel74 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel75 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel76 = New Infragistics.Win.Misc.UltraLabel()
        Me.txtSPConfirm = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtSPNew = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtSPOld = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.UltraTabPageControl15 = New Infragistics.Win.UltraWinTabControl.UltraTabPageControl()
        Me.UltraGroupBox17 = New Infragistics.Win.Misc.UltraGroupBox()
        Me.chkSetPutQty = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.UltraTabPageControl14 = New Infragistics.Win.UltraWinTabControl.UltraTabPageControl()
        Me.UltraGroupBox16 = New Infragistics.Win.Misc.UltraGroupBox()
        Me.UltraLabel50 = New Infragistics.Win.Misc.UltraLabel()
        Me.txtEmailFrequency = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.cmdEmailReport = New Infragistics.Win.Misc.UltraButton()
        Me.chkEmailError = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.chkShowOnlineTotals = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.chkPrintPayPalID = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.cmbBackupDay = New Infragistics.Win.UltraWinEditors.UltraComboEditor()
        Me.UltraLabel85 = New Infragistics.Win.Misc.UltraLabel()
        Me.chkBackupDBOnline = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.chkEnableOnline = New Infragistics.Win.UltraWinEditors.UltraCheckEditor()
        Me.UltraLabel59 = New Infragistics.Win.Misc.UltraLabel()
        Me.txtOLText = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.lstOnline = New Infragistics.Win.UltraWinListView.UltraListView()
        Me.cmdAddOnline = New Infragistics.Win.Misc.UltraButton()
        Me.txtOnline = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.cmdDeleteOnline = New Infragistics.Win.Misc.UltraButton()
        Me.cmdSave = New Infragistics.Win.Misc.UltraButton()
        Me.cmdCancel = New Infragistics.Win.Misc.UltraButton()
        Me.UltraTabSharedControlsPage1 = New Infragistics.Win.UltraWinTabControl.UltraTabSharedControlsPage()
        Me.utcSettings = New Infragistics.Win.UltraWinTabControl.UltraTabControl()
        Me.lblSaving = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraTabPageControl3.SuspendLayout()
        CType(Me.UltraGroupBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.UltraGroupBox4.SuspendLayout()
        CType(Me.chkIsTabletPC, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkCenterMainForm, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkLastOrdered, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkNumberOrdered, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkAutoDelPastOrders, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkAutoCashCard, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkAutoMarkAsPaid, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.optMainSubSystem, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkPartOfMultiSystem, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkFirstOrdered, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkShowMinimise, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkSaveCustomerHistory, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkShowHomeAfterPrint, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkSaveDishHistory, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkPasswordTakings, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkDisableCursor, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkShowLabelText, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkCAP, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtCAP, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.UltraTabPageControl1.SuspendLayout()
        CType(Me.UltraGroupBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.UltraGroupBox6.SuspendLayout()
        CType(Me.chkGiveDiscount, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtDiscountExc, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.optDiscount, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkDiscountExc, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtDiscount, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.UltraGroupBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.UltraGroupBox5.SuspendLayout()
        CType(Me.txtMyPostcode, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkDTime, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtDTime, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkMinOrderAmount, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtMinOrderAmount, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkDelivCharge, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtDelivUnder, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.optDeliv, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkDelivUnder, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtDeliv, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.UltraTabPageControl8.SuspendLayout()
        CType(Me.UltraGroupBox14, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.UltraGroupBox14.SuspendLayout()
        CType(Me.chkRoundingMethod, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lstDiscCharges, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbDCAorP, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbDCType, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtDCRate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtDCName, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.UltraTabPageControl4.SuspendLayout()
        CType(Me.UltraGroupBox8, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.UltraGroupBox8.SuspendLayout()
        CType(Me.optCometMeteor, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkDoNotShowCID, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkEnableRecording, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbActiveCIDPort, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkEnableActiveCID, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.UltraGroupBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.UltraGroupBox3.SuspendLayout()
        CType(Me.txtPhLen3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtPhTrim3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtPhLen2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtPhTrim2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtPhLen1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtPhTrim1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.UltraTabPageControl6.SuspendLayout()
        CType(Me.UltraGroupBox9, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.UltraGroupBox9.SuspendLayout()
        CType(Me.chkLogoItalic, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkLogoBold, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbLogoSize, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbLogoFont, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtFooter, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtHeader6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtHeader5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtHeader4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtHeader3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtHeader2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtHeader1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.UltraTabPageControl16.SuspendLayout()
        CType(Me.ugbCuisines, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ugbCuisines.SuspendLayout()
        CType(Me.txtCuisine5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtCuisine4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtCuisine3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtCuisine2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtCuisine1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.UltraTabPageControl11.SuspendLayout()
        CType(Me.UltraGroupBox11, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.UltraGroupBox11.SuspendLayout()
        CType(Me.cmbCuisineGroups, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lstGroups, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtGroups, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.UltraTabPageControl18.SuspendLayout()
        CType(Me.UltraGroupBox19, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.UltraGroupBox19.SuspendLayout()
        CType(Me.chkDishesUppercase, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkDishesSimpleName, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtPortionSmall, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtPortionLarge, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkDishesUseConcise, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.UltraTabPageControl7.SuspendLayout()
        CType(Me.UltraGroupBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.UltraGroupBox1.SuspendLayout()
        CType(Me.chkShowModLabelPrinter, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkZeroCost, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkDisableCostChange, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lstMods, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtCost, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtMod, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.UltraTabPageControl9.SuspendLayout()
        CType(Me.UltraGroupBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.UltraGroupBox7.SuspendLayout()
        CType(Me.cmbCuisinePrinters, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkHidePrintDialog, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbT_SC_Kitchen, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbT_SC_Shop, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbD_SC_Kitchen, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbD_SC_Shop, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbD_KC_Kitchen, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbD_KC_Shop, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbT_KC_Kitchen, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbT_KC_Shop, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbC_SC_Kitchen, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbC_SC_Shop, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbC_KC_Kitchen, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbC_KC_Shop, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbPrinterKitchen, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbPrinterShop, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.UltraTabPageControl5.SuspendLayout()
        CType(Me.UltraGroupBox13, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.UltraGroupBox13.SuspendLayout()
        CType(Me.cmbCuisineLabelPrinter, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtLabelLeftOffset, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtLabelTopOffset, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtLabelHeight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtLabelWidth, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkPrintLabelAny, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbPrinterLabel, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtLabelTopMargin, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtLabelLeftMargin, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbLabelFontSize, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkPrintLabels, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.UltraTabPageControl13.SuspendLayout()
        CType(Me.UltraGroupBox10, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.UltraGroupBox10.SuspendLayout()
        CType(Me.chkSameSKHeader, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkSimultaneousPrinting, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkKitchenGap, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkExtraGap, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkDrinksFoodGrouped, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkDrinksHeader, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkDrinksAndFoodGap, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkDrinksFoodSeparatePrice, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkDrinksItemise, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.optKitchen, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.optCustomer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.optOnScreen, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkKitchenDate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkShopDate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkKitchenTime, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkShopTime, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkKitchenCard, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkShopCard, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkKitchenItem, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkShopItem, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkKitchenTotal, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkShopTotal, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.UltraTabPageControl17.SuspendLayout()
        CType(Me.UltraGroupBox18, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.UltraGroupBox18.SuspendLayout()
        CType(Me.txtCentreOffset, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtRightOffset, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtPaperWidth, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtKitchenHeaderText, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbFontSizeKitchenAddress, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbFontSizeKitchen, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbFontSizeShop, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtKitchenTopOffset, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtMinPaperLengthKitchen, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtMinPaperLengthShop, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtShopTopOffset, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtDrinksLabel, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtFoodLabel, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbPaidLocation, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbPaidFontSize, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.UltraTabPageControl19.SuspendLayout()
        CType(Me.UltraGroupBox20, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.UltraGroupBox20.SuspendLayout()
        CType(Me.chkServiceCharge, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ucpTStatus, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lstTStatus, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTStatus, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbNumTables, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkTableAutoCovers, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkTableExtLights, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTableExtLine3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTableExtLine2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTableExtLine1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkTableExtMode, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.UltraTabPageControl20.SuspendLayout()
        CType(Me.UltraGroupBox21, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.UltraGroupBox21.SuspendLayout()
        CType(Me.chkSummaryCDTTotals, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkSummaryPrintDate, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.UltraTabPageControl12.SuspendLayout()
        CType(Me.UltraGroupBox15, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.UltraGroupBox15.SuspendLayout()
        CType(Me.chkXClearOnExit, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkRequireLogon, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkXClearOrders, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkXAccessBanking, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkXAccessSummary, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkXOrderTotals, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkXAccessManager, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkXOrderReprint, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkXOrderEdit, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkXOrderDelete, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkXOrders, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtSPConfirm, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtSPNew, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtSPOld, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.UltraTabPageControl15.SuspendLayout()
        CType(Me.UltraGroupBox17, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.UltraGroupBox17.SuspendLayout()
        CType(Me.chkSetPutQty, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.UltraTabPageControl14.SuspendLayout()
        CType(Me.UltraGroupBox16, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.UltraGroupBox16.SuspendLayout()
        CType(Me.txtEmailFrequency, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkEmailError, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkShowOnlineTotals, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkPrintPayPalID, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbBackupDay, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkBackupDBOnline, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkEnableOnline, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtOLText, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lstOnline, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtOnline, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.utcSettings, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.utcSettings.SuspendLayout()
        Me.SuspendLayout()
        '
        'UltraTabPageControl3
        '
        Me.UltraTabPageControl3.Controls.Add(Me.UltraGroupBox4)
        Me.UltraTabPageControl3.Location = New System.Drawing.Point(-10000, -10000)
        Me.UltraTabPageControl3.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.UltraTabPageControl3.Name = "UltraTabPageControl3"
        Me.UltraTabPageControl3.Size = New System.Drawing.Size(546, 602)
        '
        'UltraGroupBox4
        '
        Appearance1.BackColor = System.Drawing.Color.Transparent
        Me.UltraGroupBox4.Appearance = Appearance1
        Me.UltraGroupBox4.Controls.Add(Me.chkIsTabletPC)
        Me.UltraGroupBox4.Controls.Add(Me.chkCenterMainForm)
        Me.UltraGroupBox4.Controls.Add(Me.chkLastOrdered)
        Me.UltraGroupBox4.Controls.Add(Me.chkNumberOrdered)
        Me.UltraGroupBox4.Controls.Add(Me.chkAutoDelPastOrders)
        Me.UltraGroupBox4.Controls.Add(Me.chkAutoCashCard)
        Me.UltraGroupBox4.Controls.Add(Me.chkAutoMarkAsPaid)
        Me.UltraGroupBox4.Controls.Add(Me.optMainSubSystem)
        Me.UltraGroupBox4.Controls.Add(Me.chkPartOfMultiSystem)
        Me.UltraGroupBox4.Controls.Add(Me.chkFirstOrdered)
        Me.UltraGroupBox4.Controls.Add(Me.chkShowMinimise)
        Me.UltraGroupBox4.Controls.Add(Me.chkSaveCustomerHistory)
        Me.UltraGroupBox4.Controls.Add(Me.chkShowHomeAfterPrint)
        Me.UltraGroupBox4.Controls.Add(Me.chkSaveDishHistory)
        Me.UltraGroupBox4.Controls.Add(Me.chkPasswordTakings)
        Me.UltraGroupBox4.Controls.Add(Me.chkDisableCursor)
        Me.UltraGroupBox4.Controls.Add(Me.chkShowLabelText)
        Me.UltraGroupBox4.Controls.Add(Me.chkCAP)
        Me.UltraGroupBox4.Controls.Add(Me.txtCAP)
        Me.UltraGroupBox4.Controls.Add(Me.UltraLabel18)
        Me.UltraGroupBox4.Location = New System.Drawing.Point(15, 11)
        Me.UltraGroupBox4.Name = "UltraGroupBox4"
        Me.UltraGroupBox4.Size = New System.Drawing.Size(517, 570)
        Me.UltraGroupBox4.TabIndex = 18
        Me.UltraGroupBox4.Text = "General"
        '
        'chkIsTabletPC
        '
        Appearance2.FontData.Name = "Segoe UI"
        Appearance2.FontData.SizeInPoints = 10.0!
        Me.chkIsTabletPC.Appearance = Appearance2
        Me.chkIsTabletPC.BackColor = System.Drawing.Color.Transparent
        Me.chkIsTabletPC.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkIsTabletPC.Location = New System.Drawing.Point(25, 392)
        Me.chkIsTabletPC.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkIsTabletPC.Name = "chkIsTabletPC"
        Me.chkIsTabletPC.Size = New System.Drawing.Size(320, 26)
        Me.chkIsTabletPC.TabIndex = 59
        Me.chkIsTabletPC.Text = "This is a tablet PC"
        '
        'chkCenterMainForm
        '
        Appearance3.FontData.Name = "Segoe UI"
        Appearance3.FontData.SizeInPoints = 10.0!
        Me.chkCenterMainForm.Appearance = Appearance3
        Me.chkCenterMainForm.BackColor = System.Drawing.Color.Transparent
        Me.chkCenterMainForm.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkCenterMainForm.Location = New System.Drawing.Point(25, 292)
        Me.chkCenterMainForm.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkCenterMainForm.Name = "chkCenterMainForm"
        Me.chkCenterMainForm.Size = New System.Drawing.Size(320, 26)
        Me.chkCenterMainForm.TabIndex = 58
        Me.chkCenterMainForm.Text = "Center main form on startup"
        '
        'chkLastOrdered
        '
        Appearance4.FontData.Name = "Segoe UI"
        Appearance4.FontData.SizeInPoints = 10.0!
        Me.chkLastOrdered.Appearance = Appearance4
        Me.chkLastOrdered.BackColor = System.Drawing.Color.Transparent
        Me.chkLastOrdered.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkLastOrdered.Location = New System.Drawing.Point(258, 224)
        Me.chkLastOrdered.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkLastOrdered.Name = "chkLastOrdered"
        Me.chkLastOrdered.Size = New System.Drawing.Size(201, 26)
        Me.chkLastOrdered.TabIndex = 57
        Me.chkLastOrdered.Text = "Save/show date of last order"
        '
        'chkNumberOrdered
        '
        Appearance5.FontData.Name = "Segoe UI"
        Appearance5.FontData.SizeInPoints = 10.0!
        Me.chkNumberOrdered.Appearance = Appearance5
        Me.chkNumberOrdered.BackColor = System.Drawing.Color.Transparent
        Me.chkNumberOrdered.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkNumberOrdered.Location = New System.Drawing.Point(258, 190)
        Me.chkNumberOrdered.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkNumberOrdered.Name = "chkNumberOrdered"
        Me.chkNumberOrdered.Size = New System.Drawing.Size(203, 26)
        Me.chkNumberOrdered.TabIndex = 56
        Me.chkNumberOrdered.Text = "Save/show number of orders"
        '
        'chkAutoDelPastOrders
        '
        Appearance6.FontData.Name = "Segoe UI"
        Appearance6.FontData.SizeInPoints = 10.0!
        Me.chkAutoDelPastOrders.Appearance = Appearance6
        Me.chkAutoDelPastOrders.BackColor = System.Drawing.Color.Transparent
        Me.chkAutoDelPastOrders.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkAutoDelPastOrders.Location = New System.Drawing.Point(25, 224)
        Me.chkAutoDelPastOrders.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkAutoDelPastOrders.Name = "chkAutoDelPastOrders"
        Me.chkAutoDelPastOrders.Size = New System.Drawing.Size(214, 26)
        Me.chkAutoDelPastOrders.TabIndex = 55
        Me.chkAutoDelPastOrders.Text = "Auto delete past orders"
        '
        'chkAutoCashCard
        '
        Appearance7.FontData.Name = "Segoe UI"
        Appearance7.FontData.SizeInPoints = 10.0!
        Me.chkAutoCashCard.Appearance = Appearance7
        Me.chkAutoCashCard.BackColor = System.Drawing.Color.Transparent
        Me.chkAutoCashCard.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkAutoCashCard.Location = New System.Drawing.Point(25, 258)
        Me.chkAutoCashCard.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkAutoCashCard.Name = "chkAutoCashCard"
        Me.chkAutoCashCard.Size = New System.Drawing.Size(320, 26)
        Me.chkAutoCashCard.TabIndex = 54
        Me.chkAutoCashCard.Text = "Auto calculate cash/card on split payments"
        '
        'chkAutoMarkAsPaid
        '
        Appearance8.FontData.Name = "Segoe UI"
        Appearance8.FontData.SizeInPoints = 10.0!
        Me.chkAutoMarkAsPaid.Appearance = Appearance8
        Me.chkAutoMarkAsPaid.BackColor = System.Drawing.Color.Transparent
        Me.chkAutoMarkAsPaid.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkAutoMarkAsPaid.Location = New System.Drawing.Point(258, 100)
        Me.chkAutoMarkAsPaid.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkAutoMarkAsPaid.Name = "chkAutoMarkAsPaid"
        Me.chkAutoMarkAsPaid.Size = New System.Drawing.Size(217, 26)
        Me.chkAutoMarkAsPaid.TabIndex = 48
        Me.chkAutoMarkAsPaid.Text = "Auto mark cash & card as paid"
        '
        'optMainSubSystem
        '
        Appearance9.BackColor = System.Drawing.Color.Transparent
        Appearance9.FontData.Name = "Segoe UI"
        Appearance9.FontData.SizeInPoints = 10.0!
        Me.optMainSubSystem.Appearance = Appearance9
        Me.optMainSubSystem.BackColor = System.Drawing.Color.Transparent
        Me.optMainSubSystem.BackColorInternal = System.Drawing.Color.Transparent
        Me.optMainSubSystem.BorderStyle = Infragistics.Win.UIElementBorderStyle.None
        ValueListItem5.DataValue = "MAIN"
        ValueListItem5.DisplayText = "This is the main system"
        ValueListItem6.DataValue = "SUB"
        ValueListItem6.DisplayText = "This is a subsystem"
        Me.optMainSubSystem.Items.AddRange(New Infragistics.Win.ValueListItem() {ValueListItem5, ValueListItem6})
        Me.optMainSubSystem.Location = New System.Drawing.Point(59, 345)
        Me.optMainSubSystem.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.optMainSubSystem.Name = "optMainSubSystem"
        Me.optMainSubSystem.Size = New System.Drawing.Size(165, 48)
        Me.optMainSubSystem.TabIndex = 47
        '
        'chkPartOfMultiSystem
        '
        Appearance10.FontData.Name = "Segoe UI"
        Appearance10.FontData.SizeInPoints = 10.0!
        Me.chkPartOfMultiSystem.Appearance = Appearance10
        Me.chkPartOfMultiSystem.BackColor = System.Drawing.Color.Transparent
        Me.chkPartOfMultiSystem.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkPartOfMultiSystem.Location = New System.Drawing.Point(25, 322)
        Me.chkPartOfMultiSystem.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkPartOfMultiSystem.Name = "chkPartOfMultiSystem"
        Me.chkPartOfMultiSystem.Size = New System.Drawing.Size(243, 26)
        Me.chkPartOfMultiSystem.TabIndex = 46
        Me.chkPartOfMultiSystem.Text = "This system is part of a multisystem"
        '
        'chkFirstOrdered
        '
        Appearance11.FontData.Name = "Segoe UI"
        Appearance11.FontData.SizeInPoints = 10.0!
        Me.chkFirstOrdered.Appearance = Appearance11
        Me.chkFirstOrdered.BackColor = System.Drawing.Color.Transparent
        Me.chkFirstOrdered.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkFirstOrdered.Location = New System.Drawing.Point(25, 190)
        Me.chkFirstOrdered.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkFirstOrdered.Name = "chkFirstOrdered"
        Me.chkFirstOrdered.Size = New System.Drawing.Size(188, 26)
        Me.chkFirstOrdered.TabIndex = 45
        Me.chkFirstOrdered.Text = "Save/show first order date"
        '
        'chkShowMinimise
        '
        Appearance12.FontData.Name = "Segoe UI"
        Appearance12.FontData.SizeInPoints = 10.0!
        Me.chkShowMinimise.Appearance = Appearance12
        Me.chkShowMinimise.BackColor = System.Drawing.Color.Transparent
        Me.chkShowMinimise.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkShowMinimise.Location = New System.Drawing.Point(258, 130)
        Me.chkShowMinimise.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkShowMinimise.Name = "chkShowMinimise"
        Me.chkShowMinimise.Size = New System.Drawing.Size(259, 26)
        Me.chkShowMinimise.TabIndex = 44
        Me.chkShowMinimise.Text = "Show minimise button on main screen"
        '
        'chkSaveCustomerHistory
        '
        Appearance13.FontData.Name = "Segoe UI"
        Appearance13.FontData.SizeInPoints = 10.0!
        Me.chkSaveCustomerHistory.Appearance = Appearance13
        Me.chkSaveCustomerHistory.BackColor = System.Drawing.Color.Transparent
        Me.chkSaveCustomerHistory.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkSaveCustomerHistory.Location = New System.Drawing.Point(258, 160)
        Me.chkSaveCustomerHistory.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkSaveCustomerHistory.Name = "chkSaveCustomerHistory"
        Me.chkSaveCustomerHistory.Size = New System.Drawing.Size(188, 26)
        Me.chkSaveCustomerHistory.TabIndex = 43
        Me.chkSaveCustomerHistory.Text = "Save customer's last order"
        '
        'chkShowHomeAfterPrint
        '
        Appearance14.FontData.Name = "Segoe UI"
        Appearance14.FontData.SizeInPoints = 10.0!
        Me.chkShowHomeAfterPrint.Appearance = Appearance14
        Me.chkShowHomeAfterPrint.BackColor = System.Drawing.Color.Transparent
        Me.chkShowHomeAfterPrint.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkShowHomeAfterPrint.Location = New System.Drawing.Point(25, 130)
        Me.chkShowHomeAfterPrint.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkShowHomeAfterPrint.Name = "chkShowHomeAfterPrint"
        Me.chkShowHomeAfterPrint.Size = New System.Drawing.Size(214, 26)
        Me.chkShowHomeAfterPrint.TabIndex = 42
        Me.chkShowHomeAfterPrint.Text = "Autoshow home after printing"
        '
        'chkSaveDishHistory
        '
        Appearance15.FontData.Name = "Segoe UI"
        Appearance15.FontData.SizeInPoints = 10.0!
        Me.chkSaveDishHistory.Appearance = Appearance15
        Me.chkSaveDishHistory.BackColor = System.Drawing.Color.Transparent
        Me.chkSaveDishHistory.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkSaveDishHistory.Location = New System.Drawing.Point(25, 160)
        Me.chkSaveDishHistory.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkSaveDishHistory.Name = "chkSaveDishHistory"
        Me.chkSaveDishHistory.Size = New System.Drawing.Size(169, 26)
        Me.chkSaveDishHistory.TabIndex = 41
        Me.chkSaveDishHistory.Text = "Save items sold history"
        '
        'chkPasswordTakings
        '
        Appearance16.FontData.Name = "Segoe UI"
        Appearance16.FontData.SizeInPoints = 10.0!
        Me.chkPasswordTakings.Appearance = Appearance16
        Me.chkPasswordTakings.BackColor = System.Drawing.Color.Transparent
        Me.chkPasswordTakings.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkPasswordTakings.Location = New System.Drawing.Point(258, 70)
        Me.chkPasswordTakings.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkPasswordTakings.Name = "chkPasswordTakings"
        Me.chkPasswordTakings.Size = New System.Drawing.Size(233, 26)
        Me.chkPasswordTakings.TabIndex = 40
        Me.chkPasswordTakings.Text = "Password protect takings (totals)"
        '
        'chkDisableCursor
        '
        Appearance17.FontData.Name = "Segoe UI"
        Appearance17.FontData.SizeInPoints = 10.0!
        Me.chkDisableCursor.Appearance = Appearance17
        Me.chkDisableCursor.BackColor = System.Drawing.Color.Transparent
        Me.chkDisableCursor.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkDisableCursor.Location = New System.Drawing.Point(25, 100)
        Me.chkDisableCursor.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkDisableCursor.Name = "chkDisableCursor"
        Me.chkDisableCursor.Size = New System.Drawing.Size(143, 26)
        Me.chkDisableCursor.TabIndex = 38
        Me.chkDisableCursor.Text = "Hide mouse cursor"
        '
        'chkShowLabelText
        '
        Appearance18.FontData.Name = "Segoe UI"
        Appearance18.FontData.SizeInPoints = 10.0!
        Me.chkShowLabelText.Appearance = Appearance18
        Me.chkShowLabelText.BackColor = System.Drawing.Color.Transparent
        Me.chkShowLabelText.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkShowLabelText.Location = New System.Drawing.Point(25, 70)
        Me.chkShowLabelText.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkShowLabelText.Name = "chkShowLabelText"
        Me.chkShowLabelText.Size = New System.Drawing.Size(143, 26)
        Me.chkShowLabelText.TabIndex = 37
        Me.chkShowLabelText.Text = "Show button labels"
        '
        'chkCAP
        '
        Appearance19.FontData.Name = "Segoe UI"
        Appearance19.FontData.SizeInPoints = 10.0!
        Me.chkCAP.Appearance = Appearance19
        Me.chkCAP.BackColor = System.Drawing.Color.Transparent
        Me.chkCAP.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkCAP.Location = New System.Drawing.Point(25, 40)
        Me.chkCAP.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkCAP.Name = "chkCAP"
        Me.chkCAP.Size = New System.Drawing.Size(52, 26)
        Me.chkCAP.TabIndex = 34
        Me.chkCAP.Text = "Add"
        '
        'txtCAP
        '
        Me.txtCAP.Location = New System.Drawing.Point(80, 41)
        Me.txtCAP.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtCAP.Name = "txtCAP"
        Me.txtCAP.Size = New System.Drawing.Size(42, 24)
        Me.txtCAP.TabIndex = 17
        Me.txtCAP.UseAppStyling = False
        Me.txtCAP.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'UltraLabel18
        '
        Me.UltraLabel18.AutoSize = True
        Me.UltraLabel18.Location = New System.Drawing.Point(131, 43)
        Me.UltraLabel18.Name = "UltraLabel18"
        Me.UltraLabel18.Size = New System.Drawing.Size(231, 19)
        Me.UltraLabel18.TabIndex = 16
        Me.UltraLabel18.Text = "pence per head for chutneys && pickles"
        '
        'UltraTabPageControl1
        '
        Me.UltraTabPageControl1.Controls.Add(Me.UltraGroupBox6)
        Me.UltraTabPageControl1.Controls.Add(Me.UltraGroupBox5)
        Me.UltraTabPageControl1.Location = New System.Drawing.Point(-10000, -10000)
        Me.UltraTabPageControl1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.UltraTabPageControl1.Name = "UltraTabPageControl1"
        Me.UltraTabPageControl1.Size = New System.Drawing.Size(546, 602)
        '
        'UltraGroupBox6
        '
        Appearance20.BackColor = System.Drawing.Color.Transparent
        Me.UltraGroupBox6.Appearance = Appearance20
        Me.UltraGroupBox6.Controls.Add(Me.lblDiscAmtLbl)
        Me.UltraGroupBox6.Controls.Add(Me.chkGiveDiscount)
        Me.UltraGroupBox6.Controls.Add(Me.txtDiscountExc)
        Me.UltraGroupBox6.Controls.Add(Me.optDiscount)
        Me.UltraGroupBox6.Controls.Add(Me.UltraLabel4)
        Me.UltraGroupBox6.Controls.Add(Me.chkDiscountExc)
        Me.UltraGroupBox6.Controls.Add(Me.txtDiscount)
        Me.UltraGroupBox6.Location = New System.Drawing.Point(282, 11)
        Me.UltraGroupBox6.Name = "UltraGroupBox6"
        Me.UltraGroupBox6.Size = New System.Drawing.Size(226, 255)
        Me.UltraGroupBox6.TabIndex = 19
        Me.UltraGroupBox6.Text = "Collection"
        '
        'lblDiscAmtLbl
        '
        Me.lblDiscAmtLbl.AutoSize = True
        Me.lblDiscAmtLbl.Location = New System.Drawing.Point(18, 202)
        Me.lblDiscAmtLbl.Name = "lblDiscAmtLbl"
        Me.lblDiscAmtLbl.Size = New System.Drawing.Size(74, 19)
        Me.lblDiscAmtLbl.TabIndex = 11
        Me.lblDiscAmtLbl.Text = "Amount (£):"
        '
        'chkGiveDiscount
        '
        Appearance21.FontData.Name = "Segoe UI"
        Appearance21.FontData.SizeInPoints = 10.0!
        Me.chkGiveDiscount.Appearance = Appearance21
        Me.chkGiveDiscount.BackColor = System.Drawing.Color.Transparent
        Me.chkGiveDiscount.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkGiveDiscount.Location = New System.Drawing.Point(30, 45)
        Me.chkGiveDiscount.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkGiveDiscount.Name = "chkGiveDiscount"
        Me.chkGiveDiscount.Size = New System.Drawing.Size(178, 26)
        Me.chkGiveDiscount.TabIndex = 5
        Me.chkGiveDiscount.Text = "Give discount"
        '
        'txtDiscountExc
        '
        Me.txtDiscountExc.Location = New System.Drawing.Point(98, 198)
        Me.txtDiscountExc.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtDiscountExc.Name = "txtDiscountExc"
        Me.txtDiscountExc.Size = New System.Drawing.Size(69, 24)
        Me.txtDiscountExc.TabIndex = 10
        Me.txtDiscountExc.UseAppStyling = False
        Me.txtDiscountExc.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'optDiscount
        '
        Appearance22.FontData.Name = "Segoe UI"
        Appearance22.FontData.SizeInPoints = 10.0!
        Me.optDiscount.Appearance = Appearance22
        Me.optDiscount.BackColor = System.Drawing.Color.Transparent
        Me.optDiscount.BackColorInternal = System.Drawing.Color.Transparent
        Me.optDiscount.BorderStyle = Infragistics.Win.UIElementBorderStyle.None
        ValueListItem1.DataValue = "P"
        ValueListItem1.DisplayText = "Percentage"
        ValueListItem2.DataValue = "A"
        ValueListItem2.DisplayText = "Amount"
        Me.optDiscount.Items.AddRange(New Infragistics.Win.ValueListItem() {ValueListItem1, ValueListItem2})
        Me.optDiscount.Location = New System.Drawing.Point(98, 108)
        Me.optDiscount.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.optDiscount.Name = "optDiscount"
        Me.optDiscount.Size = New System.Drawing.Size(105, 48)
        Me.optDiscount.TabIndex = 4
        '
        'UltraLabel4
        '
        Me.UltraLabel4.AutoSize = True
        Me.UltraLabel4.Location = New System.Drawing.Point(51, 78)
        Me.UltraLabel4.Name = "UltraLabel4"
        Me.UltraLabel4.Size = New System.Drawing.Size(41, 19)
        Me.UltraLabel4.TabIndex = 9
        Me.UltraLabel4.Text = "Value:"
        '
        'chkDiscountExc
        '
        Appearance23.FontData.Name = "Segoe UI"
        Appearance23.FontData.SizeInPoints = 10.0!
        Me.chkDiscountExc.Appearance = Appearance23
        Me.chkDiscountExc.BackColor = System.Drawing.Color.Transparent
        Me.chkDiscountExc.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkDiscountExc.Location = New System.Drawing.Point(30, 164)
        Me.chkDiscountExc.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkDiscountExc.Name = "chkDiscountExc"
        Me.chkDiscountExc.Size = New System.Drawing.Size(178, 26)
        Me.chkDiscountExc.TabIndex = 6
        Me.chkDiscountExc.Text = "Only on amounts over:"
        '
        'txtDiscount
        '
        Me.txtDiscount.Location = New System.Drawing.Point(98, 74)
        Me.txtDiscount.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtDiscount.Name = "txtDiscount"
        Me.txtDiscount.Size = New System.Drawing.Size(69, 24)
        Me.txtDiscount.TabIndex = 7
        Me.txtDiscount.UseAppStyling = False
        Me.txtDiscount.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'UltraGroupBox5
        '
        Appearance24.BackColor = System.Drawing.Color.Transparent
        Me.UltraGroupBox5.Appearance = Appearance24
        Me.UltraGroupBox5.Controls.Add(Me.UltraLabel97)
        Me.UltraGroupBox5.Controls.Add(Me.txtMyPostcode)
        Me.UltraGroupBox5.Controls.Add(Me.cmdGetTime)
        Me.UltraGroupBox5.Controls.Add(Me.chkDTime)
        Me.UltraGroupBox5.Controls.Add(Me.UltraLabel83)
        Me.UltraGroupBox5.Controls.Add(Me.txtDTime)
        Me.UltraGroupBox5.Controls.Add(Me.chkMinOrderAmount)
        Me.UltraGroupBox5.Controls.Add(Me.UltraLabel82)
        Me.UltraGroupBox5.Controls.Add(Me.txtMinOrderAmount)
        Me.UltraGroupBox5.Controls.Add(Me.lblDelivAmtLbl)
        Me.UltraGroupBox5.Controls.Add(Me.chkDelivCharge)
        Me.UltraGroupBox5.Controls.Add(Me.txtDelivUnder)
        Me.UltraGroupBox5.Controls.Add(Me.optDeliv)
        Me.UltraGroupBox5.Controls.Add(Me.UltraLabel1)
        Me.UltraGroupBox5.Controls.Add(Me.chkDelivUnder)
        Me.UltraGroupBox5.Controls.Add(Me.txtDeliv)
        Me.UltraGroupBox5.Location = New System.Drawing.Point(38, 11)
        Me.UltraGroupBox5.Name = "UltraGroupBox5"
        Me.UltraGroupBox5.Size = New System.Drawing.Size(226, 558)
        Me.UltraGroupBox5.TabIndex = 18
        Me.UltraGroupBox5.Text = "Delivery"
        '
        'UltraLabel97
        '
        Me.UltraLabel97.AutoSize = True
        Me.UltraLabel97.Location = New System.Drawing.Point(16, 453)
        Me.UltraLabel97.Name = "UltraLabel97"
        Me.UltraLabel97.Size = New System.Drawing.Size(94, 19)
        Me.UltraLabel97.TabIndex = 91
        Me.UltraLabel97.Text = "Your postcode:"
        '
        'txtMyPostcode
        '
        Me.txtMyPostcode.Location = New System.Drawing.Point(116, 450)
        Me.txtMyPostcode.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtMyPostcode.Name = "txtMyPostcode"
        Me.txtMyPostcode.Size = New System.Drawing.Size(87, 24)
        Me.txtMyPostcode.TabIndex = 90
        Me.txtMyPostcode.UseAppStyling = False
        Me.txtMyPostcode.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'cmdGetTime
        '
        Me.cmdGetTime.Location = New System.Drawing.Point(98, 395)
        Me.cmdGetTime.Name = "cmdGetTime"
        Me.cmdGetTime.ShowFocusRect = False
        Me.cmdGetTime.ShowOutline = False
        Me.cmdGetTime.Size = New System.Drawing.Size(69, 26)
        Me.cmdGetTime.TabIndex = 89
        Me.cmdGetTime.Text = "Time"
        '
        'chkDTime
        '
        Appearance25.FontData.Name = "Segoe UI"
        Appearance25.FontData.SizeInPoints = 10.0!
        Me.chkDTime.Appearance = Appearance25
        Me.chkDTime.BackColor = System.Drawing.Color.Transparent
        Me.chkDTime.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkDTime.Location = New System.Drawing.Point(30, 330)
        Me.chkDTime.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkDTime.Name = "chkDTime"
        Me.chkDTime.Size = New System.Drawing.Size(178, 26)
        Me.chkDTime.TabIndex = 18
        Me.chkDTime.Text = "Last time for delivery:"
        '
        'UltraLabel83
        '
        Me.UltraLabel83.AutoSize = True
        Me.UltraLabel83.Location = New System.Drawing.Point(55, 367)
        Me.UltraLabel83.Name = "UltraLabel83"
        Me.UltraLabel83.Size = New System.Drawing.Size(37, 19)
        Me.UltraLabel83.TabIndex = 17
        Me.UltraLabel83.Text = "Time:"
        '
        'txtDTime
        '
        Me.txtDTime.Location = New System.Drawing.Point(98, 364)
        Me.txtDTime.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtDTime.Name = "txtDTime"
        Me.txtDTime.Size = New System.Drawing.Size(69, 24)
        Me.txtDTime.TabIndex = 16
        Me.txtDTime.UseAppStyling = False
        Me.txtDTime.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'chkMinOrderAmount
        '
        Appearance26.FontData.Name = "Segoe UI"
        Appearance26.FontData.SizeInPoints = 10.0!
        Me.chkMinOrderAmount.Appearance = Appearance26
        Me.chkMinOrderAmount.BackColor = System.Drawing.Color.Transparent
        Me.chkMinOrderAmount.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkMinOrderAmount.Location = New System.Drawing.Point(30, 247)
        Me.chkMinOrderAmount.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkMinOrderAmount.Name = "chkMinOrderAmount"
        Me.chkMinOrderAmount.Size = New System.Drawing.Size(178, 26)
        Me.chkMinOrderAmount.TabIndex = 15
        Me.chkMinOrderAmount.Text = "Proceed if order is over:"
        '
        'UltraLabel82
        '
        Me.UltraLabel82.AutoSize = True
        Me.UltraLabel82.Location = New System.Drawing.Point(18, 285)
        Me.UltraLabel82.Name = "UltraLabel82"
        Me.UltraLabel82.Size = New System.Drawing.Size(74, 19)
        Me.UltraLabel82.TabIndex = 13
        Me.UltraLabel82.Text = "Amount (£):"
        '
        'txtMinOrderAmount
        '
        Me.txtMinOrderAmount.Location = New System.Drawing.Point(98, 281)
        Me.txtMinOrderAmount.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtMinOrderAmount.Name = "txtMinOrderAmount"
        Me.txtMinOrderAmount.Size = New System.Drawing.Size(69, 24)
        Me.txtMinOrderAmount.TabIndex = 12
        Me.txtMinOrderAmount.UseAppStyling = False
        Me.txtMinOrderAmount.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'lblDelivAmtLbl
        '
        Me.lblDelivAmtLbl.AutoSize = True
        Me.lblDelivAmtLbl.Location = New System.Drawing.Point(18, 202)
        Me.lblDelivAmtLbl.Name = "lblDelivAmtLbl"
        Me.lblDelivAmtLbl.Size = New System.Drawing.Size(74, 19)
        Me.lblDelivAmtLbl.TabIndex = 11
        Me.lblDelivAmtLbl.Text = "Amount (£):"
        '
        'chkDelivCharge
        '
        Appearance27.FontData.Name = "Segoe UI"
        Appearance27.FontData.SizeInPoints = 10.0!
        Me.chkDelivCharge.Appearance = Appearance27
        Me.chkDelivCharge.BackColor = System.Drawing.Color.Transparent
        Me.chkDelivCharge.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkDelivCharge.Location = New System.Drawing.Point(30, 45)
        Me.chkDelivCharge.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkDelivCharge.Name = "chkDelivCharge"
        Me.chkDelivCharge.Size = New System.Drawing.Size(178, 26)
        Me.chkDelivCharge.TabIndex = 5
        Me.chkDelivCharge.Text = "Add delivery charge"
        '
        'txtDelivUnder
        '
        Me.txtDelivUnder.Location = New System.Drawing.Point(98, 198)
        Me.txtDelivUnder.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtDelivUnder.Name = "txtDelivUnder"
        Me.txtDelivUnder.Size = New System.Drawing.Size(69, 24)
        Me.txtDelivUnder.TabIndex = 10
        Me.txtDelivUnder.UseAppStyling = False
        Me.txtDelivUnder.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'optDeliv
        '
        Appearance28.FontData.Name = "Segoe UI"
        Appearance28.FontData.SizeInPoints = 10.0!
        Me.optDeliv.Appearance = Appearance28
        Me.optDeliv.BackColor = System.Drawing.Color.Transparent
        Me.optDeliv.BackColorInternal = System.Drawing.Color.Transparent
        Me.optDeliv.BorderStyle = Infragistics.Win.UIElementBorderStyle.None
        ValueListItem32.DataValue = "P"
        ValueListItem32.DisplayText = "Percentage"
        ValueListItem33.DataValue = "A"
        ValueListItem33.DisplayText = "Amount"
        Me.optDeliv.Items.AddRange(New Infragistics.Win.ValueListItem() {ValueListItem32, ValueListItem33})
        Me.optDeliv.Location = New System.Drawing.Point(98, 108)
        Me.optDeliv.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.optDeliv.Name = "optDeliv"
        Me.optDeliv.Size = New System.Drawing.Size(105, 48)
        Me.optDeliv.TabIndex = 4
        '
        'UltraLabel1
        '
        Me.UltraLabel1.AutoSize = True
        Me.UltraLabel1.Location = New System.Drawing.Point(51, 78)
        Me.UltraLabel1.Name = "UltraLabel1"
        Me.UltraLabel1.Size = New System.Drawing.Size(41, 19)
        Me.UltraLabel1.TabIndex = 9
        Me.UltraLabel1.Text = "Value:"
        '
        'chkDelivUnder
        '
        Appearance29.FontData.Name = "Segoe UI"
        Appearance29.FontData.SizeInPoints = 10.0!
        Me.chkDelivUnder.Appearance = Appearance29
        Me.chkDelivUnder.BackColor = System.Drawing.Color.Transparent
        Me.chkDelivUnder.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkDelivUnder.Location = New System.Drawing.Point(30, 164)
        Me.chkDelivUnder.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkDelivUnder.Name = "chkDelivUnder"
        Me.chkDelivUnder.Size = New System.Drawing.Size(178, 26)
        Me.chkDelivUnder.TabIndex = 6
        Me.chkDelivUnder.Text = "Only on amounts under:"
        '
        'txtDeliv
        '
        Me.txtDeliv.Location = New System.Drawing.Point(98, 74)
        Me.txtDeliv.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtDeliv.Name = "txtDeliv"
        Me.txtDeliv.Size = New System.Drawing.Size(69, 24)
        Me.txtDeliv.TabIndex = 7
        Me.txtDeliv.UseAppStyling = False
        Me.txtDeliv.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'UltraTabPageControl8
        '
        Me.UltraTabPageControl8.Controls.Add(Me.UltraGroupBox14)
        Me.UltraTabPageControl8.Location = New System.Drawing.Point(-10000, -10000)
        Me.UltraTabPageControl8.Name = "UltraTabPageControl8"
        Me.UltraTabPageControl8.Size = New System.Drawing.Size(546, 602)
        '
        'UltraGroupBox14
        '
        Appearance30.BackColor = System.Drawing.Color.Transparent
        Me.UltraGroupBox14.Appearance = Appearance30
        Me.UltraGroupBox14.Controls.Add(Me.chkRoundingMethod)
        Me.UltraGroupBox14.Controls.Add(Me.cmdDCClear)
        Me.UltraGroupBox14.Controls.Add(Me.lstDiscCharges)
        Me.UltraGroupBox14.Controls.Add(Me.cmdDCAdd)
        Me.UltraGroupBox14.Controls.Add(Me.cmdDCDelete)
        Me.UltraGroupBox14.Controls.Add(Me.cmbDCAorP)
        Me.UltraGroupBox14.Controls.Add(Me.UltraLabel72)
        Me.UltraGroupBox14.Controls.Add(Me.cmbDCType)
        Me.UltraGroupBox14.Controls.Add(Me.UltraLabel71)
        Me.UltraGroupBox14.Controls.Add(Me.txtDCRate)
        Me.UltraGroupBox14.Controls.Add(Me.txtLblValue)
        Me.UltraGroupBox14.Controls.Add(Me.txtDCName)
        Me.UltraGroupBox14.Controls.Add(Me.UltraLabel70)
        Me.UltraGroupBox14.Location = New System.Drawing.Point(38, 11)
        Me.UltraGroupBox14.Name = "UltraGroupBox14"
        Me.UltraGroupBox14.Size = New System.Drawing.Size(470, 527)
        Me.UltraGroupBox14.TabIndex = 19
        Me.UltraGroupBox14.Text = "Discounts && Charges"
        '
        'chkRoundingMethod
        '
        Appearance31.FontData.Name = "Segoe UI"
        Appearance31.FontData.SizeInPoints = 10.0!
        Me.chkRoundingMethod.Appearance = Appearance31
        Me.chkRoundingMethod.BackColor = System.Drawing.Color.Transparent
        Me.chkRoundingMethod.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkRoundingMethod.Location = New System.Drawing.Point(79, 438)
        Me.chkRoundingMethod.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkRoundingMethod.Name = "chkRoundingMethod"
        Me.chkRoundingMethod.Size = New System.Drawing.Size(253, 26)
        Me.chkRoundingMethod.TabIndex = 94
        Me.chkRoundingMethod.Text = "Use '.99' rounding rather than '0.95'"
        '
        'cmdDCClear
        '
        Me.cmdDCClear.Location = New System.Drawing.Point(339, 68)
        Me.cmdDCClear.Name = "cmdDCClear"
        Me.cmdDCClear.ShowFocusRect = False
        Me.cmdDCClear.ShowOutline = False
        Me.cmdDCClear.Size = New System.Drawing.Size(75, 26)
        Me.cmdDCClear.TabIndex = 93
        Me.cmdDCClear.Text = "Clear"
        '
        'lstDiscCharges
        '
        Me.lstDiscCharges.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Me.lstDiscCharges.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstDiscCharges.ItemSettings.AllowEdit = Infragistics.Win.DefaultableBoolean.[False]
        Me.lstDiscCharges.ItemSettings.HideSelection = False
        Me.lstDiscCharges.ItemSettings.HotTracking = True
        Me.lstDiscCharges.Location = New System.Drawing.Point(79, 182)
        Me.lstDiscCharges.Name = "lstDiscCharges"
        Me.lstDiscCharges.ShowGroups = False
        Me.lstDiscCharges.Size = New System.Drawing.Size(242, 229)
        Me.lstDiscCharges.TabIndex = 90
        Me.lstDiscCharges.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        Me.lstDiscCharges.View = Infragistics.Win.UltraWinListView.UltraListViewStyle.List
        Me.lstDiscCharges.ViewSettingsList.ImageSize = New System.Drawing.Size(0, 0)
        Me.lstDiscCharges.ViewSettingsList.MultiColumn = False
        '
        'cmdDCAdd
        '
        Me.cmdDCAdd.Location = New System.Drawing.Point(339, 36)
        Me.cmdDCAdd.Name = "cmdDCAdd"
        Me.cmdDCAdd.ShowFocusRect = False
        Me.cmdDCAdd.ShowOutline = False
        Me.cmdDCAdd.Size = New System.Drawing.Size(75, 26)
        Me.cmdDCAdd.TabIndex = 89
        Me.cmdDCAdd.Text = "Save"
        '
        'cmdDCDelete
        '
        Me.cmdDCDelete.Location = New System.Drawing.Point(339, 182)
        Me.cmdDCDelete.Name = "cmdDCDelete"
        Me.cmdDCDelete.ShowFocusRect = False
        Me.cmdDCDelete.ShowOutline = False
        Me.cmdDCDelete.Size = New System.Drawing.Size(75, 26)
        Me.cmdDCDelete.TabIndex = 88
        Me.cmdDCDelete.Text = "Delete"
        '
        'cmbDCAorP
        '
        Me.cmbDCAorP.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList
        ValueListItem23.DataValue = "A"
        ValueListItem23.DisplayText = "Fixed amount"
        ValueListItem24.DataValue = "P"
        ValueListItem24.DisplayText = "Percentage"
        Me.cmbDCAorP.Items.AddRange(New Infragistics.Win.ValueListItem() {ValueListItem23, ValueListItem24})
        Me.cmbDCAorP.Location = New System.Drawing.Point(145, 99)
        Me.cmbDCAorP.Name = "cmbDCAorP"
        Me.cmbDCAorP.Size = New System.Drawing.Size(176, 26)
        Me.cmbDCAorP.TabIndex = 82
        '
        'UltraLabel72
        '
        Me.UltraLabel72.AutoSize = True
        Me.UltraLabel72.Location = New System.Drawing.Point(14, 103)
        Me.UltraLabel72.Name = "UltraLabel72"
        Me.UltraLabel72.Size = New System.Drawing.Size(125, 19)
        Me.UltraLabel72.TabIndex = 86
        Me.UltraLabel72.Text = "Fixed or Percentage:"
        '
        'cmbDCType
        '
        Me.cmbDCType.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList
        ValueListItem31.DataValue = "Discount"
        ValueListItem31.DisplayText = "Discount"
        ValueListItem30.DataValue = "Charge"
        ValueListItem30.DisplayText = "Charge"
        Me.cmbDCType.Items.AddRange(New Infragistics.Win.ValueListItem() {ValueListItem31, ValueListItem30})
        Me.cmbDCType.Location = New System.Drawing.Point(145, 131)
        Me.cmbDCType.Name = "cmbDCType"
        Me.cmbDCType.Size = New System.Drawing.Size(176, 26)
        Me.cmbDCType.TabIndex = 83
        '
        'UltraLabel71
        '
        Me.UltraLabel71.AutoSize = True
        Me.UltraLabel71.Location = New System.Drawing.Point(103, 135)
        Me.UltraLabel71.Name = "UltraLabel71"
        Me.UltraLabel71.Size = New System.Drawing.Size(36, 19)
        Me.UltraLabel71.TabIndex = 84
        Me.UltraLabel71.Text = "Type:"
        '
        'txtDCRate
        '
        Me.txtDCRate.Location = New System.Drawing.Point(145, 68)
        Me.txtDCRate.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtDCRate.Name = "txtDCRate"
        Me.txtDCRate.Size = New System.Drawing.Size(85, 24)
        Me.txtDCRate.TabIndex = 81
        Me.txtDCRate.UseAppStyling = False
        Me.txtDCRate.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'txtLblValue
        '
        Me.txtLblValue.AutoSize = True
        Me.txtLblValue.Location = New System.Drawing.Point(98, 71)
        Me.txtLblValue.Name = "txtLblValue"
        Me.txtLblValue.Size = New System.Drawing.Size(41, 19)
        Me.txtLblValue.TabIndex = 83
        Me.txtLblValue.Text = "Value:"
        '
        'txtDCName
        '
        Me.txtDCName.Location = New System.Drawing.Point(145, 36)
        Me.txtDCName.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtDCName.MaxLength = 40
        Me.txtDCName.Name = "txtDCName"
        Me.txtDCName.Size = New System.Drawing.Size(176, 24)
        Me.txtDCName.TabIndex = 80
        Me.txtDCName.UseAppStyling = False
        Me.txtDCName.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'UltraLabel70
        '
        Me.UltraLabel70.AutoSize = True
        Me.UltraLabel70.Location = New System.Drawing.Point(96, 39)
        Me.UltraLabel70.Name = "UltraLabel70"
        Me.UltraLabel70.Size = New System.Drawing.Size(43, 19)
        Me.UltraLabel70.TabIndex = 81
        Me.UltraLabel70.Text = "Name:"
        '
        'UltraTabPageControl4
        '
        Me.UltraTabPageControl4.Controls.Add(Me.UltraGroupBox8)
        Me.UltraTabPageControl4.Controls.Add(Me.UltraGroupBox3)
        Me.UltraTabPageControl4.Location = New System.Drawing.Point(-10000, -10000)
        Me.UltraTabPageControl4.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.UltraTabPageControl4.Name = "UltraTabPageControl4"
        Me.UltraTabPageControl4.Size = New System.Drawing.Size(546, 602)
        '
        'UltraGroupBox8
        '
        Appearance32.BackColor = System.Drawing.Color.Transparent
        Me.UltraGroupBox8.Appearance = Appearance32
        Me.UltraGroupBox8.Controls.Add(Me.cmdReleaseCOMPort)
        Me.UltraGroupBox8.Controls.Add(Me.cmdResetActiveCID)
        Me.UltraGroupBox8.Controls.Add(Me.optCometMeteor)
        Me.UltraGroupBox8.Controls.Add(Me.chkDoNotShowCID)
        Me.UltraGroupBox8.Controls.Add(Me.chkEnableRecording)
        Me.UltraGroupBox8.Controls.Add(Me.cmbActiveCIDPort)
        Me.UltraGroupBox8.Controls.Add(Me.UltraLabel10)
        Me.UltraGroupBox8.Controls.Add(Me.chkEnableActiveCID)
        Me.UltraGroupBox8.Location = New System.Drawing.Point(73, 226)
        Me.UltraGroupBox8.Name = "UltraGroupBox8"
        Me.UltraGroupBox8.Size = New System.Drawing.Size(400, 249)
        Me.UltraGroupBox8.TabIndex = 20
        Me.UltraGroupBox8.Text = "ActiveCID"
        '
        'cmdReleaseCOMPort
        '
        Me.cmdReleaseCOMPort.Location = New System.Drawing.Point(74, 187)
        Me.cmdReleaseCOMPort.Name = "cmdReleaseCOMPort"
        Me.cmdReleaseCOMPort.ShowFocusRect = False
        Me.cmdReleaseCOMPort.ShowOutline = False
        Me.cmdReleaseCOMPort.Size = New System.Drawing.Size(110, 26)
        Me.cmdReleaseCOMPort.TabIndex = 75
        Me.cmdReleaseCOMPort.Text = "Release COM"
        '
        'cmdResetActiveCID
        '
        Me.cmdResetActiveCID.Location = New System.Drawing.Point(190, 187)
        Me.cmdResetActiveCID.Name = "cmdResetActiveCID"
        Me.cmdResetActiveCID.ShowFocusRect = False
        Me.cmdResetActiveCID.ShowOutline = False
        Me.cmdResetActiveCID.Size = New System.Drawing.Size(110, 26)
        Me.cmdResetActiveCID.TabIndex = 74
        Me.cmdResetActiveCID.Text = "Reset ActiveCID"
        '
        'optCometMeteor
        '
        Appearance33.FontData.Name = "Segoe UI"
        Appearance33.FontData.SizeInPoints = 10.0!
        Me.optCometMeteor.Appearance = Appearance33
        Me.optCometMeteor.BackColor = System.Drawing.Color.Transparent
        Me.optCometMeteor.BackColorInternal = System.Drawing.Color.Transparent
        Me.optCometMeteor.BorderStyle = Infragistics.Win.UIElementBorderStyle.None
        ValueListItem26.DataValue = "Meteor"
        ValueListItem26.DisplayText = "Use CTI Meteor"
        ValueListItem27.CheckState = System.Windows.Forms.CheckState.Checked
        ValueListItem27.DataValue = "Comet"
        ValueListItem27.DisplayText = "Use CTI Comet"
        Me.optCometMeteor.Items.AddRange(New Infragistics.Win.ValueListItem() {ValueListItem26, ValueListItem27})
        Me.optCometMeteor.Location = New System.Drawing.Point(23, 131)
        Me.optCometMeteor.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.optCometMeteor.Name = "optCometMeteor"
        Me.optCometMeteor.Size = New System.Drawing.Size(178, 48)
        Me.optCometMeteor.TabIndex = 24
        Me.optCometMeteor.UseAppStyling = False
        Me.optCometMeteor.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'chkDoNotShowCID
        '
        Appearance34.FontData.Name = "Segoe UI"
        Appearance34.FontData.SizeInPoints = 10.0!
        Me.chkDoNotShowCID.Appearance = Appearance34
        Me.chkDoNotShowCID.BackColor = System.Drawing.Color.Transparent
        Me.chkDoNotShowCID.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkDoNotShowCID.Location = New System.Drawing.Point(23, 98)
        Me.chkDoNotShowCID.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkDoNotShowCID.Name = "chkDoNotShowCID"
        Me.chkDoNotShowCID.Size = New System.Drawing.Size(355, 26)
        Me.chkDoNotShowCID.TabIndex = 23
        Me.chkDoNotShowCID.Text = "Do not show caller ID box when caller id is unavailable"
        '
        'chkEnableRecording
        '
        Appearance35.FontData.Name = "Segoe UI"
        Appearance35.FontData.SizeInPoints = 10.0!
        Me.chkEnableRecording.Appearance = Appearance35
        Me.chkEnableRecording.BackColor = System.Drawing.Color.Transparent
        Me.chkEnableRecording.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkEnableRecording.Location = New System.Drawing.Point(23, 64)
        Me.chkEnableRecording.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkEnableRecording.Name = "chkEnableRecording"
        Me.chkEnableRecording.Size = New System.Drawing.Size(178, 26)
        Me.chkEnableRecording.TabIndex = 22
        Me.chkEnableRecording.Text = "Enable voice recording"
        '
        'cmbActiveCIDPort
        '
        ValueListItem34.DataValue = "ValueListItem0"
        ValueListItem34.DisplayText = "COM1"
        ValueListItem35.DataValue = "ValueListItem1"
        ValueListItem35.DisplayText = "COM2"
        ValueListItem36.DataValue = "ValueListItem2"
        ValueListItem36.DisplayText = "COM3"
        ValueListItem37.DataValue = "ValueListItem3"
        ValueListItem37.DisplayText = "COM4"
        ValueListItem38.DataValue = "ValueListItem4"
        ValueListItem38.DisplayText = "COM5"
        ValueListItem39.DataValue = "ValueListItem5"
        ValueListItem39.DisplayText = "COM6"
        ValueListItem40.DataValue = "ValueListItem6"
        ValueListItem40.DisplayText = "COM7"
        ValueListItem41.DataValue = "ValueListItem7"
        ValueListItem41.DisplayText = "COM8"
        ValueListItem42.DataValue = "ValueListItem8"
        ValueListItem42.DisplayText = "COM9"
        ValueListItem43.DataValue = "ValueListItem9"
        ValueListItem43.DisplayText = "COM10"
        Me.cmbActiveCIDPort.Items.AddRange(New Infragistics.Win.ValueListItem() {ValueListItem34, ValueListItem35, ValueListItem36, ValueListItem37, ValueListItem38, ValueListItem39, ValueListItem40, ValueListItem41, ValueListItem42, ValueListItem43})
        Me.cmbActiveCIDPort.Location = New System.Drawing.Point(268, 29)
        Me.cmbActiveCIDPort.Name = "cmbActiveCIDPort"
        Me.cmbActiveCIDPort.Size = New System.Drawing.Size(110, 26)
        Me.cmbActiveCIDPort.TabIndex = 21
        '
        'UltraLabel10
        '
        Me.UltraLabel10.AutoSize = True
        Me.UltraLabel10.Location = New System.Drawing.Point(170, 33)
        Me.UltraLabel10.Name = "UltraLabel10"
        Me.UltraLabel10.Size = New System.Drawing.Size(92, 19)
        Me.UltraLabel10.TabIndex = 15
        Me.UltraLabel10.Text = "Use COM port:"
        '
        'chkEnableActiveCID
        '
        Appearance36.FontData.Name = "Segoe UI"
        Appearance36.FontData.SizeInPoints = 10.0!
        Me.chkEnableActiveCID.Appearance = Appearance36
        Me.chkEnableActiveCID.BackColor = System.Drawing.Color.Transparent
        Me.chkEnableActiveCID.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkEnableActiveCID.Location = New System.Drawing.Point(23, 30)
        Me.chkEnableActiveCID.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkEnableActiveCID.Name = "chkEnableActiveCID"
        Me.chkEnableActiveCID.Size = New System.Drawing.Size(132, 26)
        Me.chkEnableActiveCID.TabIndex = 13
        Me.chkEnableActiveCID.Text = "Enable ActiveCID"
        '
        'UltraGroupBox3
        '
        Appearance37.BackColor = System.Drawing.Color.Transparent
        Me.UltraGroupBox3.Appearance = Appearance37
        Me.UltraGroupBox3.Controls.Add(Me.txtPhLen3)
        Me.UltraGroupBox3.Controls.Add(Me.txtPhTrim3)
        Me.UltraGroupBox3.Controls.Add(Me.UltraLabel9)
        Me.UltraGroupBox3.Controls.Add(Me.txtPhLen2)
        Me.UltraGroupBox3.Controls.Add(Me.txtPhTrim2)
        Me.UltraGroupBox3.Controls.Add(Me.UltraLabel8)
        Me.UltraGroupBox3.Controls.Add(Me.txtPhLen1)
        Me.UltraGroupBox3.Controls.Add(Me.txtPhTrim1)
        Me.UltraGroupBox3.Controls.Add(Me.UltraLabel7)
        Me.UltraGroupBox3.Controls.Add(Me.UltraLabel6)
        Me.UltraGroupBox3.Location = New System.Drawing.Point(73, 11)
        Me.UltraGroupBox3.Name = "UltraGroupBox3"
        Me.UltraGroupBox3.Size = New System.Drawing.Size(400, 197)
        Me.UltraGroupBox3.TabIndex = 18
        Me.UltraGroupBox3.Text = "Phone"
        '
        'txtPhLen3
        '
        Me.txtPhLen3.Location = New System.Drawing.Point(268, 149)
        Me.txtPhLen3.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtPhLen3.Name = "txtPhLen3"
        Me.txtPhLen3.Size = New System.Drawing.Size(33, 24)
        Me.txtPhLen3.TabIndex = 32
        Me.txtPhLen3.UseAppStyling = False
        Me.txtPhLen3.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'txtPhTrim3
        '
        Me.txtPhTrim3.Location = New System.Drawing.Point(92, 149)
        Me.txtPhTrim3.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtPhTrim3.Name = "txtPhTrim3"
        Me.txtPhTrim3.Size = New System.Drawing.Size(76, 24)
        Me.txtPhTrim3.TabIndex = 31
        Me.txtPhTrim3.UseAppStyling = False
        Me.txtPhTrim3.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'UltraLabel9
        '
        Me.UltraLabel9.AutoSize = True
        Me.UltraLabel9.Location = New System.Drawing.Point(26, 153)
        Me.UltraLabel9.Name = "UltraLabel9"
        Me.UltraLabel9.Size = New System.Drawing.Size(322, 19)
        Me.UltraLabel9.TabIndex = 30
        Me.UltraLabel9.Text = "Get rid of                        if number is of               digits"
        '
        'txtPhLen2
        '
        Me.txtPhLen2.Location = New System.Drawing.Point(268, 115)
        Me.txtPhLen2.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtPhLen2.Name = "txtPhLen2"
        Me.txtPhLen2.Size = New System.Drawing.Size(33, 24)
        Me.txtPhLen2.TabIndex = 29
        Me.txtPhLen2.UseAppStyling = False
        Me.txtPhLen2.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'txtPhTrim2
        '
        Me.txtPhTrim2.Location = New System.Drawing.Point(92, 115)
        Me.txtPhTrim2.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtPhTrim2.Name = "txtPhTrim2"
        Me.txtPhTrim2.Size = New System.Drawing.Size(76, 24)
        Me.txtPhTrim2.TabIndex = 28
        Me.txtPhTrim2.UseAppStyling = False
        Me.txtPhTrim2.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'UltraLabel8
        '
        Me.UltraLabel8.AutoSize = True
        Me.UltraLabel8.Location = New System.Drawing.Point(26, 119)
        Me.UltraLabel8.Name = "UltraLabel8"
        Me.UltraLabel8.Size = New System.Drawing.Size(322, 19)
        Me.UltraLabel8.TabIndex = 27
        Me.UltraLabel8.Text = "Get rid of                        if number is of               digits"
        '
        'txtPhLen1
        '
        Me.txtPhLen1.Location = New System.Drawing.Point(268, 81)
        Me.txtPhLen1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtPhLen1.Name = "txtPhLen1"
        Me.txtPhLen1.Size = New System.Drawing.Size(33, 24)
        Me.txtPhLen1.TabIndex = 26
        Me.txtPhLen1.UseAppStyling = False
        Me.txtPhLen1.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'txtPhTrim1
        '
        Me.txtPhTrim1.Location = New System.Drawing.Point(92, 81)
        Me.txtPhTrim1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtPhTrim1.Name = "txtPhTrim1"
        Me.txtPhTrim1.Size = New System.Drawing.Size(76, 24)
        Me.txtPhTrim1.TabIndex = 25
        Me.txtPhTrim1.UseAppStyling = False
        Me.txtPhTrim1.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'UltraLabel7
        '
        Me.UltraLabel7.Location = New System.Drawing.Point(26, 24)
        Me.UltraLabel7.Name = "UltraLabel7"
        Me.UltraLabel7.Size = New System.Drawing.Size(337, 37)
        Me.UltraLabel7.TabIndex = 24
        Me.UltraLabel7.Text = "Enter below the first digits to remove and the length of the number to match"
        '
        'UltraLabel6
        '
        Me.UltraLabel6.AutoSize = True
        Me.UltraLabel6.Location = New System.Drawing.Point(26, 85)
        Me.UltraLabel6.Name = "UltraLabel6"
        Me.UltraLabel6.Size = New System.Drawing.Size(322, 19)
        Me.UltraLabel6.TabIndex = 23
        Me.UltraLabel6.Text = "Get rid of                        if number is of               digits"
        '
        'UltraTabPageControl6
        '
        Me.UltraTabPageControl6.Controls.Add(Me.UltraGroupBox9)
        Me.UltraTabPageControl6.Location = New System.Drawing.Point(-10000, -10000)
        Me.UltraTabPageControl6.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.UltraTabPageControl6.Name = "UltraTabPageControl6"
        Me.UltraTabPageControl6.Size = New System.Drawing.Size(546, 602)
        '
        'UltraGroupBox9
        '
        Appearance38.BackColor = System.Drawing.Color.Transparent
        Me.UltraGroupBox9.Appearance = Appearance38
        Me.UltraGroupBox9.Controls.Add(Me.UltraLabel79)
        Me.UltraGroupBox9.Controls.Add(Me.chkLogoItalic)
        Me.UltraGroupBox9.Controls.Add(Me.chkLogoBold)
        Me.UltraGroupBox9.Controls.Add(Me.cmbLogoSize)
        Me.UltraGroupBox9.Controls.Add(Me.cmbLogoFont)
        Me.UltraGroupBox9.Controls.Add(Me.UltraLabel28)
        Me.UltraGroupBox9.Controls.Add(Me.txtFooter)
        Me.UltraGroupBox9.Controls.Add(Me.UltraLabel49)
        Me.UltraGroupBox9.Controls.Add(Me.cmdLogoFontSave)
        Me.UltraGroupBox9.Controls.Add(Me.txtHeader6)
        Me.UltraGroupBox9.Controls.Add(Me.txtHeader5)
        Me.UltraGroupBox9.Controls.Add(Me.txtHeader4)
        Me.UltraGroupBox9.Controls.Add(Me.txtHeader3)
        Me.UltraGroupBox9.Controls.Add(Me.txtHeader2)
        Me.UltraGroupBox9.Controls.Add(Me.txtHeader1)
        Me.UltraGroupBox9.Controls.Add(Me.UltraLabel13)
        Me.UltraGroupBox9.Location = New System.Drawing.Point(38, 11)
        Me.UltraGroupBox9.Name = "UltraGroupBox9"
        Me.UltraGroupBox9.Size = New System.Drawing.Size(470, 574)
        Me.UltraGroupBox9.TabIndex = 20
        Me.UltraGroupBox9.Text = "Header && Footer"
        '
        'UltraLabel79
        '
        Me.UltraLabel79.AutoSize = True
        Me.UltraLabel79.Location = New System.Drawing.Point(51, 328)
        Me.UltraLabel79.Name = "UltraLabel79"
        Me.UltraLabel79.Size = New System.Drawing.Size(34, 19)
        Me.UltraLabel79.TabIndex = 93
        Me.UltraLabel79.Text = "Font:"
        '
        'chkLogoItalic
        '
        Appearance39.FontData.Name = "Segoe UI"
        Appearance39.FontData.SizeInPoints = 10.0!
        Me.chkLogoItalic.Appearance = Appearance39
        Me.chkLogoItalic.AutoSize = True
        Me.chkLogoItalic.BackColor = System.Drawing.Color.Transparent
        Me.chkLogoItalic.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkLogoItalic.Location = New System.Drawing.Point(263, 360)
        Me.chkLogoItalic.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkLogoItalic.Name = "chkLogoItalic"
        Me.chkLogoItalic.Size = New System.Drawing.Size(50, 23)
        Me.chkLogoItalic.TabIndex = 92
        Me.chkLogoItalic.Text = "Italic"
        '
        'chkLogoBold
        '
        Appearance40.FontData.Name = "Segoe UI"
        Appearance40.FontData.SizeInPoints = 10.0!
        Me.chkLogoBold.Appearance = Appearance40
        Me.chkLogoBold.AutoSize = True
        Me.chkLogoBold.BackColor = System.Drawing.Color.Transparent
        Me.chkLogoBold.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkLogoBold.Location = New System.Drawing.Point(195, 360)
        Me.chkLogoBold.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkLogoBold.Name = "chkLogoBold"
        Me.chkLogoBold.Size = New System.Drawing.Size(49, 23)
        Me.chkLogoBold.TabIndex = 91
        Me.chkLogoBold.Text = "Bold"
        '
        'cmbLogoSize
        '
        Me.cmbLogoSize.Location = New System.Drawing.Point(91, 356)
        Me.cmbLogoSize.Name = "cmbLogoSize"
        Me.cmbLogoSize.Size = New System.Drawing.Size(85, 26)
        Me.cmbLogoSize.TabIndex = 90
        '
        'cmbLogoFont
        '
        ValueListItem44.DataValue = "ValueListItem0"
        ValueListItem44.DisplayText = "COM1"
        ValueListItem45.DataValue = "ValueListItem1"
        ValueListItem45.DisplayText = "COM2"
        ValueListItem46.DataValue = "ValueListItem2"
        ValueListItem46.DisplayText = "COM3"
        ValueListItem47.DataValue = "ValueListItem3"
        ValueListItem47.DisplayText = "COM4"
        ValueListItem48.DataValue = "ValueListItem4"
        ValueListItem48.DisplayText = "COM5"
        ValueListItem49.DataValue = "ValueListItem5"
        ValueListItem49.DisplayText = "COM6"
        ValueListItem50.DataValue = "ValueListItem6"
        ValueListItem50.DisplayText = "COM7"
        ValueListItem51.DataValue = "ValueListItem7"
        ValueListItem51.DisplayText = "COM8"
        ValueListItem52.DataValue = "ValueListItem8"
        ValueListItem52.DisplayText = "COM9"
        ValueListItem53.DataValue = "ValueListItem9"
        ValueListItem53.DisplayText = "COM10"
        Me.cmbLogoFont.Items.AddRange(New Infragistics.Win.ValueListItem() {ValueListItem44, ValueListItem45, ValueListItem46, ValueListItem47, ValueListItem48, ValueListItem49, ValueListItem50, ValueListItem51, ValueListItem52, ValueListItem53})
        Me.cmbLogoFont.Location = New System.Drawing.Point(91, 324)
        Me.cmbLogoFont.Name = "cmbLogoFont"
        Me.cmbLogoFont.Size = New System.Drawing.Size(203, 26)
        Me.cmbLogoFont.TabIndex = 88
        '
        'UltraLabel28
        '
        Me.UltraLabel28.AutoSize = True
        Me.UltraLabel28.Location = New System.Drawing.Point(49, 458)
        Me.UltraLabel28.Name = "UltraLabel28"
        Me.UltraLabel28.Size = New System.Drawing.Size(72, 19)
        Me.UltraLabel28.TabIndex = 87
        Me.UltraLabel28.Text = "Footer text:"
        '
        'txtFooter
        '
        Appearance41.TextHAlignAsString = "Center"
        Me.txtFooter.Appearance = Appearance41
        Me.txtFooter.Location = New System.Drawing.Point(49, 484)
        Me.txtFooter.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtFooter.Multiline = True
        Me.txtFooter.Name = "txtFooter"
        Me.txtFooter.Size = New System.Drawing.Size(372, 73)
        Me.txtFooter.TabIndex = 86
        Me.txtFooter.Text = "Thank you for your custom. Please call again."
        Me.txtFooter.UseAppStyling = False
        Me.txtFooter.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'UltraLabel49
        '
        Me.UltraLabel49.AutoSize = True
        Me.UltraLabel49.Location = New System.Drawing.Point(54, 360)
        Me.UltraLabel49.Name = "UltraLabel49"
        Me.UltraLabel49.Size = New System.Drawing.Size(31, 19)
        Me.UltraLabel49.TabIndex = 39
        Me.UltraLabel49.Text = "Size:"
        '
        'cmdLogoFontSave
        '
        Me.cmdLogoFontSave.Location = New System.Drawing.Point(315, 324)
        Me.cmdLogoFontSave.Name = "cmdLogoFontSave"
        Me.cmdLogoFontSave.Size = New System.Drawing.Size(98, 23)
        Me.cmdLogoFontSave.TabIndex = 38
        Me.cmdLogoFontSave.Text = "Save Font"
        '
        'txtHeader6
        '
        Appearance42.TextHAlignAsString = "Center"
        Me.txtHeader6.Appearance = Appearance42
        Me.txtHeader6.Location = New System.Drawing.Point(91, 240)
        Me.txtHeader6.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtHeader6.Name = "txtHeader6"
        Me.txtHeader6.Size = New System.Drawing.Size(288, 24)
        Me.txtHeader6.TabIndex = 32
        Me.txtHeader6.UseAppStyling = False
        Me.txtHeader6.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'txtHeader5
        '
        Appearance43.TextHAlignAsString = "Center"
        Me.txtHeader5.Appearance = Appearance43
        Me.txtHeader5.Location = New System.Drawing.Point(91, 206)
        Me.txtHeader5.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtHeader5.Name = "txtHeader5"
        Me.txtHeader5.Size = New System.Drawing.Size(288, 24)
        Me.txtHeader5.TabIndex = 31
        Me.txtHeader5.UseAppStyling = False
        Me.txtHeader5.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'txtHeader4
        '
        Appearance44.TextHAlignAsString = "Center"
        Me.txtHeader4.Appearance = Appearance44
        Me.txtHeader4.Location = New System.Drawing.Point(91, 172)
        Me.txtHeader4.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtHeader4.Name = "txtHeader4"
        Me.txtHeader4.Size = New System.Drawing.Size(288, 24)
        Me.txtHeader4.TabIndex = 30
        Me.txtHeader4.UseAppStyling = False
        Me.txtHeader4.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'txtHeader3
        '
        Appearance45.TextHAlignAsString = "Center"
        Me.txtHeader3.Appearance = Appearance45
        Me.txtHeader3.Location = New System.Drawing.Point(91, 138)
        Me.txtHeader3.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtHeader3.Name = "txtHeader3"
        Me.txtHeader3.Size = New System.Drawing.Size(288, 24)
        Me.txtHeader3.TabIndex = 29
        Me.txtHeader3.UseAppStyling = False
        Me.txtHeader3.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'txtHeader2
        '
        Appearance46.TextHAlignAsString = "Center"
        Me.txtHeader2.Appearance = Appearance46
        Me.txtHeader2.Location = New System.Drawing.Point(91, 94)
        Me.txtHeader2.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtHeader2.Name = "txtHeader2"
        Me.txtHeader2.Size = New System.Drawing.Size(288, 24)
        Me.txtHeader2.TabIndex = 28
        Me.txtHeader2.UseAppStyling = False
        Me.txtHeader2.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'txtHeader1
        '
        Appearance47.TextHAlignAsString = "Center"
        Me.txtHeader1.Appearance = Appearance47
        Me.txtHeader1.Location = New System.Drawing.Point(91, 60)
        Me.txtHeader1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtHeader1.Name = "txtHeader1"
        Me.txtHeader1.Size = New System.Drawing.Size(288, 24)
        Me.txtHeader1.TabIndex = 27
        Me.txtHeader1.UseAppStyling = False
        Me.txtHeader1.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'UltraLabel13
        '
        Me.UltraLabel13.AutoSize = True
        Me.UltraLabel13.Location = New System.Drawing.Point(69, 24)
        Me.UltraLabel13.Name = "UltraLabel13"
        Me.UltraLabel13.Size = New System.Drawing.Size(333, 19)
        Me.UltraLabel13.TabIndex = 26
        Me.UltraLabel13.Text = "Enter below the header for the printed copies of the bill"
        '
        'UltraTabPageControl16
        '
        Me.UltraTabPageControl16.Controls.Add(Me.ugbCuisines)
        Me.UltraTabPageControl16.Location = New System.Drawing.Point(-10000, -10000)
        Me.UltraTabPageControl16.Name = "UltraTabPageControl16"
        Me.UltraTabPageControl16.Size = New System.Drawing.Size(546, 602)
        '
        'ugbCuisines
        '
        Appearance48.BackColor = System.Drawing.Color.Transparent
        Me.ugbCuisines.Appearance = Appearance48
        Me.ugbCuisines.Controls.Add(Me.cmdRenameCuisine5)
        Me.ugbCuisines.Controls.Add(Me.cmdRenameCuisine4)
        Me.ugbCuisines.Controls.Add(Me.cmdRenameCuisine3)
        Me.ugbCuisines.Controls.Add(Me.cmdRenameCuisine2)
        Me.ugbCuisines.Controls.Add(Me.cmdRenameCuisine1)
        Me.ugbCuisines.Controls.Add(Me.cmdDeleteCuisine5)
        Me.ugbCuisines.Controls.Add(Me.cmdDeleteCuisine4)
        Me.ugbCuisines.Controls.Add(Me.cmdDeleteCuisine3)
        Me.ugbCuisines.Controls.Add(Me.cmdDeleteCuisine2)
        Me.ugbCuisines.Controls.Add(Me.cmdDeleteCuisine1)
        Me.ugbCuisines.Controls.Add(Me.txtCuisine5)
        Me.ugbCuisines.Controls.Add(Me.txtCuisine4)
        Me.ugbCuisines.Controls.Add(Me.txtCuisine3)
        Me.ugbCuisines.Controls.Add(Me.txtCuisine2)
        Me.ugbCuisines.Controls.Add(Me.txtCuisine1)
        Me.ugbCuisines.Controls.Add(Me.UltraLabel91)
        Me.ugbCuisines.Controls.Add(Me.UltraLabel90)
        Me.ugbCuisines.Controls.Add(Me.UltraLabel89)
        Me.ugbCuisines.Controls.Add(Me.UltraLabel88)
        Me.ugbCuisines.Controls.Add(Me.UltraLabel87)
        Me.ugbCuisines.Controls.Add(Me.cmdCuisineSave)
        Me.ugbCuisines.Location = New System.Drawing.Point(38, 16)
        Me.ugbCuisines.Name = "ugbCuisines"
        Me.ugbCuisines.Size = New System.Drawing.Size(470, 571)
        Me.ugbCuisines.TabIndex = 18
        Me.ugbCuisines.Text = "Cuisines"
        '
        'cmdRenameCuisine5
        '
        Me.cmdRenameCuisine5.Location = New System.Drawing.Point(266, 173)
        Me.cmdRenameCuisine5.Name = "cmdRenameCuisine5"
        Me.cmdRenameCuisine5.ShowFocusRect = False
        Me.cmdRenameCuisine5.ShowOutline = False
        Me.cmdRenameCuisine5.Size = New System.Drawing.Size(75, 26)
        Me.cmdRenameCuisine5.TabIndex = 98
        Me.cmdRenameCuisine5.Text = "Rename"
        '
        'cmdRenameCuisine4
        '
        Me.cmdRenameCuisine4.Location = New System.Drawing.Point(266, 141)
        Me.cmdRenameCuisine4.Name = "cmdRenameCuisine4"
        Me.cmdRenameCuisine4.ShowFocusRect = False
        Me.cmdRenameCuisine4.ShowOutline = False
        Me.cmdRenameCuisine4.Size = New System.Drawing.Size(75, 26)
        Me.cmdRenameCuisine4.TabIndex = 97
        Me.cmdRenameCuisine4.Text = "Rename"
        '
        'cmdRenameCuisine3
        '
        Me.cmdRenameCuisine3.Location = New System.Drawing.Point(266, 109)
        Me.cmdRenameCuisine3.Name = "cmdRenameCuisine3"
        Me.cmdRenameCuisine3.ShowFocusRect = False
        Me.cmdRenameCuisine3.ShowOutline = False
        Me.cmdRenameCuisine3.Size = New System.Drawing.Size(75, 26)
        Me.cmdRenameCuisine3.TabIndex = 96
        Me.cmdRenameCuisine3.Text = "Rename"
        '
        'cmdRenameCuisine2
        '
        Me.cmdRenameCuisine2.Location = New System.Drawing.Point(266, 77)
        Me.cmdRenameCuisine2.Name = "cmdRenameCuisine2"
        Me.cmdRenameCuisine2.ShowFocusRect = False
        Me.cmdRenameCuisine2.ShowOutline = False
        Me.cmdRenameCuisine2.Size = New System.Drawing.Size(75, 26)
        Me.cmdRenameCuisine2.TabIndex = 95
        Me.cmdRenameCuisine2.Text = "Rename"
        '
        'cmdRenameCuisine1
        '
        Me.cmdRenameCuisine1.Location = New System.Drawing.Point(266, 45)
        Me.cmdRenameCuisine1.Name = "cmdRenameCuisine1"
        Me.cmdRenameCuisine1.ShowFocusRect = False
        Me.cmdRenameCuisine1.ShowOutline = False
        Me.cmdRenameCuisine1.Size = New System.Drawing.Size(75, 26)
        Me.cmdRenameCuisine1.TabIndex = 94
        Me.cmdRenameCuisine1.Text = "Rename"
        '
        'cmdDeleteCuisine5
        '
        Me.cmdDeleteCuisine5.Location = New System.Drawing.Point(347, 173)
        Me.cmdDeleteCuisine5.Name = "cmdDeleteCuisine5"
        Me.cmdDeleteCuisine5.ShowFocusRect = False
        Me.cmdDeleteCuisine5.ShowOutline = False
        Me.cmdDeleteCuisine5.Size = New System.Drawing.Size(75, 26)
        Me.cmdDeleteCuisine5.TabIndex = 93
        Me.cmdDeleteCuisine5.Text = "Delete"
        '
        'cmdDeleteCuisine4
        '
        Me.cmdDeleteCuisine4.Location = New System.Drawing.Point(347, 141)
        Me.cmdDeleteCuisine4.Name = "cmdDeleteCuisine4"
        Me.cmdDeleteCuisine4.ShowFocusRect = False
        Me.cmdDeleteCuisine4.ShowOutline = False
        Me.cmdDeleteCuisine4.Size = New System.Drawing.Size(75, 26)
        Me.cmdDeleteCuisine4.TabIndex = 92
        Me.cmdDeleteCuisine4.Text = "Delete"
        '
        'cmdDeleteCuisine3
        '
        Me.cmdDeleteCuisine3.Location = New System.Drawing.Point(347, 109)
        Me.cmdDeleteCuisine3.Name = "cmdDeleteCuisine3"
        Me.cmdDeleteCuisine3.ShowFocusRect = False
        Me.cmdDeleteCuisine3.ShowOutline = False
        Me.cmdDeleteCuisine3.Size = New System.Drawing.Size(75, 26)
        Me.cmdDeleteCuisine3.TabIndex = 91
        Me.cmdDeleteCuisine3.Text = "Delete"
        '
        'cmdDeleteCuisine2
        '
        Me.cmdDeleteCuisine2.Location = New System.Drawing.Point(347, 77)
        Me.cmdDeleteCuisine2.Name = "cmdDeleteCuisine2"
        Me.cmdDeleteCuisine2.ShowFocusRect = False
        Me.cmdDeleteCuisine2.ShowOutline = False
        Me.cmdDeleteCuisine2.Size = New System.Drawing.Size(75, 26)
        Me.cmdDeleteCuisine2.TabIndex = 90
        Me.cmdDeleteCuisine2.Text = "Delete"
        '
        'cmdDeleteCuisine1
        '
        Me.cmdDeleteCuisine1.Enabled = False
        Me.cmdDeleteCuisine1.Location = New System.Drawing.Point(347, 45)
        Me.cmdDeleteCuisine1.Name = "cmdDeleteCuisine1"
        Me.cmdDeleteCuisine1.ShowFocusRect = False
        Me.cmdDeleteCuisine1.ShowOutline = False
        Me.cmdDeleteCuisine1.Size = New System.Drawing.Size(75, 26)
        Me.cmdDeleteCuisine1.TabIndex = 89
        Me.cmdDeleteCuisine1.Text = "Delete"
        '
        'txtCuisine5
        '
        Me.txtCuisine5.Location = New System.Drawing.Point(49, 173)
        Me.txtCuisine5.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtCuisine5.Name = "txtCuisine5"
        Me.txtCuisine5.Size = New System.Drawing.Size(211, 24)
        Me.txtCuisine5.TabIndex = 88
        Me.txtCuisine5.UseAppStyling = False
        Me.txtCuisine5.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'txtCuisine4
        '
        Me.txtCuisine4.Location = New System.Drawing.Point(49, 141)
        Me.txtCuisine4.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtCuisine4.Name = "txtCuisine4"
        Me.txtCuisine4.Size = New System.Drawing.Size(211, 24)
        Me.txtCuisine4.TabIndex = 87
        Me.txtCuisine4.UseAppStyling = False
        Me.txtCuisine4.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'txtCuisine3
        '
        Me.txtCuisine3.Location = New System.Drawing.Point(49, 109)
        Me.txtCuisine3.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtCuisine3.Name = "txtCuisine3"
        Me.txtCuisine3.Size = New System.Drawing.Size(211, 24)
        Me.txtCuisine3.TabIndex = 86
        Me.txtCuisine3.UseAppStyling = False
        Me.txtCuisine3.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'txtCuisine2
        '
        Me.txtCuisine2.Location = New System.Drawing.Point(49, 77)
        Me.txtCuisine2.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtCuisine2.Name = "txtCuisine2"
        Me.txtCuisine2.Size = New System.Drawing.Size(211, 24)
        Me.txtCuisine2.TabIndex = 85
        Me.txtCuisine2.UseAppStyling = False
        Me.txtCuisine2.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'txtCuisine1
        '
        Me.txtCuisine1.Location = New System.Drawing.Point(49, 45)
        Me.txtCuisine1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtCuisine1.Name = "txtCuisine1"
        Me.txtCuisine1.Size = New System.Drawing.Size(211, 24)
        Me.txtCuisine1.TabIndex = 84
        Me.txtCuisine1.UseAppStyling = False
        Me.txtCuisine1.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'UltraLabel91
        '
        Me.UltraLabel91.AutoSize = True
        Me.UltraLabel91.Location = New System.Drawing.Point(28, 176)
        Me.UltraLabel91.Name = "UltraLabel91"
        Me.UltraLabel91.Size = New System.Drawing.Size(15, 19)
        Me.UltraLabel91.TabIndex = 83
        Me.UltraLabel91.Text = "5."
        '
        'UltraLabel90
        '
        Me.UltraLabel90.AutoSize = True
        Me.UltraLabel90.Location = New System.Drawing.Point(28, 144)
        Me.UltraLabel90.Name = "UltraLabel90"
        Me.UltraLabel90.Size = New System.Drawing.Size(15, 19)
        Me.UltraLabel90.TabIndex = 82
        Me.UltraLabel90.Text = "4."
        '
        'UltraLabel89
        '
        Me.UltraLabel89.AutoSize = True
        Me.UltraLabel89.Location = New System.Drawing.Point(28, 112)
        Me.UltraLabel89.Name = "UltraLabel89"
        Me.UltraLabel89.Size = New System.Drawing.Size(15, 19)
        Me.UltraLabel89.TabIndex = 81
        Me.UltraLabel89.Text = "3."
        '
        'UltraLabel88
        '
        Me.UltraLabel88.AutoSize = True
        Me.UltraLabel88.Location = New System.Drawing.Point(28, 80)
        Me.UltraLabel88.Name = "UltraLabel88"
        Me.UltraLabel88.Size = New System.Drawing.Size(15, 19)
        Me.UltraLabel88.TabIndex = 80
        Me.UltraLabel88.Text = "2."
        '
        'UltraLabel87
        '
        Me.UltraLabel87.AutoSize = True
        Me.UltraLabel87.Location = New System.Drawing.Point(28, 48)
        Me.UltraLabel87.Name = "UltraLabel87"
        Me.UltraLabel87.Size = New System.Drawing.Size(15, 19)
        Me.UltraLabel87.TabIndex = 79
        Me.UltraLabel87.Text = "1."
        '
        'cmdCuisineSave
        '
        Me.cmdCuisineSave.Location = New System.Drawing.Point(185, 204)
        Me.cmdCuisineSave.Name = "cmdCuisineSave"
        Me.cmdCuisineSave.ShowFocusRect = False
        Me.cmdCuisineSave.ShowOutline = False
        Me.cmdCuisineSave.Size = New System.Drawing.Size(75, 26)
        Me.cmdCuisineSave.TabIndex = 16
        Me.cmdCuisineSave.Text = "Save"
        '
        'UltraTabPageControl11
        '
        Me.UltraTabPageControl11.Controls.Add(Me.UltraGroupBox11)
        Me.UltraTabPageControl11.Location = New System.Drawing.Point(-10000, -10000)
        Me.UltraTabPageControl11.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.UltraTabPageControl11.Name = "UltraTabPageControl11"
        Me.UltraTabPageControl11.Size = New System.Drawing.Size(546, 602)
        '
        'UltraGroupBox11
        '
        Appearance49.BackColor = System.Drawing.Color.Transparent
        Me.UltraGroupBox11.Appearance = Appearance49
        Me.UltraGroupBox11.Controls.Add(Me.cmdMergeGroup)
        Me.UltraGroupBox11.Controls.Add(Me.cmdRenameGroup)
        Me.UltraGroupBox11.Controls.Add(Me.UltraLabel86)
        Me.UltraGroupBox11.Controls.Add(Me.cmdRefreshCuisinesGroups)
        Me.UltraGroupBox11.Controls.Add(Me.cmbCuisineGroups)
        Me.UltraGroupBox11.Controls.Add(Me.cmdGroupingMode)
        Me.UltraGroupBox11.Controls.Add(Me.cmdInsertLine)
        Me.UltraGroupBox11.Controls.Add(Me.UltraLabel78)
        Me.UltraGroupBox11.Controls.Add(Me.cmdSaveGroups)
        Me.UltraGroupBox11.Controls.Add(Me.cmdMoveUp)
        Me.UltraGroupBox11.Controls.Add(Me.cmdMoveDown)
        Me.UltraGroupBox11.Controls.Add(Me.cmdMainGroup)
        Me.UltraGroupBox11.Controls.Add(Me.cmdSubGroup)
        Me.UltraGroupBox11.Controls.Add(Me.lstGroups)
        Me.UltraGroupBox11.Controls.Add(Me.cmdAddGroup)
        Me.UltraGroupBox11.Controls.Add(Me.txtGroups)
        Me.UltraGroupBox11.Controls.Add(Me.cmdDeleteGroup)
        Me.UltraGroupBox11.Location = New System.Drawing.Point(38, 16)
        Me.UltraGroupBox11.Name = "UltraGroupBox11"
        Me.UltraGroupBox11.Size = New System.Drawing.Size(470, 571)
        Me.UltraGroupBox11.TabIndex = 17
        Me.UltraGroupBox11.Text = "Groups"
        '
        'cmdMergeGroup
        '
        Me.cmdMergeGroup.Location = New System.Drawing.Point(332, 215)
        Me.cmdMergeGroup.Name = "cmdMergeGroup"
        Me.cmdMergeGroup.ShowFocusRect = False
        Me.cmdMergeGroup.ShowOutline = False
        Me.cmdMergeGroup.Size = New System.Drawing.Size(75, 26)
        Me.cmdMergeGroup.TabIndex = 87
        Me.cmdMergeGroup.Text = "Merge"
        '
        'cmdRenameGroup
        '
        Me.cmdRenameGroup.Location = New System.Drawing.Point(332, 183)
        Me.cmdRenameGroup.Name = "cmdRenameGroup"
        Me.cmdRenameGroup.ShowFocusRect = False
        Me.cmdRenameGroup.ShowOutline = False
        Me.cmdRenameGroup.Size = New System.Drawing.Size(75, 26)
        Me.cmdRenameGroup.TabIndex = 86
        Me.cmdRenameGroup.Text = "Rename"
        '
        'UltraLabel86
        '
        Me.UltraLabel86.AutoSize = True
        Me.UltraLabel86.Location = New System.Drawing.Point(59, 39)
        Me.UltraLabel86.Name = "UltraLabel86"
        Me.UltraLabel86.Size = New System.Drawing.Size(87, 19)
        Me.UltraLabel86.TabIndex = 85
        Me.UltraLabel86.Text = "Select cuisine:"
        '
        'cmdRefreshCuisinesGroups
        '
        Me.cmdRefreshCuisinesGroups.Location = New System.Drawing.Point(332, 35)
        Me.cmdRefreshCuisinesGroups.Name = "cmdRefreshCuisinesGroups"
        Me.cmdRefreshCuisinesGroups.ShowFocusRect = False
        Me.cmdRefreshCuisinesGroups.ShowOutline = False
        Me.cmdRefreshCuisinesGroups.Size = New System.Drawing.Size(75, 26)
        Me.cmdRefreshCuisinesGroups.TabIndex = 84
        Me.cmdRefreshCuisinesGroups.Text = "Refresh"
        '
        'cmbCuisineGroups
        '
        Me.cmbCuisineGroups.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList
        Me.cmbCuisineGroups.Location = New System.Drawing.Point(152, 35)
        Me.cmbCuisineGroups.Name = "cmbCuisineGroups"
        Me.cmbCuisineGroups.Size = New System.Drawing.Size(157, 26)
        Me.cmbCuisineGroups.TabIndex = 83
        '
        'cmdGroupingMode
        '
        Me.cmdGroupingMode.Location = New System.Drawing.Point(332, 451)
        Me.cmdGroupingMode.Name = "cmdGroupingMode"
        Me.cmdGroupingMode.ShowFocusRect = False
        Me.cmdGroupingMode.ShowOutline = False
        Me.cmdGroupingMode.Size = New System.Drawing.Size(94, 40)
        Me.cmdGroupingMode.TabIndex = 82
        Me.cmdGroupingMode.Tag = "0"
        Me.cmdGroupingMode.Text = "Grouping mode"
        '
        'cmdInsertLine
        '
        Me.cmdInsertLine.Enabled = False
        Me.cmdInsertLine.Location = New System.Drawing.Point(332, 497)
        Me.cmdInsertLine.Name = "cmdInsertLine"
        Me.cmdInsertLine.ShowFocusRect = False
        Me.cmdInsertLine.ShowOutline = False
        Me.cmdInsertLine.Size = New System.Drawing.Size(94, 26)
        Me.cmdInsertLine.TabIndex = 81
        Me.cmdInsertLine.Text = "Insert line"
        '
        'UltraLabel78
        '
        Me.UltraLabel78.AutoSize = True
        Me.UltraLabel78.Location = New System.Drawing.Point(59, 541)
        Me.UltraLabel78.Name = "UltraLabel78"
        Me.UltraLabel78.Size = New System.Drawing.Size(353, 19)
        Me.UltraLabel78.TabIndex = 80
        Me.UltraLabel78.Text = "The first group in the list will be taken as the starters group"
        '
        'cmdSaveGroups
        '
        Me.cmdSaveGroups.Location = New System.Drawing.Point(332, 374)
        Me.cmdSaveGroups.Name = "cmdSaveGroups"
        Me.cmdSaveGroups.ShowFocusRect = False
        Me.cmdSaveGroups.ShowOutline = False
        Me.cmdSaveGroups.Size = New System.Drawing.Size(75, 26)
        Me.cmdSaveGroups.TabIndex = 79
        Me.cmdSaveGroups.Text = "Save"
        '
        'cmdMoveUp
        '
        Me.cmdMoveUp.Location = New System.Drawing.Point(332, 293)
        Me.cmdMoveUp.Name = "cmdMoveUp"
        Me.cmdMoveUp.ShowFocusRect = False
        Me.cmdMoveUp.ShowOutline = False
        Me.cmdMoveUp.Size = New System.Drawing.Size(75, 26)
        Me.cmdMoveUp.TabIndex = 78
        Me.cmdMoveUp.Text = "Up"
        '
        'cmdMoveDown
        '
        Me.cmdMoveDown.Location = New System.Drawing.Point(332, 325)
        Me.cmdMoveDown.Name = "cmdMoveDown"
        Me.cmdMoveDown.ShowFocusRect = False
        Me.cmdMoveDown.ShowOutline = False
        Me.cmdMoveDown.Size = New System.Drawing.Size(75, 26)
        Me.cmdMoveDown.TabIndex = 77
        Me.cmdMoveDown.Text = "Down"
        '
        'cmdMainGroup
        '
        Me.cmdMainGroup.Location = New System.Drawing.Point(59, 74)
        Me.cmdMainGroup.Name = "cmdMainGroup"
        Me.cmdMainGroup.ShowFocusRect = False
        Me.cmdMainGroup.ShowOutline = False
        Me.cmdMainGroup.Size = New System.Drawing.Size(118, 29)
        Me.cmdMainGroup.TabIndex = 76
        Me.cmdMainGroup.Text = "Groups"
        '
        'cmdSubGroup
        '
        Me.cmdSubGroup.Location = New System.Drawing.Point(183, 74)
        Me.cmdSubGroup.Name = "cmdSubGroup"
        Me.cmdSubGroup.ShowFocusRect = False
        Me.cmdSubGroup.ShowOutline = False
        Me.cmdSubGroup.Size = New System.Drawing.Size(118, 29)
        Me.cmdSubGroup.TabIndex = 75
        Me.cmdSubGroup.Text = "Subgroups"
        '
        'lstGroups
        '
        Me.lstGroups.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Me.lstGroups.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstGroups.ItemSettings.AllowEdit = Infragistics.Win.DefaultableBoolean.[False]
        Me.lstGroups.ItemSettings.HideSelection = False
        Me.lstGroups.ItemSettings.HotTracking = True
        Me.lstGroups.Location = New System.Drawing.Point(59, 151)
        Me.lstGroups.Name = "lstGroups"
        Me.lstGroups.ShowGroups = False
        Me.lstGroups.Size = New System.Drawing.Size(263, 384)
        Me.lstGroups.TabIndex = 74
        Me.lstGroups.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        Me.lstGroups.View = Infragistics.Win.UltraWinListView.UltraListViewStyle.List
        Me.lstGroups.ViewSettingsList.ImageSize = New System.Drawing.Size(0, 0)
        Me.lstGroups.ViewSettingsList.MultiColumn = False
        '
        'cmdAddGroup
        '
        Me.cmdAddGroup.Location = New System.Drawing.Point(332, 118)
        Me.cmdAddGroup.Name = "cmdAddGroup"
        Me.cmdAddGroup.ShowFocusRect = False
        Me.cmdAddGroup.ShowOutline = False
        Me.cmdAddGroup.Size = New System.Drawing.Size(75, 26)
        Me.cmdAddGroup.TabIndex = 16
        Me.cmdAddGroup.Text = "Add"
        '
        'txtGroups
        '
        Me.txtGroups.Location = New System.Drawing.Point(59, 118)
        Me.txtGroups.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtGroups.Name = "txtGroups"
        Me.txtGroups.Size = New System.Drawing.Size(263, 24)
        Me.txtGroups.TabIndex = 17
        Me.txtGroups.UseAppStyling = False
        Me.txtGroups.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'cmdDeleteGroup
        '
        Me.cmdDeleteGroup.Location = New System.Drawing.Point(332, 151)
        Me.cmdDeleteGroup.Name = "cmdDeleteGroup"
        Me.cmdDeleteGroup.ShowFocusRect = False
        Me.cmdDeleteGroup.ShowOutline = False
        Me.cmdDeleteGroup.Size = New System.Drawing.Size(75, 26)
        Me.cmdDeleteGroup.TabIndex = 15
        Me.cmdDeleteGroup.Text = "Delete"
        '
        'UltraTabPageControl18
        '
        Me.UltraTabPageControl18.Controls.Add(Me.UltraGroupBox19)
        Me.UltraTabPageControl18.Location = New System.Drawing.Point(-10000, -10000)
        Me.UltraTabPageControl18.Name = "UltraTabPageControl18"
        Me.UltraTabPageControl18.Size = New System.Drawing.Size(546, 602)
        '
        'UltraGroupBox19
        '
        Appearance50.BackColor = System.Drawing.Color.Transparent
        Me.UltraGroupBox19.Appearance = Appearance50
        Me.UltraGroupBox19.Controls.Add(Me.chkDishesUppercase)
        Me.UltraGroupBox19.Controls.Add(Me.chkDishesSimpleName)
        Me.UltraGroupBox19.Controls.Add(Me.UltraLabel104)
        Me.UltraGroupBox19.Controls.Add(Me.txtPortionSmall)
        Me.UltraGroupBox19.Controls.Add(Me.UltraLabel106)
        Me.UltraGroupBox19.Controls.Add(Me.txtPortionLarge)
        Me.UltraGroupBox19.Controls.Add(Me.chkDishesUseConcise)
        Me.UltraGroupBox19.Location = New System.Drawing.Point(38, 16)
        Me.UltraGroupBox19.Name = "UltraGroupBox19"
        Me.UltraGroupBox19.Size = New System.Drawing.Size(470, 571)
        Me.UltraGroupBox19.TabIndex = 19
        Me.UltraGroupBox19.Text = "Dishes"
        '
        'chkDishesUppercase
        '
        Appearance51.FontData.Name = "Segoe UI"
        Appearance51.FontData.SizeInPoints = 10.0!
        Me.chkDishesUppercase.Appearance = Appearance51
        Me.chkDishesUppercase.AutoSize = True
        Me.chkDishesUppercase.BackColor = System.Drawing.Color.Transparent
        Me.chkDishesUppercase.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkDishesUppercase.Location = New System.Drawing.Point(37, 80)
        Me.chkDishesUppercase.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkDishesUppercase.Name = "chkDishesUppercase"
        Me.chkDishesUppercase.Size = New System.Drawing.Size(175, 23)
        Me.chkDishesUppercase.TabIndex = 100
        Me.chkDishesUppercase.Text = "Use uppercase in popups"
        '
        'chkDishesSimpleName
        '
        Appearance52.FontData.Name = "Segoe UI"
        Appearance52.FontData.SizeInPoints = 10.0!
        Me.chkDishesSimpleName.Appearance = Appearance52
        Me.chkDishesSimpleName.AutoSize = True
        Me.chkDishesSimpleName.BackColor = System.Drawing.Color.Transparent
        Me.chkDishesSimpleName.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkDishesSimpleName.Location = New System.Drawing.Point(37, 60)
        Me.chkDishesSimpleName.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkDishesSimpleName.Name = "chkDishesSimpleName"
        Me.chkDishesSimpleName.Size = New System.Drawing.Size(210, 23)
        Me.chkDishesSimpleName.TabIndex = 99
        Me.chkDishesSimpleName.Text = "Use short dish names in popup"
        '
        'UltraLabel104
        '
        Me.UltraLabel104.AutoSize = True
        Me.UltraLabel104.Location = New System.Drawing.Point(28, 177)
        Me.UltraLabel104.Name = "UltraLabel104"
        Me.UltraLabel104.Size = New System.Drawing.Size(119, 19)
        Me.UltraLabel104.TabIndex = 98
        Me.UltraLabel104.Text = "Large portion label:"
        '
        'txtPortionSmall
        '
        Me.txtPortionSmall.Location = New System.Drawing.Point(153, 141)
        Me.txtPortionSmall.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtPortionSmall.Name = "txtPortionSmall"
        Me.txtPortionSmall.Size = New System.Drawing.Size(97, 24)
        Me.txtPortionSmall.TabIndex = 95
        Me.txtPortionSmall.Tag = ""
        Me.txtPortionSmall.Text = "[S]"
        Me.txtPortionSmall.UseAppStyling = False
        Me.txtPortionSmall.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'UltraLabel106
        '
        Me.UltraLabel106.AutoSize = True
        Me.UltraLabel106.Location = New System.Drawing.Point(29, 144)
        Me.UltraLabel106.Name = "UltraLabel106"
        Me.UltraLabel106.Size = New System.Drawing.Size(119, 19)
        Me.UltraLabel106.TabIndex = 96
        Me.UltraLabel106.Text = "Small portion label:"
        '
        'txtPortionLarge
        '
        Me.txtPortionLarge.Location = New System.Drawing.Point(153, 174)
        Me.txtPortionLarge.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtPortionLarge.Name = "txtPortionLarge"
        Me.txtPortionLarge.Size = New System.Drawing.Size(97, 24)
        Me.txtPortionLarge.TabIndex = 94
        Me.txtPortionLarge.Tag = "0"
        Me.txtPortionLarge.Text = "[L]"
        Me.txtPortionLarge.UseAppStyling = False
        Me.txtPortionLarge.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'chkDishesUseConcise
        '
        Appearance53.FontData.Name = "Segoe UI"
        Appearance53.FontData.SizeInPoints = 10.0!
        Me.chkDishesUseConcise.Appearance = Appearance53
        Me.chkDishesUseConcise.AutoSize = True
        Me.chkDishesUseConcise.BackColor = System.Drawing.Color.Transparent
        Me.chkDishesUseConcise.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkDishesUseConcise.Location = New System.Drawing.Point(37, 40)
        Me.chkDishesUseConcise.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkDishesUseConcise.Name = "chkDishesUseConcise"
        Me.chkDishesUseConcise.Size = New System.Drawing.Size(160, 23)
        Me.chkDishesUseConcise.TabIndex = 92
        Me.chkDishesUseConcise.Text = "Use concise dish menu"
        '
        'UltraTabPageControl7
        '
        Me.UltraTabPageControl7.Controls.Add(Me.UltraGroupBox1)
        Me.UltraTabPageControl7.Location = New System.Drawing.Point(-10000, -10000)
        Me.UltraTabPageControl7.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.UltraTabPageControl7.Name = "UltraTabPageControl7"
        Me.UltraTabPageControl7.Size = New System.Drawing.Size(546, 602)
        '
        'UltraGroupBox1
        '
        Appearance54.BackColor = System.Drawing.Color.Transparent
        Me.UltraGroupBox1.Appearance = Appearance54
        Me.UltraGroupBox1.Controls.Add(Me.chkShowModLabelPrinter)
        Me.UltraGroupBox1.Controls.Add(Me.chkZeroCost)
        Me.UltraGroupBox1.Controls.Add(Me.chkDisableCostChange)
        Me.UltraGroupBox1.Controls.Add(Me.lstMods)
        Me.UltraGroupBox1.Controls.Add(Me.UltraLabel31)
        Me.UltraGroupBox1.Controls.Add(Me.txtCost)
        Me.UltraGroupBox1.Controls.Add(Me.UltraLabel30)
        Me.UltraGroupBox1.Controls.Add(Me.UltraLabel29)
        Me.UltraGroupBox1.Controls.Add(Me.cmdAddMod)
        Me.UltraGroupBox1.Controls.Add(Me.txtMod)
        Me.UltraGroupBox1.Controls.Add(Me.cmdDeleteMod)
        Me.UltraGroupBox1.Location = New System.Drawing.Point(38, 11)
        Me.UltraGroupBox1.Name = "UltraGroupBox1"
        Me.UltraGroupBox1.Size = New System.Drawing.Size(470, 576)
        Me.UltraGroupBox1.TabIndex = 16
        Me.UltraGroupBox1.Text = "Modifiers"
        '
        'chkShowModLabelPrinter
        '
        Appearance55.FontData.Name = "Segoe UI"
        Appearance55.FontData.SizeInPoints = 10.0!
        Me.chkShowModLabelPrinter.Appearance = Appearance55
        Me.chkShowModLabelPrinter.BackColor = System.Drawing.Color.Transparent
        Me.chkShowModLabelPrinter.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkShowModLabelPrinter.Location = New System.Drawing.Point(72, 540)
        Me.chkShowModLabelPrinter.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkShowModLabelPrinter.Name = "chkShowModLabelPrinter"
        Me.chkShowModLabelPrinter.Size = New System.Drawing.Size(145, 26)
        Me.chkShowModLabelPrinter.TabIndex = 54
        Me.chkShowModLabelPrinter.Text = "Show label printer"
        '
        'chkZeroCost
        '
        Appearance56.FontData.Name = "Segoe UI"
        Appearance56.FontData.SizeInPoints = 10.0!
        Me.chkZeroCost.Appearance = Appearance56
        Me.chkZeroCost.BackColor = System.Drawing.Color.Transparent
        Me.chkZeroCost.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkZeroCost.Location = New System.Drawing.Point(72, 520)
        Me.chkZeroCost.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkZeroCost.Name = "chkZeroCost"
        Me.chkZeroCost.Size = New System.Drawing.Size(245, 26)
        Me.chkZeroCost.TabIndex = 53
        Me.chkZeroCost.Text = "Do not print modifier price if 0.00"
        '
        'chkDisableCostChange
        '
        Appearance57.FontData.Name = "Segoe UI"
        Appearance57.FontData.SizeInPoints = 10.0!
        Me.chkDisableCostChange.Appearance = Appearance57
        Me.chkDisableCostChange.BackColor = System.Drawing.Color.Transparent
        Me.chkDisableCostChange.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkDisableCostChange.Location = New System.Drawing.Point(72, 500)
        Me.chkDisableCostChange.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkDisableCostChange.Name = "chkDisableCostChange"
        Me.chkDisableCostChange.Size = New System.Drawing.Size(245, 26)
        Me.chkDisableCostChange.TabIndex = 52
        Me.chkDisableCostChange.Text = "Disable price change in modifiers"
        '
        'lstMods
        '
        Me.lstMods.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Me.lstMods.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstMods.ItemSettings.AllowEdit = Infragistics.Win.DefaultableBoolean.[False]
        Me.lstMods.ItemSettings.HotTracking = True
        Me.lstMods.Location = New System.Drawing.Point(74, 143)
        Me.lstMods.Name = "lstMods"
        Me.lstMods.ShowGroups = False
        Me.lstMods.Size = New System.Drawing.Size(243, 347)
        Me.lstMods.TabIndex = 51
        Me.lstMods.Text = "UltraListView1"
        Me.lstMods.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        Me.lstMods.View = Infragistics.Win.UltraWinListView.UltraListViewStyle.List
        Me.lstMods.ViewSettingsList.ImageSize = New System.Drawing.Size(0, 0)
        Me.lstMods.ViewSettingsList.MultiColumn = False
        '
        'UltraLabel31
        '
        Me.UltraLabel31.AutoSize = True
        Me.UltraLabel31.Location = New System.Drawing.Point(81, 98)
        Me.UltraLabel31.Name = "UltraLabel31"
        Me.UltraLabel31.Size = New System.Drawing.Size(45, 19)
        Me.UltraLabel31.TabIndex = 49
        Me.UltraLabel31.Text = "(if any)"
        '
        'txtCost
        '
        Me.txtCost.Location = New System.Drawing.Point(132, 77)
        Me.txtCost.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtCost.Name = "txtCost"
        Me.txtCost.Size = New System.Drawing.Size(74, 24)
        Me.txtCost.TabIndex = 48
        Me.txtCost.UseAppStyling = False
        Me.txtCost.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'UltraLabel30
        '
        Me.UltraLabel30.AutoSize = True
        Me.UltraLabel30.Location = New System.Drawing.Point(76, 81)
        Me.UltraLabel30.Name = "UltraLabel30"
        Me.UltraLabel30.Size = New System.Drawing.Size(50, 19)
        Me.UltraLabel30.TabIndex = 47
        Me.UltraLabel30.Text = "Charge:"
        '
        'UltraLabel29
        '
        Me.UltraLabel29.AutoSize = True
        Me.UltraLabel29.Location = New System.Drawing.Point(83, 47)
        Me.UltraLabel29.Name = "UltraLabel29"
        Me.UltraLabel29.Size = New System.Drawing.Size(43, 19)
        Me.UltraLabel29.TabIndex = 46
        Me.UltraLabel29.Text = "Name:"
        '
        'cmdAddMod
        '
        Me.cmdAddMod.Location = New System.Drawing.Point(327, 143)
        Me.cmdAddMod.Name = "cmdAddMod"
        Me.cmdAddMod.ShowFocusRect = False
        Me.cmdAddMod.ShowOutline = False
        Me.cmdAddMod.Size = New System.Drawing.Size(75, 26)
        Me.cmdAddMod.TabIndex = 16
        Me.cmdAddMod.Text = "Add"
        '
        'txtMod
        '
        Me.txtMod.Location = New System.Drawing.Point(132, 43)
        Me.txtMod.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtMod.Name = "txtMod"
        Me.txtMod.Size = New System.Drawing.Size(209, 24)
        Me.txtMod.TabIndex = 17
        Me.txtMod.UseAppStyling = False
        Me.txtMod.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'cmdDeleteMod
        '
        Me.cmdDeleteMod.Location = New System.Drawing.Point(327, 175)
        Me.cmdDeleteMod.Name = "cmdDeleteMod"
        Me.cmdDeleteMod.ShowFocusRect = False
        Me.cmdDeleteMod.ShowOutline = False
        Me.cmdDeleteMod.Size = New System.Drawing.Size(75, 26)
        Me.cmdDeleteMod.TabIndex = 15
        Me.cmdDeleteMod.Text = "Delete"
        '
        'UltraTabPageControl9
        '
        Me.UltraTabPageControl9.Controls.Add(Me.UltraGroupBox7)
        Me.UltraTabPageControl9.Location = New System.Drawing.Point(-10000, -10000)
        Me.UltraTabPageControl9.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.UltraTabPageControl9.Name = "UltraTabPageControl9"
        Me.UltraTabPageControl9.Size = New System.Drawing.Size(546, 602)
        '
        'UltraGroupBox7
        '
        Appearance58.BackColor = System.Drawing.Color.Transparent
        Me.UltraGroupBox7.Appearance = Appearance58
        Me.UltraGroupBox7.Controls.Add(Me.cmdSavePrinters)
        Me.UltraGroupBox7.Controls.Add(Me.UltraLabel94)
        Me.UltraGroupBox7.Controls.Add(Me.cmdRefreshCuisinesPrinters)
        Me.UltraGroupBox7.Controls.Add(Me.cmbCuisinePrinters)
        Me.UltraGroupBox7.Controls.Add(Me.chkHidePrintDialog)
        Me.UltraGroupBox7.Controls.Add(Me.UltraLabel43)
        Me.UltraGroupBox7.Controls.Add(Me.UltraLabel44)
        Me.UltraGroupBox7.Controls.Add(Me.UltraLabel45)
        Me.UltraGroupBox7.Controls.Add(Me.UltraLabel46)
        Me.UltraGroupBox7.Controls.Add(Me.UltraLabel47)
        Me.UltraGroupBox7.Controls.Add(Me.UltraLabel48)
        Me.UltraGroupBox7.Controls.Add(Me.UltraLabel5)
        Me.UltraGroupBox7.Controls.Add(Me.UltraLabel40)
        Me.UltraGroupBox7.Controls.Add(Me.UltraLabel41)
        Me.UltraGroupBox7.Controls.Add(Me.UltraLabel42)
        Me.UltraGroupBox7.Controls.Add(Me.UltraLabel39)
        Me.UltraGroupBox7.Controls.Add(Me.UltraLabel38)
        Me.UltraGroupBox7.Controls.Add(Me.UltraLabel37)
        Me.UltraGroupBox7.Controls.Add(Me.cmbT_SC_Kitchen)
        Me.UltraGroupBox7.Controls.Add(Me.cmbT_SC_Shop)
        Me.UltraGroupBox7.Controls.Add(Me.cmbD_SC_Kitchen)
        Me.UltraGroupBox7.Controls.Add(Me.cmbD_SC_Shop)
        Me.UltraGroupBox7.Controls.Add(Me.cmbD_KC_Kitchen)
        Me.UltraGroupBox7.Controls.Add(Me.cmbD_KC_Shop)
        Me.UltraGroupBox7.Controls.Add(Me.cmbT_KC_Kitchen)
        Me.UltraGroupBox7.Controls.Add(Me.cmbT_KC_Shop)
        Me.UltraGroupBox7.Controls.Add(Me.cmbC_SC_Kitchen)
        Me.UltraGroupBox7.Controls.Add(Me.cmbC_SC_Shop)
        Me.UltraGroupBox7.Controls.Add(Me.cmbC_KC_Kitchen)
        Me.UltraGroupBox7.Controls.Add(Me.UltraLabel34)
        Me.UltraGroupBox7.Controls.Add(Me.UltraLabel33)
        Me.UltraGroupBox7.Controls.Add(Me.UltraLabel32)
        Me.UltraGroupBox7.Controls.Add(Me.UltraLabel36)
        Me.UltraGroupBox7.Controls.Add(Me.UltraLabel35)
        Me.UltraGroupBox7.Controls.Add(Me.cmbC_KC_Shop)
        Me.UltraGroupBox7.Controls.Add(Me.cmbPrinterKitchen)
        Me.UltraGroupBox7.Controls.Add(Me.cmbPrinterShop)
        Me.UltraGroupBox7.Controls.Add(Me.UltraLabel15)
        Me.UltraGroupBox7.Controls.Add(Me.UltraLabel14)
        Me.UltraGroupBox7.Location = New System.Drawing.Point(38, 11)
        Me.UltraGroupBox7.Name = "UltraGroupBox7"
        Me.UltraGroupBox7.Size = New System.Drawing.Size(470, 539)
        Me.UltraGroupBox7.TabIndex = 19
        Me.UltraGroupBox7.Text = "Printers"
        '
        'cmdSavePrinters
        '
        Me.cmdSavePrinters.Location = New System.Drawing.Point(317, 488)
        Me.cmdSavePrinters.Name = "cmdSavePrinters"
        Me.cmdSavePrinters.ShowFocusRect = False
        Me.cmdSavePrinters.ShowOutline = False
        Me.cmdSavePrinters.Size = New System.Drawing.Size(75, 26)
        Me.cmdSavePrinters.TabIndex = 89
        Me.cmdSavePrinters.Text = "Save"
        '
        'UltraLabel94
        '
        Me.UltraLabel94.AutoSize = True
        Me.UltraLabel94.Location = New System.Drawing.Point(42, 48)
        Me.UltraLabel94.Name = "UltraLabel94"
        Me.UltraLabel94.Size = New System.Drawing.Size(87, 19)
        Me.UltraLabel94.TabIndex = 88
        Me.UltraLabel94.Text = "Select cuisine:"
        '
        'cmdRefreshCuisinesPrinters
        '
        Me.cmdRefreshCuisinesPrinters.Location = New System.Drawing.Point(333, 45)
        Me.cmdRefreshCuisinesPrinters.Name = "cmdRefreshCuisinesPrinters"
        Me.cmdRefreshCuisinesPrinters.ShowFocusRect = False
        Me.cmdRefreshCuisinesPrinters.ShowOutline = False
        Me.cmdRefreshCuisinesPrinters.Size = New System.Drawing.Size(75, 26)
        Me.cmdRefreshCuisinesPrinters.TabIndex = 87
        Me.cmdRefreshCuisinesPrinters.Text = "Refresh"
        '
        'cmbCuisinePrinters
        '
        Me.cmbCuisinePrinters.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList
        Me.cmbCuisinePrinters.Location = New System.Drawing.Point(135, 44)
        Me.cmbCuisinePrinters.Name = "cmbCuisinePrinters"
        Me.cmbCuisinePrinters.Size = New System.Drawing.Size(186, 26)
        Me.cmbCuisinePrinters.TabIndex = 86
        '
        'chkHidePrintDialog
        '
        Appearance59.FontData.Name = "Segoe UI"
        Appearance59.FontData.SizeInPoints = 10.0!
        Me.chkHidePrintDialog.Appearance = Appearance59
        Me.chkHidePrintDialog.AutoSize = True
        Me.chkHidePrintDialog.BackColor = System.Drawing.Color.Transparent
        Me.chkHidePrintDialog.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkHidePrintDialog.Location = New System.Drawing.Point(76, 445)
        Me.chkHidePrintDialog.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkHidePrintDialog.Name = "chkHidePrintDialog"
        Me.chkHidePrintDialog.Size = New System.Drawing.Size(201, 23)
        Me.chkHidePrintDialog.TabIndex = 78
        Me.chkHidePrintDialog.Text = "Disable printing status popup"
        '
        'UltraLabel43
        '
        Me.UltraLabel43.AutoSize = True
        Me.UltraLabel43.Location = New System.Drawing.Point(300, 380)
        Me.UltraLabel43.Name = "UltraLabel43"
        Me.UltraLabel43.Size = New System.Drawing.Size(20, 19)
        Me.UltraLabel43.TabIndex = 70
        Me.UltraLabel43.Text = "SC"
        '
        'UltraLabel44
        '
        Me.UltraLabel44.AutoSize = True
        Me.UltraLabel44.Location = New System.Drawing.Point(300, 316)
        Me.UltraLabel44.Name = "UltraLabel44"
        Me.UltraLabel44.Size = New System.Drawing.Size(20, 19)
        Me.UltraLabel44.TabIndex = 69
        Me.UltraLabel44.Text = "SC"
        '
        'UltraLabel45
        '
        Me.UltraLabel45.AutoSize = True
        Me.UltraLabel45.Location = New System.Drawing.Point(300, 252)
        Me.UltraLabel45.Name = "UltraLabel45"
        Me.UltraLabel45.Size = New System.Drawing.Size(20, 19)
        Me.UltraLabel45.TabIndex = 68
        Me.UltraLabel45.Text = "SC"
        '
        'UltraLabel46
        '
        Me.UltraLabel46.AutoSize = True
        Me.UltraLabel46.Location = New System.Drawing.Point(300, 348)
        Me.UltraLabel46.Name = "UltraLabel46"
        Me.UltraLabel46.Size = New System.Drawing.Size(21, 19)
        Me.UltraLabel46.TabIndex = 67
        Me.UltraLabel46.Text = "KC"
        '
        'UltraLabel47
        '
        Me.UltraLabel47.AutoSize = True
        Me.UltraLabel47.Location = New System.Drawing.Point(300, 284)
        Me.UltraLabel47.Name = "UltraLabel47"
        Me.UltraLabel47.Size = New System.Drawing.Size(21, 19)
        Me.UltraLabel47.TabIndex = 66
        Me.UltraLabel47.Text = "KC"
        '
        'UltraLabel48
        '
        Me.UltraLabel48.AutoSize = True
        Me.UltraLabel48.Location = New System.Drawing.Point(300, 220)
        Me.UltraLabel48.Name = "UltraLabel48"
        Me.UltraLabel48.Size = New System.Drawing.Size(21, 19)
        Me.UltraLabel48.TabIndex = 65
        Me.UltraLabel48.Text = "KC"
        '
        'UltraLabel5
        '
        Me.UltraLabel5.AutoSize = True
        Me.UltraLabel5.Location = New System.Drawing.Point(169, 408)
        Me.UltraLabel5.Name = "UltraLabel5"
        Me.UltraLabel5.Size = New System.Drawing.Size(220, 19)
        Me.UltraLabel5.TabIndex = 64
        Me.UltraLabel5.Text = "(KC = kitchen copy, SC = shop copy)"
        '
        'UltraLabel40
        '
        Me.UltraLabel40.AutoSize = True
        Me.UltraLabel40.Location = New System.Drawing.Point(143, 380)
        Me.UltraLabel40.Name = "UltraLabel40"
        Me.UltraLabel40.Size = New System.Drawing.Size(20, 19)
        Me.UltraLabel40.TabIndex = 63
        Me.UltraLabel40.Text = "SC"
        '
        'UltraLabel41
        '
        Me.UltraLabel41.AutoSize = True
        Me.UltraLabel41.Location = New System.Drawing.Point(143, 316)
        Me.UltraLabel41.Name = "UltraLabel41"
        Me.UltraLabel41.Size = New System.Drawing.Size(20, 19)
        Me.UltraLabel41.TabIndex = 62
        Me.UltraLabel41.Text = "SC"
        '
        'UltraLabel42
        '
        Me.UltraLabel42.AutoSize = True
        Me.UltraLabel42.Location = New System.Drawing.Point(143, 252)
        Me.UltraLabel42.Name = "UltraLabel42"
        Me.UltraLabel42.Size = New System.Drawing.Size(20, 19)
        Me.UltraLabel42.TabIndex = 61
        Me.UltraLabel42.Text = "SC"
        '
        'UltraLabel39
        '
        Me.UltraLabel39.AutoSize = True
        Me.UltraLabel39.Location = New System.Drawing.Point(143, 348)
        Me.UltraLabel39.Name = "UltraLabel39"
        Me.UltraLabel39.Size = New System.Drawing.Size(21, 19)
        Me.UltraLabel39.TabIndex = 60
        Me.UltraLabel39.Text = "KC"
        '
        'UltraLabel38
        '
        Me.UltraLabel38.AutoSize = True
        Me.UltraLabel38.Location = New System.Drawing.Point(143, 284)
        Me.UltraLabel38.Name = "UltraLabel38"
        Me.UltraLabel38.Size = New System.Drawing.Size(21, 19)
        Me.UltraLabel38.TabIndex = 59
        Me.UltraLabel38.Text = "KC"
        '
        'UltraLabel37
        '
        Me.UltraLabel37.AutoSize = True
        Me.UltraLabel37.Location = New System.Drawing.Point(143, 220)
        Me.UltraLabel37.Name = "UltraLabel37"
        Me.UltraLabel37.Size = New System.Drawing.Size(21, 19)
        Me.UltraLabel37.TabIndex = 58
        Me.UltraLabel37.Text = "KC"
        '
        'cmbT_SC_Kitchen
        '
        Me.cmbT_SC_Kitchen.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList
        Me.cmbT_SC_Kitchen.Location = New System.Drawing.Point(327, 376)
        Me.cmbT_SC_Kitchen.Name = "cmbT_SC_Kitchen"
        Me.cmbT_SC_Kitchen.Size = New System.Drawing.Size(65, 26)
        Me.cmbT_SC_Kitchen.TabIndex = 51
        '
        'cmbT_SC_Shop
        '
        Me.cmbT_SC_Shop.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList
        Me.cmbT_SC_Shop.Location = New System.Drawing.Point(170, 376)
        Me.cmbT_SC_Shop.Name = "cmbT_SC_Shop"
        Me.cmbT_SC_Shop.Size = New System.Drawing.Size(65, 26)
        Me.cmbT_SC_Shop.TabIndex = 50
        '
        'cmbD_SC_Kitchen
        '
        Me.cmbD_SC_Kitchen.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList
        Me.cmbD_SC_Kitchen.Location = New System.Drawing.Point(327, 312)
        Me.cmbD_SC_Kitchen.Name = "cmbD_SC_Kitchen"
        Me.cmbD_SC_Kitchen.Size = New System.Drawing.Size(65, 26)
        Me.cmbD_SC_Kitchen.TabIndex = 47
        '
        'cmbD_SC_Shop
        '
        Me.cmbD_SC_Shop.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList
        Me.cmbD_SC_Shop.Location = New System.Drawing.Point(170, 312)
        Me.cmbD_SC_Shop.Name = "cmbD_SC_Shop"
        Me.cmbD_SC_Shop.Size = New System.Drawing.Size(65, 26)
        Me.cmbD_SC_Shop.TabIndex = 46
        '
        'cmbD_KC_Kitchen
        '
        Me.cmbD_KC_Kitchen.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList
        Me.cmbD_KC_Kitchen.Location = New System.Drawing.Point(327, 280)
        Me.cmbD_KC_Kitchen.Name = "cmbD_KC_Kitchen"
        Me.cmbD_KC_Kitchen.Size = New System.Drawing.Size(65, 26)
        Me.cmbD_KC_Kitchen.TabIndex = 45
        '
        'cmbD_KC_Shop
        '
        Me.cmbD_KC_Shop.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList
        Me.cmbD_KC_Shop.Location = New System.Drawing.Point(170, 280)
        Me.cmbD_KC_Shop.Name = "cmbD_KC_Shop"
        Me.cmbD_KC_Shop.Size = New System.Drawing.Size(65, 26)
        Me.cmbD_KC_Shop.TabIndex = 44
        '
        'cmbT_KC_Kitchen
        '
        Me.cmbT_KC_Kitchen.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList
        Me.cmbT_KC_Kitchen.Location = New System.Drawing.Point(327, 344)
        Me.cmbT_KC_Kitchen.Name = "cmbT_KC_Kitchen"
        Me.cmbT_KC_Kitchen.Size = New System.Drawing.Size(65, 26)
        Me.cmbT_KC_Kitchen.TabIndex = 49
        '
        'cmbT_KC_Shop
        '
        Me.cmbT_KC_Shop.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList
        Me.cmbT_KC_Shop.Location = New System.Drawing.Point(170, 344)
        Me.cmbT_KC_Shop.Name = "cmbT_KC_Shop"
        Me.cmbT_KC_Shop.Size = New System.Drawing.Size(65, 26)
        Me.cmbT_KC_Shop.TabIndex = 48
        '
        'cmbC_SC_Kitchen
        '
        Me.cmbC_SC_Kitchen.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList
        Me.cmbC_SC_Kitchen.Location = New System.Drawing.Point(327, 248)
        Me.cmbC_SC_Kitchen.Name = "cmbC_SC_Kitchen"
        Me.cmbC_SC_Kitchen.Size = New System.Drawing.Size(65, 26)
        Me.cmbC_SC_Kitchen.TabIndex = 43
        '
        'cmbC_SC_Shop
        '
        Me.cmbC_SC_Shop.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList
        Me.cmbC_SC_Shop.Location = New System.Drawing.Point(170, 248)
        Me.cmbC_SC_Shop.Name = "cmbC_SC_Shop"
        Me.cmbC_SC_Shop.Size = New System.Drawing.Size(65, 26)
        Me.cmbC_SC_Shop.TabIndex = 42
        '
        'cmbC_KC_Kitchen
        '
        Me.cmbC_KC_Kitchen.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList
        Me.cmbC_KC_Kitchen.Location = New System.Drawing.Point(327, 216)
        Me.cmbC_KC_Kitchen.Name = "cmbC_KC_Kitchen"
        Me.cmbC_KC_Kitchen.Size = New System.Drawing.Size(65, 26)
        Me.cmbC_KC_Kitchen.TabIndex = 41
        '
        'UltraLabel34
        '
        Me.UltraLabel34.AutoSize = True
        Me.UltraLabel34.Location = New System.Drawing.Point(85, 348)
        Me.UltraLabel34.Name = "UltraLabel34"
        Me.UltraLabel34.Size = New System.Drawing.Size(40, 19)
        Me.UltraLabel34.TabIndex = 48
        Me.UltraLabel34.Text = "Table:"
        '
        'UltraLabel33
        '
        Me.UltraLabel33.AutoSize = True
        Me.UltraLabel33.Location = New System.Drawing.Point(70, 284)
        Me.UltraLabel33.Name = "UltraLabel33"
        Me.UltraLabel33.Size = New System.Drawing.Size(55, 19)
        Me.UltraLabel33.TabIndex = 47
        Me.UltraLabel33.Text = "Delivery:"
        '
        'UltraLabel32
        '
        Me.UltraLabel32.AutoSize = True
        Me.UltraLabel32.Location = New System.Drawing.Point(58, 220)
        Me.UltraLabel32.Name = "UltraLabel32"
        Me.UltraLabel32.Size = New System.Drawing.Size(67, 19)
        Me.UltraLabel32.TabIndex = 46
        Me.UltraLabel32.Text = "Collection:"
        '
        'UltraLabel36
        '
        Me.UltraLabel36.AutoSize = True
        Me.UltraLabel36.Location = New System.Drawing.Point(150, 192)
        Me.UltraLabel36.Name = "UltraLabel36"
        Me.UltraLabel36.Size = New System.Drawing.Size(97, 19)
        Me.UltraLabel36.TabIndex = 45
        Me.UltraLabel36.Text = "To Shop Printer"
        '
        'UltraLabel35
        '
        Me.UltraLabel35.AutoSize = True
        Me.UltraLabel35.Location = New System.Drawing.Point(298, 192)
        Me.UltraLabel35.Name = "UltraLabel35"
        Me.UltraLabel35.Size = New System.Drawing.Size(110, 19)
        Me.UltraLabel35.TabIndex = 44
        Me.UltraLabel35.Text = "To Kitchen Printer"
        '
        'cmbC_KC_Shop
        '
        Me.cmbC_KC_Shop.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList
        Me.cmbC_KC_Shop.Location = New System.Drawing.Point(170, 216)
        Me.cmbC_KC_Shop.Name = "cmbC_KC_Shop"
        Me.cmbC_KC_Shop.Size = New System.Drawing.Size(65, 26)
        Me.cmbC_KC_Shop.TabIndex = 40
        '
        'cmbPrinterKitchen
        '
        Me.cmbPrinterKitchen.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList
        Me.cmbPrinterKitchen.Location = New System.Drawing.Point(135, 133)
        Me.cmbPrinterKitchen.Name = "cmbPrinterKitchen"
        Me.cmbPrinterKitchen.Size = New System.Drawing.Size(301, 26)
        Me.cmbPrinterKitchen.TabIndex = 37
        '
        'cmbPrinterShop
        '
        Me.cmbPrinterShop.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList
        Me.cmbPrinterShop.Location = New System.Drawing.Point(135, 101)
        Me.cmbPrinterShop.Name = "cmbPrinterShop"
        Me.cmbPrinterShop.Size = New System.Drawing.Size(301, 26)
        Me.cmbPrinterShop.TabIndex = 22
        '
        'UltraLabel15
        '
        Me.UltraLabel15.AutoSize = True
        Me.UltraLabel15.Location = New System.Drawing.Point(35, 137)
        Me.UltraLabel15.Name = "UltraLabel15"
        Me.UltraLabel15.Size = New System.Drawing.Size(94, 19)
        Me.UltraLabel15.TabIndex = 28
        Me.UltraLabel15.Text = "Kitchen Printer:"
        '
        'UltraLabel14
        '
        Me.UltraLabel14.AutoSize = True
        Me.UltraLabel14.Location = New System.Drawing.Point(48, 105)
        Me.UltraLabel14.Name = "UltraLabel14"
        Me.UltraLabel14.Size = New System.Drawing.Size(81, 19)
        Me.UltraLabel14.TabIndex = 27
        Me.UltraLabel14.Text = "Shop Printer:"
        '
        'UltraTabPageControl5
        '
        Me.UltraTabPageControl5.Controls.Add(Me.UltraGroupBox13)
        Me.UltraTabPageControl5.Location = New System.Drawing.Point(-10000, -10000)
        Me.UltraTabPageControl5.Name = "UltraTabPageControl5"
        Me.UltraTabPageControl5.Size = New System.Drawing.Size(546, 602)
        '
        'UltraGroupBox13
        '
        Appearance60.BackColor = System.Drawing.Color.Transparent
        Me.UltraGroupBox13.Appearance = Appearance60
        Me.UltraGroupBox13.Controls.Add(Me.UltraLabel108)
        Me.UltraGroupBox13.Controls.Add(Me.cmdSaveLabelPrinters)
        Me.UltraGroupBox13.Controls.Add(Me.UltraLabel95)
        Me.UltraGroupBox13.Controls.Add(Me.cmdRefreshCuisinesLabel)
        Me.UltraGroupBox13.Controls.Add(Me.cmbCuisineLabelPrinter)
        Me.UltraGroupBox13.Controls.Add(Me.cmdDefault)
        Me.UltraGroupBox13.Controls.Add(Me.UltraLabel66)
        Me.UltraGroupBox13.Controls.Add(Me.UltraLabel67)
        Me.UltraGroupBox13.Controls.Add(Me.txtLabelLeftOffset)
        Me.UltraGroupBox13.Controls.Add(Me.txtLabelTopOffset)
        Me.UltraGroupBox13.Controls.Add(Me.UltraLabel68)
        Me.UltraGroupBox13.Controls.Add(Me.UltraLabel69)
        Me.UltraGroupBox13.Controls.Add(Me.UltraLabel65)
        Me.UltraGroupBox13.Controls.Add(Me.UltraLabel64)
        Me.UltraGroupBox13.Controls.Add(Me.UltraLabel63)
        Me.UltraGroupBox13.Controls.Add(Me.UltraLabel62)
        Me.UltraGroupBox13.Controls.Add(Me.txtLabelHeight)
        Me.UltraGroupBox13.Controls.Add(Me.txtLabelWidth)
        Me.UltraGroupBox13.Controls.Add(Me.UltraLabel60)
        Me.UltraGroupBox13.Controls.Add(Me.UltraLabel61)
        Me.UltraGroupBox13.Controls.Add(Me.chkPrintLabelAny)
        Me.UltraGroupBox13.Controls.Add(Me.cmbPrinterLabel)
        Me.UltraGroupBox13.Controls.Add(Me.txtLabelTopMargin)
        Me.UltraGroupBox13.Controls.Add(Me.txtLabelLeftMargin)
        Me.UltraGroupBox13.Controls.Add(Me.UltraLabel16)
        Me.UltraGroupBox13.Controls.Add(Me.UltraLabel53)
        Me.UltraGroupBox13.Controls.Add(Me.UltraLabel52)
        Me.UltraGroupBox13.Controls.Add(Me.cmbLabelFontSize)
        Me.UltraGroupBox13.Controls.Add(Me.UltraLabel51)
        Me.UltraGroupBox13.Controls.Add(Me.chkPrintLabels)
        Me.UltraGroupBox13.Location = New System.Drawing.Point(38, 11)
        Me.UltraGroupBox13.Name = "UltraGroupBox13"
        Me.UltraGroupBox13.Size = New System.Drawing.Size(470, 531)
        Me.UltraGroupBox13.TabIndex = 18
        Me.UltraGroupBox13.Text = "Label Printer"
        '
        'UltraLabel108
        '
        Me.UltraLabel108.AutoSize = True
        Me.UltraLabel108.Location = New System.Drawing.Point(92, 480)
        Me.UltraLabel108.Name = "UltraLabel108"
        Me.UltraLabel108.Size = New System.Drawing.Size(252, 19)
        Me.UltraLabel108.TabIndex = 97
        Me.UltraLabel108.Text = "Click 'Save' after changes for each cuisine:"
        '
        'cmdSaveLabelPrinters
        '
        Me.cmdSaveLabelPrinters.Location = New System.Drawing.Point(350, 477)
        Me.cmdSaveLabelPrinters.Name = "cmdSaveLabelPrinters"
        Me.cmdSaveLabelPrinters.ShowFocusRect = False
        Me.cmdSaveLabelPrinters.ShowOutline = False
        Me.cmdSaveLabelPrinters.Size = New System.Drawing.Size(75, 26)
        Me.cmdSaveLabelPrinters.TabIndex = 96
        Me.cmdSaveLabelPrinters.Text = "Save"
        '
        'UltraLabel95
        '
        Me.UltraLabel95.AutoSize = True
        Me.UltraLabel95.Location = New System.Drawing.Point(77, 46)
        Me.UltraLabel95.Name = "UltraLabel95"
        Me.UltraLabel95.Size = New System.Drawing.Size(87, 19)
        Me.UltraLabel95.TabIndex = 95
        Me.UltraLabel95.Text = "Select cuisine:"
        '
        'cmdRefreshCuisinesLabel
        '
        Me.cmdRefreshCuisinesLabel.Location = New System.Drawing.Point(350, 42)
        Me.cmdRefreshCuisinesLabel.Name = "cmdRefreshCuisinesLabel"
        Me.cmdRefreshCuisinesLabel.ShowFocusRect = False
        Me.cmdRefreshCuisinesLabel.ShowOutline = False
        Me.cmdRefreshCuisinesLabel.Size = New System.Drawing.Size(75, 26)
        Me.cmdRefreshCuisinesLabel.TabIndex = 94
        Me.cmdRefreshCuisinesLabel.Text = "Refresh"
        '
        'cmbCuisineLabelPrinter
        '
        Me.cmbCuisineLabelPrinter.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList
        Me.cmbCuisineLabelPrinter.Location = New System.Drawing.Point(170, 42)
        Me.cmbCuisineLabelPrinter.Name = "cmbCuisineLabelPrinter"
        Me.cmbCuisineLabelPrinter.Size = New System.Drawing.Size(157, 26)
        Me.cmbCuisineLabelPrinter.TabIndex = 93
        '
        'cmdDefault
        '
        Me.cmdDefault.Location = New System.Drawing.Point(308, 359)
        Me.cmdDefault.Name = "cmdDefault"
        Me.cmdDefault.ShowFocusRect = False
        Me.cmdDefault.ShowOutline = False
        Me.cmdDefault.Size = New System.Drawing.Size(97, 26)
        Me.cmdDefault.TabIndex = 92
        Me.cmdDefault.Text = "Default"
        '
        'UltraLabel66
        '
        Me.UltraLabel66.AutoSize = True
        Me.UltraLabel66.Location = New System.Drawing.Point(228, 298)
        Me.UltraLabel66.Name = "UltraLabel66"
        Me.UltraLabel66.Size = New System.Drawing.Size(36, 19)
        Me.UltraLabel66.TabIndex = 91
        Me.UltraLabel66.Text = "(mm)"
        '
        'UltraLabel67
        '
        Me.UltraLabel67.AutoSize = True
        Me.UltraLabel67.Location = New System.Drawing.Point(228, 264)
        Me.UltraLabel67.Name = "UltraLabel67"
        Me.UltraLabel67.Size = New System.Drawing.Size(36, 19)
        Me.UltraLabel67.TabIndex = 90
        Me.UltraLabel67.Text = "(mm)"
        '
        'txtLabelLeftOffset
        '
        Me.txtLabelLeftOffset.Location = New System.Drawing.Point(170, 328)
        Me.txtLabelLeftOffset.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtLabelLeftOffset.Name = "txtLabelLeftOffset"
        Me.txtLabelLeftOffset.Size = New System.Drawing.Size(52, 24)
        Me.txtLabelLeftOffset.TabIndex = 86
        Me.txtLabelLeftOffset.Tag = "30"
        Me.txtLabelLeftOffset.Text = "30"
        Me.txtLabelLeftOffset.UseAppStyling = False
        Me.txtLabelLeftOffset.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'txtLabelTopOffset
        '
        Me.txtLabelTopOffset.Location = New System.Drawing.Point(170, 362)
        Me.txtLabelTopOffset.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtLabelTopOffset.Name = "txtLabelTopOffset"
        Me.txtLabelTopOffset.Size = New System.Drawing.Size(52, 24)
        Me.txtLabelTopOffset.TabIndex = 88
        Me.txtLabelTopOffset.Tag = "10"
        Me.txtLabelTopOffset.Text = "10"
        Me.txtLabelTopOffset.UseAppStyling = False
        Me.txtLabelTopOffset.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'UltraLabel68
        '
        Me.UltraLabel68.AutoSize = True
        Me.UltraLabel68.Location = New System.Drawing.Point(88, 298)
        Me.UltraLabel68.Name = "UltraLabel68"
        Me.UltraLabel68.Size = New System.Drawing.Size(76, 19)
        Me.UltraLabel68.TabIndex = 89
        Me.UltraLabel68.Text = "Top margin:"
        '
        'UltraLabel69
        '
        Me.UltraLabel69.AutoSize = True
        Me.UltraLabel69.Location = New System.Drawing.Point(89, 264)
        Me.UltraLabel69.Name = "UltraLabel69"
        Me.UltraLabel69.Size = New System.Drawing.Size(75, 19)
        Me.UltraLabel69.TabIndex = 87
        Me.UltraLabel69.Text = "Left margin:"
        '
        'UltraLabel65
        '
        Me.UltraLabel65.AutoSize = True
        Me.UltraLabel65.Location = New System.Drawing.Point(228, 332)
        Me.UltraLabel65.Name = "UltraLabel65"
        Me.UltraLabel65.Size = New System.Drawing.Size(36, 19)
        Me.UltraLabel65.TabIndex = 85
        Me.UltraLabel65.Text = "(mm)"
        '
        'UltraLabel64
        '
        Me.UltraLabel64.AutoSize = True
        Me.UltraLabel64.Location = New System.Drawing.Point(228, 366)
        Me.UltraLabel64.Name = "UltraLabel64"
        Me.UltraLabel64.Size = New System.Drawing.Size(36, 19)
        Me.UltraLabel64.TabIndex = 84
        Me.UltraLabel64.Text = "(mm)"
        '
        'UltraLabel63
        '
        Me.UltraLabel63.AutoSize = True
        Me.UltraLabel63.Location = New System.Drawing.Point(228, 230)
        Me.UltraLabel63.Name = "UltraLabel63"
        Me.UltraLabel63.Size = New System.Drawing.Size(36, 19)
        Me.UltraLabel63.TabIndex = 83
        Me.UltraLabel63.Text = "(mm)"
        '
        'UltraLabel62
        '
        Me.UltraLabel62.AutoSize = True
        Me.UltraLabel62.Location = New System.Drawing.Point(228, 196)
        Me.UltraLabel62.Name = "UltraLabel62"
        Me.UltraLabel62.Size = New System.Drawing.Size(36, 19)
        Me.UltraLabel62.TabIndex = 82
        Me.UltraLabel62.Text = "(mm)"
        '
        'txtLabelHeight
        '
        Me.txtLabelHeight.Location = New System.Drawing.Point(170, 192)
        Me.txtLabelHeight.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtLabelHeight.Name = "txtLabelHeight"
        Me.txtLabelHeight.Size = New System.Drawing.Size(52, 24)
        Me.txtLabelHeight.TabIndex = 78
        Me.txtLabelHeight.Tag = "20"
        Me.txtLabelHeight.Text = "20"
        Me.txtLabelHeight.UseAppStyling = False
        Me.txtLabelHeight.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'txtLabelWidth
        '
        Me.txtLabelWidth.Location = New System.Drawing.Point(170, 226)
        Me.txtLabelWidth.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtLabelWidth.Name = "txtLabelWidth"
        Me.txtLabelWidth.Size = New System.Drawing.Size(52, 24)
        Me.txtLabelWidth.TabIndex = 80
        Me.txtLabelWidth.Tag = "50"
        Me.txtLabelWidth.Text = "50"
        Me.txtLabelWidth.UseAppStyling = False
        Me.txtLabelWidth.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'UltraLabel60
        '
        Me.UltraLabel60.AutoSize = True
        Me.UltraLabel60.Location = New System.Drawing.Point(88, 230)
        Me.UltraLabel60.Name = "UltraLabel60"
        Me.UltraLabel60.Size = New System.Drawing.Size(76, 19)
        Me.UltraLabel60.TabIndex = 81
        Me.UltraLabel60.Text = "Label width:"
        '
        'UltraLabel61
        '
        Me.UltraLabel61.AutoSize = True
        Me.UltraLabel61.Location = New System.Drawing.Point(84, 196)
        Me.UltraLabel61.Name = "UltraLabel61"
        Me.UltraLabel61.Size = New System.Drawing.Size(80, 19)
        Me.UltraLabel61.TabIndex = 79
        Me.UltraLabel61.Text = "Label height:"
        '
        'chkPrintLabelAny
        '
        Appearance61.FontData.Name = "Segoe UI"
        Appearance61.FontData.SizeInPoints = 10.0!
        Me.chkPrintLabelAny.Appearance = Appearance61
        Me.chkPrintLabelAny.AutoSize = True
        Me.chkPrintLabelAny.BackColor = System.Drawing.Color.Transparent
        Me.chkPrintLabelAny.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkPrintLabelAny.Location = New System.Drawing.Point(90, 410)
        Me.chkPrintLabelAny.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkPrintLabelAny.Name = "chkPrintLabelAny"
        Me.chkPrintLabelAny.Size = New System.Drawing.Size(293, 23)
        Me.chkPrintLabelAny.TabIndex = 77
        Me.chkPrintLabelAny.Text = "Always print label for any non-database item"
        '
        'cmbPrinterLabel
        '
        Me.cmbPrinterLabel.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList
        Me.cmbPrinterLabel.Location = New System.Drawing.Point(170, 127)
        Me.cmbPrinterLabel.Name = "cmbPrinterLabel"
        Me.cmbPrinterLabel.Size = New System.Drawing.Size(220, 26)
        Me.cmbPrinterLabel.TabIndex = 52
        '
        'txtLabelTopMargin
        '
        Me.txtLabelTopMargin.Location = New System.Drawing.Point(170, 294)
        Me.txtLabelTopMargin.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtLabelTopMargin.Name = "txtLabelTopMargin"
        Me.txtLabelTopMargin.Size = New System.Drawing.Size(52, 24)
        Me.txtLabelTopMargin.TabIndex = 71
        Me.txtLabelTopMargin.Tag = "0"
        Me.txtLabelTopMargin.Text = "0"
        Me.txtLabelTopMargin.UseAppStyling = False
        Me.txtLabelTopMargin.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'txtLabelLeftMargin
        '
        Me.txtLabelLeftMargin.Location = New System.Drawing.Point(170, 260)
        Me.txtLabelLeftMargin.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtLabelLeftMargin.Name = "txtLabelLeftMargin"
        Me.txtLabelLeftMargin.Size = New System.Drawing.Size(52, 24)
        Me.txtLabelLeftMargin.TabIndex = 73
        Me.txtLabelLeftMargin.Tag = "0"
        Me.txtLabelLeftMargin.Text = "0"
        Me.txtLabelLeftMargin.UseAppStyling = False
        Me.txtLabelLeftMargin.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'UltraLabel16
        '
        Me.UltraLabel16.AutoSize = True
        Me.UltraLabel16.Location = New System.Drawing.Point(82, 131)
        Me.UltraLabel16.Name = "UltraLabel16"
        Me.UltraLabel16.Size = New System.Drawing.Size(82, 19)
        Me.UltraLabel16.TabIndex = 29
        Me.UltraLabel16.Text = "Label printer:"
        '
        'UltraLabel53
        '
        Me.UltraLabel53.AutoSize = True
        Me.UltraLabel53.Location = New System.Drawing.Point(108, 163)
        Me.UltraLabel53.Name = "UltraLabel53"
        Me.UltraLabel53.Size = New System.Drawing.Size(56, 19)
        Me.UltraLabel53.TabIndex = 76
        Me.UltraLabel53.Text = "Fontsize:"
        '
        'UltraLabel52
        '
        Me.UltraLabel52.AutoSize = True
        Me.UltraLabel52.Location = New System.Drawing.Point(97, 332)
        Me.UltraLabel52.Name = "UltraLabel52"
        Me.UltraLabel52.Size = New System.Drawing.Size(67, 19)
        Me.UltraLabel52.TabIndex = 74
        Me.UltraLabel52.Text = "Left offset:"
        '
        'cmbLabelFontSize
        '
        Me.cmbLabelFontSize.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList
        Me.cmbLabelFontSize.Location = New System.Drawing.Point(170, 159)
        Me.cmbLabelFontSize.Name = "cmbLabelFontSize"
        Me.cmbLabelFontSize.Size = New System.Drawing.Size(82, 26)
        Me.cmbLabelFontSize.TabIndex = 75
        '
        'UltraLabel51
        '
        Me.UltraLabel51.AutoSize = True
        Me.UltraLabel51.Location = New System.Drawing.Point(96, 366)
        Me.UltraLabel51.Name = "UltraLabel51"
        Me.UltraLabel51.Size = New System.Drawing.Size(68, 19)
        Me.UltraLabel51.TabIndex = 72
        Me.UltraLabel51.Text = "Top offset:"
        '
        'chkPrintLabels
        '
        Appearance62.FontData.Name = "Segoe UI"
        Appearance62.FontData.SizeInPoints = 10.0!
        Me.chkPrintLabels.Appearance = Appearance62
        Me.chkPrintLabels.AutoSize = True
        Me.chkPrintLabels.BackColor = System.Drawing.Color.Transparent
        Me.chkPrintLabels.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkPrintLabels.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkPrintLabels.Location = New System.Drawing.Point(90, 97)
        Me.chkPrintLabels.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkPrintLabels.Name = "chkPrintLabels"
        Me.chkPrintLabels.Size = New System.Drawing.Size(92, 23)
        Me.chkPrintLabels.TabIndex = 53
        Me.chkPrintLabels.Text = "Print labels:"
        '
        'UltraTabPageControl13
        '
        Me.UltraTabPageControl13.Controls.Add(Me.UltraGroupBox10)
        Me.UltraTabPageControl13.Location = New System.Drawing.Point(-10000, -10000)
        Me.UltraTabPageControl13.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.UltraTabPageControl13.Name = "UltraTabPageControl13"
        Me.UltraTabPageControl13.Size = New System.Drawing.Size(546, 602)
        '
        'UltraGroupBox10
        '
        Appearance63.BackColor = System.Drawing.Color.Transparent
        Me.UltraGroupBox10.Appearance = Appearance63
        Me.UltraGroupBox10.Controls.Add(Me.chkSameSKHeader)
        Me.UltraGroupBox10.Controls.Add(Me.chkSimultaneousPrinting)
        Me.UltraGroupBox10.Controls.Add(Me.chkKitchenGap)
        Me.UltraGroupBox10.Controls.Add(Me.chkExtraGap)
        Me.UltraGroupBox10.Controls.Add(Me.chkDrinksFoodGrouped)
        Me.UltraGroupBox10.Controls.Add(Me.chkDrinksHeader)
        Me.UltraGroupBox10.Controls.Add(Me.chkDrinksAndFoodGap)
        Me.UltraGroupBox10.Controls.Add(Me.chkDrinksFoodSeparatePrice)
        Me.UltraGroupBox10.Controls.Add(Me.chkDrinksItemise)
        Me.UltraGroupBox10.Controls.Add(Me.UltraLabel58)
        Me.UltraGroupBox10.Controls.Add(Me.UltraLabel57)
        Me.UltraGroupBox10.Controls.Add(Me.UltraLabel56)
        Me.UltraGroupBox10.Controls.Add(Me.optKitchen)
        Me.UltraGroupBox10.Controls.Add(Me.optCustomer)
        Me.UltraGroupBox10.Controls.Add(Me.UltraLabel54)
        Me.UltraGroupBox10.Controls.Add(Me.UltraLabel55)
        Me.UltraGroupBox10.Controls.Add(Me.optOnScreen)
        Me.UltraGroupBox10.Controls.Add(Me.chkKitchenDate)
        Me.UltraGroupBox10.Controls.Add(Me.chkShopDate)
        Me.UltraGroupBox10.Controls.Add(Me.UltraLabel19)
        Me.UltraGroupBox10.Controls.Add(Me.chkKitchenTime)
        Me.UltraGroupBox10.Controls.Add(Me.chkShopTime)
        Me.UltraGroupBox10.Controls.Add(Me.UltraLabel17)
        Me.UltraGroupBox10.Controls.Add(Me.chkKitchenCard)
        Me.UltraGroupBox10.Controls.Add(Me.chkShopCard)
        Me.UltraGroupBox10.Controls.Add(Me.chkKitchenItem)
        Me.UltraGroupBox10.Controls.Add(Me.chkShopItem)
        Me.UltraGroupBox10.Controls.Add(Me.UltraLabel23)
        Me.UltraGroupBox10.Controls.Add(Me.UltraLabel22)
        Me.UltraGroupBox10.Controls.Add(Me.chkKitchenTotal)
        Me.UltraGroupBox10.Controls.Add(Me.chkShopTotal)
        Me.UltraGroupBox10.Controls.Add(Me.UltraLabel12)
        Me.UltraGroupBox10.Controls.Add(Me.UltraLabel3)
        Me.UltraGroupBox10.Controls.Add(Me.UltraLabel2)
        Me.UltraGroupBox10.Location = New System.Drawing.Point(38, 11)
        Me.UltraGroupBox10.Name = "UltraGroupBox10"
        Me.UltraGroupBox10.Size = New System.Drawing.Size(470, 573)
        Me.UltraGroupBox10.TabIndex = 20
        Me.UltraGroupBox10.Text = "Print Settings"
        '
        'chkSameSKHeader
        '
        Appearance64.FontData.Name = "Segoe UI"
        Appearance64.FontData.SizeInPoints = 10.0!
        Me.chkSameSKHeader.Appearance = Appearance64
        Me.chkSameSKHeader.AutoSize = True
        Me.chkSameSKHeader.BackColor = System.Drawing.Color.Transparent
        Me.chkSameSKHeader.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkSameSKHeader.Location = New System.Drawing.Point(37, 471)
        Me.chkSameSKHeader.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkSameSKHeader.Name = "chkSameSKHeader"
        Me.chkSameSKHeader.Size = New System.Drawing.Size(252, 23)
        Me.chkSameSKHeader.TabIndex = 97
        Me.chkSameSKHeader.Text = "Do kitchen header same as shop copy"
        '
        'chkSimultaneousPrinting
        '
        Appearance65.FontData.Name = "Segoe UI"
        Appearance65.FontData.SizeInPoints = 10.0!
        Me.chkSimultaneousPrinting.Appearance = Appearance65
        Me.chkSimultaneousPrinting.AutoSize = True
        Me.chkSimultaneousPrinting.BackColor = System.Drawing.Color.Transparent
        Me.chkSimultaneousPrinting.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkSimultaneousPrinting.Location = New System.Drawing.Point(37, 451)
        Me.chkSimultaneousPrinting.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkSimultaneousPrinting.Name = "chkSimultaneousPrinting"
        Me.chkSimultaneousPrinting.Size = New System.Drawing.Size(434, 23)
        Me.chkSimultaneousPrinting.TabIndex = 96
        Me.chkSimultaneousPrinting.Text = "Print to both printers at same time (unckeck if print problems occur)"
        '
        'chkKitchenGap
        '
        Appearance66.FontData.Name = "Segoe UI"
        Appearance66.FontData.SizeInPoints = 10.0!
        Me.chkKitchenGap.Appearance = Appearance66
        Me.chkKitchenGap.AutoSize = True
        Me.chkKitchenGap.BackColor = System.Drawing.Color.Transparent
        Me.chkKitchenGap.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkKitchenGap.Location = New System.Drawing.Point(37, 331)
        Me.chkKitchenGap.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkKitchenGap.Name = "chkKitchenGap"
        Me.chkKitchenGap.Size = New System.Drawing.Size(311, 23)
        Me.chkKitchenGap.TabIndex = 93
        Me.chkKitchenGap.Text = "Put a gap between dish groups on kitchen copy"
        '
        'chkExtraGap
        '
        Appearance67.FontData.Name = "Segoe UI"
        Appearance67.FontData.SizeInPoints = 10.0!
        Me.chkExtraGap.Appearance = Appearance67
        Me.chkExtraGap.BackColor = System.Drawing.Color.Transparent
        Me.chkExtraGap.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkExtraGap.Location = New System.Drawing.Point(37, 311)
        Me.chkExtraGap.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkExtraGap.Name = "chkExtraGap"
        Me.chkExtraGap.Size = New System.Drawing.Size(416, 26)
        Me.chkExtraGap.TabIndex = 95
        Me.chkExtraGap.Text = "Extra gap between starters and main courses on kitchen copy"
        '
        'chkDrinksFoodGrouped
        '
        Appearance68.FontData.Name = "Segoe UI"
        Appearance68.FontData.SizeInPoints = 10.0!
        Me.chkDrinksFoodGrouped.Appearance = Appearance68
        Me.chkDrinksFoodGrouped.AutoSize = True
        Me.chkDrinksFoodGrouped.BackColor = System.Drawing.Color.Transparent
        Me.chkDrinksFoodGrouped.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkDrinksFoodGrouped.Location = New System.Drawing.Point(37, 351)
        Me.chkDrinksFoodGrouped.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkDrinksFoodGrouped.Name = "chkDrinksFoodGrouped"
        Me.chkDrinksFoodGrouped.Size = New System.Drawing.Size(192, 23)
        Me.chkDrinksFoodGrouped.TabIndex = 94
        Me.chkDrinksFoodGrouped.Text = "Put 'Drinks' with food listing"
        '
        'chkDrinksHeader
        '
        Appearance69.FontData.Name = "Segoe UI"
        Appearance69.FontData.SizeInPoints = 10.0!
        Me.chkDrinksHeader.Appearance = Appearance69
        Me.chkDrinksHeader.AutoSize = True
        Me.chkDrinksHeader.BackColor = System.Drawing.Color.Transparent
        Me.chkDrinksHeader.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkDrinksHeader.Location = New System.Drawing.Point(37, 431)
        Me.chkDrinksHeader.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkDrinksHeader.Name = "chkDrinksHeader"
        Me.chkDrinksHeader.Size = New System.Drawing.Size(209, 23)
        Me.chkDrinksHeader.TabIndex = 83
        Me.chkDrinksHeader.Text = "Show drinks label above drinks"
        '
        'chkDrinksAndFoodGap
        '
        Appearance70.FontData.Name = "Segoe UI"
        Appearance70.FontData.SizeInPoints = 10.0!
        Me.chkDrinksAndFoodGap.Appearance = Appearance70
        Me.chkDrinksAndFoodGap.AutoSize = True
        Me.chkDrinksAndFoodGap.BackColor = System.Drawing.Color.Transparent
        Me.chkDrinksAndFoodGap.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkDrinksAndFoodGap.Location = New System.Drawing.Point(37, 391)
        Me.chkDrinksAndFoodGap.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkDrinksAndFoodGap.Name = "chkDrinksAndFoodGap"
        Me.chkDrinksAndFoodGap.Size = New System.Drawing.Size(212, 23)
        Me.chkDrinksAndFoodGap.TabIndex = 82
        Me.chkDrinksAndFoodGap.Text = "Put gap between food & drinks"
        '
        'chkDrinksFoodSeparatePrice
        '
        Appearance71.FontData.Name = "Segoe UI"
        Appearance71.FontData.SizeInPoints = 10.0!
        Me.chkDrinksFoodSeparatePrice.Appearance = Appearance71
        Me.chkDrinksFoodSeparatePrice.AutoSize = True
        Me.chkDrinksFoodSeparatePrice.BackColor = System.Drawing.Color.Transparent
        Me.chkDrinksFoodSeparatePrice.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkDrinksFoodSeparatePrice.Location = New System.Drawing.Point(37, 411)
        Me.chkDrinksFoodSeparatePrice.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkDrinksFoodSeparatePrice.Name = "chkDrinksFoodSeparatePrice"
        Me.chkDrinksFoodSeparatePrice.Size = New System.Drawing.Size(196, 23)
        Me.chkDrinksFoodSeparatePrice.TabIndex = 77
        Me.chkDrinksFoodSeparatePrice.Text = "Separate food & drink prices"
        '
        'chkDrinksItemise
        '
        Appearance72.FontData.Name = "Segoe UI"
        Appearance72.FontData.SizeInPoints = 10.0!
        Me.chkDrinksItemise.Appearance = Appearance72
        Me.chkDrinksItemise.AutoSize = True
        Me.chkDrinksItemise.BackColor = System.Drawing.Color.Transparent
        Me.chkDrinksItemise.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkDrinksItemise.Location = New System.Drawing.Point(37, 371)
        Me.chkDrinksItemise.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkDrinksItemise.Name = "chkDrinksItemise"
        Me.chkDrinksItemise.Size = New System.Drawing.Size(171, 23)
        Me.chkDrinksItemise.TabIndex = 76
        Me.chkDrinksItemise.Text = "Itemise drinks on receipt"
        '
        'UltraLabel58
        '
        Me.UltraLabel58.AutoSize = True
        Me.UltraLabel58.Location = New System.Drawing.Point(46, 249)
        Me.UltraLabel58.Name = "UltraLabel58"
        Me.UltraLabel58.Size = New System.Drawing.Size(81, 19)
        Me.UltraLabel58.TabIndex = 73
        Me.UltraLabel58.Text = "Kitchen copy"
        '
        'UltraLabel57
        '
        Me.UltraLabel57.AutoSize = True
        Me.UltraLabel57.Location = New System.Drawing.Point(46, 223)
        Me.UltraLabel57.Name = "UltraLabel57"
        Me.UltraLabel57.Size = New System.Drawing.Size(106, 19)
        Me.UltraLabel57.TabIndex = 72
        Me.UltraLabel57.Text = "Customer receipt"
        '
        'UltraLabel56
        '
        Me.UltraLabel56.AutoSize = True
        Me.UltraLabel56.Location = New System.Drawing.Point(46, 197)
        Me.UltraLabel56.Name = "UltraLabel56"
        Me.UltraLabel56.Size = New System.Drawing.Size(115, 19)
        Me.UltraLabel56.TabIndex = 71
        Me.UltraLabel56.Text = "On-screen buttons"
        '
        'optKitchen
        '
        Me.optKitchen.BorderStyle = Infragistics.Win.UIElementBorderStyle.None
        ValueListItem8.DataValue = "LN"
        ValueListItem8.DisplayText = " "
        ValueListItem9.DataValue = "SN"
        ValueListItem9.DisplayText = " "
        Me.optKitchen.Items.AddRange(New Infragistics.Win.ValueListItem() {ValueListItem8, ValueListItem9})
        Me.optKitchen.ItemSpacingHorizontal = 57
        Me.optKitchen.Location = New System.Drawing.Point(221, 248)
        Me.optKitchen.Name = "optKitchen"
        Me.optKitchen.Size = New System.Drawing.Size(97, 20)
        Me.optKitchen.TabIndex = 70
        Me.optKitchen.UseAppStyling = False
        Me.optKitchen.UseFlatMode = Infragistics.Win.DefaultableBoolean.[False]
        '
        'optCustomer
        '
        Me.optCustomer.BorderStyle = Infragistics.Win.UIElementBorderStyle.None
        ValueListItem10.DataValue = "LN"
        ValueListItem10.DisplayText = " "
        ValueListItem25.DataValue = "SN"
        ValueListItem25.DisplayText = " "
        Me.optCustomer.Items.AddRange(New Infragistics.Win.ValueListItem() {ValueListItem10, ValueListItem25})
        Me.optCustomer.ItemSpacingHorizontal = 57
        Me.optCustomer.Location = New System.Drawing.Point(221, 222)
        Me.optCustomer.Name = "optCustomer"
        Me.optCustomer.Size = New System.Drawing.Size(97, 20)
        Me.optCustomer.TabIndex = 69
        Me.optCustomer.UseAppStyling = False
        Me.optCustomer.UseFlatMode = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraLabel54
        '
        Me.UltraLabel54.AutoSize = True
        Me.UltraLabel54.Location = New System.Drawing.Point(194, 171)
        Me.UltraLabel54.Name = "UltraLabel54"
        Me.UltraLabel54.Size = New System.Drawing.Size(71, 19)
        Me.UltraLabel54.TabIndex = 68
        Me.UltraLabel54.Text = "Long name"
        '
        'UltraLabel55
        '
        Me.UltraLabel55.AutoSize = True
        Me.UltraLabel55.Location = New System.Drawing.Point(271, 171)
        Me.UltraLabel55.Name = "UltraLabel55"
        Me.UltraLabel55.Size = New System.Drawing.Size(73, 19)
        Me.UltraLabel55.TabIndex = 67
        Me.UltraLabel55.Text = "Short name"
        '
        'optOnScreen
        '
        Me.optOnScreen.BorderStyle = Infragistics.Win.UIElementBorderStyle.None
        ValueListItem54.DataValue = "LN"
        ValueListItem54.DisplayText = " "
        ValueListItem55.DataValue = "SN"
        ValueListItem55.DisplayText = " "
        Me.optOnScreen.Items.AddRange(New Infragistics.Win.ValueListItem() {ValueListItem54, ValueListItem55})
        Me.optOnScreen.ItemSpacingHorizontal = 57
        Me.optOnScreen.Location = New System.Drawing.Point(221, 196)
        Me.optOnScreen.Name = "optOnScreen"
        Me.optOnScreen.Size = New System.Drawing.Size(97, 20)
        Me.optOnScreen.TabIndex = 66
        Me.optOnScreen.UseAppStyling = False
        Me.optOnScreen.UseFlatMode = Infragistics.Win.DefaultableBoolean.[False]
        '
        'chkKitchenDate
        '
        Appearance73.FontData.Name = "Segoe UI"
        Appearance73.FontData.SizeInPoints = 10.0!
        Me.chkKitchenDate.Appearance = Appearance73
        Me.chkKitchenDate.AutoSize = True
        Me.chkKitchenDate.BackColor = System.Drawing.Color.Transparent
        Me.chkKitchenDate.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkKitchenDate.Location = New System.Drawing.Point(299, 144)
        Me.chkKitchenDate.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkKitchenDate.Name = "chkKitchenDate"
        Me.chkKitchenDate.Size = New System.Drawing.Size(14, 13)
        Me.chkKitchenDate.TabIndex = 65
        '
        'chkShopDate
        '
        Appearance74.FontData.Name = "Segoe UI"
        Appearance74.FontData.SizeInPoints = 10.0!
        Me.chkShopDate.Appearance = Appearance74
        Me.chkShopDate.AutoSize = True
        Me.chkShopDate.BackColor = System.Drawing.Color.Transparent
        Me.chkShopDate.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkShopDate.Location = New System.Drawing.Point(221, 144)
        Me.chkShopDate.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkShopDate.Name = "chkShopDate"
        Me.chkShopDate.Size = New System.Drawing.Size(14, 13)
        Me.chkShopDate.TabIndex = 64
        '
        'UltraLabel19
        '
        Me.UltraLabel19.AutoSize = True
        Me.UltraLabel19.Location = New System.Drawing.Point(46, 138)
        Me.UltraLabel19.Name = "UltraLabel19"
        Me.UltraLabel19.Size = New System.Drawing.Size(62, 19)
        Me.UltraLabel19.TabIndex = 63
        Me.UltraLabel19.Text = "Print date"
        '
        'chkKitchenTime
        '
        Appearance75.FontData.Name = "Segoe UI"
        Appearance75.FontData.SizeInPoints = 10.0!
        Me.chkKitchenTime.Appearance = Appearance75
        Me.chkKitchenTime.AutoSize = True
        Me.chkKitchenTime.BackColor = System.Drawing.Color.Transparent
        Me.chkKitchenTime.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkKitchenTime.Location = New System.Drawing.Point(299, 119)
        Me.chkKitchenTime.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkKitchenTime.Name = "chkKitchenTime"
        Me.chkKitchenTime.Size = New System.Drawing.Size(14, 13)
        Me.chkKitchenTime.TabIndex = 62
        '
        'chkShopTime
        '
        Appearance76.FontData.Name = "Segoe UI"
        Appearance76.FontData.SizeInPoints = 10.0!
        Me.chkShopTime.Appearance = Appearance76
        Me.chkShopTime.AutoSize = True
        Me.chkShopTime.BackColor = System.Drawing.Color.Transparent
        Me.chkShopTime.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkShopTime.Location = New System.Drawing.Point(221, 119)
        Me.chkShopTime.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkShopTime.Name = "chkShopTime"
        Me.chkShopTime.Size = New System.Drawing.Size(14, 13)
        Me.chkShopTime.TabIndex = 61
        '
        'UltraLabel17
        '
        Me.UltraLabel17.AutoSize = True
        Me.UltraLabel17.Location = New System.Drawing.Point(46, 113)
        Me.UltraLabel17.Name = "UltraLabel17"
        Me.UltraLabel17.Size = New System.Drawing.Size(62, 19)
        Me.UltraLabel17.TabIndex = 60
        Me.UltraLabel17.Text = "Print time"
        '
        'chkKitchenCard
        '
        Appearance77.FontData.Name = "Segoe UI"
        Appearance77.FontData.SizeInPoints = 10.0!
        Me.chkKitchenCard.Appearance = Appearance77
        Me.chkKitchenCard.AutoSize = True
        Me.chkKitchenCard.BackColor = System.Drawing.Color.Transparent
        Me.chkKitchenCard.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkKitchenCard.Location = New System.Drawing.Point(299, 94)
        Me.chkKitchenCard.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkKitchenCard.Name = "chkKitchenCard"
        Me.chkKitchenCard.Size = New System.Drawing.Size(14, 13)
        Me.chkKitchenCard.TabIndex = 59
        '
        'chkShopCard
        '
        Appearance78.FontData.Name = "Segoe UI"
        Appearance78.FontData.SizeInPoints = 10.0!
        Me.chkShopCard.Appearance = Appearance78
        Me.chkShopCard.AutoSize = True
        Me.chkShopCard.BackColor = System.Drawing.Color.Transparent
        Me.chkShopCard.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkShopCard.Location = New System.Drawing.Point(221, 94)
        Me.chkShopCard.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkShopCard.Name = "chkShopCard"
        Me.chkShopCard.Size = New System.Drawing.Size(14, 13)
        Me.chkShopCard.TabIndex = 58
        '
        'chkKitchenItem
        '
        Appearance79.FontData.Name = "Segoe UI"
        Appearance79.FontData.SizeInPoints = 10.0!
        Me.chkKitchenItem.Appearance = Appearance79
        Me.chkKitchenItem.AutoSize = True
        Me.chkKitchenItem.BackColor = System.Drawing.Color.Transparent
        Me.chkKitchenItem.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkKitchenItem.Location = New System.Drawing.Point(299, 69)
        Me.chkKitchenItem.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkKitchenItem.Name = "chkKitchenItem"
        Me.chkKitchenItem.Size = New System.Drawing.Size(14, 13)
        Me.chkKitchenItem.TabIndex = 57
        '
        'chkShopItem
        '
        Appearance80.FontData.Name = "Segoe UI"
        Appearance80.FontData.SizeInPoints = 10.0!
        Me.chkShopItem.Appearance = Appearance80
        Me.chkShopItem.AutoSize = True
        Me.chkShopItem.BackColor = System.Drawing.Color.Transparent
        Me.chkShopItem.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkShopItem.Location = New System.Drawing.Point(221, 69)
        Me.chkShopItem.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkShopItem.Name = "chkShopItem"
        Me.chkShopItem.Size = New System.Drawing.Size(14, 13)
        Me.chkShopItem.TabIndex = 56
        '
        'UltraLabel23
        '
        Me.UltraLabel23.AutoSize = True
        Me.UltraLabel23.Location = New System.Drawing.Point(46, 63)
        Me.UltraLabel23.Name = "UltraLabel23"
        Me.UltraLabel23.Size = New System.Drawing.Size(95, 19)
        Me.UltraLabel23.TabIndex = 55
        Me.UltraLabel23.Text = "Print item price"
        '
        'UltraLabel22
        '
        Me.UltraLabel22.AutoSize = True
        Me.UltraLabel22.Location = New System.Drawing.Point(46, 88)
        Me.UltraLabel22.Name = "UltraLabel22"
        Me.UltraLabel22.Size = New System.Drawing.Size(111, 19)
        Me.UltraLabel22.TabIndex = 54
        Me.UltraLabel22.Text = "Print card number"
        '
        'chkKitchenTotal
        '
        Appearance81.FontData.Name = "Segoe UI"
        Appearance81.FontData.SizeInPoints = 10.0!
        Me.chkKitchenTotal.Appearance = Appearance81
        Me.chkKitchenTotal.AutoSize = True
        Me.chkKitchenTotal.BackColor = System.Drawing.Color.Transparent
        Me.chkKitchenTotal.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkKitchenTotal.Location = New System.Drawing.Point(299, 44)
        Me.chkKitchenTotal.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkKitchenTotal.Name = "chkKitchenTotal"
        Me.chkKitchenTotal.Size = New System.Drawing.Size(14, 13)
        Me.chkKitchenTotal.TabIndex = 49
        '
        'chkShopTotal
        '
        Appearance82.FontData.Name = "Segoe UI"
        Appearance82.FontData.SizeInPoints = 10.0!
        Me.chkShopTotal.Appearance = Appearance82
        Me.chkShopTotal.AutoSize = True
        Me.chkShopTotal.BackColor = System.Drawing.Color.Transparent
        Me.chkShopTotal.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkShopTotal.Location = New System.Drawing.Point(221, 44)
        Me.chkShopTotal.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkShopTotal.Name = "chkShopTotal"
        Me.chkShopTotal.Size = New System.Drawing.Size(14, 13)
        Me.chkShopTotal.TabIndex = 48
        '
        'UltraLabel12
        '
        Me.UltraLabel12.AutoSize = True
        Me.UltraLabel12.Location = New System.Drawing.Point(211, 18)
        Me.UltraLabel12.Name = "UltraLabel12"
        Me.UltraLabel12.Size = New System.Drawing.Size(35, 19)
        Me.UltraLabel12.TabIndex = 47
        Me.UltraLabel12.Text = "Shop"
        '
        'UltraLabel3
        '
        Me.UltraLabel3.AutoSize = True
        Me.UltraLabel3.Location = New System.Drawing.Point(284, 18)
        Me.UltraLabel3.Name = "UltraLabel3"
        Me.UltraLabel3.Size = New System.Drawing.Size(49, 19)
        Me.UltraLabel3.TabIndex = 46
        Me.UltraLabel3.Text = "Kitchen"
        '
        'UltraLabel2
        '
        Me.UltraLabel2.AutoSize = True
        Me.UltraLabel2.Location = New System.Drawing.Point(46, 38)
        Me.UltraLabel2.Name = "UltraLabel2"
        Me.UltraLabel2.Size = New System.Drawing.Size(84, 19)
        Me.UltraLabel2.TabIndex = 45
        Me.UltraLabel2.Text = "Print bill total"
        '
        'UltraTabPageControl17
        '
        Me.UltraTabPageControl17.Controls.Add(Me.UltraGroupBox18)
        Me.UltraTabPageControl17.Location = New System.Drawing.Point(-10000, -10000)
        Me.UltraTabPageControl17.Name = "UltraTabPageControl17"
        Me.UltraTabPageControl17.Size = New System.Drawing.Size(546, 602)
        '
        'UltraGroupBox18
        '
        Appearance83.BackColor = System.Drawing.Color.Transparent
        Me.UltraGroupBox18.Appearance = Appearance83
        Me.UltraGroupBox18.Controls.Add(Me.UltraLabel115)
        Me.UltraGroupBox18.Controls.Add(Me.UltraLabel114)
        Me.UltraGroupBox18.Controls.Add(Me.UltraLabel113)
        Me.UltraGroupBox18.Controls.Add(Me.txtCentreOffset)
        Me.UltraGroupBox18.Controls.Add(Me.UltraLabel112)
        Me.UltraGroupBox18.Controls.Add(Me.txtRightOffset)
        Me.UltraGroupBox18.Controls.Add(Me.UltraLabel109)
        Me.UltraGroupBox18.Controls.Add(Me.txtPaperWidth)
        Me.UltraGroupBox18.Controls.Add(Me.UltraLabel105)
        Me.UltraGroupBox18.Controls.Add(Me.txtKitchenHeaderText)
        Me.UltraGroupBox18.Controls.Add(Me.UltraLabel100)
        Me.UltraGroupBox18.Controls.Add(Me.cmbFontSizeKitchenAddress)
        Me.UltraGroupBox18.Controls.Add(Me.UltraLabel99)
        Me.UltraGroupBox18.Controls.Add(Me.cmbFontSizeKitchen)
        Me.UltraGroupBox18.Controls.Add(Me.UltraLabel98)
        Me.UltraGroupBox18.Controls.Add(Me.cmbFontSizeShop)
        Me.UltraGroupBox18.Controls.Add(Me.txtKitchenTopOffset)
        Me.UltraGroupBox18.Controls.Add(Me.UltraLabel92)
        Me.UltraGroupBox18.Controls.Add(Me.UltraLabel93)
        Me.UltraGroupBox18.Controls.Add(Me.UltraLabel84)
        Me.UltraGroupBox18.Controls.Add(Me.UltraLabel81)
        Me.UltraGroupBox18.Controls.Add(Me.txtMinPaperLengthKitchen)
        Me.UltraGroupBox18.Controls.Add(Me.UltraLabel80)
        Me.UltraGroupBox18.Controls.Add(Me.txtMinPaperLengthShop)
        Me.UltraGroupBox18.Controls.Add(Me.UltraLabel77)
        Me.UltraGroupBox18.Controls.Add(Me.txtShopTopOffset)
        Me.UltraGroupBox18.Controls.Add(Me.UltraLabel27)
        Me.UltraGroupBox18.Controls.Add(Me.txtDrinksLabel)
        Me.UltraGroupBox18.Controls.Add(Me.UltraLabel26)
        Me.UltraGroupBox18.Controls.Add(Me.txtFoodLabel)
        Me.UltraGroupBox18.Controls.Add(Me.UltraLabel111)
        Me.UltraGroupBox18.Controls.Add(Me.cmbPaidLocation)
        Me.UltraGroupBox18.Controls.Add(Me.UltraLabel110)
        Me.UltraGroupBox18.Controls.Add(Me.cmbPaidFontSize)
        Me.UltraGroupBox18.Location = New System.Drawing.Point(38, 11)
        Me.UltraGroupBox18.Name = "UltraGroupBox18"
        Me.UltraGroupBox18.Size = New System.Drawing.Size(470, 573)
        Me.UltraGroupBox18.TabIndex = 21
        Me.UltraGroupBox18.Text = "More Print Settings"
        '
        'UltraLabel115
        '
        Me.UltraLabel115.AutoSize = True
        Me.UltraLabel115.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UltraLabel115.Location = New System.Drawing.Point(309, 144)
        Me.UltraLabel115.Name = "UltraLabel115"
        Me.UltraLabel115.Size = New System.Drawing.Size(13, 17)
        Me.UltraLabel115.TabIndex = 139
        Me.UltraLabel115.Text = "%"
        '
        'UltraLabel114
        '
        Me.UltraLabel114.AutoSize = True
        Me.UltraLabel114.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UltraLabel114.Location = New System.Drawing.Point(309, 176)
        Me.UltraLabel114.Name = "UltraLabel114"
        Me.UltraLabel114.Size = New System.Drawing.Size(13, 17)
        Me.UltraLabel114.TabIndex = 138
        Me.UltraLabel114.Text = "%"
        '
        'UltraLabel113
        '
        Me.UltraLabel113.AutoSize = True
        Me.UltraLabel113.Location = New System.Drawing.Point(134, 173)
        Me.UltraLabel113.Name = "UltraLabel113"
        Me.UltraLabel113.Size = New System.Drawing.Size(84, 19)
        Me.UltraLabel113.TabIndex = 137
        Me.UltraLabel113.Text = "Centre offset:"
        '
        'txtCentreOffset
        '
        Me.txtCentreOffset.Location = New System.Drawing.Point(224, 170)
        Me.txtCentreOffset.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtCentreOffset.MaxLength = 20
        Me.txtCentreOffset.Name = "txtCentreOffset"
        Me.txtCentreOffset.Size = New System.Drawing.Size(82, 24)
        Me.txtCentreOffset.TabIndex = 136
        Me.txtCentreOffset.Text = "100"
        Me.txtCentreOffset.UseAppStyling = False
        Me.txtCentreOffset.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'UltraLabel112
        '
        Me.UltraLabel112.AutoSize = True
        Me.UltraLabel112.Location = New System.Drawing.Point(142, 141)
        Me.UltraLabel112.Name = "UltraLabel112"
        Me.UltraLabel112.Size = New System.Drawing.Size(76, 19)
        Me.UltraLabel112.TabIndex = 135
        Me.UltraLabel112.Text = "Right offset:"
        '
        'txtRightOffset
        '
        Me.txtRightOffset.Location = New System.Drawing.Point(224, 138)
        Me.txtRightOffset.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtRightOffset.MaxLength = 20
        Me.txtRightOffset.Name = "txtRightOffset"
        Me.txtRightOffset.Size = New System.Drawing.Size(82, 24)
        Me.txtRightOffset.TabIndex = 134
        Me.txtRightOffset.Text = "90"
        Me.txtRightOffset.UseAppStyling = False
        Me.txtRightOffset.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'UltraLabel109
        '
        Me.UltraLabel109.AutoSize = True
        Me.UltraLabel109.Location = New System.Drawing.Point(140, 109)
        Me.UltraLabel109.Name = "UltraLabel109"
        Me.UltraLabel109.Size = New System.Drawing.Size(78, 19)
        Me.UltraLabel109.TabIndex = 133
        Me.UltraLabel109.Text = "Paper width:"
        '
        'txtPaperWidth
        '
        Me.txtPaperWidth.Location = New System.Drawing.Point(224, 106)
        Me.txtPaperWidth.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtPaperWidth.MaxLength = 20
        Me.txtPaperWidth.Name = "txtPaperWidth"
        Me.txtPaperWidth.Size = New System.Drawing.Size(82, 24)
        Me.txtPaperWidth.TabIndex = 132
        Me.txtPaperWidth.Text = "280"
        Me.txtPaperWidth.UseAppStyling = False
        Me.txtPaperWidth.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'UltraLabel105
        '
        Me.UltraLabel105.AutoSize = True
        Me.UltraLabel105.Location = New System.Drawing.Point(21, 423)
        Me.UltraLabel105.Name = "UltraLabel105"
        Me.UltraLabel105.Size = New System.Drawing.Size(143, 19)
        Me.UltraLabel105.TabIndex = 131
        Me.UltraLabel105.Text = "Text on kitchen header:"
        '
        'txtKitchenHeaderText
        '
        Me.txtKitchenHeaderText.Location = New System.Drawing.Point(169, 420)
        Me.txtKitchenHeaderText.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtKitchenHeaderText.MaxLength = 20
        Me.txtKitchenHeaderText.Name = "txtKitchenHeaderText"
        Me.txtKitchenHeaderText.Size = New System.Drawing.Size(207, 24)
        Me.txtKitchenHeaderText.TabIndex = 130
        Me.txtKitchenHeaderText.Text = "Kitchen Copy"
        Me.txtKitchenHeaderText.UseAppStyling = False
        Me.txtKitchenHeaderText.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'UltraLabel100
        '
        Me.UltraLabel100.AutoSize = True
        Me.UltraLabel100.Location = New System.Drawing.Point(35, 391)
        Me.UltraLabel100.Name = "UltraLabel100"
        Me.UltraLabel100.Size = New System.Drawing.Size(129, 19)
        Me.UltraLabel100.TabIndex = 129
        Me.UltraLabel100.Text = "Kitchen address font:"
        '
        'cmbFontSizeKitchenAddress
        '
        Me.cmbFontSizeKitchenAddress.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList
        Me.cmbFontSizeKitchenAddress.Location = New System.Drawing.Point(169, 387)
        Me.cmbFontSizeKitchenAddress.Name = "cmbFontSizeKitchenAddress"
        Me.cmbFontSizeKitchenAddress.Size = New System.Drawing.Size(82, 26)
        Me.cmbFontSizeKitchenAddress.TabIndex = 128
        '
        'UltraLabel99
        '
        Me.UltraLabel99.AutoSize = True
        Me.UltraLabel99.Location = New System.Drawing.Point(44, 358)
        Me.UltraLabel99.Name = "UltraLabel99"
        Me.UltraLabel99.Size = New System.Drawing.Size(120, 19)
        Me.UltraLabel99.TabIndex = 125
        Me.UltraLabel99.Text = "Kitchen dishes font:"
        '
        'cmbFontSizeKitchen
        '
        Me.cmbFontSizeKitchen.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList
        Me.cmbFontSizeKitchen.Location = New System.Drawing.Point(169, 354)
        Me.cmbFontSizeKitchen.Name = "cmbFontSizeKitchen"
        Me.cmbFontSizeKitchen.Size = New System.Drawing.Size(82, 26)
        Me.cmbFontSizeKitchen.TabIndex = 124
        '
        'UltraLabel98
        '
        Me.UltraLabel98.AutoSize = True
        Me.UltraLabel98.Location = New System.Drawing.Point(72, 325)
        Me.UltraLabel98.Name = "UltraLabel98"
        Me.UltraLabel98.Size = New System.Drawing.Size(92, 19)
        Me.UltraLabel98.TabIndex = 123
        Me.UltraLabel98.Text = "Shop font size:"
        '
        'cmbFontSizeShop
        '
        Me.cmbFontSizeShop.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList
        Me.cmbFontSizeShop.Location = New System.Drawing.Point(169, 321)
        Me.cmbFontSizeShop.Name = "cmbFontSizeShop"
        Me.cmbFontSizeShop.Size = New System.Drawing.Size(82, 26)
        Me.cmbFontSizeShop.TabIndex = 122
        '
        'txtKitchenTopOffset
        '
        Me.txtKitchenTopOffset.Location = New System.Drawing.Point(340, 226)
        Me.txtKitchenTopOffset.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtKitchenTopOffset.MaxLength = 2
        Me.txtKitchenTopOffset.Name = "txtKitchenTopOffset"
        Me.txtKitchenTopOffset.Size = New System.Drawing.Size(40, 24)
        Me.txtKitchenTopOffset.TabIndex = 121
        Me.txtKitchenTopOffset.Text = "1"
        Me.txtKitchenTopOffset.UseAppStyling = False
        Me.txtKitchenTopOffset.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'UltraLabel92
        '
        Me.UltraLabel92.AutoSize = True
        Me.UltraLabel92.Location = New System.Drawing.Point(283, 229)
        Me.UltraLabel92.Name = "UltraLabel92"
        Me.UltraLabel92.Size = New System.Drawing.Size(51, 19)
        Me.UltraLabel92.TabIndex = 120
        Me.UltraLabel92.Text = "kitchen:"
        '
        'UltraLabel93
        '
        Me.UltraLabel93.AutoSize = True
        Me.UltraLabel93.Location = New System.Drawing.Point(181, 229)
        Me.UltraLabel93.Name = "UltraLabel93"
        Me.UltraLabel93.Size = New System.Drawing.Size(37, 19)
        Me.UltraLabel93.TabIndex = 119
        Me.UltraLabel93.Text = "shop:"
        '
        'UltraLabel84
        '
        Me.UltraLabel84.AutoSize = True
        Me.UltraLabel84.Location = New System.Drawing.Point(283, 261)
        Me.UltraLabel84.Name = "UltraLabel84"
        Me.UltraLabel84.Size = New System.Drawing.Size(51, 19)
        Me.UltraLabel84.TabIndex = 118
        Me.UltraLabel84.Text = "kitchen:"
        '
        'UltraLabel81
        '
        Me.UltraLabel81.AutoSize = True
        Me.UltraLabel81.Location = New System.Drawing.Point(181, 261)
        Me.UltraLabel81.Name = "UltraLabel81"
        Me.UltraLabel81.Size = New System.Drawing.Size(37, 19)
        Me.UltraLabel81.TabIndex = 117
        Me.UltraLabel81.Text = "shop:"
        '
        'txtMinPaperLengthKitchen
        '
        Me.txtMinPaperLengthKitchen.Location = New System.Drawing.Point(340, 258)
        Me.txtMinPaperLengthKitchen.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtMinPaperLengthKitchen.MaxLength = 2
        Me.txtMinPaperLengthKitchen.Name = "txtMinPaperLengthKitchen"
        Me.txtMinPaperLengthKitchen.Size = New System.Drawing.Size(40, 24)
        Me.txtMinPaperLengthKitchen.TabIndex = 116
        Me.txtMinPaperLengthKitchen.Text = "1"
        Me.txtMinPaperLengthKitchen.UseAppStyling = False
        Me.txtMinPaperLengthKitchen.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'UltraLabel80
        '
        Me.UltraLabel80.AutoSize = True
        Me.UltraLabel80.Location = New System.Drawing.Point(25, 261)
        Me.UltraLabel80.Name = "UltraLabel80"
        Me.UltraLabel80.Size = New System.Drawing.Size(149, 19)
        Me.UltraLabel80.TabIndex = 115
        Me.UltraLabel80.Text = "Min paper length (1-20):"
        '
        'txtMinPaperLengthShop
        '
        Me.txtMinPaperLengthShop.Location = New System.Drawing.Point(224, 258)
        Me.txtMinPaperLengthShop.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtMinPaperLengthShop.MaxLength = 2
        Me.txtMinPaperLengthShop.Name = "txtMinPaperLengthShop"
        Me.txtMinPaperLengthShop.Size = New System.Drawing.Size(40, 24)
        Me.txtMinPaperLengthShop.TabIndex = 114
        Me.txtMinPaperLengthShop.Text = "10"
        Me.txtMinPaperLengthShop.UseAppStyling = False
        Me.txtMinPaperLengthShop.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'UltraLabel77
        '
        Me.UltraLabel77.AutoSize = True
        Me.UltraLabel77.Location = New System.Drawing.Point(93, 229)
        Me.UltraLabel77.Name = "UltraLabel77"
        Me.UltraLabel77.Size = New System.Drawing.Size(82, 19)
        Me.UltraLabel77.TabIndex = 113
        Me.UltraLabel77.Text = "Top margins:"
        '
        'txtShopTopOffset
        '
        Me.txtShopTopOffset.Location = New System.Drawing.Point(224, 226)
        Me.txtShopTopOffset.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtShopTopOffset.MaxLength = 3
        Me.txtShopTopOffset.Name = "txtShopTopOffset"
        Me.txtShopTopOffset.Size = New System.Drawing.Size(40, 24)
        Me.txtShopTopOffset.TabIndex = 112
        Me.txtShopTopOffset.Text = "40"
        Me.txtShopTopOffset.UseAppStyling = False
        Me.txtShopTopOffset.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'UltraLabel27
        '
        Me.UltraLabel27.AutoSize = True
        Me.UltraLabel27.Location = New System.Drawing.Point(78, 77)
        Me.UltraLabel27.Name = "UltraLabel27"
        Me.UltraLabel27.Size = New System.Drawing.Size(140, 19)
        Me.UltraLabel27.TabIndex = 111
        Me.UltraLabel27.Text = "Drinks label on receipt:"
        '
        'txtDrinksLabel
        '
        Me.txtDrinksLabel.Location = New System.Drawing.Point(224, 74)
        Me.txtDrinksLabel.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtDrinksLabel.MaxLength = 20
        Me.txtDrinksLabel.Name = "txtDrinksLabel"
        Me.txtDrinksLabel.Size = New System.Drawing.Size(82, 24)
        Me.txtDrinksLabel.TabIndex = 110
        Me.txtDrinksLabel.Text = "Drinks"
        Me.txtDrinksLabel.UseAppStyling = False
        Me.txtDrinksLabel.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'UltraLabel26
        '
        Me.UltraLabel26.AutoSize = True
        Me.UltraLabel26.Location = New System.Drawing.Point(85, 44)
        Me.UltraLabel26.Name = "UltraLabel26"
        Me.UltraLabel26.Size = New System.Drawing.Size(133, 19)
        Me.UltraLabel26.TabIndex = 109
        Me.UltraLabel26.Text = "Food label on receipt:"
        '
        'txtFoodLabel
        '
        Me.txtFoodLabel.Location = New System.Drawing.Point(224, 41)
        Me.txtFoodLabel.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtFoodLabel.MaxLength = 20
        Me.txtFoodLabel.Name = "txtFoodLabel"
        Me.txtFoodLabel.Size = New System.Drawing.Size(82, 24)
        Me.txtFoodLabel.TabIndex = 108
        Me.txtFoodLabel.Text = "Food"
        Me.txtFoodLabel.UseAppStyling = False
        Me.txtFoodLabel.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'UltraLabel111
        '
        Me.UltraLabel111.AutoSize = True
        Me.UltraLabel111.Location = New System.Drawing.Point(270, 358)
        Me.UltraLabel111.Name = "UltraLabel111"
        Me.UltraLabel111.Size = New System.Drawing.Size(90, 19)
        Me.UltraLabel111.TabIndex = 107
        Me.UltraLabel111.Text = "'Paid' location:"
        '
        'cmbPaidLocation
        '
        Me.cmbPaidLocation.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList
        ValueListItem14.DataValue = "ValueListItem0"
        ValueListItem14.DisplayText = "Left"
        ValueListItem15.DataValue = "ValueListItem1"
        ValueListItem15.DisplayText = "Centre"
        ValueListItem16.DataValue = "ValueListItem2"
        ValueListItem16.DisplayText = "Right"
        Me.cmbPaidLocation.Items.AddRange(New Infragistics.Win.ValueListItem() {ValueListItem14, ValueListItem15, ValueListItem16})
        Me.cmbPaidLocation.Location = New System.Drawing.Point(368, 354)
        Me.cmbPaidLocation.Name = "cmbPaidLocation"
        Me.cmbPaidLocation.Size = New System.Drawing.Size(82, 26)
        Me.cmbPaidLocation.TabIndex = 106
        '
        'UltraLabel110
        '
        Me.UltraLabel110.AutoSize = True
        Me.UltraLabel110.Location = New System.Drawing.Point(270, 325)
        Me.UltraLabel110.Name = "UltraLabel110"
        Me.UltraLabel110.Size = New System.Drawing.Size(93, 19)
        Me.UltraLabel110.TabIndex = 105
        Me.UltraLabel110.Text = "'Paid' font size:"
        '
        'cmbPaidFontSize
        '
        Me.cmbPaidFontSize.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList
        Me.cmbPaidFontSize.Location = New System.Drawing.Point(368, 321)
        Me.cmbPaidFontSize.Name = "cmbPaidFontSize"
        Me.cmbPaidFontSize.Size = New System.Drawing.Size(82, 26)
        Me.cmbPaidFontSize.TabIndex = 104
        '
        'UltraTabPageControl19
        '
        Me.UltraTabPageControl19.Controls.Add(Me.UltraGroupBox20)
        Me.UltraTabPageControl19.Location = New System.Drawing.Point(-10000, -10000)
        Me.UltraTabPageControl19.Name = "UltraTabPageControl19"
        Me.UltraTabPageControl19.Size = New System.Drawing.Size(546, 602)
        '
        'UltraGroupBox20
        '
        Appearance84.BackColor = System.Drawing.Color.Transparent
        Me.UltraGroupBox20.Appearance = Appearance84
        Me.UltraGroupBox20.Controls.Add(Me.chkServiceCharge)
        Me.UltraGroupBox20.Controls.Add(Me.ucpTStatus)
        Me.UltraGroupBox20.Controls.Add(Me.UltraLabel107)
        Me.UltraGroupBox20.Controls.Add(Me.lstTStatus)
        Me.UltraGroupBox20.Controls.Add(Me.cmdAddTStatus)
        Me.UltraGroupBox20.Controls.Add(Me.txtTStatus)
        Me.UltraGroupBox20.Controls.Add(Me.cmdDeleteTStatus)
        Me.UltraGroupBox20.Controls.Add(Me.cmbNumTables)
        Me.UltraGroupBox20.Controls.Add(Me.UltraLabel11)
        Me.UltraGroupBox20.Controls.Add(Me.chkTableAutoCovers)
        Me.UltraGroupBox20.Controls.Add(Me.chkTableExtLights)
        Me.UltraGroupBox20.Controls.Add(Me.chkTableExtSave)
        Me.UltraGroupBox20.Controls.Add(Me.chkTableExtDelete)
        Me.UltraGroupBox20.Controls.Add(Me.txtTableExtLine3)
        Me.UltraGroupBox20.Controls.Add(Me.txtTableExtLine2)
        Me.UltraGroupBox20.Controls.Add(Me.txtTableExtLine1)
        Me.UltraGroupBox20.Controls.Add(Me.UltraLabel101)
        Me.UltraGroupBox20.Controls.Add(Me.UltraLabel102)
        Me.UltraGroupBox20.Controls.Add(Me.UltraLabel103)
        Me.UltraGroupBox20.Controls.Add(Me.chkTableExtMode)
        Me.UltraGroupBox20.Location = New System.Drawing.Point(38, 11)
        Me.UltraGroupBox20.Name = "UltraGroupBox20"
        Me.UltraGroupBox20.Size = New System.Drawing.Size(470, 576)
        Me.UltraGroupBox20.TabIndex = 17
        Me.UltraGroupBox20.Text = "Tables"
        '
        'chkServiceCharge
        '
        Appearance85.FontData.Name = "Segoe UI"
        Appearance85.FontData.SizeInPoints = 10.0!
        Me.chkServiceCharge.Appearance = Appearance85
        Me.chkServiceCharge.AutoSize = True
        Me.chkServiceCharge.BackColor = System.Drawing.Color.Transparent
        Me.chkServiceCharge.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkServiceCharge.Location = New System.Drawing.Point(36, 105)
        Me.chkServiceCharge.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkServiceCharge.Name = "chkServiceCharge"
        Me.chkServiceCharge.Size = New System.Drawing.Size(280, 23)
        Me.chkServiceCharge.TabIndex = 55
        Me.chkServiceCharge.Text = "Print 'Service Charge Not Included' on bills"
        '
        'ucpTStatus
        '
        Me.ucpTStatus.Location = New System.Drawing.Point(73, 340)
        Me.ucpTStatus.Name = "ucpTStatus"
        Me.ucpTStatus.Size = New System.Drawing.Size(265, 26)
        Me.ucpTStatus.TabIndex = 63
        Me.ucpTStatus.Text = "Control"
        '
        'UltraLabel107
        '
        Me.UltraLabel107.AutoSize = True
        Me.UltraLabel107.Location = New System.Drawing.Point(75, 283)
        Me.UltraLabel107.Name = "UltraLabel107"
        Me.UltraLabel107.Size = New System.Drawing.Size(78, 19)
        Me.UltraLabel107.TabIndex = 130
        Me.UltraLabel107.Text = "Table status:"
        '
        'lstTStatus
        '
        Me.lstTStatus.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Me.lstTStatus.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstTStatus.ItemSettings.AllowEdit = Infragistics.Win.DefaultableBoolean.[False]
        Me.lstTStatus.ItemSettings.HideSelection = False
        Me.lstTStatus.ItemSettings.HotTracking = True
        Me.lstTStatus.Location = New System.Drawing.Point(73, 374)
        Me.lstTStatus.Name = "lstTStatus"
        Me.lstTStatus.ShowGroups = False
        Me.lstTStatus.Size = New System.Drawing.Size(265, 186)
        Me.lstTStatus.TabIndex = 64
        Me.lstTStatus.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        Me.lstTStatus.View = Infragistics.Win.UltraWinListView.UltraListViewStyle.List
        Me.lstTStatus.ViewSettingsList.ImageSize = New System.Drawing.Size(0, 0)
        Me.lstTStatus.ViewSettingsList.MultiColumn = False
        '
        'cmdAddTStatus
        '
        Me.cmdAddTStatus.Location = New System.Drawing.Point(346, 374)
        Me.cmdAddTStatus.Name = "cmdAddTStatus"
        Me.cmdAddTStatus.ShowFocusRect = False
        Me.cmdAddTStatus.ShowOutline = False
        Me.cmdAddTStatus.Size = New System.Drawing.Size(75, 26)
        Me.cmdAddTStatus.TabIndex = 65
        Me.cmdAddTStatus.Text = "Add"
        '
        'txtTStatus
        '
        Me.txtTStatus.Location = New System.Drawing.Point(73, 309)
        Me.txtTStatus.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtTStatus.Name = "txtTStatus"
        Me.txtTStatus.Size = New System.Drawing.Size(265, 24)
        Me.txtTStatus.TabIndex = 62
        Me.txtTStatus.UseAppStyling = False
        Me.txtTStatus.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'cmdDeleteTStatus
        '
        Me.cmdDeleteTStatus.Location = New System.Drawing.Point(346, 407)
        Me.cmdDeleteTStatus.Name = "cmdDeleteTStatus"
        Me.cmdDeleteTStatus.ShowFocusRect = False
        Me.cmdDeleteTStatus.ShowOutline = False
        Me.cmdDeleteTStatus.Size = New System.Drawing.Size(75, 26)
        Me.cmdDeleteTStatus.TabIndex = 66
        Me.cmdDeleteTStatus.Text = "Delete"
        '
        'cmbNumTables
        '
        Me.cmbNumTables.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList
        ValueListItem3.DataValue = "ValueListItem0"
        ValueListItem3.DisplayText = "12"
        ValueListItem17.DataValue = "ValueListItem3"
        ValueListItem17.DisplayText = "16"
        ValueListItem4.DataValue = "ValueListItem1"
        ValueListItem4.DisplayText = "20"
        ValueListItem22.DataValue = "ValueListItem2"
        ValueListItem22.DisplayText = "28"
        Me.cmbNumTables.Items.AddRange(New Infragistics.Win.ValueListItem() {ValueListItem3, ValueListItem17, ValueListItem4, ValueListItem22})
        Me.cmbNumTables.Location = New System.Drawing.Point(374, 41)
        Me.cmbNumTables.Name = "cmbNumTables"
        Me.cmbNumTables.Size = New System.Drawing.Size(71, 26)
        Me.cmbNumTables.TabIndex = 56
        '
        'UltraLabel11
        '
        Me.UltraLabel11.AutoSize = True
        Me.UltraLabel11.Location = New System.Drawing.Point(257, 45)
        Me.UltraLabel11.Name = "UltraLabel11"
        Me.UltraLabel11.Size = New System.Drawing.Size(111, 19)
        Me.UltraLabel11.TabIndex = 107
        Me.UltraLabel11.Text = "Number of tables:"
        '
        'chkTableAutoCovers
        '
        Appearance86.FontData.Name = "Segoe UI"
        Appearance86.FontData.SizeInPoints = 10.0!
        Me.chkTableAutoCovers.Appearance = Appearance86
        Me.chkTableAutoCovers.BackColor = System.Drawing.Color.Transparent
        Me.chkTableAutoCovers.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkTableAutoCovers.Location = New System.Drawing.Point(36, 85)
        Me.chkTableAutoCovers.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkTableAutoCovers.Name = "chkTableAutoCovers"
        Me.chkTableAutoCovers.Size = New System.Drawing.Size(207, 20)
        Me.chkTableAutoCovers.TabIndex = 54
        Me.chkTableAutoCovers.Text = "Auto display covers popup"
        '
        'chkTableExtLights
        '
        Appearance87.FontData.Name = "Segoe UI"
        Appearance87.FontData.SizeInPoints = 10.0!
        Me.chkTableExtLights.Appearance = Appearance87
        Me.chkTableExtLights.BackColor = System.Drawing.Color.Transparent
        Me.chkTableExtLights.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkTableExtLights.Location = New System.Drawing.Point(36, 65)
        Me.chkTableExtLights.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkTableExtLights.Name = "chkTableExtLights"
        Me.chkTableExtLights.Size = New System.Drawing.Size(207, 20)
        Me.chkTableExtLights.TabIndex = 53
        Me.chkTableExtLights.Text = "Enable 'lights'"
        '
        'chkTableExtSave
        '
        Me.chkTableExtSave.Location = New System.Drawing.Point(344, 160)
        Me.chkTableExtSave.Name = "chkTableExtSave"
        Me.chkTableExtSave.ShowFocusRect = False
        Me.chkTableExtSave.ShowOutline = False
        Me.chkTableExtSave.Size = New System.Drawing.Size(75, 26)
        Me.chkTableExtSave.TabIndex = 60
        Me.chkTableExtSave.Text = "Save"
        '
        'chkTableExtDelete
        '
        Me.chkTableExtDelete.Location = New System.Drawing.Point(344, 192)
        Me.chkTableExtDelete.Name = "chkTableExtDelete"
        Me.chkTableExtDelete.ShowFocusRect = False
        Me.chkTableExtDelete.ShowOutline = False
        Me.chkTableExtDelete.Size = New System.Drawing.Size(75, 26)
        Me.chkTableExtDelete.TabIndex = 61
        Me.chkTableExtDelete.Text = "Delete"
        '
        'txtTableExtLine3
        '
        Me.txtTableExtLine3.Location = New System.Drawing.Point(73, 225)
        Me.txtTableExtLine3.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtTableExtLine3.Name = "txtTableExtLine3"
        Me.txtTableExtLine3.Size = New System.Drawing.Size(265, 24)
        Me.txtTableExtLine3.TabIndex = 59
        Me.txtTableExtLine3.UseAppStyling = False
        Me.txtTableExtLine3.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'txtTableExtLine2
        '
        Me.txtTableExtLine2.Location = New System.Drawing.Point(73, 193)
        Me.txtTableExtLine2.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtTableExtLine2.Name = "txtTableExtLine2"
        Me.txtTableExtLine2.Size = New System.Drawing.Size(265, 24)
        Me.txtTableExtLine2.TabIndex = 58
        Me.txtTableExtLine2.UseAppStyling = False
        Me.txtTableExtLine2.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'txtTableExtLine1
        '
        Me.txtTableExtLine1.Location = New System.Drawing.Point(73, 161)
        Me.txtTableExtLine1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtTableExtLine1.Name = "txtTableExtLine1"
        Me.txtTableExtLine1.Size = New System.Drawing.Size(265, 24)
        Me.txtTableExtLine1.TabIndex = 57
        Me.txtTableExtLine1.UseAppStyling = False
        Me.txtTableExtLine1.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'UltraLabel101
        '
        Me.UltraLabel101.AutoSize = True
        Me.UltraLabel101.Location = New System.Drawing.Point(52, 235)
        Me.UltraLabel101.Name = "UltraLabel101"
        Me.UltraLabel101.Size = New System.Drawing.Size(15, 19)
        Me.UltraLabel101.TabIndex = 99
        Me.UltraLabel101.Text = "3."
        '
        'UltraLabel102
        '
        Me.UltraLabel102.AutoSize = True
        Me.UltraLabel102.Location = New System.Drawing.Point(52, 203)
        Me.UltraLabel102.Name = "UltraLabel102"
        Me.UltraLabel102.Size = New System.Drawing.Size(15, 19)
        Me.UltraLabel102.TabIndex = 98
        Me.UltraLabel102.Text = "2."
        '
        'UltraLabel103
        '
        Me.UltraLabel103.AutoSize = True
        Me.UltraLabel103.Location = New System.Drawing.Point(52, 171)
        Me.UltraLabel103.Name = "UltraLabel103"
        Me.UltraLabel103.Size = New System.Drawing.Size(15, 19)
        Me.UltraLabel103.TabIndex = 97
        Me.UltraLabel103.Text = "1."
        '
        'chkTableExtMode
        '
        Appearance88.FontData.Name = "Segoe UI"
        Appearance88.FontData.SizeInPoints = 10.0!
        Me.chkTableExtMode.Appearance = Appearance88
        Me.chkTableExtMode.BackColor = System.Drawing.Color.Transparent
        Me.chkTableExtMode.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkTableExtMode.Location = New System.Drawing.Point(36, 45)
        Me.chkTableExtMode.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkTableExtMode.Name = "chkTableExtMode"
        Me.chkTableExtMode.Size = New System.Drawing.Size(207, 20)
        Me.chkTableExtMode.TabIndex = 52
        Me.chkTableExtMode.Text = "Use Extended Tables Mode"
        '
        'UltraTabPageControl20
        '
        Me.UltraTabPageControl20.Controls.Add(Me.UltraGroupBox21)
        Me.UltraTabPageControl20.Location = New System.Drawing.Point(-10000, -10000)
        Me.UltraTabPageControl20.Name = "UltraTabPageControl20"
        Me.UltraTabPageControl20.Size = New System.Drawing.Size(546, 602)
        '
        'UltraGroupBox21
        '
        Appearance89.BackColor = System.Drawing.Color.Transparent
        Me.UltraGroupBox21.Appearance = Appearance89
        Me.UltraGroupBox21.Controls.Add(Me.chkSummaryCDTTotals)
        Me.UltraGroupBox21.Controls.Add(Me.chkSummaryPrintDate)
        Me.UltraGroupBox21.Location = New System.Drawing.Point(38, 11)
        Me.UltraGroupBox21.Name = "UltraGroupBox21"
        Me.UltraGroupBox21.Size = New System.Drawing.Size(470, 430)
        Me.UltraGroupBox21.TabIndex = 21
        Me.UltraGroupBox21.Text = "Summary"
        '
        'chkSummaryCDTTotals
        '
        Appearance90.FontData.Name = "Segoe UI"
        Appearance90.FontData.SizeInPoints = 10.0!
        Me.chkSummaryCDTTotals.Appearance = Appearance90
        Me.chkSummaryCDTTotals.BackColor = System.Drawing.Color.Transparent
        Me.chkSummaryCDTTotals.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkSummaryCDTTotals.Location = New System.Drawing.Point(37, 60)
        Me.chkSummaryCDTTotals.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkSummaryCDTTotals.Name = "chkSummaryCDTTotals"
        Me.chkSummaryCDTTotals.Size = New System.Drawing.Size(349, 26)
        Me.chkSummaryCDTTotals.TabIndex = 79
        Me.chkSummaryCDTTotals.Text = "Print collection, delivery and table totals"
        '
        'chkSummaryPrintDate
        '
        Appearance91.FontData.Name = "Segoe UI"
        Appearance91.FontData.SizeInPoints = 10.0!
        Me.chkSummaryPrintDate.Appearance = Appearance91
        Me.chkSummaryPrintDate.BackColor = System.Drawing.Color.Transparent
        Me.chkSummaryPrintDate.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkSummaryPrintDate.Location = New System.Drawing.Point(37, 40)
        Me.chkSummaryPrintDate.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkSummaryPrintDate.Name = "chkSummaryPrintDate"
        Me.chkSummaryPrintDate.Size = New System.Drawing.Size(349, 26)
        Me.chkSummaryPrintDate.TabIndex = 78
        Me.chkSummaryPrintDate.Text = "Print date and time on summary"
        '
        'UltraTabPageControl12
        '
        Me.UltraTabPageControl12.Controls.Add(Me.UltraGroupBox15)
        Me.UltraTabPageControl12.Location = New System.Drawing.Point(-10000, -10000)
        Me.UltraTabPageControl12.Name = "UltraTabPageControl12"
        Me.UltraTabPageControl12.Size = New System.Drawing.Size(546, 602)
        '
        'UltraGroupBox15
        '
        Appearance92.BackColor = System.Drawing.Color.Transparent
        Me.UltraGroupBox15.Appearance = Appearance92
        Me.UltraGroupBox15.Controls.Add(Me.chkXClearOnExit)
        Me.UltraGroupBox15.Controls.Add(Me.chkRequireLogon)
        Me.UltraGroupBox15.Controls.Add(Me.chkXClearOrders)
        Me.UltraGroupBox15.Controls.Add(Me.cmdShowPassword)
        Me.UltraGroupBox15.Controls.Add(Me.chkXAccessBanking)
        Me.UltraGroupBox15.Controls.Add(Me.chkXAccessSummary)
        Me.UltraGroupBox15.Controls.Add(Me.chkXOrderTotals)
        Me.UltraGroupBox15.Controls.Add(Me.chkXAccessManager)
        Me.UltraGroupBox15.Controls.Add(Me.chkXOrderReprint)
        Me.UltraGroupBox15.Controls.Add(Me.chkXOrderEdit)
        Me.UltraGroupBox15.Controls.Add(Me.chkXOrderDelete)
        Me.UltraGroupBox15.Controls.Add(Me.chkXOrders)
        Me.UltraGroupBox15.Controls.Add(Me.UltraLabel25)
        Me.UltraGroupBox15.Controls.Add(Me.UltraLabel73)
        Me.UltraGroupBox15.Controls.Add(Me.cmdSetSupervisorPassword)
        Me.UltraGroupBox15.Controls.Add(Me.UltraLabel74)
        Me.UltraGroupBox15.Controls.Add(Me.UltraLabel75)
        Me.UltraGroupBox15.Controls.Add(Me.UltraLabel76)
        Me.UltraGroupBox15.Controls.Add(Me.txtSPConfirm)
        Me.UltraGroupBox15.Controls.Add(Me.txtSPNew)
        Me.UltraGroupBox15.Controls.Add(Me.txtSPOld)
        Me.UltraGroupBox15.Location = New System.Drawing.Point(38, 11)
        Me.UltraGroupBox15.Name = "UltraGroupBox15"
        Me.UltraGroupBox15.Size = New System.Drawing.Size(470, 562)
        Me.UltraGroupBox15.TabIndex = 19
        Me.UltraGroupBox15.Text = "Manager"
        '
        'chkXClearOnExit
        '
        Appearance93.FontData.Name = "Segoe UI"
        Appearance93.FontData.SizeInPoints = 10.0!
        Me.chkXClearOnExit.Appearance = Appearance93
        Me.chkXClearOnExit.BackColor = System.Drawing.Color.Transparent
        Me.chkXClearOnExit.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkXClearOnExit.Location = New System.Drawing.Point(88, 311)
        Me.chkXClearOnExit.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkXClearOnExit.Name = "chkXClearOnExit"
        Me.chkXClearOnExit.Size = New System.Drawing.Size(278, 26)
        Me.chkXClearOnExit.TabIndex = 85
        Me.chkXClearOnExit.Text = "Clear orders on exit"
        '
        'chkRequireLogon
        '
        Appearance94.FontData.Name = "Segoe UI"
        Appearance94.FontData.SizeInPoints = 10.0!
        Me.chkRequireLogon.Appearance = Appearance94
        Me.chkRequireLogon.AutoSize = True
        Me.chkRequireLogon.BackColor = System.Drawing.Color.Transparent
        Me.chkRequireLogon.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkRequireLogon.Location = New System.Drawing.Point(47, 35)
        Me.chkRequireLogon.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkRequireLogon.Name = "chkRequireLogon"
        Me.chkRequireLogon.Size = New System.Drawing.Size(163, 23)
        Me.chkRequireLogon.TabIndex = 84
        Me.chkRequireLogon.Text = "Require users to log on"
        '
        'chkXClearOrders
        '
        Appearance95.FontData.Name = "Segoe UI"
        Appearance95.FontData.SizeInPoints = 10.0!
        Me.chkXClearOrders.Appearance = Appearance95
        Me.chkXClearOrders.BackColor = System.Drawing.Color.Transparent
        Me.chkXClearOrders.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkXClearOrders.Location = New System.Drawing.Point(127, 163)
        Me.chkXClearOrders.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkXClearOrders.Name = "chkXClearOrders"
        Me.chkXClearOrders.Size = New System.Drawing.Size(189, 26)
        Me.chkXClearOrders.TabIndex = 83
        Me.chkXClearOrders.Text = "Clear today's orders"
        '
        'cmdShowPassword
        '
        Me.cmdShowPassword.Location = New System.Drawing.Point(295, 500)
        Me.cmdShowPassword.Name = "cmdShowPassword"
        Me.cmdShowPassword.ShowFocusRect = False
        Me.cmdShowPassword.ShowOutline = False
        Me.cmdShowPassword.Size = New System.Drawing.Size(80, 26)
        Me.cmdShowPassword.TabIndex = 82
        Me.cmdShowPassword.Text = "Reveal"
        '
        'chkXAccessBanking
        '
        Appearance96.FontData.Name = "Segoe UI"
        Appearance96.FontData.SizeInPoints = 10.0!
        Me.chkXAccessBanking.Appearance = Appearance96
        Me.chkXAccessBanking.BackColor = System.Drawing.Color.Transparent
        Me.chkXAccessBanking.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkXAccessBanking.Location = New System.Drawing.Point(127, 143)
        Me.chkXAccessBanking.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkXAccessBanking.Name = "chkXAccessBanking"
        Me.chkXAccessBanking.Size = New System.Drawing.Size(216, 26)
        Me.chkXAccessBanking.TabIndex = 81
        Me.chkXAccessBanking.Text = "Accessing Banking screen"
        '
        'chkXAccessSummary
        '
        Appearance97.FontData.Name = "Segoe UI"
        Appearance97.FontData.SizeInPoints = 10.0!
        Me.chkXAccessSummary.Appearance = Appearance97
        Me.chkXAccessSummary.BackColor = System.Drawing.Color.Transparent
        Me.chkXAccessSummary.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkXAccessSummary.Location = New System.Drawing.Point(127, 123)
        Me.chkXAccessSummary.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkXAccessSummary.Name = "chkXAccessSummary"
        Me.chkXAccessSummary.Size = New System.Drawing.Size(254, 26)
        Me.chkXAccessSummary.TabIndex = 80
        Me.chkXAccessSummary.Text = "Accessing Summary  screen"
        '
        'chkXOrderTotals
        '
        Appearance98.FontData.Name = "Segoe UI"
        Appearance98.FontData.SizeInPoints = 10.0!
        Me.chkXOrderTotals.Appearance = Appearance98
        Me.chkXOrderTotals.BackColor = System.Drawing.Color.Transparent
        Me.chkXOrderTotals.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkXOrderTotals.Location = New System.Drawing.Point(127, 277)
        Me.chkXOrderTotals.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkXOrderTotals.Name = "chkXOrderTotals"
        Me.chkXOrderTotals.Size = New System.Drawing.Size(189, 26)
        Me.chkXOrderTotals.TabIndex = 79
        Me.chkXOrderTotals.Text = "Order totals"
        '
        'chkXAccessManager
        '
        Appearance99.FontData.Name = "Segoe UI"
        Appearance99.FontData.SizeInPoints = 10.0!
        Me.chkXAccessManager.Appearance = Appearance99
        Me.chkXAccessManager.BackColor = System.Drawing.Color.Transparent
        Me.chkXAccessManager.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkXAccessManager.Location = New System.Drawing.Point(88, 103)
        Me.chkXAccessManager.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkXAccessManager.Name = "chkXAccessManager"
        Me.chkXAccessManager.Size = New System.Drawing.Size(189, 26)
        Me.chkXAccessManager.TabIndex = 78
        Me.chkXAccessManager.Text = "Accessing Manager screen"
        '
        'chkXOrderReprint
        '
        Appearance100.FontData.Name = "Segoe UI"
        Appearance100.FontData.SizeInPoints = 10.0!
        Me.chkXOrderReprint.Appearance = Appearance100
        Me.chkXOrderReprint.BackColor = System.Drawing.Color.Transparent
        Me.chkXOrderReprint.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkXOrderReprint.Location = New System.Drawing.Point(127, 257)
        Me.chkXOrderReprint.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkXOrderReprint.Name = "chkXOrderReprint"
        Me.chkXOrderReprint.Size = New System.Drawing.Size(189, 26)
        Me.chkXOrderReprint.TabIndex = 77
        Me.chkXOrderReprint.Text = "Reprint order"
        '
        'chkXOrderEdit
        '
        Appearance101.FontData.Name = "Segoe UI"
        Appearance101.FontData.SizeInPoints = 10.0!
        Me.chkXOrderEdit.Appearance = Appearance101
        Me.chkXOrderEdit.BackColor = System.Drawing.Color.Transparent
        Me.chkXOrderEdit.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkXOrderEdit.Location = New System.Drawing.Point(127, 237)
        Me.chkXOrderEdit.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkXOrderEdit.Name = "chkXOrderEdit"
        Me.chkXOrderEdit.Size = New System.Drawing.Size(189, 26)
        Me.chkXOrderEdit.TabIndex = 76
        Me.chkXOrderEdit.Text = "Edit order"
        '
        'chkXOrderDelete
        '
        Appearance102.FontData.Name = "Segoe UI"
        Appearance102.FontData.SizeInPoints = 10.0!
        Me.chkXOrderDelete.Appearance = Appearance102
        Me.chkXOrderDelete.BackColor = System.Drawing.Color.Transparent
        Me.chkXOrderDelete.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkXOrderDelete.Location = New System.Drawing.Point(127, 217)
        Me.chkXOrderDelete.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkXOrderDelete.Name = "chkXOrderDelete"
        Me.chkXOrderDelete.Size = New System.Drawing.Size(189, 26)
        Me.chkXOrderDelete.TabIndex = 75
        Me.chkXOrderDelete.Text = "Deleting order"
        '
        'chkXOrders
        '
        Appearance103.FontData.Name = "Segoe UI"
        Appearance103.FontData.SizeInPoints = 10.0!
        Me.chkXOrders.Appearance = Appearance103
        Me.chkXOrders.BackColor = System.Drawing.Color.Transparent
        Me.chkXOrders.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkXOrders.Location = New System.Drawing.Point(88, 197)
        Me.chkXOrders.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkXOrders.Name = "chkXOrders"
        Me.chkXOrders.Size = New System.Drawing.Size(189, 26)
        Me.chkXOrders.TabIndex = 74
        Me.chkXOrders.Text = "Accessing Orders screen"
        '
        'UltraLabel25
        '
        Me.UltraLabel25.AutoSize = True
        Me.UltraLabel25.Location = New System.Drawing.Point(47, 76)
        Me.UltraLabel25.Name = "UltraLabel25"
        Me.UltraLabel25.Size = New System.Drawing.Size(265, 19)
        Me.UltraLabel25.TabIndex = 73
        Me.UltraLabel25.Text = "Ask for manager password on the following:"
        '
        'UltraLabel73
        '
        Me.UltraLabel73.AutoSize = True
        Me.UltraLabel73.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UltraLabel73.Location = New System.Drawing.Point(88, 375)
        Me.UltraLabel73.Name = "UltraLabel73"
        Me.UltraLabel73.Size = New System.Drawing.Size(166, 19)
        Me.UltraLabel73.TabIndex = 71
        Me.UltraLabel73.Text = "Change manager password"
        '
        'cmdSetSupervisorPassword
        '
        Me.cmdSetSupervisorPassword.Location = New System.Drawing.Point(209, 500)
        Me.cmdSetSupervisorPassword.Name = "cmdSetSupervisorPassword"
        Me.cmdSetSupervisorPassword.ShowFocusRect = False
        Me.cmdSetSupervisorPassword.ShowOutline = False
        Me.cmdSetSupervisorPassword.Size = New System.Drawing.Size(80, 26)
        Me.cmdSetSupervisorPassword.TabIndex = 70
        Me.cmdSetSupervisorPassword.Text = "Set"
        '
        'UltraLabel74
        '
        Me.UltraLabel74.AutoSize = True
        Me.UltraLabel74.Location = New System.Drawing.Point(88, 473)
        Me.UltraLabel74.Name = "UltraLabel74"
        Me.UltraLabel74.Size = New System.Drawing.Size(108, 19)
        Me.UltraLabel74.TabIndex = 69
        Me.UltraLabel74.Text = "Retype password:"
        '
        'UltraLabel75
        '
        Me.UltraLabel75.AutoSize = True
        Me.UltraLabel75.Location = New System.Drawing.Point(101, 439)
        Me.UltraLabel75.Name = "UltraLabel75"
        Me.UltraLabel75.Size = New System.Drawing.Size(94, 19)
        Me.UltraLabel75.TabIndex = 68
        Me.UltraLabel75.Text = "New password:"
        '
        'UltraLabel76
        '
        Me.UltraLabel76.AutoSize = True
        Me.UltraLabel76.Location = New System.Drawing.Point(107, 405)
        Me.UltraLabel76.Name = "UltraLabel76"
        Me.UltraLabel76.Size = New System.Drawing.Size(89, 19)
        Me.UltraLabel76.TabIndex = 67
        Me.UltraLabel76.Text = "Old password:"
        '
        'txtSPConfirm
        '
        Me.txtSPConfirm.Location = New System.Drawing.Point(201, 469)
        Me.txtSPConfirm.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtSPConfirm.Name = "txtSPConfirm"
        Me.txtSPConfirm.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtSPConfirm.Size = New System.Drawing.Size(182, 24)
        Me.txtSPConfirm.TabIndex = 66
        Me.txtSPConfirm.UseAppStyling = False
        Me.txtSPConfirm.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'txtSPNew
        '
        Me.txtSPNew.Location = New System.Drawing.Point(201, 435)
        Me.txtSPNew.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtSPNew.Name = "txtSPNew"
        Me.txtSPNew.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtSPNew.Size = New System.Drawing.Size(182, 24)
        Me.txtSPNew.TabIndex = 65
        Me.txtSPNew.UseAppStyling = False
        Me.txtSPNew.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'txtSPOld
        '
        Me.txtSPOld.Location = New System.Drawing.Point(201, 401)
        Me.txtSPOld.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtSPOld.Name = "txtSPOld"
        Me.txtSPOld.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtSPOld.Size = New System.Drawing.Size(182, 24)
        Me.txtSPOld.TabIndex = 64
        Me.txtSPOld.UseAppStyling = False
        Me.txtSPOld.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'UltraTabPageControl15
        '
        Me.UltraTabPageControl15.Controls.Add(Me.UltraGroupBox17)
        Me.UltraTabPageControl15.Location = New System.Drawing.Point(-10000, -10000)
        Me.UltraTabPageControl15.Name = "UltraTabPageControl15"
        Me.UltraTabPageControl15.Size = New System.Drawing.Size(546, 602)
        '
        'UltraGroupBox17
        '
        Appearance104.BackColor = System.Drawing.Color.Transparent
        Me.UltraGroupBox17.Appearance = Appearance104
        Me.UltraGroupBox17.Controls.Add(Me.chkSetPutQty)
        Me.UltraGroupBox17.Location = New System.Drawing.Point(38, 11)
        Me.UltraGroupBox17.Name = "UltraGroupBox17"
        Me.UltraGroupBox17.Size = New System.Drawing.Size(470, 430)
        Me.UltraGroupBox17.TabIndex = 20
        Me.UltraGroupBox17.Text = "Set meals"
        '
        'chkSetPutQty
        '
        Appearance105.FontData.Name = "Segoe UI"
        Appearance105.FontData.SizeInPoints = 10.0!
        Me.chkSetPutQty.Appearance = Appearance105
        Me.chkSetPutQty.BackColor = System.Drawing.Color.Transparent
        Me.chkSetPutQty.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkSetPutQty.Location = New System.Drawing.Point(36, 45)
        Me.chkSetPutQty.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkSetPutQty.Name = "chkSetPutQty"
        Me.chkSetPutQty.Size = New System.Drawing.Size(349, 26)
        Me.chkSetPutQty.TabIndex = 78
        Me.chkSetPutQty.Text = "Put quantity next to set item"
        '
        'UltraTabPageControl14
        '
        Me.UltraTabPageControl14.Controls.Add(Me.UltraGroupBox16)
        Me.UltraTabPageControl14.Location = New System.Drawing.Point(137, 1)
        Me.UltraTabPageControl14.Name = "UltraTabPageControl14"
        Me.UltraTabPageControl14.Size = New System.Drawing.Size(546, 602)
        '
        'UltraGroupBox16
        '
        Appearance106.BackColor = System.Drawing.Color.Transparent
        Me.UltraGroupBox16.Appearance = Appearance106
        Me.UltraGroupBox16.Controls.Add(Me.UltraLabel50)
        Me.UltraGroupBox16.Controls.Add(Me.txtEmailFrequency)
        Me.UltraGroupBox16.Controls.Add(Me.cmdEmailReport)
        Me.UltraGroupBox16.Controls.Add(Me.chkEmailError)
        Me.UltraGroupBox16.Controls.Add(Me.chkShowOnlineTotals)
        Me.UltraGroupBox16.Controls.Add(Me.chkPrintPayPalID)
        Me.UltraGroupBox16.Controls.Add(Me.cmbBackupDay)
        Me.UltraGroupBox16.Controls.Add(Me.UltraLabel85)
        Me.UltraGroupBox16.Controls.Add(Me.chkBackupDBOnline)
        Me.UltraGroupBox16.Controls.Add(Me.chkEnableOnline)
        Me.UltraGroupBox16.Controls.Add(Me.UltraLabel59)
        Me.UltraGroupBox16.Controls.Add(Me.txtOLText)
        Me.UltraGroupBox16.Controls.Add(Me.lstOnline)
        Me.UltraGroupBox16.Controls.Add(Me.cmdAddOnline)
        Me.UltraGroupBox16.Controls.Add(Me.txtOnline)
        Me.UltraGroupBox16.Controls.Add(Me.cmdDeleteOnline)
        Me.UltraGroupBox16.Location = New System.Drawing.Point(38, 11)
        Me.UltraGroupBox16.Name = "UltraGroupBox16"
        Me.UltraGroupBox16.Size = New System.Drawing.Size(470, 574)
        Me.UltraGroupBox16.TabIndex = 18
        Me.UltraGroupBox16.Text = "Online"
        '
        'UltraLabel50
        '
        Me.UltraLabel50.AutoSize = True
        Me.UltraLabel50.Location = New System.Drawing.Point(81, 413)
        Me.UltraLabel50.Name = "UltraLabel50"
        Me.UltraLabel50.Size = New System.Drawing.Size(138, 19)
        Me.UltraLabel50.TabIndex = 93
        Me.UltraLabel50.Text = "Send frequency (days):"
        '
        'txtEmailFrequency
        '
        Me.txtEmailFrequency.Location = New System.Drawing.Point(224, 410)
        Me.txtEmailFrequency.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtEmailFrequency.MaxLength = 3
        Me.txtEmailFrequency.Name = "txtEmailFrequency"
        Me.txtEmailFrequency.Size = New System.Drawing.Size(48, 24)
        Me.txtEmailFrequency.TabIndex = 92
        Me.txtEmailFrequency.Text = "14"
        Me.txtEmailFrequency.UseAppStyling = False
        Me.txtEmailFrequency.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'cmdEmailReport
        '
        Me.cmdEmailReport.Location = New System.Drawing.Point(312, 410)
        Me.cmdEmailReport.Name = "cmdEmailReport"
        Me.cmdEmailReport.ShowFocusRect = False
        Me.cmdEmailReport.ShowOutline = False
        Me.cmdEmailReport.Size = New System.Drawing.Size(85, 26)
        Me.cmdEmailReport.TabIndex = 74
        Me.cmdEmailReport.Text = "Send now"
        '
        'chkEmailError
        '
        Appearance107.FontData.Name = "Segoe UI"
        Appearance107.FontData.SizeInPoints = 10.0!
        Me.chkEmailError.Appearance = Appearance107
        Me.chkEmailError.AutoSize = True
        Me.chkEmailError.BackColor = System.Drawing.Color.Transparent
        Me.chkEmailError.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkEmailError.Location = New System.Drawing.Point(66, 385)
        Me.chkEmailError.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkEmailError.Name = "chkEmailError"
        Me.chkEmailError.Size = New System.Drawing.Size(192, 23)
        Me.chkEmailError.TabIndex = 91
        Me.chkEmailError.Text = "Enable emailing error report"
        '
        'chkShowOnlineTotals
        '
        Appearance108.FontData.Name = "Segoe UI"
        Appearance108.FontData.SizeInPoints = 10.0!
        Me.chkShowOnlineTotals.Appearance = Appearance108
        Me.chkShowOnlineTotals.AutoSize = True
        Me.chkShowOnlineTotals.BackColor = System.Drawing.Color.Transparent
        Me.chkShowOnlineTotals.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkShowOnlineTotals.Location = New System.Drawing.Point(63, 467)
        Me.chkShowOnlineTotals.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkShowOnlineTotals.Name = "chkShowOnlineTotals"
        Me.chkShowOnlineTotals.Size = New System.Drawing.Size(196, 23)
        Me.chkShowOnlineTotals.TabIndex = 90
        Me.chkShowOnlineTotals.Text = "Show totals on online screen"
        '
        'chkPrintPayPalID
        '
        Appearance109.FontData.Name = "Segoe UI"
        Appearance109.FontData.SizeInPoints = 10.0!
        Me.chkPrintPayPalID.Appearance = Appearance109
        Me.chkPrintPayPalID.AutoSize = True
        Me.chkPrintPayPalID.BackColor = System.Drawing.Color.Transparent
        Me.chkPrintPayPalID.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkPrintPayPalID.Location = New System.Drawing.Point(63, 447)
        Me.chkPrintPayPalID.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkPrintPayPalID.Name = "chkPrintPayPalID"
        Me.chkPrintPayPalID.Size = New System.Drawing.Size(246, 23)
        Me.chkPrintPayPalID.TabIndex = 89
        Me.chkPrintPayPalID.Text = "Print PayPal transaction ID on receipt"
        '
        'cmbBackupDay
        '
        Me.cmbBackupDay.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList
        ValueListItem28.DataValue = "DAILY"
        ValueListItem28.DisplayText = "Daily"
        ValueListItem7.DataValue = "Monday"
        ValueListItem7.DisplayText = "Monday"
        ValueListItem11.DataValue = "Tuesday"
        ValueListItem11.DisplayText = "Tuesday"
        ValueListItem12.DataValue = "Wednesday"
        ValueListItem12.DisplayText = "Wednesday"
        ValueListItem13.DataValue = "Thursday"
        ValueListItem13.DisplayText = "Thursday"
        ValueListItem20.DataValue = "Friday"
        ValueListItem20.DisplayText = "Friday"
        ValueListItem21.DataValue = "Saturday"
        ValueListItem21.DisplayText = "Saturday"
        ValueListItem29.DataValue = "Sunday"
        ValueListItem29.DisplayText = "Sunday"
        Me.cmbBackupDay.Items.AddRange(New Infragistics.Win.ValueListItem() {ValueListItem28, ValueListItem7, ValueListItem11, ValueListItem12, ValueListItem13, ValueListItem20, ValueListItem21, ValueListItem29})
        Me.cmbBackupDay.Location = New System.Drawing.Point(91, 532)
        Me.cmbBackupDay.Name = "cmbBackupDay"
        Me.cmbBackupDay.Size = New System.Drawing.Size(176, 26)
        Me.cmbBackupDay.TabIndex = 87
        '
        'UltraLabel85
        '
        Me.UltraLabel85.AutoSize = True
        Me.UltraLabel85.Location = New System.Drawing.Point(91, 509)
        Me.UltraLabel85.Name = "UltraLabel85"
        Me.UltraLabel85.Size = New System.Drawing.Size(114, 19)
        Me.UltraLabel85.TabIndex = 88
        Me.UltraLabel85.Text = "Select backup day:"
        '
        'chkBackupDBOnline
        '
        Appearance110.FontData.Name = "Segoe UI"
        Appearance110.FontData.SizeInPoints = 10.0!
        Me.chkBackupDBOnline.Appearance = Appearance110
        Me.chkBackupDBOnline.AutoSize = True
        Me.chkBackupDBOnline.BackColor = System.Drawing.Color.Transparent
        Me.chkBackupDBOnline.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkBackupDBOnline.Location = New System.Drawing.Point(63, 487)
        Me.chkBackupDBOnline.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkBackupDBOnline.Name = "chkBackupDBOnline"
        Me.chkBackupDBOnline.Size = New System.Drawing.Size(210, 23)
        Me.chkBackupDBOnline.TabIndex = 77
        Me.chkBackupDBOnline.Text = "Enable online database backup"
        '
        'chkEnableOnline
        '
        Appearance111.FontData.Name = "Segoe UI"
        Appearance111.FontData.SizeInPoints = 10.0!
        Me.chkEnableOnline.Appearance = Appearance111
        Me.chkEnableOnline.AutoSize = True
        Me.chkEnableOnline.BackColor = System.Drawing.Color.Transparent
        Me.chkEnableOnline.BackColorInternal = System.Drawing.Color.Transparent
        Me.chkEnableOnline.Location = New System.Drawing.Point(63, 40)
        Me.chkEnableOnline.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkEnableOnline.Name = "chkEnableOnline"
        Me.chkEnableOnline.Size = New System.Drawing.Size(142, 23)
        Me.chkEnableOnline.TabIndex = 76
        Me.chkEnableOnline.Text = "Enable online mode"
        '
        'UltraLabel59
        '
        Me.UltraLabel59.AutoSize = True
        Me.UltraLabel59.Location = New System.Drawing.Point(63, 343)
        Me.UltraLabel59.Name = "UltraLabel59"
        Me.UltraLabel59.Size = New System.Drawing.Size(104, 19)
        Me.UltraLabel59.TabIndex = 75
        Me.UltraLabel59.Text = "Online label text:"
        '
        'txtOLText
        '
        Me.txtOLText.Location = New System.Drawing.Point(173, 340)
        Me.txtOLText.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtOLText.Name = "txtOLText"
        Me.txtOLText.Size = New System.Drawing.Size(153, 24)
        Me.txtOLText.TabIndex = 74
        Me.txtOLText.Text = "Order source"
        Me.txtOLText.UseAppStyling = False
        Me.txtOLText.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'lstOnline
        '
        Me.lstOnline.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Me.lstOnline.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstOnline.ItemSettings.AllowEdit = Infragistics.Win.DefaultableBoolean.[False]
        Me.lstOnline.ItemSettings.HotTracking = True
        Me.lstOnline.Location = New System.Drawing.Point(63, 104)
        Me.lstOnline.Name = "lstOnline"
        Me.lstOnline.ShowGroups = False
        Me.lstOnline.Size = New System.Drawing.Size(263, 208)
        Me.lstOnline.TabIndex = 73
        Me.lstOnline.Text = "UltraListView1"
        Me.lstOnline.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        Me.lstOnline.View = Infragistics.Win.UltraWinListView.UltraListViewStyle.List
        Me.lstOnline.ViewSettingsList.ImageSize = New System.Drawing.Size(0, 0)
        Me.lstOnline.ViewSettingsList.MultiColumn = False
        '
        'cmdAddOnline
        '
        Me.cmdAddOnline.Location = New System.Drawing.Point(332, 71)
        Me.cmdAddOnline.Name = "cmdAddOnline"
        Me.cmdAddOnline.ShowFocusRect = False
        Me.cmdAddOnline.ShowOutline = False
        Me.cmdAddOnline.Size = New System.Drawing.Size(75, 26)
        Me.cmdAddOnline.TabIndex = 16
        Me.cmdAddOnline.Text = "Add"
        '
        'txtOnline
        '
        Me.txtOnline.Location = New System.Drawing.Point(63, 71)
        Me.txtOnline.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtOnline.Name = "txtOnline"
        Me.txtOnline.Size = New System.Drawing.Size(263, 24)
        Me.txtOnline.TabIndex = 17
        Me.txtOnline.UseAppStyling = False
        Me.txtOnline.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        '
        'cmdDeleteOnline
        '
        Me.cmdDeleteOnline.Location = New System.Drawing.Point(332, 104)
        Me.cmdDeleteOnline.Name = "cmdDeleteOnline"
        Me.cmdDeleteOnline.ShowFocusRect = False
        Me.cmdDeleteOnline.ShowOutline = False
        Me.cmdDeleteOnline.Size = New System.Drawing.Size(75, 26)
        Me.cmdDeleteOnline.TabIndex = 15
        Me.cmdDeleteOnline.Text = "Delete"
        '
        'cmdSave
        '
        Me.cmdSave.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdSave.Location = New System.Drawing.Point(516, 639)
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.ShowFocusRect = False
        Me.cmdSave.ShowOutline = False
        Me.cmdSave.Size = New System.Drawing.Size(75, 26)
        Me.cmdSave.TabIndex = 1
        Me.cmdSave.Text = "Save"
        '
        'cmdCancel
        '
        Me.cmdCancel.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdCancel.Location = New System.Drawing.Point(597, 638)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.ShowFocusRect = False
        Me.cmdCancel.ShowOutline = False
        Me.cmdCancel.Size = New System.Drawing.Size(75, 26)
        Me.cmdCancel.TabIndex = 2
        Me.cmdCancel.Text = "Cancel"
        '
        'UltraTabSharedControlsPage1
        '
        Me.UltraTabSharedControlsPage1.Location = New System.Drawing.Point(-10000, -10000)
        Me.UltraTabSharedControlsPage1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.UltraTabSharedControlsPage1.Name = "UltraTabSharedControlsPage1"
        Me.UltraTabSharedControlsPage1.Size = New System.Drawing.Size(546, 602)
        '
        'utcSettings
        '
        Me.utcSettings.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.utcSettings.Controls.Add(Me.UltraTabSharedControlsPage1)
        Me.utcSettings.Controls.Add(Me.UltraTabPageControl1)
        Me.utcSettings.Controls.Add(Me.UltraTabPageControl3)
        Me.utcSettings.Controls.Add(Me.UltraTabPageControl4)
        Me.utcSettings.Controls.Add(Me.UltraTabPageControl6)
        Me.utcSettings.Controls.Add(Me.UltraTabPageControl7)
        Me.utcSettings.Controls.Add(Me.UltraTabPageControl9)
        Me.utcSettings.Controls.Add(Me.UltraTabPageControl11)
        Me.utcSettings.Controls.Add(Me.UltraTabPageControl13)
        Me.utcSettings.Controls.Add(Me.UltraTabPageControl5)
        Me.utcSettings.Controls.Add(Me.UltraTabPageControl8)
        Me.utcSettings.Controls.Add(Me.UltraTabPageControl12)
        Me.utcSettings.Controls.Add(Me.UltraTabPageControl14)
        Me.utcSettings.Controls.Add(Me.UltraTabPageControl15)
        Me.utcSettings.Controls.Add(Me.UltraTabPageControl16)
        Me.utcSettings.Controls.Add(Me.UltraTabPageControl17)
        Me.utcSettings.Controls.Add(Me.UltraTabPageControl18)
        Me.utcSettings.Controls.Add(Me.UltraTabPageControl19)
        Me.utcSettings.Controls.Add(Me.UltraTabPageControl20)
        Me.utcSettings.Location = New System.Drawing.Point(0, -1)
        Me.utcSettings.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.utcSettings.Name = "utcSettings"
        Me.utcSettings.SharedControlsPage = Me.UltraTabSharedControlsPage1
        Me.utcSettings.Size = New System.Drawing.Size(684, 604)
        Me.utcSettings.Style = Infragistics.Win.UltraWinTabControl.UltraTabControlStyle.Office2007Ribbon
        Me.utcSettings.TabIndex = 0
        Me.utcSettings.TabOrientation = Infragistics.Win.UltraWinTabs.TabOrientation.LeftTop
        UltraTab25.Key = "General"
        UltraTab25.TabPage = Me.UltraTabPageControl3
        UltraTab25.Text = "General"
        UltraTab23.Key = "DelivColn"
        UltraTab23.TabPage = Me.UltraTabPageControl1
        UltraTab23.Text = "Delivery && Collection"
        UltraTab3.Key = "DiscCharges"
        UltraTab3.TabPage = Me.UltraTabPageControl8
        UltraTab3.Text = "Discounts && Charges"
        UltraTab26.Key = "Phone"
        UltraTab26.TabPage = Me.UltraTabPageControl4
        UltraTab26.Text = "Phone"
        UltraTab22.Key = "Header"
        UltraTab22.TabPage = Me.UltraTabPageControl6
        UltraTab22.Text = "Header && Footer"
        UltraTab7.Key = "Cuisines"
        UltraTab7.TabPage = Me.UltraTabPageControl16
        UltraTab7.Text = "Cuisines"
        UltraTab34.Key = "Groups"
        UltraTab34.TabPage = Me.UltraTabPageControl11
        UltraTab34.Text = "Groups"
        UltraTab9.Key = "Dishes"
        UltraTab9.TabPage = Me.UltraTabPageControl18
        UltraTab9.Text = "Dishes"
        UltraTab30.Key = "Modifiers"
        UltraTab30.TabPage = Me.UltraTabPageControl7
        UltraTab30.Text = "Modifiers"
        UltraTab32.Key = "Printers"
        UltraTab32.TabPage = Me.UltraTabPageControl9
        UltraTab32.Text = "Printers"
        UltraTab2.Key = "LabelPrinter"
        UltraTab2.TabPage = Me.UltraTabPageControl5
        UltraTab2.Text = "Label Printer"
        UltraTab36.Key = "Print"
        UltraTab36.TabPage = Me.UltraTabPageControl13
        UltraTab36.Text = "Print Settings"
        UltraTab8.Key = "MPS"
        UltraTab8.TabPage = Me.UltraTabPageControl17
        UltraTab8.Text = "More Print Settings"
        UltraTab10.Key = "Tables"
        UltraTab10.TabPage = Me.UltraTabPageControl19
        UltraTab10.Text = "Tables && Bookings"
        UltraTab11.TabPage = Me.UltraTabPageControl20
        UltraTab11.Text = "Summary"
        UltraTab4.Key = "Manager"
        UltraTab4.TabPage = Me.UltraTabPageControl12
        UltraTab4.Text = "Manager"
        UltraTab6.Key = "Set"
        UltraTab6.TabPage = Me.UltraTabPageControl15
        UltraTab6.Text = "Set meals"
        UltraTab5.Key = "Online"
        UltraTab5.TabPage = Me.UltraTabPageControl14
        UltraTab5.Text = "Online"
        Me.utcSettings.Tabs.AddRange(New Infragistics.Win.UltraWinTabControl.UltraTab() {UltraTab25, UltraTab23, UltraTab3, UltraTab26, UltraTab22, UltraTab7, UltraTab34, UltraTab9, UltraTab30, UltraTab32, UltraTab2, UltraTab36, UltraTab8, UltraTab10, UltraTab11, UltraTab4, UltraTab6, UltraTab5})
        Me.utcSettings.TextOrientation = Infragistics.Win.UltraWinTabs.TextOrientation.Horizontal
        Me.utcSettings.ViewStyle = Infragistics.Win.UltraWinTabControl.ViewStyle.Office2007
        '
        'lblSaving
        '
        Me.lblSaving.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Appearance112.TextHAlignAsString = "Center"
        Me.lblSaving.Appearance = Appearance112
        Me.lblSaving.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSaving.Location = New System.Drawing.Point(213, 640)
        Me.lblSaving.Name = "lblSaving"
        Me.lblSaving.Size = New System.Drawing.Size(258, 22)
        Me.lblSaving.TabIndex = 73
        Me.lblSaving.Text = "Saving settings, please wait ..."
        Me.lblSaving.Visible = False
        '
        'frmSettings
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(684, 676)
        Me.Controls.Add(Me.lblSaving)
        Me.Controls.Add(Me.cmdCancel)
        Me.Controls.Add(Me.cmdSave)
        Me.Controls.Add(Me.utcSettings)
        Me.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.MinimumSize = New System.Drawing.Size(700, 715)
        Me.Name = "frmSettings"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Settings"
        Me.UltraTabPageControl3.ResumeLayout(False)
        CType(Me.UltraGroupBox4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.UltraGroupBox4.ResumeLayout(False)
        Me.UltraGroupBox4.PerformLayout()
        CType(Me.chkIsTabletPC, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkCenterMainForm, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkLastOrdered, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkNumberOrdered, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkAutoDelPastOrders, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkAutoCashCard, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkAutoMarkAsPaid, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.optMainSubSystem, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkPartOfMultiSystem, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkFirstOrdered, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkShowMinimise, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkSaveCustomerHistory, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkShowHomeAfterPrint, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkSaveDishHistory, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkPasswordTakings, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkDisableCursor, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkShowLabelText, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkCAP, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtCAP, System.ComponentModel.ISupportInitialize).EndInit()
        Me.UltraTabPageControl1.ResumeLayout(False)
        CType(Me.UltraGroupBox6, System.ComponentModel.ISupportInitialize).EndInit()
        Me.UltraGroupBox6.ResumeLayout(False)
        Me.UltraGroupBox6.PerformLayout()
        CType(Me.chkGiveDiscount, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtDiscountExc, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.optDiscount, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkDiscountExc, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtDiscount, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.UltraGroupBox5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.UltraGroupBox5.ResumeLayout(False)
        Me.UltraGroupBox5.PerformLayout()
        CType(Me.txtMyPostcode, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkDTime, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtDTime, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkMinOrderAmount, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtMinOrderAmount, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkDelivCharge, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtDelivUnder, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.optDeliv, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkDelivUnder, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtDeliv, System.ComponentModel.ISupportInitialize).EndInit()
        Me.UltraTabPageControl8.ResumeLayout(False)
        CType(Me.UltraGroupBox14, System.ComponentModel.ISupportInitialize).EndInit()
        Me.UltraGroupBox14.ResumeLayout(False)
        Me.UltraGroupBox14.PerformLayout()
        CType(Me.chkRoundingMethod, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lstDiscCharges, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbDCAorP, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbDCType, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtDCRate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtDCName, System.ComponentModel.ISupportInitialize).EndInit()
        Me.UltraTabPageControl4.ResumeLayout(False)
        CType(Me.UltraGroupBox8, System.ComponentModel.ISupportInitialize).EndInit()
        Me.UltraGroupBox8.ResumeLayout(False)
        Me.UltraGroupBox8.PerformLayout()
        CType(Me.optCometMeteor, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkDoNotShowCID, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkEnableRecording, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbActiveCIDPort, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkEnableActiveCID, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.UltraGroupBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.UltraGroupBox3.ResumeLayout(False)
        Me.UltraGroupBox3.PerformLayout()
        CType(Me.txtPhLen3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtPhTrim3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtPhLen2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtPhTrim2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtPhLen1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtPhTrim1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.UltraTabPageControl6.ResumeLayout(False)
        CType(Me.UltraGroupBox9, System.ComponentModel.ISupportInitialize).EndInit()
        Me.UltraGroupBox9.ResumeLayout(False)
        Me.UltraGroupBox9.PerformLayout()
        CType(Me.chkLogoItalic, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkLogoBold, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbLogoSize, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbLogoFont, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtFooter, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtHeader6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtHeader5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtHeader4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtHeader3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtHeader2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtHeader1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.UltraTabPageControl16.ResumeLayout(False)
        CType(Me.ugbCuisines, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ugbCuisines.ResumeLayout(False)
        Me.ugbCuisines.PerformLayout()
        CType(Me.txtCuisine5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtCuisine4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtCuisine3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtCuisine2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtCuisine1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.UltraTabPageControl11.ResumeLayout(False)
        CType(Me.UltraGroupBox11, System.ComponentModel.ISupportInitialize).EndInit()
        Me.UltraGroupBox11.ResumeLayout(False)
        Me.UltraGroupBox11.PerformLayout()
        CType(Me.cmbCuisineGroups, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lstGroups, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtGroups, System.ComponentModel.ISupportInitialize).EndInit()
        Me.UltraTabPageControl18.ResumeLayout(False)
        CType(Me.UltraGroupBox19, System.ComponentModel.ISupportInitialize).EndInit()
        Me.UltraGroupBox19.ResumeLayout(False)
        Me.UltraGroupBox19.PerformLayout()
        CType(Me.chkDishesUppercase, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkDishesSimpleName, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtPortionSmall, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtPortionLarge, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkDishesUseConcise, System.ComponentModel.ISupportInitialize).EndInit()
        Me.UltraTabPageControl7.ResumeLayout(False)
        CType(Me.UltraGroupBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.UltraGroupBox1.ResumeLayout(False)
        Me.UltraGroupBox1.PerformLayout()
        CType(Me.chkShowModLabelPrinter, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkZeroCost, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkDisableCostChange, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lstMods, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtCost, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtMod, System.ComponentModel.ISupportInitialize).EndInit()
        Me.UltraTabPageControl9.ResumeLayout(False)
        CType(Me.UltraGroupBox7, System.ComponentModel.ISupportInitialize).EndInit()
        Me.UltraGroupBox7.ResumeLayout(False)
        Me.UltraGroupBox7.PerformLayout()
        CType(Me.cmbCuisinePrinters, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkHidePrintDialog, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbT_SC_Kitchen, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbT_SC_Shop, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbD_SC_Kitchen, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbD_SC_Shop, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbD_KC_Kitchen, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbD_KC_Shop, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbT_KC_Kitchen, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbT_KC_Shop, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbC_SC_Kitchen, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbC_SC_Shop, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbC_KC_Kitchen, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbC_KC_Shop, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbPrinterKitchen, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbPrinterShop, System.ComponentModel.ISupportInitialize).EndInit()
        Me.UltraTabPageControl5.ResumeLayout(False)
        CType(Me.UltraGroupBox13, System.ComponentModel.ISupportInitialize).EndInit()
        Me.UltraGroupBox13.ResumeLayout(False)
        Me.UltraGroupBox13.PerformLayout()
        CType(Me.cmbCuisineLabelPrinter, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtLabelLeftOffset, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtLabelTopOffset, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtLabelHeight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtLabelWidth, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkPrintLabelAny, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbPrinterLabel, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtLabelTopMargin, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtLabelLeftMargin, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbLabelFontSize, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkPrintLabels, System.ComponentModel.ISupportInitialize).EndInit()
        Me.UltraTabPageControl13.ResumeLayout(False)
        CType(Me.UltraGroupBox10, System.ComponentModel.ISupportInitialize).EndInit()
        Me.UltraGroupBox10.ResumeLayout(False)
        Me.UltraGroupBox10.PerformLayout()
        CType(Me.chkSameSKHeader, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkSimultaneousPrinting, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkKitchenGap, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkExtraGap, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkDrinksFoodGrouped, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkDrinksHeader, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkDrinksAndFoodGap, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkDrinksFoodSeparatePrice, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkDrinksItemise, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.optKitchen, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.optCustomer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.optOnScreen, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkKitchenDate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkShopDate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkKitchenTime, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkShopTime, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkKitchenCard, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkShopCard, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkKitchenItem, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkShopItem, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkKitchenTotal, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkShopTotal, System.ComponentModel.ISupportInitialize).EndInit()
        Me.UltraTabPageControl17.ResumeLayout(False)
        CType(Me.UltraGroupBox18, System.ComponentModel.ISupportInitialize).EndInit()
        Me.UltraGroupBox18.ResumeLayout(False)
        Me.UltraGroupBox18.PerformLayout()
        CType(Me.txtCentreOffset, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtRightOffset, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtPaperWidth, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtKitchenHeaderText, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbFontSizeKitchenAddress, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbFontSizeKitchen, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbFontSizeShop, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtKitchenTopOffset, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtMinPaperLengthKitchen, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtMinPaperLengthShop, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtShopTopOffset, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtDrinksLabel, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtFoodLabel, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbPaidLocation, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbPaidFontSize, System.ComponentModel.ISupportInitialize).EndInit()
        Me.UltraTabPageControl19.ResumeLayout(False)
        CType(Me.UltraGroupBox20, System.ComponentModel.ISupportInitialize).EndInit()
        Me.UltraGroupBox20.ResumeLayout(False)
        Me.UltraGroupBox20.PerformLayout()
        CType(Me.chkServiceCharge, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ucpTStatus, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lstTStatus, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTStatus, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbNumTables, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkTableAutoCovers, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkTableExtLights, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTableExtLine3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTableExtLine2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTableExtLine1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkTableExtMode, System.ComponentModel.ISupportInitialize).EndInit()
        Me.UltraTabPageControl20.ResumeLayout(False)
        CType(Me.UltraGroupBox21, System.ComponentModel.ISupportInitialize).EndInit()
        Me.UltraGroupBox21.ResumeLayout(False)
        CType(Me.chkSummaryCDTTotals, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkSummaryPrintDate, System.ComponentModel.ISupportInitialize).EndInit()
        Me.UltraTabPageControl12.ResumeLayout(False)
        CType(Me.UltraGroupBox15, System.ComponentModel.ISupportInitialize).EndInit()
        Me.UltraGroupBox15.ResumeLayout(False)
        Me.UltraGroupBox15.PerformLayout()
        CType(Me.chkXClearOnExit, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkRequireLogon, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkXClearOrders, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkXAccessBanking, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkXAccessSummary, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkXOrderTotals, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkXAccessManager, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkXOrderReprint, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkXOrderEdit, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkXOrderDelete, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkXOrders, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtSPConfirm, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtSPNew, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtSPOld, System.ComponentModel.ISupportInitialize).EndInit()
        Me.UltraTabPageControl15.ResumeLayout(False)
        CType(Me.UltraGroupBox17, System.ComponentModel.ISupportInitialize).EndInit()
        Me.UltraGroupBox17.ResumeLayout(False)
        CType(Me.chkSetPutQty, System.ComponentModel.ISupportInitialize).EndInit()
        Me.UltraTabPageControl14.ResumeLayout(False)
        CType(Me.UltraGroupBox16, System.ComponentModel.ISupportInitialize).EndInit()
        Me.UltraGroupBox16.ResumeLayout(False)
        Me.UltraGroupBox16.PerformLayout()
        CType(Me.txtEmailFrequency, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkEmailError, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkShowOnlineTotals, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkPrintPayPalID, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbBackupDay, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkBackupDBOnline, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkEnableOnline, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtOLText, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lstOnline, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtOnline, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.utcSettings, System.ComponentModel.ISupportInitialize).EndInit()
        Me.utcSettings.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents cmdSave As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdCancel As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraTabPageControl13 As Infragistics.Win.UltraWinTabControl.UltraTabPageControl
    Friend WithEvents UltraTabPageControl11 As Infragistics.Win.UltraWinTabControl.UltraTabPageControl
    Friend WithEvents UltraTabPageControl9 As Infragistics.Win.UltraWinTabControl.UltraTabPageControl
    Friend WithEvents UltraTabPageControl7 As Infragistics.Win.UltraWinTabControl.UltraTabPageControl
    Friend WithEvents UltraTabPageControl6 As Infragistics.Win.UltraWinTabControl.UltraTabPageControl
    Friend WithEvents UltraTabPageControl4 As Infragistics.Win.UltraWinTabControl.UltraTabPageControl
    Friend WithEvents UltraTabPageControl3 As Infragistics.Win.UltraWinTabControl.UltraTabPageControl
    Friend WithEvents UltraTabPageControl1 As Infragistics.Win.UltraWinTabControl.UltraTabPageControl
    Friend WithEvents lblDiscAmtLbl As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents txtDiscountExc As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents UltraLabel4 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents txtDiscount As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents chkDiscountExc As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents chkGiveDiscount As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents optDiscount As Infragistics.Win.UltraWinEditors.UltraOptionSet
    Friend WithEvents lblDelivAmtLbl As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents txtDelivUnder As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents UltraLabel1 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents txtDeliv As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents chkDelivUnder As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents chkDelivCharge As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents optDeliv As Infragistics.Win.UltraWinEditors.UltraOptionSet
    Friend WithEvents UltraTabSharedControlsPage1 As Infragistics.Win.UltraWinTabControl.UltraTabSharedControlsPage
    Friend WithEvents utcSettings As Infragistics.Win.UltraWinTabControl.UltraTabControl
    Friend WithEvents UltraGroupBox1 As Infragistics.Win.Misc.UltraGroupBox
    Friend WithEvents cmdAddMod As Infragistics.Win.Misc.UltraButton
    Friend WithEvents txtMod As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents cmdDeleteMod As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraGroupBox4 As Infragistics.Win.Misc.UltraGroupBox
    Friend WithEvents txtCAP As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents UltraLabel18 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraGroupBox6 As Infragistics.Win.Misc.UltraGroupBox
    Friend WithEvents UltraGroupBox5 As Infragistics.Win.Misc.UltraGroupBox
    Friend WithEvents UltraGroupBox8 As Infragistics.Win.Misc.UltraGroupBox
    Friend WithEvents UltraLabel10 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents chkEnableActiveCID As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents UltraGroupBox3 As Infragistics.Win.Misc.UltraGroupBox
    Friend WithEvents txtPhLen3 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtPhTrim3 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents UltraLabel9 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents txtPhLen2 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtPhTrim2 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents UltraLabel8 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents txtPhLen1 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtPhTrim1 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents UltraLabel7 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel6 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraGroupBox9 As Infragistics.Win.Misc.UltraGroupBox
    Friend WithEvents txtHeader6 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtHeader5 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtHeader4 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtHeader3 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtHeader2 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtHeader1 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents UltraLabel13 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraGroupBox7 As Infragistics.Win.Misc.UltraGroupBox
    Friend WithEvents UltraLabel16 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel15 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel14 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents chkPrintLabels As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents chkCAP As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents cmbActiveCIDPort As Infragistics.Win.UltraWinEditors.UltraComboEditor
    Friend WithEvents cmbPrinterLabel As Infragistics.Win.UltraWinEditors.UltraComboEditor
    Friend WithEvents cmbPrinterKitchen As Infragistics.Win.UltraWinEditors.UltraComboEditor
    Friend WithEvents cmbPrinterShop As Infragistics.Win.UltraWinEditors.UltraComboEditor
    Friend WithEvents UltraGroupBox11 As Infragistics.Win.Misc.UltraGroupBox
    Friend WithEvents cmdAddGroup As Infragistics.Win.Misc.UltraButton
    Friend WithEvents txtGroups As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents cmdDeleteGroup As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraGroupBox10 As Infragistics.Win.Misc.UltraGroupBox
    Friend WithEvents chkKitchenCard As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents chkShopCard As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents chkKitchenItem As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents chkShopItem As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents UltraLabel23 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel22 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents chkKitchenTotal As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents chkShopTotal As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents UltraLabel12 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel3 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel2 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents chkKitchenDate As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents chkShopDate As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents UltraLabel19 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents chkKitchenTime As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents chkShopTime As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents UltraLabel17 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel31 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents txtCost As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents UltraLabel30 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel29 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lstMods As Infragistics.Win.UltraWinListView.UltraListView
    Friend WithEvents lstGroups As Infragistics.Win.UltraWinListView.UltraListView
    Friend WithEvents cmbC_KC_Shop As Infragistics.Win.UltraWinEditors.UltraComboEditor
    Friend WithEvents cmdMainGroup As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdSubGroup As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdMoveUp As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdMoveDown As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdSaveGroups As Infragistics.Win.Misc.UltraButton
    Friend WithEvents chkShowLabelText As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents chkDisableCursor As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents chkPasswordTakings As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents UltraLabel43 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel44 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel45 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel46 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel47 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel48 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel5 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel40 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel41 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel42 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel39 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel38 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel37 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents cmbT_SC_Kitchen As Infragistics.Win.UltraWinEditors.UltraComboEditor
    Friend WithEvents cmbT_SC_Shop As Infragistics.Win.UltraWinEditors.UltraComboEditor
    Friend WithEvents cmbD_SC_Kitchen As Infragistics.Win.UltraWinEditors.UltraComboEditor
    Friend WithEvents cmbD_SC_Shop As Infragistics.Win.UltraWinEditors.UltraComboEditor
    Friend WithEvents cmbD_KC_Kitchen As Infragistics.Win.UltraWinEditors.UltraComboEditor
    Friend WithEvents cmbD_KC_Shop As Infragistics.Win.UltraWinEditors.UltraComboEditor
    Friend WithEvents cmbT_KC_Kitchen As Infragistics.Win.UltraWinEditors.UltraComboEditor
    Friend WithEvents cmbT_KC_Shop As Infragistics.Win.UltraWinEditors.UltraComboEditor
    Friend WithEvents cmbC_SC_Kitchen As Infragistics.Win.UltraWinEditors.UltraComboEditor
    Friend WithEvents cmbC_SC_Shop As Infragistics.Win.UltraWinEditors.UltraComboEditor
    Friend WithEvents cmbC_KC_Kitchen As Infragistics.Win.UltraWinEditors.UltraComboEditor
    Friend WithEvents UltraLabel34 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel33 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel32 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel36 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel35 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents chkEnableRecording As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents chkSaveDishHistory As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents chkShowHomeAfterPrint As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents cmdLogoFontSave As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraLabel49 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel52 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents txtLabelLeftMargin As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents UltraLabel51 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents txtLabelTopMargin As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents lblSaving As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents chkDoNotShowCID As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents cmbLabelFontSize As Infragistics.Win.UltraWinEditors.UltraComboEditor
    Friend WithEvents UltraLabel53 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel58 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel57 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel56 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents optKitchen As Infragistics.Win.UltraWinEditors.UltraOptionSet
    Friend WithEvents optCustomer As Infragistics.Win.UltraWinEditors.UltraOptionSet
    Friend WithEvents UltraLabel54 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel55 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents optOnScreen As Infragistics.Win.UltraWinEditors.UltraOptionSet
    Friend WithEvents chkPrintLabelAny As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents chkSaveCustomerHistory As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents UltraTabPageControl5 As Infragistics.Win.UltraWinTabControl.UltraTabPageControl
    Friend WithEvents UltraGroupBox13 As Infragistics.Win.Misc.UltraGroupBox
    Friend WithEvents txtLabelHeight As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtLabelWidth As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents UltraLabel60 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel61 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel65 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel64 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel63 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel62 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel66 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel67 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents txtLabelLeftOffset As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtLabelTopOffset As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents UltraLabel68 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel69 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents chkShowMinimise As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents chkHidePrintDialog As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents chkFirstOrdered As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents optMainSubSystem As Infragistics.Win.UltraWinEditors.UltraOptionSet
    Friend WithEvents chkPartOfMultiSystem As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents chkDisableCostChange As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents UltraTabPageControl8 As Infragistics.Win.UltraWinTabControl.UltraTabPageControl
    Friend WithEvents UltraGroupBox14 As Infragistics.Win.Misc.UltraGroupBox
    Friend WithEvents cmbDCAorP As Infragistics.Win.UltraWinEditors.UltraComboEditor
    Friend WithEvents UltraLabel72 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents cmbDCType As Infragistics.Win.UltraWinEditors.UltraComboEditor
    Friend WithEvents UltraLabel71 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents txtDCRate As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtLblValue As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents txtDCName As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents UltraLabel70 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lstDiscCharges As Infragistics.Win.UltraWinListView.UltraListView
    Friend WithEvents cmdDCAdd As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDCDelete As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDCClear As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraTabPageControl12 As Infragistics.Win.UltraWinTabControl.UltraTabPageControl
    Friend WithEvents UltraGroupBox15 As Infragistics.Win.Misc.UltraGroupBox
    Friend WithEvents UltraLabel73 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents cmdSetSupervisorPassword As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraLabel74 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel75 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel76 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents txtSPConfirm As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtSPNew As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtSPOld As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents chkXOrderEdit As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents chkXOrderDelete As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents chkXOrders As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents UltraLabel25 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents chkXOrderReprint As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents chkXAccessManager As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents chkXOrderTotals As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents optCometMeteor As Infragistics.Win.UltraWinEditors.UltraOptionSet
    Friend WithEvents chkDrinksItemise As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents chkDrinksFoodSeparatePrice As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents chkDrinksHeader As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents chkDrinksAndFoodGap As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents chkZeroCost As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents UltraLabel78 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents cmdReleaseCOMPort As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdResetActiveCID As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraTabPageControl14 As Infragistics.Win.UltraWinTabControl.UltraTabPageControl
    Friend WithEvents UltraGroupBox16 As Infragistics.Win.Misc.UltraGroupBox
    Friend WithEvents lstOnline As Infragistics.Win.UltraWinListView.UltraListView
    Friend WithEvents cmdAddOnline As Infragistics.Win.Misc.UltraButton
    Friend WithEvents txtOnline As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents cmdDeleteOnline As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraLabel28 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents txtFooter As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents cmbLogoFont As Infragistics.Win.UltraWinEditors.UltraComboEditor
    Friend WithEvents cmbLogoSize As Infragistics.Win.UltraWinEditors.UltraComboEditor
    Friend WithEvents chkLogoItalic As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents chkLogoBold As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents UltraLabel79 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel59 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents txtOLText As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents chkEnableOnline As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents chkAutoMarkAsPaid As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents chkShowModLabelPrinter As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents chkRoundingMethod As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents UltraTabPageControl15 As Infragistics.Win.UltraWinTabControl.UltraTabPageControl
    Friend WithEvents UltraGroupBox17 As Infragistics.Win.Misc.UltraGroupBox
    Friend WithEvents chkSetPutQty As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents UltraLabel82 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents txtMinOrderAmount As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents chkMinOrderAmount As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents cmdGetTime As Infragistics.Win.Misc.UltraButton
    Friend WithEvents chkDTime As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents UltraLabel83 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents txtDTime As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents chkXAccessSummary As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents chkXAccessBanking As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents cmdShowPassword As Infragistics.Win.Misc.UltraButton
    Friend WithEvents chkKitchenGap As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents cmdInsertLine As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdGroupingMode As Infragistics.Win.Misc.UltraButton
    Friend WithEvents chkBackupDBOnline As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents cmbBackupDay As Infragistics.Win.UltraWinEditors.UltraComboEditor
    Friend WithEvents UltraLabel85 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents chkDrinksFoodGrouped As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents chkExtraGap As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents chkSimultaneousPrinting As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents chkPrintPayPalID As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents chkShowOnlineTotals As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents cmbCuisineGroups As Infragistics.Win.UltraWinEditors.UltraComboEditor
    Friend WithEvents UltraTabPageControl16 As Infragistics.Win.UltraWinTabControl.UltraTabPageControl
    Friend WithEvents ugbCuisines As Infragistics.Win.Misc.UltraGroupBox
    Friend WithEvents cmdCuisineSave As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdRefreshCuisinesGroups As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraLabel86 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents txtCuisine5 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtCuisine4 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtCuisine3 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtCuisine2 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtCuisine1 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents UltraLabel91 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel90 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel89 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel88 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel87 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents cmdRenameCuisine5 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdRenameCuisine4 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdRenameCuisine3 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdRenameCuisine2 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdRenameCuisine1 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDeleteCuisine5 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDeleteCuisine4 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDeleteCuisine3 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDeleteCuisine2 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDeleteCuisine1 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDefault As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraLabel94 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents cmdRefreshCuisinesPrinters As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmbCuisinePrinters As Infragistics.Win.UltraWinEditors.UltraComboEditor
    Friend WithEvents cmdSavePrinters As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraLabel95 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents cmdRefreshCuisinesLabel As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmbCuisineLabelPrinter As Infragistics.Win.UltraWinEditors.UltraComboEditor
    Friend WithEvents chkAutoCashCard As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents chkAutoDelPastOrders As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents UltraLabel97 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents txtMyPostcode As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents chkNumberOrdered As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents chkLastOrdered As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents UltraTabPageControl17 As Infragistics.Win.UltraWinTabControl.UltraTabPageControl
    Friend WithEvents UltraGroupBox18 As Infragistics.Win.Misc.UltraGroupBox
    Friend WithEvents UltraLabel111 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents cmbPaidLocation As Infragistics.Win.UltraWinEditors.UltraComboEditor
    Friend WithEvents UltraLabel110 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents cmbPaidFontSize As Infragistics.Win.UltraWinEditors.UltraComboEditor
    Friend WithEvents UltraLabel99 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents cmbFontSizeKitchen As Infragistics.Win.UltraWinEditors.UltraComboEditor
    Friend WithEvents UltraLabel98 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents cmbFontSizeShop As Infragistics.Win.UltraWinEditors.UltraComboEditor
    Friend WithEvents txtKitchenTopOffset As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents UltraLabel92 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel93 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel84 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel81 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents txtMinPaperLengthKitchen As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents UltraLabel80 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents txtMinPaperLengthShop As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents UltraLabel77 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents txtShopTopOffset As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents UltraLabel27 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents txtDrinksLabel As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents UltraLabel26 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents txtFoodLabel As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents UltraTabPageControl18 As Infragistics.Win.UltraWinTabControl.UltraTabPageControl
    Friend WithEvents UltraGroupBox19 As Infragistics.Win.Misc.UltraGroupBox
    Friend WithEvents chkDishesUseConcise As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents UltraLabel100 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents cmbFontSizeKitchenAddress As Infragistics.Win.UltraWinEditors.UltraComboEditor
    Friend WithEvents UltraLabel104 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents txtPortionSmall As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents UltraLabel106 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents txtPortionLarge As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents chkSameSKHeader As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents cmdRenameGroup As Infragistics.Win.Misc.UltraButton
    Friend WithEvents chkDishesSimpleName As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents cmdMergeGroup As Infragistics.Win.Misc.UltraButton
    Friend WithEvents chkXClearOrders As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents chkEmailError As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents chkDishesUppercase As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents cmdEmailReport As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraLabel50 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents txtEmailFrequency As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents UltraTabPageControl19 As Infragistics.Win.UltraWinTabControl.UltraTabPageControl
    Friend WithEvents UltraGroupBox20 As Infragistics.Win.Misc.UltraGroupBox
    Friend WithEvents chkTableExtMode As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents chkTableExtDelete As Infragistics.Win.Misc.UltraButton
    Friend WithEvents txtTableExtLine3 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtTableExtLine2 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtTableExtLine1 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents UltraLabel101 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel102 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel103 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents chkTableExtSave As Infragistics.Win.Misc.UltraButton
    Friend WithEvents chkTableExtLights As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents chkRequireLogon As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents chkTableAutoCovers As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents cmbNumTables As Infragistics.Win.UltraWinEditors.UltraComboEditor
    Friend WithEvents UltraLabel11 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents chkXClearOnExit As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents UltraTabPageControl20 As Infragistics.Win.UltraWinTabControl.UltraTabPageControl
    Friend WithEvents UltraGroupBox21 As Infragistics.Win.Misc.UltraGroupBox
    Friend WithEvents chkSummaryCDTTotals As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents chkSummaryPrintDate As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents UltraLabel105 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents txtKitchenHeaderText As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents UltraLabel107 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lstTStatus As Infragistics.Win.UltraWinListView.UltraListView
    Friend WithEvents cmdAddTStatus As Infragistics.Win.Misc.UltraButton
    Friend WithEvents txtTStatus As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents cmdDeleteTStatus As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ucpTStatus As Infragistics.Win.UltraWinEditors.UltraColorPicker
    Friend WithEvents chkCenterMainForm As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents chkIsTabletPC As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents UltraLabel108 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents cmdSaveLabelPrinters As Infragistics.Win.Misc.UltraButton
    Friend WithEvents chkServiceCharge As Infragistics.Win.UltraWinEditors.UltraCheckEditor
    Friend WithEvents UltraLabel109 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents txtPaperWidth As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents UltraLabel112 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents txtRightOffset As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents UltraLabel115 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel114 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel113 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents txtCentreOffset As Infragistics.Win.UltraWinEditors.UltraTextEditor
End Class