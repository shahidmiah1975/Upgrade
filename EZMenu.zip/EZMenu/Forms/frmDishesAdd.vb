﻿Imports Infragistics.Win.UltraWinEditors
Imports System.IO
Imports EZControls

Public Class frmDishesAdd

    Private UniqueButtonID As Short
    Private strDishesFileName As String = "\mydishes.csv"
    Private _owner As frmDishes2
    Private _cuisine As String
    Private _selIndex As Integer

    Public objPrevControl As Object

    Public Sub New(objOwner As frmDishes2, strCuisine As String, intSelIndex As Integer)

        MyBase.New

        ' This call is required by the designer.
        InitializeComponent()

        _owner = objOwner
        _cuisine = strCuisine
        _selIndex = intSelIndex

        MyBase.HeaderText("Add New Dish")

        CenterToScreen()

        ezkbdAddDish.BorderStyle = BorderStyle.None
        lblDishAdded.Text = String.Empty

        cmbGroup.Items.Clear()
        cmbGroup.Items.Add("")

        drcDatarowCollection = objDB.GetDataRows($"SELECT GroupName FROM Groups WHERE CuisineName = '{ strCuisine }'")
        If drcDatarowCollection IsNot Nothing AndAlso drcDatarowCollection.Count > 1 Then
            For Each myRow As DataRow In drcDatarowCollection
                cmbGroup.Items.Add(myRow!GroupName)
            Next
        End If

        cmdLoadFromFile.Enabled = File.Exists(Application.StartupPath & strDishesFileName)

        ResetAll()

        ShowDialog()

    End Sub

    Private Sub frmDishesAdd_Activated(sender As Object, e As EventArgs) Handles Me.Activated

        Try
            txtDishName.Focus()
        Catch ex As Exception

        End Try

    End Sub

    Private Sub ButtonMouseEnter(sender As Object, e As EventArgs)
        sender.text = sender.tag
    End Sub

    Private Sub ButtonMouseLeave(sender As Object, e As EventArgs)
        sender.Text = String.Empty
    End Sub

    Private Sub cmdDishClose_Click(sender As Object, e As EventArgs) Handles cmdDishClose.Click
        Close()
    End Sub

    Private Sub cmdDishNew_Click(sender As Object, e As EventArgs) Handles cmdDishNew.Click
        ResetAll()
    End Sub

    Private Sub ResetAll()

        'clears all boxes for entry of new dish

        'get highest code number from the database
        drDataRow = clsDish.GetMaxCodeUniqueID(_cuisine)

        UniqueButtonID = Val("" & drDataRow!MaxUniqueID) + 1
        txtCode.Text = Val("" & drDataRow!MaxCode) + 1
        txtDishName.Clear()
        txtShortName.Clear()
        txtShortcode.Clear()
        txtPriceIn.Text = "0.00"
        txtPriceOut.Text = "0.00"
        cmbGroup.Text = String.Empty

        txtCode.Enabled = True
        txtDishName.Enabled = True
        txtShortName.Enabled = True
        txtShortcode.Enabled = True
        txtPriceIn.Enabled = True
        txtPriceOut.Enabled = IIf(chkSameOutPrice.Checked = True, False, True)
        cmbGroup.Enabled = True
        cmdDishAdd.Enabled = True

        lblDishAdded.Visible = False

        txtCode.Focus()
        txtCode.SelectAll()

    End Sub

    Private Sub cmdDishAdd_Click(sender As Object, e As EventArgs) Handles cmdDishAdd.Click

        Dim NCode, NDName, NPName, NPriceIn, NPriceOut, NSCode, NGroup As String

        NCode = txtCode.Text.Trim
        NDName = txtDishName.Text.Trim
        NPName = txtShortName.Text.Trim
        NSCode = txtShortcode.Text.Trim.ToUpper
        NPriceIn = txtPriceIn.Text.Trim
        NPriceOut = txtPriceOut.Text.Trim
        NGroup = cmbGroup.Text.Trim

        'do some data validation

        If NCode = "" Then
            strMsgBox = "You must enter a code number for the dish"
            EZMsgBox.Show(strMsgBox, MessageBoxButtons.OK, MessageBoxIcon.Information)
            txtCode.Focus()
            Exit Sub
        End If

        If Not IsANumber(NCode) Then
            strMsgBox = "Code entered is not a valid number"
            EZMsgBox.Show(strMsgBox, MessageBoxButtons.OK, MessageBoxIcon.Information)
            txtCode.Focus()
            Exit Sub
        End If

        If NDName = "" Then
            strMsgBox = "You must enter a name for the dish"
            EZMsgBox.Show(strMsgBox, MessageBoxButtons.OK, MessageBoxIcon.Information)
            txtDishName.Focus()
            Exit Sub
        End If

        If NPName = "" Then
            strMsgBox = "Enter a short name for the dish" & vbCrLf & "(this will be printed out on the order list)"
            EZMsgBox.Show(strMsgBox, MessageBoxButtons.OK, MessageBoxIcon.Information)
            Exit Sub
        End If

        If Not IsANumber(NPriceIn) Then
            strMsgBox = "Entered in-price is not valid"
            EZMsgBox.Show(strMsgBox, MessageBoxButtons.OK, MessageBoxIcon.Information)
            txtPriceIn.Focus()
            Exit Sub
        Else
            txtPriceIn.Text = fixCur(txtPriceIn.Text)
        End If

        If Not IsANumber(NPriceOut) Then
            strMsgBox = "Entered out-price is not valid"
            EZMsgBox.Show(strMsgBox, MessageBoxButtons.OK, MessageBoxIcon.Information)
            txtPriceOut.Focus()
            Exit Sub
        Else
            txtPriceOut.Text = fixCur(txtPriceOut.Text)
        End If

        If NGroup = "" Then
            strMsgBox = "Enter a group for the dish"
            EZMsgBox.Show(strMsgBox, MessageBoxButtons.OK, MessageBoxIcon.Information)
            cmbGroup.Focus()
            Exit Sub
        End If

        If NPriceIn = 0 Or (NPriceOut = 0 And txtPriceOut.Enabled = True) Then
            strMsgBox = "You have not specified a price for the dish. Sure you want to add this dish without a price?"
            intMsgBoxResult = EZMsgBox.Show(strMsgBox, MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If intMsgBoxResult = MsgBoxResult.No Then
                Exit Sub
            Else
                If NPriceIn = 0 Then
                    If txtPriceIn.Enabled = True Then txtPriceIn.Focus()
                Else
                    If txtPriceOut.Enabled = True Then txtPriceOut.Focus()
                End If
            End If
        End If

        'check shortcode does not contain any digits
        For Each x In NSCode
            If IsANumber(x) Then
                strMsgBox = "Enter only letters for shortcode. Your input must not contain any numbers."
                EZMsgBox.Show(strMsgBox, MessageBoxButtons.OK, MessageBoxIcon.Information)
                txtShortcode.Focus()
                Exit Sub
            End If
        Next

        'check if the shortcode is already in use
        If NSCode <> "" Then
            If clsDish.ExistsShortcode(NSCode, _cuisine) Then
                strMsgBox = "The selected short code is already used by another dish."
                EZMsgBox.Show(strMsgBox, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                SelectText(txtShortcode)
                Exit Sub
            End If
        End If

        'check if that dish name is already in the table
        If clsDish.ExistsDishname(NDName, _cuisine) Then
            strMsgBox = NDName & " is already in the database. You must change the name."
            EZMsgBox.Show(strMsgBox, MessageBoxButtons.OK, MessageBoxIcon.Information)
            SelectText(txtDishName)
            Exit Sub
        End If

        'check if that dish shortname is already in the table
        If clsDish.ExistsShortname(NPName, _cuisine) Then
            strMsgBox = "This short name is already in use by another dish. Select a different short name for this dish."
            EZMsgBox.Show(strMsgBox, MessageBoxButtons.OK, MessageBoxIcon.Information)
            SelectText(txtShortName)
            Exit Sub
        End If

        'insert this new dish into the table
        clsDish.AddNewDish(NCode, NDName, NPriceIn, NPriceOut, NGroup)

        SaveToDishTemplate(NDName, NPName, NSCode)

        If NSCode <> "" Then
            clsDish.AddShortCode(UniqueButtonID, NSCode)
        End If

        'don't need to add shortname if it is the same as dishname
        If NPName = NDName Then NPName = ""

        If NPName <> "" Then
            clsDish.AddShortName(UniqueButtonID, NPName)
        End If

        txtCode.Enabled = False
        txtDishName.Enabled = False
        txtShortName.Enabled = False
        txtShortcode.Enabled = False
        txtPriceIn.Enabled = False
        txtPriceOut.Enabled = False
        cmbGroup.Enabled = False
        cmdDishAdd.Enabled = False
        cmdDishNew.Focus()

        lblDishAdded.Text = "Details have been added to the database"
        lblDishAdded.Visible = True

        _owner.UpdateGrid()

    End Sub

    Private Sub chkSameOutPrice_CheckedChanged(sender As Object, e As EventArgs) Handles chkSameOutPrice.CheckedChanged

        txtPriceOut.Enabled = Not chkSameOutPrice.Checked
        If txtPriceOut.Enabled = False Then txtPriceOut.Text = txtPriceIn.Text

    End Sub

    Private Sub txtPriceIn_KeyDown(sender As Object, e As KeyEventArgs) Handles txtPriceIn.KeyDown

        If e.KeyCode = Keys.Enter Then
            If txtPriceOut.Enabled = True Then
                txtPriceOut.Focus()
            Else
                cmdDishAdd_Click(sender, e)
            End If
        End If

    End Sub

    Private Sub txtPriceIn_TextChanged(sender As Object, e As EventArgs) Handles txtPriceIn.TextChanged

        If chkSameOutPrice.Checked Then
            txtPriceOut.Text = txtPriceIn.Text
        End If

    End Sub

    Private Sub txtDishName_KeyDown(sender As Object, e As KeyEventArgs) Handles txtDishName.KeyDown

        If txtDishName.Text.Trim <> String.Empty AndAlso e.KeyCode = Keys.Enter Then
            If InStr(txtDishName.Text.Trim, "#") Then
                GetFromDishTemplate(txtDishName.Text.Trim)
            Else
                txtShortName.Focus()
            End If
        End If

    End Sub

    Private Sub txtShortCode_KeyDown(sender As Object, e As KeyEventArgs) Handles txtShortcode.KeyDown

        If txtShortcode.Text.Trim <> String.Empty AndAlso e.KeyCode = Keys.Enter Then
            If InStr(txtShortcode.Text.Trim, "#") Then
                GetFromDishTemplate(txtShortcode.Text.Trim)
            Else
                cmbGroup.Focus()
            End If
        End If

    End Sub

    Private Sub txtCode_KeyDown(sender As Object, e As KeyEventArgs) Handles txtCode.KeyDown
        If txtCode.Text.Trim <> String.Empty AndAlso e.KeyCode = Keys.Enter Then txtDishName.Focus()
    End Sub

    Private Sub txtShortName_KeyDown(sender As Object, e As KeyEventArgs) Handles txtShortName.KeyDown
        If txtShortName.Text.Trim <> String.Empty AndAlso e.KeyCode = Keys.Enter Then txtShortcode.Focus()
    End Sub

    Private Sub cmbGroup_KeyDown(sender As Object, e As KeyEventArgs) Handles cmbGroup.KeyDown
        If cmbGroup.Text.Trim <> String.Empty AndAlso e.KeyCode = Keys.Enter Then txtPriceIn.Focus()
    End Sub

    Private Sub txtPriceOut_KeyDown(sender As Object, e As KeyEventArgs) Handles txtPriceOut.KeyDown
        If e.KeyCode = Keys.Enter Then cmdDishAdd_Click(sender, e)
    End Sub

    Private Sub TextBoxEntered2(sender As Object, e As EventArgs) Handles txtCode.Enter, txtDishName.Enter, txtPriceIn.Enter,
                                                                                      txtPriceOut.Enter, txtShortName.Enter, txtShortcode.Enter

        Dim ctrlSender As UltraTextEditor = CType(sender, UltraTextEditor)

        HiLitBox(ctrlSender)

        If objPrevControl IsNot Nothing AndAlso objPrevControl.Name <> ctrlSender.Name Then
            HiLitOffBox(objPrevControl)
        End If

        ctrlSender.AlwaysInEditMode = True
        objPrevControl = ctrlSender
        ezkbdAddDish.ctrlActive = ctrlSender

    End Sub

    Private Sub txtDishName_ValueChanged(sender As Object, e As EventArgs) Handles txtDishName.ValueChanged

        If txtDishName.Text.Length > 0 AndAlso txtDishName.Text.Substring(0, 1) = "#" Then Exit Sub

        Dim strNewDish As String = txtDishName.Text

        Dim arrList() = {"Chicken Tikka", "Chi Tk", "Lamb Tikka", "Lb Tk", "King Prawn", "K Pr", "Prawn", "Pr",
                         "Chicken", "Chi", "Lamb", "Lb", "Vegetable", "Veg", "Tandoori", "Tand", "Special", "Sp"}

        For i = arrList.GetLowerBound(0) To arrList.GetUpperBound(0) Step 2
            If strNewDish.IndexOf(arrList(i)) > -1 Then
                strNewDish = strNewDish.Replace(arrList(i), arrList(i + 1))
                Exit For
            End If
        Next

        txtShortName.Text = strNewDish

    End Sub

    Private Sub txtCode_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtCode.KeyPress

        Select Case e.KeyChar
            Case ChrW(Keys.Enter)
                e.Handled = False
                If txtCode.Text <> String.Empty Then txtDishName.Focus()
            Case ChrW(Keys.D0) To ChrW(Keys.D9), ChrW(Keys.Back)
                e.Handled = False
            Case Else
                e.Handled = True
        End Select

    End Sub

    Private Sub GetFromDishTemplate(strCodeString As String)

        strCodeString = strCodeString.Replace("#", "")

        SQLQuery = "SELECT * FROM DishTemplate WHERE ShortCode = '" & strCodeString & "'"

        drDataRow = objDB.GetSingleRow(SQLQuery)
        If drDataRow IsNot Nothing Then
            txtDishName.Text = drDataRow!DishName
            txtShortName.Text = drDataRow!ShortName
        End If

        txtShortcode.Text = strCodeString.ToUpper
        txtDishName.Focus()

    End Sub

    Private Sub SaveToDishTemplate(strXDishName As String, strXShortName As String, strXShortcode As String)

        Try
            If strXDishName = String.Empty Or strXShortcode = String.Empty Then Exit Sub

            SQLQuery = "SELECT * FROM DishTemplate WHERE DishName = '" & strXDishName.Punctuate & "'"

            drDataRow = objDB.GetSingleRow(SQLQuery)
            If drDataRow Is Nothing Then
                SQLQuery = String.Format("INSERT INTO DishTemplate (ShortCode, DishName, ShortName) VALUES ('{0}', '{1}', '{2}')",
                                        strXShortcode, strXDishName.Punctuate, strXShortName.Punctuate)
                objDB.ExeNonQuery(SQLQuery)
            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub cmdLoadFromFile_Click(sender As Object, e As EventArgs) Handles cmdLoadFromFile.Click

        Dim NCode, NDName, NPName, NPriceIn, NPriceOut, NSCode, NGroup As String
        Dim intGrpPos
        Dim line = "", strPrevGroup As String = ""
        Dim NUniqueID
        Dim NItems As Short = 1

        Dim lstGroups As New Dictionary(Of Short, String)

        Try

            If File.Exists(Application.StartupPath & strDishesFileName) Then

                If GetAppSettingCS("MultiCuisines", 0) = 0 Then
                    SQLQuery = "TRUNCATE TABLE Dish"
                    objDB.ExeNonQuery(SQLQuery)
                    SQLQuery = "TRUNCATE TABLE DishShortName"
                    objDB.ExeNonQuery(SQLQuery)
                    SQLQuery = "TRUNCATE TABLE Codes"
                    objDB.ExeNonQuery(SQLQuery)
                    SQLQuery = "TRUNCATE TABLE Groups"
                    objDB.ExeNonQuery(SQLQuery)
                    SQLQuery = "TRUNCATE TABLE Typical"
                    objDB.ExeNonQuery(SQLQuery)
                End If

                cmdDishAdd.Enabled = False
                cmdDishNew.Enabled = False
                cmdLoadFromFile.Enabled = False
                cmdDishClose.Enabled = False
                intGrpPos = 0

                lblItemsAdded.Text = ""
                lblItemsAdded.Visible = True

                Using sr As StreamReader = New StreamReader(Application.StartupPath & strDishesFileName)
                    line = sr.ReadLine
                    Do While (line IsNot Nothing)

                        Dim arrItems = line.Split(",")
                        NCode = arrItems(0).Trim
                        NGroup = arrItems(1).Trim
                        NDName = arrItems(2).Trim
                        NPName = arrItems(3).Trim
                        NPriceIn = arrItems(4).Trim
                        NPriceOut = arrItems(5).Trim
                        NSCode = arrItems(6).Trim.ToUpper

                        'insert this new dish into the table
                        SQLQuery = "INSERT INTO Dish (Code, DishName, PriceIn, PriceOut, PrintLabel, GroupName, DoButton) " &
                                    "VALUES (" & NCode & ",'" & NDName.Punctuate & "'," & NPriceIn & "," & NPriceOut & ",-1,'" & NGroup.Punctuate & "', 'True')"

                        objDB.ExeNonQuery(SQLQuery)
                        NUniqueID = idIdentity

                        If NSCode <> "#" Then SaveToDishTemplate(NDName, NPName, NSCode)

                        If NSCode <> "" And NSCode <> "#" Then
                            SQLQuery = "INSERT INTO Codes (UniqueID, ShortCode) VALUES (" & NUniqueID & ",'" & NSCode & "')"
                            objDB.ExeNonQuery(SQLQuery)
                        End If

                        'don't need to add shortname if it is the same as dishname
                        If NPName <> NDName Then
                            SQLQuery = "INSERT INTO DishShortName (UniqueID, ShortName) VALUES (" & NUniqueID & ",'" & NPName.Punctuate & "')"
                            objDB.ExeNonQuery(SQLQuery)
                        End If

                        lblItemsAdded.Text = NItems & " items added"
                        Application.DoEvents()
                        NItems += 1

                        'add group to database
                        If Not lstGroups.ContainsValue(NGroup) Then
                            lstGroups.Add(lstGroups.Count + 1, NGroup)
                        End If

                        line = sr.ReadLine

                    Loop

                    'now add all groups to the database
                    Dim intGrpIndx As Short
                    Dim strCuisneName As String
                    If GetAppSettingCS("MultiCuisines", 0) = 0 Then
                        intGrpIndx = 1001
                        strCuisneName = GetAppSettingCS("MultiCuisinesDefault", "Indian")
                    Else
                        intGrpIndx = ((_selIndex + 1) * 1000) + 1
                        strCuisneName = _cuisine
                    End If

                    For Each x In lstGroups
                        SQLQuery = "INSERT INTO Groups (GroupIndex, GroupName, CuisineName) " &
                            $"SELECT {x.Key}, '{x.Value}', '" & strCuisneName & "' " &
                            "WHERE NOT EXISTS (SELECT * FROM Groups WHERE GroupName = '" & strCuisneName & "')"
                        objDB.ExeNonQuery(SQLQuery)
                    Next

                    lblItemsAdded.Text = NItems - 1 & " items added"
                    Application.DoEvents()
                    strMsgBox = NItems - 1 & " items have been imported"
                    strMsgBox &= vbCrLf & lstGroups.Count & " groups have been imported"
                    EZMsgBox.Show(strMsgBox, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    _owner.LoadDishesGrid()

                    Close()

                End Using

            Else
                Alert("File '" & Application.StartupPath & strDishesFileName & "' does not exist.")

            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    'Declare the variables
    Dim drag As Boolean
    Dim mousex As Integer
    Dim mousey As Integer

    Private Sub Form1_MouseDown(sender As Object, e As MouseEventArgs) Handles Me.MouseDown
        drag = True 'Sets the variable drag to true.
        mousex = Cursor.Position.X - Left 'Sets variable mousex
        mousey = Cursor.Position.Y - Top 'Sets variable mousey
    End Sub

    Private Sub Form1_MouseMove(sender As Object, e As MouseEventArgs) Handles Me.MouseMove
        'If drag is set to true then move the form accordingly.
        If drag Then
            Top = Cursor.Position.Y - mousey
            Left = Cursor.Position.X - mousex
        End If
    End Sub

    Private Sub Form1_MouseUp(sender As Object, e As MouseEventArgs) Handles Me.MouseUp
        drag = False 'Sets drag to false, so the form does not move according to the code in MouseMove
    End Sub

End Class