﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmReprint
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim Appearance1 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance2 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance3 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance4 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance5 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmReprint))
        Dim Appearance6 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance7 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Me.cmdShopCopy = New Infragistics.Win.Misc.UltraButton()
        Me.cmdKitchenCopy = New Infragistics.Win.Misc.UltraButton()
        Me.cmdBothCopies = New Infragistics.Win.Misc.UltraButton()
        Me.lblAddressLbl = New Infragistics.Win.Misc.UltraLabel()
        Me.cmdClose = New Infragistics.Win.Misc.UltraButton()
        Me.SuspendLayout()
        '
        'cmdShopCopy
        '
        Me.cmdShopCopy.Anchor = System.Windows.Forms.AnchorStyles.Top
        Appearance1.BackColor = System.Drawing.Color.Transparent
        Me.cmdShopCopy.Appearance = Appearance1
        Me.cmdShopCopy.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdShopCopy.Location = New System.Drawing.Point(12, 81)
        Me.cmdShopCopy.Name = "cmdShopCopy"
        Me.cmdShopCopy.ShowFocusRect = False
        Me.cmdShopCopy.ShowOutline = False
        Me.cmdShopCopy.Size = New System.Drawing.Size(242, 60)
        Me.cmdShopCopy.StyleSetName = "TextButton"
        Me.cmdShopCopy.TabIndex = 559
        Me.cmdShopCopy.Tag = "Shop"
        Me.cmdShopCopy.Text = "Shop"
        Me.cmdShopCopy.UseAppStyling = False
        Me.cmdShopCopy.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        '
        'cmdKitchenCopy
        '
        Me.cmdKitchenCopy.Anchor = System.Windows.Forms.AnchorStyles.Top
        Appearance2.BackColor = System.Drawing.Color.Transparent
        Me.cmdKitchenCopy.Appearance = Appearance2
        Me.cmdKitchenCopy.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdKitchenCopy.Location = New System.Drawing.Point(12, 147)
        Me.cmdKitchenCopy.Name = "cmdKitchenCopy"
        Me.cmdKitchenCopy.ShowFocusRect = False
        Me.cmdKitchenCopy.ShowOutline = False
        Me.cmdKitchenCopy.Size = New System.Drawing.Size(242, 60)
        Me.cmdKitchenCopy.StyleSetName = "TextButton"
        Me.cmdKitchenCopy.TabIndex = 560
        Me.cmdKitchenCopy.TabStop = False
        Me.cmdKitchenCopy.Tag = "Kitchen"
        Me.cmdKitchenCopy.Text = "Kitchen"
        Me.cmdKitchenCopy.UseAppStyling = False
        Me.cmdKitchenCopy.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        '
        'cmdBothCopies
        '
        Me.cmdBothCopies.Anchor = System.Windows.Forms.AnchorStyles.Top
        Appearance3.BackColor = System.Drawing.Color.Transparent
        Me.cmdBothCopies.Appearance = Appearance3
        Me.cmdBothCopies.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdBothCopies.Location = New System.Drawing.Point(12, 213)
        Me.cmdBothCopies.Name = "cmdBothCopies"
        Me.cmdBothCopies.ShowFocusRect = False
        Me.cmdBothCopies.ShowOutline = False
        Me.cmdBothCopies.Size = New System.Drawing.Size(242, 60)
        Me.cmdBothCopies.StyleSetName = "TextButton"
        Me.cmdBothCopies.TabIndex = 561
        Me.cmdBothCopies.Tag = "Both"
        Me.cmdBothCopies.Text = "Both"
        Me.cmdBothCopies.UseAppStyling = False
        Me.cmdBothCopies.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        '
        'lblAddressLbl
        '
        Me.lblAddressLbl.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance4.BackColor = System.Drawing.Color.Transparent
        Appearance4.ForeColor = System.Drawing.Color.DimGray
        Appearance4.TextHAlignAsString = "Center"
        Me.lblAddressLbl.Appearance = Appearance4
        Me.lblAddressLbl.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAddressLbl.Location = New System.Drawing.Point(38, 24)
        Me.lblAddressLbl.Name = "lblAddressLbl"
        Me.lblAddressLbl.Size = New System.Drawing.Size(191, 51)
        Me.lblAddressLbl.StyleSetName = "TextEntryLabel"
        Me.lblAddressLbl.TabIndex = 562
        Me.lblAddressLbl.Text = "Which copy do you want to reprint?"
        Me.lblAddressLbl.UseAppStyling = False
        Me.lblAddressLbl.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdClose
        '
        Me.cmdClose.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Appearance5.BackColor = System.Drawing.Color.Transparent
        Appearance5.BackColor2 = System.Drawing.Color.Transparent
        Appearance5.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance5.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance5.BorderColor = System.Drawing.Color.Transparent
        Appearance5.BorderColor2 = System.Drawing.Color.Maroon
        Appearance5.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance5.ForeColor = System.Drawing.Color.White
        Appearance5.Image = CType(resources.GetObject("Appearance5.Image"), Object)
        Appearance5.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance5.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance5.TextVAlignAsString = "Bottom"
        Me.cmdClose.Appearance = Appearance5
        Me.cmdClose.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdClose.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance6.BackColor = System.Drawing.Color.DarkOrange
        Appearance6.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance6.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance6.BorderColor = System.Drawing.Color.Transparent
        Appearance6.ForeColor = System.Drawing.Color.Black
        Me.cmdClose.HotTrackAppearance = Appearance6
        Me.cmdClose.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdClose.Location = New System.Drawing.Point(101, 316)
        Me.cmdClose.Name = "cmdClose"
        Me.cmdClose.Padding = New System.Drawing.Size(15, 0)
        Appearance7.BackColor = System.Drawing.Color.OrangeRed
        Appearance7.BackColor2 = System.Drawing.Color.Tomato
        Appearance7.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance7.BorderColor = System.Drawing.Color.Transparent
        Me.cmdClose.PressedAppearance = Appearance7
        Me.cmdClose.ShowFocusRect = False
        Me.cmdClose.ShowOutline = False
        Me.cmdClose.Size = New System.Drawing.Size(64, 44)
        Me.cmdClose.StyleSetName = "StatusBar"
        Me.cmdClose.TabIndex = 563
        Me.cmdClose.Tag = "Return"
        Me.cmdClose.UseAppStyling = False
        Me.cmdClose.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdClose.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdClose.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'frmReprint
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(266, 372)
        Me.ControlBox = False
        Me.Controls.Add(Me.cmdClose)
        Me.Controls.Add(Me.lblAddressLbl)
        Me.Controls.Add(Me.cmdBothCopies)
        Me.Controls.Add(Me.cmdKitchenCopy)
        Me.Controls.Add(Me.cmdShopCopy)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Name = "frmReprint"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents cmdShopCopy As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdKitchenCopy As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdBothCopies As Infragistics.Win.Misc.UltraButton
    Friend WithEvents lblAddressLbl As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents cmdClose As Infragistics.Win.Misc.UltraButton
End Class
