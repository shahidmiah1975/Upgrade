﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBaseForm

    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim Appearance1 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance2 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance3 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Me.pnlBaseHeader = New Infragistics.Win.Misc.UltraPanel()
        Me.lblBaseHeader = New Infragistics.Win.Misc.UltraLabel()
        Me.lblBaseLabel = New Infragistics.Win.Misc.UltraLabel()
        Me.uplBasePanel = New Infragistics.Win.Misc.UltraPanel()
        Me.pnlBaseHeader.ClientArea.SuspendLayout()
        Me.pnlBaseHeader.SuspendLayout()
        Me.uplBasePanel.ClientArea.SuspendLayout()
        Me.uplBasePanel.SuspendLayout()
        Me.SuspendLayout()
        '
        'pnlBaseHeader
        '
        Appearance1.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.pnlBaseHeader.Appearance = Appearance1
        '
        'pnlBaseHeader.ClientArea
        '
        Me.pnlBaseHeader.ClientArea.Controls.Add(Me.lblBaseHeader)
        Me.pnlBaseHeader.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlBaseHeader.Location = New System.Drawing.Point(0, 0)
        Me.pnlBaseHeader.Name = "pnlBaseHeader"
        Me.pnlBaseHeader.Size = New System.Drawing.Size(984, 40)
        Me.pnlBaseHeader.StyleSetName = "Reservation"
        Me.pnlBaseHeader.TabIndex = 548
        Me.pnlBaseHeader.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblBaseHeader
        '
        Appearance2.BackColor = System.Drawing.Color.Transparent
        Appearance2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(120, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance2.TextVAlignAsString = "Middle"
        Me.lblBaseHeader.Appearance = Appearance2
        Me.lblBaseHeader.AutoSize = True
        Me.lblBaseHeader.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBaseHeader.Location = New System.Drawing.Point(3, 1)
        Me.lblBaseHeader.Name = "lblBaseHeader"
        Me.lblBaseHeader.Size = New System.Drawing.Size(115, 40)
        Me.lblBaseHeader.StyleSetName = "Reservation"
        Me.lblBaseHeader.TabIndex = 461
        Me.lblBaseHeader.Text = "ezMENU"
        Me.lblBaseHeader.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblBaseLabel
        '
        Appearance3.BorderColor = System.Drawing.Color.Silver
        Me.lblBaseLabel.Appearance = Appearance3
        Me.lblBaseLabel.BorderStyleInner = Infragistics.Win.UIElementBorderStyle.Solid
        Me.lblBaseLabel.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblBaseLabel.Location = New System.Drawing.Point(0, 0)
        Me.lblBaseLabel.Name = "lblBaseLabel"
        Me.lblBaseLabel.Size = New System.Drawing.Size(984, 1)
        Me.lblBaseLabel.TabIndex = 549
        '
        'uplBasePanel
        '
        '
        'uplBasePanel.ClientArea
        '
        Me.uplBasePanel.ClientArea.Controls.Add(Me.lblBaseLabel)
        Me.uplBasePanel.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.uplBasePanel.Location = New System.Drawing.Point(0, 634)
        Me.uplBasePanel.Name = "uplBasePanel"
        Me.uplBasePanel.Size = New System.Drawing.Size(984, 50)
        Me.uplBasePanel.TabIndex = 550
        '
        'frmBaseForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(984, 684)
        Me.ControlBox = False
        Me.Controls.Add(Me.uplBasePanel)
        Me.Controls.Add(Me.pnlBaseHeader)
        Me.DoubleBuffered = True
        Me.MinimumSize = New System.Drawing.Size(1000, 700)
        Me.Name = "frmBaseForm"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.pnlBaseHeader.ClientArea.ResumeLayout(False)
        Me.pnlBaseHeader.ClientArea.PerformLayout()
        Me.pnlBaseHeader.ResumeLayout(False)
        Me.uplBasePanel.ClientArea.ResumeLayout(False)
        Me.uplBasePanel.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents tmrCallPhone As System.Windows.Forms.Timer
    Friend WithEvents tmrTimer As System.Windows.Forms.Timer
    Friend WithEvents pnlBaseHeader As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents lblBaseLabel As Infragistics.Win.Misc.UltraLabel
    Public WithEvents uplBasePanel As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents lblBaseHeader As Infragistics.Win.Misc.UltraLabel
End Class
