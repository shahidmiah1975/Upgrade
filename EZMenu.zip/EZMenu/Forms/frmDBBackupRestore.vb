﻿Imports System.IO
Imports EZControls

Public Class frmDBBackupRestore

    Private strBackupFileName As String
    Private strFile1, strFile2, strFile3 As String
    Private strSunday1, strSunday2 As String
    Private strOnlineFilename, userName, userPassword As String

    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.

        strBackupFileName = AppPath() & "backup\ezdb" & Format(Now, "ddMMyyyy") & ".bak"
        strFile1 = AppPath() & "backup\ezdb1.bak"
        strFile2 = AppPath() & "backup\ezdb2.bak"
        strFile3 = AppPath() & "backup\ezdb3.bak"
        strSunday1 = AppPath() & "backup\ezdbsunday.bak"
        strSunday2 = AppPath() & "backup\ezdbsunday2.bak"
        strOnlineFilename = "ftp://u319135038@77.37.34.121/domains/shahidmiah.net/public_html/ezdatabases/" & objSecurity.AES_Decrypt(objDB.EZSettingRead("SystemID")).ToLower & ".dbb"
        userName = "u319135038"
        userPassword = "75Bracondale!"

    End Sub

    Public Sub PerformDBBackup()

        Try

            Show()

            Application.DoEvents()

            Dim strLastBackupDate As String = GetAppSettingCS("LastDBBackup", String.Empty)
            Dim blnDoAllBackup As Boolean = True

            If File.Exists(strBackupFileName) = True Then File.Delete(strBackupFileName)

            If IsDate(strLastBackupDate) AndAlso CDate(strLastBackupDate) = FormatEZDate(Now) Then
                blnDoAllBackup = False
            End If

            ShowInTempLabel("Performing database backup, please wait . . .")

            SQLQuery = $"BACKUP DATABASE [EZMENU] TO DISK = '{strBackupFileName}'"
            objDB.ExeNonQuery(SQLQuery)

            Application.DoEvents()

            If File.Exists(strBackupFileName) = True Then
                If blnDoAllBackup = True Then
                    If File.Exists(strFile3) Then File.Delete(strFile3)
                    If File.Exists(strFile2) Then File.Move(strFile2, strFile3)
                    If File.Exists(strFile1) Then File.Move(strFile1, strFile2)
                    Application.DoEvents()
                End If

                If File.Exists(strFile1) Then File.Delete(strFile1)
                Application.DoEvents()
                File.Move(strBackupFileName, strFile1)

                'do Sunday backup
                If Now.DayOfWeek = DayOfWeek.Sunday Then
                    If File.Exists(strSunday1) Then
                        If File.Exists(strSunday2) Then File.Delete(strSunday2)
                        File.Move(strSunday1, strSunday2)
                    End If
                    File.Copy(strFile1, strSunday1)
                End If

                'do online backup
                If GetAppSettingCS("OLDBBackup", True) Then
                    If GetAppSettingCS("OLDBBackupDay", "") = "Daily" OrElse (Now.DayOfWeek.ToString.ToUpper = GetAppSettingCS("OLDBBackupDay", "Sunday").ToString.ToUpper) Then

                        Dim conn As New EZService.ConnectivityService
                        If conn.IsInternetAvailable() Then
                            OnlineBackup(strFile1)
                        Else
                            strMsgBox = "Internet connection could not be detected, online backup will not be done."
                                Alert(strMsgBox, MessageBoxIcon.Exclamation)
                            End If
                        End If
                    End If

                ShowInTempLabel("Database backup successful.")

            Else
                Alert("Error encountered while backing up database. File '" & strBackupFileName & "' does not exist.")
            End If

            SaveAppSetting("LastDBBackup", FormatEZDate(Now))

        Catch ex As Exception
            DisplayError(ex)
            Dispose()
        End Try

    End Sub

    Public Sub PerformDBRestore()

        Try
            Application.DoEvents()

            Dim strRestoreName As String = String.Empty

            For iXnt As Short = 1 To 3
                tempStr = AppPath() & "backup\ezdb" & iXnt.ToString & ".bak"
                If File.Exists(tempStr) Then
                    strRestoreName = tempStr
                    Exit For
                End If
            Next

            'if not found then does a Sunday copy exist
            If strRestoreName = String.Empty Then
                If File.Exists(strSunday1) = True Then
                    strRestoreName = strSunday1
                ElseIf File.Exists(strSunday2) = True Then
                    strRestoreName = strSunday2
                End If
            End If

            If strRestoreName <> String.Empty AndAlso File.Exists(strRestoreName) Then
                strMsgBox = "You are about to restore the database to the last saved state. Any information " &
                            "currently in the database since then will be lost. Are you sure?"
                intMsgBoxResult = EZMsgBox.Show(strMsgBox, MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                Application.DoEvents()
                If intMsgBoxResult = MsgBoxResult.Yes Then
                    Show()
                    Application.DoEvents()
                    RestoreDB(strRestoreName)
                End If

                'restore from online
            ElseIf OnlineRestore() = True Then
                Application.DoEvents()
                RestoreDB(strFile1)

            Else
                DisplayError("No local or server copy of database found to restore.")

            End If

        Catch ex As Exception
            DisplayError(ex)
            Dispose()
        End Try

    End Sub

    Private Sub OnlineBackup(strFileToUpload As String)

        Try
            Dim fwrRequest As Net.FtpWebRequest = DirectCast(Net.WebRequest.Create(strOnlineFilename), Net.FtpWebRequest)
            fwrRequest.Credentials = New Net.NetworkCredential(userName, userPassword)
            fwrRequest.Method = Net.WebRequestMethods.Ftp.UploadFile

            Dim bFile() As Byte = File.ReadAllBytes(strFileToUpload)  'read in file...
            Dim iosStream As Stream = fwrRequest.GetRequestStream()   'upload file...

            ShowInTempLabel("Performing online database backup . . .")

            With pgbProgress
                .Name = "pgbUploadFile"
                .Text = "[Formatted]"
                .Style = Infragistics.Win.UltraWinProgressBar.ProgressBarStyle.Continuous
            End With

            Dim intStepsize As Integer = 50000
            Dim intPbVal
            For offset As Integer = 0 To bFile.Length Step intStepsize
                intPbVal = offset * pgbProgress.Maximum / bFile.Length
                pgbProgress.Value = intPbVal
                pgbProgress.CreateGraphics().DrawString(Decimal.Round(intPbVal, 1) & "%", New Font("Arial", 10, FontStyle.Regular),
                                                        Brushes.Black, New PointF(pgbProgress.Width / 2 - 10, pgbProgress.Height / 2 - 8))
                Dim chunkSize As Integer = bFile.Length - offset - 1
                If chunkSize > intStepsize Then chunkSize = intStepsize
                iosStream.Write(bFile, offset, chunkSize)
                Application.DoEvents()
            Next
            pgbProgress.Value = pgbProgress.Maximum
            Application.DoEvents()
            iosStream.Close()
            iosStream.Dispose()

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Function OnlineRestore() As Boolean

        Dim request As New Net.WebClient With {
            .Credentials = New Net.NetworkCredential(userName, userPassword)
        }

        Show()

        ShowInTempLabel("No local backup found." & vbCrLf & "Downloading database from server...")

        Try
            'Read the file data into a Byte array
            Dim bytes() As Byte = request.DownloadData(strOnlineFilename)

            '  Create a FileStream to read the file into
            Dim fsDownload As FileStream = File.Create(strFile1)
            '  Stream this data into the file
            fsDownload.Write(bytes, 0, bytes.Length)
            '  Close the FileStream
            fsDownload.Close()

            ShowInTempLabel("Download successful.")

            Return True

        Catch ex As Exception
            ShowInTempLabel(ex.Message)
            DisplayError(ex)
            Return False

        Finally
            request.Dispose()

        End Try

    End Function

    Private Function RestoreDB(FileToRestore As String)

        Try
            ShowInTempLabel("Performing database restore, please wait . . .")
            SQLQuery = $"USE MASTER; RESTORE DATABASE [EZMENU] FROM DISK = '{FileToRestore}'"
            objDB.ExeNonQuery(SQLQuery)

            If blnSQLSuccess = True Then
                ShowInTempLabel("Database successfully restored to last saved version.")
            Else
                DisplayError("Error in restoring database.")
            End If

            Return True

        Catch ex As Exception
            DisplayError(ex)
            Return False
        End Try

    End Function

    Private Function GetMyID() As String

        Dim myID = objDB.EZSettingRead("SystemID")

        If myID = String.Empty Then
            Return "EZTANDOORI".ToLower
        Else
            Return objSecurity.AES_Decrypt(myID).ToLower
        End If

    End Function

    Private Sub ShowInTempLabel(strMessage As String)

        lblMessage.Text = strMessage
        lblMessage.Refresh()
        Application.DoEvents()
        Sleep(1500)

    End Sub

End Class

