﻿Imports Infragistics.Win.UltraWinDataSource
Imports EZControls

Public Class frmDishesHistory

    Private Sub frmDishesHistory_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Size = New Size(1000, 730)
        CenterToParent()

        txtEndDate.Text = FormatEZDate(Now)
        txtStartDate.Text = FormatEZDate(Now.AddMonths(-1))

        Try
            ShowAllHistory()

        Catch ex As Exception

            MsgBox(ex.Message)

        End Try

    End Sub

    Private Sub cmdOEHome_Click(sender As Object, e As EventArgs) Handles cmdOEHome.Click
        Close()
    End Sub

    Private Sub cmdOK_Click(sender As Object, e As EventArgs) Handles cmdOK.Click

        udsDishesHistory.Rows.Clear()

        If Not IsDate(txtStartDate.Text) Then
            strMsgBox = "Invalid start date specified"
            EZMsgBox.Show(strMsgBox, MessageBoxIcon.Asterisk)
            txtStartDate.Focus()
        ElseIf Not IsDate(txtEndDate.Text) Then
            strMsgBox = "Invalid end date specified"
            EZMsgBox.Show(strMsgBox, MessageBoxIcon.Asterisk)
            txtEndDate.Focus()
        ElseIf txtStartDate.Text > CDate(txtEndDate.Text) Then
            strMsgBox = "The dates specified are invalid: the start date cannot be later than the end date"
            EZMsgBox.Show(strMsgBox, MessageBoxIcon.Error)
            Exit Sub
        Else
            ugdDishesHistory.DisplayLayout.Bands(0).Columns("Date").Hidden = True
            SQLQuery = String.Format("SELECT TDish, SUM(TPickup) AS TPickup, SUM(TDelivery) AS TDelivery, SUM(TTable) AS TTable " &
                        "FROM DishHistory " &
                        "WHERE TDATE BETWEEN '{0}' AND '{1}' " &
                        "GROUP BY TDish " &
                        "ORDER BY TDish", Format(CDate(txtStartDate.Text), "dd/MMM/yyyy"), Format(CDate(txtEndDate.Text), "dd/MMM/yyyy"))

            drcDatarowCollection = objDB.GetDataRows(SQLQuery)
            If drcDatarowCollection IsNot Nothing Then
                For Each myRow As DataRow In drcDatarowCollection
                    Dim udrRow As UltraDataRow = udsDishesHistory.Rows.Add
                    udrRow.Item("Dish") = myRow("TDish")
                    udrRow.Item("Pickup") = myRow("TPickup")
                    udrRow.Item("Delivery") = myRow("TDelivery")
                    udrRow.Item("Table") = myRow("TTable")
                    udrRow.Item("Total") = myRow("TPickup") + myRow("TDelivery") + myRow("TTable")
                Next
            End If

        End If

        ugdDishesHistory.DataSource = udsDishesHistory
        lblNumRecords.Text = "Number of records: " & ugdDishesHistory.Rows.Count & "  " & lblNumRecords.Tag

    End Sub

    Private Sub cmdKBPrintStart_Click(sender As Object, e As EventArgs) Handles cmdKBPrintStart.Click

        Dim strDate As String = EZDatePicker.SelectedDate
        If strDate <> String.Empty Then
            txtStartDate.Text = FormatEZDate(strDate)
        End If

    End Sub

    Private Sub cmdKBPrintEnd_Click(sender As Object, e As EventArgs) Handles cmdKBPrintEnd.Click

        Dim strDate As String = EZDatePicker.SelectedDate
        If strDate <> String.Empty Then
            txtEndDate.Text = FormatEZDate(strDate)
        End If

    End Sub

    Private Sub ShowAllHistory()

        udsDishesHistory.Rows.Clear()

        SQLQuery = "SELECT TOP 1000 * FROM DishHistory"
        drcDatarowCollection = objDB.GetDataRows(SQLQuery)
        If drcDatarowCollection IsNot Nothing Then
            ugdDishesHistory.DisplayLayout.Bands(0).Columns("Date").Hidden = False
            For Each myRow As DataRow In drcDatarowCollection
                Dim udrRow As UltraDataRow = udsDishesHistory.Rows.Add
                udrRow.Item("Date") = myRow("TDate")
                udrRow.Item("Dish") = myRow("TDish")
                udrRow.Item("Pickup") = myRow("TPickup")
                udrRow.Item("Delivery") = myRow("TDelivery")
                udrRow.Item("Table") = myRow("TTable")
                udrRow.Item("Total") = myRow("TPickup") + myRow("TDelivery") + myRow("TTable")
            Next
        End If

        ugdDishesHistory.DataSource = udsDishesHistory
        lblNumRecords.Text = "Number of records: " & ugdDishesHistory.Rows.Count & "  " & lblNumRecords.Tag

    End Sub

    Private Sub cmdClear_Click(sender As Object, e As EventArgs) Handles cmdClear.Click

        ShowAllHistory()

    End Sub

    Private Sub cmdDelHistoryAll_Click(sender As Object, e As EventArgs) Handles cmdDelHistoryAll.Click

        Try
            strMsgBox = "You are about to delete all the history records in the database. You will not be able to retrieve these again. " &
                "Are you sure?"

            intMsgBoxResult = EZMsgBox.Show(strMsgBox.ToUpper, MessageBoxButtons.YesNo, MessageBoxIcon.Warning)

            If intMsgBoxResult = MsgBoxResult.Yes Then
                SQLQuery = "DELETE FROM DishHistory"
                objDB.ExeNonQuery(SQLQuery)
                ShowAllHistory()
            End If

        Catch ex As Exception

            strMsgBox = ex.Message
            EZMsgBox.Show(strMsgBox, MessageBoxIcon.Error)

        End Try

    End Sub

    Private Sub cmdDelHistoryDated_Click(sender As Object, e As EventArgs) Handles cmdDelHistoryDated.Click

        Try

            If Not IsDate(txtStartDate.Text) Then
                strMsgBox = "Invalid start date specified"
                EZMsgBox.Show(strMsgBox, MessageBoxIcon.Asterisk)
                txtStartDate.Focus()
                Exit Sub
            ElseIf Not IsDate(txtEndDate.Text) Then
                strMsgBox = "Invalid end date specified"
                EZMsgBox.Show(strMsgBox, MessageBoxIcon.Asterisk)
                txtEndDate.Focus()
                Exit Sub
            ElseIf txtStartDate.Text > CDate(txtEndDate.Text) Then
                strMsgBox = "The dates specified are invalid: the start date cannot be later than the end date"
                EZMsgBox.Show(strMsgBox, MessageBoxIcon.Error)
                Exit Sub
            End If

            strMsgBox = String.Format("You are about to delete all the history records dated between {0} and {1}. " &
                "You will not be able to retrieve these again. Are you sure?", txtStartDate.Text, txtEndDate.Text)

            intMsgBoxResult = EZMsgBox.Show(strMsgBox.ToUpper, MessageBoxButtons.YesNo, MessageBoxIcon.Warning)

            If intMsgBoxResult = MsgBoxResult.Yes Then
                SQLQuery = "DELETE FROM DishHistory WHERE TDate BETWEEN '" & Format(CDate(txtStartDate.Text), "dd/MMM/yyyy") & "' AND '" & Format(CDate(txtEndDate.Text), "dd/MMM/yyyy") & "'"
                objDB.ExeNonQuery(SQLQuery)
                ShowAllHistory()
            End If

        Catch ex As Exception

            strMsgBox = ex.Message
            EZMsgBox.Show(strMsgBox, MessageBoxIcon.Error)

        End Try

    End Sub

    'Declare the variables
    Dim drag As Boolean
    Dim mousex As Integer
    Dim mousey As Integer

    Private Sub Form1_MouseDown(sender As Object, e As MouseEventArgs) Handles Me.MouseDown
        drag = True 'Sets the variable drag to true.
        mousex = Cursor.Position.X - Left 'Sets variable mousex
        mousey = Cursor.Position.Y - Top 'Sets variable mousey
    End Sub

    Private Sub Form1_MouseMove(sender As Object, e As MouseEventArgs) Handles Me.MouseMove
        'If drag is set to true then move the form accordingly.
        If drag Then
            Top = Cursor.Position.Y - mousey
            Left = Cursor.Position.X - mousex
        End If
    End Sub

    Private Sub Form1_MouseUp(sender As Object, e As MouseEventArgs) Handles Me.MouseUp
        drag = False 'Sets drag to false, so the form does not move according to the code in MouseMove
    End Sub

End Class