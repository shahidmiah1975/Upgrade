﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAbout
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub


    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmAbout))
        Me.cmdOK = New Infragistics.Win.Misc.UltraButton()
        Me.lblDisclaimer = New System.Windows.Forms.Label()
        Me.lblVersion = New System.Windows.Forms.Label()
        Me.lblLicensedTo = New System.Windows.Forms.Label()
        Me.lblSerial = New System.Windows.Forms.Label()
        Me.tmrTimer = New System.Windows.Forms.Timer(Me.components)
        Me.cmdInfo = New Infragistics.Win.Misc.UltraButton()
        Me.SuspendLayout()
        '
        'cmdOK
        '
        Me.cmdOK.Location = New System.Drawing.Point(493, 350)
        Me.cmdOK.Name = "cmdOK"
        Me.cmdOK.ShowFocusRect = False
        Me.cmdOK.ShowOutline = False
        Me.cmdOK.Size = New System.Drawing.Size(90, 35)
        Me.cmdOK.TabIndex = 517
        Me.cmdOK.Text = "OK"
        Me.cmdOK.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        '
        'lblDisclaimer
        '
        Me.lblDisclaimer.BackColor = System.Drawing.Color.Transparent
        Me.lblDisclaimer.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDisclaimer.ForeColor = System.Drawing.Color.LightGray
        Me.lblDisclaimer.Location = New System.Drawing.Point(34, 315)
        Me.lblDisclaimer.Name = "lblDisclaimer"
        Me.lblDisclaimer.Size = New System.Drawing.Size(387, 70)
        Me.lblDisclaimer.TabIndex = 518
        Me.lblDisclaimer.Text = "lblDisclaimer"
        '
        'lblVersion
        '
        Me.lblVersion.BackColor = System.Drawing.Color.Transparent
        Me.lblVersion.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblVersion.ForeColor = System.Drawing.Color.LightGray
        Me.lblVersion.Location = New System.Drawing.Point(270, 133)
        Me.lblVersion.Name = "lblVersion"
        Me.lblVersion.Size = New System.Drawing.Size(255, 42)
        Me.lblVersion.TabIndex = 519
        Me.lblVersion.Text = "<Version Number>"
        Me.lblVersion.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblLicensedTo
        '
        Me.lblLicensedTo.BackColor = System.Drawing.Color.Transparent
        Me.lblLicensedTo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblLicensedTo.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLicensedTo.ForeColor = System.Drawing.Color.White
        Me.lblLicensedTo.Location = New System.Drawing.Point(35, 213)
        Me.lblLicensedTo.Name = "lblLicensedTo"
        Me.lblLicensedTo.Size = New System.Drawing.Size(525, 73)
        Me.lblLicensedTo.TabIndex = 521
        Me.lblLicensedTo.Text = "lblLicensedTo"
        Me.lblLicensedTo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblSerial
        '
        Me.lblSerial.BackColor = System.Drawing.Color.Transparent
        Me.lblSerial.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSerial.ForeColor = System.Drawing.Color.White
        Me.lblSerial.Location = New System.Drawing.Point(39, 262)
        Me.lblSerial.Name = "lblSerial"
        Me.lblSerial.Size = New System.Drawing.Size(517, 20)
        Me.lblSerial.TabIndex = 523
        Me.lblSerial.Text = "<serial number>"
        Me.lblSerial.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'tmrTimer
        '
        Me.tmrTimer.Enabled = True
        Me.tmrTimer.Interval = 2000
        '
        'cmdInfo
        '
        Me.cmdInfo.Location = New System.Drawing.Point(493, 309)
        Me.cmdInfo.Name = "cmdInfo"
        Me.cmdInfo.ShowFocusRect = False
        Me.cmdInfo.ShowOutline = False
        Me.cmdInfo.Size = New System.Drawing.Size(90, 35)
        Me.cmdInfo.TabIndex = 524
        Me.cmdInfo.Text = "Info"
        Me.cmdInfo.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        '
        'frmAbout
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(595, 397)
        Me.Controls.Add(Me.cmdInfo)
        Me.Controls.Add(Me.lblSerial)
        Me.Controls.Add(Me.lblVersion)
        Me.Controls.Add(Me.lblDisclaimer)
        Me.Controls.Add(Me.cmdOK)
        Me.Controls.Add(Me.lblLicensedTo)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmAbout"
        Me.Padding = New System.Windows.Forms.Padding(9)
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frmAbout"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents cmdOK As Infragistics.Win.Misc.UltraButton
    Friend WithEvents lblDisclaimer As System.Windows.Forms.Label
    Friend WithEvents lblVersion As System.Windows.Forms.Label
    Friend WithEvents lblLicensedTo As System.Windows.Forms.Label
    Friend WithEvents lblSerial As System.Windows.Forms.Label
    Friend WithEvents tmrTimer As System.Windows.Forms.Timer
    Friend WithEvents cmdInfo As Infragistics.Win.Misc.UltraButton

End Class
