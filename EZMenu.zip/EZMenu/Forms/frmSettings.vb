﻿Imports System.Drawing.Printing
Imports EZControls
Imports System.IO

Public Class frmSettings

    Dim blnBoxIsDirty As Boolean
    Dim strGroupingGap As String = "-  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -"
    Dim intCuisinePrintersIndex As Short
    Dim intCuisineLabelPrinterIndex As Integer

    Private Sub frmSettings_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Height = Owner.Height * 0.95
        CenterToParent()

        LoadAllSettings()

        'set the first tab
        utcSettings.SelectedTab = utcSettings.Tabs("General")

        Cursor.Show()

    End Sub

    Private Sub cmdCancel_Click(sender As Object, e As EventArgs) Handles cmdCancel.Click

        If blnBoxIsDirty = True Then
            strMsgBox = "Do you wish save the changes made?"
            intResponseBox = EZMsgBox.Show(strMsgBox, MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question)
            If intResponseBox = vbYes Then
                cmdSaveGroups_Click(sender, e)
            ElseIf intResponseBox = vbCancel Then
                Exit Sub
            End If
        End If

        If GetAppSettingCS("DisableCursor", True) = True Then Cursor.Hide() Else Cursor.Show()

        Close()

    End Sub

    Private Sub cmdSave_Click(sender As Object, e As EventArgs) Handles cmdSave.Click
        'save any changes made to the DB

        lblSaving.Visible = True
        Application.DoEvents()

        Try

#Region "General tab"

            '********** GENERAL TAB **********

            'chutneys & pickles
            If txtCAP.Text = String.Empty Then txtCAP.Text = 0
            If Not IsANumber(txtCAP.Text) Then
                utcSettings.SelectedTab = utcSettings.Tabs("General")
                SelectText(txtCAP)
                strMsgBox = "This is not a valid amount. Enter a valid amount for chutneys & pickles."
                Alert(strMsgBox)
                Exit Sub
            End If

            If chkCAP.Checked = True And txtCAP.Text = 0 Then
                utcSettings.SelectedTab = utcSettings.Tabs("General")
                SelectText(txtCAP)
                strMsgBox = "This is not a valid amount. Enter a valid amount for chutneys & pickles."
                Alert(strMsgBox)
                Exit Sub
            End If

            txtCAP.Text = Int(Val(txtCAP.Text))
            SaveAppSetting("CAPStatus", Val(chkCAP.Checked))
            SaveAppSetting("CAPValue", txtCAP.Text)

            SaveAppSetting("ExtraStarterSpace", chkExtraGap.Checked)
            SaveAppSetting("ShowLabelText", chkShowLabelText.Checked)

            SaveAppSetting("DisableCursor", chkDisableCursor.Checked)
            If chkDisableCursor.Checked Then Cursor.Hide() Else Cursor.Show()

            SaveAppSetting("PasswordTotals", chkPasswordTakings.Checked)
            SaveAppSetting("SaveDishHistory", chkSaveDishHistory.Checked)
            SaveAppSetting("SaveCustomerHistory", chkSaveCustomerHistory.Checked)
            SaveAppSetting("ShowHomeAfterPrint", chkShowHomeAfterPrint.Checked)
            SaveAppSetting("AutoMarkPaid", chkAutoMarkAsPaid.Checked)
            SaveAppSetting("ShowMinimiseButton", chkShowMinimise.Checked)
            frmOpener.cmdMinimise.Visible = chkShowMinimise.Checked
            SaveAppSetting("ShowFirstOrdered", chkFirstOrdered.Checked)
            SaveAppSetting("ShowLastOrdered", chkLastOrdered.Checked)
            SaveAppSetting("ShowCustomersOrders", chkNumberOrdered.Checked)
            SaveAppSetting("AutoSplitPayment", Val(chkAutoCashCard.Checked))
            SaveAppSetting("AutoDeleteOrders", Val(chkAutoDelPastOrders.Checked))
            SaveAppSetting("CenterMainForm", Val(chkCenterMainForm.Checked))
            SaveAppSetting("IsPartOfMultiSystem", chkPartOfMultiSystem.Checked)
            If chkPartOfMultiSystem.Checked = True Then
                If optMainSubSystem.Value = "MAIN" Then
                    SaveAppSetting("MultiSystemIsMain", True)
                Else
                    SaveAppSetting("MultiSystemIsMain", False)
                End If
            End If
            SaveAppSetting("IsTabletPC", Val(chkIsTabletPC.Checked))

#End Region

#Region "Deliver and Collection tab"

            ''********** DELIVERY & COLLECTION TAB **********

            'make sure amt is entered if checkbox is ticked
            If chkDelivCharge.Checked = True Then
                If txtDeliv.Text.Trim = "" Then
                    utcSettings.SelectedTab = utcSettings.Tabs("DelivColn")
                    strMsgBox = "You need to enter an amount in this box."
                    Alert(strMsgBox, MessageBoxIcon.Information)
                    SelectText(txtDeliv)
                    Exit Sub
                ElseIf Not IsANumber(txtDeliv.Text) Then
                    utcSettings.SelectedTab = utcSettings.Tabs("DelivColn")
                    strMsgBox = "This is not a valid amount. Check the input and enter a number."
                    Alert(strMsgBox, MessageBoxIcon.Information)
                    SelectText(txtDeliv)
                    Exit Sub
                End If

                If chkDelivUnder.Checked = True Then
                    If txtDelivUnder.Text.Trim = "" Then
                        utcSettings.SelectedTab = utcSettings.Tabs("DelivColn")
                        strMsgBox = "You need to enter an amount in the box"
                        Alert(strMsgBox, MessageBoxIcon.Information)
                        SelectText(txtDelivUnder)
                        Exit Sub
                    ElseIf Not IsANumber(txtDelivUnder.Text) Then
                        utcSettings.SelectedTab = utcSettings.Tabs("DelivColn")
                        strMsgBox = "This is not a valid amount. Check the input and enter a number."
                        Alert(strMsgBox, MessageBoxIcon.Information)
                        SelectText(txtDelivUnder)
                        Exit Sub
                    End If
                End If
            End If

            If chkGiveDiscount.Checked = True Then
                If txtDiscount.Text.Trim = "" Then
                    utcSettings.SelectedTab = utcSettings.Tabs("DelivColn")
                    strMsgBox = "You need to enter an amount in this box."
                    Alert(strMsgBox, MessageBoxIcon.Information)
                    SelectText(txtDiscount)
                    Exit Sub
                ElseIf Not IsANumber(txtDiscount.Text) Then
                    utcSettings.SelectedTab = utcSettings.Tabs("DelivColn")
                    strMsgBox = "This is not a valid amount. Check the input and enter a number."
                    Alert(strMsgBox, MessageBoxIcon.Information)
                    Exit Sub
                End If

                If chkDiscountExc.Checked = True Then
                    If txtDiscountExc.Text.Trim = "" Then
                        utcSettings.SelectedTab = utcSettings.Tabs("DelivColn")
                        strMsgBox = "You need to enter an amount in this box."
                        Alert(strMsgBox, MessageBoxIcon.Information)
                        SelectText(txtDiscountExc)
                        Exit Sub
                    ElseIf Not IsANumber(txtDelivUnder.Text) Then
                        utcSettings.SelectedTab = utcSettings.Tabs("DelivColn")
                        strMsgBox = "This is not a valid amount. Check the input and enter a number."
                        Alert(strMsgBox, MessageBoxIcon.Information)
                        SelectText(txtDiscountExc)
                        Exit Sub
                    End If
                End If
            End If

            'deliv charge
            GlobalCharges.CheckEnabled = chkDelivCharge.Checked
            GlobalCharges.Value = CDec(Val(txtDeliv.Text))
            GlobalCharges.AorP = optDeliv.Value
            GlobalCharges.AmtChkEnabled = chkDelivUnder.Checked
            GlobalCharges.AmtValue = Val(txtDelivUnder.Text)

            'discount
            GlobalDiscounts.CheckEnabled = chkGiveDiscount.Checked
            GlobalDiscounts.Value = CDec(Val(txtDiscount.Text))
            GlobalDiscounts.AorP = optDiscount.Value
            GlobalDiscounts.AmtChkEnabled = chkDiscountExc.Checked
            GlobalDiscounts.AmtValue = Val(txtDiscountExc.Text)

            txtDeliv.Text = Replace(Replace(txtDeliv.Text, "£", ""), "%", "")
            txtDiscount.Text = Replace(Replace(txtDiscount.Text, "£", ""), "%", "")

            SaveAppSetting("AllChargesCheck", GlobalCharges.CheckEnabled)
            SaveAppSetting("AllChargesAmount", GlobalCharges.Value)
            SaveAppSetting("AllChargesAorP", GlobalCharges.AorP)
            SaveAppSetting("AllChargesAmtExcChk", GlobalCharges.AmtChkEnabled)
            SaveAppSetting("AllChargesAmtExcVal", GlobalCharges.AmtValue)

            SaveAppSetting("AllDiscountsCheck", GlobalDiscounts.CheckEnabled)
            SaveAppSetting("AllDiscountsAmount", GlobalDiscounts.Value)
            SaveAppSetting("AllDiscountsAorP", GlobalDiscounts.AorP)
            SaveAppSetting("AllDiscountsAmtExcChk", GlobalDiscounts.AmtChkEnabled)
            SaveAppSetting("AllDiscountsAmtExcVal", GlobalDiscounts.AmtValue)

            SaveAppSetting("MinDeliveryChecked", Val(chkMinOrderAmount.Checked))
            If chkMinOrderAmount.Checked = True Then
                If Not IsANumber(txtMinOrderAmount.Text) Then
                    utcSettings.SelectedTab = utcSettings.Tabs("DelivColn")
                    strMsgBox = "Invalid input for minimum delivery"
                    Alert(strMsgBox, MessageBoxIcon.Asterisk)
                    SelectText(txtMinOrderAmount)
                    Exit Sub
                End If
                SaveAppSetting("MinDeliveryAmount", txtMinOrderAmount.Text)
            End If

            SaveAppSetting("LastDeliveryChecked", Val(chkDTime.Checked))
            If chkDTime.Checked = True Then
                If Not IsDate(txtDTime.Text) Then
                    utcSettings.SelectedTab = utcSettings.Tabs("DelivColn")
                    strMsgBox = "Invalid input for last delivery time"
                    Alert(strMsgBox, MessageBoxIcon.Asterisk)
                    SelectText(txtDTime)
                    Exit Sub
                End If
                SaveAppSetting("LastDeliveryTime", txtDTime.Text)
            End If

            SaveAppSetting("MyPostcode", txtMyPostcode.Text.ToUpper)

#End Region

#Region "Discount and charges tab"

            '********** DISCOUNTS & CHARGES TAB **********

            SaveAppSetting("RoundingMethod", Val(chkRoundingMethod.Checked))

#End Region

#Region "Phone tab"

            '********** PHONE TAB **********

            SaveAppSetting("TruncPhNum1", txtPhTrim1.Text.Trim)
            SaveAppSetting("TruncPhNum2", txtPhTrim2.Text.Trim)
            SaveAppSetting("TruncPhNum3", txtPhTrim3.Text.Trim)
            SaveAppSetting("TruncPhLen1", txtPhLen1.Text.Trim)
            SaveAppSetting("TruncPhLen2", txtPhLen2.Text.Trim)
            SaveAppSetting("TruncPhLen3", txtPhLen3.Text.Trim)

            'ActiveCID settings
            If chkEnableActiveCID.Checked = True Then
                'make sure COM port is set
                If cmbActiveCIDPort.SelectedIndex < 0 Then
                    strMsgBox = "Select a COM port to which CTI Meteor is connected"
                    Alert(strMsgBox, MessageBoxIcon.Asterisk)
                    Exit Sub
                Else
                    SaveAppSetting("ActiveCIDPort", (cmbActiveCIDPort.SelectedIndex + 1))
                End If
            End If
            SaveAppSetting("EnableActiveCID", Val(chkEnableActiveCID.Checked))
            frmOpener.cmdShowCID.Enabled = chkEnableActiveCID.Checked
            SaveAppSetting("HideCIDWhenNoCID", Val(chkDoNotShowCID.Checked))

            If optCometMeteor.Value = "Comet" Then
                SaveAppSetting("CTIType", "Comet")
            Else
                SaveAppSetting("CTIType", "Meteor")
            End If

#End Region

#Region "Header and footer tab"

            '********** HEADER TAB **********

            SaveAppSetting("PrintHead1", txtHeader1.Text)
            SaveAppSetting("PrintHead2", txtHeader2.Text)
            SaveAppSetting("PrintHead3", txtHeader3.Text)
            SaveAppSetting("PrintHead4", txtHeader4.Text)
            SaveAppSetting("PrintHead5", txtHeader5.Text)
            SaveAppSetting("PrintHead6", txtHeader6.Text)
            SaveAppSetting("FooterText", txtFooter.Text.Trim)

#End Region

#Region "Dishes tab"

            '********** DISHES TAB **********

            SaveAppSetting("DishesUseConcise", Val(chkDishesUseConcise.Checked))
            SaveAppSetting("DishesUseSimpleName", Val(chkDishesSimpleName.Checked))
            SaveAppSetting("DishesUppercase", Val(chkDishesUppercase.Checked))

            txtPortionSmall.Text = txtPortionSmall.Text.Trim
            If txtPortionSmall.Text = String.Empty Then txtPortionSmall.Text = "[S]"
            txtPortionLarge.Text = txtPortionLarge.Text.Trim
            If txtPortionLarge.Text = String.Empty Then txtPortionLarge.Text = "[L]"
            SaveAppSetting("PortionSmall", " " & txtPortionSmall.Text)
            SaveAppSetting("PortionLarge", " " & txtPortionLarge.Text)

#End Region

#Region "Modifiers tab"

            '********** MODIFIERS TAB **********

            SaveAppSetting("DisablePriceChangeInMod", Val(chkDisableCostChange.Checked))
            SaveAppSetting("PrintZeroCost", Val(chkZeroCost.Checked))
            SaveAppSetting("ModLabelPrinter", Val(chkShowModLabelPrinter.Checked))

#End Region

#Region "Printers tab"

            '********** PRINTERS TAB **********

            'The routine for printers tab is handled by cmdSavePrinters.Click proc
#End Region

#Region "Label Printer tab"

            '********** LABEL PRINTER TAB **********

            'The routine for label printers tab is handled by cmdSaveLabelPrinters_Click proc

#End Region

#Region "Print Settings / More Print Settings tab"

            '********** PRINT SETTINGS TAB **********

            SaveAppSetting("PrintKitchenCard", chkKitchenCard.Checked)
            SaveAppSetting("PrintKitchenDate", chkKitchenDate.Checked)
            SaveAppSetting("PrintKitchenItem", chkKitchenItem.Checked)
            SaveAppSetting("PrintKitchenTime", chkKitchenTime.Checked)
            SaveAppSetting("PrintKitchenTotal", chkKitchenTotal.Checked)

            SaveAppSetting("PrintShopCard", chkShopCard.Checked)
            SaveAppSetting("PrintShopDate", chkShopDate.Checked)
            SaveAppSetting("PrintShopItem", chkShopItem.Checked)
            SaveAppSetting("PrintShopTime", chkShopTime.Checked)
            SaveAppSetting("PrintShopTotal", chkShopTotal.Checked)

            SaveAppSetting("LNSNOnscreen", optOnScreen.Value)
            SaveAppSetting("LNSNCustomer", optCustomer.Value)
            SaveAppSetting("LNSNKitchen", optKitchen.Value)

            SaveAppSetting("PrintServiceCharge", Val(chkServiceCharge.Checked))
            SaveAppSetting("DrinksAndFoodGrouped", Val(chkDrinksFoodGrouped.Checked))
            SaveAppSetting("DrinksItemise", Val(chkDrinksItemise.Checked))
            SaveAppSetting("DrinksFoodSeparatePrice", Val(chkDrinksFoodSeparatePrice.Checked))
            SaveAppSetting("DrinksAndFoodGap", Val(chkDrinksAndFoodGap.Checked))
            SaveAppSetting("DishesGapKitchen", Val(chkKitchenGap.Checked))
            SaveAppSetting("DrinksHeader", Val(chkDrinksHeader.Checked))
            SaveAppSetting("SimultaneousPrinting", Val(chkSimultaneousPrinting.Checked))
            SaveAppSetting("SameSKHeader", Val(chkSameSKHeader.Checked))
            SaveAppSetting("FontSizeShop", cmbFontSizeShop.Text)
            SaveAppSetting("FontSizeKitchen", cmbFontSizeKitchen.Text)
            SaveAppSetting("FontSizeKitchenAddress", cmbFontSizeKitchenAddress.Text)
            SaveAppSetting("KitchenHeaderText", txtKitchenHeaderText.Text)
            SaveAppSetting("FontSizePaid", cmbPaidFontSize.Text)
            SaveAppSetting("PaidLocation", cmbPaidLocation.Text)

            SaveAppSetting("FoodLabelOnReceipt", txtFoodLabel.Text.Trim)
            SaveAppSetting("DrinksLabelOnReceipt", txtDrinksLabel.Text.Trim)
            SaveAppSetting("PaperWidth", txtPaperWidth.Text.Trim)
            SaveAppSetting("RightOffset", txtRightOffset.Text.Trim)
            SaveAppSetting("CentreOffset", txtCentreOffset.Text.Trim)
            SaveAppSetting("KitchenCopyTopOffset", txtKitchenTopOffset.Text.Trim)
            SaveAppSetting("ShopCopyTopOffset", txtShopTopOffset.Text.Trim)
            SaveAppSetting("MinPaperS", txtMinPaperLengthShop.Text.Trim)
            SaveAppSetting("MinPaperK", txtMinPaperLengthKitchen.Text.Trim)

#End Region

#Region "Tables tab"

            '********** TABLES TAB **********

            'changed number of tables
            If cmbNumTables.Text <> GetAppSettingCS("NumberOfTables", 20) Then
                SaveAppSetting("NumberOfTables", cmbNumTables.Text)
                If objTables IsNot Nothing Then objTables.Dispose()     'this will reload the form and redraw the tables!!
            End If

            SaveAppSetting("TablesExtMode", chkTableExtMode.Checked)
            SaveAppSetting("TablesExtLights", chkTableExtLights.Checked)
            SaveAppSetting("TablesExtLine1", txtTableExtLine1.Text.Trim)
            SaveAppSetting("TablesExtLine2", txtTableExtLine2.Text.Trim)
            SaveAppSetting("TablesExtLine3", txtTableExtLine3.Text.Trim)
            SaveAppSetting("TablesAutoCovers", chkTableAutoCovers.Checked)

#End Region

#Region "Summary tab"

            '********** SUMMARY TAB **********

            SaveAppSetting("SummaryCDTTotals", Val(chkSummaryCDTTotals.Checked))
            SaveAppSetting("SummaryPrintDate", Val(chkSummaryPrintDate.Checked))

#End Region

#Region "Manager tab"

            '********** MANAGER TAB **********

            SaveAppSetting("XAccessManager", Val(chkXAccessManager.Checked))
            SaveAppSetting("XOrderDelete", Val(chkXOrderDelete.Checked))
            SaveAppSetting("XOrderEdit", Val(chkXOrderEdit.Checked))
            SaveAppSetting("XOrderReprint", Val(chkXOrderReprint.Checked))
            SaveAppSetting("XOrderTotals", Val(chkXOrderTotals.Checked))
            SaveAppSetting("XOrders", Val(chkXOrders.Checked))
            SaveAppSetting("XClearOrders", Val(chkXClearOrders.Checked))
            SaveAppSetting("XAccessSummary", Val(chkXAccessSummary.Checked))
            SaveAppSetting("XAccessBanking", Val(chkXAccessBanking.Checked))
            SaveAppSetting("XClearOnExit", Val(chkXClearOnExit.Checked))

#End Region

#Region "Set meals tab"

            '********** SET MEALS TAB **********

            SaveAppSetting("SetPutQty", chkSetPutQty.Checked)

#End Region

#Region "Online tab"

            '********** ONLINE TAB **********

            SaveAppSetting("OLEnabled", Val(chkEnableOnline.Checked))
            If lstOnline.Items.Count = 0 Then SaveAppSetting("OLEnabled", 0)
            SaveAppSetting("OLPrintoutText", txtOLText.Text)
            SaveAppSetting("OLEnableErrEmail", Val(chkEmailError.Checked))
            SaveAppSetting("OLEmailFrequency", txtEmailFrequency.Text)
            SaveAppSetting("OLPrintPayPalID", Val(chkPrintPayPalID.Checked))
            SaveAppSetting("OLDisplayTotals", Val(chkShowOnlineTotals.Checked))
            SaveAppSetting("OLDBBackup", Val(chkBackupDBOnline.Checked))
            SaveAppSetting("OLDBBackupDay", cmbBackupDay.Text)
#End Region

        Catch ex As Exception
            DisplayError(ex)
        End Try

        Close()

    End Sub

    Private Sub CreatePrintersList()

        Dim P1Temp, P2Temp, P3Temp, strInstalledPrinters As String

        If PrinterSettings.InstalledPrinters.Count = 0 Then
            cmbPrinterShop.Enabled = False
            cmbPrinterKitchen.Enabled = False
            cmbPrinterLabel.Enabled = False
            Exit Sub
        End If

        cmbPrinterShop.Items.Clear() : cmbPrinterKitchen.Items.Clear() : cmbPrinterLabel.Items.Clear()
        cmbC_SC_Shop.Items.Clear() : cmbC_SC_Kitchen.Items.Clear() : cmbC_KC_Shop.Items.Clear()
        cmbC_KC_Kitchen.Items.Clear() : cmbD_SC_Shop.Items.Clear() : cmbD_SC_Kitchen.Items.Clear()
        cmbD_KC_Shop.Items.Clear() : cmbD_KC_Kitchen.Items.Clear() : cmbT_SC_Shop.Items.Clear()
        cmbT_SC_Kitchen.Items.Clear() : cmbT_KC_Shop.Items.Clear() : cmbT_KC_Kitchen.Items.Clear()

        For Each strInstalledPrinters In PrinterSettings.InstalledPrinters
            cmbPrinterShop.Items.Add(Rnd, strInstalledPrinters)
            cmbPrinterKitchen.Items.Add(Rnd, strInstalledPrinters)
            cmbPrinterLabel.Items.Add(Rnd, strInstalledPrinters)
        Next

        'fill combo text with previously selected printer
        P1Temp = GetAppSettingCS("PrinterShop" & intCuisinePrintersIndex.ToString, "")
        P2Temp = GetAppSettingCS("PrinterKitchen" & intCuisinePrintersIndex.ToString, "")
        P3Temp = GetAppSettingCS("PrinterLabels" & intCuisineLabelPrinterIndex.ToString, "")

        For iCntr As Short = 0 To cmbPrinterShop.Items.Count - 1
            If cmbPrinterShop.Items(iCntr).ToString.Contains(P1Temp) Then
                cmbPrinterShop.SelectedIndex = iCntr
            End If
            If cmbPrinterKitchen.Items(iCntr).ToString.Contains(P2Temp) Then
                cmbPrinterKitchen.SelectedIndex = iCntr
            End If
            If cmbPrinterLabel.Items(iCntr).ToString.Contains(P3Temp) Then
                cmbPrinterLabel.SelectedIndex = iCntr
            End If
        Next

        For iCntr As Short = 0 To 5
            cmbC_SC_Shop.Items.Add(iCntr, iCntr)
            cmbC_SC_Kitchen.Items.Add(iCntr, iCntr)
            cmbC_KC_Shop.Items.Add(iCntr, iCntr)
            cmbC_KC_Kitchen.Items.Add(iCntr, iCntr)

            cmbD_SC_Shop.Items.Add(iCntr, iCntr)
            cmbD_SC_Kitchen.Items.Add(iCntr, iCntr)
            cmbD_KC_Shop.Items.Add(iCntr, iCntr)
            cmbD_KC_Kitchen.Items.Add(iCntr, iCntr)

            cmbT_SC_Shop.Items.Add(iCntr, iCntr)
            cmbT_SC_Kitchen.Items.Add(iCntr, iCntr)
            cmbT_KC_Shop.Items.Add(iCntr, iCntr)
            cmbT_KC_Kitchen.Items.Add(iCntr, iCntr)
        Next

        cmbC_SC_Shop.SelectedIndex = GetAppSettingCS("prtcopC_SC_Shop" & intCuisinePrintersIndex.ToString, 1)
        cmbC_SC_Kitchen.SelectedIndex = GetAppSettingCS("prtcopC_SC_Kitchen" & intCuisinePrintersIndex.ToString, 0)
        cmbC_KC_Shop.SelectedIndex = GetAppSettingCS("prtcopC_KC_Shop" & intCuisinePrintersIndex.ToString, 0)
        cmbC_KC_Kitchen.SelectedIndex = GetAppSettingCS("prtcopC_KC_Kitchen" & intCuisinePrintersIndex.ToString, 1)

        cmbD_SC_Shop.SelectedIndex = GetAppSettingCS("prtcopD_SC_Shop" & intCuisinePrintersIndex.ToString, 1)
        cmbD_SC_Kitchen.SelectedIndex = GetAppSettingCS("prtcopD_SC_Kitchen" & intCuisinePrintersIndex.ToString, 0)
        cmbD_KC_Shop.SelectedIndex = GetAppSettingCS("prtcopD_KC_Shop" & intCuisinePrintersIndex.ToString, 0)
        cmbD_KC_Kitchen.SelectedIndex = GetAppSettingCS("prtcopD_KC_Kitchen" & intCuisinePrintersIndex.ToString, 1)

        cmbT_SC_Shop.SelectedIndex = GetAppSettingCS("prtcopT_SC_Shop" & intCuisinePrintersIndex.ToString, 1)
        cmbT_SC_Kitchen.SelectedIndex = GetAppSettingCS("prtcopT_SC_Kitchen" & intCuisinePrintersIndex.ToString, 0)
        cmbT_KC_Shop.SelectedIndex = GetAppSettingCS("prtcopT_KC_Shop" & intCuisinePrintersIndex.ToString, 0)
        cmbT_KC_Kitchen.SelectedIndex = GetAppSettingCS("prtcopT_KC_Kitchen" & intCuisinePrintersIndex.ToString, 1)

    End Sub

    Private Sub cmdDeleteMod_Click(sender As Object, e As EventArgs) Handles cmdDeleteMod.Click

        If lstMods.SelectedItems.Count = 0 Then Exit Sub

        For Each mySeln In lstMods.SelectedItems
            SQLQuery = "DELETE FROM Modifiers WHERE Name = '" & mySeln.Text & "'"
            objDB.ExeNonQuery(SQLQuery)
        Next

        For i As Short = lstMods.SelectedItems.Count - 1 To 0 Step -1
            lstMods.Items.Remove(lstMods.SelectedItems(i))
        Next

        txtMod.Focus()

    End Sub

    Private Sub cmdAddMod_Click(sender As Object, e As EventArgs) Handles cmdAddMod.Click

        tempStr = txtMod.Text.Trim

        If txtCost.Text.Trim <> "" Then
            If Not IsANumber(txtCost.Text) Then
                strMsgBox = "Entered amount is invalid"
                Alert(strMsgBox, MessageBoxIcon.Asterisk)
                Exit Sub
            End If
        End If

        If tempStr <> "" Then
            'see its not in list already
            If IsInListbox(tempStr, lstMods) = False Then
                lstMods.Items.Add(Rnd, txtMod.Text.Trim)
                If txtCost.Text <> String.Empty AndAlso IsANumber(txtCost.Text) Then
                    SQLQuery = $"INSERT INTO Modifiers (Name, Cost) VALUES ('{ tempStr }', '{ txtCost.Text }');"
                Else
                    SQLQuery = $"INSERT INTO Modifiers (Name) VALUES ('{ tempStr }');"
                End If

                objDB.ExeNonQuery(SQLQuery)
                txtMod.Clear()
                txtCost.Clear()
                txtMod.Focus()

            Else
                strMsgBox = tempStr & " is already in the list"
                Alert(strMsgBox, MessageBoxIcon.Asterisk)
            End If
        End If

    End Sub

    Private Sub cmdAddGroup_Click(sender As Object, e As EventArgs) Handles cmdAddGroup.Click

        tempStr = txtGroups.Text.Trim

        If tempStr <> "" Then

            'see its not in list already
            If IsInListbox(tempStr, lstGroups) = False Then
                lstGroups.Items.Add(Rnd, txtGroups.Text.Trim)
                txtGroups.Clear()
                txtGroups.Focus()
                blnBoxIsDirty = True
            Else
                strMsgBox = tempStr & " is already in the list"
                Alert(strMsgBox, MessageBoxIcon.Asterisk)
            End If

        End If

    End Sub

    Private Sub cmdDeleteGroup_Click(sender As Object, e As EventArgs) Handles cmdDeleteGroup.Click

        If lstGroups.SelectedItems.Count = 0 Then Exit Sub

        For iCnt As Integer = lstGroups.SelectedItems.Count - 1 To 0 Step -1
            lstGroups.Items.Remove(lstGroups.SelectedItems(iCnt))
            blnBoxIsDirty = True
        Next

        txtGroups.Focus()

    End Sub

    Private Sub cmdSetSupervisorPassword_Click(sender As Object, e As EventArgs) Handles cmdSetSupervisorPassword.Click

        Try
            If txtSPOld.Text = String.Empty Or txtSPNew.Text = String.Empty Or txtSPConfirm.Text = String.Empty Then
                strMsgBox = "All three boxes need to be filled in"
                Alert(strMsgBox, MessageBoxIcon.Exclamation)
            ElseIf txtSPNew.Text <> txtSPConfirm.Text Then
                strMsgBox = "New password does not match"
                Alert(strMsgBox, MessageBoxIcon.Exclamation)
            Else
                'password must be numeric only

                If Not StringAllNumbers(txtSPConfirm.Text) Then
                    strMsgBox = "Password must contain only numbers"
                    Alert(strMsgBox, MessageBoxIcon.Exclamation)
                    Exit Sub
                End If


                Dim strSuperDuper As String = objDB.EZSettingRead("SuperDuper")
                If strSuperDuper IsNot Nothing Then
                    If strSuperDuper = objSecurity.MD5Hash_ThenSplitAndSwap(txtSPOld.Text) Then  'super password matches so allow change
                        objDB.EZSettingWrite("SuperDuper", objSecurity.MD5Hash_ThenSplitAndSwap(txtSPNew.Text.Trim))
                        strMsgBox = "Supervisor password has been changed"
                        Alert(strMsgBox, MessageBoxIcon.Information)
                        txtSPOld.Clear()
                        txtSPNew.Clear()
                        txtSPConfirm.Clear()
                    Else
                        'entered super pass is invalid
                        strMsgBox = "Invalid supervisor password"
                        Alert(strMsgBox, MessageBoxIcon.Exclamation)
                    End If
                Else
                    'entered super pass is invalid
                    strMsgBox = "Invalid supervisor password"
                    Alert(strMsgBox, MessageBoxIcon.Exclamation)
                End If

            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub txtGroups_Enter(sender As Object, e As EventArgs) Handles txtGroups.Enter
        AcceptButton = cmdAddGroup
    End Sub

    Private Sub txtGroups_Leave(sender As Object, e As EventArgs) Handles txtGroups.Leave
        AcceptButton = Nothing
    End Sub

    Private Sub txtMod_Enter(sender As Object, e As EventArgs) Handles txtMod.Enter, txtCost.Enter
        AcceptButton = cmdAddMod
    End Sub

    Private Sub txtMod_Leave(sender As Object, e As EventArgs) Handles txtMod.Leave, txtCost.Leave
        AcceptButton = Nothing
    End Sub

    Private Sub LeaveTextBoxes(sender As Object, e As EventArgs) Handles txtDelivUnder.Leave, txtDiscountExc.Leave,
        txtMinOrderAmount.Leave

        Try
            If IsANumber(sender.text) Then sender.Text = fixCur(sender.Text)
        Catch ex As Exception

        End Try

    End Sub

    Private Sub cmdMoveUp_Click(sender As Object, e As EventArgs) Handles cmdMoveUp.Click, cmdMoveDown.Click

        If lstGroups.SelectedItems.Count = 1 Then

            Dim blnCanDoMove As Boolean

            If cmdGroupingMode.Tag = "1" AndAlso lstGroups.SelectedItems(0).Text <> strGroupingGap Then
                blnCanDoMove = False
            Else
                blnCanDoMove = True
            End If

            If blnCanDoMove Then

                Dim lstVI As Infragistics.Win.UltraWinListView.UltraListViewItem = lstGroups.SelectedItems.First
                Dim nPos As Short = lstGroups.SelectedItems.First.Index

                If (sender.text = "Up" And lstGroups.SelectedItems.Item(0).Index > 0) Then
                    lstGroups.Items.Remove(lstGroups.SelectedItems.First)
                    lstGroups.Items.Insert(nPos - 1, lstVI)
                    lstGroups.SelectedItems.Add(lstGroups.Items(nPos - 1))
                    blnBoxIsDirty = True
                ElseIf (sender.text = "Down" And lstGroups.SelectedItems.Item(0).Index < lstGroups.Items.Count - 1) Then
                    lstGroups.Items.Remove(lstGroups.SelectedItems.First)
                    lstGroups.Items.Insert(nPos + 1, lstVI)
                    lstGroups.SelectedItems.Add(lstGroups.Items(nPos + 1))
                    blnBoxIsDirty = True
                End If

            End If

        End If

    End Sub

    Private Sub Group_SubGroup_Click(sender As Object, e As EventArgs) Handles cmdMainGroup.Click, cmdSubGroup.Click

        txtGroups.Clear()
        lstGroups.Items.Clear()

        If sender.text = "Groups" Then
            SQLQuery = "SELECT GroupName AS MyVal FROM Groups WHERE CuisineName = '" & cmbCuisineGroups.Text & "' ORDER BY GroupIndex"
            lstGroups.Tag = "G"
        Else
            SQLQuery = "SELECT TName AS MyVal FROM Typical WHERE CuisineName = '" & cmbCuisineGroups.Text & "' ORDER BY TID"
            lstGroups.Tag = "S"
        End If

        drcDatarowCollection = objDB.GetDataRows(SQLQuery)
        If drcDatarowCollection IsNot Nothing Then
            For Each myRow As DataRow In drcDatarowCollection
                lstGroups.Items.Add(Rnd, myRow!MyVal)
            Next
        End If

    End Sub

    Private Sub cmdSaveGroups_Click(sender As Object, e As EventArgs) Handles cmdSaveGroups.Click

        If cmdGroupingMode.Tag = "0" Then

            Dim blnBoxHasErrors As Boolean

            'check that there are no separator gaps
            For iCnt As Integer = 0 To lstGroups.Items.Count - 1
                If lstGroups.Items(iCnt).Text = strGroupingGap Then blnBoxHasErrors = True
            Next

            If blnBoxHasErrors = False Then

                If lstGroups.Tag = "G" Then

                    Try
                        Dim intGrpIndx As Short = ((cmbCuisineGroups.SelectedIndex + 1) * 1000) + 1

                        objDB.ExeNonQuery("DELETE FROM Groups WHERE CuisineName = '" & cmbCuisineGroups.Text & "'")
                        SQLQuery = String.Format("DELETE FROM Groups WHERE GroupIndex BETWEEN {0} AND {1}", intGrpIndx - 1, intGrpIndx + 998)
                        objDB.ExeNonQuery(SQLQuery)

                        If lstGroups.Items.Count > 0 Then SaveAppSetting("StarterGroupName", lstGroups.Items(0).Text)

                        For iCnt As Integer = 0 To lstGroups.Items.Count - 1
                            tempStr = lstGroups.Items(iCnt).Text
                            SQLQuery = String.Format("INSERT INTO Groups (GroupIndex, GroupName, CuisineName) VALUES ({0}, '{1}', '{2}')", intGrpIndx, tempStr.Punctuate, cmbCuisineGroups.Text.Punctuate)
                            objDB.ExeNonQuery(SQLQuery)
                            intGrpIndx += 1
                        Next

                        strMsgBox = "Groups have been saved"
                        Alert(strMsgBox, MessageBoxIcon.Information)

                    Catch ex As Exception
                        DisplayError(ex)
                    End Try

                Else

                    Try
                        objDB.ExeNonQuery("DELETE FROM Typical WHERE CuisineName = '" & cmbCuisineGroups.Text & "'")

                        Dim intGrpIndx As Short = ((cmbCuisineGroups.SelectedIndex + 1) * 1000) + 1

                        For iCnt As Integer = 0 To lstGroups.Items.Count - 1
                            tempStr = lstGroups.Items(iCnt).Text
                            SQLQuery = String.Format("INSERT INTO Typical (TID, TName, CuisineName) VALUES ({0}, '{1}', '{2}')", intGrpIndx, tempStr, cmbCuisineGroups.Text)
                            objDB.ExeNonQuery(SQLQuery)
                            intGrpIndx += 1
                        Next

                        strMsgBox = "Subgroups have been saved"
                        Alert(strMsgBox, MessageBoxIcon.Information)

                    Catch ex As Exception
                        DisplayError(ex)
                    End Try

                End If

                blnBoxIsDirty = False

            Else

                strMsgBox = "You need to remove the " & strGroupingGap & " from the list before proceeding to save the groups"
                Alert(strMsgBox, MessageBoxIcon.Information)

            End If

        Else
            'save groupings for kitchen dishes' grouped printing
            'first and last on the list cannot be strGroupingGap
            If lstGroups.Items(0).Text = strGroupingGap Or lstGroups.Items(lstGroups.Items.Count - 1).Text = strGroupingGap Then
                strMsgBox = "First or last item in list cannot be the" & vbCrLf & "separator (" & strGroupingGap & ")"
                Alert(strMsgBox, MessageBoxIcon.Error)
            Else

                Dim intFirstNum, intLastNum As Short

                objDB.ExeNonQuery("DELETE FROM GroupGaps")

                For iCnt As Integer = 0 To lstGroups.Items.Count - 1
                    tempStr = lstGroups.Items(iCnt).Text
                    If tempStr = strGroupingGap Then
                        If intFirstNum = Nothing Then
                            intFirstNum = GetGroupNumber(lstGroups.Items(0).Text)
                        End If
                        intLastNum = GetGroupNumber(lstGroups.Items(iCnt - 1).Text)
                        SQLQuery = String.Format("INSERT INTO GroupGaps (GroupNumber) VALUES ({0}),({1})", intFirstNum, intLastNum)
                        objDB.ExeNonQuery(SQLQuery)
                        intFirstNum = GetGroupNumber(lstGroups.Items(iCnt + 1).Text)
                    End If
                Next

                Alert("Setting has been saved", MessageBoxIcon.Information)

            End If

        End If

    End Sub

    Private Sub chkEnableActiveCID_CheckStateChanged(sender As Object, e As EventArgs) Handles chkEnableActiveCID.CheckStateChanged

        chkEnableRecording.Enabled = chkEnableActiveCID.Checked

    End Sub

    Private Sub cmdSaveFont_Click(sender As Object, e As EventArgs) Handles cmdLogoFontSave.Click

        Try
            strMsgBox = String.Empty
            If cmbLogoFont.Text = String.Empty Then
                strMsgBox = "No font name specified"
            ElseIf cmbLogoSize.Text = String.Empty Then
                strMsgBox = "No font size specified"
            ElseIf Integer.Parse(cmbLogoSize.Text) < 0 Or Integer.Parse(cmbLogoSize.Text) > 100 Then
                strMsgBox = "Invalid font size specified -" & vbCrLf & "must be between 1 and 100"
            End If

            If strMsgBox <> String.Empty Then
                Alert(strMsgBox, MessageBoxIcon.Error)
            Else
                'save settings to registry
                SaveAppSetting("LogoFontName", cmbLogoFont.Text)
                SaveAppSetting("LogoFontSize", cmbLogoSize.Text)
                SaveAppSetting("LogoFontBold", chkLogoBold.Checked)
                SaveAppSetting("LogoFontItalic", chkLogoItalic.Checked)
                strMsgBox = "Settings saved"
                Alert(strMsgBox, MessageBoxIcon.Information)
            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub LoadAllSettings()
        'Private Sub utcSettings_SelectedTabChanged(sender As System.Object, e As Infragistics.Win.UltraWinTabControl.SelectedTabChangedEventArgs) Handles utcSettings.SelectedTabChanged

        Try

            'If e.Tab.Key = "General" Then

            chkCAP.Checked = GetAppSettingCS("CAPStatus", 0)
            txtCAP.Text = GetAppSettingCS("CAPValue", 0)

            'set number of tables box
            Select Case GetAppSettingCS("NumberOfTables", 20)
                Case 12 : cmbNumTables.SelectedIndex = 0
                Case 16 : cmbNumTables.SelectedIndex = 1
                Case 20 : cmbNumTables.SelectedIndex = 2
                Case 28 : cmbNumTables.SelectedIndex = 3
                Case Else : cmbNumTables.SelectedIndex = 2
            End Select

            chkExtraGap.Checked = GetAppSettingCS("ExtraStarterSpace", 0)
            chkShowLabelText.Checked = GetAppSettingCS("ShowLabelText", 0)
            chkDisableCursor.Checked = GetAppSettingCS("DisableCursor", False)
            chkPasswordTakings.Checked = GetAppSettingCS("PasswordTotals", 0)
            chkSaveDishHistory.Checked = GetAppSettingCS("SaveDishHistory", 0)
            chkSaveCustomerHistory.Checked = GetAppSettingCS("SaveCustomerHistory", False)
            chkShowHomeAfterPrint.Checked = GetAppSettingCS("ShowHomeAfterPrint", False)
            chkAutoMarkAsPaid.Checked = GetAppSettingCS("AutoMarkPaid", 0)
            chkShowMinimise.Checked = GetAppSettingCS("ShowMinimiseButton", 0)
            chkFirstOrdered.Checked = GetAppSettingCS("ShowFirstOrdered", 0)
            chkLastOrdered.Checked = GetAppSettingCS("ShowLastOrdered", 0)
            chkNumberOrdered.Checked = GetAppSettingCS("ShowCustomersOrders", 0)
            chkAutoCashCard.Checked = GetAppSettingCS("AutoSplitPayment", 0)
            chkAutoDelPastOrders.Checked = GetAppSettingCS("AutoDeleteOrders", 0)
            chkCenterMainForm.Checked = GetAppSettingCS("CenterMainForm", 0)

            chkPartOfMultiSystem.Checked = GetAppSettingCS("IsPartOfMultiSystem", False)
            If chkPartOfMultiSystem.Checked = True Then
                If GetAppSettingCS("MultiSystemIsMain", True) = True Then
                    optMainSubSystem.Value = "MAIN"
                Else
                    optMainSubSystem.Value = "SUB"
                End If
            End If
            optMainSubSystem.Enabled = chkPartOfMultiSystem.Checked
            chkIsTabletPC.Checked = GetAppSettingCS("IsTabletPC", 0)

            'ElseIf e.Tab.Key = "DelivColn" Then

            ''sort out bits regarding discounts and charges
            chkDelivCharge.Checked = GetAppSettingCS("AllChargesCheck", 0)
            txtDeliv.Text = GetAppSettingCS("AllChargesAmount", 0)
            optDeliv.Value = GetAppSettingCS("AllChargesAorP", "A")
            If optDeliv.Value = "A" Then txtDeliv.Text = fixCur(txtDeliv.Text)
            chkDelivUnder.Checked = GetAppSettingCS("AllChargesAmtExcChk", 0)
            txtDelivUnder.Text = fixCur(GetAppSettingCS("AllChargesAmtExcVal", 0))
            chkMinOrderAmount.Checked = GetAppSettingCS("MinDeliveryChecked", 0)
            txtMinOrderAmount.Text = fixCur(GetAppSettingCS("MinDeliveryAmount", 0))
            chkDTime.Checked = GetAppSettingCS("LastDeliveryChecked", 0)
            txtDTime.Text = GetAppSettingCS("LastDeliveryTime", "")
            txtMyPostcode.Text = GetAppSettingCS("MyPostcode", "").ToString.ToUpper

            chkGiveDiscount.Checked = GetAppSettingCS("AllDiscountsCheck", 0)
            txtDiscount.Text = GetAppSettingCS("AllDiscountsAmount", 0)
            optDiscount.Value = GetAppSettingCS("AllDiscountsAorP", "A")
            If optDiscount.Value = "A" Then txtDiscount.Text = fixCur(txtDiscount.Text)
            chkDiscountExc.Checked = GetAppSettingCS("AllDiscountsAmtExcChk", 0)
            txtDiscountExc.Text = fixCur(GetAppSettingCS("AllDiscountsAmtExcVal", 0))

            'ElseIf e.Tab.Key = "DiscCharges" Then

            chkRoundingMethod.Checked = GetAppSettingCS("RoundingMethod", 0)

            'ElseIf e.Tab.Key = "Phone" Then

            'phone numbers tab
            txtPhTrim1.Text = GetAppSettingCS("TruncPhNum1", "")
            txtPhLen1.Text = GetAppSettingCS("TruncPhLen1", "")
            txtPhTrim2.Text = GetAppSettingCS("TruncPhNum2", "")
            txtPhLen2.Text = GetAppSettingCS("TruncPhLen2", "")
            txtPhTrim3.Text = GetAppSettingCS("TruncPhNum3", "")
            txtPhLen3.Text = GetAppSettingCS("TruncPhLen3", "")

            'ActiveCID settings
            chkEnableActiveCID.Checked = GetAppSettingCS("EnableActiveCID", 0)
            cmbActiveCIDPort.SelectedIndex = GetAppSettingCS("ActiveCIDPort", 1) - 1
            chkEnableRecording.Enabled = chkEnableActiveCID.Checked
            chkDoNotShowCID.Checked = GetAppSettingCS("HideCIDWhenNoCID", 0)
            If chkEnableActiveCID.Checked = True Then
                chkEnableRecording.Checked = GetAppSettingCS("EnableRecording", 0)
            Else
                chkEnableRecording.Checked = False
            End If
            optCometMeteor.Value = GetAppSettingCS("CTIType", "Comet")

            'ElseIf e.Tab.Key = "Header" Then

            Dim installed_fonts As New Text.InstalledFontCollection

            'print headers
            txtHeader1.Text = GetAppSettingCS("PrintHead1", "")
            txtHeader2.Text = GetAppSettingCS("PrintHead2", "")
            txtHeader3.Text = GetAppSettingCS("PrintHead3", "")
            txtHeader4.Text = GetAppSettingCS("PrintHead4", "")
            txtHeader5.Text = GetAppSettingCS("PrintHead5", "")
            txtHeader6.Text = GetAppSettingCS("PrintHead6", "")

            cmbLogoFont.Items.Clear()
            cmbLogoFont.Items.Add(String.Empty)
            For Each font_family As FontFamily In installed_fonts.Families
                cmbLogoFont.Items.Add(font_family.Name)
            Next font_family
            cmbLogoFont.SelectedIndex = 0

            With cmbLogoSize.Items
                .Add(String.Empty)
                For i = 10 To 50 Step 4
                    .Add(i)
                Next
            End With

            cmbLogoFont.Text = GetAppSettingCS("LogoFontName", String.Empty)
            cmbLogoSize.Text = GetAppSettingCS("LogoFontSize", String.Empty)
            chkLogoBold.Checked = GetAppSettingCS("LogoFontBold", False)
            chkLogoItalic.Checked = GetAppSettingCS("LogoFontItalic", False)

            'ElseIf e.Tab.Key = "Modifiers" Then
            chkDisableCostChange.Checked = GetAppSettingCS("DisablePriceChangeInMod", 0)
            chkZeroCost.Checked = GetAppSettingCS("PrintZeroCost", 0)
            chkShowModLabelPrinter.Checked = GetAppSettingCS("ModLabelPrinter", 0)

            'form query to get existing modifier options
            SQLQuery = "SELECT Name FROM Modifiers ORDER BY Name"
            drcDatarowCollection = objDB.GetDataRows(SQLQuery)
            If drcDatarowCollection IsNot Nothing Then
                For Each myRow As DataRow In drcDatarowCollection
                    lstMods.Items.Add(Rnd, myRow!Name)
                Next
            End If

            'ElseIf e.Tab.Key = "Printers" Then

            'printer tab
            CreatePrintersList() 'setup printers
            chkHidePrintDialog.Checked = GetAppSettingCS("HidePrintDialog", 0)

            'ElseIf e.Tab.Key = "LabelPrinter" Then
            chkPrintLabels.Checked = GetAppSettingCS("PrintLabels1", 0)
            For i = 10 To 20
                cmbLabelFontSize.Items.Add(i)
                cmbFontSizeShop.Items.Add(i)
                cmbFontSizeKitchen.Items.Add(i)
                'cmbFontSizeShopAddress.Items.Add(i)
                cmbFontSizeKitchenAddress.Items.Add(i)
                cmbPaidFontSize.Items.Add(i)
            Next
            cmbLabelFontSize.Text = GetAppSettingCS("LabelFontSize", 12)
            txtLabelHeight.Text = GetAppSettingCS("LabelHeight", 19)
            txtLabelWidth.Text = GetAppSettingCS("LabelWidth", 45)
            txtLabelTopMargin.Text = GetAppSettingCS("LabelTopMargin", 0)
            txtLabelLeftMargin.Text = GetAppSettingCS("LabelLeftMargin", 0)
            txtLabelTopOffset.Text = GetAppSettingCS("LabelTopOffset", 10)
            txtLabelLeftOffset.Text = GetAppSettingCS("LabelLeftOffset", 50)
            chkPrintLabelAny.Checked = GetAppSettingCS("LabelsPrintAny", 0)
            txtKitchenHeaderText.Text = GetAppSettingCS("KitchenHeaderText", "KITCHEN ORDER")

            'ElseIf e.Tab.Key = "Print" Then

            chkKitchenCard.Checked = GetAppSettingCS("PrintKitchenCard", 0)
            chkKitchenDate.Checked = GetAppSettingCS("PrintKitchenDate", 0)
            chkKitchenItem.Checked = GetAppSettingCS("PrintKitchenItem", 0)
            chkKitchenTime.Checked = GetAppSettingCS("PrintKitchenTime", 0)
            chkKitchenTotal.Checked = GetAppSettingCS("PrintKitchenTotal", 0)

            chkShopCard.Checked = GetAppSettingCS("PrintShopCard", 0)
            chkShopDate.Checked = GetAppSettingCS("PrintShopDate", 0)
            chkShopItem.Checked = GetAppSettingCS("PrintShopItem", 0)
            chkShopTime.Checked = GetAppSettingCS("PrintShopTime", 0)
            chkShopTotal.Checked = GetAppSettingCS("PrintShopTotal", 0)

            optOnScreen.Value = GetAppSettingCS("LNSNOnscreen", "LN")
            optCustomer.Value = GetAppSettingCS("LNSNCustomer", "LN")
            optKitchen.Value = GetAppSettingCS("LNSNKitchen", "SN")

            chkServiceCharge.Checked = GetAppSettingCS("PrintServiceCharge", 0)
            chkDrinksFoodGrouped.Checked = GetAppSettingCS("DrinksAndFoodGrouped", 0)
            chkDrinksItemise.Checked = GetAppSettingCS("DrinksItemise", 0)
            chkDrinksFoodSeparatePrice.Checked = GetAppSettingCS("DrinksFoodSeparatePrice", 0)
            chkDrinksFoodSeparatePrice.Enabled = chkDrinksItemise.Checked
            chkDrinksAndFoodGap.Checked = GetAppSettingCS("DrinksAndFoodGap", 0)
            chkDrinksAndFoodGap.Enabled = chkDrinksItemise.Checked
            chkKitchenGap.Checked = GetAppSettingCS("DishesGapKitchen", 0)
            chkDrinksHeader.Checked = GetAppSettingCS("DrinksHeader", 0)
            chkDrinksHeader.Enabled = chkDrinksItemise.Checked
            chkSimultaneousPrinting.Checked = GetAppSettingCS("SimultaneousPrinting", 0)
            chkSameSKHeader.Checked = GetAppSettingCS("SameSKHeader", 0)
            cmbFontSizeShop.Text = GetAppSettingCS("FontSizeShop", 12)
            cmbFontSizeKitchen.Text = GetAppSettingCS("FontSizeKitchen", 14)
            'cmbFontSizeShopAddress.Text = GetAppSettingCS("FontSizeShopAddress", 12)
            cmbFontSizeKitchenAddress.Text = GetAppSettingCS("FontSizeKitchenAddress", 14)
            txtKitchenHeaderText.Text = GetAppSettingCS("KitchenHeaderText", "KITCHEN ORDER")
            cmbPaidFontSize.Text = GetAppSettingCS("FontSizePaid", 10)
            cmbPaidLocation.Text = GetAppSettingCS("PaidLocation", "Right")
            txtFoodLabel.Text = GetAppSettingCS("FoodLabelOnReceipt", "Food")
            txtDrinksLabel.Text = GetAppSettingCS("DrinksLabelOnReceipt", "Drinks")
            txtPaperWidth.Text = GetAppSettingCS("PaperWidth", 280)
            txtRightOffset.Text = GetAppSettingCS("RightOffset", 90)
            txtCentreOffset.Text = GetAppSettingCS("CentreOffset", 100)
            txtKitchenTopOffset.Text = GetAppSettingCS("KitchenCopyTopOffset", 40)
            txtShopTopOffset.Text = GetAppSettingCS("ShopCopyTopOffset", 10)
            txtMinPaperLengthShop.Text = GetAppSettingCS("MinPaperS", 10)
            txtMinPaperLengthKitchen.Text = GetAppSettingCS("MinPaperK", 1)
            txtFooter.Text = GetAppSettingCS("FooterText", "Thank you for your customer. Please call again soon.")

            'ElseIf e.Tab.Key = "Tables" Then

            chkTableExtMode.Checked = GetAppSettingCS("TablesExtMode", False)
            chkTableExtLights.Checked = GetAppSettingCS("TablesExtLights", False)
            txtTableExtLine1.Text = GetAppSettingCS("TablesExtLine1", "")
            txtTableExtLine2.Text = GetAppSettingCS("TablesExtLine2", "")
            txtTableExtLine3.Text = GetAppSettingCS("TablesExtLine3", "")
            chkTableAutoCovers.Checked = GetAppSettingCS("TablesAutoCovers", False)

            'form query to get table statuses
            SQLQuery = "SELECT Status FROM Table_Status ORDER BY ID"
            drcDatarowCollection = objDB.GetDataRows(SQLQuery)
            If drcDatarowCollection IsNot Nothing Then
                For Each myRow As DataRow In drcDatarowCollection
                    lstTStatus.Items.Add(Rnd, myRow!Status)
                Next
            End If

            'ElseIf e.Tab.Key = "Summary" Then

            chkSummaryCDTTotals.Checked = GetAppSettingCS("SummaryCDTTotals", 0)
            chkSummaryPrintDate.Checked = GetAppSettingCS("SummaryPrintDate", 0)

            'ElseIf e.Tab.Key = "Dishes" Then

            chkDishesUseConcise.Checked = GetAppSettingCS("DishesUseConcise", 0)
            chkDishesSimpleName.Checked = GetAppSettingCS("DishesUseSimpleName", 0)
            chkDishesUppercase.Checked = GetAppSettingCS("DishesUppercase", 0)
            txtPortionSmall.Text = GetAppSettingCS("PortionSmall", "[S]").ToString.Trim
            txtPortionLarge.Text = GetAppSettingCS("PortionLarge", "[L]").ToString.Trim

            chkRequireLogon.Checked = GetAppSettingCS("RequireLogon", 0)

            'ElseIf e.Tab.Key = "Cuisines" Then

            'form query to get existing cuisines
            drcDatarowCollection = objDB.GetDataRows("SELECT TOP 5 CuisineName FROM Cuisine WHERE CuisineName <> '' ORDER BY ID")
            If drcDatarowCollection IsNot Nothing AndAlso drcDatarowCollection.Count > 0 Then
                Dim i As Short = 1
                For Each myRow As DataRow In drcDatarowCollection
                    For Each myObj In ugbCuisines.Controls
                        If (TypeName(myObj) = "UltraTextEditor" AndAlso myObj.text = String.Empty AndAlso (myObj.name.IndexOf(i.ToString) <> -1)) Then
                            myObj.Text = myRow!CuisineName.ToString
                            myObj.Enabled = vbFalse
                            i += 1
                            Exit For
                        End If
                    Next
                Next
            End If

            'ElseIf e.Tab.Key = "Groups" Then

            'form query to get existing groups
            SQLQuery = "SELECT GroupName FROM Groups"
            drcDatarowCollection = objDB.GetDataRows(SQLQuery)
            lstGroups.Items.Clear()
            If drcDatarowCollection IsNot Nothing Then
                For Each myRow As DataRow In drcDatarowCollection
                    lstGroups.Items.Add(Rnd, myRow!GroupName)
                Next
            End If
            lstGroups.Tag = "G"

            'ElseIf e.Tab.Key = "Manager" Then

            chkXAccessManager.Checked = GetAppSettingCS("XAccessManager", 0)
            chkXOrderDelete.Checked = GetAppSettingCS("XOrderDelete", 0)
            chkXOrderEdit.Checked = GetAppSettingCS("XOrderEdit", 0)
            chkXOrderReprint.Checked = GetAppSettingCS("XOrderReprint", 0)
            chkXOrderTotals.Checked = GetAppSettingCS("XOrderTotals", 0)
            chkXOrders.Checked = GetAppSettingCS("XOrders", 0)
            chkXClearOrders.Checked = GetAppSettingCS("XClearOrders", 0)
            chkXAccessSummary.Checked = GetAppSettingCS("XAccessSummary", 0)
            chkXAccessBanking.Checked = GetAppSettingCS("XAccessBanking", 0)
            chkXClearOnExit.Checked = GetAppSettingCS("XClearOnExit", 0)

            'ElseIf e.Tab.Key = "Set" Then

            chkSetPutQty.Checked = GetAppSettingCS("SetPutQty", False)

            'ElseIf e.Tab.Key = "Online" Then

            chkEnableOnline.Checked = GetAppSettingCS("OLEnabled", 0)
            txtOLText.Text = GetAppSettingCS("OLPrintoutText", "Order source")
            chkEmailError.Checked = GetAppSettingCS("OLEnableErrEmail", 0)
            txtEmailFrequency.Text = GetAppSettingCS("OLEmailFrequency", "14")
            chkPrintPayPalID.Checked = GetAppSettingCS("OLPrintPayPalID", 0)
            chkShowOnlineTotals.Checked = GetAppSettingCS("OLDisplayTotals", 0)
            chkBackupDBOnline.Checked = GetAppSettingCS("OLDBBackup", 0)
            cmbBackupDay.Text = GetAppSettingCS("OLDBBackupDay", "Daily")

            'End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub chkPartOfMultiSystem_CheckedChanged(sender As Object, e As EventArgs) Handles chkPartOfMultiSystem.CheckedChanged

        optMainSubSystem.Enabled = chkPartOfMultiSystem.Checked

        If chkPartOfMultiSystem.Checked Then
            If optMainSubSystem.Value = Nothing Then
                optMainSubSystem.Value = "MAIN"
            End If
        Else
            optMainSubSystem.Value = Nothing
        End If

    End Sub

    Private Sub cmdDCAdd_Click(sender As Object, e As EventArgs) Handles cmdDCAdd.Click

        Try

            tempStr = String.Empty
            If txtDCName.Text = String.Empty Then
                tempStr = "You need to specify a name"
            ElseIf (txtDCRate.Text = String.Empty Or IsANumber(txtDCRate.Text) = False) Then
                tempStr = "You need to specify a numeric value"
            ElseIf cmbDCType.Text = String.Empty Then
                tempStr = "You need to select a type (discount or charge)"
            ElseIf cmbDCAorP.Text = String.Empty Then
                tempStr = "You need to specify if this is a fixed amount or a percentage"
            End If

            If tempStr <> String.Empty Then
                Alert(tempStr, MessageBoxButtons.OK)
                Exit Sub
            End If

            txtDCName.Text = txtDCName.Text.Trim

            SQLQuery = "DELETE FROM DiscCharges WHERE eName = '" & txtDCName.Text.Trim & "'"
            objDB.ExeNonQuery(SQLQuery)
            SQLQuery = String.Format("INSERT INTO DiscCharges (eName, eValue, eType, eAorP) VALUES ('{0}', {1}, '{2}', '{3}')",
                                         txtDCName.Text.Trim, txtDCRate.Text.Trim, cmbDCType.Value, cmbDCAorP.Value)
            objDB.ExeNonQuery(SQLQuery)

            If lstDiscCharges.SelectedItems.Count > 0 Then
                lstDiscCharges.Items.Clear()
                SQLQuery = "SELECT * FROM DiscCharges ORDER BY eName"
                drcDatarowCollection = objDB.GetDataRows(SQLQuery)
                If drcDatarowCollection IsNot Nothing Then
                    For Each myRow In drcDatarowCollection
                        lstDiscCharges.Items.Add(myRow!eName, myRow!eName)
                    Next
                End If
            Else
                lstDiscCharges.Items.Add(Rnd, txtDCName.Text)
            End If
            cmdDCClear_Click(sender, e)

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub utcSettings_SelectedTabChanged(sender As Object, e As Infragistics.Win.UltraWinTabControl.SelectedTabChangedEventArgs) Handles utcSettings.SelectedTabChanged

        Try
            If e.Tab.Key = "DiscCharges" Then
                lstDiscCharges.Items.Clear()
                SQLQuery = "SELECT * FROM DiscCharges ORDER BY eName"
                drcDatarowCollection = objDB.GetDataRows(SQLQuery)
                If drcDatarowCollection IsNot Nothing Then
                    For Each myRow In drcDatarowCollection
                        lstDiscCharges.Items.Add(myRow!eName, myRow!eName)
                    Next
                End If

            ElseIf e.Tab.Key = "Groups" Then
                RefreshPrinters(cmdRefreshCuisinesGroups, Nothing)
                cmbCuisineGroups.SelectedIndex = 0

            ElseIf e.Tab.Key = "Printers" Then
                RefreshPrinters(cmdRefreshCuisinesPrinters, Nothing)
                cmbCuisinePrinters.SelectedIndex = 0

            ElseIf e.Tab.Key = "LabelPrinter" Then
                RefreshPrinters(cmdRefreshCuisinesLabel, Nothing)
                cmbCuisineLabelPrinter.SelectedIndex = 0

            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub cmdDCDelete_Click(sender As Object, e As EventArgs) Handles cmdDCDelete.Click

        If lstDiscCharges.SelectedItems.Count > 0 Then

            For Each mySeln In lstDiscCharges.SelectedItems
                SQLQuery = "DELETE FROM DiscCharges WHERE eName = '" & mySeln.Text & "'"
                objDB.ExeNonQuery(SQLQuery)
            Next

            For i As Integer = lstDiscCharges.SelectedItems.Count - 1 To 0 Step -1
                lstDiscCharges.Items.Remove(lstDiscCharges.SelectedItems(i))
            Next

        End If

        cmdDCClear_Click(sender, e)
        txtDCName.Focus()

    End Sub

    Private Sub cmdDCClear_Click(sender As Object, e As EventArgs) Handles cmdDCClear.Click

        txtDCName.Text = String.Empty
        txtDCRate.Text = String.Empty
        cmbDCAorP.Text = String.Empty
        cmbDCType.Text = String.Empty
        txtDCName.Focus()

    End Sub

    Private Sub lstDiscCharges_Click(sender As Object, e As EventArgs) Handles lstDiscCharges.Click

        Try

            If lstDiscCharges.Items.Count > 0 Then
                SQLQuery = String.Format("SELECT * FROM DiscCharges WHERE eName = '{0}'", lstDiscCharges.SelectedItems.Item(0).Text)
                drDataRow = objDB.GetSingleRow(SQLQuery)
                If drDataRow IsNot Nothing Then
                    txtDCName.Text = drDataRow!eName
                    txtDCRate.Text = drDataRow!eValue
                    cmbDCType.Text = drDataRow!eType
                    cmbDCAorP.Text = drDataRow!eAorP
                End If
            End If

        Catch ex As Exception

            DisplayError(ex)

        End Try

    End Sub

    Private Sub chkItemiseDrinks_CheckedChanged(sender As Object, e As EventArgs) Handles chkDrinksItemise.CheckedChanged

        chkDrinksFoodSeparatePrice.Enabled = chkDrinksItemise.Checked
        chkDrinksAndFoodGap.Enabled = chkDrinksItemise.Checked
        chkDrinksHeader.Enabled = chkDrinksItemise.Checked

        If chkDrinksItemise.Checked = True AndAlso chkDrinksFoodGrouped.Checked = True Then
            chkDrinksFoodGrouped.Checked = False
        End If

    End Sub

    Private Sub cmdReleaseCOMPort_Click(sender As Object, e As EventArgs) Handles cmdReleaseCOMPort.Click

        'close the COM Port
        frmOpener.ActiveCIDProcess(1)

    End Sub

    Private Sub cmdResetActiveCID_Click(sender As Object, e As EventArgs) Handles cmdResetActiveCID.Click

        'reinitialise ActiveCID
        frmOpener.ActiveCIDProcess(2)

    End Sub

    Private Sub optCometMeteor_ValueChanged(sender As Object, e As EventArgs) Handles optCometMeteor.ValueChanged

        If optCometMeteor.Value = "Comet" Then
            SaveAppSetting("CTIType", "Comet")
        Else
            SaveAppSetting("CTIType", "Meteor")
        End If

    End Sub

    Private Sub cmbActiveCIDPort_ValueChanged(sender As Object, e As EventArgs) Handles cmbActiveCIDPort.ValueChanged

        If cmbActiveCIDPort.SelectedIndex <> -1 Then
            SaveAppSetting("ActiveCIDPort", (cmbActiveCIDPort.SelectedIndex + 1))
        End If

    End Sub

    Private Sub cmdAddOnline_Click(sender As Object, e As EventArgs) Handles cmdAddOnline.Click

        tempStr = txtOnline.Text.Trim

        If tempStr <> "" Then
            If lstOnline.Items.Count >= 7 Then
                strMsgBox = "Only 7 options can be put in here"
                Alert(strMsgBox)
            Else
                'see its not in list already
                If IsInListbox(tempStr, lstOnline) = False Then
                    lstOnline.Items.Add(Rnd, txtOnline.Text.Trim)
                    SQLQuery = "INSERT INTO OnlineShops (ShopName) " &
                               "VALUES ('" & tempStr & "');"
                    objDB.ExeNonQuery(SQLQuery)
                Else
                    strMsgBox = tempStr & " is already in the list"
                    Alert(strMsgBox, MessageBoxIcon.Asterisk)
                End If
                txtOnline.Clear()
                txtOnline.Focus()
            End If
        End If

    End Sub

    Private Sub cmdDeleteOnline_Click(sender As Object, e As EventArgs) Handles cmdDeleteOnline.Click

        If lstOnline.SelectedItems.Count = 0 Then Exit Sub

        For i As Integer = 0 To lstOnline.SelectedItems.Count - 1
            SQLQuery = "DELETE FROM OnlineShops WHERE ShopName = '" & lstOnline.SelectedItems(i).Text & "'"
            objDB.ExeNonQuery(SQLQuery)
        Next

        For i As Integer = lstOnline.SelectedItems.Count - 1 To 0 Step -1
            lstOnline.Items.Remove(lstOnline.SelectedItems(i))
        Next

        txtOnline.Focus()

    End Sub

    Private Sub txtOnline_KeyDown(sender As Object, e As KeyEventArgs) Handles txtOnline.KeyDown

        If e.KeyCode = Keys.Enter Then cmdAddOnline_Click(sender, e)

    End Sub

    Private Sub cmdGetTime_Click(sender As Object, e As EventArgs) Handles cmdGetTime.Click

        Try

            Dim strTimeValue As String = TimesGrid.Show

            If strTimeValue <> String.Empty Then
                If strTimeValue <> "0:00" Then
                    If IsDate(strTimeValue) Then
                        txtDTime.Text = strTimeValue & " PM"
                    Else
                        strMsgBox = "Entered time is invalid"
                        Alert(strMsgBox, MessageBoxIcon.Error)
                    End If
                End If
            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub cmdShowPassword_Click(sender As Object, e As EventArgs) Handles cmdShowPassword.Click

        If txtSPOld.PasswordChar = "*" Then
            txtSPOld.PasswordChar = Nothing
            txtSPNew.PasswordChar = Nothing
            txtSPConfirm.PasswordChar = Nothing
            cmdShowPassword.Text = "Hide"
        Else
            txtSPOld.PasswordChar = "*"
            txtSPNew.PasswordChar = "*"
            txtSPConfirm.PasswordChar = "*"
            cmdShowPassword.Text = "Reveal"
        End If

    End Sub

    Private Sub cmdInsertLine_Click(sender As Object, e As EventArgs) Handles cmdInsertLine.Click

        'must have atleast two items to put a separation line
        If lstGroups.Items.Count < 2 Then Exit Sub

        If lstGroups.Items(lstGroups.Items.Count - 1).Text <> strGroupingGap Then
            lstGroups.SelectedItems.Clear()
            lstGroups.Items.Add(Rnd, strGroupingGap)
            lstGroups.SelectedItems.Add(lstGroups.Items(lstGroups.Items.Count - 1))
        End If

    End Sub

    Private Sub cmdGroupingMode_Click(sender As Object, e As EventArgs) Handles cmdGroupingMode.Click

        If cmdGroupingMode.Tag = "0" Then
            cmdMainGroup.Enabled = False
            cmdSubGroup.Enabled = False
            cmdAddGroup.Enabled = False
            cmdInsertLine.Enabled = True
            cmdGroupingMode.Tag = "1"
        Else
            'remove any lines
            Dim iX As Short = 0
            Try
                Do
                    If lstGroups.Items(iX).Text = strGroupingGap Then
                        lstGroups.Items.Remove(lstGroups.Items(iX))
                    End If
                    iX += 1
                Loop While iX < lstGroups.Items.Count

            Catch ex As Exception
                DisplayError(ex)
            End Try

            cmdMainGroup.Enabled = True
            cmdSubGroup.Enabled = True
            cmdAddGroup.Enabled = True
            cmdInsertLine.Enabled = False
            cmdGroupingMode.Tag = "0"
        End If

    End Sub

    Private Function GetGroupNumber(strGroupName As String)

        SQLQuery = String.Format("SELECT GroupIndex FROM Groups WHERE GroupName = '{0}'", strGroupName.Punctuate)
        drDataRow = objDB.GetSingleRow(SQLQuery)
        If drDataRow IsNot Nothing Then
            Return drDataRow!GroupIndex
        End If

        Return -1

    End Function

    Private Sub chkGroupDrinkFood_CheckedChanged(sender As Object, e As EventArgs) Handles chkDrinksFoodGrouped.CheckedChanged

        If chkDrinksFoodGrouped.Checked = True AndAlso chkDrinksItemise.Checked = True Then
            chkDrinksItemise.Checked = False
        End If

    End Sub

    Private Sub RefreshPrinters(sender As Object, e As EventArgs) Handles cmdRefreshCuisinesGroups.Click, cmdRefreshCuisinesPrinters.Click, cmdRefreshCuisinesLabel.Click

        Dim myobj As Infragistics.Win.UltraWinEditors.UltraComboEditor = cmbCuisineGroups
        If sender.name = "cmdRefreshCuisinesPrinters" Then myobj = cmbCuisinePrinters
        If sender.name = "cmdRefreshCuisinesLabel" Then myobj = cmbCuisineLabelPrinter

        drcDatarowCollection = objDB.GetDataRows("SELECT * FROM Cuisine WHERE CuisineName <> '' ORDER BY ID")
        myobj.Items.Clear()
        If drcDatarowCollection IsNot Nothing Then
            For Each myRow As DataRow In drcDatarowCollection
                If myRow!CuisineName <> String.Empty Then myobj.Items.Add(Rnd, myRow!CuisineName)
            Next
        End If

    End Sub

    Private Sub cmbCuisine_ValueChanged(sender As Object, e As EventArgs) Handles cmbCuisineGroups.ValueChanged

        SQLQuery = String.Format("SELECT GroupName FROM Groups WHERE CuisineName = '{0}' ORDER BY GroupIndex", cmbCuisineGroups.Text)
        drcDatarowCollection = objDB.GetDataRows(SQLQuery)
        lstGroups.Items.Clear()
        If drcDatarowCollection IsNot Nothing Then
            For Each myRow As DataRow In drcDatarowCollection
                lstGroups.Items.Add(Rnd, myRow!GroupName)
            Next
        End If
        lstGroups.Tag = "G"

    End Sub

    Private Sub DeleteCuisine(strCuisineName As String)

        SQLQuery = String.Format("SELECT GroupName FROM Groups WHERE CuisineName = '{0}'", strCuisineName)
        drcDatarowCollection = objDB.GetDataRows(SQLQuery)
        If drcDatarowCollection IsNot Nothing Then
            For Each myRow As DataRow In drcDatarowCollection
                'ALSO NEED TO PUT CODE TO DELETE ALL THE DISH CODES
                objDB.ExeNonQuery("DELETE FROM Dish WHERE GroupName = '" & myRow!GroupName & "'")
            Next
            objDB.ReseedTableNew("Dish", "UniqueID")
        End If

        SQLQuery = String.Format("SELECT TName FROM Typical WHERE CuisineName = '{0}'", strCuisineName)
        drcDatarowCollection = objDB.GetDataRows(SQLQuery)
        If drcDatarowCollection IsNot Nothing Then
            For Each myRow As DataRow In drcDatarowCollection
                objDB.ExeNonQuery("DELETE FROM DishSubgroup WHERE TName = '" & myRow!TName & "'")
            Next
        End If

        SQLQuery = String.Format("DELETE FROM Groups WHERE CuisineName = '{0}'", strCuisineName)
        objDB.ExeNonQuery(SQLQuery)
        SQLQuery = String.Format("DELETE FROM Typical WHERE CuisineName = '{0}'", strCuisineName)
        objDB.ExeNonQuery(SQLQuery)
        SQLQuery = String.Format("DELETE FROM Cuisine WHERE CuisineName = '{0}'", strCuisineName)
        objDB.ExeNonQuery(SQLQuery)

    End Sub

    Private Sub cmdCuisineSave_Click(sender As Object, e As EventArgs) Handles cmdCuisineSave.Click

        Dim numMultiCuisines As Short = 0

        txtCuisine1.Text = txtCuisine1.Text.Trim

        If txtCuisine1.Text = String.Empty Then
            strMsgBox = "You must specify at least one cuisine"
            Alert(strMsgBox)

        Else
            txtCuisine2.Text = txtCuisine2.Text.Trim
            txtCuisine3.Text = txtCuisine3.Text.Trim
            txtCuisine4.Text = txtCuisine4.Text.Trim
            txtCuisine5.Text = txtCuisine5.Text.Trim

            'delete any existing cuisine details
            drcDatarowCollection = objDB.GetDataRows("SELECT TOP 5 CuisineName FROM Cuisine WHERE CuisineName <> '' ORDER BY ID")
            If drcDatarowCollection IsNot Nothing Then
                For Each myRow In drcDatarowCollection
                    Dim blnDelete As Boolean = True
                    tempStr = myRow!CuisineName
                    If txtCuisine5.Text = tempStr Then
                        blnDelete = False
                    ElseIf txtCuisine4.Text = tempStr Then
                        blnDelete = False
                    ElseIf txtCuisine3.Text = tempStr Then
                        blnDelete = False
                    ElseIf txtCuisine2.Text = tempStr Then
                        blnDelete = False
                    ElseIf txtCuisine1.Text = tempStr Then
                        blnDelete = False
                    End If
                    If blnDelete = True Then DeleteCuisine(tempStr)
                Next
            End If

            SQLQuery = "TRUNCATE TABLE Cuisine"
            objDB.ExeNonQuery(SQLQuery)

            SQLQuery = $"INSERT INTO Cuisine (CuisineName) VALUES ('{txtCuisine1.Text,0}'), ('{txtCuisine2.Text}'), ('{txtCuisine3.Text}'), ('{txtCuisine4.Text}'), ('{txtCuisine5.Text}')"
            objDB.ExeNonQuery(SQLQuery)

            If txtCuisine5.Text <> String.Empty Then numMultiCuisines += 1 : tempStr = txtCuisine5.Text
            If txtCuisine4.Text <> String.Empty Then numMultiCuisines += 1 : tempStr = txtCuisine4.Text
            If txtCuisine3.Text <> String.Empty Then numMultiCuisines += 1 : tempStr = txtCuisine3.Text
            If txtCuisine2.Text <> String.Empty Then numMultiCuisines += 1 : tempStr = txtCuisine2.Text
            If txtCuisine1.Text <> String.Empty Then numMultiCuisines += 1 : tempStr = txtCuisine1.Text

            numMultiCuisines = IIf(numMultiCuisines > 1, 1, 0)
            SaveAppSetting("MultiCuisines", numMultiCuisines)
            SaveAppSetting("MultiCuisinesDefault", tempStr)

            Alert("Cuisines have been saved." & vbCrLf & "Default cuisine is " & tempStr)

        End If

    End Sub

    Private Sub RenameCuisines(sender As Object, e As EventArgs) Handles cmdRenameCuisine1.Click, cmdRenameCuisine2.Click,
        cmdRenameCuisine3.Click, cmdRenameCuisine4.Click, cmdRenameCuisine5.Click

        Dim myButton As Infragistics.Win.Misc.UltraButton = CType(sender, Infragistics.Win.Misc.UltraButton)
        Dim myTextBox As Infragistics.Win.UltraWinEditors.UltraTextEditor
        Dim strRenCuisine As String

        For Each myCtrl In ugbCuisines.Controls
            If TypeName(myCtrl) = "UltraTextEditor" Then
                myTextBox = CType(myCtrl, Infragistics.Win.UltraWinEditors.UltraTextEditor)
                For iZ = 1 To 5
                    If (myTextBox.Name.IndexOf(iZ.ToString) <> -1 And myButton.Name.IndexOf(iZ.ToString) <> -1 And myTextBox.Text <> String.Empty) Then
                        strRenCuisine = InputBox("Enter new cuisine name:", "Change Name", myTextBox.Text)
                        If strRenCuisine <> String.Empty And strRenCuisine <> myTextBox.Text Then
                            RenameCuisinesInDB(myTextBox.Text, strRenCuisine)
                            myTextBox.Text = strRenCuisine
                        End If
                    End If
                Next
            End If
        Next

    End Sub

    Private Sub RenameCuisinesInDB(strExCuisine As String, strNewCuisine As String)

        SQLQuery = String.Format("UPDATE Cuisine SET CuisineName = '{0}' WHERE CuisineName = '{1}'", strNewCuisine, strExCuisine)
        objDB.ExeNonQuery(SQLQuery)

        SQLQuery = String.Format("UPDATE Groups SET CuisineName = '{0}' WHERE CuisineName = '{1}'", strNewCuisine, strExCuisine)
        objDB.ExeNonQuery(SQLQuery)

        SQLQuery = String.Format("UPDATE Typical SET CuisineName = '{0}' WHERE CuisineName = '{1}'", strNewCuisine, strExCuisine)
        objDB.ExeNonQuery(SQLQuery)

        If GetAppSettingCS("MultiCuisinesDefault", "Indian") = strExCuisine Then
            SaveAppSetting("MultiCuisinesDefault", strNewCuisine)
        End If

    End Sub

    Private Sub DeleteCuisine(sender As Object, e As EventArgs) Handles cmdDeleteCuisine1.Click, cmdDeleteCuisine2.Click,
        cmdDeleteCuisine3.Click, cmdDeleteCuisine4.Click, cmdDeleteCuisine5.Click

        Dim myButton As Infragistics.Win.Misc.UltraButton = CType(sender, Infragistics.Win.Misc.UltraButton)
        Dim myTextBox As Infragistics.Win.UltraWinEditors.UltraTextEditor

        For Each myCtrl In ugbCuisines.Controls
            If TypeName(myCtrl) = "UltraTextEditor" Then
                myTextBox = CType(myCtrl, Infragistics.Win.UltraWinEditors.UltraTextEditor)
                For iZ = 1 To 5
                    If (myTextBox.Name.IndexOf(iZ.ToString) <> -1 And myButton.Name.IndexOf(iZ.ToString) <> -1 And myTextBox.Text <> String.Empty) Then
                        strMsgBox = "You are about to delete all information relating to cuisine " & myTextBox.Text & ". Are you sure?"
                        intResponseBox = EZMsgBox.Show(strMsgBox, MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                        If intResponseBox = vbYes Then
                            DeleteCuisine(myTextBox.Text)
                            myTextBox.Text = String.Empty
                            myTextBox.Enabled = True
                            If GetAppSettingCS("MultiCuisinesDefault", "Indian") = myTextBox.Text Then
                                SaveAppSetting("MultiCuisinesDefault", txtCuisine1.Text)
                            End If
                        End If
                    End If
                Next
            End If
        Next

    End Sub

    Private Sub cmdDefault_Click(sender As Object, e As EventArgs) Handles cmdDefault.Click

        txtLabelHeight.Text = txtLabelHeight.Tag
        txtLabelWidth.Text = txtLabelWidth.Tag
        txtLabelLeftMargin.Text = txtLabelLeftMargin.Tag
        txtLabelTopMargin.Text = txtLabelTopMargin.Tag
        txtLabelTopOffset.Text = txtLabelTopOffset.Tag

    End Sub

    Private Sub cmdSavePrinters_Click(sender As Object, e As EventArgs) Handles cmdSavePrinters.Click

        intCuisinePrintersIndex = cmbCuisinePrinters.SelectedIndex + 1

        If cmbPrinterShop.Text = String.Empty Or cmbPrinterKitchen.Text = String.Empty Then
            utcSettings.SelectedTab = utcSettings.Tabs("Printers")
            strMsgBox = "Either a shop or kitchen printer is not set. If you are using" &
                  "only one printer, then enter that for both shop and kitchen."
            Alert(strMsgBox, MessageBoxIcon.Information)
            Exit Sub
        Else
            SaveAppSetting("PrinterShop" & intCuisinePrintersIndex.ToString, cmbPrinterShop.Text)
            SaveAppSetting("PrinterKitchen" & intCuisinePrintersIndex.ToString, cmbPrinterKitchen.Text)
        End If

        SaveAppSetting("prtcopC_SC_Shop" & intCuisinePrintersIndex.ToString, cmbC_SC_Shop.Text)
        SaveAppSetting("prtcopC_SC_Kitchen" & intCuisinePrintersIndex.ToString, cmbC_SC_Kitchen.Text)
        SaveAppSetting("prtcopC_KC_Shop" & intCuisinePrintersIndex.ToString, cmbC_KC_Shop.Text)
        SaveAppSetting("prtcopC_KC_Kitchen" & intCuisinePrintersIndex.ToString, cmbC_KC_Kitchen.Text)
        SaveAppSetting("prtcopD_SC_Shop" & intCuisinePrintersIndex.ToString, cmbD_SC_Shop.Text)
        SaveAppSetting("prtcopD_SC_Kitchen" & intCuisinePrintersIndex.ToString, cmbD_SC_Kitchen.Text)
        SaveAppSetting("prtcopD_KC_Shop" & intCuisinePrintersIndex.ToString, cmbD_KC_Shop.Text)
        SaveAppSetting("prtcopD_KC_Kitchen" & intCuisinePrintersIndex.ToString, cmbD_KC_Kitchen.Text)
        SaveAppSetting("prtcopT_SC_Shop" & intCuisinePrintersIndex.ToString, cmbT_SC_Shop.Text)
        SaveAppSetting("prtcopT_SC_Kitchen" & intCuisinePrintersIndex.ToString, cmbT_SC_Kitchen.Text)
        SaveAppSetting("prtcopT_KC_Shop" & intCuisinePrintersIndex.ToString, cmbT_KC_Shop.Text)
        SaveAppSetting("prtcopT_KC_Kitchen" & intCuisinePrintersIndex.ToString, cmbT_KC_Kitchen.Text)

        SaveAppSetting("HidePrintDialog" & intCuisinePrintersIndex.ToString, chkHidePrintDialog.Checked)

        Alert("Settings have been saved")

    End Sub

    Private Sub cmbCuisine2_ValueChanged(sender As Object, e As EventArgs) Handles cmbCuisinePrinters.ValueChanged

        intCuisinePrintersIndex = cmbCuisinePrinters.SelectedIndex + 1
        CreatePrintersList()

    End Sub

    Private Sub cmbCuisine3_ValueChanged(sender As Object, e As EventArgs) Handles cmbCuisineLabelPrinter.ValueChanged

        If cmbCuisineLabelPrinter.SelectedIndex <> -1 Then
            chkPrintLabels.Checked = GetAppSettingCS("PrintLabels" & (cmbCuisineLabelPrinter.SelectedIndex + 1), 0)
            cmbPrinterLabel.Text = GetAppSettingCS("PrinterLabels" & (cmbCuisineLabelPrinter.SelectedIndex + 1), String.Empty)
            cmbLabelFontSize.Text = GetAppSettingCS("LabelFontsize" & (cmbCuisineLabelPrinter.SelectedIndex + 1), 10)
        End If

    End Sub

    Private Sub chkPrintLabels_CheckedChanged(sender As Object, e As EventArgs) Handles chkPrintLabels.CheckedChanged

        SaveAppSetting("PrintLabels" & cmbCuisineLabelPrinter.SelectedIndex + 1, chkPrintLabels.Checked)

    End Sub


    Private Sub cmbPrinterLabel_ValueChanged(sender As Object, e As EventArgs) Handles cmbPrinterLabel.ValueChanged

        If cmbCuisineLabelPrinter.SelectedIndex <> -1 Then SaveAppSetting("PrinterLabels" & cmbCuisineLabelPrinter.SelectedIndex + 1, cmbPrinterLabel.Text)

    End Sub

    Private Sub cmbLabelFontSize_ValueChanged(sender As Object, e As EventArgs) Handles cmbLabelFontSize.ValueChanged

        If cmbCuisineLabelPrinter.SelectedIndex <> -1 Then SaveAppSetting("LabelFontsize" & cmbCuisineLabelPrinter.SelectedIndex + 1, cmbLabelFontSize.Text)

    End Sub

    Private Sub chkPrintLabelAny_CheckedChanged(sender As Object, e As EventArgs) Handles chkPrintLabelAny.CheckedChanged

        SaveAppSetting("LabelsPrintAny", Val(chkPrintLabelAny.Checked))

    End Sub

    Private Sub cmdRenameGroup_Click(sender As Object, e As EventArgs) Handles cmdRenameGroup.Click

        If lstGroups.Items.Count > 0 Then
            If lstGroups.Items.Count = 1 AndAlso lstGroups.SelectedItems.Count = 0 Then lstGroups.SelectedItems.Add(lstGroups.Items(0))
            If lstGroups.SelectedItems.Count = 1 Then
                Dim strOldGroupName As String = lstGroups.SelectedItems(0).Text
                Dim strNewGroupName As String = InputBox("Enter new name:", "Change Name", strOldGroupName)
                If strNewGroupName <> String.Empty And strNewGroupName <> lstGroups.SelectedItems(0).Text Then
                    If Not IsInListbox(strNewGroupName, lstGroups) Then
                        SQLQuery = String.Format("UPDATE Dish SET GroupName = '{0}' WHERE GroupName = '{1}'", strNewGroupName.Punctuate, strOldGroupName.Punctuate)
                        objDB.ExeNonQuery(SQLQuery)
                        SQLQuery = String.Format("UPDATE Groups SET GroupName = '{0}' WHERE GroupName = '{1}'", strNewGroupName.Punctuate, strOldGroupName.Punctuate)
                        objDB.ExeNonQuery(SQLQuery)
                        SQLQuery = String.Format("UPDATE DishSubgroup SET TName = '{0}' WHERE TName = '{1}'", strNewGroupName.Punctuate, strOldGroupName.Punctuate)
                        objDB.ExeNonQuery(SQLQuery)
                        SQLQuery = String.Format("UPDATE DishCascade SET GroupName = '{0}' WHERE GroupName = '{1}'", strNewGroupName.Punctuate, strOldGroupName.Punctuate)
                        objDB.ExeNonQuery(SQLQuery)
                        lstGroups.Items(lstGroups.SelectedItems.First.Index).Value = strNewGroupName
                    Else
                        Alert("Cannot rename because '" & strNewGroupName & "' is already in the list")
                    End If
                End If
            Else
                Alert("Select the one item to rename")
            End If
        End If

        txtGroups.Focus()

    End Sub

    Private Sub cmdMergeGroup_Click(sender As Object, e As EventArgs) Handles cmdMergeGroup.Click

        If lstGroups.Items.Count >= 2 Then
            If lstGroups.SelectedItems.Count = 2 Then
                Dim strFirstItem As String = lstGroups.SelectedItems(0).Text
                Dim strSecondItem As String = lstGroups.SelectedItems(1).Text
                strMsgBox = String.Format("All dishes belonging to group '{0}' would now be under '{1}'." &
                                          " This cannot be undone. Do you want to proceed?", strFirstItem, strSecondItem)
                intResponseBox = EZMsgBox.Show(strMsgBox, MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                If intResponseBox = vbYes Then
                    SQLQuery = String.Format("UPDATE Dish SET GroupName = '{0}' WHERE GroupName = '{1}'", strSecondItem, strFirstItem)
                    objDB.ExeNonQuery(SQLQuery)
                    SQLQuery = String.Format("DELETE FROM Groups WHERE GroupName = '{0}'", strFirstItem)
                    objDB.ExeNonQuery(SQLQuery)
                    SQLQuery = String.Format("UPDATE DishCascade SET GroupName = '{0}' WHERE GroupName = '{1}'", strSecondItem, strFirstItem)
                    objDB.ExeNonQuery(SQLQuery)
                    lstGroups.Items.Remove(lstGroups.SelectedItems(0))
                End If

            Else
                strMsgBox = "You must select two groups to merge. First select group to merge, then select group to which merging should happen."
                Alert(strMsgBox)
            End If
        Else
            strMsgBox = "Two groups are needed for a merge."
            Alert(strMsgBox)
        End If

    End Sub

    Private Sub utcSettings_SelectedTabChanging(sender As Object, e As Infragistics.Win.UltraWinTabControl.SelectedTabChangingEventArgs) Handles utcSettings.SelectedTabChanging

        If e.Tab.Key = "Manager" Then
            If GetSuperFromDB() = False Then
                e.Cancel = True
                objSecurity.DisplaySuperError()
            End If
        End If

    End Sub

    Private Sub cmdEmailReport_Click(sender As Object, e As EventArgs) Handles cmdEmailReport.Click

        If File.Exists("ezerrorlog.txt") Then
            Dim MyFile As New FileInfo("ezerrorlog.txt")
            If MyFile.Length > 0 Then bgwEmailErrorLog.RunWorkerAsync()
        Else
            Alert("Log file not found")
        End If

    End Sub

    Private Sub chkTableExtSave_Click(sender As Object, e As EventArgs) Handles chkTableExtSave.Click

        SaveAppSetting("TablesExtMode", chkTableExtMode.Checked)
        SaveAppSetting("TablesExtLights", chkTableExtLights.Checked)
        SaveAppSetting("TablesExtLine1", txtTableExtLine1.Text.Trim)
        SaveAppSetting("TablesExtLine2", txtTableExtLine2.Text.Trim)
        SaveAppSetting("TablesExtLine3", txtTableExtLine3.Text.Trim)
        SaveAppSetting("TablesAutoCovers", chkTableAutoCovers.Checked)

        strMsgBox = "All have been saved"
        Alert(strMsgBox, MessageBoxIcon.Information)

    End Sub

    Private Sub chkTableExtDelete_Click(sender As Object, e As EventArgs) Handles chkTableExtDelete.Click

        SaveAppSetting("TablesExtMode", chkTableExtMode.Checked)
        SaveAppSetting("TablesExtLights", chkTableExtLights.Checked)
        SaveAppSetting("TablesExtLine1", "Starters served")
        SaveAppSetting("TablesExtLine2", "Mains served")
        SaveAppSetting("TablesExtLine3", "Bill paid")

        txtTableExtLine1.Clear()
        txtTableExtLine2.Clear()
        txtTableExtLine3.Clear()

    End Sub

    Private Sub cmdAddTStatus_Click(sender As Object, e As EventArgs) Handles cmdAddTStatus.Click

        tempStr = txtTStatus.Text.Trim

        If tempStr <> "" Then

            'see its not in list already
            If IsInListbox(tempStr, lstTStatus) = False Then
                lstTStatus.Items.Add(Rnd, txtTStatus.Text.Trim)
                SQLQuery = "INSERT INTO Table_Status (Status, Colour) VALUES ('" & tempStr & "', '" & ucpTStatus.Color.ToArgb & "');"
                objDB.ExeNonQuery(SQLQuery)
                txtTStatus.Clear()
                txtTStatus.Focus()
            Else
                strMsgBox = tempStr & " is already in the list"
                Alert(strMsgBox, MessageBoxIcon.Asterisk)
            End If

        End If

    End Sub

    Private Sub cmdDeleteTStatus_Click(sender As Object, e As EventArgs) Handles cmdDeleteTStatus.Click

        Try

            If lstTStatus.SelectedItems.Count = 0 Then Exit Sub

            For Each mySeln In lstTStatus.SelectedItems
                SQLQuery = "DELETE FROM Table_Status WHERE Status = '" & mySeln.Text & "'"
                objDB.ExeNonQuery(SQLQuery)
            Next

            For iCnt As Short = lstTStatus.SelectedItems.Count - 1 To 0 Step -1
                lstTStatus.Items.Remove(lstTStatus.SelectedItems(iCnt))
            Next

            If lstTStatus.Items.Count = 0 Then
                SQLQuery = "TRUNCATE TABLE Table_Status"
                objDB.ExeNonQuery(SQLQuery)
            End If

            txtTStatus.Focus()

        Catch ex As Exception

            DisplayError(ex)

        End Try

    End Sub

    Private Sub txtUserPassword_KeyPress(sender As Object, e As KeyPressEventArgs)

        Select Case e.KeyChar
            Case ChrW(Keys.D0) To ChrW(Keys.D9), ChrW(Keys.Back)
                e.Handled = False
            Case Else
                e.Handled = True
        End Select

    End Sub

    Private Sub chkRequireLogon_CheckedChanged(sender As Object, e As EventArgs) Handles chkRequireLogon.CheckedChanged

        If chkRequireLogon.Checked Then
            SQLQuery = "SELECT UserName FROM Users"
            drcDatarowCollection = objDB.GetDataRows(SQLQuery)
            If drcDatarowCollection.Count = 0 Then
                strMsgBox = "Change not allowed because there are no users in the database. Set the users in the Users tab then change this setting."
                chkRequireLogon.Checked = False
                Alert(strMsgBox)
            End If
        End If

    End Sub

    Private Sub cmdSaveLabelPrinters_Click(sender As Object, e As EventArgs) Handles cmdSaveLabelPrinters.Click

        Dim intCuisineLabelPrinter As Integer = cmbCuisineLabelPrinter.SelectedIndex + 1

        SaveAppSetting("PrinterLabel" & intCuisineLabelPrinter.ToString, cmbPrinterLabel.Text)
        SaveAppSetting("PrintLabels" & intCuisineLabelPrinter.ToString, chkPrintLabels.Checked)
        SaveAppSetting("LabelFontSize" & intCuisineLabelPrinter.ToString, cmbLabelFontSize.Text)

        txtLabelHeight.Text = Val(txtLabelHeight.Text)
        txtLabelWidth.Text = Val(txtLabelWidth.Text)
        txtLabelTopMargin.Text = Val(txtLabelTopMargin.Text)
        txtLabelLeftMargin.Text = Val(txtLabelLeftMargin.Text)
        If Val(txtLabelHeight.Text) < 0 Or Val(txtLabelWidth.Text) < 0 Then
            utcSettings.SelectedTab = utcSettings.Tabs("LabelPrinter")
            strMsgBox = "Invalid label height and/or width. Must be greater than 0."
            Alert(strMsgBox)
            Exit Sub
        Else
            SaveAppSetting("LabelHeight" & intCuisineLabelPrinter.ToString, txtLabelHeight.Text)
            SaveAppSetting("LabelWidth" & intCuisineLabelPrinter.ToString, txtLabelWidth.Text)
        End If
        SaveAppSetting("LabelTopMargin" & intCuisineLabelPrinter.ToString, txtLabelTopMargin.Text)
        SaveAppSetting("LabelLeftMargin" & intCuisineLabelPrinter.ToString, txtLabelLeftMargin.Text)
        SaveAppSetting("LabelTopOffset" & intCuisineLabelPrinter.ToString, txtLabelTopOffset.Text)
        SaveAppSetting("LabelLeftOffset" & intCuisineLabelPrinter.ToString, txtLabelLeftOffset.Text)

        SaveAppSetting("PrintLabelAny" & intCuisineLabelPrinter.ToString, chkPrintLabelAny.Checked)

        Alert("Settings have been saved")

    End Sub

    Private Sub chkTableExtMode_CheckedChanged(sender As Object, e As EventArgs) Handles chkTableExtMode.CheckedChanged

        If chkTableExtMode.Checked = True Then
            chkTableExtLights.Enabled = True
        Else
            chkTableExtLights.Checked = False
            chkTableExtLights.Enabled = False
        End If

    End Sub
End Class