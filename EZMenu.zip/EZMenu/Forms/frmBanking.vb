﻿Imports System.Configuration
Imports System.IO
Imports EZControls
Imports EZMenu.Core

Public Class frmBanking

    Dim strFileName As String
    Dim twrWriter As TextWriter

    Private Sub frmBanking_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        BankingTableAdapter.Connection.ConnectionString = ConfigurationManager.ConnectionStrings(EZConstants.EZDatabaseConnectionString).ConnectionString
        BankingTableAdapter.Fill(EZMenuDataSet.Banking)

        'Size = Owner.Size
        'Location = Owner.Location

        txtDate.Text = Format(Now, "dd/MM/yy")
        txtPrintStart.Text = Format(Now.AddMonths(-3), "dd/MM/yy")
        txtPrintEnd.Text = Format(Now, "dd/MM/yy")

    End Sub

    Private Sub cmdClose_Click(sender As Object, e As EventArgs) Handles cmdClose.Click
        Close()
    End Sub

    Private Sub cmdKBTotal_Click(sender As Object, e As EventArgs) Handles cmdKBTotal.Click

        Dim strNumInput As String

        Using objFormQty As New frmQty
            objFormQty.Display("Enter amount", "0.00")
            strNumInput = objFormQty.ReturnValue
        End Using

        If strNumInput <> "x" Then txtTotal.Text = fixCur(strNumInput)

    End Sub

    Private Sub cmdKBTips_Click(sender As Object, e As EventArgs) Handles cmdKBTips.Click

        Dim strNumInput As String

        Using objFormQty As New frmQty
            objFormQty.Display("Enter amount", "0.00")
            strNumInput = objFormQty.ReturnValue
        End Using

        If strNumInput <> "x" Then txtTips.Text = fixCur(strNumInput)

    End Sub

    Private Sub cmdClear_Click(sender As Object, e As EventArgs) Handles cmdClear.Click

        txtCash.Text = "0.00"
        txtCard.Text = "0.00"
        txtOther.Text = "0.00"
        txtTips.Text = "0.00"
        txtTotal.Text = "0.00"

    End Sub

    Private Sub cmdKBPrintStart_Click(sender As Object, e As EventArgs) Handles cmdKBPrintStart.Click

        Dim strDate As String = EZDatePicker.SelectedDate
        If strDate <> String.Empty Then
            txtPrintStart.Text = Format(CDate(strDate), "dd/MM/yy")
        End If

    End Sub

    Private Sub cmdKBPrintEnd_Click(sender As Object, e As EventArgs) Handles cmdKBPrintEnd.Click

        Dim strDate As String = EZDatePicker.SelectedDate
        If strDate <> String.Empty Then
            txtPrintEnd.Text = Format(CDate(strDate), "dd/MM/yy")
        End If

    End Sub

    Private Sub cmdKBDate_Click(sender As Object, e As EventArgs) Handles cmdKBDate.Click

        Dim strDate As String = EZDatePicker.SelectedDate
        If strDate <> String.Empty Then
            txtDate.Text = Format(CDate(strDate), "dd/MM/yy")
        End If

    End Sub

    Private Sub cmdOK_Click(sender As Object, e As EventArgs) Handles cmdOK.Click

        'validate inputs
        If Not IsDate(txtDate.Text) Then
            EZMsgBox.Show("Input is not a date", MessageBoxButtons.Ok, MessageBoxIcon.Error)
            txtDate.Focus()
        ElseIf Not IsANumber(txtCard.Text) Then
            EZMsgBox.Show("Input is invalid. Put an amount in this box.", MessageBoxButtons.Ok, MessageBoxIcon.Error)
            txtCard.Focus()
        ElseIf Not IsANumber(txtCash.Text) Then
            EZMsgBox.Show("Input is invalid. Put an amount in this box.", MessageBoxButtons.Ok, MessageBoxIcon.Error)
            txtCash.Focus()
        ElseIf Not IsANumber(txtOther.Text) Then
            EZMsgBox.Show("Input is invalid. Put an amount in this box.", MessageBoxButtons.Ok, MessageBoxIcon.Error)
            txtOther.Focus()
        ElseIf Not IsANumber(txtTotal.Text) Then
            EZMsgBox.Show("Input is invalid. Put an amount in this box.", MessageBoxButtons.Ok, MessageBoxIcon.Error)
            txtTotal.Focus()
        ElseIf Not IsANumber(txtTips.Text) Then
            EZMsgBox.Show("Input is invalid. Put an amount in this box.", MessageBoxButtons.Ok, MessageBoxIcon.Error)
            txtTips.Focus()

        Else

            Dim myRow As DataRow

            SQLQuery = String.Format("DELETE FROM Banking WHERE Date = '{0}'", Format(CDate(txtDate.Text), "dd/MMM/yyyy"))
            objDB.ExeNonQuery(SQLQuery)
            BankingTableAdapter.Fill(EZMenuDataSet.Banking)

            txtCash.Text = fixCur(txtCash.Text)
            txtCard.Text = fixCur(txtCard.Text)
            txtOther.Text = fixCur(txtOther.Text)
            txtTotal.Text = fixCur(txtTotal.Text)
            txtTips.Text = fixCur(txtTips.Text)

            myRow = EZMenuDataSet.Banking.NewRow
            myRow.Item("Date") = txtDate.Text
            myRow.Item("Cash") = txtCash.Text
            myRow.Item("Card") = txtCard.Text
            myRow.Item("Other") = txtOther.Text
            myRow.Item("Tips") = txtTips.Text
            myRow.Item("Total") = txtTotal.Text
            EZMenuDataSet.Banking.Rows.Add(myRow)

            BankingTableAdapter.Update(EZMenuDataSet.Banking)

        End If

    End Sub

    Private Sub cmdKBCash_Click(sender As Object, e As EventArgs) Handles cmdKBCash.Click

        Dim strNumInput As String

        Using objFormQty As New frmQty
            objFormQty.Display("Enter amount", "0.00")
            strNumInput = objFormQty.ReturnValue
        End Using

        If strNumInput <> "x" Then txtCash.Text = fixCur(strNumInput)

    End Sub

    Private Sub cmdKBCard_Click(sender As Object, e As EventArgs) Handles cmdKBCard.Click

        Dim strNumInput As String = String.Empty

        Using objFormQty As New frmQty
            objFormQty.Display("Enter amount", "0.00")
            strNumInput = objFormQty.ReturnValue
        End Using

        If strNumInput <> "x" Then txtCard.Text = fixCur(strNumInput)

    End Sub

    Private Sub cmdKBOther_Click(sender As Object, e As EventArgs) Handles cmdKBOther.Click

        Dim strNumInput As String = String.Empty

        Using objFormQty As New frmQty
            objFormQty.Display("Enter amount", "0.00")
            strNumInput = objFormQty.ReturnValue
        End Using

        If strNumInput <> "x" Then txtOther.Text = fixCur(strNumInput)

    End Sub

    Private Sub cmdGridUpDown_Click(sender As Object, e As EventArgs) Handles cmdGridUp.Click, cmdGridDown.Click

        If ugdBanking.Rows.Count = 0 Then Exit Sub

        If ugdBanking.ActiveRow Is Nothing Then
            ugdBanking.ActiveRow = ugdBanking.Rows(0)
        End If

        If sender.name = "cmdGridUp" Then

            If ugdBanking.ActiveRow.Index > 0 Then
                ugdBanking.ActiveRow = ugdBanking.Rows(ugdBanking.ActiveRow.Index - 1)
            Else
                ugdBanking.ActiveRow = ugdBanking.Rows(ugdBanking.Rows.Count - 1)
            End If

        Else

            If ugdBanking.ActiveRow.Index < ugdBanking.Rows.Count - 1 Then
                ugdBanking.ActiveRow = ugdBanking.Rows(ugdBanking.ActiveRow.Index + 1)
            Else
                ugdBanking.ActiveRow = ugdBanking.Rows(0)
            End If

        End If

        Try
            txtDate.Text = Format(ugdBanking.ActiveRow.Cells("Date").Value, "dd/MM/yy")
            txtCash.Text = fixCur(ugdBanking.ActiveRow.Cells("Cash").Value)
            txtCard.Text = fixCur(ugdBanking.ActiveRow.Cells("Card").Value)
            txtOther.Text = fixCur(ugdBanking.ActiveRow.Cells("Other").Value)
            txtTips.Text = fixCur(ugdBanking.ActiveRow.Cells("Tips").Value)
            txtTotal.Text = fixCur(ugdBanking.ActiveRow.Cells("Total").Value)

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub cmdAdd_Click(sender As Object, e As EventArgs) Handles cmdAdd.Click

        txtTotal.Text = fixCur(Val(txtCash.Text) + Val(txtCard.Text) + Val(txtOther.Text) + Val(txtTips.Text))

    End Sub

    Private Sub cmdPrintReport_Click(sender As Object, e As EventArgs) Handles cmdPrintReport.Click

        If Not IsDate(txtPrintStart.Text) Then
            strMsgBox = "Invalid start date specified"
            EZMsgBox.Show(strMsgBox, MessageBoxIcon.Asterisk)
            txtPrintStart.Focus()
        ElseIf Not IsDate(txtPrintEnd.Text) Then
            strMsgBox = "Invalid end date specified"
            EZMsgBox.Show(strMsgBox, MessageBoxIcon.Asterisk)
            txtPrintEnd.Focus()
        Else

            SQLQuery = String.Format("SELECT Date, Cash, Card, Other, Tips, Total " &
                                     "FROM Banking WHERE (Date BETWEEN '{0}' AND '{1}')" &
                                     "ORDER BY Date DESC", Format(CDate(txtPrintStart.Text), "dd/MMM/yyyy"), Format(CDate(txtPrintEnd.Text), "dd/MMM/yyyy"))

            drcDatarowCollection = objDB.GetDataRows(SQLQuery)
            If drcDatarowCollection.Count > 0 Then
                Try
                    strFileName = GetEZPDAPath() & "REPORT.DAT"
                    If File.Exists(strFileName) Then File.Delete(strFileName)

                    twrWriter = New StreamWriter(strFileName)
                    WriteField("#StartDate = " & txtPrintStart.Text)
                    WriteField("#EndDate = " & txtPrintEnd.Text)
                    For Each myRow As DataRow In drcDatarowCollection
                        tempStr = Format(CDate(myRow("Date")), "dd/MM/yy") & ","
                        tempStr &= myRow("Cash") & ","
                        tempStr &= myRow("Card") & ","
                        tempStr &= myRow("Other") & ","
                        tempStr &= myRow("Tips") & ","
                        tempStr &= myRow("Total")
                        WriteField(tempStr)
                    Next
                    twrWriter.Flush()
                    twrWriter.Close()

                Catch ex As Exception
                    DisplayError(ex)
                End Try
            Else
                Alert("No records found between specified dates.")
            End If
        End If

    End Sub

    Private Sub cmdPrintShowAll_Click(sender As Object, e As EventArgs) Handles cmdPrintShowAll.Click

        BankingTableAdapter.Fill(EZMenuDataSet.Banking)

    End Sub

    Private Sub cmdDeleteRow_Click(sender As Object, e As EventArgs) Handles cmdDeleteRow.Click

        If ugdBanking.ActiveRow IsNot Nothing Then
            ugdBanking.ActiveRow.Delete()
            BankingTableAdapter.Update(EZMenuDataSet.Banking)
        End If

    End Sub

    Private Sub cmdPrintToday_Click(sender As Object, e As EventArgs) Handles cmdPrintToday.Click

        Try
            strFileName = GetEZPDAPath() & "BANKING.DAT"
            If File.Exists(strFileName) Then File.Delete(strFileName)

            twrWriter = New StreamWriter(strFileName)
            WriteField("#Date = " & txtDate.Text)
            WriteField("#Cash = " & txtCash.Text)
            WriteField("#Cards = " & txtCard.Text)
            WriteField("#Other = " & txtOther.Text)
            WriteField("#Tips = " & txtTips.Text)
            WriteField("#Total = " & txtTotal.Text)

            twrWriter.Flush()
            twrWriter.Close()

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub WriteField(strFieldToWrite As String, Optional strFieldName As String = "")

        If strFieldToWrite.Trim = "" Then Exit Sub

        If strFieldName = "" Then

            If InStr(strFieldToWrite, "=") = 0 Then
                tempStr = strFieldToWrite
            Else
                tempStr = strFieldToWrite.Substring(strFieldToWrite.IndexOf(" = ") + 3).Trim
            End If

            If tempStr <> "" Then twrWriter.WriteLine(strFieldToWrite)

        Else
            'get the field setting from the DB which was put in there by SaveInDatabase
            tempStr = strFieldToWrite & strFieldName
            twrWriter.WriteLine(tempStr)
        End If

    End Sub

    Private Sub txtCash_TextChanged(sender As Object, e As EventArgs) Handles txtCash.TextChanged
        CalculateTotals()
    End Sub

    Private Sub txtCard_TextChanged(sender As Object, e As EventArgs) Handles txtCard.TextChanged
        CalculateTotals()
    End Sub

    Private Sub txtOther_TextChanged(sender As Object, e As EventArgs) Handles txtOther.TextChanged
        CalculateTotals()
    End Sub

    Private Sub txtTips_TextChanged(sender As Object, e As EventArgs) Handles txtTips.TextChanged
        CalculateTotals()
    End Sub

    Private Sub CalculateTotals()

        txtTotal.Text = fixCur(Val(txtCash.Text) + Val(txtCard.Text) + Val(txtOther.Text) + Val(txtTips.Text))

    End Sub

End Class