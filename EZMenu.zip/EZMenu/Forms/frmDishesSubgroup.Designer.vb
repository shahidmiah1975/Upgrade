﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDishesSubgroup
	Inherits System.Windows.Forms.Form

	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		Try
			If disposing AndAlso components IsNot Nothing Then
				components.Dispose()
			End If
		Finally
			MyBase.Dispose(disposing)
		End Try
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
        Dim Appearance1 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance3 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance4 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance5 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance6 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance7 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance10 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance11 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance12 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance13 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance2 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance9 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance8 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Me.cmbSubgroups = New Infragistics.Win.UltraWinEditors.UltraComboEditor()
        Me.lstSubgroups = New Infragistics.Win.UltraWinListView.UltraListView()
        Me.upnlSubgrouping = New Infragistics.Win.Misc.UltraPanel()
        Me.cmdAdd = New Infragistics.Win.Misc.UltraButton()
        Me.cmdCancel = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDelete = New Infragistics.Win.Misc.UltraButton()
        Me.cmdSave = New Infragistics.Win.Misc.UltraButton()
        Me.upnlExtraLabels = New Infragistics.Win.Misc.UltraPanel()
        Me.cmdClose = New Infragistics.Win.Misc.UltraButton()
        Me.cmdTurnOffLabel = New Infragistics.Win.Misc.UltraButton()
        Me.lstLabelItems = New Infragistics.Win.UltraWinListView.UltraListView()
        Me.cmdLabelRemove = New Infragistics.Win.Misc.UltraButton()
        Me.cmdLabelAdd = New Infragistics.Win.Misc.UltraButton()
        Me.UltraLabel1 = New Infragistics.Win.Misc.UltraLabel()
        Me.lblStatus = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel3 = New Infragistics.Win.Misc.UltraLabel()
        CType(Me.cmbSubgroups, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lstSubgroups, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.upnlSubgrouping.ClientArea.SuspendLayout()
        Me.upnlSubgrouping.SuspendLayout()
        Me.upnlExtraLabels.ClientArea.SuspendLayout()
        Me.upnlExtraLabels.SuspendLayout()
        CType(Me.lstLabelItems, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'cmbSubgroups
        '
        Me.cmbSubgroups.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList
        Me.cmbSubgroups.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbSubgroups.Location = New System.Drawing.Point(23, 60)
        Me.cmbSubgroups.Name = "cmbSubgroups"
        Me.cmbSubgroups.Size = New System.Drawing.Size(176, 26)
        Me.cmbSubgroups.TabIndex = 79
        Me.cmbSubgroups.UseAppStyling = False
        '
        'lstSubgroups
        '
        Me.lstSubgroups.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Me.lstSubgroups.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstSubgroups.ItemSettings.AllowEdit = Infragistics.Win.DefaultableBoolean.[False]
        Me.lstSubgroups.ItemSettings.HideSelection = False
        Me.lstSubgroups.ItemSettings.HotTracking = True
        Me.lstSubgroups.Location = New System.Drawing.Point(205, 60)
        Me.lstSubgroups.Name = "lstSubgroups"
        Me.lstSubgroups.ShowGroups = False
        Me.lstSubgroups.Size = New System.Drawing.Size(172, 210)
        Me.lstSubgroups.TabIndex = 84
        Me.lstSubgroups.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        Me.lstSubgroups.View = Infragistics.Win.UltraWinListView.UltraListViewStyle.List
        Me.lstSubgroups.ViewSettingsList.ImageSize = New System.Drawing.Size(0, 0)
        Me.lstSubgroups.ViewSettingsList.MultiColumn = False
        '
        'upnlSubgrouping
        '
        Appearance1.BackColor = System.Drawing.Color.Transparent
        Appearance1.BorderColor = System.Drawing.Color.Silver
        Me.upnlSubgrouping.Appearance = Appearance1
        Me.upnlSubgrouping.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        '
        'upnlSubgrouping.ClientArea
        '
        Me.upnlSubgrouping.ClientArea.Controls.Add(Me.UltraLabel1)
        Me.upnlSubgrouping.ClientArea.Controls.Add(Me.lstSubgroups)
        Me.upnlSubgrouping.ClientArea.Controls.Add(Me.cmbSubgroups)
        Me.upnlSubgrouping.ClientArea.Controls.Add(Me.cmdAdd)
        Me.upnlSubgrouping.ClientArea.Controls.Add(Me.cmdCancel)
        Me.upnlSubgrouping.ClientArea.Controls.Add(Me.cmdDelete)
        Me.upnlSubgrouping.ClientArea.Controls.Add(Me.cmdSave)
        Me.upnlSubgrouping.Location = New System.Drawing.Point(12, 12)
        Me.upnlSubgrouping.Name = "upnlSubgrouping"
        Me.upnlSubgrouping.Size = New System.Drawing.Size(525, 292)
        Me.upnlSubgrouping.TabIndex = 85
        '
        'cmdAdd
        '
        Me.cmdAdd.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance3.BackColor = System.Drawing.Color.Transparent
        Me.cmdAdd.Appearance = Appearance3
        Me.cmdAdd.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdAdd.Location = New System.Drawing.Point(393, 70)
        Me.cmdAdd.Name = "cmdAdd"
        Me.cmdAdd.ShowFocusRect = False
        Me.cmdAdd.ShowOutline = False
        Me.cmdAdd.Size = New System.Drawing.Size(105, 35)
        Me.cmdAdd.StyleSetName = "TextButton"
        Me.cmdAdd.TabIndex = 559
        Me.cmdAdd.Text = "Add"
        Me.cmdAdd.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        '
        'cmdCancel
        '
        Me.cmdCancel.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance4.BackColor = System.Drawing.Color.Transparent
        Me.cmdCancel.Appearance = Appearance4
        Me.cmdCancel.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdCancel.Location = New System.Drawing.Point(393, 221)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.ShowFocusRect = False
        Me.cmdCancel.ShowOutline = False
        Me.cmdCancel.Size = New System.Drawing.Size(105, 35)
        Me.cmdCancel.StyleSetName = "TextButton"
        Me.cmdCancel.TabIndex = 562
        Me.cmdCancel.Text = "Cancel"
        Me.cmdCancel.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        '
        'cmdDelete
        '
        Me.cmdDelete.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance5.BackColor = System.Drawing.Color.Transparent
        Me.cmdDelete.Appearance = Appearance5
        Me.cmdDelete.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdDelete.Location = New System.Drawing.Point(393, 111)
        Me.cmdDelete.Name = "cmdDelete"
        Me.cmdDelete.ShowFocusRect = False
        Me.cmdDelete.ShowOutline = False
        Me.cmdDelete.Size = New System.Drawing.Size(105, 35)
        Me.cmdDelete.StyleSetName = "TextButton"
        Me.cmdDelete.TabIndex = 560
        Me.cmdDelete.Text = "Delete"
        Me.cmdDelete.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        '
        'cmdSave
        '
        Me.cmdSave.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance6.BackColor = System.Drawing.Color.Transparent
        Me.cmdSave.Appearance = Appearance6
        Me.cmdSave.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdSave.Location = New System.Drawing.Point(393, 180)
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.ShowFocusRect = False
        Me.cmdSave.ShowOutline = False
        Me.cmdSave.Size = New System.Drawing.Size(105, 35)
        Me.cmdSave.StyleSetName = "TextButton"
        Me.cmdSave.TabIndex = 561
        Me.cmdSave.Text = "Save"
        Me.cmdSave.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        '
        'upnlExtraLabels
        '
        Appearance7.BackColor = System.Drawing.Color.Transparent
        Appearance7.BorderColor = System.Drawing.Color.Silver
        Me.upnlExtraLabels.Appearance = Appearance7
        Me.upnlExtraLabels.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        '
        'upnlExtraLabels.ClientArea
        '
        Me.upnlExtraLabels.ClientArea.Controls.Add(Me.UltraLabel3)
        Me.upnlExtraLabels.ClientArea.Controls.Add(Me.lblStatus)
        Me.upnlExtraLabels.ClientArea.Controls.Add(Me.cmdClose)
        Me.upnlExtraLabels.ClientArea.Controls.Add(Me.cmdTurnOffLabel)
        Me.upnlExtraLabels.ClientArea.Controls.Add(Me.lstLabelItems)
        Me.upnlExtraLabels.ClientArea.Controls.Add(Me.cmdLabelRemove)
        Me.upnlExtraLabels.ClientArea.Controls.Add(Me.cmdLabelAdd)
        Me.upnlExtraLabels.Location = New System.Drawing.Point(12, 12)
        Me.upnlExtraLabels.Name = "upnlExtraLabels"
        Me.upnlExtraLabels.Size = New System.Drawing.Size(525, 292)
        Me.upnlExtraLabels.TabIndex = 86
        '
        'cmdClose
        '
        Me.cmdClose.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance10.BackColor = System.Drawing.Color.Transparent
        Me.cmdClose.Appearance = Appearance10
        Me.cmdClose.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdClose.Location = New System.Drawing.Point(368, 212)
        Me.cmdClose.Name = "cmdClose"
        Me.cmdClose.ShowFocusRect = False
        Me.cmdClose.ShowOutline = False
        Me.cmdClose.Size = New System.Drawing.Size(105, 35)
        Me.cmdClose.StyleSetName = "TextButton"
        Me.cmdClose.TabIndex = 566
        Me.cmdClose.Text = "Close"
        Me.cmdClose.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        '
        'cmdTurnOffLabel
        '
        Me.cmdTurnOffLabel.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance11.BackColor = System.Drawing.Color.Transparent
        Me.cmdTurnOffLabel.Appearance = Appearance11
        Me.cmdTurnOffLabel.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdTurnOffLabel.Location = New System.Drawing.Point(368, 171)
        Me.cmdTurnOffLabel.Name = "cmdTurnOffLabel"
        Me.cmdTurnOffLabel.ShowFocusRect = False
        Me.cmdTurnOffLabel.ShowOutline = False
        Me.cmdTurnOffLabel.Size = New System.Drawing.Size(105, 35)
        Me.cmdTurnOffLabel.StyleSetName = "TextButton"
        Me.cmdTurnOffLabel.TabIndex = 565
        Me.cmdTurnOffLabel.Text = "Enable"
        Me.cmdTurnOffLabel.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        '
        'lstLabelItems
        '
        Me.lstLabelItems.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Me.lstLabelItems.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstLabelItems.ItemSettings.AllowEdit = Infragistics.Win.DefaultableBoolean.[False]
        Me.lstLabelItems.ItemSettings.HideSelection = False
        Me.lstLabelItems.ItemSettings.HotTracking = True
        Me.lstLabelItems.Location = New System.Drawing.Point(118, 56)
        Me.lstLabelItems.Name = "lstLabelItems"
        Me.lstLabelItems.ShowGroups = False
        Me.lstLabelItems.Size = New System.Drawing.Size(213, 198)
        Me.lstLabelItems.TabIndex = 90
        Me.lstLabelItems.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        Me.lstLabelItems.View = Infragistics.Win.UltraWinListView.UltraListViewStyle.List
        Me.lstLabelItems.ViewSettingsList.ImageSize = New System.Drawing.Size(0, 0)
        Me.lstLabelItems.ViewSettingsList.MultiColumn = False
        '
        'cmdLabelRemove
        '
        Me.cmdLabelRemove.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance12.BackColor = System.Drawing.Color.Transparent
        Me.cmdLabelRemove.Appearance = Appearance12
        Me.cmdLabelRemove.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdLabelRemove.Location = New System.Drawing.Point(368, 102)
        Me.cmdLabelRemove.Name = "cmdLabelRemove"
        Me.cmdLabelRemove.ShowFocusRect = False
        Me.cmdLabelRemove.ShowOutline = False
        Me.cmdLabelRemove.Size = New System.Drawing.Size(105, 35)
        Me.cmdLabelRemove.StyleSetName = "TextButton"
        Me.cmdLabelRemove.TabIndex = 564
        Me.cmdLabelRemove.Text = "Remove"
        Me.cmdLabelRemove.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        '
        'cmdLabelAdd
        '
        Me.cmdLabelAdd.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance13.BackColor = System.Drawing.Color.Transparent
        Me.cmdLabelAdd.Appearance = Appearance13
        Me.cmdLabelAdd.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdLabelAdd.Location = New System.Drawing.Point(368, 61)
        Me.cmdLabelAdd.Name = "cmdLabelAdd"
        Me.cmdLabelAdd.ShowFocusRect = False
        Me.cmdLabelAdd.ShowOutline = False
        Me.cmdLabelAdd.Size = New System.Drawing.Size(105, 35)
        Me.cmdLabelAdd.StyleSetName = "TextButton"
        Me.cmdLabelAdd.TabIndex = 563
        Me.cmdLabelAdd.Text = "Add"
        Me.cmdLabelAdd.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        '
        'UltraLabel1
        '
        Appearance2.ForeColor = System.Drawing.Color.DimGray
        Me.UltraLabel1.Appearance = Appearance2
        Me.UltraLabel1.AutoSize = True
        Me.UltraLabel1.Font = New System.Drawing.Font("Segoe UI", 11.25!)
        Me.UltraLabel1.Location = New System.Drawing.Point(115, 21)
        Me.UltraLabel1.Name = "UltraLabel1"
        Me.UltraLabel1.Size = New System.Drawing.Size(292, 22)
        Me.UltraLabel1.TabIndex = 563
        Me.UltraLabel1.Text = "Select the subgroup(s) to add this item to:"
        '
        'lblStatus
        '
        Appearance9.ForeColor = System.Drawing.Color.DimGray
        Me.lblStatus.Appearance = Appearance9
        Me.lblStatus.AutoSize = True
        Me.lblStatus.Font = New System.Drawing.Font("Segoe UI", 11.25!)
        Me.lblStatus.Location = New System.Drawing.Point(130, 260)
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(262, 22)
        Me.lblStatus.TabIndex = 567
        Me.lblStatus.Text = "Label printing is disabled for this item"
        '
        'UltraLabel3
        '
        Appearance8.ForeColor = System.Drawing.Color.DimGray
        Me.UltraLabel3.Appearance = Appearance8
        Me.UltraLabel3.AutoSize = True
        Me.UltraLabel3.Font = New System.Drawing.Font("Segoe UI", 11.25!)
        Me.UltraLabel3.Location = New System.Drawing.Point(27, 21)
        Me.UltraLabel3.Name = "UltraLabel3"
        Me.UltraLabel3.Size = New System.Drawing.Size(469, 22)
        Me.UltraLabel3.TabIndex = 568
        Me.UltraLabel3.Text = "When printing this item, the labels named below will also be printed"
        '
        'frmDishesSubgroup
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(550, 317)
        Me.ControlBox = False
        Me.Controls.Add(Me.upnlExtraLabels)
        Me.Controls.Add(Me.upnlSubgrouping)
        Me.DoubleBuffered = True
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "frmDishesSubgroup"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        CType(Me.cmbSubgroups, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lstSubgroups, System.ComponentModel.ISupportInitialize).EndInit()
        Me.upnlSubgrouping.ClientArea.ResumeLayout(False)
        Me.upnlSubgrouping.ClientArea.PerformLayout()
        Me.upnlSubgrouping.ResumeLayout(False)
        Me.upnlExtraLabels.ClientArea.ResumeLayout(False)
        Me.upnlExtraLabels.ClientArea.PerformLayout()
        Me.upnlExtraLabels.ResumeLayout(False)
        CType(Me.lstLabelItems, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub


    Friend WithEvents cmdDishClose As System.Windows.Forms.Button
    Friend WithEvents cmbSubgroups As Infragistics.Win.UltraWinEditors.UltraComboEditor
    Friend WithEvents lstSubgroups As Infragistics.Win.UltraWinListView.UltraListView
    Friend WithEvents upnlSubgrouping As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents upnlExtraLabels As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents lstLabelItems As Infragistics.Win.UltraWinListView.UltraListView
    Friend WithEvents cmdAdd As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdCancel As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDelete As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdSave As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdClose As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdTurnOffLabel As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdLabelRemove As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdLabelAdd As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraLabel1 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel3 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblStatus As Infragistics.Win.Misc.UltraLabel
End Class
