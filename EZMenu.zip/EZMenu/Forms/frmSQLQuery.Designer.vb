﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSQLQuery
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim Appearance1 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmSQLQuery))
        Dim Appearance2 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance3 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance4 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance5 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance6 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance7 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance8 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance9 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance10 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance11 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance12 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance13 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance14 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance15 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Me.cmdOK = New Infragistics.Win.Misc.UltraButton()
        Me.cmdCancel = New Infragistics.Win.Misc.UltraButton()
        Me.txtQuery = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.cmdDBBackup = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDBRestore = New Infragistics.Win.Misc.UltraButton()
        Me.lblQueryLabel = New Infragistics.Win.Misc.UltraLabel()
        Me.lblStatus = New Infragistics.Win.Misc.UltraLabel()
        CType(Me.txtQuery, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'cmdOK
        '
        Me.cmdOK.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance1.ForeColor = System.Drawing.Color.DimGray
        Appearance1.Image = CType(resources.GetObject("Appearance1.Image"), Object)
        Appearance1.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance1.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance1.TextVAlignAsString = "Bottom"
        Me.cmdOK.Appearance = Appearance1
        Me.cmdOK.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdOK.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance2.BackColor = System.Drawing.Color.DarkOrange
        Appearance2.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance2.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance2.ForeColor = System.Drawing.Color.Black
        Me.cmdOK.HotTrackAppearance = Appearance2
        Me.cmdOK.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdOK.Location = New System.Drawing.Point(507, 324)
        Me.cmdOK.Name = "cmdOK"
        Appearance3.BackColor = System.Drawing.Color.OrangeRed
        Appearance3.BackColor2 = System.Drawing.Color.Tomato
        Appearance3.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdOK.PressedAppearance = Appearance3
        Me.cmdOK.ShowFocusRect = False
        Me.cmdOK.ShowOutline = False
        Me.cmdOK.Size = New System.Drawing.Size(115, 60)
        Me.cmdOK.StyleSetName = "StatusBar"
        Me.cmdOK.TabIndex = 370
        Me.cmdOK.Tag = ""
        Me.cmdOK.Text = "Execute SQL"
        Me.cmdOK.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOK.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOK.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdCancel
        '
        Me.cmdCancel.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance4.ForeColor = System.Drawing.Color.DimGray
        Appearance4.Image = CType(resources.GetObject("Appearance4.Image"), Object)
        Appearance4.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance4.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance4.TextVAlignAsString = "Bottom"
        Me.cmdCancel.Appearance = Appearance4
        Me.cmdCancel.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdCancel.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance5.BackColor = System.Drawing.Color.DarkOrange
        Appearance5.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance5.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance5.ForeColor = System.Drawing.Color.Black
        Me.cmdCancel.HotTrackAppearance = Appearance5
        Me.cmdCancel.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdCancel.Location = New System.Drawing.Point(628, 324)
        Me.cmdCancel.Name = "cmdCancel"
        Appearance6.BackColor = System.Drawing.Color.OrangeRed
        Appearance6.BackColor2 = System.Drawing.Color.Tomato
        Appearance6.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdCancel.PressedAppearance = Appearance6
        Me.cmdCancel.ShowFocusRect = False
        Me.cmdCancel.ShowOutline = False
        Me.cmdCancel.Size = New System.Drawing.Size(70, 60)
        Me.cmdCancel.StyleSetName = "StatusBar"
        Me.cmdCancel.TabIndex = 369
        Me.cmdCancel.Tag = "Cancel"
        Me.cmdCancel.Text = "Cancel"
        Me.cmdCancel.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdCancel.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdCancel.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtQuery
        '
        Me.txtQuery.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance7.BackColor = System.Drawing.Color.Beige
        Me.txtQuery.Appearance = Appearance7
        Me.txtQuery.BackColor = System.Drawing.Color.Beige
        Me.txtQuery.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtQuery.Location = New System.Drawing.Point(12, 100)
        Me.txtQuery.MaxLength = 0
        Me.txtQuery.Multiline = True
        Me.txtQuery.Name = "txtQuery"
        Me.txtQuery.Size = New System.Drawing.Size(686, 194)
        Me.txtQuery.TabIndex = 506
        Me.txtQuery.UseAppStyling = False
        '
        'cmdDBBackup
        '
        Me.cmdDBBackup.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Appearance8.ForeColor = System.Drawing.Color.DimGray
        Appearance8.Image = CType(resources.GetObject("Appearance8.Image"), Object)
        Appearance8.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance8.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance8.TextVAlignAsString = "Bottom"
        Me.cmdDBBackup.Appearance = Appearance8
        Me.cmdDBBackup.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdDBBackup.Enabled = False
        Me.cmdDBBackup.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance9.BackColor = System.Drawing.Color.DarkOrange
        Appearance9.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance9.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance9.ForeColor = System.Drawing.Color.Black
        Me.cmdDBBackup.HotTrackAppearance = Appearance9
        Me.cmdDBBackup.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdDBBackup.Location = New System.Drawing.Point(12, 324)
        Me.cmdDBBackup.Name = "cmdDBBackup"
        Appearance10.BackColor = System.Drawing.Color.OrangeRed
        Appearance10.BackColor2 = System.Drawing.Color.Tomato
        Appearance10.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdDBBackup.PressedAppearance = Appearance10
        Me.cmdDBBackup.ShowFocusRect = False
        Me.cmdDBBackup.ShowOutline = False
        Me.cmdDBBackup.Size = New System.Drawing.Size(70, 60)
        Me.cmdDBBackup.StyleSetName = "StatusBar"
        Me.cmdDBBackup.TabIndex = 507
        Me.cmdDBBackup.Tag = ""
        Me.cmdDBBackup.Text = "Backup"
        Me.cmdDBBackup.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDBBackup.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDBBackup.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDBRestore
        '
        Me.cmdDBRestore.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Appearance11.ForeColor = System.Drawing.Color.DimGray
        Appearance11.Image = CType(resources.GetObject("Appearance11.Image"), Object)
        Appearance11.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance11.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance11.TextVAlignAsString = "Bottom"
        Me.cmdDBRestore.Appearance = Appearance11
        Me.cmdDBRestore.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdDBRestore.Enabled = False
        Me.cmdDBRestore.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance12.BackColor = System.Drawing.Color.DarkOrange
        Appearance12.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance12.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance12.ForeColor = System.Drawing.Color.Black
        Me.cmdDBRestore.HotTrackAppearance = Appearance12
        Me.cmdDBRestore.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdDBRestore.Location = New System.Drawing.Point(88, 324)
        Me.cmdDBRestore.Name = "cmdDBRestore"
        Appearance13.BackColor = System.Drawing.Color.OrangeRed
        Appearance13.BackColor2 = System.Drawing.Color.Tomato
        Appearance13.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdDBRestore.PressedAppearance = Appearance13
        Me.cmdDBRestore.ShowFocusRect = False
        Me.cmdDBRestore.ShowOutline = False
        Me.cmdDBRestore.Size = New System.Drawing.Size(70, 60)
        Me.cmdDBRestore.StyleSetName = "StatusBar"
        Me.cmdDBRestore.TabIndex = 508
        Me.cmdDBRestore.Tag = ""
        Me.cmdDBRestore.Text = "Restore"
        Me.cmdDBRestore.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDBRestore.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDBRestore.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblQueryLabel
        '
        Me.lblQueryLabel.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance14.BackColor = System.Drawing.Color.Transparent
        Appearance14.ForeColor = System.Drawing.Color.DimGray
        Appearance14.TextHAlignAsString = "Left"
        Me.lblQueryLabel.Appearance = Appearance14
        Me.lblQueryLabel.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblQueryLabel.Location = New System.Drawing.Point(12, 21)
        Me.lblQueryLabel.Name = "lblQueryLabel"
        Me.lblQueryLabel.Size = New System.Drawing.Size(686, 73)
        Me.lblQueryLabel.StyleSetName = "TextEntryLabel"
        Me.lblQueryLabel.TabIndex = 662
        Me.lblQueryLabel.Text = "Enter SQL Query here:"
        Me.lblQueryLabel.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblStatus
        '
        Me.lblStatus.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance15.BackColor = System.Drawing.Color.Transparent
        Appearance15.ForeColor = System.Drawing.Color.DimGray
        Appearance15.TextHAlignAsString = "Left"
        Me.lblStatus.Appearance = Appearance15
        Me.lblStatus.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStatus.Location = New System.Drawing.Point(12, 300)
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(686, 27)
        Me.lblStatus.StyleSetName = "TextEntryLabel"
        Me.lblStatus.TabIndex = 663
        Me.lblStatus.Text = "Please wait . . ."
        Me.lblStatus.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        Me.lblStatus.Visible = False
        '
        'frmSQLQuery
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(710, 396)
        Me.ControlBox = False
        Me.Controls.Add(Me.lblStatus)
        Me.Controls.Add(Me.lblQueryLabel)
        Me.Controls.Add(Me.cmdDBRestore)
        Me.Controls.Add(Me.cmdDBBackup)
        Me.Controls.Add(Me.txtQuery)
        Me.Controls.Add(Me.cmdOK)
        Me.Controls.Add(Me.cmdCancel)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmSQLQuery"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        CType(Me.txtQuery, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents cmdOK As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdCancel As Infragistics.Win.Misc.UltraButton
    Friend WithEvents txtQuery As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents cmdDBBackup As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDBRestore As Infragistics.Win.Misc.UltraButton
    Friend WithEvents lblQueryLabel As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblStatus As Infragistics.Win.Misc.UltraLabel
End Class
