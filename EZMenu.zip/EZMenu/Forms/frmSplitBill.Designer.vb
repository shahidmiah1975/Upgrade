﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSplitBill
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim Appearance7 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance21 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance22 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance23 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance24 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance9 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmSplitBill))
        Dim Appearance10 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance11 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance191 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance192 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance19 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance20 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance1 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance2 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance3 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance4 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance12 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance13 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance225 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance226 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance227 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance8 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance14 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance15 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance5 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance6 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance28 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance109 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance113 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance114 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance29 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance44 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance45 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance103 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance104 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance105 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance16 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance17 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance18 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Me.UltraPanel1 = New Infragistics.Win.Misc.UltraPanel()
        Me.UltraGroupBox1 = New Infragistics.Win.Misc.UltraGroupBox()
        Me.cmdTipAmount = New Infragistics.Win.Misc.UltraButton()
        Me.lblTipsBreakdown = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cmdBack = New Infragistics.Win.Misc.UltraButton()
        Me.lblTipTotals = New System.Windows.Forms.Label()
        Me.lblTipInfo = New System.Windows.Forms.Label()
        Me.cmdUseTotal = New Infragistics.Win.Misc.UltraButton()
        Me.cmdReset = New Infragistics.Win.Misc.UltraButton()
        Me.lblTotalLabel = New System.Windows.Forms.Label()
        Me.lblPaymentLabel = New System.Windows.Forms.Label()
        Me.cmdTips = New Infragistics.Win.Misc.UltraButton()
        Me.cmdBill = New Infragistics.Win.Misc.UltraButton()
        Me.cmdSplitOther = New Infragistics.Win.Misc.UltraButton()
        Me.cmdSplitOther2 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdSplitCard = New Infragistics.Win.Misc.UltraButton()
        Me.cmdSplitCash = New Infragistics.Win.Misc.UltraButton()
        Me.cmdSplitCard2 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdSplitCash2 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdSplits = New Infragistics.Win.Misc.UltraButton()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.UltraPanel1.ClientArea.SuspendLayout()
        Me.UltraPanel1.SuspendLayout()
        CType(Me.UltraGroupBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.UltraGroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'UltraPanel1
        '
        Appearance7.BackColor = System.Drawing.Color.Indigo
        Me.UltraPanel1.Appearance = Appearance7
        Me.UltraPanel1.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded4Thick
        '
        'UltraPanel1.ClientArea
        '
        Me.UltraPanel1.ClientArea.Controls.Add(Me.UltraGroupBox1)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.cmdUseTotal)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.cmdReset)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.lblTotalLabel)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.lblPaymentLabel)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.cmdTips)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.cmdBill)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.cmdSplitOther)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.cmdSplitOther2)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.cmdSplitCard)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.cmdSplitCash)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.cmdSplitCard2)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.cmdSplitCash2)
        Me.UltraPanel1.ForeColor = System.Drawing.Color.Yellow
        Me.UltraPanel1.Location = New System.Drawing.Point(1, 1)
        Me.UltraPanel1.Name = "UltraPanel1"
        Me.UltraPanel1.Size = New System.Drawing.Size(680, 520)
        Me.UltraPanel1.TabIndex = 471
        '
        'UltraGroupBox1
        '
        Appearance21.BackColor = System.Drawing.Color.FromArgb(CType(CType(87, Byte), Integer), CType(CType(30, Byte), Integer), CType(CType(129, Byte), Integer))
        Appearance21.BorderAlpha = Infragistics.Win.Alpha.Transparent
        Me.UltraGroupBox1.Appearance = Appearance21
        Me.UltraGroupBox1.Controls.Add(Me.cmdSplits)
        Me.UltraGroupBox1.Controls.Add(Me.Label2)
        Me.UltraGroupBox1.Controls.Add(Me.cmdTipAmount)
        Me.UltraGroupBox1.Controls.Add(Me.lblTipsBreakdown)
        Me.UltraGroupBox1.Controls.Add(Me.Label1)
        Me.UltraGroupBox1.Controls.Add(Me.cmdBack)
        Me.UltraGroupBox1.Controls.Add(Me.lblTipTotals)
        Me.UltraGroupBox1.Controls.Add(Me.lblTipInfo)
        Me.UltraGroupBox1.Location = New System.Drawing.Point(5, 292)
        Me.UltraGroupBox1.Name = "UltraGroupBox1"
        Me.UltraGroupBox1.Size = New System.Drawing.Size(665, 217)
        Me.UltraGroupBox1.TabIndex = 555
        '
        'cmdTipAmount
        '
        Appearance22.BackColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance22.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance22.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance22.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance22.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance22.BorderColor2 = System.Drawing.Color.Maroon
        Appearance22.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance22.ForeColor = System.Drawing.Color.White
        Appearance22.TextVAlignAsString = "Middle"
        Me.cmdTipAmount.Appearance = Appearance22
        Me.cmdTipAmount.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance23.BackColor = System.Drawing.Color.DarkOrange
        Appearance23.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance23.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance23.ForeColor = System.Drawing.Color.Black
        Me.cmdTipAmount.HotTrackAppearance = Appearance23
        Me.cmdTipAmount.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdTipAmount.Location = New System.Drawing.Point(162, 34)
        Me.cmdTipAmount.Name = "cmdTipAmount"
        Appearance24.BackColor = System.Drawing.Color.OrangeRed
        Appearance24.BackColor2 = System.Drawing.Color.Tomato
        Appearance24.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdTipAmount.PressedAppearance = Appearance24
        Me.cmdTipAmount.ShowFocusRect = False
        Me.cmdTipAmount.ShowOutline = False
        Me.cmdTipAmount.Size = New System.Drawing.Size(118, 45)
        Me.cmdTipAmount.TabIndex = 547
        Me.cmdTipAmount.Tag = "0"
        Me.cmdTipAmount.Text = "0"
        Me.cmdTipAmount.UseAppStyling = False
        Me.cmdTipAmount.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTipAmount.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTipAmount.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblTipsBreakdown
        '
        Me.lblTipsBreakdown.BackColor = System.Drawing.Color.Transparent
        Me.lblTipsBreakdown.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTipsBreakdown.ForeColor = System.Drawing.Color.Yellow
        Me.lblTipsBreakdown.Location = New System.Drawing.Point(283, 96)
        Me.lblTipsBreakdown.Name = "lblTipsBreakdown"
        Me.lblTipsBreakdown.Size = New System.Drawing.Size(247, 111)
        Me.lblTipsBreakdown.TabIndex = 554
        Me.lblTipsBreakdown.Text = "0.00"
        Me.lblTipsBreakdown.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(105, 46)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(51, 18)
        Me.Label1.TabIndex = 548
        Me.Label1.Text = "Tip %:"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cmdBack
        '
        Appearance9.BackColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance9.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance9.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance9.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance9.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance9.BorderColor2 = System.Drawing.Color.Maroon
        Appearance9.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance9.ForeColor = System.Drawing.Color.Black
        Appearance9.Image = CType(resources.GetObject("Appearance9.Image"), Object)
        Appearance9.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance9.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance9.TextVAlignAsString = "Bottom"
        Me.cmdBack.Appearance = Appearance9
        Me.cmdBack.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance10.BackColor = System.Drawing.Color.DarkOrange
        Appearance10.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance10.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance10.ForeColor = System.Drawing.Color.Black
        Me.cmdBack.HotTrackAppearance = Appearance10
        Me.cmdBack.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdBack.Location = New System.Drawing.Point(594, 171)
        Me.cmdBack.Name = "cmdBack"
        Appearance11.BackColor = System.Drawing.Color.OrangeRed
        Appearance11.BackColor2 = System.Drawing.Color.Tomato
        Appearance11.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdBack.PressedAppearance = Appearance11
        Me.cmdBack.ShowFocusRect = False
        Me.cmdBack.ShowOutline = False
        Me.cmdBack.Size = New System.Drawing.Size(65, 40)
        Me.cmdBack.TabIndex = 479
        Me.cmdBack.Tag = "Back"
        Me.cmdBack.UseAppStyling = False
        Me.cmdBack.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdBack.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdBack.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblTipTotals
        '
        Me.lblTipTotals.BackColor = System.Drawing.Color.Transparent
        Me.lblTipTotals.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTipTotals.ForeColor = System.Drawing.Color.Yellow
        Me.lblTipTotals.Location = New System.Drawing.Point(162, 96)
        Me.lblTipTotals.Name = "lblTipTotals"
        Me.lblTipTotals.Size = New System.Drawing.Size(84, 93)
        Me.lblTipTotals.TabIndex = 550
        Me.lblTipTotals.Text = "0.00"
        Me.lblTipTotals.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblTipInfo
        '
        Me.lblTipInfo.BackColor = System.Drawing.Color.Transparent
        Me.lblTipInfo.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTipInfo.ForeColor = System.Drawing.Color.White
        Me.lblTipInfo.Location = New System.Drawing.Point(6, 96)
        Me.lblTipInfo.Name = "lblTipInfo"
        Me.lblTipInfo.Size = New System.Drawing.Size(150, 93)
        Me.lblTipInfo.TabIndex = 549
        Me.lblTipInfo.Text = "Total:"
        Me.lblTipInfo.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'cmdUseTotal
        '
        Appearance191.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(120, Byte), Integer), CType(CType(69, Byte), Integer))
        Appearance191.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(70, Byte), Integer))
        Appearance191.BackGradientStyle = Infragistics.Win.GradientStyle.VerticalBump
        Appearance191.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(180, Byte), Integer), CType(CType(70, Byte), Integer))
        Appearance191.BorderColor2 = System.Drawing.Color.Maroon
        Appearance191.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance191.ForeColor = System.Drawing.Color.White
        Me.cmdUseTotal.Appearance = Appearance191
        Me.cmdUseTotal.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance192.BackColor = System.Drawing.Color.PowderBlue
        Appearance192.BackColor2 = System.Drawing.Color.Aqua
        Appearance192.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance192.ForeColor = System.Drawing.Color.Black
        Me.cmdUseTotal.HotTrackAppearance = Appearance192
        Me.cmdUseTotal.Location = New System.Drawing.Point(483, 16)
        Me.cmdUseTotal.Name = "cmdUseTotal"
        Me.cmdUseTotal.ShowFocusRect = False
        Me.cmdUseTotal.ShowOutline = False
        Me.cmdUseTotal.Size = New System.Drawing.Size(166, 45)
        Me.cmdUseTotal.TabIndex = 553
        Me.cmdUseTotal.Text = "Use £0.00"
        Me.cmdUseTotal.UseAppStyling = False
        Me.cmdUseTotal.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdUseTotal.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdUseTotal.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdReset
        '
        Appearance19.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(120, Byte), Integer), CType(CType(69, Byte), Integer))
        Appearance19.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(70, Byte), Integer))
        Appearance19.BackGradientStyle = Infragistics.Win.GradientStyle.VerticalBump
        Appearance19.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(180, Byte), Integer), CType(CType(70, Byte), Integer))
        Appearance19.BorderColor2 = System.Drawing.Color.Maroon
        Appearance19.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance19.ForeColor = System.Drawing.Color.White
        Me.cmdReset.Appearance = Appearance19
        Me.cmdReset.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance20.BackColor = System.Drawing.Color.PowderBlue
        Appearance20.BackColor2 = System.Drawing.Color.Aqua
        Appearance20.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance20.ForeColor = System.Drawing.Color.Black
        Me.cmdReset.HotTrackAppearance = Appearance20
        Me.cmdReset.Location = New System.Drawing.Point(483, 112)
        Me.cmdReset.Name = "cmdReset"
        Me.cmdReset.ShowFocusRect = False
        Me.cmdReset.ShowOutline = False
        Me.cmdReset.Size = New System.Drawing.Size(166, 45)
        Me.cmdReset.TabIndex = 552
        Me.cmdReset.Text = "Reset"
        Me.cmdReset.UseAppStyling = False
        Me.cmdReset.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdReset.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdReset.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblTotalLabel
        '
        Me.lblTotalLabel.BackColor = System.Drawing.Color.Transparent
        Me.lblTotalLabel.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotalLabel.ForeColor = System.Drawing.Color.Yellow
        Me.lblTotalLabel.Location = New System.Drawing.Point(269, 16)
        Me.lblTotalLabel.Name = "lblTotalLabel"
        Me.lblTotalLabel.Size = New System.Drawing.Size(84, 93)
        Me.lblTotalLabel.TabIndex = 546
        Me.lblTotalLabel.Text = "0.00"
        Me.lblTotalLabel.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblPaymentLabel
        '
        Me.lblPaymentLabel.BackColor = System.Drawing.Color.Transparent
        Me.lblPaymentLabel.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPaymentLabel.ForeColor = System.Drawing.Color.White
        Me.lblPaymentLabel.Location = New System.Drawing.Point(113, 16)
        Me.lblPaymentLabel.Name = "lblPaymentLabel"
        Me.lblPaymentLabel.Size = New System.Drawing.Size(150, 93)
        Me.lblPaymentLabel.TabIndex = 545
        Me.lblPaymentLabel.Text = "Total:"
        Me.lblPaymentLabel.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'cmdTips
        '
        Appearance1.BackColor = System.Drawing.Color.Maroon
        Appearance1.BackColor2 = System.Drawing.Color.Firebrick
        Appearance1.BackGradientStyle = Infragistics.Win.GradientStyle.VerticalBump
        Appearance1.BorderAlpha = Infragistics.Win.Alpha.Opaque
        Appearance1.BorderColor = System.Drawing.Color.Gold
        Appearance1.BorderColor2 = System.Drawing.Color.Yellow
        Appearance1.ForeColor = System.Drawing.Color.White
        Me.cmdTips.Appearance = Appearance1
        Me.cmdTips.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance2.BackColor = System.Drawing.Color.PowderBlue
        Appearance2.BackColor2 = System.Drawing.Color.Aqua
        Appearance2.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance2.ForeColor = System.Drawing.Color.Black
        Me.cmdTips.HotTrackAppearance = Appearance2
        Me.cmdTips.Location = New System.Drawing.Point(23, 189)
        Me.cmdTips.Name = "cmdTips"
        Appearance3.BackColor = System.Drawing.Color.Orange
        Appearance3.BackColor2 = System.Drawing.Color.DarkOrange
        Appearance3.ForeColor = System.Drawing.Color.Maroon
        Me.cmdTips.PressedAppearance = Appearance3
        Me.cmdTips.ShowFocusRect = False
        Me.cmdTips.ShowOutline = False
        Me.cmdTips.Size = New System.Drawing.Size(148, 70)
        Me.cmdTips.TabIndex = 544
        Me.cmdTips.Tag = "0"
        Me.cmdTips.Text = "Tips"
        Me.cmdTips.UseAppStyling = False
        Me.cmdTips.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTips.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdTips.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdBill
        '
        Appearance4.BackColor = System.Drawing.Color.Yellow
        Appearance4.BackColor2 = System.Drawing.Color.Orange
        Appearance4.BackGradientStyle = Infragistics.Win.GradientStyle.VerticalBump
        Appearance4.BorderAlpha = Infragistics.Win.Alpha.Opaque
        Appearance4.BorderColor = System.Drawing.Color.Gold
        Appearance4.BorderColor2 = System.Drawing.Color.Yellow
        Appearance4.ForeColor = System.Drawing.Color.Maroon
        Me.cmdBill.Appearance = Appearance4
        Me.cmdBill.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance12.BackColor = System.Drawing.Color.PowderBlue
        Appearance12.BackColor2 = System.Drawing.Color.Aqua
        Appearance12.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance12.ForeColor = System.Drawing.Color.Black
        Me.cmdBill.HotTrackAppearance = Appearance12
        Me.cmdBill.Location = New System.Drawing.Point(23, 112)
        Me.cmdBill.Name = "cmdBill"
        Appearance13.BackColor = System.Drawing.Color.Orange
        Appearance13.BackColor2 = System.Drawing.Color.DarkOrange
        Appearance13.ForeColor = System.Drawing.Color.Maroon
        Me.cmdBill.PressedAppearance = Appearance13
        Me.cmdBill.ShowFocusRect = False
        Me.cmdBill.ShowOutline = False
        Me.cmdBill.Size = New System.Drawing.Size(148, 70)
        Me.cmdBill.TabIndex = 543
        Me.cmdBill.Tag = "1"
        Me.cmdBill.Text = "Bill"
        Me.cmdBill.UseAppStyling = False
        Me.cmdBill.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdBill.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdBill.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdSplitOther
        '
        Appearance225.BackColor = System.Drawing.Color.DarkGoldenrod
        Appearance225.BackColor2 = System.Drawing.Color.DarkOliveGreen
        Appearance225.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance225.BorderColor = System.Drawing.Color.Khaki
        Appearance225.BorderColor2 = System.Drawing.Color.Maroon
        Appearance225.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance225.ForeColor = System.Drawing.Color.White
        Appearance225.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance225.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance225.TextVAlignAsString = "Middle"
        Me.cmdSplitOther.Appearance = Appearance225
        Me.cmdSplitOther.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance226.BackColor = System.Drawing.Color.DarkOrange
        Appearance226.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance226.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance226.ForeColor = System.Drawing.Color.Black
        Me.cmdSplitOther.HotTrackAppearance = Appearance226
        Me.cmdSplitOther.ImageSize = New System.Drawing.Size(40, 40)
        Me.cmdSplitOther.Location = New System.Drawing.Point(301, 214)
        Me.cmdSplitOther.Name = "cmdSplitOther"
        Appearance227.BackColor = System.Drawing.Color.OrangeRed
        Appearance227.BackColor2 = System.Drawing.Color.Tomato
        Appearance227.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdSplitOther.PressedAppearance = Appearance227
        Me.cmdSplitOther.ShowFocusRect = False
        Me.cmdSplitOther.ShowOutline = False
        Me.cmdSplitOther.Size = New System.Drawing.Size(142, 45)
        Me.cmdSplitOther.TabIndex = 542
        Me.cmdSplitOther.Tag = "0"
        Me.cmdSplitOther.Text = "0.00"
        Me.cmdSplitOther.UseAppStyling = False
        Me.cmdSplitOther.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdSplitOther.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdSplitOther.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdSplitOther2
        '
        Appearance8.BackColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance8.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance8.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance8.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance8.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance8.BorderColor2 = System.Drawing.Color.Maroon
        Appearance8.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance8.ForeColor = System.Drawing.Color.White
        Appearance8.TextVAlignAsString = "Middle"
        Me.cmdSplitOther2.Appearance = Appearance8
        Me.cmdSplitOther2.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance14.BackColor = System.Drawing.Color.DarkOrange
        Appearance14.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance14.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance14.ForeColor = System.Drawing.Color.Black
        Me.cmdSplitOther2.HotTrackAppearance = Appearance14
        Me.cmdSplitOther2.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdSplitOther2.Location = New System.Drawing.Point(177, 214)
        Me.cmdSplitOther2.Name = "cmdSplitOther2"
        Appearance15.BackColor = System.Drawing.Color.OrangeRed
        Appearance15.BackColor2 = System.Drawing.Color.Tomato
        Appearance15.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdSplitOther2.PressedAppearance = Appearance15
        Me.cmdSplitOther2.ShowFocusRect = False
        Me.cmdSplitOther2.ShowOutline = False
        Me.cmdSplitOther2.Size = New System.Drawing.Size(118, 45)
        Me.cmdSplitOther2.TabIndex = 541
        Me.cmdSplitOther2.Tag = "0"
        Me.cmdSplitOther2.Text = "Other"
        Me.cmdSplitOther2.UseAppStyling = False
        Me.cmdSplitOther2.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdSplitOther2.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdSplitOther2.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdSplitCard
        '
        Appearance5.BackColor = System.Drawing.Color.DarkGoldenrod
        Appearance5.BackColor2 = System.Drawing.Color.DarkOliveGreen
        Appearance5.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance5.BorderColor = System.Drawing.Color.Khaki
        Appearance5.BorderColor2 = System.Drawing.Color.Maroon
        Appearance5.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance5.ForeColor = System.Drawing.Color.White
        Appearance5.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance5.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance5.TextVAlignAsString = "Middle"
        Me.cmdSplitCard.Appearance = Appearance5
        Me.cmdSplitCard.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance6.BackColor = System.Drawing.Color.DarkOrange
        Appearance6.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance6.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance6.ForeColor = System.Drawing.Color.Black
        Me.cmdSplitCard.HotTrackAppearance = Appearance6
        Me.cmdSplitCard.ImageSize = New System.Drawing.Size(40, 40)
        Me.cmdSplitCard.Location = New System.Drawing.Point(301, 163)
        Me.cmdSplitCard.Name = "cmdSplitCard"
        Appearance28.BackColor = System.Drawing.Color.OrangeRed
        Appearance28.BackColor2 = System.Drawing.Color.Tomato
        Appearance28.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdSplitCard.PressedAppearance = Appearance28
        Me.cmdSplitCard.ShowFocusRect = False
        Me.cmdSplitCard.ShowOutline = False
        Me.cmdSplitCard.Size = New System.Drawing.Size(142, 45)
        Me.cmdSplitCard.TabIndex = 540
        Me.cmdSplitCard.Tag = "0"
        Me.cmdSplitCard.Text = "0.00"
        Me.cmdSplitCard.UseAppStyling = False
        Me.cmdSplitCard.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdSplitCard.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdSplitCard.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdSplitCash
        '
        Appearance109.BackColor = System.Drawing.Color.DarkGoldenrod
        Appearance109.BackColor2 = System.Drawing.Color.DarkOliveGreen
        Appearance109.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance109.BorderColor = System.Drawing.Color.Khaki
        Appearance109.BorderColor2 = System.Drawing.Color.Maroon
        Appearance109.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance109.ForeColor = System.Drawing.Color.White
        Appearance109.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance109.ImageVAlign = Infragistics.Win.VAlign.Top
        Appearance109.TextVAlignAsString = "Middle"
        Me.cmdSplitCash.Appearance = Appearance109
        Me.cmdSplitCash.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance113.BackColor = System.Drawing.Color.DarkOrange
        Appearance113.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance113.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance113.ForeColor = System.Drawing.Color.Black
        Me.cmdSplitCash.HotTrackAppearance = Appearance113
        Me.cmdSplitCash.ImageSize = New System.Drawing.Size(40, 40)
        Me.cmdSplitCash.Location = New System.Drawing.Point(301, 112)
        Me.cmdSplitCash.Name = "cmdSplitCash"
        Appearance114.BackColor = System.Drawing.Color.OrangeRed
        Appearance114.BackColor2 = System.Drawing.Color.Tomato
        Appearance114.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdSplitCash.PressedAppearance = Appearance114
        Me.cmdSplitCash.ShowFocusRect = False
        Me.cmdSplitCash.ShowOutline = False
        Me.cmdSplitCash.Size = New System.Drawing.Size(142, 45)
        Me.cmdSplitCash.TabIndex = 539
        Me.cmdSplitCash.Tag = "0"
        Me.cmdSplitCash.Text = "0.00"
        Me.cmdSplitCash.UseAppStyling = False
        Me.cmdSplitCash.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdSplitCash.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdSplitCash.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdSplitCard2
        '
        Appearance29.BackColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance29.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance29.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance29.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance29.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance29.BorderColor2 = System.Drawing.Color.Maroon
        Appearance29.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance29.ForeColor = System.Drawing.Color.White
        Appearance29.TextVAlignAsString = "Middle"
        Me.cmdSplitCard2.Appearance = Appearance29
        Me.cmdSplitCard2.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance44.BackColor = System.Drawing.Color.DarkOrange
        Appearance44.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance44.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance44.ForeColor = System.Drawing.Color.Black
        Me.cmdSplitCard2.HotTrackAppearance = Appearance44
        Me.cmdSplitCard2.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdSplitCard2.Location = New System.Drawing.Point(177, 163)
        Me.cmdSplitCard2.Name = "cmdSplitCard2"
        Appearance45.BackColor = System.Drawing.Color.OrangeRed
        Appearance45.BackColor2 = System.Drawing.Color.Tomato
        Appearance45.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdSplitCard2.PressedAppearance = Appearance45
        Me.cmdSplitCard2.ShowFocusRect = False
        Me.cmdSplitCard2.ShowOutline = False
        Me.cmdSplitCard2.Size = New System.Drawing.Size(118, 45)
        Me.cmdSplitCard2.TabIndex = 538
        Me.cmdSplitCard2.Tag = "0"
        Me.cmdSplitCard2.Text = "Card"
        Me.cmdSplitCard2.UseAppStyling = False
        Me.cmdSplitCard2.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdSplitCard2.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdSplitCard2.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdSplitCash2
        '
        Appearance103.BackColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance103.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance103.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance103.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance103.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance103.BorderColor2 = System.Drawing.Color.Maroon
        Appearance103.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance103.ForeColor = System.Drawing.Color.White
        Appearance103.TextVAlignAsString = "Middle"
        Me.cmdSplitCash2.Appearance = Appearance103
        Me.cmdSplitCash2.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance104.BackColor = System.Drawing.Color.DarkOrange
        Appearance104.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance104.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance104.ForeColor = System.Drawing.Color.Black
        Me.cmdSplitCash2.HotTrackAppearance = Appearance104
        Me.cmdSplitCash2.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdSplitCash2.Location = New System.Drawing.Point(177, 112)
        Me.cmdSplitCash2.Name = "cmdSplitCash2"
        Appearance105.BackColor = System.Drawing.Color.OrangeRed
        Appearance105.BackColor2 = System.Drawing.Color.Tomato
        Appearance105.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdSplitCash2.PressedAppearance = Appearance105
        Me.cmdSplitCash2.ShowFocusRect = False
        Me.cmdSplitCash2.ShowOutline = False
        Me.cmdSplitCash2.Size = New System.Drawing.Size(118, 45)
        Me.cmdSplitCash2.TabIndex = 537
        Me.cmdSplitCash2.Tag = "0"
        Me.cmdSplitCash2.Text = "Cash"
        Me.cmdSplitCash2.UseAppStyling = False
        Me.cmdSplitCash2.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdSplitCash2.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdSplitCash2.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdSplits
        '
        Appearance16.BackColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance16.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance16.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance16.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance16.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance16.BorderColor2 = System.Drawing.Color.Maroon
        Appearance16.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance16.ForeColor = System.Drawing.Color.White
        Appearance16.TextVAlignAsString = "Middle"
        Me.cmdSplits.Appearance = Appearance16
        Me.cmdSplits.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance17.BackColor = System.Drawing.Color.DarkOrange
        Appearance17.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance17.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance17.ForeColor = System.Drawing.Color.Black
        Me.cmdSplits.HotTrackAppearance = Appearance17
        Me.cmdSplits.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdSplits.Location = New System.Drawing.Point(382, 34)
        Me.cmdSplits.Name = "cmdSplits"
        Appearance18.BackColor = System.Drawing.Color.OrangeRed
        Appearance18.BackColor2 = System.Drawing.Color.Tomato
        Appearance18.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdSplits.PressedAppearance = Appearance18
        Me.cmdSplits.ShowFocusRect = False
        Me.cmdSplits.ShowOutline = False
        Me.cmdSplits.Size = New System.Drawing.Size(118, 45)
        Me.cmdSplits.TabIndex = 555
        Me.cmdSplits.Tag = "0"
        Me.cmdSplits.Text = "1"
        Me.cmdSplits.UseAppStyling = False
        Me.cmdSplits.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdSplits.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdSplits.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(325, 46)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(51, 18)
        Me.Label2.TabIndex = 556
        Me.Label2.Text = "Splits:"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'frmSplitBill
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Indigo
        Me.ClientSize = New System.Drawing.Size(682, 522)
        Me.ControlBox = False
        Me.Controls.Add(Me.UltraPanel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmSplitBill"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Number Input"
        Me.UltraPanel1.ClientArea.ResumeLayout(False)
        Me.UltraPanel1.ResumeLayout(False)
        CType(Me.UltraGroupBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.UltraGroupBox1.ResumeLayout(False)
        Me.UltraGroupBox1.PerformLayout()
        Me.ResumeLayout(False)

End Sub
    Friend WithEvents UltraPanel1 As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents cmdSplitOther As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdSplitOther2 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdSplitCard As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdSplitCash As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdSplitCard2 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdSplitCash2 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdTips As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdBill As Infragistics.Win.Misc.UltraButton
    Friend WithEvents lblTotalLabel As System.Windows.Forms.Label
    Friend WithEvents lblPaymentLabel As System.Windows.Forms.Label
    Friend WithEvents cmdBack As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdTipAmount As Infragistics.Win.Misc.UltraButton
    Friend WithEvents lblTipTotals As System.Windows.Forms.Label
    Friend WithEvents lblTipInfo As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cmdUseTotal As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdReset As Infragistics.Win.Misc.UltraButton
    Friend WithEvents lblTipsBreakdown As System.Windows.Forms.Label
    Private WithEvents UltraGroupBox1 As Infragistics.Win.Misc.UltraGroupBox
    Friend WithEvents cmdSplits As Infragistics.Win.Misc.UltraButton
    Friend WithEvents Label2 As System.Windows.Forms.Label
End Class
