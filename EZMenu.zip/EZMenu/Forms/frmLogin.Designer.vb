﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmLogin
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim Appearance49 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance50 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance51 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance52 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance53 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance54 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance55 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance56 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance57 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance58 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance59 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance60 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance61 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance62 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance63 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance64 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance65 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance66 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance67 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance68 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance69 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance70 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance71 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance72 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance73 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance74 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance75 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance76 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance77 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance78 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance79 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance80 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance81 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance82 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance83 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance84 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance85 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance86 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance87 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance88 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance89 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance90 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance91 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance92 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance93 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance94 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance95 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance96 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Me.lblOutput = New Infragistics.Win.Misc.UltraLabel()
        Me.lblHeader = New Infragistics.Win.Misc.UltraLabel()
        Me.lblWelcome = New Infragistics.Win.Misc.UltraLabel()
        Me.gbxBorder = New System.Windows.Forms.GroupBox()
        Me.btnClear = New Infragistics.Win.Misc.UltraButton()
        Me.btnLogin = New Infragistics.Win.Misc.UltraButton()
        Me.btnClose = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton3 = New Infragistics.Win.Misc.UltraButton()
        Me.UltraButton2 = New Infragistics.Win.Misc.UltraButton()
        Me.btn0 = New Infragistics.Win.Misc.UltraButton()
        Me.btn9 = New Infragistics.Win.Misc.UltraButton()
        Me.btn8 = New Infragistics.Win.Misc.UltraButton()
        Me.btn7 = New Infragistics.Win.Misc.UltraButton()
        Me.btn6 = New Infragistics.Win.Misc.UltraButton()
        Me.btn5 = New Infragistics.Win.Misc.UltraButton()
        Me.btn4 = New Infragistics.Win.Misc.UltraButton()
        Me.btn3 = New Infragistics.Win.Misc.UltraButton()
        Me.btn2 = New Infragistics.Win.Misc.UltraButton()
        Me.btn1 = New Infragistics.Win.Misc.UltraButton()
        Me.gbxBorder.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblOutput
        '
        Me.lblOutput.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance49.BackColor = System.Drawing.Color.Transparent
        Appearance49.ForeColor = System.Drawing.Color.FromArgb(CType(CType(90, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(50, Byte), Integer))
        Appearance49.TextHAlignAsString = "Center"
        Me.lblOutput.Appearance = Appearance49
        Me.lblOutput.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOutput.Location = New System.Drawing.Point(6, 44)
        Me.lblOutput.Name = "lblOutput"
        Me.lblOutput.Size = New System.Drawing.Size(249, 23)
        Me.lblOutput.TabIndex = 542
        Me.lblOutput.UseAppStyling = False
        '
        'lblHeader
        '
        Me.lblHeader.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance50.BackColor = System.Drawing.Color.Transparent
        Appearance50.ForeColor = System.Drawing.Color.FromArgb(CType(CType(90, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(50, Byte), Integer))
        Appearance50.TextHAlignAsString = "Center"
        Me.lblHeader.Appearance = Appearance50
        Me.lblHeader.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHeader.Location = New System.Drawing.Point(6, 19)
        Me.lblHeader.Name = "lblHeader"
        Me.lblHeader.Size = New System.Drawing.Size(249, 23)
        Me.lblHeader.TabIndex = 543
        Me.lblHeader.Text = "<super / user id>"
        Me.lblHeader.UseAppStyling = False
        '
        'lblWelcome
        '
        Me.lblWelcome.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance51.BackColor = System.Drawing.Color.Transparent
        Appearance51.ForeColor = System.Drawing.Color.FromArgb(CType(CType(90, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(50, Byte), Integer))
        Appearance51.TextHAlignAsString = "Center"
        Appearance51.TextVAlignAsString = "Middle"
        Me.lblWelcome.Appearance = Appearance51
        Me.lblWelcome.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWelcome.Location = New System.Drawing.Point(6, 69)
        Me.lblWelcome.Name = "lblWelcome"
        Me.lblWelcome.Size = New System.Drawing.Size(249, 38)
        Me.lblWelcome.TabIndex = 544
        Me.lblWelcome.UseAppStyling = False
        '
        'gbxBorder
        '
        Me.gbxBorder.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gbxBorder.BackColor = System.Drawing.Color.FromArgb(CType(CType(200, Byte), Integer), CType(CType(180, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.gbxBorder.Controls.Add(Me.lblWelcome)
        Me.gbxBorder.Controls.Add(Me.btnClear)
        Me.gbxBorder.Controls.Add(Me.btnLogin)
        Me.gbxBorder.Controls.Add(Me.lblOutput)
        Me.gbxBorder.Controls.Add(Me.lblHeader)
        Me.gbxBorder.Controls.Add(Me.btnClose)
        Me.gbxBorder.Controls.Add(Me.UltraButton3)
        Me.gbxBorder.Controls.Add(Me.UltraButton2)
        Me.gbxBorder.Controls.Add(Me.btn0)
        Me.gbxBorder.Controls.Add(Me.btn9)
        Me.gbxBorder.Controls.Add(Me.btn8)
        Me.gbxBorder.Controls.Add(Me.btn7)
        Me.gbxBorder.Controls.Add(Me.btn6)
        Me.gbxBorder.Controls.Add(Me.btn5)
        Me.gbxBorder.Controls.Add(Me.btn4)
        Me.gbxBorder.Controls.Add(Me.btn3)
        Me.gbxBorder.Controls.Add(Me.btn2)
        Me.gbxBorder.Controls.Add(Me.btn1)
        Me.gbxBorder.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.gbxBorder.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.gbxBorder.Location = New System.Drawing.Point(12, 12)
        Me.gbxBorder.Name = "gbxBorder"
        Me.gbxBorder.Size = New System.Drawing.Size(261, 468)
        Me.gbxBorder.TabIndex = 545
        Me.gbxBorder.TabStop = False
        '
        'btnClear
        '
        Appearance52.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Appearance52.BackGradientStyle = Infragistics.Win.GradientStyle.None
        Appearance52.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance52.BorderColor = System.Drawing.Color.FromArgb(CType(CType(160, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance52.BorderColor2 = System.Drawing.Color.FromArgb(CType(CType(160, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance52.ForeColor = System.Drawing.Color.FromArgb(CType(CType(90, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(50, Byte), Integer))
        Appearance52.TextVAlignAsString = "Middle"
        Me.btnClear.Appearance = Appearance52
        Me.btnClear.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance53.BackColor = System.Drawing.Color.DarkOrange
        Appearance53.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance53.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance53.ForeColor = System.Drawing.Color.Black
        Me.btnClear.HotTrackAppearance = Appearance53
        Me.btnClear.ImageSize = New System.Drawing.Size(32, 32)
        Me.btnClear.Location = New System.Drawing.Point(34, 337)
        Me.btnClear.Name = "btnClear"
        Appearance54.BackColor = System.Drawing.Color.OrangeRed
        Appearance54.BackColor2 = System.Drawing.Color.Tomato
        Appearance54.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.btnClear.PressedAppearance = Appearance54
        Me.btnClear.ShowFocusRect = False
        Me.btnClear.ShowOutline = False
        Me.btnClear.Size = New System.Drawing.Size(93, 50)
        Me.btnClear.TabIndex = 15
        Me.btnClear.Tag = "Clear"
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseAppStyling = False
        Me.btnClear.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.btnClear.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.btnClear.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'btnLogin
        '
        Appearance55.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Appearance55.BackGradientStyle = Infragistics.Win.GradientStyle.None
        Appearance55.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance55.BorderColor = System.Drawing.Color.FromArgb(CType(CType(160, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance55.BorderColor2 = System.Drawing.Color.FromArgb(CType(CType(160, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance55.ForeColor = System.Drawing.Color.FromArgb(CType(CType(90, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(50, Byte), Integer))
        Appearance55.TextVAlignAsString = "Middle"
        Me.btnLogin.Appearance = Appearance55
        Me.btnLogin.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance56.BackColor = System.Drawing.Color.DarkOrange
        Appearance56.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance56.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance56.ForeColor = System.Drawing.Color.Black
        Me.btnLogin.HotTrackAppearance = Appearance56
        Me.btnLogin.ImageSize = New System.Drawing.Size(32, 32)
        Me.btnLogin.Location = New System.Drawing.Point(133, 337)
        Me.btnLogin.Name = "btnLogin"
        Appearance57.BackColor = System.Drawing.Color.OrangeRed
        Appearance57.BackColor2 = System.Drawing.Color.Tomato
        Appearance57.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.btnLogin.PressedAppearance = Appearance57
        Me.btnLogin.ShowFocusRect = False
        Me.btnLogin.ShowOutline = False
        Me.btnLogin.Size = New System.Drawing.Size(93, 50)
        Me.btnLogin.TabIndex = 14
        Me.btnLogin.Tag = "Login"
        Me.btnLogin.Text = "Login"
        Me.btnLogin.UseAppStyling = False
        Me.btnLogin.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.btnLogin.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.btnLogin.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'btnClose
        '
        Appearance58.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Appearance58.BackGradientStyle = Infragistics.Win.GradientStyle.None
        Appearance58.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance58.BorderColor = System.Drawing.Color.FromArgb(CType(CType(160, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance58.BorderColor2 = System.Drawing.Color.FromArgb(CType(CType(160, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance58.ForeColor = System.Drawing.Color.FromArgb(CType(CType(90, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(50, Byte), Integer))
        Appearance58.TextVAlignAsString = "Middle"
        Me.btnClose.Appearance = Appearance58
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance59.BackColor = System.Drawing.Color.DarkOrange
        Appearance59.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance59.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance59.ForeColor = System.Drawing.Color.Black
        Me.btnClose.HotTrackAppearance = Appearance59
        Me.btnClose.ImageSize = New System.Drawing.Size(32, 32)
        Me.btnClose.Location = New System.Drawing.Point(34, 393)
        Me.btnClose.Name = "btnClose"
        Appearance60.BackColor = System.Drawing.Color.OrangeRed
        Appearance60.BackColor2 = System.Drawing.Color.Tomato
        Appearance60.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.btnClose.PressedAppearance = Appearance60
        Me.btnClose.ShowFocusRect = False
        Me.btnClose.ShowOutline = False
        Me.btnClose.Size = New System.Drawing.Size(192, 50)
        Me.btnClose.TabIndex = 13
        Me.btnClose.Tag = "Close"
        Me.btnClose.Text = "Close"
        Me.btnClose.UseAppStyling = False
        Me.btnClose.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.btnClose.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.btnClose.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton3
        '
        Appearance61.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Appearance61.BackGradientStyle = Infragistics.Win.GradientStyle.None
        Appearance61.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance61.BorderColor = System.Drawing.Color.FromArgb(CType(CType(160, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance61.BorderColor2 = System.Drawing.Color.FromArgb(CType(CType(160, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance61.ForeColor = System.Drawing.Color.FromArgb(CType(CType(90, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(50, Byte), Integer))
        Appearance61.TextVAlignAsString = "Middle"
        Me.UltraButton3.Appearance = Appearance61
        Me.UltraButton3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance62.BackColor = System.Drawing.Color.DarkOrange
        Appearance62.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance62.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance62.ForeColor = System.Drawing.Color.Black
        Me.UltraButton3.HotTrackAppearance = Appearance62
        Me.UltraButton3.ImageSize = New System.Drawing.Size(32, 32)
        Me.UltraButton3.Location = New System.Drawing.Point(166, 281)
        Me.UltraButton3.Name = "UltraButton3"
        Appearance63.BackColor = System.Drawing.Color.OrangeRed
        Appearance63.BackColor2 = System.Drawing.Color.Tomato
        Appearance63.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.UltraButton3.PressedAppearance = Appearance63
        Me.UltraButton3.ShowFocusRect = False
        Me.UltraButton3.ShowOutline = False
        Me.UltraButton3.Size = New System.Drawing.Size(60, 50)
        Me.UltraButton3.TabIndex = 12
        Me.UltraButton3.Tag = "7"
        Me.UltraButton3.UseAppStyling = False
        Me.UltraButton3.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton3.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton3.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraButton2
        '
        Appearance64.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Appearance64.BackGradientStyle = Infragistics.Win.GradientStyle.None
        Appearance64.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance64.BorderColor = System.Drawing.Color.FromArgb(CType(CType(160, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance64.BorderColor2 = System.Drawing.Color.FromArgb(CType(CType(160, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance64.ForeColor = System.Drawing.Color.FromArgb(CType(CType(90, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(50, Byte), Integer))
        Appearance64.TextVAlignAsString = "Middle"
        Me.UltraButton2.Appearance = Appearance64
        Me.UltraButton2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance65.BackColor = System.Drawing.Color.DarkOrange
        Appearance65.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance65.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance65.ForeColor = System.Drawing.Color.Black
        Me.UltraButton2.HotTrackAppearance = Appearance65
        Me.UltraButton2.ImageSize = New System.Drawing.Size(32, 32)
        Me.UltraButton2.Location = New System.Drawing.Point(34, 281)
        Me.UltraButton2.Name = "UltraButton2"
        Appearance66.BackColor = System.Drawing.Color.OrangeRed
        Appearance66.BackColor2 = System.Drawing.Color.Tomato
        Appearance66.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.UltraButton2.PressedAppearance = Appearance66
        Me.UltraButton2.ShowFocusRect = False
        Me.UltraButton2.ShowOutline = False
        Me.UltraButton2.Size = New System.Drawing.Size(60, 50)
        Me.UltraButton2.TabIndex = 11
        Me.UltraButton2.Tag = "7"
        Me.UltraButton2.UseAppStyling = False
        Me.UltraButton2.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton2.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.UltraButton2.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'btn0
        '
        Appearance67.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Appearance67.BackGradientStyle = Infragistics.Win.GradientStyle.None
        Appearance67.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance67.BorderColor = System.Drawing.Color.FromArgb(CType(CType(160, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance67.ForeColor = System.Drawing.Color.FromArgb(CType(CType(90, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(50, Byte), Integer))
        Appearance67.TextVAlignAsString = "Middle"
        Me.btn0.Appearance = Appearance67
        Me.btn0.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance68.BackColor = System.Drawing.Color.DarkOrange
        Appearance68.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance68.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance68.ForeColor = System.Drawing.Color.Black
        Me.btn0.HotTrackAppearance = Appearance68
        Me.btn0.ImageSize = New System.Drawing.Size(32, 32)
        Me.btn0.Location = New System.Drawing.Point(100, 281)
        Me.btn0.Name = "btn0"
        Appearance69.BackColor = System.Drawing.Color.OrangeRed
        Appearance69.BackColor2 = System.Drawing.Color.Tomato
        Appearance69.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.btn0.PressedAppearance = Appearance69
        Me.btn0.ShowFocusRect = False
        Me.btn0.ShowOutline = False
        Me.btn0.Size = New System.Drawing.Size(60, 50)
        Me.btn0.TabIndex = 10
        Me.btn0.Tag = "0"
        Me.btn0.Text = "0"
        Me.btn0.UseAppStyling = False
        Me.btn0.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.btn0.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.btn0.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'btn9
        '
        Appearance70.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Appearance70.BackGradientStyle = Infragistics.Win.GradientStyle.None
        Appearance70.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance70.BorderColor = System.Drawing.Color.FromArgb(CType(CType(160, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance70.ForeColor = System.Drawing.Color.FromArgb(CType(CType(90, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(50, Byte), Integer))
        Appearance70.TextVAlignAsString = "Middle"
        Me.btn9.Appearance = Appearance70
        Me.btn9.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance71.BackColor = System.Drawing.Color.DarkOrange
        Appearance71.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance71.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance71.ForeColor = System.Drawing.Color.Black
        Me.btn9.HotTrackAppearance = Appearance71
        Me.btn9.ImageSize = New System.Drawing.Size(32, 32)
        Me.btn9.Location = New System.Drawing.Point(166, 225)
        Me.btn9.Name = "btn9"
        Appearance72.BackColor = System.Drawing.Color.OrangeRed
        Appearance72.BackColor2 = System.Drawing.Color.Tomato
        Appearance72.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.btn9.PressedAppearance = Appearance72
        Me.btn9.ShowFocusRect = False
        Me.btn9.ShowOutline = False
        Me.btn9.Size = New System.Drawing.Size(60, 50)
        Me.btn9.TabIndex = 0
        Me.btn9.Tag = "9"
        Me.btn9.Text = "9"
        Me.btn9.UseAppStyling = False
        Me.btn9.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.btn9.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.btn9.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'btn8
        '
        Appearance73.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Appearance73.BackGradientStyle = Infragistics.Win.GradientStyle.None
        Appearance73.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance73.BorderColor = System.Drawing.Color.FromArgb(CType(CType(160, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance73.ForeColor = System.Drawing.Color.FromArgb(CType(CType(90, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(50, Byte), Integer))
        Appearance73.TextVAlignAsString = "Middle"
        Me.btn8.Appearance = Appearance73
        Me.btn8.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance74.BackColor = System.Drawing.Color.DarkOrange
        Appearance74.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance74.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance74.ForeColor = System.Drawing.Color.Black
        Me.btn8.HotTrackAppearance = Appearance74
        Me.btn8.ImageSize = New System.Drawing.Size(32, 32)
        Me.btn8.Location = New System.Drawing.Point(100, 225)
        Me.btn8.Name = "btn8"
        Appearance75.BackColor = System.Drawing.Color.OrangeRed
        Appearance75.BackColor2 = System.Drawing.Color.Tomato
        Appearance75.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.btn8.PressedAppearance = Appearance75
        Me.btn8.ShowFocusRect = False
        Me.btn8.ShowOutline = False
        Me.btn8.Size = New System.Drawing.Size(60, 50)
        Me.btn8.TabIndex = 1
        Me.btn8.Tag = "8"
        Me.btn8.Text = "8"
        Me.btn8.UseAppStyling = False
        Me.btn8.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.btn8.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.btn8.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'btn7
        '
        Appearance76.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Appearance76.BackGradientStyle = Infragistics.Win.GradientStyle.None
        Appearance76.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance76.BorderColor = System.Drawing.Color.FromArgb(CType(CType(160, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance76.BorderColor2 = System.Drawing.Color.FromArgb(CType(CType(160, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance76.ForeColor = System.Drawing.Color.FromArgb(CType(CType(90, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(50, Byte), Integer))
        Appearance76.TextVAlignAsString = "Middle"
        Me.btn7.Appearance = Appearance76
        Me.btn7.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance77.BackColor = System.Drawing.Color.DarkOrange
        Appearance77.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance77.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance77.ForeColor = System.Drawing.Color.Black
        Me.btn7.HotTrackAppearance = Appearance77
        Me.btn7.ImageSize = New System.Drawing.Size(32, 32)
        Me.btn7.Location = New System.Drawing.Point(34, 225)
        Me.btn7.Name = "btn7"
        Appearance78.BackColor = System.Drawing.Color.OrangeRed
        Appearance78.BackColor2 = System.Drawing.Color.Tomato
        Appearance78.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.btn7.PressedAppearance = Appearance78
        Me.btn7.ShowFocusRect = False
        Me.btn7.ShowOutline = False
        Me.btn7.Size = New System.Drawing.Size(60, 50)
        Me.btn7.TabIndex = 2
        Me.btn7.Tag = "7"
        Me.btn7.Text = "7"
        Me.btn7.UseAppStyling = False
        Me.btn7.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.btn7.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.btn7.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'btn6
        '
        Appearance79.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Appearance79.BackGradientStyle = Infragistics.Win.GradientStyle.None
        Appearance79.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance79.BorderColor = System.Drawing.Color.FromArgb(CType(CType(160, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance79.BorderColor2 = System.Drawing.Color.FromArgb(CType(CType(160, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance79.ForeColor = System.Drawing.Color.FromArgb(CType(CType(90, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(50, Byte), Integer))
        Appearance79.TextVAlignAsString = "Middle"
        Me.btn6.Appearance = Appearance79
        Me.btn6.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance80.BackColor = System.Drawing.Color.DarkOrange
        Appearance80.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance80.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance80.ForeColor = System.Drawing.Color.Black
        Me.btn6.HotTrackAppearance = Appearance80
        Me.btn6.ImageSize = New System.Drawing.Size(32, 32)
        Me.btn6.Location = New System.Drawing.Point(166, 169)
        Me.btn6.Name = "btn6"
        Appearance81.BackColor = System.Drawing.Color.OrangeRed
        Appearance81.BackColor2 = System.Drawing.Color.Tomato
        Appearance81.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.btn6.PressedAppearance = Appearance81
        Me.btn6.ShowFocusRect = False
        Me.btn6.ShowOutline = False
        Me.btn6.Size = New System.Drawing.Size(60, 50)
        Me.btn6.TabIndex = 3
        Me.btn6.Tag = "6"
        Me.btn6.Text = "6"
        Me.btn6.UseAppStyling = False
        Me.btn6.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.btn6.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.btn6.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'btn5
        '
        Appearance82.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Appearance82.BackGradientStyle = Infragistics.Win.GradientStyle.None
        Appearance82.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance82.BorderColor = System.Drawing.Color.FromArgb(CType(CType(160, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance82.BorderColor2 = System.Drawing.Color.FromArgb(CType(CType(160, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance82.ForeColor = System.Drawing.Color.FromArgb(CType(CType(90, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(50, Byte), Integer))
        Appearance82.TextVAlignAsString = "Middle"
        Me.btn5.Appearance = Appearance82
        Me.btn5.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance83.BackColor = System.Drawing.Color.DarkOrange
        Appearance83.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance83.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance83.ForeColor = System.Drawing.Color.Black
        Me.btn5.HotTrackAppearance = Appearance83
        Me.btn5.ImageSize = New System.Drawing.Size(32, 32)
        Me.btn5.Location = New System.Drawing.Point(100, 169)
        Me.btn5.Name = "btn5"
        Appearance84.BackColor = System.Drawing.Color.OrangeRed
        Appearance84.BackColor2 = System.Drawing.Color.Tomato
        Appearance84.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.btn5.PressedAppearance = Appearance84
        Me.btn5.ShowFocusRect = False
        Me.btn5.ShowOutline = False
        Me.btn5.Size = New System.Drawing.Size(60, 50)
        Me.btn5.TabIndex = 4
        Me.btn5.Tag = "5"
        Me.btn5.Text = "5"
        Me.btn5.UseAppStyling = False
        Me.btn5.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.btn5.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.btn5.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'btn4
        '
        Appearance85.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Appearance85.BackGradientStyle = Infragistics.Win.GradientStyle.None
        Appearance85.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance85.BorderColor = System.Drawing.Color.FromArgb(CType(CType(160, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance85.BorderColor2 = System.Drawing.Color.FromArgb(CType(CType(160, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance85.ForeColor = System.Drawing.Color.FromArgb(CType(CType(90, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(50, Byte), Integer))
        Appearance85.TextVAlignAsString = "Middle"
        Me.btn4.Appearance = Appearance85
        Me.btn4.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance86.BackColor = System.Drawing.Color.DarkOrange
        Appearance86.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance86.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance86.ForeColor = System.Drawing.Color.Black
        Me.btn4.HotTrackAppearance = Appearance86
        Me.btn4.ImageSize = New System.Drawing.Size(32, 32)
        Me.btn4.Location = New System.Drawing.Point(34, 169)
        Me.btn4.Name = "btn4"
        Appearance87.BackColor = System.Drawing.Color.OrangeRed
        Appearance87.BackColor2 = System.Drawing.Color.Tomato
        Appearance87.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.btn4.PressedAppearance = Appearance87
        Me.btn4.ShowFocusRect = False
        Me.btn4.ShowOutline = False
        Me.btn4.Size = New System.Drawing.Size(60, 50)
        Me.btn4.TabIndex = 5
        Me.btn4.Tag = "4"
        Me.btn4.Text = "4"
        Me.btn4.UseAppStyling = False
        Me.btn4.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.btn4.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.btn4.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'btn3
        '
        Appearance88.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Appearance88.BackGradientStyle = Infragistics.Win.GradientStyle.None
        Appearance88.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance88.BorderColor = System.Drawing.Color.FromArgb(CType(CType(160, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance88.BorderColor2 = System.Drawing.Color.FromArgb(CType(CType(160, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance88.ForeColor = System.Drawing.Color.FromArgb(CType(CType(90, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(50, Byte), Integer))
        Appearance88.TextVAlignAsString = "Middle"
        Me.btn3.Appearance = Appearance88
        Me.btn3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance89.BackColor = System.Drawing.Color.DarkOrange
        Appearance89.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance89.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance89.ForeColor = System.Drawing.Color.Black
        Me.btn3.HotTrackAppearance = Appearance89
        Me.btn3.ImageSize = New System.Drawing.Size(32, 32)
        Me.btn3.Location = New System.Drawing.Point(166, 113)
        Me.btn3.Name = "btn3"
        Appearance90.BackColor = System.Drawing.Color.OrangeRed
        Appearance90.BackColor2 = System.Drawing.Color.Tomato
        Appearance90.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.btn3.PressedAppearance = Appearance90
        Me.btn3.ShowFocusRect = False
        Me.btn3.ShowOutline = False
        Me.btn3.Size = New System.Drawing.Size(60, 50)
        Me.btn3.TabIndex = 6
        Me.btn3.Tag = "3"
        Me.btn3.Text = "3"
        Me.btn3.UseAppStyling = False
        Me.btn3.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.btn3.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.btn3.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'btn2
        '
        Appearance91.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Appearance91.BackGradientStyle = Infragistics.Win.GradientStyle.None
        Appearance91.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance91.BorderColor = System.Drawing.Color.FromArgb(CType(CType(160, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance91.BorderColor2 = System.Drawing.Color.FromArgb(CType(CType(160, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance91.ForeColor = System.Drawing.Color.FromArgb(CType(CType(90, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(50, Byte), Integer))
        Appearance91.TextVAlignAsString = "Middle"
        Me.btn2.Appearance = Appearance91
        Me.btn2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance92.BackColor = System.Drawing.Color.DarkOrange
        Appearance92.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance92.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance92.ForeColor = System.Drawing.Color.Black
        Me.btn2.HotTrackAppearance = Appearance92
        Me.btn2.ImageSize = New System.Drawing.Size(32, 32)
        Me.btn2.Location = New System.Drawing.Point(100, 113)
        Me.btn2.Name = "btn2"
        Appearance93.BackColor = System.Drawing.Color.OrangeRed
        Appearance93.BackColor2 = System.Drawing.Color.Tomato
        Appearance93.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.btn2.PressedAppearance = Appearance93
        Me.btn2.ShowFocusRect = False
        Me.btn2.ShowOutline = False
        Me.btn2.Size = New System.Drawing.Size(60, 50)
        Me.btn2.TabIndex = 7
        Me.btn2.Tag = "2"
        Me.btn2.Text = "2"
        Me.btn2.UseAppStyling = False
        Me.btn2.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.btn2.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.btn2.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'btn1
        '
        Appearance94.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Appearance94.BackGradientStyle = Infragistics.Win.GradientStyle.None
        Appearance94.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance94.BorderColor = System.Drawing.Color.FromArgb(CType(CType(160, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance94.BorderColor2 = System.Drawing.Color.FromArgb(CType(CType(160, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance94.ForeColor = System.Drawing.Color.FromArgb(CType(CType(90, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(50, Byte), Integer))
        Appearance94.TextVAlignAsString = "Middle"
        Me.btn1.Appearance = Appearance94
        Me.btn1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance95.BackColor = System.Drawing.Color.DarkOrange
        Appearance95.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance95.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance95.ForeColor = System.Drawing.Color.Black
        Me.btn1.HotTrackAppearance = Appearance95
        Me.btn1.ImageSize = New System.Drawing.Size(32, 32)
        Me.btn1.Location = New System.Drawing.Point(34, 113)
        Me.btn1.Name = "btn1"
        Appearance96.BackColor = System.Drawing.Color.OrangeRed
        Appearance96.BackColor2 = System.Drawing.Color.Tomato
        Appearance96.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.btn1.PressedAppearance = Appearance96
        Me.btn1.ShowFocusRect = False
        Me.btn1.ShowOutline = False
        Me.btn1.Size = New System.Drawing.Size(60, 50)
        Me.btn1.TabIndex = 8
        Me.btn1.Tag = "1"
        Me.btn1.Text = "1"
        Me.btn1.UseAppStyling = False
        Me.btn1.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.btn1.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.btn1.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'frmLogin
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(200, Byte), Integer), CType(CType(180, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(287, 499)
        Me.ControlBox = False
        Me.Controls.Add(Me.gbxBorder)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "frmLogin"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.gbxBorder.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Private WithEvents lblOutput As Infragistics.Win.Misc.UltraLabel
    Private WithEvents lblHeader As Infragistics.Win.Misc.UltraLabel
    Private WithEvents lblWelcome As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents gbxBorder As Windows.Forms.GroupBox
    Friend WithEvents btnClear As Infragistics.Win.Misc.UltraButton
    Friend WithEvents btnLogin As Infragistics.Win.Misc.UltraButton
    Friend WithEvents btnClose As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton3 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraButton2 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents btn0 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents btn9 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents btn8 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents btn7 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents btn6 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents btn5 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents btn4 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents btn3 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents btn2 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents btn1 As Infragistics.Win.Misc.UltraButton

End Class
