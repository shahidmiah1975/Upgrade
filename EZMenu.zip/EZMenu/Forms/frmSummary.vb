﻿Imports Infragistics.Win.Misc
Imports System.IO
Imports Infragistics.Win
Imports Infragistics.Win.UltraWinEditors
Imports EZControls

Public Class frmSummary

    Private ctrlControlEntered As UltraTextEditor
    Private blnEraseBox As Boolean = False
    Private twrWriter As TextWriter
    Private strFileName As String
    Private datWorkingDay As Date
    Private objPrevTextbox As UltraTextEditor
    Private tValue As Single

    Private Sub frmSummaryLoad(sender As Object, e As EventArgs) Handles MyBase.Load

        Size = frmOpener.Size
        Location = frmOpener.Location

        SetupButtons()

        'store num values for printing
        txtDTotal.Tag = Nothing
        txtCTotal.Tag = Nothing

        datWorkingDay = GetDateNow()

        If objSecurity.IsMySystem() Then
            UltraButton1.Visible = True
            UltraButton2.Visible = True
        End If

        Try
            GetCollectionData()
            GetDeliveryData()
            GetTableData()

            CalcRowTotals()
            CalcColTotals()
            DoTotalTotal()

            GetOnlineData()

            GetSummaryFromDB()

            CalcTipsTotals()

            cmdDoSums_Click(sender, e)
            cmdDoOLSums_Click(sender, e)
            cmdDoAllGrandTotals_Click(sender, e)

            lblStatus.Text = "Summary for: " & Format(CDate(GetDateNow()), "dddd dd MMMM yyyy")

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub SetupButtons()

        For Each myobjx In Controls
            If (TypeName(myobjx) = "UltraButton" And myobjx.width = 126) Then
                Dim myObj As UltraButton = DirectCast(myobjx, UltraButton)
                myObj.Tag = myObj.Text
                myObj.Text = String.Empty
                AddHandler myObj.MouseEnter, AddressOf ButtonMouseEnter
                AddHandler myObj.MouseLeave, AddressOf ButtonMouseLeave
            End If
        Next

    End Sub

    Private Sub ButtonMouseEnter(sender As Object, e As EventArgs)
        sender.text = sender.tag
    End Sub

    Private Sub ButtonMouseLeave(sender As Object, e As EventArgs)
        sender.Text = String.Empty
    End Sub

    Private Sub cmdClose_Click(sender As Object, e As EventArgs) Handles cmdClose.Click
        Dispose()
    End Sub

    Private Sub TextboxEnter(sender As Object, e As EventArgs) Handles txtDCash.Enter, txtDCards.Enter, txtDOther.Enter, txtCCash.Enter,
                                                                                                 txtCCards.Enter, txtCOther.Enter, txtTCash.Enter, txtTCards.Enter,
                                                                                                 txtTOther.Enter, txtExpenses.Enter, txtR1C1.Enter, txtR1C2.Enter,
                                                                                                 txtR1C3.Enter, txtR2C1.Enter, txtR2C2.Enter, txtR2C3.Enter,
                                                                                                 txtR3C1.Enter, txtR3C2.Enter, txtR3C3.Enter, txtR4C1.Enter,
                                                                                                 txtR4C2.Enter, txtR4C3.Enter, txtR5C1.Enter, txtR5C2.Enter,
                                                                                                 txtR5C3.Enter, txtBankCard.Enter, txtBankCash.Enter, txtBankOther.Enter,
                                                                                                 txtTipsCard.Enter, txtTipsCash.Enter, txtTipsOther.Enter

        ctrlControlEntered = CType(sender, UltraTextEditor)

        HiLitBox(ctrlControlEntered)

        If objPrevTextbox IsNot Nothing AndAlso objPrevTextbox.Name <> ctrlControlEntered.Name Then
            HiLitOffBox(objPrevTextbox)
        End If

        ctrlControlEntered.AlwaysInEditMode = True
        objPrevTextbox = ctrlControlEntered
        blnEraseBox = True

        Try
            ctrlControlEntered.SelectAll()
        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub TextboxLeave(sender As Object, e As EventArgs) ' Handles txtDCash.Leave, txtDCards.Leave, txtDOther.Leave, _
        'txtCCash.Leave, txtCCards.Leave, txtCOther.Leave, txtTCash.Leave, txtTCards.Leave, txtTOther.Leave, txtTips.Leave, txtExpenses.Leave

        Try
            sender.text = fixCur(sender.text)
            CalcRowTotals()
            CalcColTotals()
            DoTotalTotal()
        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub TextboxValueChanged(sender As Object, e As EventArgs) Handles txtDCash.TextChanged, txtDCards.TextChanged, txtDOther.TextChanged, txtCCash.TextChanged,
                                                                                                 txtCCards.TextChanged, txtCOther.TextChanged, txtTCash.TextChanged, txtTCards.TextChanged,
                                                                                                 txtTOther.TextChanged, txtExpenses.TextChanged, txtR1C1.TextChanged, txtR1C2.TextChanged,
                                                                                                 txtR1C3.TextChanged, txtR2C1.TextChanged, txtR2C2.TextChanged, txtR2C3.TextChanged,
                                                                                                 txtR3C1.TextChanged, txtR3C2.TextChanged, txtR3C3.TextChanged, txtR4C1.TextChanged,
                                                                                                 txtR4C2.TextChanged, txtR4C3.TextChanged, txtR5C1.TextChanged, txtR5C2.TextChanged,
                                                                                                 txtR5C3.TextChanged, txtBankCard.TextChanged, txtBankCash.TextChanged, txtBankOther.TextChanged,
                                                                                                 txtTipsCard.TextChanged, txtTipsCash.TextChanged, txtTipsOther.TextChanged

        cmdDoSums_Click(sender, e)
        cmdDoOLSums_Click(sender, e)

        txtGrandCash.Text = fixCur(Val(txtTotalCash.Text) + Val(txtOLTotalCash.Text))
        txtGrandCards.Text = fixCur(Val(txtTotalCards.Text) + Val(txtOLTotalCards.Text))
        txtGrandOther.Text = fixCur(Val(txtTotalOther.Text) + Val(txtOLTotalOther.Text))
        txtGrandTotalTotal.Text = fixCur(Val(txtGrandCash.Text) + Val(txtGrandCards.Text) + Val(txtGrandOther.Text))

    End Sub

    Private Sub NumHandler(sender As Object, e As EventArgs) Handles cmdNum0.Click, cmdNum1.Click, cmdNum2.Click, cmdNum3.Click,
        cmdNum4.Click, cmdNum5.Click, cmdNum6.Click, cmdNum7.Click, cmdNum8.Click, cmdNum9.Click

        If ctrlControlEntered Is Nothing Then Exit Sub

        If ctrlControlEntered.TextLength = 10 Then Exit Sub

        Dim intNum As Short, blnIsOk As Boolean = False

        intNum = sender.text

        Select Case intNum
            Case 0
                If ctrlControlEntered.Text = "0" Then
                    blnIsOk = False
                Else
                    blnIsOk = True
                End If
            Case 1 To 9
                If ctrlControlEntered.Text = "0" Then
                    ctrlControlEntered.Text = String.Empty
                End If
                blnIsOk = True
            Case Else
        End Select

        If blnIsOk Then
            If blnEraseBox = True Then
                ctrlControlEntered.Text = "0.00"
                blnEraseBox = False
            End If
            AppendNum(ctrlControlEntered, intNum, 8)
        End If

    End Sub

    Private Sub DotHandler(sender As Object, e As EventArgs)

        If ctrlControlEntered Is Nothing Then Exit Sub

        If ctrlControlEntered.TextLength = 10 Then Exit Sub

        If InStr(ctrlControlEntered.Text, ".") = 0 Then
            ctrlControlEntered.Text += "."
        End If

    End Sub

    Private Sub cmdClear_Click(sender As Object, e As EventArgs) Handles cmdClear.Click

        If ctrlControlEntered Is Nothing Then Exit Sub

        ctrlControlEntered.Text = "0.00"

    End Sub

    Private Sub GetSummaryFromDB()

        lblDeliveries.Text = "Deliveries (" & GetCounts("DN") & "): "
        txtDTotal.Text = fixCur(GetCounts("DS"))
        txtDTotal.Tag = GetCounts("DN")

        lblCollections.Text = "Collections (" & GetCounts("CN") & "): "
        txtCTotal.Text = fixCur(GetCounts("CS"))
        txtCTotal.Tag = GetCounts("CN")

        SQLQuery = "SELECT COUNT(TabUniqueID) AS NumTable, CASE WHEN SUM(BillTotal) IS NULL THEN 0 ELSE SUM(BillTotal) END AS SumTable, " &
                   "CASE WHEN SUM(NumCust) IS NULL THEN 0 ELSE SUM(NumCust) END AS TableCusts " &
                   "FROM Table_Bill WHERE ((TableStatus > 1) AND (BizId BETWEEN 40 AND 60));"
        drDataRow = objDB.GetSingleRow(SQLQuery)
        If drDataRow IsNot Nothing Then
            Dim tempStr2, tempStr3 As String
            If IsDBNull(drDataRow!NumTable) Then tempStr = "0" Else tempStr = drDataRow!NumTable
            tempStr2 = GetCounts("TCusts")
            tempStr3 = GetCounts("TS")
            lblTables.Text = "Tables (" & tempStr & "/" & tempStr2 & "): "
            lblTables.Tag = tempStr2
            txtTTotal.Text = fixCur(tempStr3)
            txtTTotal.Tag = tempStr
        End If

        SQLQuery = "SELECT SUM(TCash) AS TCash, SUM(TCard) AS TCard, SUM(TOther) AS TOther FROM Table_Bill WHERE ((TableStatus > 1) AND (BizId BETWEEN 40 AND 60));"
        drDataRow = objDB.GetSingleRow(SQLQuery)
        If drDataRow IsNot Nothing Then
            txtTipsCash.Text = fixCur(drDataRow!TCash)
            txtTipsCard.Text = fixCur(drDataRow!TCard)
            txtTipsOther.Text = fixCur(drDataRow!TOther)
        End If

    End Sub

    Private Sub cmdPrintSummary_Click(sender As Object, e As EventArgs) Handles cmdPrintSummary.Click

        Try
            strFileName = GetEZPDAPath() & "SUMMARY.DAT"
            If File.Exists(strFileName) Then File.Delete(strFileName)

            twrWriter = New StreamWriter(strFileName)
            If lblStatus.Text.Contains(" - ") = True Then
                tempStr = cmdDateStart.Tag & " - " & cmdDateEnd.Tag
            Else
                tempStr = Format(datWorkingDay, "ddd dd MMM yyyy")
            End If
            WriteField("#DateString = " & tempStr)
            WriteField("#DCash = " & txtDCash.Text)
            WriteField("#CCash = " & txtCCash.Text)
            WriteField("#TCash = " & txtTCash.Text)
            WriteField("#DCard = " & txtDCards.Text)
            WriteField("#CCard = " & txtCCards.Text)
            WriteField("#TCard = " & txtTCards.Text)
            WriteField("#DOther = " & txtDOther.Text)
            WriteField("#COther = " & txtCOther.Text)
            WriteField("#TOther = " & txtTOther.Text)
            WriteField("#DTotal = " & txtDTotal.Text)
            WriteField("#CTotal = " & txtCTotal.Text)
            WriteField("#TTotal = " & txtTTotal.Text)
            WriteField("#TotalCash = " & txtTotalCash.Text)
            WriteField("#TotalCard = " & txtTotalCards.Text)
            WriteField("#TotalOther = " & txtTotalOther.Text)
            WriteField("#GrandTotal = " & txtTotalTotal.Text)
            WriteField("#NumDeliveries = " & txtDTotal.Tag)
            WriteField("#NumCollections = " & txtCTotal.Tag)
            WriteField("#NumTables = " & txtTTotal.Tag)
            WriteField("#NumOrders = " & (Val(txtCTotal.Tag) + Val(txtDTotal.Tag) + Val(txtTTotal.Tag)))
            WriteField("#TableCusts = " & lblTables.Tag)
            WriteField("#Tips = " & txtTipsTotal.Text)
            WriteField("#Expenses = " & txtExpenses.Text)

            'print online order totals
            If lblOL1.Visible = True Then
                WriteField("#OL1 = " & lblOL1.Text & txtR1C4.Text)
                WriteField("#OLTotals = " & txtOLTotalTotal.Text)
                WriteField("#GrandCash = " & txtGrandCash.Text)
                WriteField("#GrandCards = " & txtGrandCards.Text)
                WriteField("#GrandOther = " & txtGrandOther.Text)
                WriteField("#GrandTotalTotal = " & txtGrandTotalTotal.Text)
            End If
            If lblOL2.Visible = True Then WriteField("#OL2 = " & lblOL2.Text & txtR2C4.Text)
            If lblOL3.Visible = True Then WriteField("#OL3 = " & lblOL3.Text & txtR3C4.Text)
            If lblOL4.Visible = True Then WriteField("#OL4 = " & lblOL4.Text & txtR4C4.Text)
            If lblOL5.Visible = True Then WriteField("#OL5 = " & lblOL5.Text & txtR5C4.Text)
            'If lblOL6.Visible = True Then WriteField("#OL6 = " & lblOL6.Text & txtR6C4.Text)

            twrWriter.Flush()
            twrWriter.Close()

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub WriteField(strFieldToWrite As String, Optional strFieldName As String = "")

        If strFieldToWrite.Trim = "" Then Exit Sub

        If strFieldName = "" Then

            If InStr(strFieldToWrite, "=") = 0 Then
                tempStr = strFieldToWrite
            Else
                tempStr = strFieldToWrite.Substring(strFieldToWrite.IndexOf(" = ") + 3).Trim
            End If

            If tempStr <> "" Then twrWriter.WriteLine(strFieldToWrite)

        Else
            'get the field setting from the DB which was put in there by SaveInDatabase
            tempStr = strFieldToWrite & strFieldName
            twrWriter.WriteLine(tempStr)
        End If

    End Sub

    Private Sub CalcRowTotals()

        txtDTotal.Text = fixCur(Val(txtDCash.Text) + Val(txtDCards.Text) + Val(txtDOther.Text))
        txtCTotal.Text = fixCur(Val(txtCCash.Text) + Val(txtCCards.Text) + Val(txtCOther.Text))
        txtTTotal.Text = fixCur(Val(txtTCash.Text) + Val(txtTCards.Text) + Val(txtTOther.Text))
        lblRTotal.Tag = Val(txtDTotal.Text) + Val(txtCTotal.Text) + Val(txtTTotal.Text)

    End Sub

    Private Sub CalcColTotals()

        txtTotalCash.Text = fixCur(Val(txtDCash.Text) + Val(txtCCash.Text) + Val(txtTCash.Text))
        txtTotalCards.Text = fixCur(Val(txtDCards.Text) + Val(txtCCards.Text) + Val(txtTCards.Text))
        txtTotalOther.Text = fixCur(Val(txtDOther.Text) + Val(txtCOther.Text) + Val(txtTOther.Text))
        lblCTotal.Tag = Val(txtTotalCash.Text) + Val(txtTotalCards.Text) + Val(txtTotalOther.Text)

    End Sub

    Private Sub CalcOLRowTotals()

        txtR1C4.Text = fixCur(Val(txtR1C1.Text) + Val(txtR1C2.Text) + Val(txtR1C3.Text))
        txtR2C4.Text = fixCur(Val(txtR2C1.Text) + Val(txtR2C2.Text) + Val(txtR2C3.Text))
        txtR3C4.Text = fixCur(Val(txtR3C1.Text) + Val(txtR3C2.Text) + Val(txtR3C3.Text))
        txtR4C4.Text = fixCur(Val(txtR4C1.Text) + Val(txtR4C2.Text) + Val(txtR4C3.Text))
        txtR5C4.Text = fixCur(Val(txtR5C1.Text) + Val(txtR5C2.Text) + Val(txtR5C3.Text))
        'txtR6C4.Text = fixCur(Val(txtR6C1.Text) + Val(txtR6C2.Text) + Val(txtR6C3.Text))

    End Sub

    Private Sub CalcOLColTotals()

        txtOLTotalCash.Text = fixCur(Val(txtR1C1.Text) + Val(txtR2C1.Text) + Val(txtR3C1.Text) + Val(txtR4C1.Text) + Val(txtR5C1.Text))
        txtOLTotalCards.Text = fixCur(Val(txtR1C2.Text) + Val(txtR2C2.Text) + Val(txtR3C2.Text) + Val(txtR4C2.Text) + Val(txtR5C2.Text))
        txtOLTotalOther.Text = fixCur(Val(txtR1C3.Text) + Val(txtR2C3.Text) + Val(txtR3C3.Text) + Val(txtR4C3.Text) + Val(txtR5C3.Text))

    End Sub

    Private Sub CalcBankRowTotals()

        txtBankTotal.Text = fixCur(Val(txtBankCash.Text) + Val(txtBankCard.Text) + Val(txtBankOther.Text))

    End Sub

    Private Sub CalcTipsTotals()

        txtTipsTotal.Text = fixCur(Val(txtTipsCash.Text) + Val(txtTipsCard.Text) + Val(txtTipsOther.Text))

    End Sub

    Private Sub GetCollectionData()

        Try

            'collection's data
            SQLQuery = $"SELECT DISTINCT PaymentMethod, Sum(BillTotal) AS SumAll 
                        FROM Orders 
                        WHERE CustomerID >= { intMaxCustomerID } And IsDeleted = 0 AND (BizId BETWEEN 40 AND 60) 
                        GROUP BY PaymentMethod"

            drcDatarowCollection = objDB.GetDataRows(SQLQuery)
            If drcDatarowCollection.Count > 0 Then
                For Each myRow In drcDatarowCollection
                    tempStr = myRow("PaymentMethod").ToString
                    tValue = myRow("SumAll")
                    If Val(tValue) <> 0 Then
                        If tempStr.ToUpper = "CASH" Then
                            txtCCash.Text = fixCur(tValue)
                        ElseIf tempStr.ToUpper = "CARD" Then
                            txtCCards.Text = fixCur(tValue)
                        Else  'other
                            txtCOther.Text = fixCur(Val(txtCOther.Text) + Val(tValue))
                        End If
                    End If
                Next
            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub GetDeliveryData()

        Try

            'collection's data
            SQLQuery = String.Format("Select DISTINCT PaymentMethod, Sum(BillTotal) AS SumAll " &
                       "FROM Orders " &
                       "WHERE ((CustomerID < {0}) AND (IsDeleted = 0) AND (BizId BETWEEN 40 AND 60)) " &
                       "GROUP BY PaymentMethod", intMaxCustomerID)

            drcDatarowCollection = objDB.GetDataRows(SQLQuery)
            If drcDatarowCollection.Count > 0 Then
                For Each myRow In drcDatarowCollection
                    tempStr = myRow("PaymentMethod").ToString
                    tValue = myRow("SumAll")
                    If Val(tValue) <> 0 Then
                        If tempStr.ToUpper = "CASH" Then
                            txtDCash.Text = fixCur(tValue)
                        ElseIf tempStr.ToUpper = "CARD" Then
                            txtDCards.Text = fixCur(tValue)
                        Else  'other
                            txtDOther.Text = fixCur(Val(txtDOther.Text) + Val(tValue))
                        End If
                    End If
                Next

            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub GetTableData()

        Try

            'table's data
            SQLQuery = "SELECT DISTINCT CASE WHEN PaymentMethod IS NULL THEN 'Other' ELSE PaymentMethod END AS PaymentMethod, " &
                       "CASE WHEN BillTotal IS NULL THEN 0 ELSE BillTotal END AS SumAll " &
                       "FROM Table_Bill WHERE (BizId BETWEEN 40 AND 60) " &
                       "GROUP BY PaymentMethod, BillTotal HAVING (PaymentMethod <> 'Mixed')"

            drcDatarowCollection = objDB.GetDataRows(SQLQuery)
            If drcDatarowCollection.Count > 0 Then
                For Each myRow In drcDatarowCollection
                    tempStr = myRow("PaymentMethod").ToString
                    tValue = myRow("SumAll")
                    If Val(tValue) <> 0 Then
                        If tempStr.ToUpper = "CASH" Then
                            txtTCash.Text = fixCur(Val(txtTCash.Text) + tValue)
                        ElseIf tempStr.ToUpper = "CARD" Then
                            txtTCards.Text = fixCur(Val(txtTCards.Text) + tValue)
                        Else  'other
                            txtTOther.Text = fixCur(Val(txtTOther.Text) + tValue)
                        End If
                    End If
                Next
            End If

            SQLQuery = "SELECT SUM(PCash) AS PCash, SUM(PCard) AS PCard, SUM(POther) AS POther " &
                       "FROM Table_Bill WHERE (BizId BETWEEN 40 AND 60) " &
                       "GROUP BY PaymentMethod HAVING (PaymentMethod = 'Mixed')"

            drDataRow = objDB.GetSingleRow(SQLQuery)
            If drDataRow IsNot Nothing Then
                txtTCash.Text = CDec(txtTCash.Text) + CDec(drDataRow!PCash)
                txtTCards.Text = CDec(txtTCards.Text) + CDec(drDataRow!PCard)
                txtTOther.Text = CDec(txtTOther.Text) + CDec(drDataRow!POther)
            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub DoTotalTotal()

        Dim rTot, cTot As Decimal

        rTot = Val(txtTotalCash.Text) + Val(txtTotalCards.Text) + Val(txtTotalOther.Text)
        cTot = Val(txtDTotal.Text) + Val(txtCTotal.Text) + Val(txtTTotal.Text)

        If cTot = rTot Then
            txtTotalTotal.Text = fixCur(cTot)
            txtTotalTotal.Width = 112
            txtTotalTotal.Appearance.TextHAlign = HAlign.Right
        Else
            txtTotalTotal.Text = fixCur(cTot) & " | " & fixCur(rTot)
            txtTotalTotal.Width = 220
            txtTotalTotal.Appearance.TextHAlign = HAlign.Center
        End If

    End Sub

    Private Sub cmdDoSums_Click(sender As Object, e As EventArgs) Handles cmdDoSums.Click

        CalcRowTotals()
        CalcColTotals()
        DoTotalTotal()

        CalcTipsTotals()

        If lblBanking.Visible Then CalcBankRowTotals()

        'blnEraseBox = True

    End Sub

    Private Sub cmdDoAllGrandTotals_Click(sender As Object, e As EventArgs) Handles cmdDoAllGrandTotals.Click

        cmdDoSums_Click(sender, e)
        cmdDoOLSums_Click(sender, e)

        txtGrandCash.Text = fixCur(Val(txtTotalCash.Text) + Val(txtOLTotalCash.Text))
        txtGrandCards.Text = fixCur(Val(txtTotalCards.Text) + Val(txtOLTotalCards.Text))
        txtGrandOther.Text = fixCur(Val(txtTotalOther.Text) + Val(txtOLTotalOther.Text))
        txtGrandTotalTotal.Text = fixCur(Val(txtGrandCash.Text) + Val(txtGrandCards.Text) + Val(txtGrandOther.Text))

        'If lblBanking.Visible = True Then
        '    txtGrandCash.Text = fixCur(Val(txtGrandCash.Text) + Val(txtBankCash.Text))
        '    txtGrandCards.Text = fixCur(Val(txtGrandCards.Text) + Val(txtBankCard.Text))
        '    txtGrandOther.Text = fixCur(Val(txtGrandOther.Text) + Val(txtBankOther.Text))
        '    txtGrandTotalTotal.Text = fixCur(Val(txtGrandTotalTotal.Text) + Val(txtBankTotal.Text))
        'End If

    End Sub

    Private Sub cmdDoOLSums_Click(sender As Object, e As EventArgs) Handles cmdDoOLSums.Click

        CalcOLRowTotals()
        CalcOLColTotals()
        CalcOLTotalTotals()

    End Sub

    Private Sub CalcOLTotalTotals()

        Dim rTot, cTot As Decimal

        rTot = Val(txtOLTotalCash.Text) + Val(txtOLTotalCards.Text) + Val(txtOLTotalOther.Text)
        cTot = Val(txtR1C4.Text) + Val(txtR2C4.Text) + Val(txtR3C4.Text) + Val(txtR4C4.Text) + Val(txtR5C4.Text)

        If cTot = rTot Then
            txtOLTotalTotal.Text = fixCur(cTot)
            txtOLTotalTotal.Width = 112
            txtOLTotalTotal.Appearance.TextHAlign = HAlign.Right
        Else
            txtOLTotalTotal.Text = fixCur(cTot) & " | " & fixCur(rTot)
            txtOLTotalTotal.Width = 220
            txtOLTotalTotal.Appearance.TextHAlign = HAlign.Center
        End If

    End Sub

    Private Sub GetOnlineData()

        Try
            Dim blnExitOLLoop As Boolean = False
            Dim strRow, strCol As String

            strRow = ""
            strCol = ""

            SQLQuery = "SELECT DISTINCT PaymentMethod, Sum(BillTotal) AS SumAll " &
                       "FROM Orders " &
                       "WHERE BizId BETWEEN 40 AND 60" &
                       "GROUP BY PaymentMethod"

            drcDatarowCollection = objDB.GetDataRows(SQLQuery)
            If drcDatarowCollection.Count > 0 Then
                For Each myRow In drcDatarowCollection
                    blnExitOLLoop = False
                    tempStr = myRow("PaymentMethod").ToString
                    tValue = myRow("SumAll")
                    If Val(tValue) <> 0 Then
                        If tempStr.ToUpper = "CASH" Then
                            strCol = "1"
                        ElseIf tempStr.ToUpper = "CARD" Then
                            strCol = "2"
                        Else  'other
                            strCol = "3"
                        End If
                    End If
                Next

            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub cmdShowBanking_Click(sender As Object, e As EventArgs) Handles cmdShowBanking.Click

        lblBanking.Visible = Not lblBanking.Visible
        txtBankCard.Visible = lblBanking.Visible
        txtBankCash.Visible = lblBanking.Visible
        txtBankOther.Visible = lblBanking.Visible
        txtBankTotal.Visible = lblBanking.Visible
        cmdCopyBank.Visible = lblBanking.Visible
        cmdSaveBanking.Enabled = lblBanking.Visible

        If lblBanking.Visible = False Then
            cmdDoSums.Size = New Size(40, 40)
        Else
            cmdDoSums.Size = New Size(40, 68)
        End If

        strMsgBox = "Do you wish to save this as today's banking?"
        'intMsgBoxResult = EZMsgBox.Show(strMsgBox, MessageBoxButtons.YesNo)
        If intMsgBoxResult = MsgBoxResult.Yes Then

        End If

    End Sub

    Private Sub cmdCopyBank_Click(sender As Object, e As EventArgs) Handles cmdCopyBank.Click

        txtBankCash.Text = txtTotalCash.Text
        txtBankCard.Text = txtTotalCards.Text
        txtBankOther.Text = txtTotalOther.Text
        txtBankTotal.Text = txtTotalTotal.Text

    End Sub

    Private Sub cmdSaveBanking_Click(sender As Object, e As EventArgs) Handles cmdSaveBanking.Click

        Try

            SQLQuery = String.Format("DELETE FROM Banking WHERE Date = '{0}'", GetDateNow)
            objDB.ExeNonQuery(SQLQuery)

            SQLQuery = String.Format("INSERT INTO Banking (Date, Cash, Card, Other, Tips, Total) VALUES ('{0}', {1}, {2}, {3}, {4})",
                                        GetDateNow, txtBankCash.Text, txtBankCard.Text, txtBankOther.Text, txtBankTotal.Text)
            objDB.ExeNonQuery(SQLQuery)

            'save online shop totals
            If lblOL1.Visible = True Then SaveOL(lblOL1.Text, txtR1C1.Text, txtR1C2.Text, txtR1C3.Text, txtR1C4.Text)
            If lblOL2.Visible = True Then SaveOL(lblOL2.Text, txtR2C1.Text, txtR2C2.Text, txtR2C3.Text, txtR2C4.Text)
            If lblOL3.Visible = True Then SaveOL(lblOL3.Text, txtR3C1.Text, txtR3C2.Text, txtR3C3.Text, txtR3C4.Text)
            If lblOL4.Visible = True Then SaveOL(lblOL4.Text, txtR4C1.Text, txtR4C2.Text, txtR4C3.Text, txtR4C4.Text)
            If lblOL5.Visible = True Then SaveOL(lblOL5.Text, txtR5C1.Text, txtR5C2.Text, txtR5C3.Text, txtR5C4.Text)
            'If lblOL6.Visible = True Then SaveOL(lblOL6.Text, txtR6C1.Text, txtR6C2.Text, txtR6C3.Text, txtR6C4.Text)

            strMsgBox = "Banking has been saved"
            Alert(strMsgBox)

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub SaveOL(strShop As String, strCash As String, strCards As String, strOther As String, strTotal As String)

        Try

            strShop = Replace(strShop, ":", "").Trim

            'first delete any existing ones
            SQLQuery = String.Format("DELETE FROM OnlineSales WHERE OLDate = '{0}' AND ShopName = '{1}'", WorkDay(datWorkingDay), strShop)
            objDB.ExeNonQuery(SQLQuery)

            SQLQuery = String.Format("INSERT INTO OnlineSales (OLDate, ShopName, TCash, TCards, TOther, TTotal) VALUES ('{0}', '{1}', {2}, {3}, {4}, {5})",
                                WorkDay(datWorkingDay), strShop, strCash, strCards, strOther, strTotal)
            objDB.ExeNonQuery(SQLQuery)

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub UltraButton1_Click(sender As Object, e As EventArgs) Handles UltraButton1.Click

        Dim r As Random = New Random

        For Each myObj In upnTextBoxes.ClientArea.Controls
            If TypeName(myObj) = "TextBox" Then
                If myObj.backcolor = Color.White AndAlso myObj.visible = True Then
                    myObj.text = fixCur(r.Next(50, 501))
                End If
            End If
        Next

    End Sub

    Private Sub cmdWeekly_Click(sender As Object, e As EventArgs) Handles cmdDateStart.Click, cmdDateEnd.Click

        Dim strDate As String = EZDatePicker.SelectedDate
        If strDate <> String.Empty Then
            sender.Tag = CDate(strDate)
        End If

    End Sub

    Private Sub cmdSaveTakings_Click(sender As Object, e As EventArgs) Handles cmdSaveTakings.Click

        Try
            If IsDate(datWorkingDay) Then

                'clean table of today's takings
                SQLQuery = String.Format("DELETE FROM Sales WHERE tDate = '{0}'", WorkDay(datWorkingDay))
                objDB.ExeNonQuery(SQLQuery)

                SQLQuery = String.Format("INSERT INTO Sales (tDate, tDCash, tDCard, tDOther, tCCash, tCCard, tCOther, tTCash, tTCard, tTOther, tTips, tExpenses) " &
                                        "VALUES ('{0}', {1}, {2}, {3}, {4}, {5}, {6}, {7}, {8}, {9}, {10}, {11})", WorkDay(datWorkingDay), txtDCash.Text, txtDCards.Text, txtDOther.Text,
                                        txtCCash.Text, txtCCards.Text, txtCOther.Text, txtTCash.Text, txtTCards.Text, txtTOther.Text, txtTipsTotal.Text, txtExpenses.Text)
                objDB.ExeNonQuery(SQLQuery)

                'save online shop totals
                If lblOL1.Visible = True Then SaveOL(lblOL1.Text, txtR1C1.Text, txtR1C2.Text, txtR1C3.Text, txtR1C4.Text)
                If lblOL2.Visible = True Then SaveOL(lblOL2.Text, txtR2C1.Text, txtR2C2.Text, txtR2C3.Text, txtR2C4.Text)
                If lblOL3.Visible = True Then SaveOL(lblOL3.Text, txtR3C1.Text, txtR3C2.Text, txtR3C3.Text, txtR3C4.Text)
                If lblOL4.Visible = True Then SaveOL(lblOL4.Text, txtR4C1.Text, txtR4C2.Text, txtR4C3.Text, txtR4C4.Text)
                If lblOL5.Visible = True Then SaveOL(lblOL5.Text, txtR5C1.Text, txtR5C2.Text, txtR5C3.Text, txtR5C4.Text)
                'If lblOL6.Visible = True Then SaveOL(lblOL6.Text, txtR6C1.Text, txtR6C2.Text, txtR6C3.Text, txtR6C4.Text)

                strMsgBox = "All details have been saved"
                Alert(strMsgBox)

            Else
                strMsgBox = "Select a date or date range first"
                Alert(strMsgBox)
            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub cmdShowTakings_Click(sender As Object, e As EventArgs) Handles cmdShowTakings.Click

        cmdSaveTakings.Enabled = False
        datWorkingDay = Nothing

        If (Not IsDate(cmdDateStart.Tag)) Or (Not IsDate(cmdDateEnd.Tag)) Then
            strMsgBox = "You need to specify valid start and end dates."
            Alert(strMsgBox)

        ElseIf CDate(cmdDateStart.Tag) > CDate(cmdDateEnd.Tag) Then
            strMsgBox = "Start date cannot be later than end date."
            Alert(strMsgBox)

        Else
            ClearAllTextBoxes()
            lblStatus.Text = "Summary for: " & Format(CDate(cmdDateStart.Tag), "dddd dd MMMM yyyy") & " - " & Format(CDate(cmdDateEnd.Tag), "dddd dd MMMM yyyy")
            If cmdDateStart.Tag = cmdDateEnd.Tag Then
                cmdSaveTakings.Enabled = True
                datWorkingDay = cmdDateStart.Tag
            End If
            DisplayTakings(cmdDateStart.Tag, cmdDateEnd.Tag)

        End If

    End Sub

    Private Sub FillOnlineValues(drcTemp)

        If drcTemp IsNot Nothing Then
            Dim strRow As String, strCol As String = ""
            Dim blnExitOLLoop As Boolean = False
            Dim pmethods() = {"TCash", "TCards", "TOther", "TTotal"}
            For Each myRow As DataRow In drcTemp
                For jC As Short = 0 To 3
                    blnExitOLLoop = False
                    tempStr = pmethods(jC)
                    tValue = myRow(tempStr)
                    If Val(tValue) <> 0 Then
                        If tempStr.ToUpper = "TCASH" Then
                            strCol = "1"
                        ElseIf tempStr.ToUpper = "TCARDS" Then
                            strCol = "2"
                        ElseIf tempStr.ToUpper = "TOTHER" Then
                            strCol = "3"
                        Else  'total
                            strCol = "4"
                        End If
                    End If

                    'find the correct label
                    For Each myObj As Object In upnTextBoxes.ClientArea.Controls
                        If TypeName(myObj) = "Label" AndAlso myObj.text.ToString.ToUpper = myRow("ShopName").ToString.ToUpper & ":" Then
                            'find the corresponding textbox
                            strRow = myObj.name.ToString.Substring(myObj.name.ToString.Length - 1)
                            For Each myTextBox As Object In upnTextBoxes.ClientArea.Controls
                                If TypeName(myTextBox) = "TextBox" Then
                                    If myTextBox.name = "txtR" & strRow & "C" & strCol Then
                                        myTextBox.text = fixCur(tValue)
                                        blnExitOLLoop = True
                                        Exit For
                                    End If
                                End If
                            Next
                            If blnExitOLLoop = True Then Exit For
                        End If
                    Next
                Next
            Next
            DoAllGrandTotals()
        End If

    End Sub

    Private Sub FillSaleValues(drcTemp As DataRowCollection)

        If drcTemp IsNot Nothing Then
            For Each mRow As DataRow In drcTemp
                txtDCash.Text = fixCur(mRow!tDCash)
                txtDCards.Text = fixCur(mRow!tDCard)
                txtDOther.Text = fixCur(mRow!tDOther)
                lblDeliveries.Text = "Deliveries (" & mRow!nDeliveries & "):"

                txtCCash.Text = fixCur(mRow!tCCash)
                txtCCards.Text = fixCur(mRow!tCCard)
                txtCOther.Text = fixCur(mRow!tCOther)
                lblDeliveries.Text = "Collections (" & mRow!nCollections & "):"

                txtTCash.Text = fixCur(mRow!tTCash)
                txtTCards.Text = fixCur(mRow!tTCard)
                txtTOther.Text = fixCur(mRow!tTOther)
                lblDeliveries.Text = "Tables (" & mRow!nTables & "/" & mRow!nTableCusts & "):"

                DoAllGrandTotals()
            Next
        End If

    End Sub

    Private Sub DoAllGrandTotals()

        cmdDoAllGrandTotals_Click(Nothing, Nothing)

    End Sub

    Private Sub UltraButton2_Click(sender As Object, e As EventArgs) Handles UltraButton2.Click

        ClearAllTextBoxes()

    End Sub

    Private Sub cmdWorkingDay_Click(sender As Object, e As EventArgs) Handles cmdWorkingDay.Click

        ClearAllTextBoxes()

        datWorkingDay = GetDateNow()
        lblStatus.Text = "Summary for: " & Format(datWorkingDay, "dddd dd MMMM yyyy")

        GetCollectionData()
        GetDeliveryData()
        GetTableData()

        CalcRowTotals()
        CalcColTotals()
        DoTotalTotal()

        GetOnlineData()

        GetSummaryFromDB()

        cmdDoSums_Click(sender, e)
        cmdDoOLSums_Click(sender, e)
        cmdDoAllGrandTotals_Click(sender, e)

        cmdSaveTakings.Enabled = True

    End Sub

    Private Function WorkDay(Optional strXDate As String = "")

        If strXDate = "" Then
            Return Now.ToString("dd/MMM/yyyy")
        Else
            Return CDate(strXDate).ToString("dd/MMM/yyyy")
        End If

    End Function

    Private Sub cmdGetDate_Click(sender As Object, e As EventArgs) Handles cmdGetDate.Click

        Try
            Dim strDate As String = EZDatePicker.SelectedDate
            If strDate <> String.Empty Then

                lblStatus.Text = "Summary for: " & Format(CDate(strDate), "dddd dd MMMM yyyy")
                ClearAllTextBoxes()
                DisplayTakings(strDate)
                datWorkingDay = CDate(strDate)
                cmdSaveTakings.Enabled = True

            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub DisplayTakings(strDateX As Date, Optional strDateY As Date = Nothing)

        Try
            If strDateY = Nothing Then strDateY = strDateX

            SQLQuery = String.Format("SELECT SUM(tDCash) AS tDCash, SUM(tDCard) AS tDCard, SUM(tDOther) AS tDOther, SUM(tCCash) AS tCCash, SUM(tCCard) AS tCCard, " &
                                     "SUM(tCOther) AS tCOther, SUM(tTCash) AS tTCash, SUM(tTCard) AS tTCard, SUM(tTOther) AS tTOther, SUM(tExpenses) AS tExpenses, SUM(tTips) AS tTips, " &
                                     "SUM(nDeliveries) AS nDeliveries, SUM(nCollections) AS nCollections, SUM(nTables) AS nTables, SUM(nTableCusts) AS nTableCusts " &
                                     "FROM Sales WHERE tDate BETWEEN '{0}' AND '{1}'", WorkDay(strDateX), WorkDay(strDateY))

            drcDatarowCollection = objDB.GetDataRows(SQLQuery)
            FillSaleValues(drcDatarowCollection)

            SQLQuery = String.Format("SELECT ShopName, SUM(TCash) AS TCash, SUM(TCards) AS TCards, SUM(TOther) AS TOther, SUM(TTotal) AS TTotal " &
                             "FROM OnlineSales WHERE (OLDate BETWEEN '{0}' AND '{1}') GROUP BY ShopName", WorkDay(strDateX), WorkDay(strDateY))
            drcDatarowCollection = objDB.GetDataRows(SQLQuery)
            FillOnlineValues(drcDatarowCollection)

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub ClearAllTextBoxes()

        For Each myObj In upnTextBoxes.ClientArea.Controls
            If TypeName(myObj) = "TextBox" Then
                If myObj.visible = True Then myObj.text = "0.00"
            End If
        Next

        lblDeliveries.Text = "Deliveries:"
        lblCollections.Text = "Collections:"
        lblTables.Text = "Tables:"

    End Sub

    Private Function GetCounts(strOpt As String)

        Try

            If strOpt = "DS" Then

                SQLQuery = String.Format("SELECT SUM(BillTotal) AS SumDeliv, COUNT(*) AS NumDeliv FROM Orders WHERE (CustomerID < {0} AND (BizId BETWEEN 40 AND 60))", intMaxCustomerID)
                drDataRow = objDB.GetSingleRow(SQLQuery)
                If drDataRow IsNot Nothing Then
                    Return drDataRow!SumDeliv
                End If

            ElseIf strOpt = "DN" Then

                SQLQuery = String.Format("SELECT SUM(BillTotal) AS SumDeliv, COUNT(*) AS NumDeliv FROM Orders WHERE (CustomerID < {0} AND (BizId BETWEEN 40 AND 60))", intMaxCustomerID)
                drDataRow = objDB.GetSingleRow(SQLQuery)
                If drDataRow IsNot Nothing Then
                    Return drDataRow!NumDeliv
                End If

            ElseIf strOpt = "CS" Then

                SQLQuery = String.Format("SELECT SUM(BillTotal) AS SumColn, Count(*) AS NumColn FROM Orders WHERE (CustomerID >= {0} AND (BizId BETWEEN 40 AND 60))", intMaxCustomerID)
                drDataRow = objDB.GetSingleRow(SQLQuery)
                If drDataRow IsNot Nothing Then
                    Return drDataRow!SumColn
                End If

            ElseIf strOpt = "CN" Then

                SQLQuery = String.Format("SELECT SUM(BillTotal) AS SumColn, Count(*) AS NumColn FROM Orders WHERE (CustomerID >= {0} AND (BizId BETWEEN 40 AND 60))", intMaxCustomerID)
                drDataRow = objDB.GetSingleRow(SQLQuery)
                If drDataRow IsNot Nothing Then
                    Return drDataRow!NumColn
                End If

            ElseIf strOpt = "TS" Then

                SQLQuery = "SELECT COUNT(TabUniqueID) AS NumTable, SUM(BillTotal) AS SumTable, SUM(NumCust) AS TableCusts " &
                           "FROM Table_Bill WHERE ((TableStatus > 1) AND (BizId BETWEEN 40 AND 60));"
                drDataRow = objDB.GetSingleRow(SQLQuery)
                If drDataRow IsNot Nothing Then
                    If IsDBNull(drDataRow!SumTable) Then Return 0 Else Return drDataRow!SumTable
                End If

            ElseIf strOpt = "TN" Then

                SQLQuery = "SELECT COUNT(TabUniqueID) AS NumTable, SUM(BillTotal) AS SumTable, SUM(NumCust) AS TableCusts " &
                           "FROM Table_Bill WHERE ((TableStatus > 1) AND (BizId BETWEEN 40 AND 60));"
                drDataRow = objDB.GetSingleRow(SQLQuery)
                If drDataRow IsNot Nothing Then
                    If IsDBNull(drDataRow!NumTable) Then Return 0 Else Return drDataRow!NumTable
                End If

            ElseIf strOpt = "TCusts" Then

                SQLQuery = "SELECT COUNT(TabUniqueID) AS NumTable, SUM(BillTotal) AS SumTable, SUM(NumCust) AS TableCusts " &
                           "FROM Table_Bill WHERE ((TableStatus > 1) AND (BizId BETWEEN 40 AND 60));"
                drDataRow = objDB.GetSingleRow(SQLQuery)
                If drDataRow IsNot Nothing Then
                    If IsDBNull(drDataRow!TableCusts) Then Return 0 Else Return drDataRow!TableCusts
                End If

            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

        Return 0

    End Function

    Private Sub cmdGroupSummary_Click(sender As Object, e As EventArgs) Handles cmdGroupSummary.Click

        Try

            Dim objSummaryGroup As New frmSummaryGroups
            objSummaryGroup.ShowDialog()

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

End Class