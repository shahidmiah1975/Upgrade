﻿Imports EZControls

Friend Class frmLogin

    Private Declare Function SetWindowRgn Lib "user32" (hWnd As Integer, hRgn As Integer, bRedraw As Integer) As Integer
    Private Declare Function CreateRoundRectRgn Lib "gdi32" Alias "CreateRoundRectRgn" (X1 As Integer, Y1 As Integer, X2 As Integer, Y2 As Integer, X3 As Integer, Y3 As Integer) As Integer

    Private blnClearBox, blnLoginSuccess, blnResetWelcome As Boolean
    Private strPassword, SQLQuery, strMsgBox, _strLevel As String
    Private _strEZMenuConnString, strResult As String
    Private drDataRow As DataRow
    Private blnGrantAccess As Boolean


    Public ReadOnly Property AccessGranted As Boolean
        Get
            Return blnGrantAccess
        End Get
    End Property

    Public ReadOnly Property UserName As String
        Get
            Return strResult
        End Get

    End Property

    Public Sub New(strManagerOrUser As String)

        MyBase.New()
        'This call is required by the Windows Form Designer.
        InitializeComponent()

        _strEZMenuConnString = GetAppSettingCS("EZConnectionString", String.Empty)

        DoubleBuffered = True
        SuspendLayout()
        Dim cornerRadius As Short = 20
        SetWindowRgn(Handle, CreateRoundRectRgn(0, 0, Width, Height, cornerRadius, cornerRadius), True)
        ResumeLayout()

        _strLevel = strManagerOrUser
        If _strLevel = "Manager" Then
            lblHeader.Text = "Enter supervisor password:"
        Else
            lblHeader.Text = "Enter your user id:"
        End If

        strPassword = String.Empty
        blnGrantAccess = False

    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click

        strResult = ""
        Close()

    End Sub

    Private Sub ButtonsHandler(sender As Object, e As EventArgs) Handles btn1.Click, btn2.Click, btn3.Click, btn4.Click, btn5.Click,
                                                                                       btn6.Click, btn7.Click, btn8.Click, btn9.Click, btn0.Click

        If blnResetWelcome = True Then
            lblWelcome.Text = ""
            lblOutput.Text = ""
            blnResetWelcome = False
        End If

        If strPassword.Length < 20 Then
            strPassword &= sender.tag
            lblOutput.Text = StrDup(strPassword.Length, "*")
        Else
            MsgBox("Maximum length reached", MsgBoxStyle.OkOnly + MsgBoxStyle.Critical, "Error")
        End If

    End Sub

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click

        blnLoginSuccess = False

        If strPassword.Length > 0 Then

            If objSecurity.MD5Hash(strPassword) = "dad5afb5ad77256b42609d413477873c" Then 'sarwattanwir

                Hide()
                strMsgBox = "Master code entered. All passwords are turned off. Supervisor password reset to 123456" &
                    vbCrLf & "Go to Settings and change your options there now."
                EZMsgBox.Show(strMsgBox, MessageBoxButtons.Ok, MessageBoxIcon.Information)
                blnLoginSuccess = True
                strResult = "SuperDuper"
                objDB.EZSettingWrite("SuperDuper", objSecurity.MD5Hash_ThenSplitAndSwap("123456"))

                'is it super or user?
            ElseIf _strLevel = "Manager" Then

                blnLoginSuccess = (objDB.EZSettingRead("SuperDuper") = objSecurity.MD5Hash_ThenSplitAndSwap(strPassword))
                If blnLoginSuccess = True Then
                    lblWelcome.Text = "Password accepted"
                    Application.DoEvents()
                    Threading.Thread.Sleep(1000)
                Else
                    lblWelcome.Text = "Access Denied: Incorrect password"
                    strPassword = String.Empty
                    blnResetWelcome = True
                End If

            Else

                SQLQuery = "SELECT * FROM Users WHERE UserPassword = '" & objSecurity.MD5Hash(strPassword) & "'"
                drDataRow = objDB.GetSingleRow(SQLQuery)
                If drDataRow IsNot Nothing Then
                    blnLoginSuccess = True
                    lblWelcome.Text = "Hello " & drDataRow!UserName.ToString
                    strResult = drDataRow!UserName.ToString
                    Application.DoEvents()
                    Threading.Thread.Sleep(1500)
                Else
                    lblWelcome.Text = "Access Denied: Invalid user id"
                    strPassword = String.Empty
                    blnResetWelcome = True
                End If

            End If

            blnGrantAccess = blnLoginSuccess
            If blnGrantAccess Then Close()

        End If

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click

        blnResetWelcome = False
        lblOutput.Text = String.Empty
        lblWelcome.Text = String.Empty
        strPassword = String.Empty

    End Sub

    Private Sub lblHeader_Click(sender As Object, e As EventArgs) Handles lblHeader.Click

        Static intKeys As Short

        intKeys += 1
        If intKeys >= 5 Then
            MsgBox("Master code is SARTAN")
            intKeys = 0
        End If

    End Sub

End Class