﻿Imports EZControls
Imports Infragistics.Win.UltraWinGrid

Public Class frmDishesSubgroup

    Private tempUniqueID
    Private blnIsDirty As Boolean
    Private strTypical As String
    Private ugSGDishes As UltraGrid

    Public Sub New(ugdDishesMain As UltraGrid, strSubgroups As String)

        InitializeComponent()

        Size = New Size(557, 367)

        ugSGDishes = ugdDishesMain

        If strSubgroups = "Subgroups" Then
            upnlSubgrouping.Visible = True
            upnlExtraLabels.Visible = False

        Else
            Dim SQLQuery As String = "SELECT * FROM SetLabels WHERE UniqueID = " & ugSGDishes.ActiveRow.Cells("UniqueID").Value
            drcDatarowCollection = objDB.GetDataRows(SQLQuery)

            If drcDatarowCollection IsNot Nothing Then
                For Each myRow As DataRow In drcDatarowCollection
                    lstLabelItems.Items.Add(myRow!LabelName, myRow!LabelName)
                Next
            End If

            SQLQuery = "SELECT TOP 1 PrintLabelOnOff FROM SetLabels WHERE UniqueID = " & ugSGDishes.ActiveRow.Cells("UniqueID").Value
            drcDatarowCollection = objDB.GetDataRows(SQLQuery)

            If drcDatarowCollection IsNot Nothing Then
                For Each myRow As DataRow In drcDatarowCollection
                    tempStr = IIf(myRow!PrintLabelOnOff = 0, "Enable", "Disable")
                    cmdTurnOffLabel.Text = tempStr
                    cmdTurnOffLabel.Tag = myRow!PrintLabelOnOff
                    lblStatus.Text = "Label printing is " & IIf(myRow!PrintLabelOnOff <> 0, "enabled", "disabled") & " for this item"
                    Exit For
                Next
            End If

            upnlSubgrouping.Visible = False
            upnlExtraLabels.Visible = True

        End If

    End Sub

    Private Sub frmDishesSubgroup_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        CenterToParent()

        SQLQuery = "SELECT TName FROM Typical"
        drcDatarowCollection = objDB.GetDataRows(SQLQuery)
        If drcDatarowCollection IsNot Nothing Then
            For Each myRow As DataRow In drcDatarowCollection
                cmbSubgroups.Items.Add(Rnd, myRow!TName)
            Next
        End If

        Try
            If ugSGDishes.Selected.Rows.Count > 1 Then
                'many dishes selected so do not fill listbox
            Else
                tempUniqueID = ugSGDishes.ActiveRow.Cells("UniqueID").Value
                SQLQuery = "SELECT TName FROM DishSubgroup WHERE UniqueID = " & tempUniqueID
                drcDatarowCollection = objDB.GetDataRows(SQLQuery)
                If drcDatarowCollection IsNot Nothing Then
                    For Each myRow In drcDatarowCollection
                        lstSubgroups.Items.Add(myRow!TName, myRow!TName)
                    Next
                End If
            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub cmdSave_Click(sender As Object, e As EventArgs) Handles cmdSave.Click

        Try

            If ugSGDishes.Selected.Rows.Count > 1 Then
                Dim ugdTemp As Infragistics.Win.UltraWinGrid.UltraGrid = ugSGDishes

                For iCnt = 0 To lstSubgroups.Items.Count - 1
                    For jCnt = 0 To ugdTemp.Selected.Rows.Count - 1
                        strTypical = lstSubgroups.Items(iCnt).Text
                        tempUniqueID = ugdTemp.Selected.Rows(jCnt).Cells("UniqueID").Value
                        'see if this already exists there
                        SQLQuery = String.Format("SELECT * FROM DishSubgroup WHERE UniqueID = {0} AND TName = '{1}'", tempUniqueID, strTypical)
                        drcDatarowCollection = objDB.GetDataRows(SQLQuery)
                        If drcDatarowCollection.Count = 0 Then
                            'not there so insert it
                            SQLQuery = String.Format("INSERT INTO DishSubgroup (UniqueID, TName) VALUES ({0}, '{1}')", tempUniqueID, strTypical)
                            objDB.ExeNonQuery(SQLQuery)
                        End If
                    Next
                Next

            Else

                objDB.ExeNonQuery("DELETE FROM DishSubgroup WHERE UniqueID = " & tempUniqueID)
                For iCnt = 0 To lstSubgroups.Items.Count - 1
                    tempStr = lstSubgroups.Items(iCnt).Text
                    SQLQuery = String.Format("INSERT INTO DishSubgroup (UniqueID, TName) VALUES ({0}, '{1}')", tempUniqueID, tempStr)
                    objDB.ExeNonQuery(SQLQuery)
                Next

            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

        blnIsDirty = False
        Close()

    End Sub

    Private Sub cmdDelete_Click(sender As Object, e As EventArgs) Handles cmdDelete.Click

        If lstSubgroups.SelectedItems.Count = 0 Then Exit Sub

        For iCnt As Integer = lstSubgroups.SelectedItems.Count - 1 To 0 Step -1
            lstSubgroups.Items.Remove(lstSubgroups.SelectedItems(iCnt))
            blnIsDirty = True
        Next

        cmbSubgroups.Focus()

    End Sub

    Private Sub cmdAdd_Click(sender As Object, e As EventArgs) Handles cmdAdd.Click

        tempStr = cmbSubgroups.Text.Trim

        If tempStr <> "" Then

            'see its not in list already
            If IsInListbox(tempStr, lstSubgroups) = False Then
                lstSubgroups.Items.Add(tempStr, tempStr)
                cmbSubgroups.Focus()
                blnIsDirty = True
            Else
                strMsgBox = tempStr & " is already in the list."
                Alert(strMsgBox)
            End If

        End If

    End Sub

    Private Sub cmdCancel_Click(sender As Object, e As EventArgs) Handles cmdCancel.Click

        If blnIsDirty = True Then
            strMsgBox = "Any changes made have not been saved?" & vbCrLf & "Are you sure?"
            intMsgBoxResult = EZMsgBox.Show(strMsgBox, MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If intMsgBoxResult = MsgBoxResult.No Then
                Exit Sub
            End If
        End If

        Close()

    End Sub

    Private Sub cmdLabelAdd_Click(sender As Object, e As EventArgs) Handles cmdLabelAdd.Click

        strKBInput = EZFullKeyboard.Show()
        If strKBInput <> EZKBEscape Then
            lstLabelItems.Items.Add(strKBInput, strKBInput)
            SQLQuery = String.Format("INSERT INTO SetLabels (UniqueID, LabelName, PrintLabelOnOff) VALUES ({0}, '{1}', {2})",
                                     ugSGDishes.ActiveRow.Cells("UniqueID").Value, strKBInput, cmdTurnOffLabel.Tag)
            objDB.ExeNonQuery(SQLQuery)
        End If

    End Sub

    Private Sub cmdLabelRemove_Click(sender As Object, e As EventArgs) Handles cmdLabelRemove.Click

        If lstLabelItems.SelectedItems.Count = 0 Then Exit Sub

        For i As Integer = 0 To lstLabelItems.SelectedItems.Count - 1
            SQLQuery = String.Format("DELETE FROM SetLabels WHERE UniqueID = {0} AND LabelName = '{1}'",
                                     ugSGDishes.ActiveRow.Cells("UniqueID").Value, lstLabelItems.SelectedItems(i).Text)
            objDB.ExeNonQuery(SQLQuery)
        Next

        For i As Integer = lstLabelItems.SelectedItems.Count - 1 To 0 Step -1
            lstLabelItems.Items.Remove(lstLabelItems.SelectedItems(i))
        Next

    End Sub

    Private Sub cmdTurnOffLabel_Click(sender As Object, e As EventArgs) Handles cmdTurnOffLabel.Click

        Try

            tempStr = cmdTurnOffLabel.Text

            If tempStr.IndexOf("Enable") <> -1 Then
                cmdTurnOffLabel.Text = "Disable"
                lblStatus.Text = "Label printing is enabled for this item"
                SQLQuery = String.Format("UPDATE SetLabels SET PrintLabelOnOff = 1 WHERE UniqueID = {0}", ugSGDishes.ActiveRow.Cells("UniqueID").Value)
            Else
                cmdTurnOffLabel.Text = "Enable"
                lblStatus.Text = "Label printing is disabled for this item"
                SQLQuery = String.Format("UPDATE SetLabels SET PrintLabelOnOff = 0 WHERE UniqueID = {0}", ugSGDishes.ActiveRow.Cells("UniqueID").Value)
            End If

            objDB.ExeNonQuery(SQLQuery)

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    'Declare the variables
    Dim drag As Boolean
    Dim mousex As Integer
    Dim mousey As Integer

    Private Sub Form1_MouseDown(sender As Object, e As MouseEventArgs) Handles Me.MouseDown
        drag = True 'Sets the variable drag to true.
        mousex = Cursor.Position.X - Left 'Sets variable mousex
        mousey = Cursor.Position.Y - Top 'Sets variable mousey
    End Sub

    Private Sub Form1_MouseMove(sender As Object, e As MouseEventArgs) Handles Me.MouseMove
        'If drag is set to true then move the form accordingly.
        If drag Then
            Top = Cursor.Position.Y - mousey
            Left = Cursor.Position.X - mousex
        End If
    End Sub

    Private Sub Form1_MouseUp(sender As Object, e As MouseEventArgs) Handles Me.MouseUp
        drag = False 'Sets drag to false, so the form does not move according to the code in MouseMove
    End Sub

    Private Sub cmdClose_Click(sender As Object, e As EventArgs) Handles cmdClose.Click
        Close()
    End Sub

End Class