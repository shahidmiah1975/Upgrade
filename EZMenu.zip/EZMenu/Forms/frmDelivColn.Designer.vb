﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmDelivColn
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim Appearance1 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance2 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmDelivColn))
        Dim Appearance3 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance4 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance5 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance6 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance7 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance8 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance9 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance10 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance11 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance12 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance13 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance14 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance15 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance16 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance17 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance18 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance19 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance20 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance21 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance22 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance23 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance24 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance25 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance26 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance27 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance28 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance29 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance30 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance31 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance32 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance33 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance34 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance35 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance36 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance37 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance38 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance39 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance40 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance41 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance42 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance43 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance44 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance45 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance46 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance47 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance48 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance49 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance50 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance51 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance52 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance53 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance54 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance55 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance56 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance57 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance58 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance59 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance60 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance61 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance62 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance63 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance64 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance65 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance66 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance67 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Me.UltraLabel1 = New Infragistics.Win.Misc.UltraLabel()
        Me.cmdMap = New Infragistics.Win.Misc.UltraButton()
        Me.cmdPrevOrder = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDirections = New Infragistics.Win.Misc.UltraButton()
        Me.cmdShowKeyboard = New Infragistics.Win.Misc.UltraButton()
        Me.cmdNotes = New Infragistics.Win.Misc.UltraButton()
        Me.cmdHome = New Infragistics.Win.Misc.UltraButton()
        Me.cmdCustSearch = New Infragistics.Win.Misc.UltraButton()
        Me.cmdClearForm = New Infragistics.Win.Misc.UltraButton()
        Me.cmdCustSave = New Infragistics.Win.Misc.UltraButton()
        Me.cmdPCSearch = New Infragistics.Win.Misc.UltraButton()
        Me.cmdNextScreen = New Infragistics.Win.Misc.UltraButton()
        Me.upnlCustomerInfo = New Infragistics.Win.Misc.UltraPanel()
        Me.UltraLabel3 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel2 = New Infragistics.Win.Misc.UltraLabel()
        Me.cmdPickup = New Infragistics.Win.Misc.UltraButton()
        Me.lblNameLbl = New Infragistics.Win.Misc.UltraLabel()
        Me.cmdDelivery = New Infragistics.Win.Misc.UltraButton()
        Me.lblTelephoneLbl = New Infragistics.Win.Misc.UltraLabel()
        Me.lblPostcodeLbl = New Infragistics.Win.Misc.UltraLabel()
        Me.lblAddressLbl = New Infragistics.Win.Misc.UltraLabel()
        Me.txtName = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtTelephone = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtAddress1 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtPostcode = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtAddress2 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtMobile = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtAddress3 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txtEmail = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.ubtnAddressDown = New Infragistics.Win.Misc.UltraButton()
        Me.lblCustomerNote = New System.Windows.Forms.Label()
        Me.lblCustomerData = New System.Windows.Forms.Label()
        Me.cmdPhoneNotFound = New Infragistics.Win.Misc.UltraButton()
        Me.cmdBackScreen = New Infragistics.Win.Misc.UltraButton()
        Me.cmdPCPrev = New Infragistics.Win.Misc.UltraButton()
        Me.cmdPCNext = New Infragistics.Win.Misc.UltraButton()
        Me.uplAddressesMain = New Infragistics.Win.Misc.UltraPanel()
        Me.uplAddress = New Infragistics.Win.Misc.UltraPanel()
        Me.uflmAddress = New Infragistics.Win.Misc.UltraFlowLayoutManager(Me.components)
        Me.ezkbdDelivColn = New EZControls.EZKeyboard()
        Me.upnlCustomerInfo.ClientArea.SuspendLayout()
        Me.upnlCustomerInfo.SuspendLayout()
        CType(Me.txtName, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTelephone, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtAddress1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtPostcode, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtAddress2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtMobile, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtAddress3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtEmail, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.uplAddressesMain.ClientArea.SuspendLayout()
        Me.uplAddressesMain.SuspendLayout()
        Me.uplAddress.SuspendLayout()
        CType(Me.uflmAddress, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'UltraLabel1
        '
        Me.UltraLabel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance1.BorderColor = System.Drawing.Color.Silver
        Me.UltraLabel1.Appearance = Appearance1
        Me.UltraLabel1.BorderStyleInner = Infragistics.Win.UIElementBorderStyle.Solid
        Me.UltraLabel1.Location = New System.Drawing.Point(-1, 627)
        Me.UltraLabel1.Name = "UltraLabel1"
        Me.UltraLabel1.Size = New System.Drawing.Size(987, 1)
        Me.UltraLabel1.TabIndex = 549
        '
        'cmdMap
        '
        Me.cmdMap.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Appearance2.BackColor = System.Drawing.Color.Transparent
        Appearance2.BackColor2 = System.Drawing.Color.Transparent
        Appearance2.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance2.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance2.BorderColor = System.Drawing.Color.Transparent
        Appearance2.BorderColor2 = System.Drawing.Color.Maroon
        Appearance2.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance2.ForeColor = System.Drawing.Color.White
        Appearance2.Image = CType(resources.GetObject("Appearance2.Image"), Object)
        Appearance2.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance2.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance2.TextVAlignAsString = "Bottom"
        Me.cmdMap.Appearance = Appearance2
        Me.cmdMap.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdMap.Enabled = False
        Me.cmdMap.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance3.BackColor = System.Drawing.Color.DarkOrange
        Appearance3.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance3.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance3.BorderColor = System.Drawing.Color.Transparent
        Appearance3.ForeColor = System.Drawing.Color.Black
        Me.cmdMap.HotTrackAppearance = Appearance3
        Me.cmdMap.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdMap.Location = New System.Drawing.Point(565, 635)
        Me.cmdMap.Name = "cmdMap"
        Me.cmdMap.Padding = New System.Drawing.Size(15, 0)
        Appearance4.BackColor = System.Drawing.Color.OrangeRed
        Appearance4.BackColor2 = System.Drawing.Color.Tomato
        Appearance4.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance4.BorderColor = System.Drawing.Color.Transparent
        Me.cmdMap.PressedAppearance = Appearance4
        Me.cmdMap.ShowFocusRect = False
        Me.cmdMap.ShowOutline = False
        Me.cmdMap.Size = New System.Drawing.Size(64, 44)
        Me.cmdMap.StyleSetName = "StatusBar"
        Me.cmdMap.TabIndex = 565
        Me.cmdMap.Tag = "Map"
        Me.cmdMap.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdMap.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdMap.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdPrevOrder
        '
        Me.cmdPrevOrder.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Appearance5.BackColor = System.Drawing.Color.Transparent
        Appearance5.BackColor2 = System.Drawing.Color.Transparent
        Appearance5.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance5.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance5.BorderColor = System.Drawing.Color.Transparent
        Appearance5.BorderColor2 = System.Drawing.Color.Maroon
        Appearance5.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance5.ForeColor = System.Drawing.Color.White
        Appearance5.Image = CType(resources.GetObject("Appearance5.Image"), Object)
        Appearance5.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance5.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance5.TextVAlignAsString = "Bottom"
        Me.cmdPrevOrder.Appearance = Appearance5
        Me.cmdPrevOrder.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdPrevOrder.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance6.BackColor = System.Drawing.Color.DarkOrange
        Appearance6.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance6.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance6.BorderColor = System.Drawing.Color.Transparent
        Appearance6.ForeColor = System.Drawing.Color.Black
        Me.cmdPrevOrder.HotTrackAppearance = Appearance6
        Me.cmdPrevOrder.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdPrevOrder.Location = New System.Drawing.Point(705, 635)
        Me.cmdPrevOrder.Name = "cmdPrevOrder"
        Me.cmdPrevOrder.Padding = New System.Drawing.Size(15, 0)
        Appearance7.BackColor = System.Drawing.Color.OrangeRed
        Appearance7.BackColor2 = System.Drawing.Color.Tomato
        Appearance7.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance7.BorderColor = System.Drawing.Color.Transparent
        Me.cmdPrevOrder.PressedAppearance = Appearance7
        Me.cmdPrevOrder.ShowFocusRect = False
        Me.cmdPrevOrder.ShowOutline = False
        Me.cmdPrevOrder.Size = New System.Drawing.Size(64, 44)
        Me.cmdPrevOrder.StyleSetName = "StatusBar"
        Me.cmdPrevOrder.TabIndex = 564
        Me.cmdPrevOrder.Tag = "Past order"
        Me.cmdPrevOrder.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPrevOrder.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPrevOrder.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDirections
        '
        Me.cmdDirections.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Appearance8.BackColor = System.Drawing.Color.Transparent
        Appearance8.BackColor2 = System.Drawing.Color.Transparent
        Appearance8.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance8.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance8.BorderColor = System.Drawing.Color.Transparent
        Appearance8.BorderColor2 = System.Drawing.Color.Maroon
        Appearance8.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance8.ForeColor = System.Drawing.Color.White
        Appearance8.Image = CType(resources.GetObject("Appearance8.Image"), Object)
        Appearance8.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance8.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance8.TextVAlignAsString = "Bottom"
        Me.cmdDirections.Appearance = Appearance8
        Me.cmdDirections.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdDirections.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance9.BackColor = System.Drawing.Color.DarkOrange
        Appearance9.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance9.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance9.BorderColor = System.Drawing.Color.Transparent
        Appearance9.ForeColor = System.Drawing.Color.Black
        Me.cmdDirections.HotTrackAppearance = Appearance9
        Me.cmdDirections.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdDirections.Location = New System.Drawing.Point(635, 635)
        Me.cmdDirections.Name = "cmdDirections"
        Me.cmdDirections.Padding = New System.Drawing.Size(15, 0)
        Appearance10.BackColor = System.Drawing.Color.OrangeRed
        Appearance10.BackColor2 = System.Drawing.Color.Tomato
        Appearance10.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance10.BorderColor = System.Drawing.Color.Transparent
        Me.cmdDirections.PressedAppearance = Appearance10
        Me.cmdDirections.ShowFocusRect = False
        Me.cmdDirections.ShowOutline = False
        Me.cmdDirections.Size = New System.Drawing.Size(64, 44)
        Me.cmdDirections.StyleSetName = "StatusBar"
        Me.cmdDirections.TabIndex = 563
        Me.cmdDirections.Tag = "Directions"
        Me.cmdDirections.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDirections.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDirections.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdShowKeyboard
        '
        Me.cmdShowKeyboard.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Appearance11.BackColor = System.Drawing.Color.Transparent
        Appearance11.BackColor2 = System.Drawing.Color.Transparent
        Appearance11.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance11.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance11.BorderColor = System.Drawing.Color.Transparent
        Appearance11.BorderColor2 = System.Drawing.Color.Maroon
        Appearance11.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance11.ForeColor = System.Drawing.Color.White
        Appearance11.Image = CType(resources.GetObject("Appearance11.Image"), Object)
        Appearance11.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance11.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance11.TextVAlignAsString = "Bottom"
        Me.cmdShowKeyboard.Appearance = Appearance11
        Me.cmdShowKeyboard.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdShowKeyboard.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance12.BackColor = System.Drawing.Color.DarkOrange
        Appearance12.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance12.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance12.BorderColor = System.Drawing.Color.Transparent
        Appearance12.ForeColor = System.Drawing.Color.Black
        Me.cmdShowKeyboard.HotTrackAppearance = Appearance12
        Me.cmdShowKeyboard.ImageSize = New System.Drawing.Size(32, 25)
        Me.cmdShowKeyboard.Location = New System.Drawing.Point(495, 635)
        Me.cmdShowKeyboard.Name = "cmdShowKeyboard"
        Me.cmdShowKeyboard.Padding = New System.Drawing.Size(15, 0)
        Appearance13.BackColor = System.Drawing.Color.OrangeRed
        Appearance13.BackColor2 = System.Drawing.Color.Tomato
        Appearance13.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance13.BorderColor = System.Drawing.Color.Transparent
        Me.cmdShowKeyboard.PressedAppearance = Appearance13
        Me.cmdShowKeyboard.ShowFocusRect = False
        Me.cmdShowKeyboard.ShowOutline = False
        Me.cmdShowKeyboard.Size = New System.Drawing.Size(64, 44)
        Me.cmdShowKeyboard.StyleSetName = "StatusBar"
        Me.cmdShowKeyboard.TabIndex = 561
        Me.cmdShowKeyboard.Tag = "Keyboard"
        Me.cmdShowKeyboard.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdShowKeyboard.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdShowKeyboard.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdNotes
        '
        Me.cmdNotes.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Appearance14.BackColor = System.Drawing.Color.Transparent
        Appearance14.BackColor2 = System.Drawing.Color.Transparent
        Appearance14.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance14.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance14.BorderColor = System.Drawing.Color.Transparent
        Appearance14.BorderColor2 = System.Drawing.Color.Maroon
        Appearance14.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance14.ForeColor = System.Drawing.Color.White
        Appearance14.Image = CType(resources.GetObject("Appearance14.Image"), Object)
        Appearance14.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance14.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance14.TextVAlignAsString = "Bottom"
        Me.cmdNotes.Appearance = Appearance14
        Me.cmdNotes.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdNotes.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance15.BackColor = System.Drawing.Color.DarkOrange
        Appearance15.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance15.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance15.BorderColor = System.Drawing.Color.Transparent
        Appearance15.ForeColor = System.Drawing.Color.Black
        Me.cmdNotes.HotTrackAppearance = Appearance15
        Me.cmdNotes.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdNotes.Location = New System.Drawing.Point(425, 635)
        Me.cmdNotes.Name = "cmdNotes"
        Me.cmdNotes.Padding = New System.Drawing.Size(15, 0)
        Appearance16.BackColor = System.Drawing.Color.OrangeRed
        Appearance16.BackColor2 = System.Drawing.Color.Tomato
        Appearance16.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance16.BorderColor = System.Drawing.Color.Transparent
        Me.cmdNotes.PressedAppearance = Appearance16
        Me.cmdNotes.ShowFocusRect = False
        Me.cmdNotes.ShowOutline = False
        Me.cmdNotes.Size = New System.Drawing.Size(64, 44)
        Me.cmdNotes.StyleSetName = "StatusBar"
        Me.cmdNotes.TabIndex = 560
        Me.cmdNotes.Tag = "Notes"
        Me.cmdNotes.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdNotes.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdNotes.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdHome
        '
        Me.cmdHome.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Appearance17.BackColor = System.Drawing.Color.Transparent
        Appearance17.BackColor2 = System.Drawing.Color.Transparent
        Appearance17.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance17.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance17.BorderColor = System.Drawing.Color.Transparent
        Appearance17.BorderColor2 = System.Drawing.Color.Maroon
        Appearance17.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance17.ForeColor = System.Drawing.Color.White
        Appearance17.Image = CType(resources.GetObject("Appearance17.Image"), Object)
        Appearance17.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance17.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance17.TextVAlignAsString = "Bottom"
        Me.cmdHome.Appearance = Appearance17
        Me.cmdHome.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdHome.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance18.BackColor = System.Drawing.Color.DarkOrange
        Appearance18.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance18.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance18.BorderColor = System.Drawing.Color.Transparent
        Appearance18.ForeColor = System.Drawing.Color.Black
        Me.cmdHome.HotTrackAppearance = Appearance18
        Me.cmdHome.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdHome.Location = New System.Drawing.Point(775, 635)
        Me.cmdHome.Name = "cmdHome"
        Me.cmdHome.Padding = New System.Drawing.Size(15, 0)
        Appearance19.BackColor = System.Drawing.Color.OrangeRed
        Appearance19.BackColor2 = System.Drawing.Color.Tomato
        Appearance19.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance19.BorderColor = System.Drawing.Color.Transparent
        Me.cmdHome.PressedAppearance = Appearance19
        Me.cmdHome.ShowFocusRect = False
        Me.cmdHome.ShowOutline = False
        Me.cmdHome.Size = New System.Drawing.Size(64, 44)
        Me.cmdHome.StyleSetName = "StatusBar"
        Me.cmdHome.TabIndex = 558
        Me.cmdHome.Tag = "Return"
        Me.cmdHome.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdHome.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdHome.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdCustSearch
        '
        Me.cmdCustSearch.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Appearance20.BackColor = System.Drawing.Color.Transparent
        Appearance20.BackColor2 = System.Drawing.Color.Transparent
        Appearance20.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance20.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance20.BorderColor = System.Drawing.Color.Transparent
        Appearance20.BorderColor2 = System.Drawing.Color.Maroon
        Appearance20.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance20.ForeColor = System.Drawing.Color.White
        Appearance20.Image = CType(resources.GetObject("Appearance20.Image"), Object)
        Appearance20.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance20.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance20.TextVAlignAsString = "Bottom"
        Me.cmdCustSearch.Appearance = Appearance20
        Me.cmdCustSearch.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdCustSearch.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance21.BackColor = System.Drawing.Color.DarkOrange
        Appearance21.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance21.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance21.BorderColor = System.Drawing.Color.Transparent
        Appearance21.ForeColor = System.Drawing.Color.Black
        Me.cmdCustSearch.HotTrackAppearance = Appearance21
        Me.cmdCustSearch.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdCustSearch.Location = New System.Drawing.Point(145, 635)
        Me.cmdCustSearch.Name = "cmdCustSearch"
        Me.cmdCustSearch.Padding = New System.Drawing.Size(15, 0)
        Appearance22.BackColor = System.Drawing.Color.OrangeRed
        Appearance22.BackColor2 = System.Drawing.Color.Tomato
        Appearance22.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance22.BorderColor = System.Drawing.Color.Transparent
        Me.cmdCustSearch.PressedAppearance = Appearance22
        Me.cmdCustSearch.ShowFocusRect = False
        Me.cmdCustSearch.ShowOutline = False
        Me.cmdCustSearch.Size = New System.Drawing.Size(64, 44)
        Me.cmdCustSearch.StyleSetName = "StatusBar"
        Me.cmdCustSearch.TabIndex = 557
        Me.cmdCustSearch.Tag = "Phone"
        Me.cmdCustSearch.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdCustSearch.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdCustSearch.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdClearForm
        '
        Me.cmdClearForm.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Appearance23.BackColor = System.Drawing.Color.Transparent
        Appearance23.BackColor2 = System.Drawing.Color.Transparent
        Appearance23.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance23.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance23.BorderColor = System.Drawing.Color.Transparent
        Appearance23.BorderColor2 = System.Drawing.Color.Maroon
        Appearance23.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance23.ForeColor = System.Drawing.Color.White
        Appearance23.Image = CType(resources.GetObject("Appearance23.Image"), Object)
        Appearance23.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance23.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance23.TextVAlignAsString = "Bottom"
        Me.cmdClearForm.Appearance = Appearance23
        Me.cmdClearForm.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdClearForm.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance24.BackColor = System.Drawing.Color.DarkOrange
        Appearance24.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance24.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance24.BorderColor = System.Drawing.Color.Transparent
        Appearance24.ForeColor = System.Drawing.Color.Black
        Me.cmdClearForm.HotTrackAppearance = Appearance24
        Me.cmdClearForm.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdClearForm.Location = New System.Drawing.Point(355, 635)
        Me.cmdClearForm.Name = "cmdClearForm"
        Me.cmdClearForm.Padding = New System.Drawing.Size(15, 0)
        Appearance25.BackColor = System.Drawing.Color.OrangeRed
        Appearance25.BackColor2 = System.Drawing.Color.Tomato
        Appearance25.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance25.BorderColor = System.Drawing.Color.Transparent
        Me.cmdClearForm.PressedAppearance = Appearance25
        Me.cmdClearForm.ShowFocusRect = False
        Me.cmdClearForm.ShowOutline = False
        Me.cmdClearForm.Size = New System.Drawing.Size(64, 44)
        Me.cmdClearForm.StyleSetName = "StatusBar"
        Me.cmdClearForm.TabIndex = 556
        Me.cmdClearForm.Tag = "Clear"
        Me.cmdClearForm.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdClearForm.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdClearForm.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdCustSave
        '
        Me.cmdCustSave.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Appearance26.BackColor = System.Drawing.Color.Transparent
        Appearance26.BackColor2 = System.Drawing.Color.Transparent
        Appearance26.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance26.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance26.BorderColor = System.Drawing.Color.Transparent
        Appearance26.BorderColor2 = System.Drawing.Color.Maroon
        Appearance26.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance26.ForeColor = System.Drawing.Color.White
        Appearance26.Image = CType(resources.GetObject("Appearance26.Image"), Object)
        Appearance26.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance26.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance26.TextVAlignAsString = "Bottom"
        Me.cmdCustSave.Appearance = Appearance26
        Me.cmdCustSave.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdCustSave.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance27.BackColor = System.Drawing.Color.DarkOrange
        Appearance27.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance27.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance27.BorderColor = System.Drawing.Color.Transparent
        Appearance27.ForeColor = System.Drawing.Color.Black
        Me.cmdCustSave.HotTrackAppearance = Appearance27
        Me.cmdCustSave.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdCustSave.Location = New System.Drawing.Point(285, 635)
        Me.cmdCustSave.Name = "cmdCustSave"
        Me.cmdCustSave.Padding = New System.Drawing.Size(15, 0)
        Appearance28.BackColor = System.Drawing.Color.OrangeRed
        Appearance28.BackColor2 = System.Drawing.Color.Tomato
        Appearance28.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance28.BorderColor = System.Drawing.Color.Transparent
        Me.cmdCustSave.PressedAppearance = Appearance28
        Me.cmdCustSave.ShowFocusRect = False
        Me.cmdCustSave.ShowOutline = False
        Me.cmdCustSave.Size = New System.Drawing.Size(64, 44)
        Me.cmdCustSave.StyleSetName = "StatusBar"
        Me.cmdCustSave.TabIndex = 555
        Me.cmdCustSave.Tag = "Save"
        Me.cmdCustSave.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdCustSave.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdCustSave.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdPCSearch
        '
        Me.cmdPCSearch.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Appearance29.BackColor = System.Drawing.Color.Transparent
        Appearance29.BackColor2 = System.Drawing.Color.Transparent
        Appearance29.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance29.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance29.BorderColor = System.Drawing.Color.Transparent
        Appearance29.BorderColor2 = System.Drawing.Color.Maroon
        Appearance29.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance29.ForeColor = System.Drawing.Color.White
        Appearance29.Image = CType(resources.GetObject("Appearance29.Image"), Object)
        Appearance29.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance29.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance29.TextVAlignAsString = "Bottom"
        Me.cmdPCSearch.Appearance = Appearance29
        Me.cmdPCSearch.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdPCSearch.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance30.BackColor = System.Drawing.Color.DarkOrange
        Appearance30.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance30.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance30.BorderColor = System.Drawing.Color.Transparent
        Appearance30.ForeColor = System.Drawing.Color.Black
        Me.cmdPCSearch.HotTrackAppearance = Appearance30
        Me.cmdPCSearch.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdPCSearch.Location = New System.Drawing.Point(215, 635)
        Me.cmdPCSearch.Name = "cmdPCSearch"
        Me.cmdPCSearch.Padding = New System.Drawing.Size(15, 0)
        Appearance31.BackColor = System.Drawing.Color.OrangeRed
        Appearance31.BackColor2 = System.Drawing.Color.Tomato
        Appearance31.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance31.BorderColor = System.Drawing.Color.Transparent
        Me.cmdPCSearch.PressedAppearance = Appearance31
        Me.cmdPCSearch.ShowFocusRect = False
        Me.cmdPCSearch.ShowOutline = False
        Me.cmdPCSearch.Size = New System.Drawing.Size(64, 44)
        Me.cmdPCSearch.StyleSetName = "StatusBar"
        Me.cmdPCSearch.TabIndex = 554
        Me.cmdPCSearch.Tag = "Search"
        Me.cmdPCSearch.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPCSearch.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPCSearch.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdNextScreen
        '
        Me.cmdNextScreen.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance32.BackColor = System.Drawing.Color.Transparent
        Appearance32.BackColor2 = System.Drawing.Color.Transparent
        Appearance32.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance32.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance32.BorderColor = System.Drawing.Color.Transparent
        Appearance32.BorderColor2 = System.Drawing.Color.Maroon
        Appearance32.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance32.ForeColor = System.Drawing.Color.Black
        Appearance32.Image = CType(resources.GetObject("Appearance32.Image"), Object)
        Appearance32.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance32.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance32.TextVAlignAsString = "Bottom"
        Me.cmdNextScreen.Appearance = Appearance32
        Me.cmdNextScreen.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdNextScreen.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance33.BackColor = System.Drawing.Color.DarkOrange
        Appearance33.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance33.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance33.BorderColor = System.Drawing.Color.Transparent
        Appearance33.ForeColor = System.Drawing.Color.Black
        Me.cmdNextScreen.HotTrackAppearance = Appearance33
        Me.cmdNextScreen.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdNextScreen.Location = New System.Drawing.Point(908, 635)
        Me.cmdNextScreen.Name = "cmdNextScreen"
        Me.cmdNextScreen.Padding = New System.Drawing.Size(15, 0)
        Appearance34.BackColor = System.Drawing.Color.OrangeRed
        Appearance34.BackColor2 = System.Drawing.Color.Tomato
        Appearance34.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance34.BorderColor = System.Drawing.Color.Transparent
        Me.cmdNextScreen.PressedAppearance = Appearance34
        Me.cmdNextScreen.ShowFocusRect = False
        Me.cmdNextScreen.ShowOutline = False
        Me.cmdNextScreen.Size = New System.Drawing.Size(64, 44)
        Me.cmdNextScreen.StyleSetName = "StatusBar"
        Me.cmdNextScreen.TabIndex = 553
        Me.cmdNextScreen.Tag = "Down"
        Me.cmdNextScreen.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdNextScreen.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdNextScreen.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'upnlCustomerInfo
        '
        Me.upnlCustomerInfo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance35.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Appearance35.BorderColor = System.Drawing.Color.FromArgb(CType(CType(222, Byte), Integer), CType(CType(222, Byte), Integer), CType(CType(222, Byte), Integer))
        Me.upnlCustomerInfo.Appearance = Appearance35
        '
        'upnlCustomerInfo.ClientArea
        '
        Me.upnlCustomerInfo.ClientArea.Controls.Add(Me.UltraLabel3)
        Me.upnlCustomerInfo.ClientArea.Controls.Add(Me.UltraLabel2)
        Me.upnlCustomerInfo.ClientArea.Controls.Add(Me.cmdPickup)
        Me.upnlCustomerInfo.ClientArea.Controls.Add(Me.lblNameLbl)
        Me.upnlCustomerInfo.ClientArea.Controls.Add(Me.cmdDelivery)
        Me.upnlCustomerInfo.ClientArea.Controls.Add(Me.lblTelephoneLbl)
        Me.upnlCustomerInfo.ClientArea.Controls.Add(Me.lblPostcodeLbl)
        Me.upnlCustomerInfo.ClientArea.Controls.Add(Me.lblAddressLbl)
        Me.upnlCustomerInfo.ClientArea.Controls.Add(Me.txtName)
        Me.upnlCustomerInfo.ClientArea.Controls.Add(Me.txtTelephone)
        Me.upnlCustomerInfo.ClientArea.Controls.Add(Me.txtAddress1)
        Me.upnlCustomerInfo.ClientArea.Controls.Add(Me.txtPostcode)
        Me.upnlCustomerInfo.ClientArea.Controls.Add(Me.txtAddress2)
        Me.upnlCustomerInfo.ClientArea.Controls.Add(Me.txtMobile)
        Me.upnlCustomerInfo.ClientArea.Controls.Add(Me.txtAddress3)
        Me.upnlCustomerInfo.ClientArea.Controls.Add(Me.txtEmail)
        Me.upnlCustomerInfo.ClientArea.Controls.Add(Me.ubtnAddressDown)
        Me.upnlCustomerInfo.ClientArea.Controls.Add(Me.lblCustomerNote)
        Me.upnlCustomerInfo.ClientArea.Controls.Add(Me.lblCustomerData)
        Me.upnlCustomerInfo.ClientArea.Controls.Add(Me.cmdPhoneNotFound)
        Me.upnlCustomerInfo.Location = New System.Drawing.Point(0, 0)
        Me.upnlCustomerInfo.Name = "upnlCustomerInfo"
        Me.upnlCustomerInfo.Size = New System.Drawing.Size(984, 232)
        Me.upnlCustomerInfo.TabIndex = 551
        '
        'UltraLabel3
        '
        Appearance36.BackColor = System.Drawing.Color.Transparent
        Appearance36.ForeColor = System.Drawing.Color.DimGray
        Appearance36.TextHAlignAsString = "Right"
        Me.UltraLabel3.Appearance = Appearance36
        Me.UltraLabel3.AutoSize = True
        Me.UltraLabel3.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UltraLabel3.Location = New System.Drawing.Point(558, 59)
        Me.UltraLabel3.Name = "UltraLabel3"
        Me.UltraLabel3.Size = New System.Drawing.Size(59, 20)
        Me.UltraLabel3.StyleSetName = "TextEntryLabel"
        Me.UltraLabel3.TabIndex = 532
        Me.UltraLabel3.Text = "Mobile:"
        Me.UltraLabel3.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraLabel2
        '
        Appearance37.BackColor = System.Drawing.Color.Transparent
        Appearance37.ForeColor = System.Drawing.Color.DimGray
        Appearance37.TextHAlignAsString = "Right"
        Me.UltraLabel2.Appearance = Appearance37
        Me.UltraLabel2.AutoSize = True
        Me.UltraLabel2.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UltraLabel2.Location = New System.Drawing.Point(567, 29)
        Me.UltraLabel2.Name = "UltraLabel2"
        Me.UltraLabel2.Size = New System.Drawing.Size(50, 20)
        Me.UltraLabel2.StyleSetName = "TextEntryLabel"
        Me.UltraLabel2.TabIndex = 531
        Me.UltraLabel2.Text = "email:"
        Me.UltraLabel2.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdPickup
        '
        Appearance38.BackColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Appearance38.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance38.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance38.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance38.ForeColor = System.Drawing.Color.DimGray
        Appearance38.Image = CType(resources.GetObject("Appearance38.Image"), Object)
        Appearance38.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance38.ImageVAlign = Infragistics.Win.VAlign.Middle
        Me.cmdPickup.Appearance = Appearance38
        Me.cmdPickup.Font = New System.Drawing.Font("Gabriola", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdPickup.ImageSize = New System.Drawing.Size(42, 54)
        Me.cmdPickup.Location = New System.Drawing.Point(19, 126)
        Me.cmdPickup.Margin = New System.Windows.Forms.Padding(10)
        Me.cmdPickup.Name = "cmdPickup"
        Me.cmdPickup.ShowFocusRect = False
        Me.cmdPickup.ShowOutline = False
        Me.cmdPickup.Size = New System.Drawing.Size(75, 69)
        Me.cmdPickup.StyleSetName = "BigButton"
        Me.cmdPickup.TabIndex = 573
        Me.cmdPickup.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPickup.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPickup.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblNameLbl
        '
        Appearance39.BackColor = System.Drawing.Color.Transparent
        Appearance39.ForeColor = System.Drawing.Color.DimGray
        Appearance39.TextHAlignAsString = "Right"
        Me.lblNameLbl.Appearance = Appearance39
        Me.lblNameLbl.AutoSize = True
        Me.lblNameLbl.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNameLbl.Location = New System.Drawing.Point(147, 29)
        Me.lblNameLbl.Name = "lblNameLbl"
        Me.lblNameLbl.Size = New System.Drawing.Size(54, 20)
        Me.lblNameLbl.StyleSetName = "TextEntryLabel"
        Me.lblNameLbl.TabIndex = 530
        Me.lblNameLbl.Text = "Name:"
        Me.lblNameLbl.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDelivery
        '
        Appearance40.BackColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Appearance40.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance40.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance40.BorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance40.ForeColor = System.Drawing.Color.DimGray
        Appearance40.Image = CType(resources.GetObject("Appearance40.Image"), Object)
        Appearance40.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance40.ImageVAlign = Infragistics.Win.VAlign.Middle
        Me.cmdDelivery.Appearance = Appearance40
        Me.cmdDelivery.Font = New System.Drawing.Font("Gabriola", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdDelivery.ImageSize = New System.Drawing.Size(48, 48)
        Me.cmdDelivery.Location = New System.Drawing.Point(19, 37)
        Me.cmdDelivery.Margin = New System.Windows.Forms.Padding(10)
        Me.cmdDelivery.Name = "cmdDelivery"
        Me.cmdDelivery.ShowFocusRect = False
        Me.cmdDelivery.ShowOutline = False
        Me.cmdDelivery.Size = New System.Drawing.Size(75, 69)
        Me.cmdDelivery.StyleSetName = "BigButton"
        Me.cmdDelivery.TabIndex = 572
        Me.cmdDelivery.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDelivery.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblTelephoneLbl
        '
        Appearance41.BackColor = System.Drawing.Color.Transparent
        Appearance41.ForeColor = System.Drawing.Color.DimGray
        Appearance41.TextHAlignAsString = "Right"
        Me.lblTelephoneLbl.Appearance = Appearance41
        Me.lblTelephoneLbl.AutoSize = True
        Me.lblTelephoneLbl.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTelephoneLbl.Location = New System.Drawing.Point(113, 179)
        Me.lblTelephoneLbl.Name = "lblTelephoneLbl"
        Me.lblTelephoneLbl.Size = New System.Drawing.Size(88, 20)
        Me.lblTelephoneLbl.StyleSetName = "TextEntryLabel"
        Me.lblTelephoneLbl.TabIndex = 529
        Me.lblTelephoneLbl.Text = "Telephone:"
        Me.lblTelephoneLbl.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblPostcodeLbl
        '
        Appearance42.BackColor = System.Drawing.Color.Transparent
        Appearance42.ForeColor = System.Drawing.Color.DimGray
        Appearance42.TextHAlignAsString = "Right"
        Me.lblPostcodeLbl.Appearance = Appearance42
        Me.lblPostcodeLbl.AutoSize = True
        Me.lblPostcodeLbl.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPostcodeLbl.Location = New System.Drawing.Point(122, 149)
        Me.lblPostcodeLbl.Name = "lblPostcodeLbl"
        Me.lblPostcodeLbl.Size = New System.Drawing.Size(79, 20)
        Me.lblPostcodeLbl.StyleSetName = "TextEntryLabel"
        Me.lblPostcodeLbl.TabIndex = 528
        Me.lblPostcodeLbl.Text = "Postcode:"
        Me.lblPostcodeLbl.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblAddressLbl
        '
        Appearance43.BackColor = System.Drawing.Color.Transparent
        Appearance43.ForeColor = System.Drawing.Color.DimGray
        Appearance43.TextHAlignAsString = "Right"
        Me.lblAddressLbl.Appearance = Appearance43
        Me.lblAddressLbl.AutoSize = True
        Me.lblAddressLbl.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAddressLbl.Location = New System.Drawing.Point(130, 59)
        Me.lblAddressLbl.Name = "lblAddressLbl"
        Me.lblAddressLbl.Size = New System.Drawing.Size(71, 20)
        Me.lblAddressLbl.StyleSetName = "TextEntryLabel"
        Me.lblAddressLbl.TabIndex = 527
        Me.lblAddressLbl.Text = "Address:"
        Me.lblAddressLbl.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtName
        '
        Appearance44.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance44.BorderColor = System.Drawing.Color.LightGray
        Appearance44.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Me.txtName.Appearance = Appearance44
        Me.txtName.AutoSize = False
        Me.txtName.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtName.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtName.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName.Location = New System.Drawing.Point(207, 24)
        Me.txtName.MaxLength = 50
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(278, 28)
        Me.txtName.StyleSetName = "TextEntry"
        Me.txtName.TabIndex = 519
        Me.txtName.UseAppStyling = False
        Me.txtName.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtName.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtTelephone
        '
        Appearance45.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance45.BorderColor = System.Drawing.Color.LightGray
        Appearance45.BorderColor2 = System.Drawing.Color.Yellow
        Appearance45.BorderColor3DBase = System.Drawing.Color.Teal
        Appearance45.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Me.txtTelephone.Appearance = Appearance45
        Me.txtTelephone.AutoSize = False
        Me.txtTelephone.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtTelephone.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtTelephone.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTelephone.Location = New System.Drawing.Point(207, 174)
        Me.txtTelephone.MaxLength = 15
        Me.txtTelephone.Name = "txtTelephone"
        Me.txtTelephone.Size = New System.Drawing.Size(224, 28)
        Me.txtTelephone.StyleSetName = "TextEntry"
        Me.txtTelephone.TabIndex = 526
        Me.txtTelephone.UseAppStyling = False
        Me.txtTelephone.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtTelephone.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtAddress1
        '
        Appearance46.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance46.BorderColor = System.Drawing.Color.LightGray
        Appearance46.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Me.txtAddress1.Appearance = Appearance46
        Me.txtAddress1.AutoSize = False
        Me.txtAddress1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtAddress1.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtAddress1.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAddress1.Location = New System.Drawing.Point(207, 54)
        Me.txtAddress1.MaxLength = 50
        Me.txtAddress1.Name = "txtAddress1"
        Me.txtAddress1.Size = New System.Drawing.Size(278, 28)
        Me.txtAddress1.StyleSetName = "TextEntry"
        Me.txtAddress1.TabIndex = 520
        Me.txtAddress1.UseAppStyling = False
        Me.txtAddress1.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtAddress1.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtPostcode
        '
        Appearance47.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance47.BorderColor = System.Drawing.Color.LightGray
        Appearance47.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Me.txtPostcode.Appearance = Appearance47
        Me.txtPostcode.AutoSize = False
        Me.txtPostcode.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtPostcode.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtPostcode.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPostcode.Location = New System.Drawing.Point(207, 144)
        Me.txtPostcode.MaxLength = 10
        Me.txtPostcode.Name = "txtPostcode"
        Me.txtPostcode.Size = New System.Drawing.Size(137, 28)
        Me.txtPostcode.StyleSetName = "TextEntry"
        Me.txtPostcode.TabIndex = 525
        Me.txtPostcode.UseAppStyling = False
        Me.txtPostcode.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtPostcode.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtAddress2
        '
        Appearance48.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance48.BorderColor = System.Drawing.Color.LightGray
        Appearance48.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Me.txtAddress2.Appearance = Appearance48
        Me.txtAddress2.AutoSize = False
        Me.txtAddress2.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtAddress2.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtAddress2.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAddress2.Location = New System.Drawing.Point(207, 84)
        Me.txtAddress2.MaxLength = 50
        Me.txtAddress2.Name = "txtAddress2"
        Me.txtAddress2.Size = New System.Drawing.Size(278, 28)
        Me.txtAddress2.StyleSetName = "TextEntry"
        Me.txtAddress2.TabIndex = 521
        Me.txtAddress2.UseAppStyling = False
        Me.txtAddress2.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtAddress2.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtMobile
        '
        Appearance49.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance49.BorderColor = System.Drawing.Color.LightGray
        Appearance49.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Me.txtMobile.Appearance = Appearance49
        Me.txtMobile.AutoSize = False
        Me.txtMobile.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtMobile.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtMobile.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMobile.Location = New System.Drawing.Point(623, 54)
        Me.txtMobile.MaxLength = 15
        Me.txtMobile.Name = "txtMobile"
        Me.txtMobile.Size = New System.Drawing.Size(330, 28)
        Me.txtMobile.StyleSetName = "TextEntry"
        Me.txtMobile.TabIndex = 524
        Me.txtMobile.UseAppStyling = False
        Me.txtMobile.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtMobile.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtAddress3
        '
        Appearance50.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance50.BorderColor = System.Drawing.Color.LightGray
        Appearance50.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Me.txtAddress3.Appearance = Appearance50
        Me.txtAddress3.AutoSize = False
        Me.txtAddress3.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtAddress3.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtAddress3.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAddress3.Location = New System.Drawing.Point(207, 114)
        Me.txtAddress3.MaxLength = 50
        Me.txtAddress3.Name = "txtAddress3"
        Me.txtAddress3.Size = New System.Drawing.Size(278, 28)
        Me.txtAddress3.StyleSetName = "TextEntry"
        Me.txtAddress3.TabIndex = 522
        Me.txtAddress3.UseAppStyling = False
        Me.txtAddress3.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtAddress3.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtEmail
        '
        Appearance51.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance51.BorderColor = System.Drawing.Color.LightGray
        Appearance51.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Me.txtEmail.Appearance = Appearance51
        Me.txtEmail.AutoSize = False
        Me.txtEmail.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtEmail.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtEmail.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEmail.Location = New System.Drawing.Point(623, 24)
        Me.txtEmail.MaxLength = 50
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(330, 28)
        Me.txtEmail.StyleSetName = "TextEntry"
        Me.txtEmail.TabIndex = 523
        Me.txtEmail.UseAppStyling = False
        Me.txtEmail.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtEmail.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnAddressDown
        '
        Appearance52.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(120, Byte), Integer), CType(CType(180, Byte), Integer))
        Appearance52.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(120, Byte), Integer), CType(CType(180, Byte), Integer))
        Appearance52.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance52.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance52.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance52.BorderColor2 = System.Drawing.Color.Maroon
        Appearance52.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance52.ForeColor = System.Drawing.Color.White
        Appearance52.Image = CType(resources.GetObject("Appearance52.Image"), Object)
        Appearance52.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance52.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance52.TextVAlignAsString = "Middle"
        Me.ubtnAddressDown.Appearance = Appearance52
        Me.ubtnAddressDown.Font = New System.Drawing.Font("Calibri", 20.0!)
        Appearance53.BackColor = System.Drawing.Color.DarkOrange
        Appearance53.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance53.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance53.ForeColor = System.Drawing.Color.Black
        Me.ubtnAddressDown.HotTrackAppearance = Appearance53
        Me.ubtnAddressDown.ImageSize = New System.Drawing.Size(16, 26)
        Me.ubtnAddressDown.Location = New System.Drawing.Point(491, 52)
        Me.ubtnAddressDown.Name = "ubtnAddressDown"
        Appearance54.BackColor = System.Drawing.Color.OrangeRed
        Appearance54.BackColor2 = System.Drawing.Color.Tomato
        Appearance54.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnAddressDown.PressedAppearance = Appearance54
        Me.ubtnAddressDown.ShowFocusRect = False
        Me.ubtnAddressDown.ShowOutline = False
        Me.ubtnAddressDown.Size = New System.Drawing.Size(40, 31)
        Me.ubtnAddressDown.TabIndex = 506
        Me.ubtnAddressDown.Tag = ""
        Me.ubtnAddressDown.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnAddressDown.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnAddressDown.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        Me.ubtnAddressDown.Visible = False
        '
        'lblCustomerNote
        '
        Me.lblCustomerNote.BackColor = System.Drawing.Color.Transparent
        Me.lblCustomerNote.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCustomerNote.ForeColor = System.Drawing.Color.Brown
        Me.lblCustomerNote.Location = New System.Drawing.Point(626, 149)
        Me.lblCustomerNote.Name = "lblCustomerNote"
        Me.lblCustomerNote.Size = New System.Drawing.Size(327, 72)
        Me.lblCustomerNote.TabIndex = 499
        Me.lblCustomerNote.Visible = False
        '
        'lblCustomerData
        '
        Me.lblCustomerData.BackColor = System.Drawing.Color.Transparent
        Me.lblCustomerData.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCustomerData.ForeColor = System.Drawing.Color.DimGray
        Me.lblCustomerData.Location = New System.Drawing.Point(623, 87)
        Me.lblCustomerData.Name = "lblCustomerData"
        Me.lblCustomerData.Size = New System.Drawing.Size(330, 56)
        Me.lblCustomerData.TabIndex = 496
        Me.lblCustomerData.Visible = False
        '
        'cmdPhoneNotFound
        '
        Appearance55.BackColor = System.Drawing.Color.Firebrick
        Appearance55.BackColor2 = System.Drawing.Color.Firebrick
        Appearance55.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance55.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance55.BorderColor = System.Drawing.Color.DarkGreen
        Appearance55.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance55.ForeColor = System.Drawing.Color.White
        Me.cmdPhoneNotFound.Appearance = Appearance55
        Me.cmdPhoneNotFound.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance56.BackColor = System.Drawing.Color.PowderBlue
        Appearance56.BackColor2 = System.Drawing.Color.Aqua
        Appearance56.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance56.ForeColor = System.Drawing.Color.Black
        Me.cmdPhoneNotFound.HotTrackAppearance = Appearance56
        Me.cmdPhoneNotFound.Location = New System.Drawing.Point(437, 174)
        Me.cmdPhoneNotFound.Name = "cmdPhoneNotFound"
        Me.cmdPhoneNotFound.ShowFocusRect = False
        Me.cmdPhoneNotFound.ShowOutline = False
        Me.cmdPhoneNotFound.Size = New System.Drawing.Size(81, 28)
        Me.cmdPhoneNotFound.TabIndex = 395
        Me.cmdPhoneNotFound.Text = "No Match!"
        Me.cmdPhoneNotFound.UseAppStyling = False
        Me.cmdPhoneNotFound.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPhoneNotFound.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdPhoneNotFound.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdPhoneNotFound.Visible = False
        '
        'cmdBackScreen
        '
        Me.cmdBackScreen.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Appearance57.BackColor = System.Drawing.Color.Transparent
        Appearance57.BackColor2 = System.Drawing.Color.Transparent
        Appearance57.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance57.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance57.BorderColor = System.Drawing.Color.Transparent
        Appearance57.BorderColor2 = System.Drawing.Color.Maroon
        Appearance57.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance57.ForeColor = System.Drawing.Color.Black
        Appearance57.Image = CType(resources.GetObject("Appearance57.Image"), Object)
        Appearance57.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance57.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance57.TextVAlignAsString = "Bottom"
        Me.cmdBackScreen.Appearance = Appearance57
        Me.cmdBackScreen.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdBackScreen.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance58.BackColor = System.Drawing.Color.DarkOrange
        Appearance58.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance58.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance58.ForeColor = System.Drawing.Color.Black
        Me.cmdBackScreen.HotTrackAppearance = Appearance58
        Me.cmdBackScreen.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdBackScreen.Location = New System.Drawing.Point(12, 635)
        Me.cmdBackScreen.Name = "cmdBackScreen"
        Me.cmdBackScreen.Padding = New System.Drawing.Size(15, 0)
        Appearance59.BackColor = System.Drawing.Color.OrangeRed
        Appearance59.BackColor2 = System.Drawing.Color.Tomato
        Appearance59.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdBackScreen.PressedAppearance = Appearance59
        Me.cmdBackScreen.ShowFocusRect = False
        Me.cmdBackScreen.ShowOutline = False
        Me.cmdBackScreen.Size = New System.Drawing.Size(64, 44)
        Me.cmdBackScreen.StyleSetName = "StatusBar"
        Me.cmdBackScreen.TabIndex = 552
        Me.cmdBackScreen.Tag = "Up"
        Me.cmdBackScreen.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdBackScreen.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdBackScreen.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdPCPrev
        '
        Appearance60.BackColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance60.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance60.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance60.BorderColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance60.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance60.ForeColor = System.Drawing.Color.DarkGreen
        Appearance60.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance60.ImageVAlign = Infragistics.Win.VAlign.Top
        Me.cmdPCPrev.Appearance = Appearance60
        Me.cmdPCPrev.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance61.BackColor = System.Drawing.Color.DarkOrange
        Appearance61.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance61.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance61.ForeColor = System.Drawing.Color.Black
        Me.cmdPCPrev.HotTrackAppearance = Appearance61
        Me.cmdPCPrev.ImageSize = New System.Drawing.Size(40, 40)
        Me.cmdPCPrev.Location = New System.Drawing.Point(3, 2)
        Me.cmdPCPrev.Name = "cmdPCPrev"
        Appearance62.BackColor = System.Drawing.Color.OrangeRed
        Appearance62.BackColor2 = System.Drawing.Color.Tomato
        Appearance62.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdPCPrev.PressedAppearance = Appearance62
        Me.cmdPCPrev.ShowFocusRect = False
        Me.cmdPCPrev.ShowOutline = False
        Me.cmdPCPrev.Size = New System.Drawing.Size(110, 40)
        Me.cmdPCPrev.StyleSetName = "Reservation"
        Me.cmdPCPrev.TabIndex = 570
        Me.cmdPCPrev.Tag = "Up"
        Me.cmdPCPrev.Text = "Prev"
        Me.cmdPCPrev.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPCPrev.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPCPrev.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdPCNext
        '
        Appearance63.BackColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(210, Byte), Integer))
        Appearance63.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance63.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance63.BorderColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(120, Byte), Integer))
        Appearance63.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance63.ForeColor = System.Drawing.Color.DarkGreen
        Appearance63.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance63.ImageVAlign = Infragistics.Win.VAlign.Top
        Me.cmdPCNext.Appearance = Appearance63
        Me.cmdPCNext.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance64.BackColor = System.Drawing.Color.DarkOrange
        Appearance64.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance64.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance64.ForeColor = System.Drawing.Color.Black
        Me.cmdPCNext.HotTrackAppearance = Appearance64
        Me.cmdPCNext.ImageSize = New System.Drawing.Size(40, 40)
        Me.cmdPCNext.Location = New System.Drawing.Point(119, 2)
        Me.cmdPCNext.Name = "cmdPCNext"
        Appearance65.BackColor = System.Drawing.Color.OrangeRed
        Appearance65.BackColor2 = System.Drawing.Color.Tomato
        Appearance65.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdPCNext.PressedAppearance = Appearance65
        Me.cmdPCNext.ShowFocusRect = False
        Me.cmdPCNext.ShowOutline = False
        Me.cmdPCNext.Size = New System.Drawing.Size(110, 40)
        Me.cmdPCNext.StyleSetName = "Reservation"
        Me.cmdPCNext.TabIndex = 571
        Me.cmdPCNext.Tag = "Up"
        Me.cmdPCNext.Text = "Next"
        Me.cmdPCNext.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPCNext.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPCNext.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'uplAddressesMain
        '
        Me.uplAddressesMain.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance66.BorderColor = System.Drawing.Color.Silver
        Me.uplAddressesMain.Appearance = Appearance66
        Me.uplAddressesMain.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        '
        'uplAddressesMain.ClientArea
        '
        Me.uplAddressesMain.ClientArea.Controls.Add(Me.uplAddress)
        Me.uplAddressesMain.ClientArea.Controls.Add(Me.cmdPCNext)
        Me.uplAddressesMain.ClientArea.Controls.Add(Me.cmdPCPrev)
        Me.uplAddressesMain.ForeColor = System.Drawing.Color.White
        Me.uplAddressesMain.Location = New System.Drawing.Point(0, 238)
        Me.uplAddressesMain.Name = "uplAddressesMain"
        Me.uplAddressesMain.Size = New System.Drawing.Size(984, 383)
        Me.uplAddressesMain.TabIndex = 574
        Me.uplAddressesMain.Visible = False
        '
        'uplAddress
        '
        Me.uplAddress.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Appearance67.BorderColor = System.Drawing.Color.Silver
        Me.uplAddress.Appearance = Appearance67
        Me.uplAddress.AutoSize = True
        Me.uplAddress.Location = New System.Drawing.Point(3, 48)
        Me.uplAddress.Name = "uplAddress"
        Me.uplAddress.Size = New System.Drawing.Size(977, 330)
        Me.uplAddress.TabIndex = 572
        '
        'uflmAddress
        '
        Me.uflmAddress.ContainerControl = Me.uplAddress.ClientArea
        Me.uflmAddress.HorizontalAlignment = Infragistics.Win.Layout.DefaultableFlowLayoutAlignment.Near
        Me.uflmAddress.HorizontalGap = 1
        Me.uflmAddress.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.uflmAddress.VerticalAlignment = Infragistics.Win.Layout.DefaultableFlowLayoutAlignment.Near
        Me.uflmAddress.VerticalGap = 1
        '
        'ezkbdDelivColn
        '
        Me.ezkbdDelivColn.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.ezkbdDelivColn.BackColor = System.Drawing.Color.Transparent
        Me.ezkbdDelivColn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ezkbdDelivColn.EZKBBackColor = System.Drawing.Color.Empty
        Me.ezkbdDelivColn.EZKBBorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Me.ezkbdDelivColn.EZKBForeColor = System.Drawing.Color.SteelBlue
        Me.ezkbdDelivColn.Location = New System.Drawing.Point(91, 333)
        Me.ezkbdDelivColn.Name = "ezkbdDelivColn"
        Me.ezkbdDelivColn.Size = New System.Drawing.Size(802, 287)
        Me.ezkbdDelivColn.TabIndex = 575
        '
        'frmDelivColn
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(253, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(253, Byte), Integer))
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(984, 684)
        Me.ControlBox = False
        Me.Controls.Add(Me.uplAddressesMain)
        Me.Controls.Add(Me.cmdMap)
        Me.Controls.Add(Me.cmdPrevOrder)
        Me.Controls.Add(Me.cmdDirections)
        Me.Controls.Add(Me.cmdShowKeyboard)
        Me.Controls.Add(Me.cmdNotes)
        Me.Controls.Add(Me.cmdHome)
        Me.Controls.Add(Me.cmdCustSearch)
        Me.Controls.Add(Me.cmdClearForm)
        Me.Controls.Add(Me.cmdCustSave)
        Me.Controls.Add(Me.cmdPCSearch)
        Me.Controls.Add(Me.cmdNextScreen)
        Me.Controls.Add(Me.upnlCustomerInfo)
        Me.Controls.Add(Me.cmdBackScreen)
        Me.Controls.Add(Me.UltraLabel1)
        Me.Controls.Add(Me.ezkbdDelivColn)
        Me.DoubleBuffered = True
        Me.MinimumSize = New System.Drawing.Size(1000, 700)
        Me.Name = "frmDelivColn"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.upnlCustomerInfo.ClientArea.ResumeLayout(False)
        Me.upnlCustomerInfo.ClientArea.PerformLayout()
        Me.upnlCustomerInfo.ResumeLayout(False)
        CType(Me.txtName, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTelephone, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtAddress1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtPostcode, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtAddress2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtMobile, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtAddress3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtEmail, System.ComponentModel.ISupportInitialize).EndInit()
        Me.uplAddressesMain.ClientArea.ResumeLayout(False)
        Me.uplAddressesMain.ClientArea.PerformLayout()
        Me.uplAddressesMain.ResumeLayout(False)
        Me.uplAddress.ResumeLayout(False)
        Me.uplAddress.PerformLayout()
        CType(Me.uflmAddress, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents UltraLabel1 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents cmdMap As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdPrevOrder As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDirections As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdShowKeyboard As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdNotes As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdHome As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdCustSearch As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdClearForm As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdCustSave As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdPCSearch As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdNextScreen As Infragistics.Win.Misc.UltraButton
    Friend WithEvents upnlCustomerInfo As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents ubtnAddressDown As Infragistics.Win.Misc.UltraButton
    Friend WithEvents lblCustomerNote As Label
    Friend WithEvents lblCustomerData As Label
    Friend WithEvents cmdPhoneNotFound As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdBackScreen As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdPCPrev As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdPCNext As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdPickup As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDelivery As Infragistics.Win.Misc.UltraButton
    Friend WithEvents uplAddressesMain As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents txtName As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtTelephone As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtAddress1 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtPostcode As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtAddress2 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtMobile As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtAddress3 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtEmail As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents lblNameLbl As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblTelephoneLbl As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblPostcodeLbl As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblAddressLbl As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents ezkbdDelivColn As EZControls.EZKeyboard
    Friend WithEvents UltraLabel3 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel2 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents uplAddress As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents uflmAddress As Infragistics.Win.Misc.UltraFlowLayoutManager
End Class
