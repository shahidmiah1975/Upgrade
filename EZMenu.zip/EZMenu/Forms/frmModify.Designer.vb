﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmModify
	Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim Appearance53 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance54 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance55 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance56 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance57 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance58 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance59 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance60 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance61 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance62 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance63 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance64 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance65 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance66 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance14 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance15 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance67 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance18 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance68 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance20 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance69 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance22 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance70 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance71 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmModify))
        Dim Appearance72 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance73 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance27 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance74 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance75 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance76 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance77 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance78 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance79 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance80 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance81 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance82 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance83 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance21 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance84 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance85 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance86 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance87 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance88 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance89 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance90 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance91 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance92 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance93 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance94 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance95 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance96 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance97 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Me.UltraLabel1 = New Infragistics.Win.Misc.UltraLabel()
        Me.cmdIsMain = New Infragistics.Win.Misc.UltraButton()
        Me.cmdIsStarter = New Infragistics.Win.Misc.UltraButton()
        Me.cmdPortionSmall = New Infragistics.Win.Misc.UltraButton()
        Me.cmdPortionLarge = New Infragistics.Win.Misc.UltraButton()
        Me.upnlModItems = New Infragistics.Win.Misc.UltraPanel()
        Me.txtDName = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.lblPostcodeLbl = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel2 = New Infragistics.Win.Misc.UltraLabel()
        Me.txtDPrice = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.UltraLabel3 = New Infragistics.Win.Misc.UltraLabel()
        Me.txtDQty = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.UltraPanel1 = New Infragistics.Win.Misc.UltraPanel()
        Me.txtMod = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.UltraLabel4 = New Infragistics.Win.Misc.UltraLabel()
        Me.cmdClear = New Infragistics.Win.Misc.UltraButton()
        Me.txtPrice = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.cmdPrintLabelsMod = New Infragistics.Win.Misc.UltraButton()
        Me.UltraLabel5 = New Infragistics.Win.Misc.UltraLabel()
        Me.cmdKBModifier = New Infragistics.Win.Misc.UltraButton()
        Me.cmdGetPrice = New Infragistics.Win.Misc.UltraButton()
        Me.cmdBack = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDName = New Infragistics.Win.Misc.UltraButton()
        Me.cmdQty = New Infragistics.Win.Misc.UltraButton()
        Me.cmdChangePrice = New Infragistics.Win.Misc.UltraButton()
        Me.ufmModItems = New Infragistics.Win.Misc.UltraFlowLayoutManager(Me.components)
        Me.cmdOK = New Infragistics.Win.Misc.UltraButton()
        Me.upnlModItems.SuspendLayout()
        CType(Me.txtDName, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtDPrice, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtDQty, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.UltraPanel1.ClientArea.SuspendLayout()
        Me.UltraPanel1.SuspendLayout()
        CType(Me.txtMod, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtPrice, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ufmModItems, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'UltraLabel1
        '
        Me.UltraLabel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance53.BorderColor = System.Drawing.Color.Silver
        Me.UltraLabel1.Appearance = Appearance53
        Me.UltraLabel1.BorderStyleInner = Infragistics.Win.UIElementBorderStyle.Solid
        Me.UltraLabel1.Location = New System.Drawing.Point(-1, 641)
        Me.UltraLabel1.Name = "UltraLabel1"
        Me.UltraLabel1.Size = New System.Drawing.Size(1253, 1)
        Me.UltraLabel1.TabIndex = 549
        '
        'cmdIsMain
        '
        Me.cmdIsMain.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance54.BackColor = System.Drawing.Color.PapayaWhip
        Appearance54.BackColor2 = System.Drawing.Color.DarkKhaki
        Appearance54.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance54.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance54.BorderColor = System.Drawing.Color.DarkKhaki
        Appearance54.ForeColor = System.Drawing.Color.Black
        Me.cmdIsMain.Appearance = Appearance54
        Me.cmdIsMain.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance55.BackColor = System.Drawing.Color.DarkOrange
        Appearance55.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance55.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance55.ForeColor = System.Drawing.Color.Black
        Me.cmdIsMain.HotTrackAppearance = Appearance55
        Me.cmdIsMain.ImageSize = New System.Drawing.Size(24, 24)
        Me.cmdIsMain.Location = New System.Drawing.Point(1079, 308)
        Me.cmdIsMain.Name = "cmdIsMain"
        Appearance56.BackColor = System.Drawing.Color.OrangeRed
        Appearance56.BackColor2 = System.Drawing.Color.Tomato
        Appearance56.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdIsMain.PressedAppearance = Appearance56
        Me.cmdIsMain.ShowFocusRect = False
        Me.cmdIsMain.ShowOutline = False
        Me.cmdIsMain.Size = New System.Drawing.Size(100, 45)
        Me.cmdIsMain.TabIndex = 573
        Me.cmdIsMain.Tag = ""
        Me.cmdIsMain.Text = "Main"
        Me.cmdIsMain.UseAppStyling = False
        Me.cmdIsMain.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdIsMain.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdIsMain.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdIsStarter
        '
        Me.cmdIsStarter.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance57.BackColor = System.Drawing.Color.PapayaWhip
        Appearance57.BackColor2 = System.Drawing.Color.DarkKhaki
        Appearance57.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance57.BorderColor = System.Drawing.Color.DarkKhaki
        Appearance57.ForeColor = System.Drawing.Color.Black
        Me.cmdIsStarter.Appearance = Appearance57
        Me.cmdIsStarter.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance58.BackColor = System.Drawing.Color.DarkOrange
        Appearance58.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance58.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance58.ForeColor = System.Drawing.Color.Black
        Me.cmdIsStarter.HotTrackAppearance = Appearance58
        Me.cmdIsStarter.ImageSize = New System.Drawing.Size(24, 24)
        Me.cmdIsStarter.Location = New System.Drawing.Point(972, 308)
        Me.cmdIsStarter.Name = "cmdIsStarter"
        Appearance59.BackColor = System.Drawing.Color.OrangeRed
        Appearance59.BackColor2 = System.Drawing.Color.Tomato
        Appearance59.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdIsStarter.PressedAppearance = Appearance59
        Me.cmdIsStarter.ShowFocusRect = False
        Me.cmdIsStarter.ShowOutline = False
        Me.cmdIsStarter.Size = New System.Drawing.Size(100, 45)
        Me.cmdIsStarter.TabIndex = 572
        Me.cmdIsStarter.Tag = ""
        Me.cmdIsStarter.Text = "Starter"
        Me.cmdIsStarter.UseAppStyling = False
        Me.cmdIsStarter.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdIsStarter.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdIsStarter.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdPortionSmall
        '
        Me.cmdPortionSmall.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance60.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance60.BackColor2 = System.Drawing.Color.Silver
        Appearance60.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance60.BorderColor = System.Drawing.Color.Silver
        Appearance60.ForeColor = System.Drawing.Color.Black
        Me.cmdPortionSmall.Appearance = Appearance60
        Me.cmdPortionSmall.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance61.BackColor = System.Drawing.Color.DarkOrange
        Appearance61.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance61.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance61.ForeColor = System.Drawing.Color.Black
        Me.cmdPortionSmall.HotTrackAppearance = Appearance61
        Me.cmdPortionSmall.ImageSize = New System.Drawing.Size(24, 24)
        Me.cmdPortionSmall.Location = New System.Drawing.Point(1079, 359)
        Me.cmdPortionSmall.Name = "cmdPortionSmall"
        Appearance62.BackColor = System.Drawing.Color.OrangeRed
        Appearance62.BackColor2 = System.Drawing.Color.Tomato
        Appearance62.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdPortionSmall.PressedAppearance = Appearance62
        Me.cmdPortionSmall.ShowFocusRect = False
        Me.cmdPortionSmall.ShowOutline = False
        Me.cmdPortionSmall.Size = New System.Drawing.Size(100, 45)
        Me.cmdPortionSmall.TabIndex = 571
        Me.cmdPortionSmall.Text = "Small"
        Me.cmdPortionSmall.UseAppStyling = False
        Me.cmdPortionSmall.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPortionSmall.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPortionSmall.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdPortionLarge
        '
        Me.cmdPortionLarge.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance63.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance63.BackColor2 = System.Drawing.Color.Silver
        Appearance63.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance63.BorderColor = System.Drawing.Color.Silver
        Appearance63.ForeColor = System.Drawing.Color.Black
        Me.cmdPortionLarge.Appearance = Appearance63
        Me.cmdPortionLarge.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance64.BackColor = System.Drawing.Color.DarkOrange
        Appearance64.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance64.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance64.ForeColor = System.Drawing.Color.Black
        Me.cmdPortionLarge.HotTrackAppearance = Appearance64
        Me.cmdPortionLarge.ImageSize = New System.Drawing.Size(24, 24)
        Me.cmdPortionLarge.Location = New System.Drawing.Point(972, 359)
        Me.cmdPortionLarge.Name = "cmdPortionLarge"
        Appearance65.BackColor = System.Drawing.Color.OrangeRed
        Appearance65.BackColor2 = System.Drawing.Color.Tomato
        Appearance65.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdPortionLarge.PressedAppearance = Appearance65
        Me.cmdPortionLarge.ShowFocusRect = False
        Me.cmdPortionLarge.ShowOutline = False
        Me.cmdPortionLarge.Size = New System.Drawing.Size(100, 45)
        Me.cmdPortionLarge.TabIndex = 570
        Me.cmdPortionLarge.Text = "Large"
        Me.cmdPortionLarge.UseAppStyling = False
        Me.cmdPortionLarge.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPortionLarge.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPortionLarge.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'upnlModItems
        '
        Me.upnlModItems.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance66.BackColor = System.Drawing.Color.WhiteSmoke
        Me.upnlModItems.Appearance = Appearance66
        Me.upnlModItems.BorderStyle = Infragistics.Win.UIElementBorderStyle.None
        Me.upnlModItems.ForeColor = System.Drawing.SystemColors.Control
        Me.upnlModItems.Location = New System.Drawing.Point(12, 12)
        Me.upnlModItems.Name = "upnlModItems"
        Me.upnlModItems.Size = New System.Drawing.Size(942, 573)
        Me.upnlModItems.TabIndex = 565
        '
        'txtDName
        '
        Me.txtDName.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance14.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance14.BorderColor = System.Drawing.Color.LightGray
        Appearance14.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Me.txtDName.Appearance = Appearance14
        Me.txtDName.AutoSize = False
        Me.txtDName.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtDName.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtDName.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDName.Location = New System.Drawing.Point(960, 61)
        Me.txtDName.MaxLength = 50
        Me.txtDName.Name = "txtDName"
        Me.txtDName.Size = New System.Drawing.Size(278, 28)
        Me.txtDName.StyleSetName = "TextEntry"
        Me.txtDName.TabIndex = 583
        Me.txtDName.UseAppStyling = False
        Me.txtDName.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtDName.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblPostcodeLbl
        '
        Me.lblPostcodeLbl.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance15.BackColor = System.Drawing.Color.Transparent
        Appearance15.ForeColor = System.Drawing.Color.DimGray
        Appearance15.TextHAlignAsString = "Right"
        Me.lblPostcodeLbl.Appearance = Appearance15
        Me.lblPostcodeLbl.AutoSize = True
        Me.lblPostcodeLbl.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPostcodeLbl.Location = New System.Drawing.Point(960, 35)
        Me.lblPostcodeLbl.Name = "lblPostcodeLbl"
        Me.lblPostcodeLbl.Size = New System.Drawing.Size(54, 20)
        Me.lblPostcodeLbl.StyleSetName = "TextEntryLabel"
        Me.lblPostcodeLbl.TabIndex = 584
        Me.lblPostcodeLbl.Text = "Name:"
        Me.lblPostcodeLbl.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraLabel2
        '
        Me.UltraLabel2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance67.BackColor = System.Drawing.Color.Transparent
        Appearance67.ForeColor = System.Drawing.Color.DimGray
        Appearance67.TextHAlignAsString = "Right"
        Me.UltraLabel2.Appearance = Appearance67
        Me.UltraLabel2.AutoSize = True
        Me.UltraLabel2.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UltraLabel2.Location = New System.Drawing.Point(960, 101)
        Me.UltraLabel2.Name = "UltraLabel2"
        Me.UltraLabel2.Size = New System.Drawing.Size(48, 20)
        Me.UltraLabel2.StyleSetName = "TextEntryLabel"
        Me.UltraLabel2.TabIndex = 586
        Me.UltraLabel2.Text = "Price:"
        Me.UltraLabel2.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtDPrice
        '
        Me.txtDPrice.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance18.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance18.BorderColor = System.Drawing.Color.LightGray
        Appearance18.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Me.txtDPrice.Appearance = Appearance18
        Me.txtDPrice.AutoSize = False
        Me.txtDPrice.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtDPrice.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtDPrice.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDPrice.Location = New System.Drawing.Point(960, 127)
        Me.txtDPrice.MaxLength = 50
        Me.txtDPrice.Name = "txtDPrice"
        Me.txtDPrice.Size = New System.Drawing.Size(121, 28)
        Me.txtDPrice.StyleSetName = "TextEntry"
        Me.txtDPrice.TabIndex = 585
        Me.txtDPrice.UseAppStyling = False
        Me.txtDPrice.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtDPrice.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraLabel3
        '
        Me.UltraLabel3.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance68.BackColor = System.Drawing.Color.Transparent
        Appearance68.ForeColor = System.Drawing.Color.DimGray
        Appearance68.TextHAlignAsString = "Right"
        Me.UltraLabel3.Appearance = Appearance68
        Me.UltraLabel3.AutoSize = True
        Me.UltraLabel3.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UltraLabel3.Location = New System.Drawing.Point(960, 167)
        Me.UltraLabel3.Name = "UltraLabel3"
        Me.UltraLabel3.Size = New System.Drawing.Size(36, 20)
        Me.UltraLabel3.StyleSetName = "TextEntryLabel"
        Me.UltraLabel3.TabIndex = 588
        Me.UltraLabel3.Text = "Qty:"
        Me.UltraLabel3.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtDQty
        '
        Me.txtDQty.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance20.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance20.BorderColor = System.Drawing.Color.LightGray
        Appearance20.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Me.txtDQty.Appearance = Appearance20
        Me.txtDQty.AutoSize = False
        Me.txtDQty.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtDQty.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtDQty.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDQty.Location = New System.Drawing.Point(960, 193)
        Me.txtDQty.MaxLength = 50
        Me.txtDQty.Name = "txtDQty"
        Me.txtDQty.Size = New System.Drawing.Size(121, 28)
        Me.txtDQty.StyleSetName = "TextEntry"
        Me.txtDQty.TabIndex = 587
        Me.txtDQty.UseAppStyling = False
        Me.txtDQty.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtDQty.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraPanel1
        '
        Me.UltraPanel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance69.BackColor = System.Drawing.Color.Gainsboro
        Me.UltraPanel1.Appearance = Appearance69
        Me.UltraPanel1.BorderStyle = Infragistics.Win.UIElementBorderStyle.None
        '
        'UltraPanel1.ClientArea
        '
        Me.UltraPanel1.ClientArea.Controls.Add(Me.txtMod)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.UltraLabel4)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.cmdClear)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.txtPrice)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.cmdPrintLabelsMod)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.UltraLabel5)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.cmdKBModifier)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.cmdGetPrice)
        Me.UltraPanel1.ForeColor = System.Drawing.SystemColors.Control
        Me.UltraPanel1.Location = New System.Drawing.Point(12, 585)
        Me.UltraPanel1.Name = "UltraPanel1"
        Me.UltraPanel1.Size = New System.Drawing.Size(942, 50)
        Me.UltraPanel1.TabIndex = 593
        '
        'txtMod
        '
        Appearance22.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance22.BorderColor = System.Drawing.Color.LightGray
        Appearance22.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Me.txtMod.Appearance = Appearance22
        Me.txtMod.AutoSize = False
        Me.txtMod.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtMod.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtMod.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMod.Location = New System.Drawing.Point(89, 11)
        Me.txtMod.MaxLength = 50
        Me.txtMod.Name = "txtMod"
        Me.txtMod.Size = New System.Drawing.Size(235, 28)
        Me.txtMod.StyleSetName = "TextEntry"
        Me.txtMod.TabIndex = 597
        Me.txtMod.UseAppStyling = False
        Me.txtMod.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtMod.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraLabel4
        '
        Appearance70.BackColor = System.Drawing.Color.Transparent
        Appearance70.ForeColor = System.Drawing.Color.DimGray
        Appearance70.TextHAlignAsString = "Right"
        Me.UltraLabel4.Appearance = Appearance70
        Me.UltraLabel4.AutoSize = True
        Me.UltraLabel4.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UltraLabel4.Location = New System.Drawing.Point(402, 16)
        Me.UltraLabel4.Name = "UltraLabel4"
        Me.UltraLabel4.Size = New System.Drawing.Size(48, 20)
        Me.UltraLabel4.StyleSetName = "TextEntryLabel"
        Me.UltraLabel4.TabIndex = 600
        Me.UltraLabel4.Text = "Price:"
        Me.UltraLabel4.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdClear
        '
        Me.cmdClear.Anchor = System.Windows.Forms.AnchorStyles.Right
        Appearance71.BackColor = System.Drawing.Color.Transparent
        Appearance71.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance71.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance71.BorderColor = System.Drawing.Color.Transparent
        Appearance71.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance71.ForeColor = System.Drawing.Color.Black
        Appearance71.Image = CType(resources.GetObject("Appearance71.Image"), Object)
        Appearance71.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance71.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance71.TextVAlignAsString = "Bottom"
        Me.cmdClear.Appearance = Appearance71
        Me.cmdClear.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance72.BackColor = System.Drawing.Color.DarkOrange
        Appearance72.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance72.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance72.ForeColor = System.Drawing.Color.Black
        Me.cmdClear.HotTrackAppearance = Appearance72
        Me.cmdClear.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdClear.Location = New System.Drawing.Point(830, 6)
        Me.cmdClear.Name = "cmdClear"
        Appearance73.BackColor = System.Drawing.Color.OrangeRed
        Appearance73.BackColor2 = System.Drawing.Color.Tomato
        Appearance73.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdClear.PressedAppearance = Appearance73
        Me.cmdClear.ShowFocusRect = False
        Me.cmdClear.ShowOutline = False
        Me.cmdClear.Size = New System.Drawing.Size(50, 40)
        Me.cmdClear.StyleSetName = "StatusBar"
        Me.cmdClear.TabIndex = 593
        Me.cmdClear.Tag = "Clear"
        Me.cmdClear.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdClear.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdClear.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txtPrice
        '
        Appearance27.BackColor = System.Drawing.Color.WhiteSmoke
        Appearance27.BorderColor = System.Drawing.Color.LightGray
        Appearance27.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(93, Byte), Integer))
        Me.txtPrice.Appearance = Appearance27
        Me.txtPrice.AutoSize = False
        Me.txtPrice.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtPrice.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1
        Me.txtPrice.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPrice.Location = New System.Drawing.Point(456, 11)
        Me.txtPrice.MaxLength = 50
        Me.txtPrice.Name = "txtPrice"
        Me.txtPrice.Size = New System.Drawing.Size(121, 28)
        Me.txtPrice.StyleSetName = "TextEntry"
        Me.txtPrice.TabIndex = 599
        Me.txtPrice.UseAppStyling = False
        Me.txtPrice.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.txtPrice.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdPrintLabelsMod
        '
        Me.cmdPrintLabelsMod.Anchor = System.Windows.Forms.AnchorStyles.Right
        Appearance74.BackColor = System.Drawing.Color.Transparent
        Appearance74.BackColor2 = System.Drawing.Color.Transparent
        Appearance74.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance74.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance74.BorderColor = System.Drawing.Color.Transparent
        Appearance74.BorderColor2 = System.Drawing.Color.Maroon
        Appearance74.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance74.ForeColor = System.Drawing.Color.White
        Appearance74.Image = CType(resources.GetObject("Appearance74.Image"), Object)
        Appearance74.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance74.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance74.TextVAlignAsString = "Bottom"
        Me.cmdPrintLabelsMod.Appearance = Appearance74
        Me.cmdPrintLabelsMod.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance75.BackColor = System.Drawing.Color.DarkOrange
        Appearance75.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance75.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance75.ForeColor = System.Drawing.Color.Black
        Me.cmdPrintLabelsMod.HotTrackAppearance = Appearance75
        Me.cmdPrintLabelsMod.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdPrintLabelsMod.Location = New System.Drawing.Point(886, 6)
        Me.cmdPrintLabelsMod.Name = "cmdPrintLabelsMod"
        Appearance76.BackColor = System.Drawing.Color.OrangeRed
        Appearance76.BackColor2 = System.Drawing.Color.Tomato
        Appearance76.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdPrintLabelsMod.PressedAppearance = Appearance76
        Me.cmdPrintLabelsMod.ShowFocusRect = False
        Me.cmdPrintLabelsMod.ShowOutline = False
        Me.cmdPrintLabelsMod.Size = New System.Drawing.Size(50, 40)
        Me.cmdPrintLabelsMod.StyleSetName = "StatusBar"
        Me.cmdPrintLabelsMod.TabIndex = 594
        Me.cmdPrintLabelsMod.Tag = ""
        Me.cmdPrintLabelsMod.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPrintLabelsMod.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdPrintLabelsMod.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdPrintLabelsMod.Visible = False
        '
        'UltraLabel5
        '
        Appearance77.BackColor = System.Drawing.Color.Transparent
        Appearance77.ForeColor = System.Drawing.Color.DimGray
        Appearance77.TextHAlignAsString = "Right"
        Me.UltraLabel5.Appearance = Appearance77
        Me.UltraLabel5.AutoSize = True
        Me.UltraLabel5.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UltraLabel5.Location = New System.Drawing.Point(14, 16)
        Me.UltraLabel5.Name = "UltraLabel5"
        Me.UltraLabel5.Size = New System.Drawing.Size(69, 20)
        Me.UltraLabel5.StyleSetName = "TextEntryLabel"
        Me.UltraLabel5.TabIndex = 598
        Me.UltraLabel5.Text = "Modifier:"
        Me.UltraLabel5.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdKBModifier
        '
        Appearance78.BackColor = System.Drawing.Color.Transparent
        Appearance78.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance78.BackGradientStyle = Infragistics.Win.GradientStyle.None
        Appearance78.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance78.BorderColor = System.Drawing.Color.Transparent
        Appearance78.BorderColor2 = System.Drawing.Color.Transparent
        Appearance78.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance78.ForeColor = System.Drawing.Color.Black
        Appearance78.Image = CType(resources.GetObject("Appearance78.Image"), Object)
        Appearance78.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance78.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance78.TextVAlignAsString = "Bottom"
        Me.cmdKBModifier.Appearance = Appearance78
        Me.cmdKBModifier.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdKBModifier.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance79.BackColor = System.Drawing.Color.DarkOrange
        Appearance79.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance79.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance79.ForeColor = System.Drawing.Color.Black
        Me.cmdKBModifier.HotTrackAppearance = Appearance79
        Me.cmdKBModifier.ImageSize = New System.Drawing.Size(42, 25)
        Me.cmdKBModifier.Location = New System.Drawing.Point(330, 5)
        Me.cmdKBModifier.Name = "cmdKBModifier"
        Appearance80.BackColor = System.Drawing.Color.Transparent
        Appearance80.BackColor2 = System.Drawing.Color.Transparent
        Me.cmdKBModifier.PressedAppearance = Appearance80
        Me.cmdKBModifier.ShowFocusRect = False
        Me.cmdKBModifier.ShowOutline = False
        Me.cmdKBModifier.Size = New System.Drawing.Size(42, 40)
        Me.cmdKBModifier.StyleSetName = "StatusBar"
        Me.cmdKBModifier.TabIndex = 595
        Me.cmdKBModifier.Tag = "Keyboard"
        Me.cmdKBModifier.UseAppStyling = False
        Me.cmdKBModifier.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdKBModifier.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdKBModifier.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdGetPrice
        '
        Appearance81.BackColor = System.Drawing.Color.Transparent
        Appearance81.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance81.BackGradientStyle = Infragistics.Win.GradientStyle.None
        Appearance81.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance81.BorderColor = System.Drawing.Color.Transparent
        Appearance81.BorderColor2 = System.Drawing.Color.Transparent
        Appearance81.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance81.ForeColor = System.Drawing.Color.Black
        Appearance81.Image = CType(resources.GetObject("Appearance81.Image"), Object)
        Appearance81.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance81.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance81.TextVAlignAsString = "Bottom"
        Me.cmdGetPrice.Appearance = Appearance81
        Me.cmdGetPrice.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdGetPrice.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance82.BackColor = System.Drawing.Color.DarkOrange
        Appearance82.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance82.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance82.ForeColor = System.Drawing.Color.Black
        Me.cmdGetPrice.HotTrackAppearance = Appearance82
        Me.cmdGetPrice.ImageSize = New System.Drawing.Size(42, 25)
        Me.cmdGetPrice.Location = New System.Drawing.Point(583, 5)
        Me.cmdGetPrice.Name = "cmdGetPrice"
        Appearance83.BackColor = System.Drawing.Color.Transparent
        Appearance83.BackColor2 = System.Drawing.Color.Transparent
        Me.cmdGetPrice.PressedAppearance = Appearance83
        Me.cmdGetPrice.ShowFocusRect = False
        Me.cmdGetPrice.ShowOutline = False
        Me.cmdGetPrice.Size = New System.Drawing.Size(42, 40)
        Me.cmdGetPrice.StyleSetName = "StatusBar"
        Me.cmdGetPrice.TabIndex = 596
        Me.cmdGetPrice.Tag = "Keyboard"
        Me.cmdGetPrice.UseAppStyling = False
        Me.cmdGetPrice.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdGetPrice.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdGetPrice.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdBack
        '
        Me.cmdBack.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Appearance21.BackColor = System.Drawing.Color.Transparent
        Appearance21.BackColor2 = System.Drawing.Color.Transparent
        Appearance21.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance21.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance21.BorderColor = System.Drawing.Color.Transparent
        Appearance21.BorderColor2 = System.Drawing.Color.Maroon
        Appearance21.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance21.ForeColor = System.Drawing.Color.White
        Appearance21.Image = CType(resources.GetObject("Appearance21.Image"), Object)
        Appearance21.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance21.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance21.TextVAlignAsString = "Bottom"
        Me.cmdBack.Appearance = Appearance21
        Me.cmdBack.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdBack.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance84.BackColor = System.Drawing.Color.DarkOrange
        Appearance84.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance84.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance84.BorderColor = System.Drawing.Color.Transparent
        Appearance84.ForeColor = System.Drawing.Color.Black
        Me.cmdBack.HotTrackAppearance = Appearance84
        Me.cmdBack.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdBack.Location = New System.Drawing.Point(628, 648)
        Me.cmdBack.Name = "cmdBack"
        Me.cmdBack.Padding = New System.Drawing.Size(15, 0)
        Appearance85.BackColor = System.Drawing.Color.OrangeRed
        Appearance85.BackColor2 = System.Drawing.Color.Tomato
        Appearance85.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance85.BorderColor = System.Drawing.Color.Transparent
        Me.cmdBack.PressedAppearance = Appearance85
        Me.cmdBack.ShowFocusRect = False
        Me.cmdBack.ShowOutline = False
        Me.cmdBack.Size = New System.Drawing.Size(64, 44)
        Me.cmdBack.StyleSetName = "StatusBar"
        Me.cmdBack.TabIndex = 594
        Me.cmdBack.Tag = "Return"
        Me.cmdBack.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdBack.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdBack.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDName
        '
        Me.cmdDName.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance86.BackColor = System.Drawing.Color.Transparent
        Appearance86.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance86.BackGradientStyle = Infragistics.Win.GradientStyle.None
        Appearance86.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance86.BorderColor = System.Drawing.Color.Transparent
        Appearance86.BorderColor2 = System.Drawing.Color.Transparent
        Appearance86.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance86.ForeColor = System.Drawing.Color.Black
        Appearance86.Image = CType(resources.GetObject("Appearance86.Image"), Object)
        Appearance86.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance86.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance86.TextVAlignAsString = "Bottom"
        Me.cmdDName.Appearance = Appearance86
        Me.cmdDName.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdDName.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance87.BackColor = System.Drawing.Color.DarkOrange
        Appearance87.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance87.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance87.ForeColor = System.Drawing.Color.Black
        Me.cmdDName.HotTrackAppearance = Appearance87
        Me.cmdDName.ImageSize = New System.Drawing.Size(42, 25)
        Me.cmdDName.Location = New System.Drawing.Point(1196, 96)
        Me.cmdDName.Name = "cmdDName"
        Appearance88.BackColor = System.Drawing.Color.Transparent
        Appearance88.BackColor2 = System.Drawing.Color.Transparent
        Me.cmdDName.PressedAppearance = Appearance88
        Me.cmdDName.ShowFocusRect = False
        Me.cmdDName.ShowOutline = False
        Me.cmdDName.Size = New System.Drawing.Size(42, 40)
        Me.cmdDName.StyleSetName = "StatusBar"
        Me.cmdDName.TabIndex = 598
        Me.cmdDName.Tag = "Keyboard"
        Me.cmdDName.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDName.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDName.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdQty
        '
        Me.cmdQty.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance89.BackColor = System.Drawing.Color.Transparent
        Appearance89.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance89.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance89.BorderColor = System.Drawing.Color.Transparent
        Appearance89.ForeColor = System.Drawing.Color.Black
        Appearance89.Image = CType(resources.GetObject("Appearance89.Image"), Object)
        Appearance89.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance89.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance89.TextVAlignAsString = "Bottom"
        Me.cmdQty.Appearance = Appearance89
        Me.cmdQty.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance90.BackColor = System.Drawing.Color.DarkOrange
        Appearance90.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance90.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance90.ForeColor = System.Drawing.Color.Black
        Me.cmdQty.HotTrackAppearance = Appearance90
        Me.cmdQty.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdQty.Location = New System.Drawing.Point(1087, 187)
        Me.cmdQty.Name = "cmdQty"
        Appearance91.BackColor = System.Drawing.Color.OrangeRed
        Appearance91.BackColor2 = System.Drawing.Color.Tomato
        Appearance91.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdQty.PressedAppearance = Appearance91
        Me.cmdQty.ShowFocusRect = False
        Me.cmdQty.ShowOutline = False
        Me.cmdQty.Size = New System.Drawing.Size(40, 40)
        Me.cmdQty.StyleSetName = "StatusBar"
        Me.cmdQty.TabIndex = 597
        Me.cmdQty.Tag = "Back"
        Me.cmdQty.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdQty.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdQty.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdChangePrice
        '
        Me.cmdChangePrice.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance92.BackColor = System.Drawing.Color.Transparent
        Appearance92.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance92.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance92.BorderColor = System.Drawing.Color.Transparent
        Appearance92.ForeColor = System.Drawing.Color.Black
        Appearance92.Image = CType(resources.GetObject("Appearance92.Image"), Object)
        Appearance92.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance92.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance92.TextVAlignAsString = "Bottom"
        Me.cmdChangePrice.Appearance = Appearance92
        Me.cmdChangePrice.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance93.BackColor = System.Drawing.Color.DarkOrange
        Appearance93.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance93.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance93.ForeColor = System.Drawing.Color.Black
        Me.cmdChangePrice.HotTrackAppearance = Appearance93
        Me.cmdChangePrice.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdChangePrice.Location = New System.Drawing.Point(1087, 122)
        Me.cmdChangePrice.Name = "cmdChangePrice"
        Appearance94.BackColor = System.Drawing.Color.OrangeRed
        Appearance94.BackColor2 = System.Drawing.Color.Tomato
        Appearance94.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdChangePrice.PressedAppearance = Appearance94
        Me.cmdChangePrice.ShowFocusRect = False
        Me.cmdChangePrice.ShowOutline = False
        Me.cmdChangePrice.Size = New System.Drawing.Size(40, 40)
        Me.cmdChangePrice.StyleSetName = "StatusBar"
        Me.cmdChangePrice.TabIndex = 596
        Me.cmdChangePrice.Tag = "Back"
        Me.cmdChangePrice.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdChangePrice.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdChangePrice.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ufmModItems
        '
        Me.ufmModItems.ContainerControl = Me.upnlModItems.ClientArea
        Me.ufmModItems.HorizontalAlignment = Infragistics.Win.Layout.DefaultableFlowLayoutAlignment.Near
        Me.ufmModItems.Margins.Bottom = 5
        Me.ufmModItems.Margins.Left = 5
        Me.ufmModItems.Margins.Right = 5
        Me.ufmModItems.Margins.Top = 5
        '
        'cmdOK
        '
        Me.cmdOK.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Appearance95.BackColor = System.Drawing.Color.Transparent
        Appearance95.BackColor2 = System.Drawing.Color.Transparent
        Appearance95.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance95.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance95.BorderColor = System.Drawing.Color.Transparent
        Appearance95.BorderColor2 = System.Drawing.Color.Maroon
        Appearance95.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance95.ForeColor = System.Drawing.Color.White
        Appearance95.Image = CType(resources.GetObject("Appearance95.Image"), Object)
        Appearance95.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance95.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance95.TextVAlignAsString = "Bottom"
        Me.cmdOK.Appearance = Appearance95
        Me.cmdOK.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdOK.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance96.BackColor = System.Drawing.Color.DarkOrange
        Appearance96.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance96.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance96.BorderColor = System.Drawing.Color.Transparent
        Appearance96.ForeColor = System.Drawing.Color.Black
        Me.cmdOK.HotTrackAppearance = Appearance96
        Me.cmdOK.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdOK.Location = New System.Drawing.Point(558, 648)
        Me.cmdOK.Name = "cmdOK"
        Me.cmdOK.Padding = New System.Drawing.Size(15, 0)
        Appearance97.BackColor = System.Drawing.Color.OrangeRed
        Appearance97.BackColor2 = System.Drawing.Color.Tomato
        Appearance97.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance97.BorderColor = System.Drawing.Color.Transparent
        Me.cmdOK.PressedAppearance = Appearance97
        Me.cmdOK.ShowFocusRect = False
        Me.cmdOK.ShowOutline = False
        Me.cmdOK.Size = New System.Drawing.Size(64, 44)
        Me.cmdOK.StyleSetName = "StatusBar"
        Me.cmdOK.TabIndex = 599
        Me.cmdOK.Tag = "Return"
        Me.cmdOK.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOK.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOK.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'frmModify
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(1250, 698)
        Me.ControlBox = False
        Me.Controls.Add(Me.cmdOK)
        Me.Controls.Add(Me.cmdDName)
        Me.Controls.Add(Me.cmdQty)
        Me.Controls.Add(Me.cmdChangePrice)
        Me.Controls.Add(Me.cmdBack)
        Me.Controls.Add(Me.UltraPanel1)
        Me.Controls.Add(Me.UltraLabel3)
        Me.Controls.Add(Me.txtDQty)
        Me.Controls.Add(Me.UltraLabel2)
        Me.Controls.Add(Me.txtDPrice)
        Me.Controls.Add(Me.lblPostcodeLbl)
        Me.Controls.Add(Me.txtDName)
        Me.Controls.Add(Me.cmdIsMain)
        Me.Controls.Add(Me.cmdIsStarter)
        Me.Controls.Add(Me.cmdPortionSmall)
        Me.Controls.Add(Me.cmdPortionLarge)
        Me.Controls.Add(Me.upnlModItems)
        Me.Controls.Add(Me.UltraLabel1)
        Me.DoubleBuffered = True
        Me.MinimumSize = New System.Drawing.Size(1000, 700)
        Me.Name = "frmModify"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.upnlModItems.ResumeLayout(False)
        CType(Me.txtDName, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtDPrice, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtDQty, System.ComponentModel.ISupportInitialize).EndInit()
        Me.UltraPanel1.ClientArea.ResumeLayout(False)
        Me.UltraPanel1.ClientArea.PerformLayout()
        Me.UltraPanel1.ResumeLayout(False)
        CType(Me.txtMod, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtPrice, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ufmModItems, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents UltraLabel1 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents cmdIsMain As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdIsStarter As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdPortionSmall As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdPortionLarge As Infragistics.Win.Misc.UltraButton
    Friend WithEvents upnlModItems As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents txtDName As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents lblPostcodeLbl As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents UltraLabel2 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents txtDPrice As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents UltraLabel3 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents txtDQty As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents UltraPanel1 As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents txtMod As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents UltraLabel4 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents cmdClear As Infragistics.Win.Misc.UltraButton
    Friend WithEvents txtPrice As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents cmdPrintLabelsMod As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraLabel5 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents cmdKBModifier As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdGetPrice As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdBack As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDName As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdQty As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdChangePrice As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ufmModItems As Infragistics.Win.Misc.UltraFlowLayoutManager
    Friend WithEvents cmdOK As Infragistics.Win.Misc.UltraButton
End Class