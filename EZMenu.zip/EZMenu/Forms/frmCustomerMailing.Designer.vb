﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCustomerMailing
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim Appearance1 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance2 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance3 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmCustomerMailing))
        Dim Appearance4 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance5 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance6 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance7 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance8 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance9 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance10 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance11 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance12 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance13 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance14 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance15 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance16 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance17 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance18 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance19 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance20 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance21 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance22 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance23 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance24 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance25 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance26 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Me.lblNumRecords = New System.Windows.Forms.Label()
        Me.lblShortCode = New Infragistics.Win.Misc.UltraLabel()
        Me.txtCriteria = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.lstMatches = New System.Windows.Forms.ListBox()
        Me.lblMatchesFound = New Infragistics.Win.Misc.UltraLabel()
        Me.cmdCustSave = New Infragistics.Win.Misc.UltraButton()
        Me.cmdSearch = New Infragistics.Win.Misc.UltraButton()
        Me.cmdClear = New Infragistics.Win.Misc.UltraButton()
        Me.ezkbdKeyboard = New EZControls.EZKeyboard()
        Me.cmdCleanDB = New Infragistics.Win.Misc.UltraButton()
        Me.cmdClose = New Infragistics.Win.Misc.UltraButton()
        Me.upbSave = New Infragistics.Win.UltraWinProgressBar.UltraProgressBar()
        Me.cmdGetAll = New Infragistics.Win.Misc.UltraButton()
        Me.cmdExportToExcel = New Infragistics.Win.Misc.UltraButton()
        Me.cmdExportToCSV = New Infragistics.Win.Misc.UltraButton()
        CType(Me.txtCriteria, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblNumRecords
        '
        Me.lblNumRecords.AutoSize = True
        Me.lblNumRecords.BackColor = System.Drawing.Color.Transparent
        Me.lblNumRecords.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNumRecords.ForeColor = System.Drawing.Color.White
        Me.lblNumRecords.Location = New System.Drawing.Point(597, 119)
        Me.lblNumRecords.Name = "lblNumRecords"
        Me.lblNumRecords.Size = New System.Drawing.Size(329, 16)
        Me.lblNumRecords.TabIndex = 499
        Me.lblNumRecords.Text = "There are 250 customer records selected for mailing list"
        '
        'lblShortCode
        '
        Appearance1.BackColor = System.Drawing.Color.Transparent
        Appearance1.ForeColor = System.Drawing.Color.White
        Me.lblShortCode.Appearance = Appearance1
        Me.lblShortCode.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblShortCode.Location = New System.Drawing.Point(75, 65)
        Me.lblShortCode.Name = "lblShortCode"
        Me.lblShortCode.Size = New System.Drawing.Size(200, 17)
        Me.lblShortCode.TabIndex = 522
        Me.lblShortCode.Text = "Enter search term here:"
        Me.lblShortCode.UseAppStyling = False
        '
        'txtCriteria
        '
        Me.txtCriteria.AlwaysInEditMode = True
        Me.txtCriteria.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCriteria.Location = New System.Drawing.Point(75, 88)
        Me.txtCriteria.MaxLength = 100
        Me.txtCriteria.Name = "txtCriteria"
        Me.txtCriteria.Size = New System.Drawing.Size(408, 24)
        Me.txtCriteria.TabIndex = 523
        '
        'lstMatches
        '
        Me.lstMatches.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstMatches.FormattingEnabled = True
        Me.lstMatches.ItemHeight = 16
        Me.lstMatches.Location = New System.Drawing.Point(75, 141)
        Me.lstMatches.Name = "lstMatches"
        Me.lstMatches.Size = New System.Drawing.Size(408, 228)
        Me.lstMatches.TabIndex = 524
        '
        'lblMatchesFound
        '
        Appearance2.BackColor = System.Drawing.Color.Transparent
        Appearance2.ForeColor = System.Drawing.Color.White
        Me.lblMatchesFound.Appearance = Appearance2
        Me.lblMatchesFound.AutoSize = True
        Me.lblMatchesFound.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMatchesFound.Location = New System.Drawing.Point(75, 118)
        Me.lblMatchesFound.Name = "lblMatchesFound"
        Me.lblMatchesFound.Size = New System.Drawing.Size(326, 17)
        Me.lblMatchesFound.TabIndex = 526
        Me.lblMatchesFound.Text = "500 matches have been found (only 50 shown below):"
        Me.lblMatchesFound.UseAppStyling = False
        '
        'cmdCustSave
        '
        Appearance3.BackColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance3.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance3.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance3.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance3.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance3.BorderColor2 = System.Drawing.Color.Maroon
        Appearance3.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance3.ForeColor = System.Drawing.Color.White
        Appearance3.Image = CType(resources.GetObject("Appearance3.Image"), Object)
        Appearance3.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance3.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance3.TextVAlignAsString = "Bottom"
        Me.cmdCustSave.Appearance = Appearance3
        Me.cmdCustSave.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance4.BackColor = System.Drawing.Color.DarkOrange
        Appearance4.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance4.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance4.ForeColor = System.Drawing.Color.Black
        Me.cmdCustSave.HotTrackAppearance = Appearance4
        Me.cmdCustSave.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdCustSave.Location = New System.Drawing.Point(496, 309)
        Me.cmdCustSave.Name = "cmdCustSave"
        Appearance5.BackColor = System.Drawing.Color.OrangeRed
        Appearance5.BackColor2 = System.Drawing.Color.Tomato
        Appearance5.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdCustSave.PressedAppearance = Appearance5
        Me.cmdCustSave.ShowFocusRect = False
        Me.cmdCustSave.ShowOutline = False
        Me.cmdCustSave.Size = New System.Drawing.Size(70, 60)
        Me.cmdCustSave.TabIndex = 527
        Me.cmdCustSave.Tag = "Save"
        Me.cmdCustSave.Text = "Save"
        Me.cmdCustSave.UseAppStyling = False
        Me.cmdCustSave.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdCustSave.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdCustSave.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdSearch
        '
        Appearance6.BackColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance6.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance6.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance6.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance6.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance6.BorderColor2 = System.Drawing.Color.Maroon
        Appearance6.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance6.ForeColor = System.Drawing.Color.White
        Appearance6.Image = CType(resources.GetObject("Appearance6.Image"), Object)
        Appearance6.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance6.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance6.TextVAlignAsString = "Bottom"
        Me.cmdSearch.Appearance = Appearance6
        Me.cmdSearch.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance7.BackColor = System.Drawing.Color.DarkOrange
        Appearance7.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance7.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance7.ForeColor = System.Drawing.Color.Black
        Me.cmdSearch.HotTrackAppearance = Appearance7
        Me.cmdSearch.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdSearch.Location = New System.Drawing.Point(496, 88)
        Me.cmdSearch.Name = "cmdSearch"
        Appearance8.BackColor = System.Drawing.Color.OrangeRed
        Appearance8.BackColor2 = System.Drawing.Color.Tomato
        Appearance8.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdSearch.PressedAppearance = Appearance8
        Me.cmdSearch.ShowFocusRect = False
        Me.cmdSearch.ShowOutline = False
        Me.cmdSearch.Size = New System.Drawing.Size(70, 60)
        Me.cmdSearch.TabIndex = 528
        Me.cmdSearch.Tag = ""
        Me.cmdSearch.Text = "Search"
        Me.cmdSearch.UseAppStyling = False
        Me.cmdSearch.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdSearch.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdSearch.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdClear
        '
        Appearance9.BackColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance9.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance9.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance9.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance9.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance9.BorderColor2 = System.Drawing.Color.Maroon
        Appearance9.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance9.ForeColor = System.Drawing.Color.White
        Appearance9.Image = CType(resources.GetObject("Appearance9.Image"), Object)
        Appearance9.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance9.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance9.TextVAlignAsString = "Bottom"
        Me.cmdClear.Appearance = Appearance9
        Me.cmdClear.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance10.BackColor = System.Drawing.Color.DarkOrange
        Appearance10.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance10.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance10.ForeColor = System.Drawing.Color.Black
        Me.cmdClear.HotTrackAppearance = Appearance10
        Me.cmdClear.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdClear.Location = New System.Drawing.Point(496, 243)
        Me.cmdClear.Name = "cmdClear"
        Appearance11.BackColor = System.Drawing.Color.OrangeRed
        Appearance11.BackColor2 = System.Drawing.Color.Tomato
        Appearance11.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdClear.PressedAppearance = Appearance11
        Me.cmdClear.ShowFocusRect = False
        Me.cmdClear.ShowOutline = False
        Me.cmdClear.Size = New System.Drawing.Size(70, 60)
        Me.cmdClear.TabIndex = 529
        Me.cmdClear.Tag = ""
        Me.cmdClear.Text = "Clear"
        Me.cmdClear.UseAppStyling = False
        Me.cmdClear.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdClear.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdClear.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ezkbdKeyboard
        '
        Me.ezkbdKeyboard.BackColor = System.Drawing.Color.FromArgb(CType(CType(16, Byte), Integer), CType(CType(105, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.ezkbdKeyboard.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ezkbdKeyboard.EZKBBackColor = System.Drawing.Color.Empty
        Me.ezkbdKeyboard.EZKBBorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Me.ezkbdKeyboard.EZKBForeColor = System.Drawing.Color.SteelBlue
        Me.ezkbdKeyboard.ForeColor = System.Drawing.Color.Black
        Me.ezkbdKeyboard.Location = New System.Drawing.Point(99, 409)
        Me.ezkbdKeyboard.Name = "ezkbdKeyboard"
        Me.ezkbdKeyboard.Size = New System.Drawing.Size(802, 285)
        Me.ezkbdKeyboard.TabIndex = 530
        '
        'cmdCleanDB
        '
        Appearance12.BackColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance12.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance12.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance12.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance12.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance12.BorderColor2 = System.Drawing.Color.Maroon
        Appearance12.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance12.ForeColor = System.Drawing.Color.White
        Appearance12.Image = CType(resources.GetObject("Appearance12.Image"), Object)
        Appearance12.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance12.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance12.TextVAlignAsString = "Bottom"
        Me.cmdCleanDB.Appearance = Appearance12
        Me.cmdCleanDB.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance13.BackColor = System.Drawing.Color.DarkOrange
        Appearance13.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance13.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance13.ForeColor = System.Drawing.Color.Black
        Me.cmdCleanDB.HotTrackAppearance = Appearance13
        Me.cmdCleanDB.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdCleanDB.Location = New System.Drawing.Point(678, 243)
        Me.cmdCleanDB.Name = "cmdCleanDB"
        Appearance14.BackColor = System.Drawing.Color.OrangeRed
        Appearance14.BackColor2 = System.Drawing.Color.Tomato
        Appearance14.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdCleanDB.PressedAppearance = Appearance14
        Me.cmdCleanDB.ShowFocusRect = False
        Me.cmdCleanDB.ShowOutline = False
        Me.cmdCleanDB.Size = New System.Drawing.Size(70, 60)
        Me.cmdCleanDB.TabIndex = 531
        Me.cmdCleanDB.Tag = ""
        Me.cmdCleanDB.Text = "Clean DB"
        Me.cmdCleanDB.UseAppStyling = False
        Me.cmdCleanDB.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdCleanDB.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdCleanDB.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdClose
        '
        Appearance15.BackColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance15.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance15.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance15.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance15.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance15.BorderColor2 = System.Drawing.Color.Maroon
        Appearance15.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance15.ForeColor = System.Drawing.Color.White
        Appearance15.Image = CType(resources.GetObject("Appearance15.Image"), Object)
        Appearance15.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance15.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance15.TextVAlignAsString = "Bottom"
        Me.cmdClose.Appearance = Appearance15
        Me.cmdClose.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance16.BackColor = System.Drawing.Color.DarkOrange
        Appearance16.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance16.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance16.ForeColor = System.Drawing.Color.Black
        Me.cmdClose.HotTrackAppearance = Appearance16
        Me.cmdClose.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdClose.Location = New System.Drawing.Point(678, 309)
        Me.cmdClose.Name = "cmdClose"
        Appearance17.BackColor = System.Drawing.Color.OrangeRed
        Appearance17.BackColor2 = System.Drawing.Color.Tomato
        Appearance17.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdClose.PressedAppearance = Appearance17
        Me.cmdClose.ShowFocusRect = False
        Me.cmdClose.ShowOutline = False
        Me.cmdClose.Size = New System.Drawing.Size(70, 60)
        Me.cmdClose.TabIndex = 532
        Me.cmdClose.Tag = ""
        Me.cmdClose.Text = "Return"
        Me.cmdClose.UseAppStyling = False
        Me.cmdClose.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdClose.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdClose.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'upbSave
        '
        Me.upbSave.Location = New System.Drawing.Point(600, 154)
        Me.upbSave.Name = "upbSave"
        Me.upbSave.Size = New System.Drawing.Size(326, 23)
        Me.upbSave.TabIndex = 533
        Me.upbSave.Text = "Saving:  [Formatted] done"
        Me.upbSave.Visible = False
        '
        'cmdGetAll
        '
        Appearance18.BackColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance18.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance18.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance18.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance18.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance18.BorderColor2 = System.Drawing.Color.Maroon
        Appearance18.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance18.ForeColor = System.Drawing.Color.White
        Appearance18.Image = CType(resources.GetObject("Appearance18.Image"), Object)
        Appearance18.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance18.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance18.TextVAlignAsString = "Bottom"
        Me.cmdGetAll.Appearance = Appearance18
        Me.cmdGetAll.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance19.BackColor = System.Drawing.Color.DarkOrange
        Appearance19.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance19.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance19.ForeColor = System.Drawing.Color.Black
        Me.cmdGetAll.HotTrackAppearance = Appearance19
        Me.cmdGetAll.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdGetAll.Location = New System.Drawing.Point(496, 154)
        Me.cmdGetAll.Name = "cmdGetAll"
        Appearance20.BackColor = System.Drawing.Color.OrangeRed
        Appearance20.BackColor2 = System.Drawing.Color.Tomato
        Appearance20.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdGetAll.PressedAppearance = Appearance20
        Me.cmdGetAll.ShowFocusRect = False
        Me.cmdGetAll.ShowOutline = False
        Me.cmdGetAll.Size = New System.Drawing.Size(70, 60)
        Me.cmdGetAll.TabIndex = 534
        Me.cmdGetAll.Tag = ""
        Me.cmdGetAll.Text = "Get All"
        Me.cmdGetAll.UseAppStyling = False
        Me.cmdGetAll.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdGetAll.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdGetAll.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdExportToExcel
        '
        Appearance21.BackColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance21.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance21.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance21.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance21.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance21.BorderColor2 = System.Drawing.Color.Maroon
        Appearance21.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance21.ForeColor = System.Drawing.Color.White
        Appearance21.Image = CType(resources.GetObject("Appearance21.Image"), Object)
        Appearance21.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance21.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance21.TextVAlignAsString = "Bottom"
        Me.cmdExportToExcel.Appearance = Appearance21
        Me.cmdExportToExcel.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance22.BackColor = System.Drawing.Color.DarkOrange
        Appearance22.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance22.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance22.ForeColor = System.Drawing.Color.Black
        Appearance22.Image = CType(resources.GetObject("Appearance22.Image"), Object)
        Me.cmdExportToExcel.HotTrackAppearance = Appearance22
        Me.cmdExportToExcel.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdExportToExcel.Location = New System.Drawing.Point(572, 243)
        Me.cmdExportToExcel.Name = "cmdExportToExcel"
        Appearance23.BackColor = System.Drawing.Color.OrangeRed
        Appearance23.BackColor2 = System.Drawing.Color.Tomato
        Appearance23.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance23.Image = CType(resources.GetObject("Appearance23.Image"), Object)
        Me.cmdExportToExcel.PressedAppearance = Appearance23
        Me.cmdExportToExcel.ShowFocusRect = False
        Me.cmdExportToExcel.ShowOutline = False
        Me.cmdExportToExcel.Size = New System.Drawing.Size(100, 60)
        Me.cmdExportToExcel.TabIndex = 535
        Me.cmdExportToExcel.Tag = ""
        Me.cmdExportToExcel.Text = "Export To Excel"
        Me.cmdExportToExcel.UseAppStyling = False
        Me.cmdExportToExcel.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdExportToExcel.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdExportToExcel.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdExportToCSV
        '
        Appearance24.BackColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance24.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(165, Byte), Integer))
        Appearance24.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance24.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance24.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance24.BorderColor2 = System.Drawing.Color.Maroon
        Appearance24.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance24.ForeColor = System.Drawing.Color.White
        Appearance24.Image = CType(resources.GetObject("Appearance24.Image"), Object)
        Appearance24.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance24.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance24.TextVAlignAsString = "Bottom"
        Me.cmdExportToCSV.Appearance = Appearance24
        Me.cmdExportToCSV.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance25.BackColor = System.Drawing.Color.DarkOrange
        Appearance25.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance25.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance25.ForeColor = System.Drawing.Color.Black
        Appearance25.Image = CType(resources.GetObject("Appearance25.Image"), Object)
        Me.cmdExportToCSV.HotTrackAppearance = Appearance25
        Me.cmdExportToCSV.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdExportToCSV.Location = New System.Drawing.Point(572, 309)
        Me.cmdExportToCSV.Name = "cmdExportToCSV"
        Appearance26.BackColor = System.Drawing.Color.OrangeRed
        Appearance26.BackColor2 = System.Drawing.Color.Tomato
        Appearance26.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance26.Image = CType(resources.GetObject("Appearance26.Image"), Object)
        Me.cmdExportToCSV.PressedAppearance = Appearance26
        Me.cmdExportToCSV.ShowFocusRect = False
        Me.cmdExportToCSV.ShowOutline = False
        Me.cmdExportToCSV.Size = New System.Drawing.Size(100, 60)
        Me.cmdExportToCSV.TabIndex = 536
        Me.cmdExportToCSV.Tag = ""
        Me.cmdExportToCSV.Text = "Export To CSV"
        Me.cmdExportToCSV.UseAppStyling = False
        Me.cmdExportToCSV.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdExportToCSV.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdExportToCSV.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'frmCustomerMailing
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.Color.SteelBlue
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1000, 730)
        Me.ControlBox = False
        Me.Controls.Add(Me.cmdExportToCSV)
        Me.Controls.Add(Me.cmdExportToExcel)
        Me.Controls.Add(Me.cmdGetAll)
        Me.Controls.Add(Me.upbSave)
        Me.Controls.Add(Me.cmdClose)
        Me.Controls.Add(Me.cmdCleanDB)
        Me.Controls.Add(Me.ezkbdKeyboard)
        Me.Controls.Add(Me.cmdClear)
        Me.Controls.Add(Me.cmdSearch)
        Me.Controls.Add(Me.cmdCustSave)
        Me.Controls.Add(Me.lblMatchesFound)
        Me.Controls.Add(Me.lblShortCode)
        Me.Controls.Add(Me.txtCriteria)
        Me.Controls.Add(Me.lstMatches)
        Me.Controls.Add(Me.lblNumRecords)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "frmCustomerMailing"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        CType(Me.txtCriteria, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblNumRecords As System.Windows.Forms.Label
    Friend WithEvents lblShortCode As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents txtCriteria As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents lstMatches As System.Windows.Forms.ListBox
    Friend WithEvents lblMatchesFound As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents cmdCustSave As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdSearch As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdClear As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ezkbdKeyboard As EZControls.EZKeyboard
    Friend WithEvents cmdCleanDB As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdClose As Infragistics.Win.Misc.UltraButton
    Friend WithEvents upbSave As Infragistics.Win.UltraWinProgressBar.UltraProgressBar
    Friend WithEvents cmdGetAll As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdExportToExcel As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdExportToCSV As Infragistics.Win.Misc.UltraButton
End Class
