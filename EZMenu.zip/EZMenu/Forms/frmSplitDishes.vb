﻿Imports Infragistics.Win.UltraWinDataSource
Imports Infragistics.Win.UltraWinGrid
Imports Infragistics.Win.Misc

Public Class frmSplitDishes

    Private intQty As Short
    Private tempStr As String
    Private ugdSplitDishes As UltraGrid
    Private gridRowIndex As Integer

    Public WriteOnly Property DishArray As UltraGrid

        Set(value As UltraGrid)
            ugdSplitDishes = value
        End Set

    End Property

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Try
            ugdMain.DisplayLayout.Override.MinRowHeight = 30
            ug1.DisplayLayout.Override.MinRowHeight = 30
            ug2.DisplayLayout.Override.MinRowHeight = 30

            With ugdMain.DisplayLayout.Bands(0)
                .Columns("DQty").Width = 42
                .Columns("DName").Width = 180
                .Columns("Total").Width = 50
            End With
            With ug1.DisplayLayout.Bands(0)
                .Columns("DQty").Width = ugdMain.DisplayLayout.Bands(0).Columns("DQty").Width
                .Columns("DName").Width = ugdMain.DisplayLayout.Bands(0).Columns("DName").Width
                .Columns("Total").Width = ugdMain.DisplayLayout.Bands(0).Columns("Total").Width
            End With
            With ug2.DisplayLayout.Bands(0)
                .Columns("DQty").Width = ugdMain.DisplayLayout.Bands(0).Columns("DQty").Width
                .Columns("DName").Width = ugdMain.DisplayLayout.Bands(0).Columns("DName").Width
                .Columns("Total").Width = ugdMain.DisplayLayout.Bands(0).Columns("Total").Width
            End With

            With ugdSplitDishes
                For Each mRow In .Rows
                    gridRowIndex = mRow.Index
                    Dim udrRow As UltraDataRow = udsOrder.Rows.Add
                    udrRow.Item("DCode") = .Rows(gridRowIndex).Cells("DCode").Value
                    udrRow.Item("DName") = .Rows(gridRowIndex).Cells("DName").Value
                    udrRow.Item("DPrice") = .Rows(gridRowIndex).Cells("DPrice").Value
                    udrRow.Item("DQty") = .Rows(gridRowIndex).Cells("DQty").Value
                    udrRow.Item("Total") = .Rows(gridRowIndex).Cells("Total").Value
                    udrRow.Item("GroupIndex") = .Rows(gridRowIndex).Cells("GroupIndex").Value
                Next
            End With

            DoTotals()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub AddToGrids(sender As Object, e As EventArgs)

        If ugdMain.ActiveRow IsNot Nothing Then
            Dim udsTemp As UltraDataSource = Nothing
            Dim ugdTemp As UltraGrid = Nothing

            If sender.name = "cmdGrid1AddN" Then
                udsTemp = uds1 : ugdTemp = ug1
            Else
                udsTemp = uds2 : ugdTemp = ug2
            End If

            Dim intPosition As Short = 0

            If UpdateItemInGrid(ugdMain.ActiveRow.Cells("DName").Value, ugdMain.ActiveRow.Cells("DQty").Value, ugdTemp) = False Then

                'find the correct dish position
                If ugdTemp.Rows.Count > 0 Then
                    intPosition = DishPosition(ugdMain.ActiveRow.Cells("DCode").Value, ugdMain.ActiveRow.Cells("GroupIndex").Value, ugdTemp)
                End If

                Dim myRow As UltraDataRow = udsTemp.Rows.Insert(intPosition)
                myRow.Item("DCode") = ugdMain.ActiveRow.Cells("DCode").Value
                myRow.Item("DName") = ugdMain.ActiveRow.Cells("DName").Value
                myRow.Item("DPrice") = ugdMain.ActiveRow.Cells("DPrice").Value
                myRow.Item("DQty") = ugdMain.ActiveRow.Cells("DQty").Value
                myRow.Item("Total") = ugdMain.ActiveRow.Cells("Total").Value
                myRow.Item("GroupIndex") = ugdMain.ActiveRow.Cells("GroupIndex").Value
            End If
            ugdTemp.DataSource = udsTemp
            ugdMain.ActiveRow.Delete(False)
            If ugdTemp.Rows.Count > 0 Then ugdTemp.Rows(intPosition).Activate()
            UpdateRowTotal(ugdTemp)
            DoTotals()
            If ugdMain.Rows.Count > 0 Then ugdMain.Rows(intPosition).Activate()

        Else

            If ugdMain.Rows.Count > 0 Then
                MsgBox("No active row set")
            Else
                MsgBox("There are no more items")
            End If

        End If

    End Sub

    Private Sub RemoveItem(sender As Object, e As EventArgs) Handles cmdRemove1.Click, cmdRemove2.Click

        Dim udsTemp As UltraDataSource
        Dim ugdTemp As UltraGrid

        If sender.name = "cmdRemove1" Then
            udsTemp = uds1 : ugdTemp = ug1
        Else
            udsTemp = uds2 : ugdTemp = ug2
        End If

        Dim intPosition As Short = 0
        'find the correct dish position
        If ugdTemp.Rows.Count > 0 Then
            intPosition = DishPosition(ugdTemp.ActiveRow.Cells("DCode").Value,
                                       ugdTemp.ActiveRow.Cells("GroupIndex").Value, ugdMain)
        End If

        If ugdTemp.ActiveRow IsNot Nothing Then
            If UpdateItemInGrid(ugdTemp.ActiveRow.Cells("DName").Value, ugdTemp.ActiveRow.Cells("DQty").Value, ugdMain) = False Then
                Dim myRow As UltraDataRow = udsOrder.Rows.Insert(intPosition)
                myRow.Item("DCode") = ugdTemp.ActiveRow.Cells("DCode").Value
                myRow.Item("DName") = ugdTemp.ActiveRow.Cells("DName").Value
                myRow.Item("DPrice") = ugdTemp.ActiveRow.Cells("DPrice").Value
                myRow.Item("DQty") = ugdTemp.ActiveRow.Cells("DQty").Value
                myRow.Item("Total") = ugdTemp.ActiveRow.Cells("Total").Value
                myRow.Item("GroupIndex") = ugdTemp.ActiveRow.Cells("GroupIndex").Value
                ugdMain.DataSource = udsOrder
                ugdMain.Rows(intPosition).Activate()
            End If
            ugdTemp.ActiveRow.Delete(False)
            DoTotals()
        Else
            If ugdTemp.Rows.Count > 0 Then
                MsgBox("First select item to remove")
            Else
                'MsgBox("There are no more items")
            End If
        End If

        If ugdTemp.Rows.Count > 0 Then ugdTemp.Rows(0).Activate()

    End Sub

    Private Sub DoTotals()

        'first the main grid
        Dim total As Decimal

        lblDetails.Visible = False

        With ugdMain
            For Each mrow In .Rows
                gridRowIndex = mrow.Index
                total += .Rows(gridRowIndex).Cells("Total").Value
            Next
        End With
        txtMain.Text = Format(total, "#0.00")

        total = 0
        With ug1
            For Each mrow In .Rows
                gridRowIndex = mrow.Index
                total += .Rows(gridRowIndex).Cells("Total").Value
            Next
        End With
        txt1.Text = Format(total, "#0.00")

        total = 0
        With ug2
            For Each mrow In .Rows
                gridRowIndex = mrow.Index
                total += .Rows(gridRowIndex).Cells("Total").Value
            Next
        End With
        txt2.Text = Format(total, "#0.00")

        If CDec(objOrderEntry.lblSubtotal.Text) <> CDec(txt1.Text) + CDec(txt2.Text) Then
            If ugdMain.Rows.Count = 0 AndAlso (ug1.Rows.Count > 0 Or ug2.Rows.Count > 0) Then
                lblDetails.Text = "Original bill total: " & objOrderEntry.lblSubtotal.Text
                lblDetails.Text &= vbCrLf & "Both split totals: " & CDec(txt1.Text) + CDec(txt2.Text)
                lblDetails.Visible = True
            End If
        End If

    End Sub

    Private Sub UpdateRowTotal(ugdGridName As UltraGrid)

        If ugdGridName.ActiveRow IsNot Nothing Then
            ugdGridName.ActiveRow.Cells("Total").Value = ugdGridName.ActiveRow.Cells("DPrice").Value * ugdGridName.ActiveRow.Cells("DQty").Value
        End If

    End Sub

    Private Sub cmdBack_Click(sender As Object, e As EventArgs) Handles cmdBack.Click

        Close()

    End Sub

    Private Sub UltraButton1_Click(sender As Object, e As EventArgs) Handles cmdGrid1Add1.Click, cmdGrid1AddN.Click, cmdGrid2Add1.Click, cmdGrid2AddN.Click

        Dim btnSender As UltraButton = CType(sender, UltraButton)
        Dim blnDeleteRow As Boolean = False

        If ugdMain.ActiveRow Is Nothing AndAlso ugdMain.Rows.Count > 0 Then
            ugdMain.ActiveRow = ugdMain.Rows(0)
        End If

        If ugdMain.ActiveRow IsNot Nothing Then
            Dim udsTemp As UltraDataSource = Nothing
            Dim ugdTemp As UltraGrid = Nothing
            Dim intPosition As Short = 0
            Dim intMainPosition As Short = ugdMain.ActiveRow.Index

            If btnSender.Name = "cmdGrid1Add1" Or btnSender.Name = "cmdGrid1AddN" Then
                udsTemp = uds1 : ugdTemp = ug1
            Else
                udsTemp = uds2 : ugdTemp = ug2
            End If

            Dim intQQty As Short = IIf(btnSender.Name.ToString.Contains("Add1"), 1, ugdMain.ActiveRow.Cells("DQty").Value)

            If ugdMain.ActiveRow.Cells("DQty").Value > 1 AndAlso btnSender.Name.ToString.Contains("Add1") Then
                ugdMain.ActiveRow.Cells("DQty").Value -= 1
            Else
                blnDeleteRow = True
            End If

            If UpdateItemInGrid(ugdMain.ActiveRow.Cells("DName").Value, intQQty, ugdTemp) = False Then
                'find the correct dish position
                If ugdTemp.Rows.Count > 0 Then
                    intPosition = DishPosition(ugdMain.ActiveRow.Cells("DCode").Value, ugdMain.ActiveRow.Cells("GroupIndex").Value, ugdTemp)
                End If
                Dim myRow As UltraDataRow = udsTemp.Rows.Insert(intPosition)
                myRow.Item("DCode") = ugdMain.ActiveRow.Cells("DCode").Value
                myRow.Item("DName") = ugdMain.ActiveRow.Cells("DName").Value
                myRow.Item("DPrice") = ugdMain.ActiveRow.Cells("DPrice").Value
                myRow.Item("DQty") = intQQty
                myRow.Item("Total") = myRow.Item("DPrice") * myRow.Item("DQty")
                myRow.Item("GroupIndex") = ugdMain.ActiveRow.Cells("GroupIndex").Value
            End If

            ugdTemp.DataSource = udsTemp
            ugdTemp.ActiveRow = ugdTemp.Rows(intPosition)
            If blnDeleteRow Then ugdMain.ActiveRow.Delete(False)
            UpdateRowTotal(ugdMain)
            UpdateRowTotal(ugdTemp)
            DoTotals()
            If ugdMain.Rows.Count > 0 AndAlso blnDeleteRow Then
                ugdMain.Rows(0).Activate()
            End If
        End If

    End Sub

    Private Function UpdateItemInGrid(strDishToUpgrade As String, intQQty As Short, ugdGrid2Check As UltraGrid) As Boolean
        'returns True if strDishToUpgrade found in grid and updated

        With ugdGrid2Check
            If .Rows.Count > 0 Then
                For Each mRow In .Rows
                    gridRowIndex = mRow.Index
                    tempStr = .Rows(gridRowIndex).Cells("DName").Value.ToString.Trim
                    If strDishToUpgrade.ToUpper = tempStr.ToUpper Then
                        .Rows(gridRowIndex).Cells("DQty").Value = .Rows(gridRowIndex).Cells("DQty").Value + intQQty
                        .Rows(gridRowIndex).Cells("Total").Value = fixCur(.Rows(gridRowIndex).Cells("DPrice").Value * .Rows(gridRowIndex).Cells("DQty").Value)
                        .Update()
                        UpdateRowTotal(ugdGrid2Check)
                        .Rows(gridRowIndex).Activate()
                        Return True
                    End If
                Next
            End If
        End With

        Return False

    End Function

    Public Function fixCur(ByRef CurToFix) As String

        If IsDBNull(CurToFix) Then CurToFix = 0

        If Decimal.TryParse(CurToFix, 0) = True Then
            CurToFix = Decimal.Parse(CurToFix)
        End If

        Return Format(CurToFix, "#0.00")

    End Function

    Private Function DishPosition(ByRef CurDishCode, ByRef CurGroupCode, ByRef ugdDestGrid)

        Dim tempCode, tempGroup, tempPos As Integer
        Dim mrow As UltraGridRow

        tempPos = ugdDestGrid.Rows.Count

        If CStr(CurDishCode) <> String.Empty Then
            'find position with group index
            With ugdDestGrid
                For Each mrow In .Rows
                    gridRowIndex = mrow.Index
                    tempGroup = .Rows(gridRowIndex).Cells("GroupIndex").Value()
                    If tempGroup = CurGroupCode AndAlso .Rows(gridRowIndex).Cells("DCode").Value() <> String.Empty Then
                        'find position within its group now, according to dish code
                        tempCode = .Rows(gridRowIndex).Cells("DCode").Value()
                        If (tempCode > Val(CurDishCode)) Then
                            Return gridRowIndex
                        End If
                    ElseIf tempGroup > CurGroupCode Then
                        Return gridRowIndex
                    End If
                Next
            End With
        End If

        Return tempPos

    End Function

End Class