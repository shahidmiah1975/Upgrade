﻿Public Class frmRegister

    Private Sub frmRegister_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        tempStr = "You need to register this software to use it. Once you provide us a challenge code, " &
                  "you will be given a response code which will unlock the software. You can continue " &
                  "to try the software without a code but printing will be disabled and a limited number " &
                  "of orders will be saved to the database."
        lblInfo.Text = tempStr

        txtChallenge.Mask = $">AAAA - AAAA - AAAA - AAAA - AAAA - AAAA - AAAA - AAAA"
        txtResponse.Mask = $">AAAA - AAAA - AAAA - AAAA - AAAA - AAAA - AAAA - AAAA - AAAA"

        txtChallenge.Text = objSecurity.PadMD5Result(objSecurity.MD5Hash(GetWMIValue()))
        txtBizName.Text = GetAppSettingCS("BizName", "")

    End Sub

    Private Function CalcResponseCode() As String

        Dim alphanum As String = $"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
        Dim strNew = ""

        If txtChallenge.Text <> "" Then
            tempStr = Replace(Replace(txtChallenge.Text, " ", ""), "-", "")
            tempStr = objSecurity.AES_Encrypt(objSecurity.MD5Hash(tempStr))
            For iCnt As Short = 0 To tempStr.Length - 1
                Dim spChar As String = tempStr.Substring(iCnt, 1)
                If InStr(alphanum, spChar, CompareMethod.Text) > 0 Then
                    strNew &= spChar
                End If
            Next
        End If

        Return strNew.ToUpper.Substring(0, 36)

    End Function

    Private Sub cmdOK_Click(sender As Object, e As EventArgs) Handles cmdOK.Click

        Dim strChallenge, strResponse As String

        Try
            txtBizName.Text = txtBizName.Text.Trim
            If txtBizName.Text = String.Empty Then
                strMsgBox = "You must provide your business name."
                Alert(strMsgBox)
            Else
                SaveAppSetting("BizName", txtBizName.Text.Trim)
                strChallenge = CalcResponseCode()
                strResponse = Replace(Replace(txtResponse.Text.ToUpper, " ", ""), "-", "")
                If strChallenge = strResponse Then
                    objDB.EZSettingWrite("RegistrationStatus", objSecurity.AES_Encrypt("AppIsRegistered"))
                    objDB.EZSettingWrite("SerialNumber", objSecurity.MD5Hash_ThenSplitAndSwap(txtBizName.Text))
                    objSecurity.SaveHardwareIDs()
                    Hide()
                    strMsgBox = "Code accepted." & vbCrLf & "EZ-Menu is now unlocked."
                    Alert(strMsgBox)
                    Close()
                Else
                    strMsgBox = "Invalid code entered"
                    Alert(strMsgBox)
                End If
            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub txtResponse_TextChanged(sender As Object, e As EventArgs) Handles txtResponse.TextChanged
        cmdOK.Enabled = txtResponse.MaskCompleted
    End Sub

    Private Sub cmdQuit_Click(sender As Object, e As EventArgs) Handles cmdQuit.Click
        Close()
    End Sub

    Private Sub cmdShowKB_Click(sender As Object, e As EventArgs) Handles cmdShowKB.Click

        tempStr = EZFullKeyboard.Show()
        If tempStr <> EZKBEscape Then
            txtResponse.Text = tempStr
        End If

    End Sub

    Private Sub cmdUpperLowerCase_Click(sender As Object, e As EventArgs) Handles cmdUpperLowerCase.Click

        If txtChallenge.Mask.IndexOf(">", StringComparison.Ordinal) <> -1 Then
            txtChallenge.Mask = Replace(txtChallenge.Mask, ">", "<")
        Else
            txtChallenge.Mask = Replace(txtChallenge.Mask, "<", ">")
        End If

    End Sub

    Private Sub cmdUnlockOnline_Click(sender As Object, e As EventArgs) Handles cmdUnlockOnline.Click

        Try

            Dim conn As New EZService.ConnectivityService

            If conn.IsInternetAvailable() Then
                Dim blnIsActivated As Boolean = True
                If blnIsActivated = True Then
                    Dim strResponseCode As String = CalcResponseCode()
                    txtResponse.Text = strResponseCode
                Else
                    strMsgBox = "Unlocking details are not available for this system. You are using an unlicensed copy of EZ-Menu."
                    Alert(strMsgBox)
                End If

            Else
                strMsgBox = "Internet connection could not be detected."
                Alert(strMsgBox, MessageBoxIcon.Error)
            End If

            conn = Nothing

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

End Class