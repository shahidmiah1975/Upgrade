﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSplitDishes
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim Appearance1 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance2 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance3 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance4 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance5 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance6 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance7 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance8 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraGridBand1 As Infragistics.Win.UltraWinGrid.UltraGridBand = New Infragistics.Win.UltraWinGrid.UltraGridBand("Band 0", -1)
        Dim UltraGridColumn1 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("DCode")
        Dim UltraGridColumn2 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("DName")
        Dim UltraGridColumn3 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("DPrice")
        Dim UltraGridColumn4 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("DQty")
        Dim UltraGridColumn5 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Total")
        Dim Appearance9 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraGridColumn6 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Mods")
        Dim UltraGridColumn7 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Discountable")
        Dim UltraGridColumn8 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("IsStarter")
        Dim UltraGridColumn9 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("OriPrice")
        Dim UltraGridColumn10 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("PriceIn")
        Dim UltraGridColumn11 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("PriceOut")
        Dim UltraGridColumn12 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("GroupIndex")
        Dim UltraGridColumn13 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("HiLite")
        Dim Appearance10 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance11 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance12 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance13 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance14 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance15 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance16 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance17 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance18 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance19 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance20 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance21 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraDataColumn1 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("DCode")
        Dim UltraDataColumn2 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("DName")
        Dim UltraDataColumn3 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("DPrice")
        Dim UltraDataColumn4 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("DQty")
        Dim UltraDataColumn5 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("Total")
        Dim UltraDataColumn6 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("Mods")
        Dim UltraDataColumn7 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("Discountable")
        Dim UltraDataColumn8 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("IsStarter")
        Dim UltraDataColumn9 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("OriPrice")
        Dim UltraDataColumn10 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("PriceIn")
        Dim UltraDataColumn11 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("PriceOut")
        Dim UltraDataColumn12 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("GroupIndex")
        Dim UltraDataColumn13 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("HiLite")
        Dim Appearance22 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance23 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance24 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance25 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance26 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance27 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance28 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance29 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance30 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance31 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance32 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraGridBand2 As Infragistics.Win.UltraWinGrid.UltraGridBand = New Infragistics.Win.UltraWinGrid.UltraGridBand("Band 0", -1)
        Dim UltraGridColumn14 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("DCode")
        Dim UltraGridColumn15 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("DName")
        Dim UltraGridColumn16 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("DPrice")
        Dim UltraGridColumn17 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("DQty")
        Dim UltraGridColumn18 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Total")
        Dim Appearance33 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraGridColumn19 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Mods")
        Dim UltraGridColumn20 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Discountable")
        Dim UltraGridColumn21 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("IsStarter")
        Dim UltraGridColumn22 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("OriPrice")
        Dim UltraGridColumn23 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("PriceIn")
        Dim UltraGridColumn24 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("PriceOut")
        Dim UltraGridColumn25 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("GroupIndex")
        Dim UltraGridColumn26 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("HiLite")
        Dim Appearance34 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance35 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance36 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance37 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance38 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance39 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance40 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance41 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance42 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance43 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance44 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance45 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraDataColumn14 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("DCode")
        Dim UltraDataColumn15 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("DName")
        Dim UltraDataColumn16 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("DPrice")
        Dim UltraDataColumn17 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("DQty")
        Dim UltraDataColumn18 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("Total")
        Dim UltraDataColumn19 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("Mods")
        Dim UltraDataColumn20 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("Discountable")
        Dim UltraDataColumn21 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("IsStarter")
        Dim UltraDataColumn22 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("OriPrice")
        Dim UltraDataColumn23 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("PriceIn")
        Dim UltraDataColumn24 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("PriceOut")
        Dim UltraDataColumn25 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("GroupIndex")
        Dim UltraDataColumn26 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("HiLite")
        Dim Appearance46 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance47 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance48 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance49 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance50 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance51 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance52 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance53 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance54 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance55 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance56 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraGridBand3 As Infragistics.Win.UltraWinGrid.UltraGridBand = New Infragistics.Win.UltraWinGrid.UltraGridBand("Band 0", -1)
        Dim UltraGridColumn27 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("DCode")
        Dim UltraGridColumn28 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("DName")
        Dim UltraGridColumn29 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("DPrice")
        Dim UltraGridColumn30 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("DQty")
        Dim UltraGridColumn31 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Total")
        Dim Appearance57 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraGridColumn32 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Mods")
        Dim UltraGridColumn33 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Discountable")
        Dim UltraGridColumn34 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("IsStarter")
        Dim UltraGridColumn35 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("OriPrice")
        Dim UltraGridColumn36 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("PriceIn")
        Dim UltraGridColumn37 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("PriceOut")
        Dim UltraGridColumn38 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("GroupIndex")
        Dim UltraGridColumn39 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("HiLite")
        Dim Appearance58 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance59 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance60 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance61 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance62 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance63 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance64 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance65 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance66 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance67 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance68 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance69 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraDataColumn27 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("DCode")
        Dim UltraDataColumn28 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("DName")
        Dim UltraDataColumn29 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("DPrice")
        Dim UltraDataColumn30 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("DQty")
        Dim UltraDataColumn31 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("Total")
        Dim UltraDataColumn32 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("Mods")
        Dim UltraDataColumn33 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("Discountable")
        Dim UltraDataColumn34 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("IsStarter")
        Dim UltraDataColumn35 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("OriPrice")
        Dim UltraDataColumn36 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("PriceIn")
        Dim UltraDataColumn37 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("PriceOut")
        Dim UltraDataColumn38 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("GroupIndex")
        Dim UltraDataColumn39 As Infragistics.Win.UltraWinDataSource.UltraDataColumn = New Infragistics.Win.UltraWinDataSource.UltraDataColumn("HiLite")
        Dim Appearance70 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance71 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance72 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance73 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Me.UltraLabel1 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel2 = New Infragistics.Win.Misc.UltraLabel()
        Me.UltraLabel3 = New Infragistics.Win.Misc.UltraLabel()
        Me.txtMain = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txt1 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.txt2 = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.upnlMain = New Infragistics.Win.Misc.UltraPanel()
        Me.ugdMain = New Infragistics.Win.UltraWinGrid.UltraGrid()
        Me.udsOrder = New Infragistics.Win.UltraWinDataSource.UltraDataSource(Me.components)
        Me.upnl1 = New Infragistics.Win.Misc.UltraPanel()
        Me.cmdRemove1 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdGrid1Add1 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdGrid1AddN = New Infragistics.Win.Misc.UltraButton()
        Me.ug1 = New Infragistics.Win.UltraWinGrid.UltraGrid()
        Me.uds1 = New Infragistics.Win.UltraWinDataSource.UltraDataSource(Me.components)
        Me.upnl2 = New Infragistics.Win.Misc.UltraPanel()
        Me.cmdRemove2 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdGrid2Add1 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdGrid2AddN = New Infragistics.Win.Misc.UltraButton()
        Me.ug2 = New Infragistics.Win.UltraWinGrid.UltraGrid()
        Me.uds2 = New Infragistics.Win.UltraWinDataSource.UltraDataSource(Me.components)
        Me.cmdBack = New Infragistics.Win.Misc.UltraButton()
        Me.lblDetails = New Infragistics.Win.Misc.UltraLabel()
        CType(Me.txtMain, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txt1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txt2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.upnlMain.ClientArea.SuspendLayout()
        Me.upnlMain.SuspendLayout()
        CType(Me.ugdMain, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.udsOrder, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.upnl1.ClientArea.SuspendLayout()
        Me.upnl1.SuspendLayout()
        CType(Me.ug1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.uds1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.upnl2.ClientArea.SuspendLayout()
        Me.upnl2.SuspendLayout()
        CType(Me.ug2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.uds2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'UltraLabel1
        '
        Appearance1.ForeColor = System.Drawing.Color.LavenderBlush
        Appearance1.TextHAlignAsString = "Center"
        Me.UltraLabel1.Appearance = Appearance1
        Me.UltraLabel1.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UltraLabel1.Location = New System.Drawing.Point(16, 16)
        Me.UltraLabel1.Name = "UltraLabel1"
        Me.UltraLabel1.Size = New System.Drawing.Size(282, 18)
        Me.UltraLabel1.TabIndex = 80
        Me.UltraLabel1.Text = "MAIN"
        Me.UltraLabel1.UseAppStyling = False
        '
        'UltraLabel2
        '
        Appearance2.ForeColor = System.Drawing.Color.LavenderBlush
        Appearance2.TextHAlignAsString = "Center"
        Me.UltraLabel2.Appearance = Appearance2
        Me.UltraLabel2.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UltraLabel2.Location = New System.Drawing.Point(304, 16)
        Me.UltraLabel2.Name = "UltraLabel2"
        Me.UltraLabel2.Size = New System.Drawing.Size(282, 18)
        Me.UltraLabel2.TabIndex = 81
        Me.UltraLabel2.Text = "SPLIT 1"
        Me.UltraLabel2.UseAppStyling = False
        '
        'UltraLabel3
        '
        Appearance3.ForeColor = System.Drawing.Color.LavenderBlush
        Appearance3.TextHAlignAsString = "Center"
        Me.UltraLabel3.Appearance = Appearance3
        Me.UltraLabel3.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UltraLabel3.Location = New System.Drawing.Point(592, 16)
        Me.UltraLabel3.Name = "UltraLabel3"
        Me.UltraLabel3.Size = New System.Drawing.Size(282, 18)
        Me.UltraLabel3.TabIndex = 82
        Me.UltraLabel3.Text = "SPLIT 2"
        Me.UltraLabel3.UseAppStyling = False
        '
        'txtMain
        '
        Appearance4.BackColor = System.Drawing.Color.LavenderBlush
        Appearance4.BorderColor = System.Drawing.Color.Navy
        Appearance4.TextHAlignAsString = "Right"
        Me.txtMain.Appearance = Appearance4
        Me.txtMain.BackColor = System.Drawing.Color.LavenderBlush
        Me.txtMain.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Me.txtMain.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMain.Location = New System.Drawing.Point(8, 436)
        Me.txtMain.Name = "txtMain"
        Me.txtMain.Size = New System.Drawing.Size(263, 25)
        Me.txtMain.TabIndex = 83
        Me.txtMain.UseAppStyling = False
        Me.txtMain.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txt1
        '
        Appearance5.BackColor = System.Drawing.Color.LavenderBlush
        Appearance5.BorderColor = System.Drawing.Color.Navy
        Appearance5.TextHAlignAsString = "Right"
        Me.txt1.Appearance = Appearance5
        Me.txt1.BackColor = System.Drawing.Color.LavenderBlush
        Me.txt1.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Me.txt1.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt1.Location = New System.Drawing.Point(8, 436)
        Me.txt1.Name = "txt1"
        Me.txt1.Size = New System.Drawing.Size(263, 25)
        Me.txt1.TabIndex = 84
        Me.txt1.UseAppStyling = False
        Me.txt1.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'txt2
        '
        Appearance6.BackColor = System.Drawing.Color.LavenderBlush
        Appearance6.BorderColor = System.Drawing.Color.Navy
        Appearance6.TextHAlignAsString = "Right"
        Me.txt2.Appearance = Appearance6
        Me.txt2.BackColor = System.Drawing.Color.LavenderBlush
        Me.txt2.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Me.txt2.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt2.Location = New System.Drawing.Point(8, 436)
        Me.txt2.Name = "txt2"
        Me.txt2.Size = New System.Drawing.Size(263, 25)
        Me.txt2.TabIndex = 85
        Me.txt2.UseAppStyling = False
        Me.txt2.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'upnlMain
        '
        Appearance7.BorderColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.upnlMain.Appearance = Appearance7
        Me.upnlMain.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded4
        '
        'upnlMain.ClientArea
        '
        Me.upnlMain.ClientArea.Controls.Add(Me.ugdMain)
        Me.upnlMain.ClientArea.Controls.Add(Me.txtMain)
        Me.upnlMain.Location = New System.Drawing.Point(16, 41)
        Me.upnlMain.Name = "upnlMain"
        Me.upnlMain.Size = New System.Drawing.Size(282, 469)
        Me.upnlMain.TabIndex = 86
        '
        'ugdMain
        '
        Me.ugdMain.DataSource = Me.udsOrder
        Appearance8.BackColor = System.Drawing.Color.Transparent
        Appearance8.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance8.ForeColor = System.Drawing.Color.Black
        Appearance8.ForeColorDisabled = System.Drawing.Color.Black
        Me.ugdMain.DisplayLayout.Appearance = Appearance8
        UltraGridColumn1.Header.Editor = Nothing
        UltraGridColumn1.Header.VisiblePosition = 0
        UltraGridColumn1.Hidden = True
        UltraGridColumn2.Header.Caption = "Name"
        UltraGridColumn2.Header.Editor = Nothing
        UltraGridColumn2.Header.VisiblePosition = 2
        UltraGridColumn2.Width = 160
        UltraGridColumn3.Header.Editor = Nothing
        UltraGridColumn3.Header.VisiblePosition = 3
        UltraGridColumn3.Hidden = True
        UltraGridColumn4.Header.Caption = "Qty"
        UltraGridColumn4.Header.Editor = Nothing
        UltraGridColumn4.Header.VisiblePosition = 1
        UltraGridColumn4.Width = 42
        Appearance9.TextHAlignAsString = "Right"
        UltraGridColumn5.CellAppearance = Appearance9
        UltraGridColumn5.Format = "#0.00"
        UltraGridColumn5.Header.Editor = Nothing
        UltraGridColumn5.Header.VisiblePosition = 4
        UltraGridColumn5.Width = 70
        UltraGridColumn6.Header.Editor = Nothing
        UltraGridColumn6.Header.VisiblePosition = 5
        UltraGridColumn6.Hidden = True
        UltraGridColumn7.Header.Editor = Nothing
        UltraGridColumn7.Header.VisiblePosition = 6
        UltraGridColumn7.Hidden = True
        UltraGridColumn8.Header.Editor = Nothing
        UltraGridColumn8.Header.VisiblePosition = 7
        UltraGridColumn8.Hidden = True
        UltraGridColumn9.Header.Editor = Nothing
        UltraGridColumn9.Header.VisiblePosition = 8
        UltraGridColumn9.Hidden = True
        UltraGridColumn10.Header.Editor = Nothing
        UltraGridColumn10.Header.VisiblePosition = 9
        UltraGridColumn10.Hidden = True
        UltraGridColumn11.Header.Editor = Nothing
        UltraGridColumn11.Header.VisiblePosition = 10
        UltraGridColumn11.Hidden = True
        UltraGridColumn12.Header.Editor = Nothing
        UltraGridColumn12.Header.VisiblePosition = 11
        UltraGridColumn12.Hidden = True
        UltraGridColumn13.Header.Editor = Nothing
        UltraGridColumn13.Header.VisiblePosition = 12
        UltraGridColumn13.Hidden = True
        UltraGridBand1.Columns.AddRange(New Object() {UltraGridColumn1, UltraGridColumn2, UltraGridColumn3, UltraGridColumn4, UltraGridColumn5, UltraGridColumn6, UltraGridColumn7, UltraGridColumn8, UltraGridColumn9, UltraGridColumn10, UltraGridColumn11, UltraGridColumn12, UltraGridColumn13})
        Appearance10.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        UltraGridBand1.Header.Appearance = Appearance10
        UltraGridBand1.Header.Editor = Nothing
        Appearance11.BackColor = System.Drawing.Color.DarkOrange
        Appearance11.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance11.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        UltraGridBand1.Override.ActiveRowAppearance = Appearance11
        UltraGridBand1.Override.AllowAddNew = Infragistics.Win.UltraWinGrid.AllowAddNew.Yes
        Me.ugdMain.DisplayLayout.BandsSerializer.Add(UltraGridBand1)
        Me.ugdMain.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Me.ugdMain.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.[False]
        Appearance12.BackColor = System.Drawing.SystemColors.ActiveBorder
        Appearance12.BackColor2 = System.Drawing.SystemColors.ControlDark
        Appearance12.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance12.BorderColor = System.Drawing.SystemColors.Window
        Me.ugdMain.DisplayLayout.GroupByBox.Appearance = Appearance12
        Appearance13.ForeColor = System.Drawing.SystemColors.GrayText
        Me.ugdMain.DisplayLayout.GroupByBox.BandLabelAppearance = Appearance13
        Me.ugdMain.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Appearance14.BackColor = System.Drawing.SystemColors.ControlLightLight
        Appearance14.BackColor2 = System.Drawing.SystemColors.Control
        Appearance14.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal
        Appearance14.ForeColor = System.Drawing.SystemColors.GrayText
        Me.ugdMain.DisplayLayout.GroupByBox.PromptAppearance = Appearance14
        Me.ugdMain.DisplayLayout.MaxColScrollRegions = 1
        Me.ugdMain.DisplayLayout.MaxRowScrollRegions = 1
        Me.ugdMain.DisplayLayout.Override.AllowColMoving = Infragistics.Win.UltraWinGrid.AllowColMoving.NotAllowed
        Me.ugdMain.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted
        Me.ugdMain.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted
        Appearance15.BackColor = System.Drawing.SystemColors.Window
        Me.ugdMain.DisplayLayout.Override.CardAreaAppearance = Appearance15
        Appearance16.BorderColor = System.Drawing.Color.Silver
        Appearance16.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter
        Me.ugdMain.DisplayLayout.Override.CellAppearance = Appearance16
        Me.ugdMain.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.EditAndSelectText
        Me.ugdMain.DisplayLayout.Override.CellPadding = 0
        Appearance17.BackColor = System.Drawing.SystemColors.Control
        Appearance17.BackColor2 = System.Drawing.SystemColors.ControlDark
        Appearance17.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element
        Appearance17.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal
        Appearance17.BorderColor = System.Drawing.SystemColors.Window
        Me.ugdMain.DisplayLayout.Override.GroupByRowAppearance = Appearance17
        Appearance18.BackColor = System.Drawing.Color.FromArgb(CType(CType(162, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance18.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(162, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance18.TextHAlignAsString = "Center"
        Me.ugdMain.DisplayLayout.Override.HeaderAppearance = Appearance18
        Me.ugdMain.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti
        Me.ugdMain.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand
        Appearance19.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.ugdMain.DisplayLayout.Override.RowAlternateAppearance = Appearance19
        Appearance20.BackColor = System.Drawing.Color.Gainsboro
        Me.ugdMain.DisplayLayout.Override.RowAppearance = Appearance20
        Me.ugdMain.DisplayLayout.Override.RowSelectorHeaderStyle = Infragistics.Win.UltraWinGrid.RowSelectorHeaderStyle.None
        Me.ugdMain.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.[False]
        Me.ugdMain.DisplayLayout.Override.RowSizing = Infragistics.Win.UltraWinGrid.RowSizing.Sychronized
        Me.ugdMain.DisplayLayout.Override.RowSizingArea = Infragistics.Win.UltraWinGrid.RowSizingArea.RowBordersOnly
        Me.ugdMain.DisplayLayout.Override.SelectTypeCol = Infragistics.Win.UltraWinGrid.SelectType.None
        Me.ugdMain.DisplayLayout.Override.SelectTypeRow = Infragistics.Win.UltraWinGrid.SelectType.[Single]
        Appearance21.BackColor = System.Drawing.SystemColors.ControlLight
        Me.ugdMain.DisplayLayout.Override.TemplateAddRowAppearance = Appearance21
        Me.ugdMain.DisplayLayout.Override.WrapHeaderText = Infragistics.Win.DefaultableBoolean.[True]
        Me.ugdMain.DisplayLayout.Scrollbars = Infragistics.Win.UltraWinGrid.Scrollbars.None
        Me.ugdMain.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill
        Me.ugdMain.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate
        Me.ugdMain.DisplayLayout.ViewStyle = Infragistics.Win.UltraWinGrid.ViewStyle.SingleBand
        Me.ugdMain.Font = New System.Drawing.Font("Arial", 10.0!)
        Me.ugdMain.Location = New System.Drawing.Point(2, 2)
        Me.ugdMain.Name = "ugdMain"
        Me.ugdMain.Size = New System.Drawing.Size(275, 428)
        Me.ugdMain.TabIndex = 480
        '
        'udsOrder
        '
        UltraDataColumn3.DataType = GetType(Decimal)
        UltraDataColumn4.DefaultValue = "''"
        UltraDataColumn5.DataType = GetType(Decimal)
        UltraDataColumn7.DataType = GetType(Short)
        UltraDataColumn8.DataType = GetType(Short)
        UltraDataColumn9.DataType = GetType(Decimal)
        UltraDataColumn10.DataType = GetType(Decimal)
        UltraDataColumn11.DataType = GetType(Decimal)
        UltraDataColumn12.DataType = GetType(Short)
        UltraDataColumn13.DataType = GetType(Short)
        Me.udsOrder.Band.Columns.AddRange(New Object() {UltraDataColumn1, UltraDataColumn2, UltraDataColumn3, UltraDataColumn4, UltraDataColumn5, UltraDataColumn6, UltraDataColumn7, UltraDataColumn8, UltraDataColumn9, UltraDataColumn10, UltraDataColumn11, UltraDataColumn12, UltraDataColumn13})
        '
        'upnl1
        '
        Appearance22.BorderColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.upnl1.Appearance = Appearance22
        Me.upnl1.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded4
        '
        'upnl1.ClientArea
        '
        Me.upnl1.ClientArea.Controls.Add(Me.cmdRemove1)
        Me.upnl1.ClientArea.Controls.Add(Me.cmdGrid1Add1)
        Me.upnl1.ClientArea.Controls.Add(Me.cmdGrid1AddN)
        Me.upnl1.ClientArea.Controls.Add(Me.ug1)
        Me.upnl1.ClientArea.Controls.Add(Me.txt1)
        Me.upnl1.Location = New System.Drawing.Point(304, 41)
        Me.upnl1.Name = "upnl1"
        Me.upnl1.Size = New System.Drawing.Size(282, 469)
        Me.upnl1.TabIndex = 87
        '
        'cmdRemove1
        '
        Appearance23.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(130, Byte), Integer), CType(CType(160, Byte), Integer))
        Appearance23.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(160, Byte), Integer))
        Appearance23.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance23.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance23.BorderColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(220, Byte), Integer))
        Appearance23.BorderColor2 = System.Drawing.Color.Maroon
        Appearance23.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance23.ForeColor = System.Drawing.Color.White
        Appearance23.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance23.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance23.TextVAlignAsString = "Middle"
        Me.cmdRemove1.Appearance = Appearance23
        Me.cmdRemove1.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance24.BackColor = System.Drawing.Color.DarkOrange
        Appearance24.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance24.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance24.ForeColor = System.Drawing.Color.Black
        Me.cmdRemove1.HotTrackAppearance = Appearance24
        Me.cmdRemove1.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdRemove1.Location = New System.Drawing.Point(186, 398)
        Me.cmdRemove1.Name = "cmdRemove1"
        Appearance25.BackColor = System.Drawing.Color.OrangeRed
        Appearance25.BackColor2 = System.Drawing.Color.Tomato
        Appearance25.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdRemove1.PressedAppearance = Appearance25
        Me.cmdRemove1.ShowFocusRect = False
        Me.cmdRemove1.ShowOutline = False
        Me.cmdRemove1.Size = New System.Drawing.Size(85, 32)
        Me.cmdRemove1.TabIndex = 486
        Me.cmdRemove1.Tag = "Back"
        Me.cmdRemove1.Text = "Remove"
        Me.cmdRemove1.UseAppStyling = False
        Me.cmdRemove1.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdRemove1.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdRemove1.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdGrid1Add1
        '
        Appearance26.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(130, Byte), Integer), CType(CType(160, Byte), Integer))
        Appearance26.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(160, Byte), Integer))
        Appearance26.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance26.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance26.BorderColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(220, Byte), Integer))
        Appearance26.BorderColor2 = System.Drawing.Color.Maroon
        Appearance26.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance26.ForeColor = System.Drawing.Color.White
        Appearance26.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance26.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance26.TextVAlignAsString = "Middle"
        Me.cmdGrid1Add1.Appearance = Appearance26
        Me.cmdGrid1Add1.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance27.BackColor = System.Drawing.Color.DarkOrange
        Appearance27.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance27.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance27.ForeColor = System.Drawing.Color.Black
        Me.cmdGrid1Add1.HotTrackAppearance = Appearance27
        Me.cmdGrid1Add1.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdGrid1Add1.Location = New System.Drawing.Point(77, 398)
        Me.cmdGrid1Add1.Name = "cmdGrid1Add1"
        Appearance28.BackColor = System.Drawing.Color.OrangeRed
        Appearance28.BackColor2 = System.Drawing.Color.Tomato
        Appearance28.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdGrid1Add1.PressedAppearance = Appearance28
        Me.cmdGrid1Add1.ShowFocusRect = False
        Me.cmdGrid1Add1.ShowOutline = False
        Me.cmdGrid1Add1.Size = New System.Drawing.Size(63, 32)
        Me.cmdGrid1Add1.TabIndex = 485
        Me.cmdGrid1Add1.Tag = "Back"
        Me.cmdGrid1Add1.Text = "+1"
        Me.cmdGrid1Add1.UseAppStyling = False
        Me.cmdGrid1Add1.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdGrid1Add1.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdGrid1Add1.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdGrid1AddN
        '
        Appearance29.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(130, Byte), Integer), CType(CType(160, Byte), Integer))
        Appearance29.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(160, Byte), Integer))
        Appearance29.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance29.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance29.BorderColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(220, Byte), Integer))
        Appearance29.BorderColor2 = System.Drawing.Color.Maroon
        Appearance29.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance29.ForeColor = System.Drawing.Color.White
        Appearance29.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance29.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance29.TextVAlignAsString = "Middle"
        Me.cmdGrid1AddN.Appearance = Appearance29
        Me.cmdGrid1AddN.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance30.BackColor = System.Drawing.Color.DarkOrange
        Appearance30.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance30.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance30.ForeColor = System.Drawing.Color.Black
        Me.cmdGrid1AddN.HotTrackAppearance = Appearance30
        Me.cmdGrid1AddN.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdGrid1AddN.Location = New System.Drawing.Point(8, 398)
        Me.cmdGrid1AddN.Name = "cmdGrid1AddN"
        Appearance31.BackColor = System.Drawing.Color.OrangeRed
        Appearance31.BackColor2 = System.Drawing.Color.Tomato
        Appearance31.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdGrid1AddN.PressedAppearance = Appearance31
        Me.cmdGrid1AddN.ShowFocusRect = False
        Me.cmdGrid1AddN.ShowOutline = False
        Me.cmdGrid1AddN.Size = New System.Drawing.Size(63, 32)
        Me.cmdGrid1AddN.TabIndex = 386
        Me.cmdGrid1AddN.Tag = "Back"
        Me.cmdGrid1AddN.Text = "+N"
        Me.cmdGrid1AddN.UseAppStyling = False
        Me.cmdGrid1AddN.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdGrid1AddN.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdGrid1AddN.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ug1
        '
        Me.ug1.DataSource = Me.uds1
        Appearance32.BackColor = System.Drawing.Color.Transparent
        Appearance32.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance32.ForeColor = System.Drawing.Color.Black
        Appearance32.ForeColorDisabled = System.Drawing.Color.Black
        Me.ug1.DisplayLayout.Appearance = Appearance32
        UltraGridColumn14.Header.Editor = Nothing
        UltraGridColumn14.Header.VisiblePosition = 0
        UltraGridColumn14.Hidden = True
        UltraGridColumn15.Header.Caption = "Name"
        UltraGridColumn15.Header.Editor = Nothing
        UltraGridColumn15.Header.VisiblePosition = 2
        UltraGridColumn15.Width = 137
        UltraGridColumn16.Header.Editor = Nothing
        UltraGridColumn16.Header.VisiblePosition = 3
        UltraGridColumn16.Hidden = True
        UltraGridColumn17.Header.Caption = "Qty"
        UltraGridColumn17.Header.Editor = Nothing
        UltraGridColumn17.Header.VisiblePosition = 1
        UltraGridColumn17.Width = 42
        Appearance33.TextHAlignAsString = "Right"
        UltraGridColumn18.CellAppearance = Appearance33
        UltraGridColumn18.Format = "#0.00"
        UltraGridColumn18.Header.Editor = Nothing
        UltraGridColumn18.Header.VisiblePosition = 4
        UltraGridColumn19.Header.Editor = Nothing
        UltraGridColumn19.Header.VisiblePosition = 5
        UltraGridColumn19.Hidden = True
        UltraGridColumn20.Header.Editor = Nothing
        UltraGridColumn20.Header.VisiblePosition = 6
        UltraGridColumn20.Hidden = True
        UltraGridColumn21.Header.Editor = Nothing
        UltraGridColumn21.Header.VisiblePosition = 7
        UltraGridColumn21.Hidden = True
        UltraGridColumn22.Header.Editor = Nothing
        UltraGridColumn22.Header.VisiblePosition = 8
        UltraGridColumn22.Hidden = True
        UltraGridColumn23.Header.Editor = Nothing
        UltraGridColumn23.Header.VisiblePosition = 9
        UltraGridColumn23.Hidden = True
        UltraGridColumn24.Header.Editor = Nothing
        UltraGridColumn24.Header.VisiblePosition = 10
        UltraGridColumn24.Hidden = True
        UltraGridColumn25.Header.Editor = Nothing
        UltraGridColumn25.Header.VisiblePosition = 11
        UltraGridColumn25.Hidden = True
        UltraGridColumn26.Header.Editor = Nothing
        UltraGridColumn26.Header.VisiblePosition = 12
        UltraGridColumn26.Hidden = True
        UltraGridBand2.Columns.AddRange(New Object() {UltraGridColumn14, UltraGridColumn15, UltraGridColumn16, UltraGridColumn17, UltraGridColumn18, UltraGridColumn19, UltraGridColumn20, UltraGridColumn21, UltraGridColumn22, UltraGridColumn23, UltraGridColumn24, UltraGridColumn25, UltraGridColumn26})
        Appearance34.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        UltraGridBand2.Header.Appearance = Appearance34
        UltraGridBand2.Header.Editor = Nothing
        Appearance35.BackColor = System.Drawing.Color.DarkOrange
        Appearance35.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance35.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        UltraGridBand2.Override.ActiveRowAppearance = Appearance35
        UltraGridBand2.Override.AllowAddNew = Infragistics.Win.UltraWinGrid.AllowAddNew.Yes
        Me.ug1.DisplayLayout.BandsSerializer.Add(UltraGridBand2)
        Me.ug1.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Me.ug1.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.[False]
        Appearance36.BackColor = System.Drawing.SystemColors.ActiveBorder
        Appearance36.BackColor2 = System.Drawing.SystemColors.ControlDark
        Appearance36.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance36.BorderColor = System.Drawing.SystemColors.Window
        Me.ug1.DisplayLayout.GroupByBox.Appearance = Appearance36
        Appearance37.ForeColor = System.Drawing.SystemColors.GrayText
        Me.ug1.DisplayLayout.GroupByBox.BandLabelAppearance = Appearance37
        Me.ug1.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Appearance38.BackColor = System.Drawing.SystemColors.ControlLightLight
        Appearance38.BackColor2 = System.Drawing.SystemColors.Control
        Appearance38.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal
        Appearance38.ForeColor = System.Drawing.SystemColors.GrayText
        Me.ug1.DisplayLayout.GroupByBox.PromptAppearance = Appearance38
        Me.ug1.DisplayLayout.MaxColScrollRegions = 1
        Me.ug1.DisplayLayout.MaxRowScrollRegions = 1
        Me.ug1.DisplayLayout.Override.AllowColMoving = Infragistics.Win.UltraWinGrid.AllowColMoving.NotAllowed
        Me.ug1.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted
        Me.ug1.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted
        Appearance39.BackColor = System.Drawing.SystemColors.Window
        Me.ug1.DisplayLayout.Override.CardAreaAppearance = Appearance39
        Appearance40.BorderColor = System.Drawing.Color.Silver
        Appearance40.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter
        Me.ug1.DisplayLayout.Override.CellAppearance = Appearance40
        Me.ug1.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.EditAndSelectText
        Me.ug1.DisplayLayout.Override.CellPadding = 0
        Appearance41.BackColor = System.Drawing.SystemColors.Control
        Appearance41.BackColor2 = System.Drawing.SystemColors.ControlDark
        Appearance41.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element
        Appearance41.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal
        Appearance41.BorderColor = System.Drawing.SystemColors.Window
        Me.ug1.DisplayLayout.Override.GroupByRowAppearance = Appearance41
        Appearance42.BackColor = System.Drawing.Color.FromArgb(CType(CType(162, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance42.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(162, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance42.TextHAlignAsString = "Center"
        Me.ug1.DisplayLayout.Override.HeaderAppearance = Appearance42
        Me.ug1.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti
        Me.ug1.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand
        Appearance43.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.ug1.DisplayLayout.Override.RowAlternateAppearance = Appearance43
        Appearance44.BackColor = System.Drawing.Color.Gainsboro
        Me.ug1.DisplayLayout.Override.RowAppearance = Appearance44
        Me.ug1.DisplayLayout.Override.RowSelectorHeaderStyle = Infragistics.Win.UltraWinGrid.RowSelectorHeaderStyle.None
        Me.ug1.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.[False]
        Me.ug1.DisplayLayout.Override.RowSizing = Infragistics.Win.UltraWinGrid.RowSizing.Sychronized
        Me.ug1.DisplayLayout.Override.RowSizingArea = Infragistics.Win.UltraWinGrid.RowSizingArea.RowBordersOnly
        Me.ug1.DisplayLayout.Override.SelectTypeCol = Infragistics.Win.UltraWinGrid.SelectType.None
        Me.ug1.DisplayLayout.Override.SelectTypeRow = Infragistics.Win.UltraWinGrid.SelectType.[Single]
        Appearance45.BackColor = System.Drawing.SystemColors.ControlLight
        Me.ug1.DisplayLayout.Override.TemplateAddRowAppearance = Appearance45
        Me.ug1.DisplayLayout.Override.WrapHeaderText = Infragistics.Win.DefaultableBoolean.[True]
        Me.ug1.DisplayLayout.Scrollbars = Infragistics.Win.UltraWinGrid.Scrollbars.None
        Me.ug1.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill
        Me.ug1.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate
        Me.ug1.DisplayLayout.ViewStyle = Infragistics.Win.UltraWinGrid.ViewStyle.SingleBand
        Me.ug1.Font = New System.Drawing.Font("Arial", 10.0!)
        Me.ug1.Location = New System.Drawing.Point(2, 2)
        Me.ug1.Name = "ug1"
        Me.ug1.Size = New System.Drawing.Size(275, 390)
        Me.ug1.TabIndex = 484
        '
        'uds1
        '
        UltraDataColumn16.DataType = GetType(Decimal)
        UltraDataColumn17.DefaultValue = "''"
        UltraDataColumn18.DataType = GetType(Decimal)
        UltraDataColumn20.DataType = GetType(Short)
        UltraDataColumn21.DataType = GetType(Short)
        UltraDataColumn22.DataType = GetType(Decimal)
        UltraDataColumn23.DataType = GetType(Decimal)
        UltraDataColumn24.DataType = GetType(Decimal)
        UltraDataColumn25.DataType = GetType(Short)
        UltraDataColumn26.DataType = GetType(Short)
        Me.uds1.Band.Columns.AddRange(New Object() {UltraDataColumn14, UltraDataColumn15, UltraDataColumn16, UltraDataColumn17, UltraDataColumn18, UltraDataColumn19, UltraDataColumn20, UltraDataColumn21, UltraDataColumn22, UltraDataColumn23, UltraDataColumn24, UltraDataColumn25, UltraDataColumn26})
        '
        'upnl2
        '
        Appearance46.BorderColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.upnl2.Appearance = Appearance46
        Me.upnl2.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded4
        '
        'upnl2.ClientArea
        '
        Me.upnl2.ClientArea.Controls.Add(Me.cmdRemove2)
        Me.upnl2.ClientArea.Controls.Add(Me.cmdGrid2Add1)
        Me.upnl2.ClientArea.Controls.Add(Me.cmdGrid2AddN)
        Me.upnl2.ClientArea.Controls.Add(Me.ug2)
        Me.upnl2.ClientArea.Controls.Add(Me.txt2)
        Me.upnl2.Location = New System.Drawing.Point(592, 41)
        Me.upnl2.Name = "upnl2"
        Me.upnl2.Size = New System.Drawing.Size(282, 469)
        Me.upnl2.TabIndex = 88
        '
        'cmdRemove2
        '
        Appearance47.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(130, Byte), Integer), CType(CType(160, Byte), Integer))
        Appearance47.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(160, Byte), Integer))
        Appearance47.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance47.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance47.BorderColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(220, Byte), Integer))
        Appearance47.BorderColor2 = System.Drawing.Color.Maroon
        Appearance47.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance47.ForeColor = System.Drawing.Color.White
        Appearance47.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance47.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance47.TextVAlignAsString = "Middle"
        Me.cmdRemove2.Appearance = Appearance47
        Me.cmdRemove2.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance48.BackColor = System.Drawing.Color.DarkOrange
        Appearance48.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance48.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance48.ForeColor = System.Drawing.Color.Black
        Me.cmdRemove2.HotTrackAppearance = Appearance48
        Me.cmdRemove2.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdRemove2.Location = New System.Drawing.Point(186, 398)
        Me.cmdRemove2.Name = "cmdRemove2"
        Appearance49.BackColor = System.Drawing.Color.OrangeRed
        Appearance49.BackColor2 = System.Drawing.Color.Tomato
        Appearance49.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdRemove2.PressedAppearance = Appearance49
        Me.cmdRemove2.ShowFocusRect = False
        Me.cmdRemove2.ShowOutline = False
        Me.cmdRemove2.Size = New System.Drawing.Size(85, 32)
        Me.cmdRemove2.TabIndex = 489
        Me.cmdRemove2.Tag = "Back"
        Me.cmdRemove2.Text = "Remove"
        Me.cmdRemove2.UseAppStyling = False
        Me.cmdRemove2.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdRemove2.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdRemove2.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdGrid2Add1
        '
        Appearance50.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(130, Byte), Integer), CType(CType(160, Byte), Integer))
        Appearance50.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(160, Byte), Integer))
        Appearance50.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance50.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance50.BorderColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(220, Byte), Integer))
        Appearance50.BorderColor2 = System.Drawing.Color.Maroon
        Appearance50.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance50.ForeColor = System.Drawing.Color.White
        Appearance50.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance50.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance50.TextVAlignAsString = "Middle"
        Me.cmdGrid2Add1.Appearance = Appearance50
        Me.cmdGrid2Add1.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance51.BackColor = System.Drawing.Color.DarkOrange
        Appearance51.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance51.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance51.ForeColor = System.Drawing.Color.Black
        Me.cmdGrid2Add1.HotTrackAppearance = Appearance51
        Me.cmdGrid2Add1.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdGrid2Add1.Location = New System.Drawing.Point(77, 398)
        Me.cmdGrid2Add1.Name = "cmdGrid2Add1"
        Appearance52.BackColor = System.Drawing.Color.OrangeRed
        Appearance52.BackColor2 = System.Drawing.Color.Tomato
        Appearance52.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdGrid2Add1.PressedAppearance = Appearance52
        Me.cmdGrid2Add1.ShowFocusRect = False
        Me.cmdGrid2Add1.ShowOutline = False
        Me.cmdGrid2Add1.Size = New System.Drawing.Size(63, 32)
        Me.cmdGrid2Add1.TabIndex = 488
        Me.cmdGrid2Add1.Tag = "Back"
        Me.cmdGrid2Add1.Text = "+1"
        Me.cmdGrid2Add1.UseAppStyling = False
        Me.cmdGrid2Add1.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdGrid2Add1.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdGrid2Add1.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdGrid2AddN
        '
        Appearance53.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(130, Byte), Integer), CType(CType(160, Byte), Integer))
        Appearance53.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(160, Byte), Integer))
        Appearance53.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance53.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance53.BorderColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(220, Byte), Integer))
        Appearance53.BorderColor2 = System.Drawing.Color.Maroon
        Appearance53.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance53.ForeColor = System.Drawing.Color.White
        Appearance53.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance53.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance53.TextVAlignAsString = "Middle"
        Me.cmdGrid2AddN.Appearance = Appearance53
        Me.cmdGrid2AddN.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance54.BackColor = System.Drawing.Color.DarkOrange
        Appearance54.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance54.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance54.ForeColor = System.Drawing.Color.Black
        Me.cmdGrid2AddN.HotTrackAppearance = Appearance54
        Me.cmdGrid2AddN.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdGrid2AddN.Location = New System.Drawing.Point(8, 398)
        Me.cmdGrid2AddN.Name = "cmdGrid2AddN"
        Appearance55.BackColor = System.Drawing.Color.OrangeRed
        Appearance55.BackColor2 = System.Drawing.Color.Tomato
        Appearance55.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdGrid2AddN.PressedAppearance = Appearance55
        Me.cmdGrid2AddN.ShowFocusRect = False
        Me.cmdGrid2AddN.ShowOutline = False
        Me.cmdGrid2AddN.Size = New System.Drawing.Size(63, 32)
        Me.cmdGrid2AddN.TabIndex = 487
        Me.cmdGrid2AddN.Tag = "Back"
        Me.cmdGrid2AddN.Text = "+N"
        Me.cmdGrid2AddN.UseAppStyling = False
        Me.cmdGrid2AddN.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdGrid2AddN.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdGrid2AddN.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ug2
        '
        Me.ug2.DataSource = Me.uds2
        Appearance56.BackColor = System.Drawing.Color.Transparent
        Appearance56.BorderColor = System.Drawing.Color.FromArgb(CType(CType(101, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance56.ForeColor = System.Drawing.Color.Black
        Appearance56.ForeColorDisabled = System.Drawing.Color.Black
        Me.ug2.DisplayLayout.Appearance = Appearance56
        UltraGridColumn27.Header.Editor = Nothing
        UltraGridColumn27.Header.VisiblePosition = 0
        UltraGridColumn27.Hidden = True
        UltraGridColumn28.Header.Caption = "Name"
        UltraGridColumn28.Header.Editor = Nothing
        UltraGridColumn28.Header.VisiblePosition = 2
        UltraGridColumn28.Width = 137
        UltraGridColumn29.Header.Editor = Nothing
        UltraGridColumn29.Header.VisiblePosition = 3
        UltraGridColumn29.Hidden = True
        UltraGridColumn30.Header.Caption = "Qty"
        UltraGridColumn30.Header.Editor = Nothing
        UltraGridColumn30.Header.VisiblePosition = 1
        UltraGridColumn30.Width = 42
        Appearance57.TextHAlignAsString = "Right"
        UltraGridColumn31.CellAppearance = Appearance57
        UltraGridColumn31.Format = "#0.00"
        UltraGridColumn31.Header.Editor = Nothing
        UltraGridColumn31.Header.VisiblePosition = 4
        UltraGridColumn32.Header.Editor = Nothing
        UltraGridColumn32.Header.VisiblePosition = 5
        UltraGridColumn32.Hidden = True
        UltraGridColumn33.Header.Editor = Nothing
        UltraGridColumn33.Header.VisiblePosition = 6
        UltraGridColumn33.Hidden = True
        UltraGridColumn34.Header.Editor = Nothing
        UltraGridColumn34.Header.VisiblePosition = 7
        UltraGridColumn34.Hidden = True
        UltraGridColumn35.Header.Editor = Nothing
        UltraGridColumn35.Header.VisiblePosition = 8
        UltraGridColumn35.Hidden = True
        UltraGridColumn36.Header.Editor = Nothing
        UltraGridColumn36.Header.VisiblePosition = 9
        UltraGridColumn36.Hidden = True
        UltraGridColumn37.Header.Editor = Nothing
        UltraGridColumn37.Header.VisiblePosition = 10
        UltraGridColumn37.Hidden = True
        UltraGridColumn38.Header.Editor = Nothing
        UltraGridColumn38.Header.VisiblePosition = 11
        UltraGridColumn38.Hidden = True
        UltraGridColumn39.Header.Editor = Nothing
        UltraGridColumn39.Header.VisiblePosition = 12
        UltraGridColumn39.Hidden = True
        UltraGridBand3.Columns.AddRange(New Object() {UltraGridColumn27, UltraGridColumn28, UltraGridColumn29, UltraGridColumn30, UltraGridColumn31, UltraGridColumn32, UltraGridColumn33, UltraGridColumn34, UltraGridColumn35, UltraGridColumn36, UltraGridColumn37, UltraGridColumn38, UltraGridColumn39})
        Appearance58.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        UltraGridBand3.Header.Appearance = Appearance58
        UltraGridBand3.Header.Editor = Nothing
        Appearance59.BackColor = System.Drawing.Color.DarkOrange
        Appearance59.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance59.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        UltraGridBand3.Override.ActiveRowAppearance = Appearance59
        UltraGridBand3.Override.AllowAddNew = Infragistics.Win.UltraWinGrid.AllowAddNew.Yes
        Me.ug2.DisplayLayout.BandsSerializer.Add(UltraGridBand3)
        Me.ug2.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Me.ug2.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.[False]
        Appearance60.BackColor = System.Drawing.SystemColors.ActiveBorder
        Appearance60.BackColor2 = System.Drawing.SystemColors.ControlDark
        Appearance60.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance60.BorderColor = System.Drawing.SystemColors.Window
        Me.ug2.DisplayLayout.GroupByBox.Appearance = Appearance60
        Appearance61.ForeColor = System.Drawing.SystemColors.GrayText
        Me.ug2.DisplayLayout.GroupByBox.BandLabelAppearance = Appearance61
        Me.ug2.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Appearance62.BackColor = System.Drawing.SystemColors.ControlLightLight
        Appearance62.BackColor2 = System.Drawing.SystemColors.Control
        Appearance62.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal
        Appearance62.ForeColor = System.Drawing.SystemColors.GrayText
        Me.ug2.DisplayLayout.GroupByBox.PromptAppearance = Appearance62
        Me.ug2.DisplayLayout.MaxColScrollRegions = 1
        Me.ug2.DisplayLayout.MaxRowScrollRegions = 1
        Me.ug2.DisplayLayout.Override.AllowColMoving = Infragistics.Win.UltraWinGrid.AllowColMoving.NotAllowed
        Me.ug2.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted
        Me.ug2.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted
        Appearance63.BackColor = System.Drawing.SystemColors.Window
        Me.ug2.DisplayLayout.Override.CardAreaAppearance = Appearance63
        Appearance64.BorderColor = System.Drawing.Color.Silver
        Appearance64.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter
        Me.ug2.DisplayLayout.Override.CellAppearance = Appearance64
        Me.ug2.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.EditAndSelectText
        Me.ug2.DisplayLayout.Override.CellPadding = 0
        Appearance65.BackColor = System.Drawing.SystemColors.Control
        Appearance65.BackColor2 = System.Drawing.SystemColors.ControlDark
        Appearance65.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element
        Appearance65.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal
        Appearance65.BorderColor = System.Drawing.SystemColors.Window
        Me.ug2.DisplayLayout.Override.GroupByRowAppearance = Appearance65
        Appearance66.BackColor = System.Drawing.Color.FromArgb(CType(CType(162, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance66.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(162, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(207, Byte), Integer))
        Appearance66.TextHAlignAsString = "Center"
        Me.ug2.DisplayLayout.Override.HeaderAppearance = Appearance66
        Me.ug2.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti
        Me.ug2.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand
        Appearance67.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.ug2.DisplayLayout.Override.RowAlternateAppearance = Appearance67
        Appearance68.BackColor = System.Drawing.Color.Gainsboro
        Me.ug2.DisplayLayout.Override.RowAppearance = Appearance68
        Me.ug2.DisplayLayout.Override.RowSelectorHeaderStyle = Infragistics.Win.UltraWinGrid.RowSelectorHeaderStyle.None
        Me.ug2.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.[False]
        Me.ug2.DisplayLayout.Override.RowSizing = Infragistics.Win.UltraWinGrid.RowSizing.Sychronized
        Me.ug2.DisplayLayout.Override.RowSizingArea = Infragistics.Win.UltraWinGrid.RowSizingArea.RowBordersOnly
        Me.ug2.DisplayLayout.Override.SelectTypeCol = Infragistics.Win.UltraWinGrid.SelectType.None
        Me.ug2.DisplayLayout.Override.SelectTypeRow = Infragistics.Win.UltraWinGrid.SelectType.[Single]
        Appearance69.BackColor = System.Drawing.SystemColors.ControlLight
        Me.ug2.DisplayLayout.Override.TemplateAddRowAppearance = Appearance69
        Me.ug2.DisplayLayout.Override.WrapHeaderText = Infragistics.Win.DefaultableBoolean.[True]
        Me.ug2.DisplayLayout.Scrollbars = Infragistics.Win.UltraWinGrid.Scrollbars.None
        Me.ug2.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill
        Me.ug2.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate
        Me.ug2.DisplayLayout.ViewStyle = Infragistics.Win.UltraWinGrid.ViewStyle.SingleBand
        Me.ug2.Font = New System.Drawing.Font("Arial", 10.0!)
        Me.ug2.Location = New System.Drawing.Point(2, 2)
        Me.ug2.Name = "ug2"
        Me.ug2.Size = New System.Drawing.Size(275, 390)
        Me.ug2.TabIndex = 485
        '
        'uds2
        '
        UltraDataColumn29.DataType = GetType(Decimal)
        UltraDataColumn30.DefaultValue = "''"
        UltraDataColumn31.DataType = GetType(Decimal)
        UltraDataColumn33.DataType = GetType(Short)
        UltraDataColumn34.DataType = GetType(Short)
        UltraDataColumn35.DataType = GetType(Decimal)
        UltraDataColumn36.DataType = GetType(Decimal)
        UltraDataColumn37.DataType = GetType(Decimal)
        UltraDataColumn38.DataType = GetType(Short)
        UltraDataColumn39.DataType = GetType(Short)
        Me.uds2.Band.Columns.AddRange(New Object() {UltraDataColumn27, UltraDataColumn28, UltraDataColumn29, UltraDataColumn30, UltraDataColumn31, UltraDataColumn32, UltraDataColumn33, UltraDataColumn34, UltraDataColumn35, UltraDataColumn36, UltraDataColumn37, UltraDataColumn38, UltraDataColumn39})
        '
        'cmdBack
        '
        Appearance70.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(130, Byte), Integer), CType(CType(160, Byte), Integer))
        Appearance70.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(160, Byte), Integer))
        Appearance70.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance70.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance70.BorderColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(220, Byte), Integer))
        Appearance70.BorderColor2 = System.Drawing.Color.Maroon
        Appearance70.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance70.ForeColor = System.Drawing.Color.White
        Appearance70.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance70.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance70.TextVAlignAsString = "Middle"
        Me.cmdBack.Appearance = Appearance70
        Me.cmdBack.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance71.BackColor = System.Drawing.Color.DarkOrange
        Appearance71.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance71.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance71.ForeColor = System.Drawing.Color.Black
        Me.cmdBack.HotTrackAppearance = Appearance71
        Me.cmdBack.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdBack.Location = New System.Drawing.Point(811, 528)
        Me.cmdBack.Name = "cmdBack"
        Appearance72.BackColor = System.Drawing.Color.OrangeRed
        Appearance72.BackColor2 = System.Drawing.Color.Tomato
        Appearance72.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdBack.PressedAppearance = Appearance72
        Me.cmdBack.ShowFocusRect = False
        Me.cmdBack.ShowOutline = False
        Me.cmdBack.Size = New System.Drawing.Size(71, 32)
        Me.cmdBack.TabIndex = 384
        Me.cmdBack.Tag = "Back"
        Me.cmdBack.Text = "Back"
        Me.cmdBack.UseAppStyling = False
        Me.cmdBack.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdBack.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdBack.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblDetails
        '
        Appearance73.ForeColor = System.Drawing.Color.Gold
        Appearance73.TextHAlignAsString = "Right"
        Me.lblDetails.Appearance = Appearance73
        Me.lblDetails.Font = New System.Drawing.Font("Arial", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDetails.Location = New System.Drawing.Point(267, 522)
        Me.lblDetails.Name = "lblDetails"
        Me.lblDetails.Size = New System.Drawing.Size(282, 43)
        Me.lblDetails.TabIndex = 385
        Me.lblDetails.UseAppStyling = False
        Me.lblDetails.Visible = False
        '
        'frmSplitDishes
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.BackColor = System.Drawing.Color.DarkSlateGray
        Me.ClientSize = New System.Drawing.Size(894, 572)
        Me.Controls.Add(Me.lblDetails)
        Me.Controls.Add(Me.cmdBack)
        Me.Controls.Add(Me.upnl2)
        Me.Controls.Add(Me.upnl1)
        Me.Controls.Add(Me.upnlMain)
        Me.Controls.Add(Me.UltraLabel3)
        Me.Controls.Add(Me.UltraLabel2)
        Me.Controls.Add(Me.UltraLabel1)
        Me.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmSplitDishes"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "EZ-Menu Dish Split"
        CType(Me.txtMain, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txt1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txt2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.upnlMain.ClientArea.ResumeLayout(False)
        Me.upnlMain.ClientArea.PerformLayout()
        Me.upnlMain.ResumeLayout(False)
        CType(Me.ugdMain, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.udsOrder, System.ComponentModel.ISupportInitialize).EndInit()
        Me.upnl1.ClientArea.ResumeLayout(False)
        Me.upnl1.ClientArea.PerformLayout()
        Me.upnl1.ResumeLayout(False)
        CType(Me.ug1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.uds1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.upnl2.ClientArea.ResumeLayout(False)
        Me.upnl2.ClientArea.PerformLayout()
        Me.upnl2.ResumeLayout(False)
        CType(Me.ug2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.uds2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Private WithEvents UltraLabel1 As Infragistics.Win.Misc.UltraLabel
    Private WithEvents UltraLabel2 As Infragistics.Win.Misc.UltraLabel
    Private WithEvents UltraLabel3 As Infragistics.Win.Misc.UltraLabel
    Private WithEvents txtMain As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Private WithEvents txt1 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Private WithEvents txt2 As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Private WithEvents upnlMain As Infragistics.Win.Misc.UltraPanel
    Private WithEvents upnl1 As Infragistics.Win.Misc.UltraPanel
    Private WithEvents upnl2 As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents ugdMain As Infragistics.Win.UltraWinGrid.UltraGrid
    Friend WithEvents cmdBack As Infragistics.Win.Misc.UltraButton
    Friend WithEvents udsOrder As Infragistics.Win.UltraWinDataSource.UltraDataSource
    Friend WithEvents uds1 As Infragistics.Win.UltraWinDataSource.UltraDataSource
    Friend WithEvents uds2 As Infragistics.Win.UltraWinDataSource.UltraDataSource
    Friend WithEvents ug1 As Infragistics.Win.UltraWinGrid.UltraGrid
    Friend WithEvents ug2 As Infragistics.Win.UltraWinGrid.UltraGrid
    Private WithEvents lblDetails As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents cmdRemove1 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdGrid1Add1 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdGrid1AddN As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdRemove2 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdGrid2Add1 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdGrid2AddN As Infragistics.Win.Misc.UltraButton

End Class
