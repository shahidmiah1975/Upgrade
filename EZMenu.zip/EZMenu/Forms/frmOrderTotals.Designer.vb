﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmOrderTotals
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim Appearance1 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance2 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance3 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance4 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance5 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance6 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance7 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance8 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance9 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance10 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance11 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmOrderTotals))
        Dim Appearance12 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance13 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Me.lblTOrders = New Infragistics.Win.Misc.UltraLabel()
        Me.upnlOrdersToday = New Infragistics.Win.Misc.UltraPanel()
        Me.lblTDLbl = New Infragistics.Win.Misc.UltraLabel()
        Me.lblTTLbl = New Infragistics.Win.Misc.UltraLabel()
        Me.lblTCLbl = New Infragistics.Win.Misc.UltraLabel()
        Me.lblTTotalLbl = New Infragistics.Win.Misc.UltraLabel()
        Me.lblTDeliv = New Infragistics.Win.Misc.UltraLabel()
        Me.lblTColn = New Infragistics.Win.Misc.UltraLabel()
        Me.lblTTables = New Infragistics.Win.Misc.UltraLabel()
        Me.lblTTotal = New Infragistics.Win.Misc.UltraLabel()
        Me.cmdClose = New Infragistics.Win.Misc.UltraButton()
        Me.UltraGroupBox1 = New Infragistics.Win.Misc.UltraGroupBox()
        Me.upnlOrdersToday.ClientArea.SuspendLayout()
        Me.upnlOrdersToday.SuspendLayout()
        CType(Me.UltraGroupBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.UltraGroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblTOrders
        '
        Appearance1.BackColor = System.Drawing.Color.Transparent
        Appearance1.ForeColor = System.Drawing.Color.Black
        Appearance1.TextHAlignAsString = "Center"
        Me.lblTOrders.Appearance = Appearance1
        Me.lblTOrders.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTOrders.Location = New System.Drawing.Point(162, 36)
        Me.lblTOrders.Name = "lblTOrders"
        Me.lblTOrders.Size = New System.Drawing.Size(203, 20)
        Me.lblTOrders.TabIndex = 663
        Me.lblTOrders.Text = "Orders Today"
        Me.lblTOrders.UseAppStyling = False
        '
        'upnlOrdersToday
        '
        Appearance2.BackColor = System.Drawing.Color.Transparent
        Appearance2.ForeColor = System.Drawing.Color.Black
        Me.upnlOrdersToday.Appearance = Appearance2
        '
        'upnlOrdersToday.ClientArea
        '
        Me.upnlOrdersToday.ClientArea.Controls.Add(Me.lblTDLbl)
        Me.upnlOrdersToday.ClientArea.Controls.Add(Me.lblTTLbl)
        Me.upnlOrdersToday.ClientArea.Controls.Add(Me.lblTCLbl)
        Me.upnlOrdersToday.ClientArea.Controls.Add(Me.lblTTotalLbl)
        Me.upnlOrdersToday.ClientArea.Controls.Add(Me.lblTDeliv)
        Me.upnlOrdersToday.ClientArea.Controls.Add(Me.lblTColn)
        Me.upnlOrdersToday.ClientArea.Controls.Add(Me.lblTTables)
        Me.upnlOrdersToday.ClientArea.Controls.Add(Me.lblTTotal)
        Me.upnlOrdersToday.Location = New System.Drawing.Point(129, 60)
        Me.upnlOrdersToday.Name = "upnlOrdersToday"
        Me.upnlOrdersToday.Size = New System.Drawing.Size(267, 104)
        Me.upnlOrdersToday.TabIndex = 664
        '
        'lblTDLbl
        '
        Appearance3.BackColor = System.Drawing.Color.Transparent
        Appearance3.ForeColor = System.Drawing.Color.Teal
        Appearance3.TextHAlignAsString = "Right"
        Me.lblTDLbl.Appearance = Appearance3
        Me.lblTDLbl.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTDLbl.Location = New System.Drawing.Point(8, 12)
        Me.lblTDLbl.Name = "lblTDLbl"
        Me.lblTDLbl.Size = New System.Drawing.Size(140, 15)
        Me.lblTDLbl.TabIndex = 369
        Me.lblTDLbl.Text = "Deliveries:"
        Me.lblTDLbl.UseAppStyling = False
        '
        'lblTTLbl
        '
        Appearance4.BackColor = System.Drawing.Color.Transparent
        Appearance4.ForeColor = System.Drawing.Color.Teal
        Appearance4.TextHAlignAsString = "Right"
        Me.lblTTLbl.Appearance = Appearance4
        Me.lblTTLbl.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTTLbl.Location = New System.Drawing.Point(8, 54)
        Me.lblTTLbl.Name = "lblTTLbl"
        Me.lblTTLbl.Size = New System.Drawing.Size(140, 15)
        Me.lblTTLbl.TabIndex = 370
        Me.lblTTLbl.Text = "Tables:"
        Me.lblTTLbl.UseAppStyling = False
        '
        'lblTCLbl
        '
        Appearance5.BackColor = System.Drawing.Color.Transparent
        Appearance5.ForeColor = System.Drawing.Color.Teal
        Appearance5.TextHAlignAsString = "Right"
        Me.lblTCLbl.Appearance = Appearance5
        Me.lblTCLbl.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTCLbl.Location = New System.Drawing.Point(8, 33)
        Me.lblTCLbl.Name = "lblTCLbl"
        Me.lblTCLbl.Size = New System.Drawing.Size(140, 15)
        Me.lblTCLbl.TabIndex = 371
        Me.lblTCLbl.Text = "Collections:"
        Me.lblTCLbl.UseAppStyling = False
        '
        'lblTTotalLbl
        '
        Appearance6.BackColor = System.Drawing.Color.Transparent
        Appearance6.ForeColor = System.Drawing.Color.Teal
        Appearance6.TextHAlignAsString = "Right"
        Me.lblTTotalLbl.Appearance = Appearance6
        Me.lblTTotalLbl.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTTotalLbl.Location = New System.Drawing.Point(8, 75)
        Me.lblTTotalLbl.Name = "lblTTotalLbl"
        Me.lblTTotalLbl.Size = New System.Drawing.Size(140, 15)
        Me.lblTTotalLbl.TabIndex = 372
        Me.lblTTotalLbl.Text = "Total:"
        Me.lblTTotalLbl.UseAppStyling = False
        '
        'lblTDeliv
        '
        Appearance7.BackColor = System.Drawing.Color.Transparent
        Appearance7.ForeColor = System.Drawing.Color.Teal
        Appearance7.TextHAlignAsString = "Right"
        Me.lblTDeliv.Appearance = Appearance7
        Me.lblTDeliv.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTDeliv.Location = New System.Drawing.Point(154, 12)
        Me.lblTDeliv.Name = "lblTDeliv"
        Me.lblTDeliv.Size = New System.Drawing.Size(71, 15)
        Me.lblTDeliv.TabIndex = 373
        Me.lblTDeliv.Text = "0.00"
        Me.lblTDeliv.UseAppStyling = False
        '
        'lblTColn
        '
        Appearance8.BackColor = System.Drawing.Color.Transparent
        Appearance8.ForeColor = System.Drawing.Color.Teal
        Appearance8.TextHAlignAsString = "Right"
        Me.lblTColn.Appearance = Appearance8
        Me.lblTColn.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTColn.Location = New System.Drawing.Point(154, 33)
        Me.lblTColn.Name = "lblTColn"
        Me.lblTColn.Size = New System.Drawing.Size(71, 15)
        Me.lblTColn.TabIndex = 374
        Me.lblTColn.Text = "0.00"
        Me.lblTColn.UseAppStyling = False
        '
        'lblTTables
        '
        Appearance9.BackColor = System.Drawing.Color.Transparent
        Appearance9.ForeColor = System.Drawing.Color.Teal
        Appearance9.TextHAlignAsString = "Right"
        Me.lblTTables.Appearance = Appearance9
        Me.lblTTables.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTTables.Location = New System.Drawing.Point(154, 54)
        Me.lblTTables.Name = "lblTTables"
        Me.lblTTables.Size = New System.Drawing.Size(71, 15)
        Me.lblTTables.TabIndex = 375
        Me.lblTTables.Text = "0.00"
        Me.lblTTables.UseAppStyling = False
        '
        'lblTTotal
        '
        Appearance10.BackColor = System.Drawing.Color.Transparent
        Appearance10.ForeColor = System.Drawing.Color.Teal
        Appearance10.TextHAlignAsString = "Right"
        Me.lblTTotal.Appearance = Appearance10
        Me.lblTTotal.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTTotal.Location = New System.Drawing.Point(154, 75)
        Me.lblTTotal.Name = "lblTTotal"
        Me.lblTTotal.Size = New System.Drawing.Size(71, 26)
        Me.lblTTotal.TabIndex = 376
        Me.lblTTotal.Text = "0.00"
        Me.lblTTotal.UseAppStyling = False
        '
        'cmdClose
        '
        Me.cmdClose.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance11.BackColor = System.Drawing.Color.Transparent
        Appearance11.BackColor2 = System.Drawing.Color.Transparent
        Appearance11.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance11.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance11.BorderColor = System.Drawing.Color.Transparent
        Appearance11.BorderColor2 = System.Drawing.Color.Maroon
        Appearance11.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance11.ForeColor = System.Drawing.Color.White
        Appearance11.Image = CType(resources.GetObject("Appearance11.Image"), Object)
        Appearance11.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance11.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance11.TextVAlignAsString = "Bottom"
        Me.cmdClose.Appearance = Appearance11
        Me.cmdClose.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdClose.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance12.BackColor = System.Drawing.Color.DarkOrange
        Appearance12.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance12.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance12.BorderColor = System.Drawing.Color.Transparent
        Appearance12.ForeColor = System.Drawing.Color.Black
        Me.cmdClose.HotTrackAppearance = Appearance12
        Me.cmdClose.ImageSize = New System.Drawing.Size(32, 32)
        Me.cmdClose.Location = New System.Drawing.Point(455, 174)
        Me.cmdClose.Name = "cmdClose"
        Me.cmdClose.Padding = New System.Drawing.Size(15, 0)
        Appearance13.BackColor = System.Drawing.Color.OrangeRed
        Appearance13.BackColor2 = System.Drawing.Color.Tomato
        Appearance13.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance13.BorderColor = System.Drawing.Color.Transparent
        Me.cmdClose.PressedAppearance = Appearance13
        Me.cmdClose.ShowFocusRect = False
        Me.cmdClose.ShowOutline = False
        Me.cmdClose.Size = New System.Drawing.Size(64, 44)
        Me.cmdClose.StyleSetName = "StatusBar"
        Me.cmdClose.TabIndex = 665
        Me.cmdClose.Tag = "Return"
        Me.cmdClose.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdClose.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdClose.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'UltraGroupBox1
        '
        Me.UltraGroupBox1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.UltraGroupBox1.Controls.Add(Me.lblTOrders)
        Me.UltraGroupBox1.Controls.Add(Me.cmdClose)
        Me.UltraGroupBox1.Controls.Add(Me.upnlOrdersToday)
        Me.UltraGroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.UltraGroupBox1.Name = "UltraGroupBox1"
        Me.UltraGroupBox1.Size = New System.Drawing.Size(525, 224)
        Me.UltraGroupBox1.TabIndex = 666
        '
        'frmOrderTotals
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.Color.White
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(549, 248)
        Me.ControlBox = False
        Me.Controls.Add(Me.UltraGroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "frmOrderTotals"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.upnlOrdersToday.ClientArea.ResumeLayout(False)
        Me.upnlOrdersToday.ResumeLayout(False)
        CType(Me.UltraGroupBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.UltraGroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents lblTOrders As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents upnlOrdersToday As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents lblTDLbl As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblTTLbl As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblTCLbl As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblTTotalLbl As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblTDeliv As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblTColn As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblTTables As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents lblTTotal As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents cmdClose As Infragistics.Win.Misc.UltraButton
    Friend WithEvents UltraGroupBox1 As Infragistics.Win.Misc.UltraGroupBox
End Class
