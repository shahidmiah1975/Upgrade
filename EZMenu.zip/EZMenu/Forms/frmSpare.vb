﻿Public Class frmSpare
    Private Sub frmSpare_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class