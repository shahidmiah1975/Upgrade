﻿Public Class frmMaps
    Friend Sub DisplayMap(tempStr As String)

        Try
            webBrowser1.Navigate(tempStr)
            ShowDialog()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Sub
End Class