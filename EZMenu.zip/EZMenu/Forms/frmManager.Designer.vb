﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmManager
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim Appearance1 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance2 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmManager))
        Dim Appearance3 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance4 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance5 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance6 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance7 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance8 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance9 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance10 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance11 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance12 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance13 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance14 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance15 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance16 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance17 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance18 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance19 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance20 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance21 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance22 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance23 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance24 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance25 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance26 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance27 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance28 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance29 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance30 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance31 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance32 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance33 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance34 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance35 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance36 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance37 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance38 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Me.upnlMainOptions = New Infragistics.Win.Misc.UltraPanel()
        Me.cmdClearPrintSpooler = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDBRestore = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDoFakeOrders = New Infragistics.Win.Misc.UltraButton()
        Me.cmdDBBackup = New Infragistics.Win.Misc.UltraButton()
        Me.cmdTestWebserviceConn = New Infragistics.Win.Misc.UltraButton()
        Me.cmdRegister = New Infragistics.Win.Misc.UltraButton()
        Me.cmdSQLQuery = New Infragistics.Win.Misc.UltraButton()
        Me.cmdViewLog = New Infragistics.Win.Misc.UltraButton()
        Me.cmdSettings = New Infragistics.Win.Misc.UltraButton()
        Me.cmdAbout = New Infragistics.Win.Misc.UltraButton()
        Me.cmdSummary = New Infragistics.Win.Misc.UltraButton()
        Me.cmdSetupDrinks = New Infragistics.Win.Misc.UltraButton()
        Me.cmdCleanDB = New Infragistics.Win.Misc.UltraButton()
        Me.cmdBanking = New Infragistics.Win.Misc.UltraButton()
        Me.cmdSetupCustomer = New Infragistics.Win.Misc.UltraButton()
        Me.cmdSetupDishes = New Infragistics.Win.Misc.UltraButton()
        Me.pnlHeader = New Infragistics.Win.Misc.UltraPanel()
        Me.lblHeader = New Infragistics.Win.Misc.UltraLabel()
        Me.cmdBack = New Infragistics.Win.Misc.UltraButton()
        Me.usbManager = New Infragistics.Win.UltraWinStatusBar.UltraStatusBar()
        Me.upnlMainOptions.ClientArea.SuspendLayout()
        Me.upnlMainOptions.SuspendLayout()
        Me.pnlHeader.ClientArea.SuspendLayout()
        Me.pnlHeader.SuspendLayout()
        CType(Me.usbManager, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'upnlMainOptions
        '
        Me.upnlMainOptions.Anchor = System.Windows.Forms.AnchorStyles.Top
        Appearance1.BackColor = System.Drawing.Color.Transparent
        Appearance1.BorderColor = System.Drawing.Color.DarkOrange
        Me.upnlMainOptions.Appearance = Appearance1
        Me.upnlMainOptions.BorderStyle = Infragistics.Win.UIElementBorderStyle.None
        '
        'upnlMainOptions.ClientArea
        '
        Me.upnlMainOptions.ClientArea.Controls.Add(Me.cmdClearPrintSpooler)
        Me.upnlMainOptions.ClientArea.Controls.Add(Me.cmdDBRestore)
        Me.upnlMainOptions.ClientArea.Controls.Add(Me.cmdDoFakeOrders)
        Me.upnlMainOptions.ClientArea.Controls.Add(Me.cmdDBBackup)
        Me.upnlMainOptions.ClientArea.Controls.Add(Me.cmdTestWebserviceConn)
        Me.upnlMainOptions.ClientArea.Controls.Add(Me.cmdRegister)
        Me.upnlMainOptions.ClientArea.Controls.Add(Me.cmdSQLQuery)
        Me.upnlMainOptions.ClientArea.Controls.Add(Me.cmdViewLog)
        Me.upnlMainOptions.ClientArea.Controls.Add(Me.cmdSettings)
        Me.upnlMainOptions.ClientArea.Controls.Add(Me.cmdAbout)
        Me.upnlMainOptions.ClientArea.Controls.Add(Me.cmdSummary)
        Me.upnlMainOptions.ClientArea.Controls.Add(Me.cmdSetupDrinks)
        Me.upnlMainOptions.ClientArea.Controls.Add(Me.cmdCleanDB)
        Me.upnlMainOptions.ClientArea.Controls.Add(Me.cmdBanking)
        Me.upnlMainOptions.ClientArea.Controls.Add(Me.cmdSetupCustomer)
        Me.upnlMainOptions.ClientArea.Controls.Add(Me.cmdSetupDishes)
        Me.upnlMainOptions.Location = New System.Drawing.Point(111, 54)
        Me.upnlMainOptions.Name = "upnlMainOptions"
        Me.upnlMainOptions.Size = New System.Drawing.Size(960, 570)
        Me.upnlMainOptions.TabIndex = 122
        '
        'cmdClearPrintSpooler
        '
        Me.cmdClearPrintSpooler.Anchor = System.Windows.Forms.AnchorStyles.None
        Appearance2.BackColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance2.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance2.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance2.BorderAlpha = Infragistics.Win.Alpha.Opaque
        Appearance2.BorderColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance2.BorderColor2 = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance2.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance2.ForeColor = System.Drawing.Color.White
        Appearance2.Image = CType(resources.GetObject("Appearance2.Image"), Object)
        Appearance2.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance2.TextVAlignAsString = "Bottom"
        Me.cmdClearPrintSpooler.Appearance = Appearance2
        Me.cmdClearPrintSpooler.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance3.BackColor = System.Drawing.Color.PowderBlue
        Appearance3.BackColor2 = System.Drawing.Color.Aqua
        Appearance3.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance3.ForeColor = System.Drawing.Color.Black
        Me.cmdClearPrintSpooler.HotTrackAppearance = Appearance3
        Me.cmdClearPrintSpooler.ImageSize = New System.Drawing.Size(38, 38)
        Me.cmdClearPrintSpooler.Location = New System.Drawing.Point(702, 271)
        Me.cmdClearPrintSpooler.Name = "cmdClearPrintSpooler"
        Me.cmdClearPrintSpooler.ShowFocusRect = False
        Me.cmdClearPrintSpooler.ShowOutline = False
        Me.cmdClearPrintSpooler.Size = New System.Drawing.Size(192, 80)
        Me.cmdClearPrintSpooler.StyleSetName = "ManagerButton"
        Me.cmdClearPrintSpooler.TabIndex = 500
        Me.cmdClearPrintSpooler.Text = "Clear print spooler"
        Me.cmdClearPrintSpooler.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdClearPrintSpooler.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdClearPrintSpooler.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDBRestore
        '
        Me.cmdDBRestore.Anchor = System.Windows.Forms.AnchorStyles.None
        Appearance4.BackColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance4.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance4.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance4.BorderAlpha = Infragistics.Win.Alpha.Opaque
        Appearance4.BorderColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance4.BorderColor2 = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance4.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance4.ForeColor = System.Drawing.Color.White
        Appearance4.Image = CType(resources.GetObject("Appearance4.Image"), Object)
        Appearance4.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance4.TextVAlignAsString = "Bottom"
        Me.cmdDBRestore.Appearance = Appearance4
        Me.cmdDBRestore.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance5.BackColor = System.Drawing.Color.PowderBlue
        Appearance5.BackColor2 = System.Drawing.Color.Aqua
        Appearance5.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance5.ForeColor = System.Drawing.Color.Black
        Me.cmdDBRestore.HotTrackAppearance = Appearance5
        Me.cmdDBRestore.ImageSize = New System.Drawing.Size(38, 38)
        Me.cmdDBRestore.Location = New System.Drawing.Point(490, 271)
        Me.cmdDBRestore.Name = "cmdDBRestore"
        Me.cmdDBRestore.ShowFocusRect = False
        Me.cmdDBRestore.ShowOutline = False
        Me.cmdDBRestore.Size = New System.Drawing.Size(192, 80)
        Me.cmdDBRestore.StyleSetName = "ManagerButton"
        Me.cmdDBRestore.TabIndex = 499
        Me.cmdDBRestore.Text = "Restore Database"
        Me.cmdDBRestore.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDBRestore.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdDBRestore.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDoFakeOrders
        '
        Me.cmdDoFakeOrders.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance6.BackColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance6.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance6.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance6.BorderAlpha = Infragistics.Win.Alpha.Opaque
        Appearance6.BorderColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance6.BorderColor2 = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance6.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance6.ForeColor = System.Drawing.Color.White
        Me.cmdDoFakeOrders.Appearance = Appearance6
        Me.cmdDoFakeOrders.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance7.BackColor = System.Drawing.Color.PowderBlue
        Appearance7.BackColor2 = System.Drawing.Color.Aqua
        Appearance7.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance7.ForeColor = System.Drawing.Color.Black
        Me.cmdDoFakeOrders.HotTrackAppearance = Appearance7
        Me.cmdDoFakeOrders.ImageSize = New System.Drawing.Size(38, 38)
        Me.cmdDoFakeOrders.Location = New System.Drawing.Point(735, 507)
        Me.cmdDoFakeOrders.Name = "cmdDoFakeOrders"
        Me.cmdDoFakeOrders.ShowFocusRect = False
        Me.cmdDoFakeOrders.ShowOutline = False
        Me.cmdDoFakeOrders.Size = New System.Drawing.Size(190, 35)
        Me.cmdDoFakeOrders.StyleSetName = "ManagerButton"
        Me.cmdDoFakeOrders.TabIndex = 501
        Me.cmdDoFakeOrders.Tag = "Do F Orders for demo"
        Me.cmdDoFakeOrders.Text = "Do F Orders for demo"
        Me.cmdDoFakeOrders.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDoFakeOrders.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdDoFakeOrders.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdDBBackup
        '
        Me.cmdDBBackup.Anchor = System.Windows.Forms.AnchorStyles.None
        Appearance8.BackColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance8.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance8.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance8.BorderAlpha = Infragistics.Win.Alpha.Opaque
        Appearance8.BorderColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance8.BorderColor2 = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance8.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance8.ForeColor = System.Drawing.Color.White
        Appearance8.Image = CType(resources.GetObject("Appearance8.Image"), Object)
        Appearance8.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance8.TextVAlignAsString = "Bottom"
        Me.cmdDBBackup.Appearance = Appearance8
        Me.cmdDBBackup.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance9.BackColor = System.Drawing.Color.PowderBlue
        Appearance9.BackColor2 = System.Drawing.Color.Aqua
        Appearance9.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance9.ForeColor = System.Drawing.Color.Black
        Me.cmdDBBackup.HotTrackAppearance = Appearance9
        Me.cmdDBBackup.ImageSize = New System.Drawing.Size(38, 38)
        Me.cmdDBBackup.Location = New System.Drawing.Point(278, 271)
        Me.cmdDBBackup.Name = "cmdDBBackup"
        Me.cmdDBBackup.ShowFocusRect = False
        Me.cmdDBBackup.ShowOutline = False
        Me.cmdDBBackup.Size = New System.Drawing.Size(192, 80)
        Me.cmdDBBackup.StyleSetName = "ManagerButton"
        Me.cmdDBBackup.TabIndex = 498
        Me.cmdDBBackup.Text = "Backup Database"
        Me.cmdDBBackup.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdDBBackup.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdDBBackup.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdTestWebserviceConn
        '
        Me.cmdTestWebserviceConn.Anchor = System.Windows.Forms.AnchorStyles.None
        Appearance10.BackColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance10.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance10.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance10.BorderAlpha = Infragistics.Win.Alpha.Opaque
        Appearance10.BorderColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance10.BorderColor2 = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance10.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance10.ForeColor = System.Drawing.Color.White
        Appearance10.Image = CType(resources.GetObject("Appearance10.Image"), Object)
        Appearance10.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance10.TextVAlignAsString = "Bottom"
        Me.cmdTestWebserviceConn.Appearance = Appearance10
        Me.cmdTestWebserviceConn.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance11.BackColor = System.Drawing.Color.PowderBlue
        Appearance11.BackColor2 = System.Drawing.Color.Aqua
        Appearance11.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance11.ForeColor = System.Drawing.Color.Black
        Me.cmdTestWebserviceConn.HotTrackAppearance = Appearance11
        Me.cmdTestWebserviceConn.ImageSize = New System.Drawing.Size(38, 38)
        Me.cmdTestWebserviceConn.Location = New System.Drawing.Point(66, 375)
        Me.cmdTestWebserviceConn.Name = "cmdTestWebserviceConn"
        Me.cmdTestWebserviceConn.ShowFocusRect = False
        Me.cmdTestWebserviceConn.ShowOutline = False
        Me.cmdTestWebserviceConn.Size = New System.Drawing.Size(192, 80)
        Me.cmdTestWebserviceConn.StyleSetName = "ManagerButton"
        Me.cmdTestWebserviceConn.TabIndex = 497
        Me.cmdTestWebserviceConn.Text = "Test Online Server Connection"
        Me.cmdTestWebserviceConn.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdTestWebserviceConn.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdTestWebserviceConn.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdRegister
        '
        Me.cmdRegister.Anchor = System.Windows.Forms.AnchorStyles.None
        Appearance12.BackColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance12.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance12.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance12.BorderAlpha = Infragistics.Win.Alpha.Opaque
        Appearance12.BorderColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance12.BorderColor2 = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance12.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance12.ForeColor = System.Drawing.Color.White
        Appearance12.Image = CType(resources.GetObject("Appearance12.Image"), Object)
        Appearance12.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance12.TextVAlignAsString = "Bottom"
        Me.cmdRegister.Appearance = Appearance12
        Me.cmdRegister.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance13.BackColor = System.Drawing.Color.PowderBlue
        Appearance13.BackColor2 = System.Drawing.Color.Aqua
        Appearance13.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance13.ForeColor = System.Drawing.Color.Black
        Me.cmdRegister.HotTrackAppearance = Appearance13
        Me.cmdRegister.ImageSize = New System.Drawing.Size(38, 38)
        Me.cmdRegister.Location = New System.Drawing.Point(490, 375)
        Me.cmdRegister.Name = "cmdRegister"
        Me.cmdRegister.ShowFocusRect = False
        Me.cmdRegister.ShowOutline = False
        Me.cmdRegister.Size = New System.Drawing.Size(192, 80)
        Me.cmdRegister.StyleSetName = "ManagerButton"
        Me.cmdRegister.TabIndex = 124
        Me.cmdRegister.Text = "Register"
        Me.cmdRegister.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdRegister.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdRegister.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdSQLQuery
        '
        Me.cmdSQLQuery.Anchor = System.Windows.Forms.AnchorStyles.None
        Appearance14.BackColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance14.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance14.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance14.BorderAlpha = Infragistics.Win.Alpha.Opaque
        Appearance14.BorderColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance14.BorderColor2 = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance14.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance14.ForeColor = System.Drawing.Color.White
        Appearance14.Image = CType(resources.GetObject("Appearance14.Image"), Object)
        Appearance14.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance14.TextVAlignAsString = "Bottom"
        Me.cmdSQLQuery.Appearance = Appearance14
        Me.cmdSQLQuery.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance15.BackColor = System.Drawing.Color.PowderBlue
        Appearance15.BackColor2 = System.Drawing.Color.Aqua
        Appearance15.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance15.ForeColor = System.Drawing.Color.Black
        Me.cmdSQLQuery.HotTrackAppearance = Appearance15
        Me.cmdSQLQuery.ImageSize = New System.Drawing.Size(38, 38)
        Me.cmdSQLQuery.Location = New System.Drawing.Point(66, 271)
        Me.cmdSQLQuery.Name = "cmdSQLQuery"
        Me.cmdSQLQuery.ShowFocusRect = False
        Me.cmdSQLQuery.ShowOutline = False
        Me.cmdSQLQuery.Size = New System.Drawing.Size(192, 80)
        Me.cmdSQLQuery.StyleSetName = "ManagerButton"
        Me.cmdSQLQuery.TabIndex = 131
        Me.cmdSQLQuery.Text = "Execute SQL"
        Me.cmdSQLQuery.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdSQLQuery.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdSQLQuery.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdViewLog
        '
        Me.cmdViewLog.Anchor = System.Windows.Forms.AnchorStyles.None
        Appearance16.BackColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance16.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance16.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance16.BorderAlpha = Infragistics.Win.Alpha.Opaque
        Appearance16.BorderColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance16.BorderColor2 = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance16.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance16.ForeColor = System.Drawing.Color.White
        Appearance16.Image = CType(resources.GetObject("Appearance16.Image"), Object)
        Appearance16.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance16.TextVAlignAsString = "Bottom"
        Me.cmdViewLog.Appearance = Appearance16
        Me.cmdViewLog.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance17.BackColor = System.Drawing.Color.PowderBlue
        Appearance17.BackColor2 = System.Drawing.Color.Aqua
        Appearance17.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance17.ForeColor = System.Drawing.Color.Black
        Me.cmdViewLog.HotTrackAppearance = Appearance17
        Me.cmdViewLog.ImageSize = New System.Drawing.Size(38, 38)
        Me.cmdViewLog.Location = New System.Drawing.Point(702, 167)
        Me.cmdViewLog.Name = "cmdViewLog"
        Me.cmdViewLog.ShowFocusRect = False
        Me.cmdViewLog.ShowOutline = False
        Me.cmdViewLog.Size = New System.Drawing.Size(192, 80)
        Me.cmdViewLog.StyleSetName = "ManagerButton"
        Me.cmdViewLog.TabIndex = 130
        Me.cmdViewLog.Text = "View log"
        Me.cmdViewLog.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdViewLog.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdViewLog.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdSettings
        '
        Me.cmdSettings.Anchor = System.Windows.Forms.AnchorStyles.None
        Appearance18.BackColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance18.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance18.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance18.BorderAlpha = Infragistics.Win.Alpha.Opaque
        Appearance18.BorderColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance18.BorderColor2 = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance18.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance18.ForeColor = System.Drawing.Color.White
        Appearance18.Image = CType(resources.GetObject("Appearance18.Image"), Object)
        Appearance18.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance18.TextVAlignAsString = "Bottom"
        Me.cmdSettings.Appearance = Appearance18
        Me.cmdSettings.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance19.BackColor = System.Drawing.Color.PowderBlue
        Appearance19.BackColor2 = System.Drawing.Color.Aqua
        Appearance19.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance19.ForeColor = System.Drawing.Color.Black
        Me.cmdSettings.HotTrackAppearance = Appearance19
        Me.cmdSettings.ImageSize = New System.Drawing.Size(38, 38)
        Me.cmdSettings.Location = New System.Drawing.Point(66, 63)
        Me.cmdSettings.Name = "cmdSettings"
        Me.cmdSettings.ShowFocusRect = False
        Me.cmdSettings.ShowOutline = False
        Me.cmdSettings.Size = New System.Drawing.Size(192, 80)
        Me.cmdSettings.StyleSetName = "ManagerButton"
        Me.cmdSettings.TabIndex = 127
        Me.cmdSettings.Text = "Settings"
        Me.cmdSettings.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdSettings.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdSettings.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdAbout
        '
        Me.cmdAbout.Anchor = System.Windows.Forms.AnchorStyles.None
        Appearance20.BackColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance20.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance20.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance20.BorderAlpha = Infragistics.Win.Alpha.Opaque
        Appearance20.BorderColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance20.BorderColor2 = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance20.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance20.ForeColor = System.Drawing.Color.White
        Appearance20.Image = CType(resources.GetObject("Appearance20.Image"), Object)
        Appearance20.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance20.TextVAlignAsString = "Bottom"
        Me.cmdAbout.Appearance = Appearance20
        Me.cmdAbout.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance21.BackColor = System.Drawing.Color.PowderBlue
        Appearance21.BackColor2 = System.Drawing.Color.Aqua
        Appearance21.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance21.ForeColor = System.Drawing.Color.Black
        Me.cmdAbout.HotTrackAppearance = Appearance21
        Me.cmdAbout.ImageSize = New System.Drawing.Size(38, 38)
        Me.cmdAbout.Location = New System.Drawing.Point(278, 375)
        Me.cmdAbout.Name = "cmdAbout"
        Me.cmdAbout.ShowFocusRect = False
        Me.cmdAbout.ShowOutline = False
        Me.cmdAbout.Size = New System.Drawing.Size(192, 80)
        Me.cmdAbout.StyleSetName = "ManagerButton"
        Me.cmdAbout.TabIndex = 125
        Me.cmdAbout.Text = "About"
        Me.cmdAbout.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdAbout.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdAbout.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdSummary
        '
        Me.cmdSummary.Anchor = System.Windows.Forms.AnchorStyles.None
        Appearance22.BackColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance22.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance22.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance22.BorderAlpha = Infragistics.Win.Alpha.Opaque
        Appearance22.BorderColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance22.BorderColor2 = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance22.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance22.ForeColor = System.Drawing.Color.White
        Appearance22.Image = CType(resources.GetObject("Appearance22.Image"), Object)
        Appearance22.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance22.TextVAlignAsString = "Bottom"
        Me.cmdSummary.Appearance = Appearance22
        Me.cmdSummary.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance23.BackColor = System.Drawing.Color.PowderBlue
        Appearance23.BackColor2 = System.Drawing.Color.Aqua
        Appearance23.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance23.ForeColor = System.Drawing.Color.Black
        Me.cmdSummary.HotTrackAppearance = Appearance23
        Me.cmdSummary.ImageSize = New System.Drawing.Size(38, 38)
        Me.cmdSummary.Location = New System.Drawing.Point(490, 167)
        Me.cmdSummary.Name = "cmdSummary"
        Me.cmdSummary.ShowFocusRect = False
        Me.cmdSummary.ShowOutline = False
        Me.cmdSummary.Size = New System.Drawing.Size(192, 80)
        Me.cmdSummary.StyleSetName = "ManagerButton"
        Me.cmdSummary.TabIndex = 123
        Me.cmdSummary.Text = "Summary"
        Me.cmdSummary.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdSummary.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdSummary.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdSetupDrinks
        '
        Me.cmdSetupDrinks.Anchor = System.Windows.Forms.AnchorStyles.None
        Appearance24.BackColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance24.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance24.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance24.BorderAlpha = Infragistics.Win.Alpha.Opaque
        Appearance24.BorderColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance24.BorderColor2 = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance24.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance24.ForeColor = System.Drawing.Color.White
        Appearance24.Image = CType(resources.GetObject("Appearance24.Image"), Object)
        Appearance24.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance24.TextVAlignAsString = "Bottom"
        Me.cmdSetupDrinks.Appearance = Appearance24
        Me.cmdSetupDrinks.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance25.BackColor = System.Drawing.Color.PowderBlue
        Appearance25.BackColor2 = System.Drawing.Color.Aqua
        Appearance25.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance25.ForeColor = System.Drawing.Color.Black
        Me.cmdSetupDrinks.HotTrackAppearance = Appearance25
        Me.cmdSetupDrinks.ImageSize = New System.Drawing.Size(38, 38)
        Me.cmdSetupDrinks.Location = New System.Drawing.Point(490, 63)
        Me.cmdSetupDrinks.Name = "cmdSetupDrinks"
        Me.cmdSetupDrinks.ShowFocusRect = False
        Me.cmdSetupDrinks.ShowOutline = False
        Me.cmdSetupDrinks.Size = New System.Drawing.Size(192, 80)
        Me.cmdSetupDrinks.StyleSetName = "ManagerButton"
        Me.cmdSetupDrinks.TabIndex = 122
        Me.cmdSetupDrinks.Text = "Drinks"
        Me.cmdSetupDrinks.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdSetupDrinks.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdSetupDrinks.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdCleanDB
        '
        Me.cmdCleanDB.Anchor = System.Windows.Forms.AnchorStyles.None
        Appearance26.BackColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance26.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance26.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance26.BorderAlpha = Infragistics.Win.Alpha.Opaque
        Appearance26.BorderColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance26.BorderColor2 = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance26.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance26.ForeColor = System.Drawing.Color.White
        Appearance26.Image = CType(resources.GetObject("Appearance26.Image"), Object)
        Appearance26.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance26.TextVAlignAsString = "Bottom"
        Me.cmdCleanDB.Appearance = Appearance26
        Me.cmdCleanDB.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance27.BackColor = System.Drawing.Color.PowderBlue
        Appearance27.BackColor2 = System.Drawing.Color.Aqua
        Appearance27.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance27.ForeColor = System.Drawing.Color.Black
        Me.cmdCleanDB.HotTrackAppearance = Appearance27
        Me.cmdCleanDB.ImageSize = New System.Drawing.Size(38, 38)
        Me.cmdCleanDB.Location = New System.Drawing.Point(66, 167)
        Me.cmdCleanDB.Name = "cmdCleanDB"
        Me.cmdCleanDB.ShowFocusRect = False
        Me.cmdCleanDB.ShowOutline = False
        Me.cmdCleanDB.Size = New System.Drawing.Size(192, 80)
        Me.cmdCleanDB.StyleSetName = "ManagerButton"
        Me.cmdCleanDB.TabIndex = 121
        Me.cmdCleanDB.Text = "Clear today's orders"
        Me.cmdCleanDB.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdCleanDB.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdCleanDB.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdBanking
        '
        Me.cmdBanking.Anchor = System.Windows.Forms.AnchorStyles.None
        Appearance28.BackColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance28.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance28.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance28.BorderAlpha = Infragistics.Win.Alpha.Opaque
        Appearance28.BorderColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance28.BorderColor2 = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance28.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance28.ForeColor = System.Drawing.Color.White
        Appearance28.Image = CType(resources.GetObject("Appearance28.Image"), Object)
        Appearance28.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance28.TextVAlignAsString = "Bottom"
        Me.cmdBanking.Appearance = Appearance28
        Me.cmdBanking.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance29.BackColor = System.Drawing.Color.PowderBlue
        Appearance29.BackColor2 = System.Drawing.Color.Aqua
        Appearance29.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance29.ForeColor = System.Drawing.Color.Black
        Me.cmdBanking.HotTrackAppearance = Appearance29
        Me.cmdBanking.ImageSize = New System.Drawing.Size(38, 38)
        Me.cmdBanking.Location = New System.Drawing.Point(278, 167)
        Me.cmdBanking.Name = "cmdBanking"
        Me.cmdBanking.ShowFocusRect = False
        Me.cmdBanking.ShowOutline = False
        Me.cmdBanking.Size = New System.Drawing.Size(192, 80)
        Me.cmdBanking.StyleSetName = "ManagerButton"
        Me.cmdBanking.TabIndex = 120
        Me.cmdBanking.Text = "Banking"
        Me.cmdBanking.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdBanking.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdBanking.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdSetupCustomer
        '
        Me.cmdSetupCustomer.Anchor = System.Windows.Forms.AnchorStyles.None
        Appearance30.BackColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance30.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance30.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance30.BorderAlpha = Infragistics.Win.Alpha.Opaque
        Appearance30.BorderColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance30.BorderColor2 = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance30.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance30.ForeColor = System.Drawing.Color.White
        Appearance30.Image = CType(resources.GetObject("Appearance30.Image"), Object)
        Appearance30.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance30.TextVAlignAsString = "Bottom"
        Me.cmdSetupCustomer.Appearance = Appearance30
        Me.cmdSetupCustomer.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance31.BackColor = System.Drawing.Color.PowderBlue
        Appearance31.BackColor2 = System.Drawing.Color.Aqua
        Appearance31.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance31.ForeColor = System.Drawing.Color.Black
        Me.cmdSetupCustomer.HotTrackAppearance = Appearance31
        Me.cmdSetupCustomer.ImageSize = New System.Drawing.Size(38, 38)
        Me.cmdSetupCustomer.Location = New System.Drawing.Point(702, 63)
        Me.cmdSetupCustomer.Name = "cmdSetupCustomer"
        Me.cmdSetupCustomer.ShowFocusRect = False
        Me.cmdSetupCustomer.ShowOutline = False
        Me.cmdSetupCustomer.Size = New System.Drawing.Size(192, 80)
        Me.cmdSetupCustomer.StyleSetName = "ManagerButton"
        Me.cmdSetupCustomer.TabIndex = 119
        Me.cmdSetupCustomer.Text = "Customers"
        Me.cmdSetupCustomer.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdSetupCustomer.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdSetupCustomer.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdSetupDishes
        '
        Me.cmdSetupDishes.Anchor = System.Windows.Forms.AnchorStyles.None
        Appearance32.BackColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance32.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(230, Byte), Integer))
        Appearance32.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance32.BorderAlpha = Infragistics.Win.Alpha.Opaque
        Appearance32.BorderColor = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance32.BorderColor2 = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance32.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(120, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Appearance32.ForeColor = System.Drawing.Color.White
        Appearance32.Image = CType(resources.GetObject("Appearance32.Image"), Object)
        Appearance32.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance32.TextVAlignAsString = "Bottom"
        Me.cmdSetupDishes.Appearance = Appearance32
        Me.cmdSetupDishes.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance33.BackColor = System.Drawing.Color.PowderBlue
        Appearance33.BackColor2 = System.Drawing.Color.Aqua
        Appearance33.BackGradientStyle = Infragistics.Win.GradientStyle.GlassBottom50
        Appearance33.ForeColor = System.Drawing.Color.Black
        Me.cmdSetupDishes.HotTrackAppearance = Appearance33
        Me.cmdSetupDishes.ImageSize = New System.Drawing.Size(38, 38)
        Me.cmdSetupDishes.Location = New System.Drawing.Point(278, 63)
        Me.cmdSetupDishes.Name = "cmdSetupDishes"
        Me.cmdSetupDishes.ShowFocusRect = False
        Me.cmdSetupDishes.ShowOutline = False
        Me.cmdSetupDishes.Size = New System.Drawing.Size(192, 80)
        Me.cmdSetupDishes.StyleSetName = "ManagerButton"
        Me.cmdSetupDishes.TabIndex = 118
        Me.cmdSetupDishes.Text = "Dishes"
        Me.cmdSetupDishes.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdSetupDishes.UseHotTracking = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmdSetupDishes.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'pnlHeader
        '
        Me.pnlHeader.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance34.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.pnlHeader.Appearance = Appearance34
        '
        'pnlHeader.ClientArea
        '
        Me.pnlHeader.ClientArea.Controls.Add(Me.lblHeader)
        Me.pnlHeader.Location = New System.Drawing.Point(2, 0)
        Me.pnlHeader.Name = "pnlHeader"
        Me.pnlHeader.Size = New System.Drawing.Size(1185, 42)
        Me.pnlHeader.StyleSetName = "Reservation"
        Me.pnlHeader.TabIndex = 549
        Me.pnlHeader.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblHeader
        '
        Appearance35.BackColor = System.Drawing.Color.Transparent
        Appearance35.ForeColor = System.Drawing.Color.Maroon
        Appearance35.TextVAlignAsString = "Middle"
        Me.lblHeader.Appearance = Appearance35
        Me.lblHeader.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHeader.Location = New System.Drawing.Point(1, 4)
        Me.lblHeader.Name = "lblHeader"
        Me.lblHeader.Size = New System.Drawing.Size(240, 35)
        Me.lblHeader.StyleSetName = "Reservation"
        Me.lblHeader.TabIndex = 460
        Me.lblHeader.Text = "ezMENU"
        Me.lblHeader.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdBack
        '
        Me.cmdBack.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Appearance36.BackColor = System.Drawing.Color.Transparent
        Appearance36.BackColor2 = System.Drawing.Color.Transparent
        Appearance36.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance36.BorderAlpha = Infragistics.Win.Alpha.UseAlphaLevel
        Appearance36.BorderColor2 = System.Drawing.Color.Maroon
        Appearance36.BorderColor3DBase = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Appearance36.ForeColor = System.Drawing.Color.White
        Appearance36.Image = CType(resources.GetObject("Appearance36.Image"), Object)
        Appearance36.ImageHAlign = Infragistics.Win.HAlign.Center
        Appearance36.ImageVAlign = Infragistics.Win.VAlign.Middle
        Appearance36.TextVAlignAsString = "Bottom"
        Me.cmdBack.Appearance = Appearance36
        Me.cmdBack.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless
        Me.cmdBack.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance37.BackColor = System.Drawing.Color.DarkOrange
        Appearance37.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance37.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance37.BorderColor = System.Drawing.Color.Transparent
        Appearance37.ForeColor = System.Drawing.Color.Black
        Me.cmdBack.HotTrackAppearance = Appearance37
        Me.cmdBack.ImageSize = New System.Drawing.Size(28, 28)
        Me.cmdBack.Location = New System.Drawing.Point(558, 640)
        Me.cmdBack.Name = "cmdBack"
        Me.cmdBack.Padding = New System.Drawing.Size(15, 0)
        Appearance38.BackColor = System.Drawing.Color.OrangeRed
        Appearance38.BackColor2 = System.Drawing.Color.Tomato
        Appearance38.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance38.BorderColor = System.Drawing.Color.Transparent
        Me.cmdBack.PressedAppearance = Appearance38
        Me.cmdBack.ShowFocusRect = False
        Me.cmdBack.ShowOutline = False
        Me.cmdBack.Size = New System.Drawing.Size(64, 44)
        Me.cmdBack.StyleSetName = "StatusBar"
        Me.cmdBack.TabIndex = 581
        Me.cmdBack.Tag = "Return"
        Me.cmdBack.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdBack.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdBack.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'usbManager
        '
        Me.usbManager.Location = New System.Drawing.Point(0, 690)
        Me.usbManager.Name = "usbManager"
        Me.usbManager.Size = New System.Drawing.Size(1183, 23)
        Me.usbManager.TabIndex = 582
        '
        'frmManager
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(1183, 713)
        Me.ControlBox = False
        Me.Controls.Add(Me.usbManager)
        Me.Controls.Add(Me.cmdBack)
        Me.Controls.Add(Me.pnlHeader)
        Me.Controls.Add(Me.upnlMainOptions)
        Me.DoubleBuffered = True
        Me.Name = "frmManager"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.upnlMainOptions.ClientArea.ResumeLayout(False)
        Me.upnlMainOptions.ResumeLayout(False)
        Me.pnlHeader.ClientArea.ResumeLayout(False)
        Me.pnlHeader.ResumeLayout(False)
        CType(Me.usbManager, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents upnlMainOptions As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents cmdBanking As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdSetupCustomer As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdSetupDishes As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdCleanDB As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdSetupDrinks As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdSummary As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdRegister As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdAbout As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdSettings As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdViewLog As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdSQLQuery As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdTestWebserviceConn As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDBRestore As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDBBackup As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdClearPrintSpooler As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdDoFakeOrders As Infragistics.Win.Misc.UltraButton
    Friend WithEvents pnlHeader As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents lblHeader As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents cmdBack As Infragistics.Win.Misc.UltraButton
    Friend WithEvents usbManager As Infragistics.Win.UltraWinStatusBar.UltraStatusBar
End Class
