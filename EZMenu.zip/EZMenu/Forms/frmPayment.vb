﻿Imports EZControls
Imports EZMenu.Core.Enums
Imports Infragistics.Win.Misc

Public Class frmPayment

    Public Property CurrentOrderType

    Private blnClearBox As Boolean
    Private ctrlTextbox As TextBox
    Private gridRowIndex As Integer

    Private Sub frmPayment_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Size = Owner.Size
        Location = Owner.Location

        GetEZKBColors()

        ctrlTextbox = txtTendered

    End Sub

    Private Sub cmdTenderExact_Click(sender As Object, e As EventArgs) Handles cmdTenderExact.Click

        blnClearBox = True

        txtTendered.Text = txtBillTotal.Text
        CalculateChange()

    End Sub

    Private Sub cmdTender102050_Click(sender As Object, e As EventArgs) Handles cmdTender10.Click, cmdTender20.Click, cmdTender50.Click

        blnClearBox = True
        txtTendered.Text = sender.tag
        CalculateChange()

    End Sub

    Private Sub NumHandler(sender As Object, e As EventArgs) Handles cmdNum0.Click, cmdNum1.Click, cmdNum2.Click, cmdNum3.Click,
        cmdNum4.Click, cmdNum5.Click, cmdNum6.Click, cmdNum7.Click, cmdNum8.Click, cmdNum9.Click

        If blnClearBox = True Then
            ctrlTextbox.Text = "0.00"
            blnClearBox = False
        End If

        AppendNum(ctrlTextbox, sender.text, 8)
        If ctrlTextbox Is txtTendered Then CalculateChange()

    End Sub

    Private Sub cmdNumDot_Click(sender As Object, e As EventArgs) Handles cmdNumDot.Click

        If blnClearBox = True Then
            ctrlTextbox.Text = "0.00"
            blnClearBox = False
        End If

        If InStr(txtTendered.Text, ".") = 0 Then
            ctrlTextbox.Text &= "."
        End If

    End Sub

    Private Sub CalculateChange()

        Try
            txtChange.Text = fixCur(CDec(txtTendered.Text) - CDec(txtBillTotal.Text))
        Catch ex As Exception
            txtChange.Text = "- ERROR -"
        End Try

        Try
            If CDec(txtChange.Text) < 0 Then
                txtChange.ForeColor = Color.Red
            Else
                txtChange.ForeColor = Color.Navy
            End If
        Catch ex As Exception

        End Try

    End Sub

    Private Sub cmdClearTendered_Click(sender As Object, e As EventArgs) Handles cmdClearTender.Click

        ctrlTextbox.Text = "0.00"
        If ctrlTextbox.Name = txtTendered.Name Then txtChange.Clear()

    End Sub

    Private Sub cmdOEHome_Click(sender As Object, e As EventArgs) Handles cmdOEHome.Click

        Try

            If objOrders.Tag = "EditMode" Then
                strMsgBox = "Any changes made have not been saved. Do you want to cancel edit and return to orders?"
                intMsgBoxResult = EZMsgBox.Show(strMsgBox, MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                If intMsgBoxResult = MsgBoxResult.Yes Then
                    Hide()
                    objOrders.Tag = Nothing
                    objOrders.Visible = True
                    Application.DoEvents()
                    objDelivColn.Dispose()
                    objOrderEntry.Dispose()
                    Dispose()
                End If
            Else
                If Tag = "Tables" Then
                    Hide()
                Else
                    strMsgBox = "Do you wish to return to home screen?"
                    intMsgBoxResult = EZMsgBox.Show(strMsgBox, MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                    If intMsgBoxResult = MsgBoxResult.Yes Then
                        ShowHomeScreen()
                    End If
                End If
            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub cmdPrintOrder_Click(sender As Object, e As EventArgs) Handles cmdPrintOrder.Click

        Try
            If ValidatePaymentFormOK() = True Then

                CollateOrderInformation(CurrentOrderType, PrintDestinationEnum.Both)

                cmdPrintOrder.Enabled = False

                If GetAppSettingCS("PrintLabels" & intCurrentCuisine, True) = True Then PrintLabels()

                cmdPrintOrder.Enabled = True
                cmdPrintOrder.Appearance.Image = My.Resources.ezresource.inkjet_printer_done

                If GetAppSettingCS("ShowHomeAfterPrint", True) = True Then
                    Application.DoEvents()
                    Sleep(2000)
                    ShowHomeScreen()
                End If

            End If

        Catch ex As Exception
            DisplayError(ex)
        Finally
            cmdPrintOrder.Enabled = True
        End Try

    End Sub

    Private Sub cmdClearDelivTime_Click(sender As Object, e As EventArgs)

        lblTime.Text = "Time: ASAP"

    End Sub

    Private Sub PaidWaitingHandler(sender As Object, e As EventArgs) Handles cmdPaid.Click, cmdWaiting.Click

        Dim ubtnButton As UltraButton = DirectCast(sender, UltraButton)
        ubtnButton.Tag = IIf(ubtnButton.Tag = cstButTogYes, cstButTogClr, cstButTogYes)
        ButtonToggle(ubtnButton, ubtnButton.Tag)

    End Sub

    Private Sub TenderHandler(sender As Object, e As EventArgs) Handles cmdTenderCash.Click, cmdTenderCard.Click, cmdTenderOther.Click

        Dim blnImagedButton As Boolean = (sender.Appearance.Image IsNot Nothing)

        ButtonToggle(cmdTenderCash, cstButTogClr)
        ButtonToggle(cmdTenderCard, cstButTogClr)
        ButtonToggle(cmdTenderOther, cstButTogClr)
        If GetAppSettingCS("AutoMarkPaid", True) Then
            ButtonToggle(cmdPaid, cstButTogClr)
            cmdPaid.Enabled = True
        End If

        If blnImagedButton = False Then
            ButtonToggle(sender, cstButTogYes)
            If GetAppSettingCS("AutoMarkPaid", True) Then
                ButtonToggle(cmdPaid, cstButTogYes)
                cmdPaid.Enabled = False
            End If
        End If

        If CurrentOrderType = OrderTypeEnum.Table Then
            'save paymethod here
            If Abs(cmdTenderCard.Tag) = 1 Then
                tempStr = "'Card'"
            ElseIf Abs(cmdTenderCash.Tag) = 1 Then
                tempStr = "'Cash'"
            ElseIf Abs(cmdTenderOther.Tag) = 1 Then
                tempStr = "'Other'"
            Else
                tempStr = "''"
            End If

            SQLQuery = String.Format("UPDATE Table_Bill SET PayMethod = {0}, Tips = {1}, " &
                                     "PCash = {2}, PCard = {3}, POther = {4}, TCash = {5}, TCard = {6}, TOther = {7} " &
                                     "WHERE TabUniqueID = {8}", tempStr, Val(txtTips.Text), 0, 0, 0, 0, 0, 0, TableInfo(CurTable).Id)
            objDB.ExeNonQuery(SQLQuery)

        End If

    End Sub

    Private Sub cmdBack_Click(sender As Object, e As EventArgs) Handles cmdBack.Click
        Hide()
    End Sub

    Private Sub cmdKSCopy_Click(sender As Object, e As EventArgs) Handles cmdKitchenCopy.Click, cmdShopCopy.Click

        If ValidatePaymentFormOK() = True Then
            CollateOrderInformation(CurrentOrderType, IIf(sender Is cmdKitchenCopy, PrintDestinationEnum.Kitchen, PrintDestinationEnum.Shop))
        End If

    End Sub

    Private Sub cmdSaveOrder_Click(sender As Object, e As EventArgs) Handles cmdSaveOrder.Click

        Try

            'this is for edit mode
            If objOrders.Tag = "EditMode" Then

                If ValidatePaymentFormOK() = True Then
                    'now save updates
                    UpdateOrderToDB()
                    objOrders.RefreshOrdersGrid()

                    objDelivColn.Visible = False
                    objOrderEntry.Visible = False
                    Visible = False
                    objOrders.Tag = Nothing
                    objOrders.Visible = True
                    StartNewOrder()
                End If

            Else

                'now save everything
                CollateOrderInformation(CurrentOrderType, PrintDestinationEnum.SaveOnly)

                strMsgBox = "Order has been saved"
                Alert(strMsgBox)

            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub cmdClearKitchenNote_Click(sender As Object, e As EventArgs) Handles cmdClearKitchenNote.Click

        txtKitchenNote.Clear()

    End Sub

    Private Function ValidatePaymentFormOK() As Boolean
        'check form to make sure everything entered is ok

        'check time entered is valid
        If FixTime() <> "ASAP" AndAlso Not IsDate(FixTime()) Then
            Alert("Entered time is not valid.")
            Return False
        End If

        'waiting order cannot have a time
        If cmdWaiting.Tag = cstButTogYes AndAlso FixTime() <> "ASAP" Then
            strMsgBox = "An order cannot be both waiting and timed. You must select only one of these options."
            Alert(strMsgBox, MessageBoxIcon.Exclamation)
            Return False
        End If

        Return True

    End Function

    Private Sub UpdateOrderToDB()

        Dim a1, strDish As String
        Dim intUDiscount, intDCode, intUDQty, intUGrpIndex As Short
        Dim decUPrice As Decimal
        Dim blnSaveToCustomer As Boolean

        'delete all order details from the Order Details table
        SQLQuery = "DELETE FROM OrderItems WHERE OrderID = " & OrderID
        objDB.ExeNonQuery(SQLQuery)
        SQLQuery = "DELETE FROM OrderMods WHERE OrderID = " & OrderID
        objDB.ExeNonQuery(SQLQuery)
        SQLQuery = "DELETE FROM SetItems WHERE OrderID = " & OrderID
        objDB.ExeNonQuery(SQLQuery)

        a1 = String.Format("SET BillTotal = {0}, Subtotal = {1}, ChargeAmount = {2}, DiscountAmount = {3}",
            CDec(objOrderEntry.lblToPay.Text), CDec(objOrderEntry.lblSubtotal.Text), Abs(CDec(objOrderEntry.lblPriceAdjDiscounts.Text)), CDec(objOrderEntry.lblPriceAdjCharges.Text))

        If CustID < intMaxCustomerID Then
            'this is a delivery order
            SQLQuery = "UPDATE Orders SET CollectionOrDeliveryTime = Null WHERE OrderID = " & OrderID
            objDB.ExeNonQuery(SQLQuery)

            If FixTime() <> "ASAP" Then a1 &= ", CollectionOrDeliveryTime = '" & FixTime() & "'"

            If GetAppSettingCS("SaveCustomerHistory", True) = True Then
                'delete existing customer order
                objDB.ExeNonQuery("DELETE FROM CustOrders WHERE CustomerID = " & CustID)
                objDB.ExeNonQuery("DELETE FROM CustOrderItems WHERE CustomerID = " & CustID)
                blnSaveToCustomer = True
            End If

        Else
            'Collection tab is selected

            'Leave this line because CustID is worked out just above
            'a2 = CustID & "," & Total

            If objDelivColn.txtName.Text <> "" Then
                a1 &= ", CustomerName = '" & objDelivColn.txtName.Text & "'"
            Else
                a1 &= ",CustomerName = ''"
            End If

            If FixTime() <> "ASAP" Then
                a1 &= ", CollectionOrDeliveryTime = '" & FixTime() & "'"
            Else
                a1 &= ", CollectionOrDeliveryTime = NULL"
            End If

            If cmdWaiting.Tag = cstButTogYes Then
                a1 &= ", CustomerIsWaiting = 1"
            Else
                a1 &= ", CustomerIsWaiting = 0"
            End If

        End If

        'save discount and charges
        'a1 &= String.Format(", Charge2 = {0}, Charge2AorP = '{1}', Charge2Rate = {2}, Discount2 = {3}, Discount2AorP = '{4}', Discount2Rate = {5}",
        '                    GlobalCharges.Charge2, GlobalCharges.Charge2AorP, GlobalCharges.Charge2Rate, GlobalDiscounts.Discount2, GlobalDiscounts.Discount2AorP, GlobalDiscounts.Discount2Rate)

        'settings applicable to both C and D
        If cmdPaid.Tag = cstButTogYes Then
            a1 &= ", OrderIsPaid = 1"
        Else
            a1 &= ", OrderIsPaid = 0"
        End If

        'append kitchen note here
        If txtKitchenNote.Text.Trim <> String.Empty Then
            a1 &= ", KitchenNote = '" & txtKitchenNote.Text.Trim.Punctuate & "'"
        End If

        'save drink to db
        If objOrderEntry.lblDrinksOE.Visible = True Then
            a1 &= ", DrinksTotal = " & CDec(objOrderEntry.lblDrinksOE.Text)
        Else
            a1 &= ", DrinksTotal = 0"
        End If

        'save paymethod here
        If Abs(cmdTenderCard.Tag) = 1 Then
            a1 &= ", PayMethod = 'Card'"
        ElseIf Abs(cmdTenderCash.Tag) = 1 Then
            a1 &= ", PayMethod = 'Cash'"
        ElseIf Abs(cmdTenderOther.Tag) = 1 Then
            a1 &= ", PayMethod = 'Other'"
        Else
            a1 &= ", PayMethod = ''"
        End If

        SQLQuery = "UPDATE Orders " & a1 & " WHERE OrderID = " & OrderID

        objDB.ExeNonQuery(SQLQuery)

        'save customer order history
        If blnSaveToCustomer = True Then
            Try
                SQLQuery = Replace(SQLQuery, "UPDATE Orders", "UPDATE CustOrders")
                objDB.ExeNonQuery(SQLQuery)
            Catch ex As Exception
                DisplayError(ex)
            End Try
        End If

        'save any drinks ordered to the db
        If (objTables IsNot Nothing) AndAlso (objTables.Tag = "DrinkAway" Or objTables.Tag = "DrinkAwayEdit") Then

            Dim Dk_Name, Dk_Price, Dk_Qty As String

            'first delete existing drinks from the order
            SQLQuery = "DELETE FROM CollectionDrinks WHERE OrderID = " & OrderID
            objDB.ExeNonQuery(SQLQuery)

            'now insert the drinks in the DB table
            With objTables.ugdDrinksGrid
                For Each mrow In .Rows
                    gridRowIndex = mrow.Index
                    Dk_Name = .Rows(gridRowIndex).Cells("DkName").Value().ToString.Punctuate
                    Dk_Qty = .Rows(gridRowIndex).Cells("DkQty").Value()
                    Dk_Price = .Rows(gridRowIndex).Cells("DkPrice").Value()
                    SQLQuery = "INSERT INTO CollectionDrinks (OrderID, DkName, DkQty, DkPrice) " &
                               "VALUES (" & OrderID & ",'" & Dk_Name & "','" & Dk_Qty & "','" & Dk_Price & "');"

                    'execute the SQL command
                    objDB.ExeNonQuery(SQLQuery)
                Next
            End With
        End If

        'put all the order information in the OrderItems table
        With objOrderEntry.ugdOrderGrid
            For Each mrow In .Rows
                gridRowIndex = mrow.Index
                If RowIsNotModOrSet(gridRowIndex) Then
                    intDCode = .Rows(gridRowIndex).Cells("DCode").Value
                    strDish = .Rows(gridRowIndex).Cells("DName").Value.ToString.Punctuate
                    intUDQty = CShort(.Rows(gridRowIndex).Cells("DQty").Value)
                    decUPrice = CDec(.Rows(gridRowIndex).Cells("DPrice").Value)
                    'save any modifiers
                    If GetAnyModifiers(gridRowIndex).Punctuate = String.Empty Then ModsSet = "0" Else ModsSet = "1"
                    'check if set meal
                    If GetSetItemsInGrid(gridRowIndex).Punctuate = String.Empty Then ModsSet &= "0" Else ModsSet &= "1"

                    intUDiscount = CShort(.Rows(gridRowIndex).Cells("Discountable").Value)
                    intUGrpIndex = CShort(.Rows(gridRowIndex).Cells("GroupIndex").Value)

                    SQLQuery = "INSERT INTO OrderItems " &
                        "(OrderID, Code, Dish, Qty, Mods, UnitPrice, Discountable, GroupIndex) VALUES " &
                        "(" & OrderID & ", " & intDCode & ", '" & strDish & "', " & intUDQty & ", '" & ModsSet & "', " & decUPrice & ", " & intUDiscount & ", " & intUGrpIndex & ");"
                    objDB.ExeNonQuery(SQLQuery)
                    If ModsSet.Substring(0, 1) = "1" Then objDB.SaveOrderModsToDB(gridRowIndex, OrderID, strDish)
                    If ModsSet.Substring(1, 1) = "1" Then objDB.SaveSetItemsToDB(gridRowIndex, OrderID, strDish)
                    If blnSaveToCustomer = True Then
                        SQLQuery = String.Format("INSERT INTO CustOrderItems (CustomerID, Code, Dish, Qty, Mods, UnitPrice, Discountable, GroupIndex) " &
                                                    "VALUES ({0}, {1}, '{2}', {3}, '{4}', {5}, {6}, {7})",
                                                    CustID, intDCode, strDish, intUDQty, ModsSet, decUPrice, intUDiscount, intUGrpIndex)
                        objDB.ExeNonQuery(SQLQuery)
                    End If
                End If
            Next
        End With

        strMsgBox = "This order has been updated"
        Alert(strMsgBox)

    End Sub

    Private Sub OnlyNumeric(sender As Object, e As KeyPressEventArgs)

        'only accept numbers

        Select Case e.KeyChar
            Case ChrW(Keys.D0) To ChrW(Keys.D9), ChrW(Keys.Back), ChrW(Keys.Return)
                e.Handled = False
            Case Else
                e.Handled = True
        End Select

    End Sub

    Private Sub cmdKBTime_Click(sender As Object, e As EventArgs) Handles cmdKBTime.Click

        Try

            If lblTime.Text = "Time: ASAP" Then

                Dim strTimeValue As String = TimesGrid.Show

                If strTimeValue <> String.Empty Then
                    If strTimeValue <> "0:00" Then
                        If IsDate(strTimeValue) Then
                            'txtTimeHH.Text = strTimeValue.Substring(0, strTimeValue.IndexOf(":"))
                            'txtTimeMM.Text = strTimeValue.Substring(strTimeValue.IndexOf(":") + 1, 2)
                            lblTime.Text = "Time: " & strTimeValue
                        Else
                            strMsgBox = "Entered time is invalid"
                            Alert(strMsgBox, MessageBoxIcon.Error)
                        End If
                    End If
                End If
            Else

                lblTime.Text = "Time: ASAP"

            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub ubtnTips_Click(sender As Object, e As EventArgs) Handles ubtnTips.Click

        Dim decTips As Decimal

        If Not IsANumber(txtChange.Text) Then decTips = 0 Else decTips = Convert.ToDecimal(txtChange.Text)
        txtTips.Text = fixCur(decTips)
        SQLQuery = $"UPDATE Table_Bill 
                     SET Tips = {decTips}  
                     WHERE TabUniqueID = {TableInfo(CurTable).Id}"
        objDB.ExeNonQuery(SQLQuery)

    End Sub

    Private Sub txtTendered_Enter(sender As Object, e As EventArgs) Handles txtTendered.Enter, txtTips.Enter

        ctrlTextbox = CType(sender, TextBox)
        ctrlTextbox.BackColor = Color.Khaki
        ctrlTextbox.ForeColor = Color.Black
        blnClearBox = True

    End Sub

    Private Sub txtTendered_Leave(sender As Object, e As EventArgs) Handles txtTendered.Leave, txtTips.Leave

        ctrlTextbox.BackColor = Color.White
        ctrlTextbox.ForeColor = Color.Black

    End Sub

    Private Sub cmdSplitPayment_Click(sender As Object, e As EventArgs) Handles cmdSplitPayment.Click

        cmdSplitPayment.Tag = String.Empty

        Using objForm As New frmSplitBill(Me, CurrentOrderType)
            objForm.ShowDialog()
        End Using

    End Sub

    Private Sub ClearMixPayment()

        SQLQuery = $"UPDATE Table_Bill 
                     SET PayMethod = '', PCash = 0, PCard = 0, POther = 0, TCash = 0, TCard = 0, TOther = 0 
                     WHERE TabUniqueID = { TableInfo(CurTable).Id }"
        objDB.ExeNonQuery(SQLQuery)

    End Sub

    Private Sub txtTips_TextChanged(sender As Object, e As EventArgs) Handles txtTips.TextChanged

        If IsANumber(txtTips.Text) AndAlso CurTable > 0 Then
            SQLQuery = $"UPDATE Table_Bill 
                         SET Tips = { CDec(txtTips.Text) } 
                         WHERE TabUniqueID = { TableInfo(CurTable).Id }"
            objDB.ExeNonQuery(SQLQuery)
        End If

    End Sub

    Public Function FixTime(Optional strMode As String = "") As String

        Dim strMyTime As String = lblTime.Text.Substring(6).Trim

        If strMode = "H" Then
            Return CDate(strMyTime).Hour

        ElseIf strMode = "M" Then
            Return CDate(strMyTime).Minute

        Else
            Return strMyTime

        End If

    End Function

    Private Sub cmdSplitDishes_Click(sender As Object, e As EventArgs) Handles cmdSplitDishes.Click

        If CurrentOrderType = OrderTypeEnum.Table Then
            Alert("This is not availble for tables")
            Exit Sub

        Else
            Using objForm As New frmSplitDishes
                objForm.DishArray = objOrderEntry.ugdOrderGrid
                objForm.ShowDialog(Me)
            End Using

        End If

    End Sub

    Private Sub GetEZKBColors()

        Try

            Dim strTemp As String = GetAppSettingCS("EZKB_ForeColor_Payment", "")
            If strTemp <> "" Then
                'SMX ezkbdKeyboard.EZKBForeColor = Color.FromArgb(strTemp)
            End If

            strTemp = GetAppSettingCS("EZKB_BackColor_Payment", "")
            If strTemp <> "" Then
                'SMX ezkbdKeyboard.EZKBBackColor = Color.FromArgb(strTemp)
            End If

        Catch ex As Exception

        End Try

    End Sub

    Private Sub txtKitchenNote_TextChanged(sender As Object, e As EventArgs) Handles txtKitchenNote.TextChanged

        cmdClearKitchenNote.Visible = (txtKitchenNote.Text.Trim.Length > 0)

    End Sub

    Private Sub cmdKBNote_Click(sender As Object, e As EventArgs) Handles cmdKBNote.Click

        strKBInput = EZFullKeyboard.Show(txtKitchenNote.Text)
        If strKBInput <> EZKBEscape Then
            txtKitchenNote.Text = strKBInput.Trim
        End If

    End Sub

End Class