﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmQty
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim Appearance1 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance2 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance3 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance4 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance5 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance6 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance7 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance8 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance9 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance10 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance11 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance12 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance13 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance14 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance15 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance16 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance17 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance18 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance19 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance20 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance21 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance22 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance23 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance24 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance25 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance26 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance27 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance28 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance29 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance30 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance31 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance32 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance33 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance34 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance35 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance36 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance37 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance38 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance39 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance40 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance41 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance42 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance43 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance44 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Me.txtTotal = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.lblCaption = New System.Windows.Forms.Label()
        Me.UltraPanel1 = New Infragistics.Win.Misc.UltraPanel()
        Me.cmdOK = New Infragistics.Win.Misc.UltraButton()
        Me.cmdBack = New Infragistics.Win.Misc.UltraButton()
        Me.ubtn8 = New Infragistics.Win.Misc.UltraButton()
        Me.cmdClear = New Infragistics.Win.Misc.UltraButton()
        Me.ubtn7 = New Infragistics.Win.Misc.UltraButton()
        Me.ubtn0 = New Infragistics.Win.Misc.UltraButton()
        Me.ubtn9 = New Infragistics.Win.Misc.UltraButton()
        Me.ubtnDot = New Infragistics.Win.Misc.UltraButton()
        Me.ubtn5 = New Infragistics.Win.Misc.UltraButton()
        Me.ubtn3 = New Infragistics.Win.Misc.UltraButton()
        Me.ubtn4 = New Infragistics.Win.Misc.UltraButton()
        Me.ubtn1 = New Infragistics.Win.Misc.UltraButton()
        Me.ubtn6 = New Infragistics.Win.Misc.UltraButton()
        Me.ubtn2 = New Infragistics.Win.Misc.UltraButton()
        CType(Me.txtTotal, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.UltraPanel1.ClientArea.SuspendLayout()
        Me.UltraPanel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtTotal
        '
        Appearance1.BackColor = System.Drawing.Color.White
        Appearance1.BackColor2 = System.Drawing.Color.White
        Appearance1.BorderColor = System.Drawing.Color.Gainsboro
        Appearance1.ForeColor = System.Drawing.Color.DimGray
        Appearance1.TextHAlignAsString = "Right"
        Me.txtTotal.Appearance = Appearance1
        Me.txtTotal.AutoSize = False
        Me.txtTotal.BackColor = System.Drawing.Color.White
        Me.txtTotal.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Me.txtTotal.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotal.Location = New System.Drawing.Point(35, 70)
        Me.txtTotal.MaxLength = 8
        Me.txtTotal.Name = "txtTotal"
        Me.txtTotal.Size = New System.Drawing.Size(198, 45)
        Me.txtTotal.TabIndex = 139
        Me.txtTotal.Text = "0"
        Me.txtTotal.UseAppStyling = False
        Me.txtTotal.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'lblCaption
        '
        Me.lblCaption.BackColor = System.Drawing.Color.Transparent
        Me.lblCaption.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCaption.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.lblCaption.Location = New System.Drawing.Point(21, 10)
        Me.lblCaption.Name = "lblCaption"
        Me.lblCaption.Size = New System.Drawing.Size(227, 46)
        Me.lblCaption.TabIndex = 470
        Me.lblCaption.Text = "1234567890"
        Me.lblCaption.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'UltraPanel1
        '
        Appearance2.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.UltraPanel1.Appearance = Appearance2
        Me.UltraPanel1.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded4Thick
        '
        'UltraPanel1.ClientArea
        '
        Me.UltraPanel1.ClientArea.Controls.Add(Me.cmdOK)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.lblCaption)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.cmdBack)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.txtTotal)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.ubtn8)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.cmdClear)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.ubtn7)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.ubtn0)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.ubtn9)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.ubtnDot)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.ubtn5)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.ubtn3)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.ubtn4)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.ubtn1)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.ubtn6)
        Me.UltraPanel1.ClientArea.Controls.Add(Me.ubtn2)
        Me.UltraPanel1.ForeColor = System.Drawing.Color.Silver
        Me.UltraPanel1.Location = New System.Drawing.Point(0, 0)
        Me.UltraPanel1.Name = "UltraPanel1"
        Me.UltraPanel1.Size = New System.Drawing.Size(275, 500)
        Me.UltraPanel1.TabIndex = 471
        '
        'cmdOK
        '
        Me.cmdOK.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance3.BackColor = System.Drawing.Color.White
        Appearance3.BackColor2 = System.Drawing.Color.White
        Appearance3.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance3.BorderColor = System.Drawing.Color.Silver
        Appearance3.ForeColor = System.Drawing.Color.DimGray
        Me.cmdOK.Appearance = Appearance3
        Me.cmdOK.Font = New System.Drawing.Font("Arial Narrow", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance4.BackColor = System.Drawing.Color.DarkOrange
        Appearance4.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance4.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance4.ForeColor = System.Drawing.Color.Black
        Me.cmdOK.HotTrackAppearance = Appearance4
        Me.cmdOK.ImageSize = New System.Drawing.Size(24, 24)
        Me.cmdOK.Location = New System.Drawing.Point(103, 393)
        Me.cmdOK.Name = "cmdOK"
        Appearance5.BackColor = System.Drawing.Color.OrangeRed
        Appearance5.BackColor2 = System.Drawing.Color.Tomato
        Appearance5.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdOK.PressedAppearance = Appearance5
        Me.cmdOK.ShowFocusRect = False
        Me.cmdOK.ShowOutline = False
        Me.cmdOK.Size = New System.Drawing.Size(130, 62)
        Me.cmdOK.TabIndex = 585
        Me.cmdOK.Text = "OK"
        Me.cmdOK.UseAppStyling = False
        Me.cmdOK.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOK.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdOK.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdBack
        '
        Me.cmdBack.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance6.BackColor = System.Drawing.Color.White
        Appearance6.BackColor2 = System.Drawing.Color.White
        Appearance6.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance6.BorderColor = System.Drawing.Color.Silver
        Appearance6.ForeColor = System.Drawing.Color.DimGray
        Me.cmdBack.Appearance = Appearance6
        Me.cmdBack.Font = New System.Drawing.Font("Arial Narrow", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance7.BackColor = System.Drawing.Color.DarkOrange
        Appearance7.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance7.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance7.ForeColor = System.Drawing.Color.Black
        Me.cmdBack.HotTrackAppearance = Appearance7
        Me.cmdBack.ImageSize = New System.Drawing.Size(24, 24)
        Me.cmdBack.Location = New System.Drawing.Point(35, 393)
        Me.cmdBack.Name = "cmdBack"
        Appearance8.BackColor = System.Drawing.Color.OrangeRed
        Appearance8.BackColor2 = System.Drawing.Color.Tomato
        Appearance8.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdBack.PressedAppearance = Appearance8
        Me.cmdBack.ShowFocusRect = False
        Me.cmdBack.ShowOutline = False
        Me.cmdBack.Size = New System.Drawing.Size(62, 62)
        Me.cmdBack.TabIndex = 584
        Me.cmdBack.Text = "Bk"
        Me.cmdBack.UseAppStyling = False
        Me.cmdBack.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdBack.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdBack.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtn8
        '
        Me.ubtn8.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance9.BackColor = System.Drawing.Color.White
        Appearance9.BackColor2 = System.Drawing.Color.White
        Appearance9.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance9.BorderColor = System.Drawing.Color.Silver
        Appearance9.ForeColor = System.Drawing.Color.DimGray
        Me.ubtn8.Appearance = Appearance9
        Me.ubtn8.Font = New System.Drawing.Font("Arial Narrow", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance10.BackColor = System.Drawing.Color.DarkOrange
        Appearance10.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance10.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance10.ForeColor = System.Drawing.Color.Black
        Me.ubtn8.HotTrackAppearance = Appearance10
        Me.ubtn8.ImageSize = New System.Drawing.Size(24, 24)
        Me.ubtn8.Location = New System.Drawing.Point(103, 121)
        Me.ubtn8.Name = "ubtn8"
        Appearance11.BackColor = System.Drawing.Color.OrangeRed
        Appearance11.BackColor2 = System.Drawing.Color.Tomato
        Appearance11.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtn8.PressedAppearance = Appearance11
        Me.ubtn8.ShowFocusRect = False
        Me.ubtn8.ShowOutline = False
        Me.ubtn8.Size = New System.Drawing.Size(62, 62)
        Me.ubtn8.TabIndex = 571
        Me.ubtn8.Text = "8"
        Me.ubtn8.UseAppStyling = False
        Me.ubtn8.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtn8.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtn8.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'cmdClear
        '
        Me.cmdClear.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance12.BackColor = System.Drawing.Color.White
        Appearance12.BackColor2 = System.Drawing.Color.White
        Appearance12.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance12.BorderColor = System.Drawing.Color.Silver
        Appearance12.ForeColor = System.Drawing.Color.DimGray
        Me.cmdClear.Appearance = Appearance12
        Me.cmdClear.Font = New System.Drawing.Font("Arial Narrow", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance13.BackColor = System.Drawing.Color.DarkOrange
        Appearance13.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance13.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance13.ForeColor = System.Drawing.Color.Black
        Me.cmdClear.HotTrackAppearance = Appearance13
        Me.cmdClear.ImageSize = New System.Drawing.Size(24, 24)
        Me.cmdClear.Location = New System.Drawing.Point(171, 325)
        Me.cmdClear.Name = "cmdClear"
        Appearance14.BackColor = System.Drawing.Color.OrangeRed
        Appearance14.BackColor2 = System.Drawing.Color.Tomato
        Appearance14.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.cmdClear.PressedAppearance = Appearance14
        Me.cmdClear.ShowFocusRect = False
        Me.cmdClear.ShowOutline = False
        Me.cmdClear.Size = New System.Drawing.Size(62, 62)
        Me.cmdClear.TabIndex = 582
        Me.cmdClear.Text = "C"
        Me.cmdClear.UseAppStyling = False
        Me.cmdClear.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdClear.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.cmdClear.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtn7
        '
        Me.ubtn7.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance15.BackColor = System.Drawing.Color.White
        Appearance15.BackColor2 = System.Drawing.Color.White
        Appearance15.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance15.BorderColor = System.Drawing.Color.Silver
        Appearance15.ForeColor = System.Drawing.Color.DimGray
        Me.ubtn7.Appearance = Appearance15
        Me.ubtn7.Font = New System.Drawing.Font("Arial Narrow", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance16.BackColor = System.Drawing.Color.DarkOrange
        Appearance16.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance16.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance16.ForeColor = System.Drawing.Color.Black
        Me.ubtn7.HotTrackAppearance = Appearance16
        Me.ubtn7.ImageSize = New System.Drawing.Size(24, 24)
        Me.ubtn7.Location = New System.Drawing.Point(35, 121)
        Me.ubtn7.Name = "ubtn7"
        Appearance17.BackColor = System.Drawing.Color.OrangeRed
        Appearance17.BackColor2 = System.Drawing.Color.Tomato
        Appearance17.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtn7.PressedAppearance = Appearance17
        Me.ubtn7.ShowFocusRect = False
        Me.ubtn7.ShowOutline = False
        Me.ubtn7.Size = New System.Drawing.Size(62, 62)
        Me.ubtn7.TabIndex = 572
        Me.ubtn7.Text = "7"
        Me.ubtn7.UseAppStyling = False
        Me.ubtn7.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtn7.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtn7.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtn0
        '
        Me.ubtn0.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance18.BackColor = System.Drawing.Color.White
        Appearance18.BackColor2 = System.Drawing.Color.White
        Appearance18.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance18.BorderColor = System.Drawing.Color.Silver
        Appearance18.ForeColor = System.Drawing.Color.DimGray
        Me.ubtn0.Appearance = Appearance18
        Me.ubtn0.Font = New System.Drawing.Font("Arial Narrow", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance19.BackColor = System.Drawing.Color.DarkOrange
        Appearance19.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance19.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance19.ForeColor = System.Drawing.Color.Black
        Me.ubtn0.HotTrackAppearance = Appearance19
        Me.ubtn0.ImageSize = New System.Drawing.Size(24, 24)
        Me.ubtn0.Location = New System.Drawing.Point(35, 325)
        Me.ubtn0.Name = "ubtn0"
        Appearance20.BackColor = System.Drawing.Color.OrangeRed
        Appearance20.BackColor2 = System.Drawing.Color.Tomato
        Appearance20.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtn0.PressedAppearance = Appearance20
        Me.ubtn0.ShowFocusRect = False
        Me.ubtn0.ShowOutline = False
        Me.ubtn0.Size = New System.Drawing.Size(62, 62)
        Me.ubtn0.TabIndex = 581
        Me.ubtn0.Text = "0"
        Me.ubtn0.UseAppStyling = False
        Me.ubtn0.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtn0.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtn0.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtn9
        '
        Me.ubtn9.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance21.BackColor = System.Drawing.Color.White
        Appearance21.BackColor2 = System.Drawing.Color.White
        Appearance21.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance21.BorderColor = System.Drawing.Color.Silver
        Appearance21.ForeColor = System.Drawing.Color.DimGray
        Me.ubtn9.Appearance = Appearance21
        Me.ubtn9.Font = New System.Drawing.Font("Arial Narrow", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance22.BackColor = System.Drawing.Color.DarkOrange
        Appearance22.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance22.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance22.ForeColor = System.Drawing.Color.Black
        Me.ubtn9.HotTrackAppearance = Appearance22
        Me.ubtn9.ImageSize = New System.Drawing.Size(24, 24)
        Me.ubtn9.Location = New System.Drawing.Point(171, 121)
        Me.ubtn9.Name = "ubtn9"
        Appearance23.BackColor = System.Drawing.Color.OrangeRed
        Appearance23.BackColor2 = System.Drawing.Color.Tomato
        Appearance23.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtn9.PressedAppearance = Appearance23
        Me.ubtn9.ShowFocusRect = False
        Me.ubtn9.ShowOutline = False
        Me.ubtn9.Size = New System.Drawing.Size(62, 62)
        Me.ubtn9.TabIndex = 573
        Me.ubtn9.Text = "9"
        Me.ubtn9.UseAppStyling = False
        Me.ubtn9.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtn9.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtn9.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtnDot
        '
        Me.ubtnDot.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance24.BackColor = System.Drawing.Color.White
        Appearance24.BackColor2 = System.Drawing.Color.White
        Appearance24.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance24.BorderColor = System.Drawing.Color.Silver
        Appearance24.ForeColor = System.Drawing.Color.DimGray
        Me.ubtnDot.Appearance = Appearance24
        Me.ubtnDot.Font = New System.Drawing.Font("Arial Narrow", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance25.BackColor = System.Drawing.Color.DarkOrange
        Appearance25.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance25.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance25.ForeColor = System.Drawing.Color.Black
        Me.ubtnDot.HotTrackAppearance = Appearance25
        Me.ubtnDot.ImageSize = New System.Drawing.Size(24, 24)
        Me.ubtnDot.Location = New System.Drawing.Point(103, 325)
        Me.ubtnDot.Name = "ubtnDot"
        Appearance26.BackColor = System.Drawing.Color.OrangeRed
        Appearance26.BackColor2 = System.Drawing.Color.Tomato
        Appearance26.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtnDot.PressedAppearance = Appearance26
        Me.ubtnDot.ShowFocusRect = False
        Me.ubtnDot.ShowOutline = False
        Me.ubtnDot.Size = New System.Drawing.Size(62, 62)
        Me.ubtnDot.TabIndex = 580
        Me.ubtnDot.Text = "."
        Me.ubtnDot.UseAppStyling = False
        Me.ubtnDot.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnDot.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtnDot.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtn5
        '
        Me.ubtn5.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance27.BackColor = System.Drawing.Color.White
        Appearance27.BackColor2 = System.Drawing.Color.White
        Appearance27.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance27.BorderColor = System.Drawing.Color.Silver
        Appearance27.ForeColor = System.Drawing.Color.DimGray
        Me.ubtn5.Appearance = Appearance27
        Me.ubtn5.Font = New System.Drawing.Font("Arial Narrow", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance28.BackColor = System.Drawing.Color.DarkOrange
        Appearance28.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance28.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance28.ForeColor = System.Drawing.Color.Black
        Me.ubtn5.HotTrackAppearance = Appearance28
        Me.ubtn5.ImageSize = New System.Drawing.Size(24, 24)
        Me.ubtn5.Location = New System.Drawing.Point(103, 189)
        Me.ubtn5.Name = "ubtn5"
        Appearance29.BackColor = System.Drawing.Color.OrangeRed
        Appearance29.BackColor2 = System.Drawing.Color.Tomato
        Appearance29.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtn5.PressedAppearance = Appearance29
        Me.ubtn5.ShowFocusRect = False
        Me.ubtn5.ShowOutline = False
        Me.ubtn5.Size = New System.Drawing.Size(62, 62)
        Me.ubtn5.TabIndex = 574
        Me.ubtn5.Text = "5"
        Me.ubtn5.UseAppStyling = False
        Me.ubtn5.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtn5.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtn5.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtn3
        '
        Me.ubtn3.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance30.BackColor = System.Drawing.Color.White
        Appearance30.BackColor2 = System.Drawing.Color.White
        Appearance30.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance30.BorderColor = System.Drawing.Color.Silver
        Appearance30.ForeColor = System.Drawing.Color.DimGray
        Me.ubtn3.Appearance = Appearance30
        Me.ubtn3.Font = New System.Drawing.Font("Arial Narrow", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance31.BackColor = System.Drawing.Color.DarkOrange
        Appearance31.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance31.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance31.ForeColor = System.Drawing.Color.Black
        Me.ubtn3.HotTrackAppearance = Appearance31
        Me.ubtn3.ImageSize = New System.Drawing.Size(24, 24)
        Me.ubtn3.Location = New System.Drawing.Point(171, 257)
        Me.ubtn3.Name = "ubtn3"
        Appearance32.BackColor = System.Drawing.Color.OrangeRed
        Appearance32.BackColor2 = System.Drawing.Color.Tomato
        Appearance32.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtn3.PressedAppearance = Appearance32
        Me.ubtn3.ShowFocusRect = False
        Me.ubtn3.ShowOutline = False
        Me.ubtn3.Size = New System.Drawing.Size(62, 62)
        Me.ubtn3.TabIndex = 579
        Me.ubtn3.Text = "3"
        Me.ubtn3.UseAppStyling = False
        Me.ubtn3.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtn3.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtn3.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtn4
        '
        Me.ubtn4.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance33.BackColor = System.Drawing.Color.White
        Appearance33.BackColor2 = System.Drawing.Color.White
        Appearance33.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance33.BorderColor = System.Drawing.Color.Silver
        Appearance33.ForeColor = System.Drawing.Color.DimGray
        Me.ubtn4.Appearance = Appearance33
        Me.ubtn4.Font = New System.Drawing.Font("Arial Narrow", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance34.BackColor = System.Drawing.Color.DarkOrange
        Appearance34.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance34.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance34.ForeColor = System.Drawing.Color.Black
        Me.ubtn4.HotTrackAppearance = Appearance34
        Me.ubtn4.ImageSize = New System.Drawing.Size(24, 24)
        Me.ubtn4.Location = New System.Drawing.Point(35, 189)
        Me.ubtn4.Name = "ubtn4"
        Appearance35.BackColor = System.Drawing.Color.OrangeRed
        Appearance35.BackColor2 = System.Drawing.Color.Tomato
        Appearance35.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtn4.PressedAppearance = Appearance35
        Me.ubtn4.ShowFocusRect = False
        Me.ubtn4.ShowOutline = False
        Me.ubtn4.Size = New System.Drawing.Size(62, 62)
        Me.ubtn4.TabIndex = 575
        Me.ubtn4.Text = "4"
        Me.ubtn4.UseAppStyling = False
        Me.ubtn4.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtn4.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtn4.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtn1
        '
        Me.ubtn1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance36.BackColor = System.Drawing.Color.White
        Appearance36.BackColor2 = System.Drawing.Color.White
        Appearance36.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance36.BorderColor = System.Drawing.Color.Silver
        Appearance36.ForeColor = System.Drawing.Color.DimGray
        Me.ubtn1.Appearance = Appearance36
        Me.ubtn1.Font = New System.Drawing.Font("Arial Narrow", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance37.BackColor = System.Drawing.Color.DarkOrange
        Appearance37.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance37.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance37.ForeColor = System.Drawing.Color.Black
        Me.ubtn1.HotTrackAppearance = Appearance37
        Me.ubtn1.ImageSize = New System.Drawing.Size(24, 24)
        Me.ubtn1.Location = New System.Drawing.Point(35, 257)
        Me.ubtn1.Name = "ubtn1"
        Appearance38.BackColor = System.Drawing.Color.OrangeRed
        Appearance38.BackColor2 = System.Drawing.Color.Tomato
        Appearance38.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtn1.PressedAppearance = Appearance38
        Me.ubtn1.ShowFocusRect = False
        Me.ubtn1.ShowOutline = False
        Me.ubtn1.Size = New System.Drawing.Size(62, 62)
        Me.ubtn1.TabIndex = 578
        Me.ubtn1.Text = "1"
        Me.ubtn1.UseAppStyling = False
        Me.ubtn1.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtn1.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtn1.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtn6
        '
        Me.ubtn6.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance39.BackColor = System.Drawing.Color.White
        Appearance39.BackColor2 = System.Drawing.Color.White
        Appearance39.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance39.BorderColor = System.Drawing.Color.Silver
        Appearance39.ForeColor = System.Drawing.Color.DimGray
        Me.ubtn6.Appearance = Appearance39
        Me.ubtn6.Font = New System.Drawing.Font("Arial Narrow", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance40.BackColor = System.Drawing.Color.DarkOrange
        Appearance40.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance40.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance40.ForeColor = System.Drawing.Color.Black
        Me.ubtn6.HotTrackAppearance = Appearance40
        Me.ubtn6.ImageSize = New System.Drawing.Size(24, 24)
        Me.ubtn6.Location = New System.Drawing.Point(171, 189)
        Me.ubtn6.Name = "ubtn6"
        Appearance41.BackColor = System.Drawing.Color.OrangeRed
        Appearance41.BackColor2 = System.Drawing.Color.Tomato
        Appearance41.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtn6.PressedAppearance = Appearance41
        Me.ubtn6.ShowFocusRect = False
        Me.ubtn6.ShowOutline = False
        Me.ubtn6.Size = New System.Drawing.Size(62, 62)
        Me.ubtn6.TabIndex = 576
        Me.ubtn6.Text = "6"
        Me.ubtn6.UseAppStyling = False
        Me.ubtn6.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtn6.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtn6.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'ubtn2
        '
        Me.ubtn2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Appearance42.BackColor = System.Drawing.Color.White
        Appearance42.BackColor2 = System.Drawing.Color.White
        Appearance42.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical
        Appearance42.BorderColor = System.Drawing.Color.Silver
        Appearance42.ForeColor = System.Drawing.Color.DimGray
        Me.ubtn2.Appearance = Appearance42
        Me.ubtn2.Font = New System.Drawing.Font("Arial Narrow", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Appearance43.BackColor = System.Drawing.Color.DarkOrange
        Appearance43.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(150, Byte), Integer))
        Appearance43.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Appearance43.ForeColor = System.Drawing.Color.Black
        Me.ubtn2.HotTrackAppearance = Appearance43
        Me.ubtn2.ImageSize = New System.Drawing.Size(24, 24)
        Me.ubtn2.Location = New System.Drawing.Point(103, 257)
        Me.ubtn2.Name = "ubtn2"
        Appearance44.BackColor = System.Drawing.Color.OrangeRed
        Appearance44.BackColor2 = System.Drawing.Color.Tomato
        Appearance44.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50
        Me.ubtn2.PressedAppearance = Appearance44
        Me.ubtn2.ShowFocusRect = false
        Me.ubtn2.ShowOutline = false
        Me.ubtn2.Size = New System.Drawing.Size(62, 62)
        Me.ubtn2.TabIndex = 577
        Me.ubtn2.Text = "2"
        Me.ubtn2.UseAppStyling = false
        Me.ubtn2.UseFlatMode = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtn2.UseHotTracking = Infragistics.Win.DefaultableBoolean.[True]
        Me.ubtn2.UseOsThemes = Infragistics.Win.DefaultableBoolean.[False]
        '
        'frmQty
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6!, 13!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(245,Byte),Integer), CType(CType(247,Byte),Integer), CType(CType(244,Byte),Integer))
        Me.ClientSize = New System.Drawing.Size(275, 500)
        Me.ControlBox = false
        Me.Controls.Add(Me.UltraPanel1)
        Me.ForeColor = System.Drawing.Color.Gray
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.MaximizeBox = false
        Me.MinimizeBox = false
        Me.Name = "frmQty"
        Me.ShowInTaskbar = false
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Number Input"
        CType(Me.txtTotal,System.ComponentModel.ISupportInitialize).EndInit
        Me.UltraPanel1.ClientArea.ResumeLayout(false)
        Me.UltraPanel1.ResumeLayout(false)
        Me.ResumeLayout(false)

End Sub
    Friend WithEvents txtTotal As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents lblCaption As System.Windows.Forms.Label
    Friend WithEvents UltraPanel1 As Infragistics.Win.Misc.UltraPanel
    Friend WithEvents cmdOK As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdBack As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtn8 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents cmdClear As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtn7 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtn0 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtn9 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtnDot As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtn5 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtn3 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtn4 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtn1 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtn6 As Infragistics.Win.Misc.UltraButton
    Friend WithEvents ubtn2 As Infragistics.Win.Misc.UltraButton
End Class
