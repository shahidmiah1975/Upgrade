﻿Public Class frmQty

    Private blnClearFirst As Boolean

    Public Property ReturnValue() As String

    Friend Sub Display(strHeader As String, strDefault As String)

        lblCaption.Text = strHeader
        txtTotal.Text = strDefault

        If strDefault = "0.00" Then txtTotal.Tag = strDefault Else txtTotal.Tag = "0"

        blnClearFirst = True

        ShowDialog()

    End Sub

    Private Sub ClearDisplay(sender As Object, e As EventArgs) Handles cmdClear.Click
        txtTotal.Text = txtTotal.Tag.ToString
    End Sub

    Private Sub NumHandler(sender As Object, e As EventArgs) Handles ubtn0.Click, ubtn1.Click, ubtn2.Click, ubtn3.Click, ubtn4.Click, ubtn5.Click, ubtn6.Click, ubtn7.Click, ubtn8.Click, ubtn9.Click

        If blnClearFirst Then
            txtTotal.Text = txtTotal.Tag
            blnClearFirst = False
        End If

        If txtTotal.Tag = "0.00" Then
            AppendNum(txtTotal, sender.text, 8)

        Else
            If txtTotal.TextLength = 10 Then Exit Sub

            Dim blnIsOK As Boolean = False
            Dim intNum As Short = sender.text

            Select Case intNum
                Case 0
                    blnIsOK = txtTotal.Text <> "0"
                Case 1 To 9
                    If txtTotal.Text = "0" Then
                        txtTotal.Clear()
                    End If
                    blnIsOK = True
            End Select

            If blnIsOK Then txtTotal.Text += intNum.ToString

        End If

    End Sub

    Private Sub DotHandler(sender As Object, e As EventArgs) Handles ubtnDot.Click

        If txtTotal.TextLength = 10 Then Exit Sub

        If InStr(txtTotal.Text, ".") = 0 Then
            txtTotal.Text += "."
        End If

    End Sub

    Private Sub cmdOK_Click(sender As Object, e As EventArgs) Handles cmdOK.Click

        ReturnValue = "x"

        If txtTotal.Text <> "" Then
            If IsANumber(txtTotal.Text) Then
                ReturnValue = txtTotal.Text
            End If
        End If

        Close()

    End Sub

    Private Sub cmdBack_Click(sender As Object, e As EventArgs) Handles cmdBack.Click

        ReturnValue = "x"
        Close()

    End Sub

    'Declare the variables
    Dim drag As Boolean
    Dim mousex As Integer
    Dim mousey As Integer

    Private Sub Form1_MouseDown(sender As Object, e As MouseEventArgs) Handles Me.MouseDown
        drag = True 'Sets the variable drag to true.
        mousex = Cursor.Position.X - Left 'Sets variable mousex
        mousey = Cursor.Position.Y - Top 'Sets variable mousey
    End Sub

    Private Sub Form1_MouseMove(sender As Object, e As MouseEventArgs) Handles Me.MouseMove
        'If drag is set to true then move the form accordingly.
        If drag Then
            Top = Cursor.Position.Y - mousey
            Left = Cursor.Position.X - mousex
        End If
    End Sub

    Private Sub Form1_MouseUp(sender As Object, e As MouseEventArgs) Handles Me.MouseUp
        drag = False 'Sets drag to false, so the form does not move according to the code in MouseMove
    End Sub

End Class