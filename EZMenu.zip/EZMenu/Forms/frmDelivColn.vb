﻿Imports Infragistics.Win.Misc
Imports Infragistics.Win.UltraWinEditors
Imports System.Text.RegularExpressions
Imports VB = Microsoft.VisualBasic
Imports EZControls
Imports EZMenu.Core.Enums
Imports EZMenu.Core.Models
Imports EZService

Public Class frmDelivColn

    Public objPrevTextbox As UltraTextEditor
    Public Property CurrentCustomer As CustomerModel
    Public Property CustomerEditModeOn As Boolean

    Private _orderType As OrderTypeEnum
    Private _customerService As CustomerService
    Private _searchCustomer As Boolean
    Private _strIncomingNumber As String, _strIncomingName As String, _strIncomingEmail As String

    Public Sub New(eOrderType As OrderTypeEnum, strIncomingNumber As String, strIncomingName As String, strIncomingEmail As String, searchCustomer As Boolean)

        MyBase.New

        ' This call is required by the designer.
        InitializeComponent()

        _orderType = eOrderType
        _searchCustomer = searchCustomer
        _strIncomingNumber = strIncomingNumber
        _strIncomingName = strIncomingName
        _strIncomingEmail = strIncomingEmail

        CurrentCustomer = New CustomerModel
        CustomerEditModeOn = False
        _customerService = New CustomerService()

    End Sub

    Private Sub frmDelivColn_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Try
            Size = Owner.Size
            Location = Owner.Location

            ezkbdDelivColn.BorderStyle = BorderStyle.None

            SetScreen(_orderType)

            If _orderType = OrderTypeEnum.Collection Then
                txtName.Focus()
            ElseIf _orderType = OrderTypeEnum.Delivery Then
                txtPostcode.Focus()
            End If

            HideHourGlass()

            If Not String.IsNullOrEmpty(_strIncomingNumber) Then
                txtTelephone.Text = _strIncomingNumber
                If _searchCustomer Then CustomerSearch()
            End If

        Catch ex As Exception
            WriteToLog(ex)
        End Try

    End Sub

    Public Sub SetScreen(eOrderType As Object)

        Try
            _orderType = eOrderType

            If objPayment Is Nothing Then
                objPayment = New frmPayment
            End If

            Select Case eOrderType

                Case OrderTypeEnum.Delivery

                    With objDelivColn
                        .SuspendLayout()
                        .lblTelephoneLbl.Top = 179
                        .txtTelephone.Top = 174
                        .txtTelephone.Size = New Size(224, 28)
                        .lblAddressLbl.Visible = True
                        .txtAddress1.Visible = True
                        .txtAddress2.Visible = True
                        .txtAddress3.Visible = True
                        .lblPostcodeLbl.Visible = True
                        .txtPostcode.Visible = True
                        .cmdPhoneNotFound.Visible = False
                        .cmdShowKeyboard.Enabled = True
                        .cmdDirections.Enabled = True
                        .cmdPrevOrder.Enabled = GetAppSettingCS("SaveCustomerHistory", True)
                        .cmdNotes.Enabled = True
                        '.cmdMap.Enabled = True
                        .ubtnAddressDown.Visible = False
                        .lblCustomerData.Visible = False
                        .ezkbdDelivColn.ctrlActive = Nothing
                        If .objPrevTextbox IsNot Nothing Then
                            .objPrevTextbox.AlwaysInEditMode = False
                            .objPrevTextbox.Appearance.BackColor = clrTextBoxes
                            .objPrevTextbox.Appearance.BackColor2 = clrTextBoxes
                            .objPrevTextbox.Appearance.BackGradientStyle = Infragistics.Win.GradientStyle.None
                        End If
                        For Each myObj As Object In .upnlCustomerInfo.ClientArea.Controls
                            If myObj.Name = "lblDistance" AndAlso myObj.Text <> Nothing Then
                                myObj.Visible = True
                            End If
                        Next
                        .ResumeLayout()
                    End With

                    With objPayment
                        .cmdWaiting.Enabled = False
                    End With


                Case OrderTypeEnum.Collection

                    With objDelivColn
                        .SuspendLayout()
                        .lblTelephoneLbl.Top = .lblAddressLbl.Top
                        .txtTelephone.Top = .txtAddress1.Top
                        .txtTelephone.Size = .txtName.Size
                        .lblAddressLbl.Visible = False
                        .txtAddress1.Visible = False
                        .txtAddress2.Visible = False
                        .txtAddress3.Visible = False
                        .lblPostcodeLbl.Visible = False
                        .txtPostcode.Visible = False
                        .cmdPhoneNotFound.Visible = False
                        .cmdShowKeyboard.Enabled = False
                        .cmdDirections.Enabled = False
                        .cmdPrevOrder.Enabled = False
                        .cmdNotes.Enabled = False
                        .cmdMap.Enabled = False
                        .ubtnAddressDown.Visible = False
                        .lblCustomerData.Visible = False
                        .ezkbdDelivColn.ctrlActive = Nothing
                        If .objPrevTextbox IsNot Nothing Then
                            .objPrevTextbox.AlwaysInEditMode = False
                            .objPrevTextbox.Appearance.BackColor = Color.Transparent
                            .objPrevTextbox.Appearance.BackColor2 = Color.Transparent
                            .objPrevTextbox.Appearance.BackGradientStyle = Infragistics.Win.GradientStyle.None
                        End If
                        For Each myObj As Object In .upnlCustomerInfo.ClientArea.Controls
                            If myObj.Name = "lblDistance" Then
                                myObj.Visible = False
                            End If
                        Next
                        .ResumeLayout()
                    End With

                    With objPayment
                        .cmdWaiting.Enabled = True
                    End With

                Case Else

            End Select

        Catch ex As Exception
            WriteToLog(ex)
        End Try

    End Sub

    Private Sub TextBoxEntered(sender As Object, e As EventArgs) Handles txtName.Enter, txtAddress1.Enter, txtAddress2.Enter, txtAddress3.Enter,
                                                                                txtTelephone.Enter, txtPostcode.Enter, txtEmail.Enter, txtMobile.Enter

        Dim ctrlSender As UltraTextEditor = CType(sender, UltraTextEditor)

        HiLitBox(ctrlSender)

        If ctrlSender Is txtPostcode Or ctrlSender Is txtTelephone Then cmdPhoneNotFound.Visible = False

        If objPrevTextbox IsNot Nothing AndAlso objPrevTextbox.Name <> ctrlSender.Name Then
            HiLitOffBox(objPrevTextbox)
        End If

        ctrlSender.AlwaysInEditMode = True
        objPrevTextbox = ctrlSender
        ezkbdDelivColn.ctrlActive = ctrlSender

    End Sub

    Private Sub cmdPickup_Click(sender As Object, e As EventArgs) Handles cmdPickup.Click

        HighlightOff()
        SetScreen(OrderTypeEnum.Collection)

    End Sub

    Private Sub cmdDelivery_Click(sender As Object, e As EventArgs) Handles cmdDelivery.Click

        HighlightOff()
        SetScreen(OrderTypeEnum.Delivery)

    End Sub

    Private Sub CustomerHandler(sender As Object, e As EventArgs) Handles cmdCustSearch.Click, cmdCustSave.Click

        HighlightOff()

        If sender Is cmdCustSave Then
            CustomerSave(True)
        ElseIf _orderType = OrderTypeEnum.Delivery AndAlso sender Is cmdCustSearch Then
            CustomerSearch()
        End If

    End Sub

    Public Sub CustomerSearch()
        'search database for customer that matches entered phone number

        Try
            PhoneQuery = FormatPhone(txtTelephone.Text)
            txtTelephone.Text = PhoneQuery
            txtTelephone.Tag = txtTelephone.Text

            'telephone number should be filled in
            If PhoneQuery = String.Empty Then
                strMsgBox = "Enter a telephone number for the search"
                Alert(strMsgBox)
                txtTelephone.Focus()
                Exit Sub
                'check for correct number of mobile digits
            ElseIf txtTelephone.Text.Length > 2 AndAlso txtTelephone.Text.Substring(0, 2) = "07" AndAlso txtTelephone.Text.Length <> 11 Then
                strMsgBox = "Mobile number does not match length that is required. " &
                  "Mobile numbers should start with 07 and be 11 digits long. " &
                  "Are you sure this is correct?"
                intMsgBoxResult = EZMsgBox.Show(strMsgBox, MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                If intMsgBoxResult = MsgBoxResult.No Then Exit Sub
            End If

            ShowHourGlass()

            'clear old details
            ClearDeliveryForm()
            Application.DoEvents()

            CurrentCustomer = _customerService.GetCustomerByPhone(PhoneQuery)
            If CurrentCustomer IsNot Nothing Then
                txtName.Text = CurrentCustomer.Name
                txtAddress1.Text = CurrentCustomer.Address1
                txtAddress2.Text = CurrentCustomer.Address2
                txtAddress3.Text = CurrentCustomer.Address3
                txtPostcode.Text = CurrentCustomer.Postcode
                txtTelephone.Text = CurrentCustomer.Phone
                txtMobile.Text = CurrentCustomer.Mobile
                txtEmail.Text = CurrentCustomer.Email

                If GetAppSettingCS("ShowLastOrdered", True) AndAlso IsDate(CurrentCustomer.LastOrder) Then
                    tempStr = FormatEZDate(CurrentCustomer.LastOrder)
                    'tempStr &= "  (" & DateDiff(DateInterval.Day, CDate(tempStr), Now) & " days)"
                    Dim datex As New DateTime(New TimeSpan(DateDiff(DateInterval.Day, CDate(tempStr), Now), 0, 0, 0).Ticks)
                    tempStr = String.Format("{0}y {1}m {2}d", datex.Year - 1, datex.Month - 1, datex.Day - 1)
                    If tempStr.Contains("0y 0m 0d") Then tempStr = "Today"
                    If tempStr.Contains("0y 0m 1d") Then tempStr = "Yesterday"
                    lblCustomerData.Text &= "Last ordered: " & tempStr & vbCrLf
                End If

                If GetAppSettingCS("ShowFirstOrdered", True) AndAlso IsDate(CurrentCustomer.FirstOrdered) Then
                    lblCustomerData.Text &= "Customer since: " & FormatEZDate(CurrentCustomer.FirstOrdered) & vbCrLf
                End If

                If GetAppSettingCS("ShowCustomersOrders", True) AndAlso IsANumber(CurrentCustomer.NumberOfOrders) Then
                    lblCustomerData.Text &= "Total orders to date: " & CurrentCustomer.NumberOfOrders & vbCrLf
                End If

                lblCustomerData.Visible = lblCustomerData.Text <> String.Empty

                lblCustomerNote.Text = _customerService.GetCustomerNote(CurrentCustomer.CustomerId)
                If lblCustomerNote.Text <> String.Empty Then
                    tempStr = "CUSTOMER NOTE:" & vbCrLf
                    tempStr &= lblCustomerNote.Text
                    lblCustomerNote.Text = tempStr
                    lblCustomerNote.Visible = True
                End If

                Refresh()
                Application.DoEvents()

                Dim strDistance As String = GetDistance(txtPostcode.Text, GetAppSettingCS("MyPostcode", ""), DistanceUnitEnum.Miles, YesNoEnum.Yes)
                If strDistance <> Nothing Then
                    Dim lblDistance As New Label
                    With lblDistance
                        .Name = "lblDistance"
                        .BackColor = lblPostcodeLbl.BackColor
                        .ForeColor = lblPostcodeLbl.ForeColor
                        .Font = lblPostcodeLbl.Font
                        .Top = lblPostcodeLbl.Top
                        .Left = txtPostcode.Left + txtPostcode.Width + 20
                        .Text = "Distance: " & strDistance
                        .AutoSize = True
                        .Parent = lblPostcodeLbl.Parent
                        .Visible = True
                    End With
                End If

                cmdCustSave.Focus()
                If objPrevTextbox IsNot Nothing Then HiLitOffBox(objPrevTextbox)

            Else
                Try
                    txtPostcode.Focus()
                Catch ex As Exception
                End Try
                cmdPhoneNotFound.Visible = True
            End If

        Catch ex As Exception
            WriteToLog(ex)
        End Try

        HideHourGlass()

    End Sub

    Private Sub CustomerSave(blnShowPrompt As Boolean)

        Try

            Dim cCustomer As CustomerModel

            If txtAddress1.Visible = True Then  'delivery
                'make sure fields are filled in
                If txtTelephone.Text = String.Empty Or txtAddress1.Text = String.Empty Then
                    strMsgBox = "You must fill in both address and telephone number."
                    Alert(strMsgBox)
                    If txtTelephone.Text = String.Empty Then txtTelephone.Focus() Else txtAddress1.Focus()
                    Exit Sub
                End If

                'set default name if blank
                If txtName.Text.Trim = String.Empty Then txtName.Text = "The Occupier"

                cCustomer = New CustomerModel With {.Name = txtName.Text.Trim.Punctuate,
                                                    .Address1 = txtAddress1.Text.Trim.Punctuate,
                                                    .Address2 = txtAddress2.Text.Trim.Punctuate,
                                                    .Address3 = txtAddress3.Text.Trim.Punctuate,
                                                    .Postcode = txtPostcode.Text.Trim,
                                                    .Phone = txtTelephone.Text.Trim,
                                                    .Mobile = txtMobile.Text.Trim,
                                                    .Email = txtEmail.Text.Trim}

                If CurrentCustomer IsNot Nothing Then cCustomer.CustomerId = CurrentCustomer.CustomerId

                'update or insert customer details
                Dim customerAdded As Boolean
                _customerService.UpsertCustomer(cCustomer, customerAdded)

                If CustomerEditModeOn = True Then blnShowPrompt = False
                If blnShowPrompt = True Then
                    If customerAdded = True Then
                        msg = "Customer details saved."
                    Else
                        msg = "Customer details have been updated."
                    End If
                    Alert(msg, MessageBoxIcon.Information)
                End If

                ubtnAddressDown.Visible = False

                If CustomerEditModeOn = True Then
                    frmCustomers.UpdateDBRecords()
                    cCustomer = Nothing
                    Close()
                End If

            Else    'collection

                'save the name and contact number of the customer
                If (txtTelephone.Text <> String.Empty And txtName.Text <> String.Empty) Then
                    txtTelephone.Text = FormatPhone(txtTelephone.Text)
                    PhoneQuery = txtTelephone.Text
                    cCustomer = New CustomerModel With {.Name = txtName.Text.Trim.Punctuate,
                                                        .Phone = txtTelephone.Text.Trim,
                                                        .Email = txtEmail.Text.Trim}
                    _customerService.AddCollector(cCustomer)
                    If blnShowPrompt = True Then Alert("Details have been saved")
                End If

            End If

            cCustomer = Nothing

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub cmdPhoneNotFound_Click(sender As Object, e As EventArgs) Handles cmdPhoneNotFound.Click

        cmdPhoneNotFound.Hide()

        Try
            txtName.Focus()
        Catch ex As Exception
        End Try

    End Sub

    Private Sub cmdBackScreen_Click(sender As Object, e As EventArgs) Handles cmdBackScreen.Click

        strMsgBox = "Do you wish to cancel this order?"
        intMsgBoxResult = EZMsgBox.Show(strMsgBox, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation)
        If intMsgBoxResult = MsgBoxResult.Yes Then
            ShowHomeScreen()
        End If

    End Sub

    Private Sub cmdNextScreen_Click(sender As Object, e As EventArgs) Handles cmdNextScreen.Click

        Try

            If ValidateDelivColn() = True Then

                Dim blnGoAhead As Boolean = Not (_orderType = OrderTypeEnum.Delivery AndAlso Not DeliveryCutOffTimeProceed())



                If blnGoAhead = True Then
                    If objOrderEntry Is Nothing Then
                        objOrderEntry = New frmOrderEntry
                    Else
                        'if there are items in grid then update price for delivery or pickup
                        If objOrderEntry.ugdOrderGrid.Rows.Count > 0 Then
                            'AddUpGridTotals()
                        End If
                    End If

                    objOrderEntry.cmdPrevOrder.Enabled = (_orderType = OrderTypeEnum.Delivery)
                    objOrderEntry.CurrentOrderType = _orderType
                    objOrderEntry.Show(Me)
                End If

            End If

        Catch ex As Exception
            WriteToLog(ex)
        End Try

    End Sub

    Private Function ValidateDelivColn()

        Try

            If _orderType = OrderTypeEnum.Delivery Then

                If (txtAddress1.Text = String.Empty And txtAddress2.Text = String.Empty And txtAddress3.Text = String.Empty) Then
                    strMsgBox = "You must fill in the address for a delivery order"
                    Alert(strMsgBox)
                    Return False
                End If

                txtAddress1.Text = txtAddress1.Text.Trim.Replace("  ", " ")

                If txtAddress1.Text = String.Empty Then
                    strMsgBox = "The first line of address cannot be empty."
                    Alert(strMsgBox)
                    Return False
                End If

                If txtTelephone.Text = String.Empty Then
                    strMsgBox = "You must fill in the telephone number"
                    Alert(strMsgBox)
                    Return False
                End If

                'telephone number must be all numeric
                For iCnt As Integer = 0 To txtTelephone.TextLength - 1
                    If Not IsANumber(txtTelephone.Text.Substring(iCnt, 1)) Then
                        strMsgBox = "Telephone number must be all numeric"
                        Alert(strMsgBox)
                        Return False
                    End If
                Next

                If txtName.Text.Trim = "" Then txtName.Text = "The Occupier"

            ElseIf _orderType = OrderTypeEnum.Collection Then

                If txtName.Text = "The Occupier" Then txtName.Text = ""

                'telephone number must be all numeric
                If txtTelephone.TextLength > 0 Then
                    For iCnt As Integer = 0 To txtTelephone.TextLength - 1
                        If Not IsANumber(txtTelephone.Text.Substring(iCnt, 1)) Then
                            strMsgBox = "Telephone number must be all numeric"
                            Alert(strMsgBox)
                            Return False
                        End If
                    Next
                End If

            End If

            'mobile number must be all numeric
            If txtMobile.TextLength > 0 Then
                For iCnt As Integer = 0 To txtMobile.TextLength - 1
                    If Not IsANumber(txtMobile.Text.Substring(iCnt, 1)) Then
                        strMsgBox = "Mobile number must be all numeric"
                        Alert(strMsgBox)
                        Return False
                    End If
                Next
            End If

            Return True

        Catch ex As Exception
            WriteToLog(ex)
            Return False
        End Try

    End Function

    Private Sub cmdClearForm_Click(sender As Object, e As EventArgs) Handles cmdClearForm.Click

        strMsgBox = "Do you want to clear all details on the screen?"
        intMsgBoxResult = EZMsgBox.Show(strMsgBox, MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If intMsgBoxResult = MsgBoxResult.Yes Then
            ClearDeliveryForm()
            HighlightOff()
            ezkbdDelivColn.Visible = True
        End If

    End Sub

    Private Sub ClearDeliveryForm()

        Try
            For Each myObj In upnlCustomerInfo.ClientArea.Controls
                If TypeOf myObj Is UltraTextEditor Then
                    myObj.Text = String.Empty
                End If
                If myObj.Name = "lblDistance" Then
                    myObj.Dispose()
                End If
            Next

            cmdPhoneNotFound.Visible = False
            uplAddressesMain.Visible = False
            ezkbdDelivColn.ctrlActive = Nothing
            lblCustomerData.Text = String.Empty
            lblCustomerNote.Text = String.Empty
            ubtnAddressDown.Visible = False

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub txtTelephone_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtTelephone.KeyPress

        Select Case e.KeyChar
            Case ChrW(Keys.Enter)
                e.Handled = False
                If txtTelephone.Text <> String.Empty Then CustomerSearch()

            Case ChrW(Keys.D0) To ChrW(Keys.D9), ChrW(Keys.Back), ChrW(22)
                e.Handled = False

            Case Else
                e.Handled = True

        End Select

    End Sub

    Private Sub txtPostCode_KeyDown(sender As Object, e As KeyEventArgs) Handles txtPostcode.KeyDown

        If (sender.text <> String.Empty And e.KeyCode = Keys.Enter) Then
            AddressLookupUsingAFD(AFDSearchTypeEnum.Postcode, Nothing)
        End If

    End Sub

    Private Function PCFormatOK(strPostcode As String) As Boolean

        Dim strRegX As String = "[A-Z]{1,2}[0-9R][0-9A-Z]? [0-9][ABD-HJLNP-UW-Z]{2}"
        Dim blnMatch As Boolean = False

        strPostcode = strPostcode.Trim.ToUpper.Replace(" ", "")

        'put a space between inner and outer codes if there is none
        If strPostcode.Length > 3 Then
            strPostcode = VB.Left(strPostcode, strPostcode.Length - 3) & " " & VB.Right(strPostcode, 3)
            txtPostcode.Text = strPostcode
            txtPostcode.Refresh()

            If strPostcode.Length >= 6 And strPostcode.Length <= 8 Then
                blnMatch = Regex.IsMatch(strPostcode, strRegX)
            End If
        End If

        If blnMatch = False Then
            strMsgBox = "Postcode entered does not meet requirement:" & vbCrLf & vbCrLf &
                        "The total length must be 6, 7 or 8 characters, a gap (space) must be included." & vbCrLf &
                        "The inward code, the part to the right of the gap, must always be 3 characters." & vbCrLf &
                        "The first character of the inward code must be numeric." & vbCrLf &
                        "The second and third characters of the inward code must be an alphabet." & vbCrLf &
                        "The second and third characters of the inward code may contain letters not accepted." & vbCrLf &
                        "The outward code, the part to the left of the gap, can be 2, 3 or 4 characters." & vbCrLf &
                        "The first character of the outward code must be an alphabet."
            MsgBox(strMsgBox, vbOKOnly)
        End If

        Return blnMatch

    End Function

    Private Sub cmdPCSearch_Click(sender As Object, e As EventArgs) Handles cmdPCSearch.Click

        HighlightOff()

        If _orderType = OrderTypeEnum.Delivery Then

            Dim searchTerm As String = String.Empty

            If txtPostcode.Text <> String.Empty Then
                If PCFormatOK(txtPostcode.Text) = True Then
                    AddressLookupUsingAFD(AFDSearchTypeEnum.Postcode, Nothing)
                    Return
                Else
                    Alert("Post code not in the correct format", MessageBoxIcon.Exclamation)
                    Return
                End If

            ElseIf txtAddress1.Text <> String.Empty Then
                searchTerm = txtAddress1.Text

            ElseIf txtAddress2.Text <> String.Empty Then
                searchTerm = txtAddress2.Text

            ElseIf txtAddress3.Text <> String.Empty Then
                searchTerm = txtAddress3.Text
            End If

            If searchTerm <> String.Empty Then AddressLookupUsingAFD(AFDSearchTypeEnum.Other, searchTerm)

        End If

    End Sub

    Private Sub AddressLookupUsingAFD(searchType As AFDSearchTypeEnum, searchField As String)

        Try
            cmdPhoneNotFound.Visible = False
            Application.DoEvents()

            Dim address As IEnumerable(Of AFDAddressModel) = Nothing

            ShowHourGlass()

            Try
                If searchType = AFDSearchTypeEnum.Postcode Then
                    txtPostcode.Text = txtPostcode.Text.ToUpper
                    address = _customerService.GetCustomerByAFDPostcode(txtPostcode.Text)
                Else
                    searchField = searchField.Replace(" ", "%")
                    address = _customerService.GetCustomerByAFDOther(searchField)
                End If

                If address IsNot Nothing Then
                    ShowAddressesAFD(address)
                Else
                    cmdPhoneNotFound.Visible = True
                    SelectText(txtPostcode)
                End If

            Catch ex As Exception
                DisplayError(ex)
            End Try

            HideHourGlass()
            HiLitOffBox(txtPostcode)

        Catch ex As Exception
            WriteToLog(ex)
        End Try

    End Sub

    Private Sub ShowAddressesAFD(addressesAFD As IEnumerable(Of AFDAddressModel))

        ezkbdDelivColn.Visible = False

        uplAddress.ClientArea.Controls.Clear()
        uplAddress.Size = New Size(1, uplAddressesMain.Height - uplAddress.Top)

        Try
            For Each address As AFDAddressModel In addressesAFD

                Dim objAddressButton As New UltraButton
                Dim strAddressLine1 As String = String.Empty
                Dim strAddressLine2 As String = String.Empty
                Dim strAddressLine3 As String = String.Empty
                Dim strAddressLine4 As String = String.Empty
                Dim tStr As String = String.Empty

                If address.Organisation.ToString.Trim <> String.Empty Then
                    strAddressLine1 = address.Organisation.ToString.Trim
                    If address.Property.ToString.Trim <> String.Empty Then
                        If address.Street.ToString.Trim <> String.Empty Then
                            strAddressLine2 = address.Property.ToString.Trim & ", " & address.Street.ToString.Trim
                        Else
                            strAddressLine2 = address.Property.ToString.Trim
                        End If
                    Else
                        strAddressLine2 = address.Street.ToString.Trim
                    End If
                Else
                    If address.Property.ToString.Trim <> String.Empty Then
                        strAddressLine1 = address.Property.ToString.Trim
                        If address.Street.ToString.Trim <> String.Empty Then
                            strAddressLine2 = address.Street.ToString.Trim
                        End If
                    Else
                        strAddressLine1 = address.Street.ToString.Trim
                    End If
                End If

                If strAddressLine1 <> String.Empty Then strAddressLine1 &= vbCrLf
                If strAddressLine2 <> String.Empty Then strAddressLine2 &= vbCrLf

                tStr = address.Town.ToString.Trim
                If tStr <> String.Empty Then strAddressLine3 = tStr & " "

                tStr = address.Postcode.ToString.Trim
                If tStr <> String.Empty Then strAddressLine4 = tStr

                AddHandler objAddressButton.Click, AddressOf AddressButtonClick

                With objAddressButton
                    .Width = 150
                    .Height = 80
                    .Name = "Address"
                    .Text = strAddressLine1 & strAddressLine2 & strAddressLine3 & strAddressLine4
                    .Tag = address
                    .StyleSetName = "DCAddressButton"
                    .UseFlatMode = Infragistics.Win.DefaultableBoolean.True
                    .UseOsThemes = Infragistics.Win.DefaultableBoolean.False
                    .ShowFocusRect = False
                    .ShowOutline = False
                    .Appearance.FontData.Bold = Infragistics.Win.DefaultableBoolean.False
                End With

                uplAddress.ClientArea.Controls.Add(objAddressButton)
            Next

            uplAddress.Left = 0
            uplAddress.Visible = True
            uplAddressesMain.Visible = True
            cmdPCNext.Visible = True
            cmdPCPrev.Visible = True

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub AddressButtonClick(sender As Object, e As EventArgs)

        Try
            Dim strLine1 As String = ""
            Dim strLine2 As String = ""
            Dim strLine3 As String = ""
            Dim strLine4 As String = ""
            Dim tStr As String = ""

            Dim selectedAddress As AFDAddressModel = CType(sender.tag, AFDAddressModel)

            If selectedAddress.Organisation.ToString.Trim <> String.Empty Then
                strLine1 = selectedAddress.Organisation.ToString.Trim
                If selectedAddress.Property.ToString.Trim <> String.Empty Then
                    If selectedAddress.Street.ToString.Trim <> String.Empty Then
                        strLine2 = selectedAddress.Property.ToString.Trim & ", " & selectedAddress.Street.ToString.Trim
                    Else
                        strLine2 = selectedAddress.Property.ToString.Trim
                    End If
                Else
                    strLine2 = selectedAddress.Street.ToString.Trim
                End If
            Else
                If selectedAddress.Property.ToString.Trim <> String.Empty Then
                    strLine1 = selectedAddress.Property.ToString.Trim
                    If selectedAddress.Street.ToString.Trim <> String.Empty Then
                        strLine2 = selectedAddress.Street.ToString.Trim
                    End If
                Else
                    strLine1 = selectedAddress.Street.ToString.Trim
                End If
            End If

            tStr = selectedAddress.Town.ToString.Trim
            If tStr <> String.Empty Then strLine3 = tStr

            tStr = selectedAddress.Postcode.ToString.Trim
            If tStr <> String.Empty Then strLine4 = tStr

            txtAddress1.Text = strLine1.Trim
            txtAddress2.Text = strLine2.Trim
            txtAddress3.Text = strLine3.Trim
            txtPostcode.Text = strLine4.Trim

            uplAddressesMain.Visible = False
            ubtnAddressDown.Visible = (txtAddress2.Text = String.Empty)
            ezkbdDelivColn.Visible = True

            txtAddress1.Focus()
            txtAddress1.SelectionStart = 0
            txtAddress1.SelectionLength = 0

            Refresh()
            Application.DoEvents()

            Dim strDistance As String = GetDistance(txtPostcode.Text, GetAppSettingCS("MyPostcode", ""), DistanceUnitEnum.Miles, YesNoEnum.Yes)
            If strDistance <> Nothing Then
                Dim lblDistance As New UltraLabel
                With lblDistance
                    .Name = "lblDistance"
                    .Font = lblPostcodeLbl.Font
                    .Top = lblPostcodeLbl.Top
                    .Left = txtPostcode.Left + txtPostcode.Width + 20
                    .Text = "Distance: " & strDistance
                    .AutoSize = True
                    .Parent = lblPostcodeLbl.Parent
                    .Appearance = lblPostcodeLbl.Appearance
                    .StyleSetName = lblPostcodeLbl.StyleSetName
                    .Visible = True
                End With
            End If

        Catch ex As Exception
            WriteToLog(ex)
        End Try

    End Sub

    Private Sub cmdHome_Click(sender As Object, e As EventArgs) Handles cmdHome.Click

        If CustomerEditModeOn = True Then
            Close()
        Else
            strMsgBox = "Do you wish to cancel this order?"
            intMsgBoxResult = EZMsgBox.Show(strMsgBox, MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If intMsgBoxResult = MsgBoxResult.Yes Then
                ShowHomeScreen()
            End If
        End If

    End Sub

    Public Sub HighlightOff()

        For Each myObj In upnlCustomerInfo.ClientArea.Controls
            If TypeOf myObj Is UltraTextEditor Then HiLitOffBox(myObj)
        Next

    End Sub

    Private Sub cmdNotes_Click(sender As Object, e As EventArgs) Handles cmdNotes.Click

        If _orderType = OrderTypeEnum.Delivery Then
            If CurrentCustomer.CustomerId > 0 Then
                ShowCustomerNotes()
            Else
                strMsgBox = "Cannot save customer note. Possible reason: customer has not been saved to the database yet. " &
                            "Save the customer's details first then try again."
                Alert(strMsgBox)
            End If
        End If

    End Sub

    Private Sub ShowCustomerNotes()

        strKBInput = _customerService.GetCustomerNote(CurrentCustomer.CustomerId)
        Using objForm As New frmNotes
            objForm.ShowDialog(Me)
        End Using

        If strKBInput.ToUpper <> "CANCEL" Then
            _customerService.DeleteCustomerNote(CurrentCustomer.CustomerId)
            lblCustomerNote.Text = String.Empty
            If strKBInput <> "" Then
                Try
                    _customerService.AddCustomerNote(CurrentCustomer.CustomerId, strKBInput.Punctuate)
                    tempStr = "CUSTOMER NOTE:" & vbCrLf & vbCrLf & strKBInput
                    lblCustomerNote.Text = tempStr
                Catch ex As Exception
                    DisplayError(ex, "Saving note was unsuccessful. Try again by using only alphabets and/or numbers." & vbCrLf & ex.Message)
                End Try
            End If
            lblCustomerNote.Visible = (lblCustomerNote.Text.Trim <> String.Empty)
        End If

    End Sub

    Private Sub lblCustomerNote_Click(sender As Object, e As EventArgs) Handles lblCustomerNote.Click
        ShowCustomerNotes()
    End Sub

    Private Sub cmdShowKeyboard_Click(sender As Object, e As EventArgs) Handles cmdShowKeyboard.Click

        uplAddressesMain.Visible = False
        ezkbdDelivColn.Visible = True

    End Sub

    Private Sub ubtnAddressDown_Click(sender As Object, e As EventArgs) Handles ubtnAddressDown.Click

        If txtAddress2.Text = String.Empty Then
            txtAddress2.Text = txtAddress1.Text.Trim
            txtAddress1.Text = String.Empty
        End If

        ubtnAddressDown.Visible = False

        Try
            txtAddress1.Focus()
        Catch ex As Exception
        End Try

    End Sub

    Private Sub cmdDirections_Click(sender As Object, e As EventArgs) Handles cmdDirections.Click

        If _orderType = OrderTypeEnum.Delivery AndAlso CurrentCustomer.CustomerId > 0 Then

            strKBInput = _customerService.GetCustomerDirections(CurrentCustomer.CustomerId)
            Using objForm As New frmNotes
                objForm.ShowDialog(Me)
            End Using

            If strKBInput.ToUpper <> "CANCEL" Then
                _customerService.DeleteCustomerDirections(CurrentCustomer.CustomerId)
                If strKBInput <> "" Then
                    Try
                        _customerService.AddCustomerDirections(CurrentCustomer.CustomerId, strKBInput.Punctuate)
                    Catch ex As Exception
                        strMsgBox = "Saving directions was unsuccessful. Try again by using only alphabets and/or numbers"
                        Alert(strMsgBox)
                    End Try
                End If
            End If
        Else
            strMsgBox = "Cannot save directions. Possible reason: customer has not been saved to the database yet." &
            "Save the customer's details first then try again."
            Alert(strMsgBox)
        End If

    End Sub

    Private Sub PCNextPrev(sender As Object, e As EventArgs) Handles cmdPCNext.Click, cmdPCPrev.Click

        If uplAddress.Width < uplAddressesMain.Width Then Exit Sub

        If sender.text = "Next" Then
            Dim b = uplAddressesMain.Width - uplAddress.Width
            Dim a = uplAddress.Left - (uplAddressesMain.Width * 0.9)
            If (a - b) < 0 Then a = b
            uplAddress.Left = a

        Else
            Dim a = uplAddress.Left + (uplAddressesMain.Width * 0.9)
            If a >= 0 Then a = 0
            uplAddress.Left = a

        End If

    End Sub

    Private Sub Address123Keydown(sender As Object, e As KeyEventArgs) Handles txtAddress1.KeyDown, txtAddress2.KeyDown, txtAddress3.KeyDown

        If e.KeyCode = Keys.Enter Then
            If sender.text.trim <> String.Empty Then

                Dim searchTerm As String = sender.text

                If sender Is txtAddress1 Then
                    searchTerm = txtAddress1.Text

                ElseIf sender Is txtAddress2 Then
                    searchTerm = txtAddress2.Text

                ElseIf sender Is txtAddress3 Then
                    searchTerm = txtAddress3.Text
                End If

                If searchTerm <> String.Empty Then AddressLookupUsingAFD(AFDSearchTypeEnum.Other, searchTerm)

            End If
        End If

    End Sub

    Private Sub cmdPrevOrder_Click(sender As Object, e As EventArgs) Handles cmdPrevOrder.Click

        Try
            If CurrentCustomer.CustomerId > 0 Then

                Dim prevOrder As CustomerOrderModel = _customerService.GetPreviousOrder(CurrentCustomer.CustomerId)

                If prevOrder IsNot Nothing Then
                    Dim oTime As String = String.Empty
                    Dim oDate As String = String.Empty
                    Dim strToPay As String = prevOrder.BillTotal.ToString
                    If Not IsDBNull(prevOrder.OrderTime) Then
                        oTime = Format(CDate(prevOrder.OrderTime.ToString), "h:mm")
                    End If
                    If Not IsDBNull(prevOrder.OrderDate) Then
                        oDate = Format(CDate(prevOrder.OrderDate.ToString), "dddd dd MMM yyyy")
                    End If

                    strMsgBox = "Previous order placed on:" & vbCrLf & oDate & "   @ " & Replace(oTime, ":", ".") & vbCrLf

                    Dim prevOrderItems As IEnumerable(Of CustOrderItems) = _customerService.GetPreviousOrderItems(CurrentCustomer.CustomerId)

                    If prevOrderItems IsNot Nothing Then
                        tempStr = String.Empty
                        For Each custOrder As CustOrderItems In prevOrderItems
                            tempStr &= Val(custOrder.Qty)
                            tempStr &= " " & custOrder.Dish
                            If Not String.IsNullOrEmpty(custOrder.Mods) And custOrder.Mods <> "00" Then tempStr &= " (" & Replace(custOrder.Mods, "^^", ";") & ")"
                            tempStr &= vbCrLf
                        Next
                        If tempStr <> String.Empty Then strMsgBox &= vbCrLf & tempStr & vbCrLf
                        strMsgBox &= "Bill total: £" & strToPay & vbCrLf
                        strMsgBox &= vbCrLf & "Recall order now?" & vbCrLf & "CAUTION: This will delete any items already in the order!"
                        intMsgBoxResult = MsgBox(strMsgBox, MsgBoxStyle.YesNo, "Previous Order")
                        If intMsgBoxResult = MsgBoxResult.Yes Then
                            If objOrderEntry Is Nothing Then
                                objOrderEntry = New frmOrderEntry
                            End If
                            objOrderEntry.GetCustomerPreviousOrder(CurrentCustomer.CustomerId)
                            cmdNextScreen_Click(sender, e)
                        End If
                    Else
                        Alert("No information found")
                    End If
                Else
                    Alert("Nothing to display. Recall a customer from the database then try again.")
                End If
            Else
                Alert("Nothing to display. Recall a customer from the database then try again.")
            End If

        Catch ex As Exception
            DisplayError(ex)
        End Try

    End Sub

    Private Sub txtMobile_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtMobile.KeyPress

        Select Case e.KeyChar
            Case ChrW(Keys.D0) To ChrW(Keys.D9), ChrW(Keys.Back), ChrW(22)
                e.Handled = False
            Case Else
                e.Handled = True
        End Select

    End Sub

    Public Sub HiLitBox(ctrlName As UltraTextEditor)
        ctrlName.Appearance.BackColor = clrTextBoxesHilit
        ctrlName.Appearance.BackColor2 = clrTextBoxesHilit
        ctrlName.Appearance.BorderColor = clrTextBoxesHilitBorder
        ctrlName.Appearance.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop37
    End Sub

    Public Sub HiLitOffBox(ctrlName As UltraTextEditor)
        ctrlName.AlwaysInEditMode = False
        ctrlName.Appearance.BackColor = clrTextBoxes
        ctrlName.Appearance.BackColor2 = clrTextBoxes
        ctrlName.Appearance.BorderColor = clrTextBoxesBorder
        ctrlName.Appearance.BackGradientStyle = Infragistics.Win.GradientStyle.None
    End Sub

    Private Sub cmdMap_Click(sender As Object, e As EventArgs) Handles cmdMap.Click

        strMsgBox = "This is still in development!"
        Alert(strMsgBox)
        Exit Sub

        Dim strDestination As String = ""

        Dim conn As New EZService.ConnectivityService
        If conn.IsInternetAvailable() Then

            If txtPostcode.Text <> "" Then
                strDestination = txtPostcode.Text.Trim
            ElseIf txtAddress2.Text <> "" Then
                strDestination = txtAddress2.Text.Trim
            Else
                strMsgBox = "Enter a postcode or street name first"
                Alert(strMsgBox)
            End If

            If strDestination <> "" Then
                If GetAppSettingCS("MyPostcode", "") <> "" Then
                    strMsgBox = "Do you wish to see directions?"
                    intResponseBox = EZMsgBox.Show(strMsgBox, MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question)
                Else
                    intResponseBox = vbNo
                End If

                If intResponseBox <> vbCancel Then
                    If intResponseBox = vbYes Then
                        tempStr = String.Format("http://maps.google.co.uk/maps?saddr={0}&daddr={1}",
                              GetAppSettingCS("MyPostcode", "SE2 9EL").ToString.Replace(" ", "+"),
                              strDestination.Replace(" ", "+"))
                    ElseIf intResponseBox = vbNo Then
                        tempStr = String.Format("https://maps.google.co.uk/?output=embed&hl=en&layer=t&q={0}&z=16",
                              strDestination.Replace(" ", "+"))
                    End If

                    Using objMaps As New frmMaps()
                        objMaps.DisplayMap(tempStr)
                    End Using

                End If
            End If

        Else
            strMsgBox = "Internet connection could not be detected. Internet connection is required for this feature."
            Alert(strMsgBox, MessageBoxIcon.Error)
        End If

    End Sub

    Private Function GetDistance(strPostcode1 As String, strPostcode2 As String, strDistanceUnit As DistanceUnitEnum, strYesNo As YesNoEnum)

        Dim strPostcode, url, strXMLResponse As String

        Try

            Dim conn As New EZService.ConnectivityService
            If conn.IsInternetAvailable() Then

                If strPostcode1 = Nothing Or strPostcode2 = Nothing Then
                    Return Nothing
                End If

                url = "http://maps.googleapis.com/maps/api/distancematrix/xml?origins=" &
                    strPostcode1 & "&destinations=" & strPostcode2 & "&mode=driving&language=en-EN&sensor=false"

                Using client As New Net.WebClient
                    strXMLResponse = client.DownloadString(url)
                End Using

                Dim xmldoc As New Xml.XmlDocument
                xmldoc.LoadXml(strXMLResponse)

                Dim sngnode = xmldoc.SelectSingleNode("DistanceMatrixResponse/row/element/distance/text")

                If sngnode IsNot Nothing Then
                    strPostcode = sngnode.InnerText
                    Dim strValue As String = strPostcode.Replace("km", "")
                    If IsANumber(strValue) Then
                        If strDistanceUnit = DistanceUnitEnum.Miles Then
                            Return Math.Round(strValue / 1.6, 1) & IIf(strYesNo = YesNoEnum.Yes, " mi", "")
                        Else
                            Return Math.Round(strValue / 1, 1) & IIf(strYesNo = YesNoEnum.Yes, " km", "")
                        End If
                    Else
                        Return Nothing
                    End If
                Else
                    Return Nothing
                End If
            Else
                Return Nothing
            End If

        Catch ex As Exception
            Return Nothing
        End Try

    End Function

    Private Function DeliveryCutOffTimeProceed() As Boolean

        Dim blnDoProceedNow As Boolean = False
        Dim dtLastDelivTime = GetAppSettingCS("LastDeliveryTime", "")

        If GetAppSettingCS("LastDeliveryChecked", True) Then
            If IsDate(dtLastDelivTime) Then
                If (Now.TimeOfDay > CDate(dtLastDelivTime).TimeOfDay) Then
                    strMsgBox = "Last delivery time (" & dtLastDelivTime & ") has passed." & vbCrLf & "Do you wish to continue?"
                    intMsgBoxResult = EZMsgBox.Show(strMsgBox, MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                    If intMsgBoxResult = MsgBoxResult.Yes Then blnDoProceedNow = True
                Else
                    blnDoProceedNow = True
                End If
            Else
                strMsgBox = "Last delivery time is invalid, please check and correct it in Settings."
                Alert(strMsgBox)
                blnDoProceedNow = True
            End If
        Else
            blnDoProceedNow = True
        End If

        Return blnDoProceedNow

    End Function

End Class