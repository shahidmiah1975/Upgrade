﻿Imports Infragistics.Win.UltraWinGrid

Public Class frmDishMerge

    Dim strDCName As String
    Dim sngUqId As Single
    Dim ugdTemp As Infragistics.Win.UltraWinGrid.UltraGrid

    Public Sub New(ugdDishes As UltraGrid)

        MyBase.New

        ' This call is required by the designer.
        InitializeComponent()

        ugdTemp = ugdDishes

    End Sub

    Private Sub frmDishMerge_Activated(sender As Object, e As EventArgs) Handles Me.Activated

        Try
            cmbConcise.Focus()
        Catch ex As Exception

        End Try

    End Sub

    Private Sub frmDishConcise_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Size = New Size(557, 367)
        CenterToScreen()

        If ugdTemp.Selected.Rows.Count = 1 Then
            sngUqId = ugdTemp.ActiveRow.Cells("UniqueID").Value
            strDCName = ugdTemp.ActiveRow.Cells("DishName").Value
            lblDCHeader.Text = "Options for " & strDCName
            SQLQuery = $"SELECT * FROM DishConcise WHERE UniqueID = {sngUqId}"
            drcDatarowCollection = objDB.GetDataRows(SQLQuery)
            If drcDatarowCollection IsNot Nothing AndAlso drcDatarowCollection.Count > 0 Then
                For Each myRow As DataRow In drcDatarowCollection
                    lstConcise.Items.Add(Rnd, myRow!ConciseName)
                Next
            End If
        Else
            lblDCHeader.Text = "Options for selected items"
        End If

        SQLQuery = "SELECT DISTINCT ConciseName FROM DishConcise ORDER BY ConciseName ASC"
        drcDatarowCollection = objDB.GetDataRows(SQLQuery)
        If drcDatarowCollection IsNot Nothing AndAlso drcDatarowCollection.Count > 0 Then
            For Each myRow As DataRow In drcDatarowCollection
                cmbConcise.Items.Add(myRow!ConciseName)
            Next
        End If

        CancelButton = cmdClose

    End Sub

    Private Sub cmdClose_Click(sender As Object, e As EventArgs) Handles cmdClose.Click

        Dispose()

    End Sub

    Private Sub cmdKBName_Click(sender As Object, e As EventArgs) Handles cmdKBName.Click

        strKBInput = EZFullKeyboard.Show()
        If strKBInput <> EZKBEscape Then
            Try
                AddItem(strKBInput)
            Catch ex As Exception
                DisplayError(ex)
            End Try
        End If

    End Sub

    Private Sub cmdDeleteName_Click(sender As Object, e As EventArgs) Handles cmdDeleteName.Click
        cmbConcise.Clear()
    End Sub

    Private Sub cmdAddToList_Click(sender As Object, e As EventArgs) Handles cmdAddToList.Click
        AddItem(cmbConcise.Text)
    End Sub

    Private Sub txtGroups_Leave(sender As Object, e As EventArgs)
        AcceptButton = Nothing
    End Sub

    Private Sub txtGroups_Enter(sender As Object, e As EventArgs)
        AcceptButton = cmdAddToList
    End Sub

    Private Sub cmdDeleteConcise_Click(sender As Object, e As EventArgs) Handles cmdDeleteConcise.Click

        If lstConcise.Items.Count > 0 Then
            If lstConcise.SelectedItems.Count > 1 Then
                Alert("Select only one item to remove at a time")
            ElseIf lstConcise.SelectedItems.Count = 0 AndAlso lstConcise.Items.Count = 1 Then
                lstConcise.SelectedItems.Add(lstConcise.Items(0))
                DeleteItem(lstConcise.SelectedItems(0).Text)
            Else
                If lstConcise.SelectedItems.Count = 1 Then DeleteItem(lstConcise.SelectedItems(0).Text)
            End If
        End If

    End Sub

    Private Sub AddItem(strItemToAdd As String)

        strItemToAdd = strItemToAdd.Trim

        If String.IsNullOrEmpty(strItemToAdd) = False Then
            'see its not in list already
            If IsInListbox(strItemToAdd, lstConcise) = False Then
                lstConcise.Items.Add(Rnd, strItemToAdd)
                cmbConcise.Clear()
                For iX As Short = 0 To ugdTemp.Selected.Rows.Count - 1
                    sngUqId = ugdTemp.Selected.Rows(iX).Cells("UniqueID").Value
                    SQLQuery = $"INSERT INTO DishConcise (UniqueID, ConciseName) VALUES ({sngUqId}, '{strItemToAdd}')"
                    objDB.ExeNonQuery(SQLQuery)
                    SQLQuery = "UPDATE Dish SET IsInConcise = " & IIf(lstConcise.Items.Count > 0, 1, 0) & " WHERE UniqueID = " & sngUqId
                    objDB.ExeNonQuery(SQLQuery)
                Next
            Else
                strMsgBox = strItemToAdd & " is already in the list"
                Alert(strMsgBox)
            End If
        End If

    End Sub

    Private Sub DeleteItem(strItemToDelete As String)

        strItemToDelete = strItemToDelete.Trim

        If String.IsNullOrEmpty(strItemToDelete) = False Then
            For iX As Short = 0 To ugdTemp.Selected.Rows.Count - 1
                sngUqId = ugdTemp.Selected.Rows(iX).Cells("UniqueID").Value

                SQLQuery = String.Format("DELETE FROM DishConcise WHERE UniqueID = {0} AND ConciseName = '{1}'",
                                         sngUqId, strItemToDelete)
                objDB.ExeNonQuery(SQLQuery)

                SQLQuery = "SELECT * FROM DishConcise WHERE UniqueID = " & sngUqId
                drcDatarowCollection = objDB.GetDataRows(SQLQuery)
                Dim tempVal = IIf(drcDatarowCollection IsNot Nothing AndAlso drcDatarowCollection.Count > 0, 1, 0)
                SQLQuery = "UPDATE Dish SET IsInConcise = " & tempVal & " WHERE UniqueID = " & sngUqId
                objDB.ExeNonQuery(SQLQuery)
            Next
            lstConcise.Items.Remove(lstConcise.SelectedItems(0))
        End If

    End Sub

    Private Sub cmbConcise_KeyPress(sender As Object, e As KeyPressEventArgs) Handles cmbConcise.KeyPress

        If e.KeyChar = Chr(13) Then
            cmdAddToList_Click(Nothing, Nothing)
        End If

    End Sub

    'Declare the variables
    Dim drag As Boolean
    Dim mousex As Integer
    Dim mousey As Integer
    Private ugdDishes As UltraGrid

    Private Sub Form1_MouseDown(sender As Object, e As MouseEventArgs) Handles Me.MouseDown
        drag = True 'Sets the variable drag to true.
        mousex = Cursor.Position.X - Left 'Sets variable mousex
        mousey = Cursor.Position.Y - Top 'Sets variable mousey
    End Sub

    Private Sub Form1_MouseMove(sender As Object, e As MouseEventArgs) Handles Me.MouseMove
        'If drag is set to true then move the form accordingly.
        If drag Then
            Top = Cursor.Position.Y - mousey
            Left = Cursor.Position.X - mousex
        End If
    End Sub

    Private Sub Form1_MouseUp(sender As Object, e As MouseEventArgs) Handles Me.MouseUp
        drag = False 'Sets drag to false, so the form does not move according to the code in MouseMove
    End Sub

End Class