﻿Imports Infragistics.Win.UltraWinEditors
Imports Infragistics.Win.UltraWinGrid

Public Class frmDishCascade

    Private strDCName As String
    Private sngUqId As Single
    Private activeRow As UltraGridRow

    Public Sub New(activeRow As UltraGridRow)

        InitializeComponent()

        Me.activeRow = activeRow

    End Sub

    Private Sub frmDishCascade_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Size = New Size(950, 550)
        CenterToScreen()

        sngUqId = activeRow.Cells("UniqueID").Value
        strDCName = activeRow.Cells("DishName").Value
        lblDCHeader.Text = "Options for " & strDCName

        For Each myobjx In Controls
            If (TypeName(myobjx) = "UltraTextEditor" And myobjx.width > 200) Then
                myobjx.Tag = myobjx.Text
                If myobjx.text <> String.Empty Then myobjx.text = myobjx.Tag & " " & strDCName
            End If
        Next

        cmdSwapName.Tag = "1"

        SQLQuery = "SELECT * FROM DishCascade WHERE UniqueID = " & sngUqId
        drcDatarowCollection = objDB.GetDataRows(SQLQuery)
        If drcDatarowCollection IsNot Nothing Then
            For Each myRow As DataRow In drcDatarowCollection
                Dim strBoxNumber As Short = Val(myRow!BoxNumber.ToString)
                If strBoxNumber > 0 Then
                    For Each myCtrl In Controls
                        If TypeName(myCtrl) = "UltraTextEditor" Then
                            If myCtrl.name.ToString = "txtName" & strBoxNumber Then
                                myCtrl.Text = myRow!DishName
                            ElseIf myCtrl.name.ToString = "txtPriceIn" & strBoxNumber Then
                                myCtrl.Text = myRow!PriceIn
                            ElseIf myCtrl.name.ToString = "txtPriceOut" & strBoxNumber Then
                                myCtrl.Text = myRow!PriceOut
                            ElseIf myCtrl.name.ToString = "txtShortName" & strBoxNumber Then
                                myCtrl.Text = myRow!ShortName
                            ElseIf myCtrl.name.ToString = "txtShortCode" & strBoxNumber Then
                                myCtrl.Text = myRow!ShortCode
                            End If
                        End If
                    Next
                End If
            Next
        End If

    End Sub

    Private Sub cmdPrice1_Click(sender As Object, e As EventArgs) Handles cmdPrice1.Click, cmdPrice2.Click,
        cmdPrice3.Click, cmdPrice4.Click, cmdPrice5.Click, cmdPrice6.Click, cmdPrice7.Click, cmdPrice8.Click, cmdPrice9.Click

        Dim strNumInput As String

        Using objFormQty As New frmQty
            objFormQty.Display("Enter new price", "0.00")
            strNumInput = objFormQty.ReturnValue
        End Using

        If strNumInput <> "x" Then
            Try
                Dim decNewAmount As Decimal = strNumInput
                If (decNewAmount >= 0 And decNewAmount < 100) Then
                    For Each myobjx In Controls
                        If (TypeName(myobjx) = "UltraTextEditor" AndAlso myobjx.name.ToString.Contains("txtPriceIn")) Then
                            If myobjx.name.ToString.Substring(myobjx.name.ToString.Length - 1) = sender.name.ToString.Substring(sender.name.ToString.Length - 1) Then
                                Dim myObj As UltraTextEditor = DirectCast(myobjx, UltraTextEditor)
                                myObj.Text = fixCur(decNewAmount)
                            End If
                        End If
                    Next
                Else
                    strMsgBox = "Number must between 0 and 99"
                    Alert(strMsgBox, MessageBoxIcon.Exclamation)
                End If

            Catch ex As Exception
                DisplayError(ex)
            End Try

        End If

    End Sub

    Private Sub cmdClose_Click(sender As Object, e As EventArgs) Handles cmdClose.Click

        Dispose()

    End Sub

    Private Sub cmdSwapName_Click(sender As Object, e As EventArgs) Handles cmdSwapName.Click

        If sender.tag = "0" Then
            For Each myobjx In Controls
                If (TypeName(myobjx) = "UltraTextEditor" And myobjx.width > 200) Then
                    If myobjx.text <> String.Empty Then myobjx.text = myobjx.Tag & " " & strDCName
                End If
            Next
            sender.tag = "1"
        Else
            For Each myobjx In Controls
                If (TypeName(myobjx) = "UltraTextEditor" And myobjx.width > 200) Then
                    If myobjx.text <> String.Empty Then myobjx.text = strDCName & " " & myobjx.Tag
                End If
            Next
            sender.tag = "0"
        End If

    End Sub

    Private Sub cmdOK_Click(sender As Object, e As EventArgs) Handles cmdOK.Click

        Try

            Dim uniqueId As Integer = activeRow.Cells("UniqueID").Value

            SQLQuery = "DELETE FROM Codes WHERE UniqueID = " & uniqueId
            objDB.ExeNonQuery(SQLQuery)
            SQLQuery = "DELETE FROM DishCascade WHERE UniqueID = " & uniqueId
            objDB.ExeNonQuery(SQLQuery)

            For Each myDishBox In Controls
                If (TypeName(myDishBox) = "UltraTextEditor" And myDishBox.name.ToString.Contains("txtName")) Then
                    If myDishBox.text <> String.Empty Then
                        Dim strBoxNumber As String = myDishBox.name.ToString
                        strBoxNumber = strBoxNumber.Substring(strBoxNumber.Length - 1)

                        Dim strTmpCascade As String = "INSERT INTO DishCascade (UniqueID, DishName, PriceIn, PriceOut, Shortcode, ShortName, GroupName, BoxNumber) VALUES (%%);"
                        Dim blnGoAhead As Boolean = False

                        'uniqueID first
                        Dim strQry = activeRow.Cells("UniqueID").Value & ", "

                        'save dish name
                        strQry &= "'" & myDishBox.text & "', "

                        'save price in
                        For Each myCtrl In Controls
                            If (TypeName(myCtrl) = "UltraTextEditor" And myCtrl.name.ToString = "txtPriceIn" & strBoxNumber) Then
                                If myCtrl.text <> String.Empty Then
                                    strQry &= myCtrl.text & ", "
                                    blnGoAhead = True
                                Else
                                    strQry &= "0,"
                                End If
                            End If
                        Next

                        'save price out
                        For Each myCtrl In Controls
                            If (TypeName(myCtrl) = "UltraTextEditor" And myCtrl.name.ToString = "txtPriceOut" & strBoxNumber) Then
                                If myCtrl.text <> String.Empty Then
                                    strQry &= myCtrl.text & ", "
                                    blnGoAhead = True
                                Else
                                    strQry &= "0,"
                                End If

                            End If
                        Next

                        'save code
                        For Each myCtrl In Controls
                            If (TypeName(myCtrl) = "UltraTextEditor" And myCtrl.name.ToString = "txtShortCode" & strBoxNumber) Then
                                If myCtrl.text <> String.Empty Then
                                    strQry &= "'" & myCtrl.text & "', "
                                    blnGoAhead = True
                                Else
                                    strQry &= "'',"
                                End If

                            End If
                        Next

                        'save shortname
                        For Each myCtrl In Controls
                            If (TypeName(myCtrl) = "UltraTextEditor" And myCtrl.name.ToString = "txtShortName" & strBoxNumber) Then
                                If myCtrl.text <> String.Empty Then
                                    strQry &= "'" & myCtrl.text & "',"
                                    blnGoAhead = True
                                Else
                                    strQry &= "'',"
                                End If

                            End If
                        Next

                        'group name 
                        strQry &= "'" & activeRow.Cells("GroupName").Value & "',"

                        'box number
                        strQry &= "'" & strBoxNumber & "'"

                        If blnGoAhead Then
                            strTmpCascade = strTmpCascade.Replace("%%", strQry)
                            objDB.ExeNonQuery(strTmpCascade)
                        End If
                    End If

                End If
            Next

            'DisplayErrorMessage("All done", , False)

        Catch ex As Exception
            DisplayError(ex, strMsgBox)
        End Try

        Dispose()

    End Sub

    Private Sub cmdPriceOut1_Click(sender As Object, e As EventArgs) Handles cmdPriceOut1.Click, cmdPriceOut2.Click, cmdPriceOut3.Click,
        cmdPriceOut4.Click, cmdPriceOut5.Click, cmdPriceOut6.Click, cmdPriceOut7.Click, cmdPriceOut8.Click, cmdPriceOut9.Click

        Dim strNumInput As String

        Using objFormQty As New frmQty
            objFormQty.Display("Enter new price", "0.00")
            strNumInput = objFormQty.ReturnValue
        End Using

        If strNumInput <> "x" Then
            Try
                Dim decNewAmount As Decimal = strNumInput
                If (decNewAmount >= 0 And decNewAmount < 100) Then
                    For Each myobjx In Controls
                        If (TypeName(myobjx) = "UltraTextEditor" AndAlso myobjx.name.ToString.Contains("txtPriceOut")) Then
                            If myobjx.name.ToString.Substring(myobjx.name.ToString.Length - 1) = sender.name.ToString.Substring(sender.name.ToString.Length - 1) Then
                                Dim myObj As UltraTextEditor = DirectCast(myobjx, UltraTextEditor)
                                myObj.Text = fixCur(decNewAmount)
                            End If
                        End If
                    Next
                Else
                    strMsgBox = "Number must between 0 and 99"
                    Alert(strMsgBox)
                End If

            Catch ex As Exception
                DisplayError(ex)
            End Try

        End If

    End Sub

    Private Sub cmdKB2_Click(sender As Object, e As EventArgs) Handles cmdKB1.Click, cmdKB2.Click, cmdKB3.Click,
        cmdKB4.Click, cmdKB5.Click, cmdKB6.Click, cmdKB7.Click, cmdKB8.Click, cmdKB9.Click

        strKBInput = EZFullKeyboard.Show()
        If strKBInput <> EZKBEscape Then
            Try
                For Each myobjx In Controls
                    If (TypeName(myobjx) = "UltraTextEditor" AndAlso myobjx.name.ToString.Contains("txtShortCode")) Then
                        If myobjx.name.ToString.Substring(myobjx.name.ToString.Length - 1) = sender.name.ToString.Substring(sender.name.ToString.Length - 1) Then
                            Dim myObj As UltraTextEditor = DirectCast(myobjx, UltraTextEditor)
                            myObj.Text = strKBInput
                        End If
                    End If
                Next

            Catch ex As Exception
                strMsgBox = "Number must between 0 and 99"
                Alert(strMsgBox, MessageBoxIcon.Error)
            End Try
        End If

    End Sub

    Private Sub cmdDelSC1_Click(sender As Object, e As EventArgs) Handles cmdDelSC1.Click, cmdDelSC2.Click, cmdDelSC3.Click,
        cmdDelSC4.Click, cmdDelSC5.Click, cmdDelSC6.Click, cmdDelSC7.Click, cmdDelSC8.Click, cmdDelSC9.Click

        For Each myobjx In Controls
            If (TypeName(myobjx) = "UltraTextEditor" AndAlso myobjx.name.ToString.Contains("txtShortCode")) Then
                If myobjx.name.ToString.Substring(myobjx.name.ToString.Length - 1) = sender.name.ToString.Substring(sender.name.ToString.Length - 1) Then
                    Dim myObj As UltraTextEditor = DirectCast(myobjx, UltraTextEditor)
                    myObj.Text = String.Empty
                End If
            End If
        Next

    End Sub

    Private Sub cmdKBSN1_Click(sender As Object, e As EventArgs) Handles cmdKBSN1.Click, cmdKBSN2.Click, cmdKBSN3.Click,
        cmdKBSN4.Click, cmdKBSN5.Click, cmdKBSN6.Click, cmdKBSN7.Click, cmdKBSN8.Click, cmdKBSN9.Click

        strKBInput = EZFullKeyboard.Show()
        If strKBInput <> EZKBEscape Then
            Try
                For Each myobjx In Controls
                    If (TypeName(myobjx) = "UltraTextEditor" AndAlso myobjx.name.ToString.Contains("txtShortName")) Then
                        If myobjx.name.ToString.Substring(myobjx.name.ToString.Length - 1) = sender.name.ToString.Substring(sender.name.ToString.Length - 1) Then
                            Dim myObj As UltraTextEditor = DirectCast(myobjx, UltraTextEditor)
                            myObj.Text = strKBInput
                        End If
                    End If
                Next

            Catch ex As Exception
                strMsgBox = ex.Message
                Alert(strMsgBox, MessageBoxIcon.Exclamation)
            End Try
        End If

    End Sub

    Private Sub cmdDelSN1_Click(sender As Object, e As EventArgs) Handles cmdDelSN1.Click, cmdDelSN2.Click, cmdDelSN3.Click,
        cmdDelSN4.Click, cmdDelSN5.Click, cmdDelSN6.Click, cmdDelSN7.Click, cmdDelSN8.Click, cmdDelSN9.Click

        For Each myobjx In Controls
            If (TypeName(myobjx) = "UltraTextEditor" AndAlso myobjx.name.ToString.Contains("txtShortName")) Then
                If myobjx.name.ToString.Substring(myobjx.name.ToString.Length - 1) = sender.name.ToString.Substring(sender.name.ToString.Length - 1) Then
                    myobjx.Text = String.Empty
                End If
            End If
        Next

    End Sub

    Private Sub cmdKBName_Click(sender As Object, e As EventArgs) Handles cmdKBName1.Click, cmdKBName2.Click, cmdKBName3.Click,
        cmdKBName4.Click, cmdKBName5.Click, cmdKBName6.Click, cmdKBName7.Click, cmdKBName8.Click, cmdKBName9.Click

        strKBInput = EZFullKeyboard.Show()
        If strKBInput <> EZKBEscape Then
            Try
                For Each myobjx In Controls
                    If (TypeName(myobjx) = "UltraTextEditor" AndAlso myobjx.name.ToString.Contains("txtName")) Then
                        If myobjx.name.ToString.Substring(myobjx.name.ToString.Length - 1) = sender.name.ToString.Substring(sender.name.ToString.Length - 1) Then
                            myobjx.Text = strKBInput
                        End If
                    End If
                Next

            Catch ex As Exception
                Alert(ex.Message, MessageBoxIcon.Exclamation)
            End Try
        End If

    End Sub

    'Declare the variables
    Dim drag As Boolean
    Dim mousex As Integer
    Dim mousey As Integer

    Private Sub Form1_MouseDown(sender As Object, e As MouseEventArgs) Handles Me.MouseDown
        drag = True 'Sets the variable drag to true.
        mousex = Cursor.Position.X - Left 'Sets variable mousex
        mousey = Cursor.Position.Y - Top 'Sets variable mousey
    End Sub

    Private Sub Form1_MouseMove(sender As Object, e As MouseEventArgs) Handles Me.MouseMove
        'If drag is set to true then move the form accordingly.
        If drag Then
            Top = Cursor.Position.Y - mousey
            Left = Cursor.Position.X - mousex
        End If
    End Sub

    Private Sub Form1_MouseUp(sender As Object, e As MouseEventArgs) Handles Me.MouseUp
        drag = False 'Sets drag to false, so the form does not move according to the code in MouseMove
    End Sub

End Class