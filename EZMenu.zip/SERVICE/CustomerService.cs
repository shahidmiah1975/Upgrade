﻿using System.Collections.Generic;
using EZMenu.Core.Models;
using EZService.Interface;
using EZService.Repository;

namespace EZService
{
    public class CustomerService : ICustomerService
    {
        CustomerRepository repository;

        public CustomerService()
        {
            repository = new CustomerRepository();
        }

        public CustomerModel GetCustomerByPhone(string phone)
        {
            var customer = repository.GetCustomerByPhone(phone);
            return customer;
        }

        public int AddCollector(CustomerModel customer)
        {
            var collector = repository.AddCollector(customer);
            return collector;
        }

        public CustomerModel GetCollector(string phone)
        {
            var collector = repository.GetCollector(phone);
            return collector;
        }

        public string GetCustomerNote(int customerId)
        {
            var note = repository.GetCustomerNote(customerId);
            return note;
        }

        public IEnumerable<AFDAddressModel> GetCustomerByAFDPostcode(string postcode)
        {
            var addresses = repository.GetCustomerByAFDPostcode(postcode);
            return addresses;
        }

        public IEnumerable<AFDAddressModel> GetCustomerByAFDOther(string field)
        {
            var addresses = repository.GetCustomerByAFDOther(field);
            return addresses;
        }

        public bool DeleteCustomer(int customerId)
        {
            bool isDeleted = repository.DeleteCustomer(customerId);
            return isDeleted;
        }

        public void AddCustomerNote(int customerId, string note)
        {
            repository.AddCustomerNote(customerId, note);
        }

        public void DeleteCustomerNote(int customerId)
        {
            repository.DeleteCustomerNote(customerId);
        }

        public bool AddCustomerDirections(int customerId, string directions)
        {
            return repository.AddCustomerDirections(customerId, directions);
        }

        public void DeleteCustomerDirections(int customerId)
        {
            repository.DeleteCustomerDirections(customerId);
        }

        public string GetCustomerDirections(int customerId)
        {
            var addresses = repository.GetCustomerDirections(customerId);
            return addresses;
        }

        public CustomerOrderModel GetPreviousOrder(short custID)
        {
            var order = repository.GetPreviousOrder(custID);
            return order;
        }

        public IEnumerable<CustOrderItems> GetPreviousOrderItems(short custID)
        {
            var orderItems = repository.GetPreviousOrderItems(custID);
            return orderItems;
        }

        public bool UpsertCustomer(CustomerModel cCustomer, ref bool customerAdded)
        {
            var orderItems = repository.UpsertCustomer(cCustomer, ref customerAdded);
            return orderItems;
        }

        public object GetRecalledOrder(string phoneNumber)
        {
            var orderItems = repository.GetRecalledOrder(phoneNumber);
            return orderItems;
        }

        public bool AddBooking(BookingModel bookingModel)
        {
            var success = repository.AddBooking(bookingModel);
            return success;
        }

        public bool DeleteBooking(BookingModel bookingModel)
        {
            var success = repository.DeleteBooking(bookingModel);
            return success;
        }

        public IList<BookingModel> GetAllBookings(bool onlyAccepted)
        {
            var bookings = repository.GetAllBookings(onlyAccepted);
            return bookings;
        }

        public bool UpdateBooking(BookingModel model)
        {
            var success = repository.UpdateBooking(model);
            return success;
        }

        public IList<BookingModel> GetBookingsByDate(object strBookingDate)
        {
            IList<BookingModel> bookings = repository.GetBookingsByDate(strBookingDate);
            return bookings;
        }

        public void DeletePastBookings()
        {
            repository.DeletePastBookings();
        }
    }
}