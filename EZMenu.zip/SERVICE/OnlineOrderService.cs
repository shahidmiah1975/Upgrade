﻿using EZMenu.Core.Models;
using EZService.Repository;
using System.Collections.Generic;
using EZService.Interface;

namespace EZService
{
    public class OnlineOrderService : IOnlineOrderService
    {
        readonly OnlineOrderRepository _onlineRepo;

        public OnlineOrderService()
        {
            _onlineRepo = new OnlineOrderRepository();
        }

        public OLOrderModel GetOrder(short orderId)
        {
            var order = _onlineRepo.GetOrderById(orderId);
            return order;
        }

        public IList<OLOrderModel> GetAllOrders()
        {
            var orders = _onlineRepo.GetAllOrders();
            return orders;
        }

        public IList<OLOrderModel> GetOrdersByDate(string orderDate)
        {
            var orders = _onlineRepo.GetOrdersByDate(orderDate);
            return orders;
        }

        public IList<OLOrderDetailsModel> GetOrderItems(short orderId)
        {
            var items = _onlineRepo.GetOrderItems(orderId);
            return items;
        }

        public IList<BookingModel> GetBookings()
        {
            var bookings = _onlineRepo.GetOnlineBookings();
            return bookings;
        }
    }
}