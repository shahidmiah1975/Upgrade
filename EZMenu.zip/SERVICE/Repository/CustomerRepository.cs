﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using Dapper;
using EZMenu.Core;
using EZMenu.Core.Models;
using EZService.Interface;
using Microsoft.Data.SqlClient;

namespace EZService.Repository
{
    public class CustomerRepository : ICustomerRepository
    {
        const int collectorIdSeed = 30001;
        private string connectionString;
        private string connectionStringAFD;

        public CustomerRepository()
        {
            connectionString = ConfigurationManager.ConnectionStrings[EZConstants.EZDatabaseConnectionString].ConnectionString; ;
            connectionStringAFD = ConfigurationManager.ConnectionStrings[EZConstants.AFDConnectionString].ConnectionString; ;
        }

        public IEnumerable<CustomerModel> GetCustomers()
        {
            var query = "SELECT * FROM Customer";
            using (var connection = new SqlConnection(connectionString))
            {
                var customers = connection.Query<CustomerModel>(query);
                return customers.OrderBy(o => o.CustomerId).ToList();
            }
        }

        public CustomerModel GetCustomer(int customerId)
        {
            var query = "SELECT * FROM Customer WHERE CustomerID = @customerId";
            using (var connection = new SqlConnection(connectionString))
            {
                CustomerModel customer = connection.QueryFirstOrDefault<CustomerModel>(query, new { customerId });
                return customer;
            }
        }

        public CustomerModel GetCustomerByPhone(string phone)
        {
            var query = @" SELECT *
                            FROM Customer
                            WHERE Phone = @phone
                                OR Mobile = @phone";

            using (var connection = new SqlConnection(connectionString))
            {
                var customer = connection.QueryFirstOrDefault<CustomerModel>(query, new { phone });
                return customer;
            }
        }

        public CustomerModel GetCollector(string phone)
        {
            var query = @" SELECT *
                            FROM Collector
                            WHERE Phone = @phone";

            using (var connection = new SqlConnection(connectionString))
            {
                var customer = connection.QueryFirstOrDefault<CustomerModel>(query, new { phone });
                return customer;
            }
        }

        public CustomerModel AddCustomer(CustomerModel customer)
        {
            CustomerModel newCustomer;

            using (var connection = new SqlConnection(connectionString))
            {
                string insertQuery = $@"IF NOT EXISTS(SELECT CustomerID
			                                          FROM Customer
			                                          WHERE Phone = '{customer.Phone}'
                                                          OR Mobile = '{customer.Phone}')                                   
                                        BEGIN
                                            INSERT INTO Customer (Name, Address1, Address2, Address3, Postcode, Phone, Mobile, Email)
                                            VALUES (@Name, @Address1, @Address2, @Address3, @Postcode, @Phone, @Mobile, @Email)
                                            SELECT SCOPE_IDENTITY()
                                        END
                                        ELSE
                                        BEGIN
                                            SELECT CustomerID   
			                                FROM Customer
			                                WHERE Phone = '{customer.Phone}'
                                                  OR Mobile = '{customer.Phone}'
                                        END";

                int customerId = connection.ExecuteScalar<int>(insertQuery,
                    new
                    {
                        customer.Name,
                        customer.Address1,
                        customer.Address2,
                        customer.Address3,
                        customer.Postcode,
                        customer.Phone,
                        customer.Mobile,
                        customer.Email
                    });

                newCustomer = GetCustomer(customerId);
                SaveCustomerDetails(customerId);
            }

            return newCustomer;
        }

        public int AddCollector(CustomerModel customer)
        {
            int collectorId = 0; //this is CustomerID for the Orders table

            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    string sqlQuery;

                    if (!string.IsNullOrEmpty(customer.Name) && !string.IsNullOrEmpty(customer.Phone))
                    {
                        sqlQuery = $"DELETE FROM Collector WHERE Phone='{customer.Phone}'";
                        connection.Execute(sqlQuery);

                        sqlQuery = @"INSERT INTO Collector (Name, Phone, Email) 
                                     VALUES (@Name, @Phone, @Email)";

                        connection.Execute(sqlQuery, new
                        {
                            customer.Name,
                            customer.Phone,
                            customer.Email
                        });
                    }

                    // get the collector ID for Orders table
                    sqlQuery = $@"SELECT ISNULL(MAX([CustomerID]), 0) AS MaxCustID 
                                  FROM Orders
                                  WHERE(CustomerID >= @collectorIdSeed AND (BizId BETWEEN 40 AND 60))";

                    collectorId = connection.ExecuteScalar<int>(sqlQuery, new { collectorIdSeed });
                    if (collectorId == 0)
                    {
                        collectorId = collectorIdSeed;
                    }

                    collectorId++;
                }
            }
            catch (Exception ex)
            {
                string err = ex.Message;
            }

            return collectorId;
        }

        public bool DeleteCustomer(int customerId)
        {
            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    //form query to delete info in Orders and Order Details tables...
                    string sql = $"SELECT * FROM Orders WHERE CustomerID = {customerId} AND (BizId BETWEEN 40 AND 60)";
                    IEnumerable<CustomerOrderModel> orders = (IEnumerable<CustomerOrderModel>)connection.Query(sql);
                    if (orders.Any())
                    {
                        foreach (var order in orders)
                        {
                            string sql2 = $"DELETE FROM OrderItems WHERE OrderID = {order.OrderID}";
                            connection.ExecuteAsync(sql2);
                        }

                        connection.ExecuteAsync(
                            $"DELETE FROM Orders WHERE CustomerID = {customerId} AND (BizId BETWEEN 40 AND 60)");
                    }

                    //delete customer's previous order
                    connection.ExecuteAsync($"DELETE FROM CustOrders WHERE CustomerID = {customerId}");
                    connection.ExecuteAsync($"DELETE FROM CustOrderItems WHERE CustomerID = {customerId}");

                    //delete all alternative phone numbers that match this number
                    sql = $"SELECT Phone FROM Customer WHERE CustomerID = {customerId}";
                    string phoneCust = connection.ExecuteScalar<string>(sql);
                    if (!string.IsNullOrEmpty(phoneCust))
                    {
                        sql = $"DELETE FROM AlternativePhone WHERE Phone = '{phoneCust}';";
                        connection.ExecuteAsync(sql);
                    }

                    connection.ExecuteAsync($"DELETE FROM NotesDB WHERE CustomerID = {customerId}");
                    connection.ExecuteAsync($"DELETE FROM Directions WHERE CustomerID = {customerId}");
                    connection.ExecuteAsync($"DELETE FROM Customer WHERE CustomerID = {customerId}");

                    return true;
                }
            }
            catch (Exception)
            {
                return false;
                // log to file
            }
        }

        public bool UpdateCustomer(CustomerModel customer)
        {
            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    string insertQuery =
                        $@"UPDATE Customer			                                                                                                 
                                            SET Name = @Name,
                                                Address1 = @Address1,
                                                Address2 = @Address2,
                                                Address3 = @Address3,
                                                Postcode = @Postcode,
                                                Phone = @Phone,
                                                Mobile = @Mobile,
                                                Email = @Email
                                            WHERE CustomerID = @CustomerId";

                    connection.ExecuteScalar<int>(insertQuery, new
                    {
                        customer.Name,
                        customer.Address1,
                        customer.Address2,
                        customer.Address3,
                        customer.Postcode,
                        customer.Phone,
                        customer.Mobile,
                        customer.Email,
                        customer.CustomerId
                    });

                    return true;
                }
            }
            catch (Exception)
            {
                return false;
                // log to file
            }
        }

        public bool UpsertCustomer(CustomerModel cCustomer, ref bool customerAdded)
        {
            bool success;

            try
            {
                if (cCustomer.CustomerId != 0)
                {
                    UpdateCustomer(cCustomer);
                    customerAdded = false;
                }
                else
                {
                    CustomerModel customerCheck = GetCustomerByPhone(cCustomer.Phone);
                    if (customerCheck == null)
                    {
                        AddCustomer(cCustomer);
                        customerAdded = true;
                    }
                    else
                    {
                        UpdateCustomer(cCustomer);
                        customerAdded = false;
                    }
                }

                success = true;
            }
            catch (Exception)
            {
                success = false;
            }

            return success;
        }

        public void SaveDishes(int customerId, int orderId, List<DishModel> orderCart)
        {
            throw new NotImplementedException();
        }

        public bool SaveCustomerDetails(int customerId)
        {
            // other details for Customer table
            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    //save first order date
                    //'If GetAppSettingCS("ShowFirstOrdered") Then
                    string SQLQuery = $@"UPDATE Customer 
                                         SET FirstOrdered = '{DateTime.Now}'
                                         WHERE CustomerID = {customerId} AND (FirstOrdered = '' OR FirstOrdered IS NULL)";
                    connection.ExecuteAsync(SQLQuery);
                    //End If

                    //If GetAppSettingCS("ShowLastOrdered", True) Then
                    //save order date to customer table
                    SQLQuery = $@"UPDATE Customer 
                                  SET LastOrder = '{DateTime.Now}' 
                                  WHERE CustomerID = {customerId}";
                    connection.ExecuteAsync(SQLQuery);
                    //End If

                    //If GetAppSettingCS("ShowCustomersOrders", True) Then
                    //increment number of orders in customer table
                    SQLQuery = $@"UPDATE Customer 
                                  SET NumOrders = ISNULL(NumOrders, 0) + 1 
                                  WHERE CustomerID = {customerId}";
                    //End If

                }

                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public IEnumerable<AFDAddressModel> GetCustomerByAFDPostcode(string postcode)
        {
            string query =
                $@"SELECT TOP 200 [Organisation], [Property], [Street], CASE WHEN[Locality] = '' THEN Town ELSE Locality +', ' + [Town] END AS Town, [Postcode]
                              FROM AFD
                              WHERE Postcode = @postcode
                              ORDER BY CONVERT(INT, LEFT(Street, PATINDEX('%[^0-9]%', 'z') - 1))";

            using (var connection = new SqlConnection(connectionStringAFD))
            {
                var addresses = connection.Query<AFDAddressModel>(query, new { postcode });
                return addresses;
            }
        }


        public IEnumerable<AFDAddressModel> GetCustomerByAFDOther(string fieldValue)
        {
            string SQLQuery = $@"SELECT TOP 200 *
                                 FROM AFD
                                 WHERE Organisation LIKE '%{fieldValue.Punctuate()}%'
                                    OR Property LIKE '%{fieldValue.Punctuate()}%'
                                    OR Street LIKE '%{fieldValue.Punctuate()}%'
                                    OR Locality LIKE '%{fieldValue.Punctuate()}%'
                                    OR Town LIKE '%{fieldValue.Punctuate()}%'";

            using (var connection = new SqlConnection(connectionStringAFD))
            {
                var addresses = connection.Query<AFDAddressModel>(SQLQuery);
                return addresses;
            }
        }

        public void AddCustomerNote(int customerId, string note)
        {
            var query = $"INSERT INTO NotesDB(CustomerID, Message) VALUES ({customerId}, '{note}')";
            using (var connection = new SqlConnection(connectionString))
            {
                connection.Query(query);
            }
        }

        public string GetCustomerNote(int customerId)
        {
            var query = $"SELECT Message FROM NotesDB WHERE CustomerID = {customerId}";
            using (var connection = new SqlConnection(connectionString))
            {
                string note = connection.QueryFirstOrDefault<string>(query);
                return note;
            }
        }

        public void DeleteCustomerNote(int customerId)
        {
            var query = $"DELETE FROM NotesDB WHERE CustomerID = {customerId}";
            using (var connection = new SqlConnection(connectionString))
            {
                connection.Query(query);
            }
        }

        public bool AddCustomerDirections(int customerId, string directions)
        {
            var query = $"INSERT INTO Directions (CustomerID, Directions) VALUES ({customerId}, '{directions}') ";
            using (var connection = new SqlConnection(connectionString))
            {
                string note = connection.QueryFirstOrDefault<string>(query);
                return true;
            }
        }

        public void DeleteCustomerDirections(int customerId)
        {
            var query = $"DELETE FROM Directions WHERE CustomerID = {customerId}";
            using (var connection = new SqlConnection(connectionString))
            {
                connection.Query(query);
            }
        }

        public string GetCustomerDirections(int customerId)
        {
            var query = $"SELECT Directions FROM Directions WHERE CustomerID = {customerId}";
            using (var connection = new SqlConnection(connectionString))
            {
                string note = connection.QueryFirstOrDefault<string>(query);
                return note;
            }
        }

        public object GetRecalledOrder(string phoneNumber)
        {
            string SQLQuery = $@"SELECT DISTINCT od.Qty, od.DishName, od.UnitPrice AS UnitPrice 
                                 FROM Customer c
                                 INNER JOIN (Orders o INNER JOIN OrderItems od ON o.OrderID = od.OrderID) ON c.CustomerID = o.CustomerID
                                 WHERE c.Phone = '{phoneNumber}'";

            using (var connection = new SqlConnection(connectionString))
            {
                object recalledOrder = connection.Query<object>(SQLQuery);
                return recalledOrder;
            }
        }

        public CustomerOrderModel GetPreviousOrder(short custID)
        {
            string SQLQuery = $"SELECT * FROM CustOrders WHERE CustomerID = {custID}";

            using (var connection = new SqlConnection(connectionString))
            {
                CustomerOrderModel prevOrder = connection.QueryFirstOrDefault<CustomerOrderModel>(SQLQuery);
                return prevOrder;
            }
        }

        public IEnumerable<CustOrderItems> GetPreviousOrderItems(short custID)
        {
            string SQLQuery = $"SELECT * FROM CustOrderItems WHERE CustomerID = {custID}";

            using (var connection = new SqlConnection(connectionString))
            {
                IEnumerable<CustOrderItems> prevOrderItems = connection.Query<CustOrderItems>(SQLQuery);
                return prevOrderItems;
            }
        }

        public bool AddBooking(BookingModel bookingModel)
        {
            var query =
                $@"INSERT INTO Bookings ([Date], [Time], [Name], [Covers], [Table], [Phone], [Message], [Status], [OnlineID], [Email])
                   VALUES('{bookingModel.Date}', '{bookingModel.Time}', {bookingModel.Name.PunctuateForDB()}, {bookingModel.Covers}, {bookingModel.Table}, '{bookingModel.Phone}', {bookingModel.Message.PunctuateForDB()}, '{bookingModel.Status}', {bookingModel.OnlineID}, '{bookingModel.Email}')";

            using (var connection = new SqlConnection(connectionString))
            {
                connection.QueryFirstOrDefault(query);
                return true;
            }
        }

        public bool DeleteBooking(BookingModel bookingModel)
        {
            var query = $@"DELETE FROM Bookings
                           WHERE ID = {bookingModel.ID}";

            using (var connection = new SqlConnection(connectionString))
            {
                connection.Query(query);
                return true;
            }
        }

        public IList<BookingModel> GetAllBookings(bool onlyAccepted)
        {
            var query = onlyAccepted
                ? "SELECT * FROM Bookings WHERE Status = 'Accepted' ORDER BY ID DESC"
                : "SELECT * FROM Bookings ORDER BY ID DESC";

            using (var connection = new SqlConnection(connectionString))
            {
                IList<BookingModel> bookings = connection.Query<BookingModel>(query).ToList();
                return bookings;
            }
        }

        public IList<BookingModel> GetBookingsByDate(object strBookingDate)
        {
            var query = $@"SELECT * FROM Bookings
                           WHERE [Date] = '{ strBookingDate }'                      
                           ORDER BY ID Desc";

            using (var connection = new SqlConnection(connectionString))
            {
                IList<BookingModel> bookings = connection.Query<BookingModel>(query).ToList();
                return bookings;
            }
        }

        public bool UpdateBooking(BookingModel model)
        {
            try
            {
                var query = @"UPDATE Bookings SET [Date] = @Date, [Time] = @Time, [Name] = @Name, [Covers] = @Covers, 
                                                   [Table] = @Table, [Phone] = @Phone, [Message] = @Message, [Email] = @Email
                              WHERE ID = @ID";

                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Execute(query, new
                    {
                        model.Date, model.Time, model.Name, model.Covers,
                        model.Table, model.Phone, model.Message, model.Email, model.ID
                    });
                }
                return true;
            }
            catch (Exception)
            {
                return false;
            }

        }

        public void DeletePastBookings()
        {
            var query = @"DELETE FROM Bookings
                          WHERE TRY_CAST([Date] AS DATETIME) < DATEADD(day, -1, GETDATE()); ";
            using (var connection = new SqlConnection(connectionString))
            {
                connection.Query(query);
            }
        }
    }
}