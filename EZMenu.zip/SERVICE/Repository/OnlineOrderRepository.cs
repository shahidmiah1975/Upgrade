﻿using Dapper;
using EZMenu.Core;
using EZMenu.Core.Models;
using EZService.Interface;
using MySql.Data.MySqlClient;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;

namespace EZService.Repository
{
    public class OnlineOrderRepository : IOnlineOrderRepository
    {
        private readonly string _connectionString;

        public OnlineOrderRepository()
        {
            string connectionString = SecurityService.Decrypt(ConfigurationManager.ConnectionStrings[EZConstants.WebserverConnectionString].ConnectionString);
            _connectionString = connectionString;
        }

        public OLOrderModel GetOrderById(int orderId)
        {
            var query = $@"SELECT orders.id AS OrderID, 
                                  CONCAT(adds.first_name, ' ', adds.last_name) AS CustomerName,
                                  adds.address_1 AS Address1,
                                  adds.address_2 AS Address2,
                                  adds.postcode AS Postcode,
                                  adds.email AS EmailAddress, 
                                  adds.phone AS Phone,
                                  orders.total_amount AS BillTotal, 
                                  orders.date_created_gmt AS OrderDate,					  
                                  CASE WHEN orders.payment_method_title LIKE '%Delivery%' THEN 'Delivery' ELSE 'Collection' END AS OrderType,
                                  orders.payment_method_title AS PaymentMethod, 
                                  orders.customer_note AS OrderNote
                           FROM u319135038_dFEri.wp_wc_orders orders
                                JOIN u319135038_dFEri.wp_wc_order_addresses adds                                    
                                    ON orders.id = adds.order_id
                           WHERE orders.id = {orderId}                                    
                           ORDER by orders.id desc; ";

            using (var connection = new MySqlConnection(_connectionString))
            {
                var order = connection.QueryFirstOrDefault<OLOrderModel>(query);
                return order;
            }
        }

        public IList<OLOrderModel> GetOrdersByDate(string orderDate)
        {
            var query = $@"SELECT orders.id AS OrderID, 
                                  CONCAT(adds.first_name, ' ', adds.last_name) AS CustomerName,
                                  adds.address_1 AS Address1,
                                  adds.address_2 AS Address2,
                                  adds.postcode AS Postcode,
                                  CONCAT_WS('\n', adds.address_1, adds.address_2, adds.postcode) AS FullAddress,
                                  adds.email AS EmailAddress,                 
                                  adds.phone AS Phone,
                                  orders.total_amount AS BillTotal, 
                                  orders.date_created_gmt AS OrderDate,					  
                                  CASE WHEN orders.payment_method_title LIKE '%Delivery%' THEN 'Delivery' ELSE 'Collection' END AS OrderType,
                                  orders.payment_method_title AS PaymentMethod, 
                                  orders.customer_note AS OrderNote
                           FROM u319135038_dFEri.wp_wc_orders orders
                                JOIN u319135038_dFEri.wp_wc_order_addresses adds                                    
                                    ON orders.id = adds.order_id
                           WHERE DATE(orders.date_created_gmt) = '{orderDate}'                                    
                           ORDER by orders.id desc; ";

            using (var connection = new MySqlConnection(_connectionString))
            {
                var orders = connection.Query<OLOrderModel>(query).ToList();
                return orders;
            }
        }

        public IList<OLOrderModel> GetAllOrders()
        {
            var query = @"SELECT orders.id, CONCAT(adds.first_name, ' ', adds.last_name) AS CustomerName,
                                  adds.address_1 AS Address1,
                                  adds.address_2 AS Address2,
                                  adds.postcode AS Postcode,
                                  adds.email AS EmailAddress, 
                                  adds.phone AS Phone,
                                  orders.total_amount AS BillTotal, 
                                  orders.date_created_gmt AS OrderDate,					  
                                  CASE WHEN orders.payment_method_title LIKE '%Delivery%' THEN 'Delivery' ELSE 'Collection' END AS OrderType,
                                  orders.payment_method_title AS PaymentMethod, 
                                  orders.customer_note AS CustomerNote
                           FROM u319135038_dFEri.wp_wc_orders orders
                                JOIN u319135038_dFEri.wp_wc_order_addresses adds                                    
                                    ON orders.id = adds.order_id                                             
                           ORDER by orders.id desc; ";

            using (var connection = new MySqlConnection(_connectionString))
            {
                var allOrders = connection.Query<OLOrderModel>(query).ToList();
                return allOrders;
            }
        }

        public IList<OLOrderDetailsModel> GetOrderItems(int orderId)
        {
            var query = $@"SELECT ium.meta_value AS Qty, oi.order_item_name AS Name, pm.meta_value AS Price
                           FROM u319135038_dFEri.wp_woocommerce_order_items oi
                                JOIN u319135038_dFEri.wp_woocommerce_order_itemmeta im
                                    ON oi.order_item_id = im.order_item_id
                                JOIN u319135038_dFEri.wp_woocommerce_order_itemmeta ium                           
                                    ON oi.order_item_id = ium.order_item_id
                                JOIN u319135038_dFEri.wp_postmeta pm
                                    ON im.meta_value = pm.post_id AND pm.meta_key = '_price'
                            WHERE oi.order_id = {orderId}
                                    AND im.meta_key = '_product_id'
                                    AND ium.meta_key = '_qty'
                            ORDER BY ium.meta_id";

            using (var connection = new MySqlConnection(_connectionString))
            {
                var orderItems = connection.Query<OLOrderDetailsModel>(query).ToList();
                return orderItems;
            }
        }

        public List<BookingModel> GetOnlineBookings()
        {
            var query = $@"SELECT 
								submission_id AS ID,
								MAX(CASE WHEN field_name = 'names' THEN field_value END) AS Name,
								MAX(CASE WHEN field_name = 'email' THEN field_value END) AS Email,
								MAX(CASE WHEN field_name = 'datetime' THEN SUBSTRING_INDEX(field_value, ' ', 1) END) AS Date,
								MAX(CASE WHEN field_name = 'datetime' THEN SUBSTRING(field_value, LENGTH(SUBSTRING_INDEX(field_value, ' ', 1)) + 2) END) AS Time,
								MAX(CASE WHEN field_name = 'numeric_field' THEN field_value END) AS Phone,
								MAX(CASE WHEN field_name = 'numeric_field_1' THEN field_value END) AS Covers,
								MAX(CASE WHEN field_name = 'message' THEN field_value END) AS Message
							FROM 
								u319135038_dFEri.wp_fluentform_entry_details
							WHERE 
								form_id = 1
							GROUP BY 
								submission_id
							ORDER BY 
								submission_id DESC;";

            using (var connection = new MySqlConnection(_connectionString))
            {
                var orderItems = connection.Query<BookingModel>(query).ToList();
                return orderItems;
            }
        }
    }
}