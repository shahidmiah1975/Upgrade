﻿using Dapper;
using Dapper.Contrib.Extensions;
using System;
using System.Collections.Generic;
using System.Configuration;
using EZMenu.Core;
using EZMenu.Core.Enums;
using Microsoft.Data.SqlClient;
using EZMenu.Core.Models;
using EZService.Interface;

namespace EZService.Repository
{
    public class OrderRepository : IOrderRepository
    {
        private OrderInfoModel orderInfo;
        private string connectionString;
        private int maxCustId = 30000;
        private CustomerRepository CustomerRepo;

        public OrderRepository()
        {
            this.connectionString = ConfigurationManager.ConnectionStrings[EZConstants.EZDatabaseConnectionString].ConnectionString;
            CustomerRepo = new CustomerRepository();
        }

        public IEnumerable<OrderModsModel> GetOrderModsFromDB(short orderNumber, string dNameOri)
        {
            string SQLQuery = $"SELECT * FROM OrderMods WHERE OrderID = {orderNumber} AND DishName = '{dNameOri}'";

            using (var connection = new SqlConnection(connectionString))
            {
                var ordermods = connection.Query<OrderModsModel>(SQLQuery);
                return ordermods;
            }
        }

        public bool ProcessOrder(OrderInfoModel oInfo)
        {
            int customerId;

            orderInfo = oInfo;

            // save customer/collector
            if (orderInfo.OrderType == OrderTypeEnum.Delivery)
            {
                if (orderInfo.Customer.CustomerId < 1 )
                {
                    CustomerModel customer = CustomerRepo.AddCustomer(orderInfo.Customer);
                    customerId = customer.CustomerId;
                    orderInfo.Customer.CustomerId = customerId;
                }
            }
            else if (orderInfo.OrderType == OrderTypeEnum.Collection)
            {
                customerId = CustomerRepo.AddCollector(orderInfo.Customer);
                orderInfo.Customer.CustomerId = customerId;
            }
            else if (orderInfo.OrderType == OrderTypeEnum.Table)
            {
                // save table info
            }

            // save into Orders table
            short orderId = SaveOrder(orderInfo);
            orderInfo.OrderID = orderId;

            return true;
        }

        public short SaveOrder(OrderInfoModel orderInfo)
        {
            // save to Orders table

            short orderId = 0;
            string query;

            try
            {
                // put orderInfo data into CustOrder

                CustomerOrderModel custOrder = new CustomerOrderModel
                {
                    BillTotal = orderInfo.BillTotal,
                    Subtotal = orderInfo.SubTotal,
                    DrinksTotal = orderInfo.DrinksTotal,
                    CollectionOrDeliveryTime = orderInfo.CollectionOrDeliveryTime,
                    CustomerIsWaiting = orderInfo.CustomerIsWaiting ? 1 : 0,
                    OrderIsPaid = orderInfo.IsPaid ? 1 : 0,
                    PaymentMethod = orderInfo.PaymentMethod == PaymentMethodEnum.Unspecified
                        ? DBNull.Value.ToString()
                        : Enum.GetName(typeof(PaymentMethodEnum), orderInfo.PaymentMethod),
                    IsDeleted = 0,
                    OrderDate = DateTime.Now.ToString("yyyy-MM-dd"),
                    OrderTime = DateTime.Now.ToString("HH:mm:ss"),
                    CuisineName = orderInfo.CuisineName,
                    BizId = orderInfo.BizId,
                    KitchenNote = orderInfo.KitchenNote
                };

                using (var connection = new SqlConnection(connectionString))
                {
                    orderId = (short)connection.Insert(custOrder);

                    // delete existing dishes
                    query = $"DELETE FROM OrderItems WHERE OrderID = {orderId}";
                    connection.Execute(query);
                    query = $"DELETE FROM OrderMods WHERE OrderID = {orderId}";
                    connection.Execute(query);

                    foreach (DishModel dish in orderInfo.OrderedItems)
                    {
                        query =
                            $@"INSERT INTO OrderItems (OrderID, Code, DishName, Qty, UnitPrice, Discountable, GroupIndex) 
                               VALUES (@OrderID, @Code, @DishName, @Qty, @UnitPrice, @Discountable, @GroupIndex)";
                        var param = new
                        {
                            OrderID = orderId,
                            Code = dish.Code,
                            DishName = dish.DishName,
                            Qty = dish.Qty,
                            UnitPrice = dish.UnitPrice,
                            Discountable = dish.Discountable,
                            GroupIndex = dish.GroupIndex
                        };
                        connection.Execute(query, param);

                        if (dish.ModifiersList.Count > 0)
                        {
                            foreach (var mod in dish.ModifiersList)
                            {
                                var modQuery = $@"INSERT INTO OrderMods (OrderID, DishName, ModName, ModCost) 
                                              VALUES (@OrderID, @DishName, @ModName, @ModCost)";
                                var modParam = new
                                {
                                    OrderID = orderId,
                                    DishName = dish.DishName,
                                    ModName = mod.ModName,
                                    ModCost = mod.ModCost
                                };
                                connection.Execute(modQuery, modParam);
                            }
                        }
                    }

                    if (!string.IsNullOrEmpty(orderInfo.Customer.Name))
                    {
                        custOrder.CustomerName = orderInfo.Customer.Name;
                    }

                    if (!string.IsNullOrEmpty(orderInfo.Customer.Phone))
                    {
                        custOrder.Telephone = orderInfo.Customer.Phone;
                    }

                    if (!string.IsNullOrEmpty(orderInfo.CollectionOrDeliveryTime))
                    {
                        custOrder.CollectionOrDeliveryTime = orderInfo.CollectionOrDeliveryTime;
                    }

                    custOrder.CustomerID = orderInfo.Customer.CustomerId;
                    if (orderInfo.Customer.CustomerId != 0 && orderInfo.Customer.CustomerId < maxCustId)
                    {
                        // delivery                    
                        custOrder.DeliveryAddress1 = orderInfo.Customer.Address1;
                        custOrder.DeliveryAddress2 = orderInfo.Customer.Address2;
                        custOrder.DeliveryAddress3 = orderInfo.Customer.Address3;
                        custOrder.DeliveryPostcode = orderInfo.Customer.Postcode;
                        custOrder.Telephone = orderInfo.Customer.Phone;
                    }
                    else
                    {
                        // collection
                        custOrder.CustomerIsWaiting = orderInfo.CustomerIsWaiting ? 1 : 0;
                    }

                    connection.Update(custOrder);

                    // discounts and charges
                    OrdersDiscChargesModel odc = new OrdersDiscChargesModel();
                    bool updateDiscCharges = false;
                    if (orderInfo.DiscountsAndCharges.ChargeAmount != 0)
                    {
                        odc.ChargeAmount = orderInfo.DiscountsAndCharges.ChargeAmount;
                        odc.ChargeLabelText = orderInfo.DiscountsAndCharges.ChargeLabelText;
                        updateDiscCharges = true;
                    }

                    if (orderInfo.DiscountsAndCharges.DiscountAmount != 0)
                    {
                        odc.DiscountAmount = orderInfo.DiscountsAndCharges.DiscountAmount;
                        odc.DiscountLabelText = orderInfo.DiscountsAndCharges.DiscountLabelText;
                        updateDiscCharges = true;
                    }

                    if (orderInfo.DiscountsAndCharges.GlobalChargeAmount != 0)
                    {
                        odc.GlobalChargeAmount = orderInfo.DiscountsAndCharges.GlobalChargeAmount;
                        odc.GlobalChargeLabelText = orderInfo.DiscountsAndCharges.GlobalChargeLabelText;
                        updateDiscCharges = true;
                    }

                    if (orderInfo.DiscountsAndCharges.GlobalDiscountAmount != 0)
                    {
                        odc.GlobalDiscountAmount = orderInfo.DiscountsAndCharges.GlobalDiscountAmount;
                        odc.GlobalDiscountLabelText = orderInfo.DiscountsAndCharges.GlobalDiscountLabelText;
                        updateDiscCharges = true;
                    }

                    odc.OrderID = orderId;
                    if (updateDiscCharges)
                        connection.Insert(odc);
                }

                return orderId;

            }
            catch (Exception ex)
            {
                return -1;
            }
        }

        public List<OrderEditDataModel> GetOrderData(short orderId)
        {
            var query = $@"SELECT Code, Discountable, DishName, GroupIndex, OrderID, Qty, UnitPrice, Qty * UnitPrice AS RowTotal
                           FROM OrderItems
                           WHERE (OrderID = {orderId})
                           UNION
                           SELECT 600 AS Code, 0 AS Discountable, 'Drinks' AS Dish, 600 AS GroupIndex, OrderID, 1 AS Qty, DrinksTotal AS UnitPrice, DrinksTotal AS RowTotal
                           FROM Orders
                           WHERE (OrderID = {orderId}) AND (DrinksTotal IS NOT NULL) AND (DrinksTotal > 0)";

            using (var connection = new SqlConnection(connectionString))
            {
                var editData = connection.Query<OrderEditDataModel>(query);
                return (List<OrderEditDataModel>)editData;
            }
        }

        public short SaveOnlineOrder(OLOrderModel order, List<OLOrderDetailsModel> orderItems)
        {
            var query =
                $@"INSERT INTO Orders (CustomerID, BillTotal, CustomerName, DeliveryAddress1, DeliveryAddress2, DeliveryAddress3, 
                                            DeliveryPostCode, OrderMethod, OnlineOrderID, OrderTime, OrderDate, KitchenNote)
                        VALUES (@CustomerID, @BillTotal, @CustomerName, @DeliveryAddress1, @DeliveryAddress2, @DeliveryAddress3, 
                                        @DeliveryPostCode, @OrderMethod, @OnlineOrderID, @OrderTime, @OrderDate, @KitchenNote);
                        SELECT SCOPE_IDENTITY();";

            var orderParams = new
            {
                CustomerID = 4000,
                BillTotal = order.BillTotal,
                CustomerName = order.CustomerName,
                DeliveryAddress1 = order.Address1,
                DeliveryAddress2 = order.Address2,
                DeliveryAddress3 = (object)DBNull.Value,
                DeliveryPostCode = order.Postcode,
                OrderMethod = "Online",
                OnlineOrderID = order.OrderID,
                OrderTime = order.OrderDate.ToShortTimeString(),
                OrderDate = order.OrderDate.ToShortDateString(),
                KitchenNote = order.OrderNote
            };

            using (var connection = new SqlConnection(connectionString))
            {
                var orderId = connection.ExecuteScalar<short>(query, orderParams);

                foreach (var item in orderItems)
                {
                    var itemQuery = @"INSERT INTO OrderItems (OrderID, Code, DishName, Qty, UnitPrice, Discountable, GroupIndex) 
                                      VALUES (@OrderID, @Code, @DishName, @Qty, @UnitPrice, @Discountable, @GroupIndex)";
                    var itemParams = new
                    {
                        OrderID = orderId,
                        Code = 400,
                        DishName = item.Name,
                        Qty = item.Qty,
                        UnitPrice = item.Price,
                        Discountable = 0,
                        GroupIndex = 0
                    };
                    connection.Execute(itemQuery, itemParams);
                }

                return orderId;
            }
        }

        public List<short> GetOnlineOrderIds()
        {
            var query = @"SELECT DISTINCT OnlineOrderId
                          FROM Orders
                          WHERE OrderMethod = 'Online'
                          ORDER BY OnlineOrderId";

            using (var connection = new SqlConnection(connectionString))
            {
                var editData = connection.Query<short>(query);
                return (List<short>)editData;
            }
        }
    }
}