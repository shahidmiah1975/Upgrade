﻿using System.Configuration;
using MySql.Data.MySqlClient;
using Dapper;
using EZMenu.Core;

namespace EZService.Repository
{
    public class OnlineEZRepository
    {
        private readonly string _connectionString;

        public OnlineEZRepository()
        {
            var encryptedString = ConfigurationManager.ConnectionStrings[EZConstants.EZWebserverConnectionString].ConnectionString;
            _connectionString = SecurityService.Decrypt(encryptedString);
        }

        public bool GetIsActivated(string systemId)
        {
            var query = $@"SELECT UserStatus 
                           FROM u319135038_ezmenu.ezusers
                           WHERE UserID = '{systemId}';";

            using (var connection = new MySqlConnection(_connectionString))
            {
                var isActivated = connection.QuerySingle<string>(query);
                return isActivated.ToUpper() == "ACTIVATED";
            }
        }
    }
}
