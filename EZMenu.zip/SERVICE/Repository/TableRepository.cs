﻿using System;
using System.Collections.Generic;
using System.Configuration;
using Dapper;
using Dapper.Contrib.Extensions;
using EZMenu.Core;
using EZMenu.Core.Models;
using Microsoft.Data.SqlClient;

namespace EZService.Repository
{
    public class TableRepository// : ITableRepository
    {
        private OrderInfoModel orderInfo;
        private string connectionString;

        public TableRepository()
        {
            this.connectionString = ConfigurationManager.ConnectionStrings[EZConstants.EZDatabaseConnectionString].ConnectionString; ;
        }

        public bool ProcessOrder(OrderInfoModel oInfo)
        {
            orderInfo = oInfo;

            // save into Orders table
            bool success = SaveOrder(orderInfo);

            return true;
        }

        public bool SaveOrder(OrderInfoModel orderInfo)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                string query = $@"UPDATE Table_Bill 
                               SET BillTotal = @BillTotal, 
                                   MealTotal = @SubTotal, 
                                   DrinksTotal = @DrinksTotal
                               WHERE TabUniqueId = @TableUniqueId";

                connection.Execute(query, new
                {
                    orderInfo.BillTotal,
                    orderInfo.SubTotal,
                    orderInfo.DrinksTotal,
                    orderInfo.TableUniqueID,
                });

                // delete existing dishes
                query = $"DELETE FROM Table_Meal WHERE TabUniqueId = {orderInfo.TableUniqueID}";
                connection.Execute(query);
                query = $"DELETE FROM Table_Mods WHERE TabUniqueId = {orderInfo.TableUniqueID}";
                connection.Execute(query);

                foreach (DishModel dish in orderInfo.OrderedItems)
                {
                    TableMealModel tableMeal = new TableMealModel
                    {
                        Code = dish.Code.ToString(),
                        DishName = dish.DishName,
                        DishPrice = dish.UnitPrice,
                        DishQty = dish.Qty,
                        IsStarter = dish.IsStarter,
                        GroupIndex = dish.GroupIndex,
                        TabUniqueID = orderInfo.TableUniqueID,
                        Discountable = dish.Discountable
                    };

                    connection.Insert(tableMeal);

                    if (dish.ModifiersList.Count > 0)
                    {
                        foreach (var mod in dish.ModifiersList)
                        {
                            var modQuery = $@"INSERT INTO Table_Mods (TabUniqueID, DishName, ModName, ModCost) 
                                          VALUES (@TabUniqueID, @DishName, @ModName, @ModCost)";
                            var modParam = new
                            {
                                TabUniqueID = orderInfo.TableUniqueID,
                                DishName = dish.DishName,
                                ModName = mod.ModName,
                                ModCost = mod.ModCost
                            };
                            connection.Execute(modQuery, modParam);
                        }
                    }
                }
            }

            return true;
        }

        public bool UpdateTableBill(float tableUniqueId, decimal billTotal, decimal mealTotal, decimal drinksTotal)
        {
            var query = $@"SELECT PrintedTime 
                       FROM Table_Bill 
                       WHERE TabUniqueId = @tableUniqueId ";

            using (var connection = new SqlConnection(connectionString))
            {
                string printedTime = connection.QueryFirstOrDefault<string>(query, new { tableUniqueId });
                if (string.IsNullOrEmpty(printedTime))
                {
                    printedTime = "Time: " + DateTime.Now.ToString("h:mm") + "    Date: " + DateTime.Now.ToString("dd/MM/yy");
                }

                query = $@"UPDATE Table_Bill 
                       SET BillTotal = @billTotal, 
                            MealTotal = @mealTotal, 
                            DrinksTotal = @drinksTotal, 
                            TableStatus = 2, 
                            PrintedTime = @printedTime
                       WHERE TabUniqueId = @tableUniqueId";

                connection.Execute(query, new
                {
                    billTotal,
                    mealTotal,
                    drinksTotal,
                    printedTime,
                    tableUniqueId
                });
            }

            return true;
        }

        public decimal DrinksTotal(float tableUniqueId)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var query = $@"SELECT COALESCE(SUM(DkPrice * DkQty), 0) AS Total 
                           FROM Table_Drinks
                           WHERE TabUniqueId = @tableUniqueId ";

                var total = connection.QuerySingleOrDefault<decimal>(query, new { tableUniqueId });
                return total;
            }
        }

        public bool UpdateTableBill()
        {
            throw new NotImplementedException();
        }

        public IEnumerable<OrderModsModel> GetTableModsFromDB(short tableUniqueID, string dNameOri)
        {
            //string SQLQuery = $"SELECT * FROM Table_Mods WHERE TabUniqueID = {tableUniqueID} AND DishName = '{dNameOri}'";

            string SQLQuery = $@"SELECT CASE WHEN tmod.ModName IS NULL THEN '' ELSE tmod.ModName END AS ModName,
                                CASE WHEN tmod.ModCost IS NULL THEN '0' ELSE tmod.ModCost END AS ModCost
                             FROM Table_Mods tmod, Table_Meal tmeal
                             WHERE tmod.TabUniqueID = tmeal.TabUniqueID
                                AND tmod.DishName = tmeal.DishName
                                AND tmod.TabUniqueID = { tableUniqueID } AND tmod.DishName = '{ dNameOri }'";

            using (var connection = new SqlConnection(connectionString))
            {
                var ordermods = connection.Query<OrderModsModel>(SQLQuery);
                return ordermods;
            }
        }
    }
}