﻿using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using Dapper;
using EZMenu.Core;
using EZMenu.Core.Models;
using EZService.Interface;
using Microsoft.Data.SqlClient;

namespace EZService.Repository
{
    public class DishRepository : IDishRepository
    {
        private string connectionString;

        public DishRepository()
        {
            this.connectionString = ConfigurationManager.ConnectionStrings[EZConstants.EZDatabaseConnectionString].ConnectionString;
        }

        public DishModel AddDish(DishModel dish)
        {
            throw new System.NotImplementedException();
        }

        public bool DeleteDish(int dishCode)
        {
            throw new System.NotImplementedException();
        }

        public DishModel GetDishByCode(int dishCode)
        {
            throw new System.NotImplementedException();
        }

        public DishModel GetDishByShortCode(string shortCode)
        {
            throw new System.NotImplementedException();
        }

        public IEnumerable<DishModel> GetDishes()
        {
            throw new System.NotImplementedException();
        }

        public bool UpdateDish(DishModel dish)
        {
            throw new System.NotImplementedException();
        }

        public List<GroupModel> GetGroups(string mainOrTypical, string cuisine)
        {
            string query;

            if (mainOrTypical == "Menu")
            {
                query = $"SELECT GroupIndex, GroupName FROM Groups WHERE CuisineName = '{cuisine}' ORDER BY GroupIndex";
            }
            else
            {
                query =
                    $"SELECT TID AS GroupIndex, TName AS GroupName FROM Typical WHERE CuisineName = '{cuisine}' ORDER BY TName";
            }

            using (var connection = new SqlConnection(connectionString))
            {
                var groupNames = connection.Query<GroupModel>(query).ToList();
                return groupNames;
            }
        }

        public List<ModifierModel> GetModifiers()
        {
            string query = @"SELECT TOP 40 ID, Name, Cost
                             FROM Modifiers ORDER BY Name";
            using (var connection = new SqlConnection(connectionString))
            {
                var modifiers = connection.Query<ModifierModel>(query).ToList();
                return modifiers;
            }
        }

        public List<CuisineModel> GetCuisines()
        {
            string query = @"SELECT CuisineName 
                             FROM Cuisine 
                             WHERE CuisineName <> '' 
                             ORDER BY ID";
            using (var connection = new SqlConnection(connectionString))
            {
                var cuisines = connection.Query<CuisineModel>(query).ToList();
                return cuisines;
            }
        }

        public CuisineModel GetCuisineByName(string defaultCuisine)
        {
            string query = $@"SELECT *
                              FROM Cuisine 
                              WHERE CuisineName = '{ defaultCuisine }'";
            using (var connection = new SqlConnection(connectionString))
            {
                var cuisine = connection.QueryFirstOrDefault<CuisineModel>(query);
                return cuisine;
            }
        }
    }
}