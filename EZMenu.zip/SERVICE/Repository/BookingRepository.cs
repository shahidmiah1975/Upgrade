﻿using System;
using System.Collections.Generic;
using EZMenu.Core.Models;
using EZService.Interface;

namespace EZService.Repository
{
    public class BookingRepository : IBookingRepository
    {
        public BookingModel AddBooking(BookingModel booking)
        {
            throw new NotImplementedException();
        }

        public bool DeleteBooking(int bookingID)
        {
            throw new NotImplementedException();
        }

        public BookingModel GetBookingByID(int bookingID)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<BookingModel> GetAllBookings()
        {
            throw new NotImplementedException();
        }

        public IEnumerable<BookingModel> GetBookingsByDate(string bookingDate)
        {
            throw new NotImplementedException();
        }

        public bool UpdateBooking(BookingModel booking)
        {
            throw new NotImplementedException();
        }
    }
}
