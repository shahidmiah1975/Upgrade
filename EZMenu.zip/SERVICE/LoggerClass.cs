﻿using log4net;
using System;
using System.Diagnostics;

namespace EZService
{
    public static class LoggerClass
    {
        private static ILog m_objLog = LogManager.GetLogger("log4net");

        public enum log4netType
        {
            Debug,
            Error,
            Warning,
            Info,
            None
        }

        public static void WriteToLog(string strMessage, log4netType lType = log4netType.Debug)
        {
            var st = new StackTrace();
            string strErrString = st.GetFrame(1).GetMethod().Name + ": " + strMessage;
            try
            {
                // log the error message
                if (lType == log4netType.Debug)
                    m_objLog.Debug(strErrString);
                else if (lType == log4netType.Error)
                    m_objLog.Error(strErrString);
                else if (lType == log4netType.Warning)
                    m_objLog.Warn(strErrString);
                else if (lType == log4netType.Info)
                    m_objLog.Info(strErrString);
            }
            catch (Exception ex)
            {
                //Interaction.MsgBox(ex.Message);
            }
        }

        public static void WriteToLog(Exception exException, string strExtraInfo = "", log4netType lType = log4netType.Error)
        {
            var st = new StackTrace();
            string strErrString;

            if (!string.IsNullOrEmpty(strExtraInfo))
                strExtraInfo += Environment.NewLine;

            strErrString = st.GetFrame(1).GetMethod().Name + ": " + strExtraInfo + exException.Message;

            // log the error message
            if (lType == log4netType.Debug)
                m_objLog.Debug(strErrString);
            else if (lType == log4netType.Error)
                m_objLog.Error(strErrString);
            else if (lType == log4netType.Warning)
                m_objLog.Warn(strErrString);
        }

    }
}