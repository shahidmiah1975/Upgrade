﻿namespace EZService
{
    class BookingService
    {
    }
}
