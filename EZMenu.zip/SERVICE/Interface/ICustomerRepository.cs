﻿using System.Collections.Generic;
using EZMenu.Core.Models;

namespace EZService.Interface
{
    public interface ICustomerRepository
    {
        int AddCollector(CustomerModel customer);
    
        CustomerModel AddCustomer(CustomerModel customer);
    
        bool AddCustomerDirections(int customerId, string directions);
    
        void AddCustomerNote(int customerId, string note);
    
        bool DeleteCustomer(int customerId);
    
        void DeleteCustomerDirections(int customerId);
    
        void DeleteCustomerNote(int customerId);
    
        CustomerModel GetCustomer(int customerId);
    
        IEnumerable<AFDAddressModel> GetCustomerByAFDOther(string fieldValue);
    
        IEnumerable<AFDAddressModel> GetCustomerByAFDPostcode(string postcode);
    
        CustomerModel GetCustomerByPhone(string phone);
    
        string GetCustomerDirections(int customerId);
    
        string GetCustomerNote(int customerId);
    
        IEnumerable<CustomerModel> GetCustomers();
    
        bool SaveCustomerDetails(int customerId);
    
        void SaveDishes(int customerId, int orderId, List<DishModel> orderedItems);
    
        bool UpdateCustomer(CustomerModel customer);

        bool UpsertCustomer(CustomerModel cCustomer, ref bool customerAdded);
    }
}