﻿using System.Collections.Generic;
using EZMenu.Core.Models;

namespace EZService.Interface
{
    public interface ICustomerService
    {
        CustomerModel GetCustomerByPhone(string phone);
        int AddCollector(CustomerModel customer);
        CustomerModel GetCollector(string phone);
        string GetCustomerNote(int customerId);
        IEnumerable<AFDAddressModel> GetCustomerByAFDPostcode(string postcode);
        IEnumerable<AFDAddressModel> GetCustomerByAFDOther(string field);
        bool DeleteCustomer(int customerId);
        void AddCustomerNote(int customerId, string note);
        void DeleteCustomerNote(int customerId);
        bool AddCustomerDirections(int customerId, string directions);
        void DeleteCustomerDirections(int customerId);
        string GetCustomerDirections(int customerId);
        CustomerOrderModel GetPreviousOrder(short custID);
        IEnumerable<CustOrderItems> GetPreviousOrderItems(short custID);
        bool UpsertCustomer(CustomerModel cCustomer, ref bool customerAdded);
        object GetRecalledOrder(string phoneNumber);
        bool AddBooking(BookingModel bookingModel);
        bool DeleteBooking(BookingModel bookingModel);
        IList<BookingModel> GetAllBookings(bool onlyAccepted);
        bool UpdateBooking(BookingModel model);
        IList<BookingModel> GetBookingsByDate(object strBookingDate);
        void DeletePastBookings();
    }
}