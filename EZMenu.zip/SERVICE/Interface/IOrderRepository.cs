﻿using System.Collections.Generic;
using EZMenu.Core.Models;

namespace EZService.Interface
{
    public interface IOrderRepository
    {
        bool ProcessOrder(OrderInfoModel orderInfo);
        short SaveOrder(OrderInfoModel orderInfo);
        short SaveOnlineOrder(OLOrderModel order, List<OLOrderDetailsModel> orderItems);
    }
}