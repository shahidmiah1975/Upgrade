﻿using System.Collections.Generic;
using EZMenu.Core.Models;

namespace EZService.Interface
{
    public interface IDishRepository
    {
        IEnumerable<DishModel> GetDishes();
        DishModel GetDishByCode(int dishCode);
        DishModel GetDishByShortCode(string shortCode);
        DishModel AddDish(DishModel dish);
        bool UpdateDish(DishModel dish);
        bool DeleteDish(int dishCode);
        List<ModifierModel> GetModifiers();
        List<CuisineModel> GetCuisines();
        List<GroupModel> GetGroups(string mainOrTypical, string cuisine);
    }
}