﻿using EZMenu.Core.Models;

namespace EZService.Interface
{
    public interface ITableRepository
    {
        bool ProcessOrder(OrderInfoModel orderInfo);
        bool SaveOrder(OrderInfoModel orderInfo);
        bool UpdateTableBill();    
    }
}