﻿using System.Collections.Generic;
using EZMenu.Core.Models;

namespace EZService.Interface
{
    public interface IBookingRepository
    {
        BookingModel AddBooking(BookingModel booking);
        bool DeleteBooking(int bookingID);
        BookingModel GetBookingByID(int bookingID);
        IEnumerable<BookingModel> GetAllBookings();
        IEnumerable<BookingModel> GetBookingsByDate(string bookingDate);
        bool UpdateBooking(BookingModel booking);
    }
}