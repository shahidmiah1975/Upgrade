﻿using EZMenu.Core.Models;
using System.Collections.Generic;

namespace EZService.Interface
{
    public interface IOnlineOrderService
    {
        OLOrderModel GetOrder(short orderId);
        IList<OLOrderModel> GetOrdersByDate(string orderDate);
        IList<OLOrderModel> GetAllOrders();
        IList<OLOrderDetailsModel> GetOrderItems(short orderId);
        //short SaveOnlineOrder(OLOrderModel olOrderModel, List<OLOrderDetailsModel> olOrderDetailsModels);
    }
}