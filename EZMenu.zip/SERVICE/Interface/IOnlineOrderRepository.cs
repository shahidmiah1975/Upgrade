﻿using EZMenu.Core.Models;
using System.Collections.Generic;

namespace EZService.Interface
{
    public interface IOnlineOrderRepository
    {
        IList<OLOrderModel> GetOrdersByDate(string orderDate);
        OLOrderModel GetOrderById(int orderId);
        IList<OLOrderDetailsModel> GetOrderItems(int orderId);
        IList<OLOrderModel> GetAllOrders();
    }
}