﻿namespace EZService
{
    public static class ExtensionMethods
    {

        public static string Punctuate(this string s)
        {
            return s.Replace("'", "''");
        }

        public static string PunctuateForDB(this string s)
        {
            string retString;

            if (string.IsNullOrEmpty(s))
            {
                retString = "''";
                //retString = "NULL";  ??
            }
            else
            {
                retString = "'" + s.Replace("'", "''") + "'";
            }

            return retString;
        }
    }
}