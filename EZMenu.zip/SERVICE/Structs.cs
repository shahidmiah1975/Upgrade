﻿namespace EZService
{
    public class Structs
    {
        public struct ChargeTypeH
        {
            public short ChkEnabled;
            public string AorP;
            public short AmtExcChk;
            public decimal AmtExcVal;
            public decimal Amount;
            public decimal Charge1;
            public decimal Charge2;
            public string Charge2AorP;
            public decimal Charge2Rate;
        }
        public struct DiscountTypeH
        {
            public short ChkEnabled;
            public string AorP;
            public short AmtExcChk;
            public decimal AmtExcVal;
            public decimal Amount;
            public decimal Discount1;
            public decimal Discount2;
            public string Discount2AorP;
            public decimal Discount2Rate;
        }
    }
}