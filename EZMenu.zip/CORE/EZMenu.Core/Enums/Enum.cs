﻿namespace EZMenu.Core.Enums
{
    public enum OrderTypeEnum
    {
        Delivery,
        Collection,
        Table,
        EditOn,
        EditOff
    }

    public enum DiscountOrChargeEnum
    {
        Discount,
        Charge
    }

    public enum AmountOrPercentageEnum
    {
        Amount,
        Percentage
    }

    public enum TStatusEnum
    {
        Clean,
        InUse,
        Printed,
        Saved
    }

    public enum AppliesToTableEnum
    {
        MealOnly,
        DrinksOnly,
        Both
    }

    public enum AFDSearchTypeEnum
    {
        Postcode,
        Other
    }

    public enum CallerIDEnum
    {
        MatchInCustomer,
        MatchInCollector,
        NoCallerID
    }

    public enum PaymentMethodEnum
    {
        Cash,
        Card,
        Other,
        Unspecified
    }

    public enum PrintDestinationEnum
    {
        Shop,
        Kitchen,
        Both,
        SaveOnly
    }

    public enum DistanceUnitEnum
    {
        Miles,
        Kilometers
    }

    public enum YesNoEnum
    {
        Yes,
        No
    }

    public enum OrderOrUserEnum
    {
        Order,
        User
    }
    
    public enum OrderMethodEnum
    {
        Local,
        Online,
        Tablet
    }
}