﻿using System;

namespace EZMenu.Core
{
    public class Helper
    {
        public static int GetRandomNum(int intFirst, int intLast)
        {
            Random myRandom = new Random(DateTime.Now.Millisecond);
            return myRandom.Next(intFirst, intLast + 1);
        }
    }
}
