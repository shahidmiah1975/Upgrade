﻿using System.Collections.Generic;
using EZMenu.Core.Enums;
using static EZMenu.Core.Structs;

namespace EZMenu.Core.Models
{
    public partial class OrderInfoModel 
    {
        public short OrderID { get; set; } 
        public OrderTypeEnum OrderType { get; set; }
        public CustomerModel Customer { get; set; }
        public List<DishModel> OrderedItems { get; set; } 
        public decimal SubTotal { get; set; }
        public List<CollectionDrinksModel> DrinksList { get; set; }
        public decimal DrinksTotal { get; set; }
        public decimal BillTotal { get; set; }        
        public short TableUniqueID { get; set; }
        public bool IsPaid { get; set; }
        public PaymentMethodEnum PaymentMethod { get; set; }
        public string KitchenNote { get; set; }        
        public ChargeTypeH AllCharges { get; set; }
        public DiscountTypeH AllDiscounts { get; set; }
        public DiscountsAndChargesModel DiscountsAndCharges { get; set; }
        public PriceAdjustmentsModel PriceAdjustmentCharges { get; set; }
        public PriceAdjustmentsModel PriceAdjustmentDiscounts { get; set; }
        public string CollectionOrDeliveryTime { get; set; } = string.Empty;
        public bool CustomerIsWaiting { get; set; }
        public string UserName { get; set; }
        public short BizId { get; set; }
        public string CuisineName{ get; set; }
    }
}