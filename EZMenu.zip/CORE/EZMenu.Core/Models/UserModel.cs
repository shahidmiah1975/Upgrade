﻿using Dapper.Contrib.Extensions;

namespace EZMenu.Core.Models
{
    [Table("Users")]
    public class UserModel
    {
        [Key]
        public int UserID { get; set; }
        public string UserName { get; set; }
        public string UserPassword { get; set; }
    }
}