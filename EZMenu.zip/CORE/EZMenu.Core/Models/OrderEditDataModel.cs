﻿namespace EZMenu.Core.Models
{
    public class OrderEditDataModel
    {
        public short Code { get; set; }
        public short Discountable { get; set; }
        public string DishName { get; set; }
        public short GroupIndex { get; set; }
        public short OrderID { get; set; }
        public short Qty { get; set; }
        public decimal UnitPrice { get; set; }
        public decimal RowTotal { get; set; }

        public OrderEditDataModel()
        {            
            Code = 0;
            Discountable = 0;
            DishName = "";
            GroupIndex = 0;
            OrderID = 0;
            Qty = 0;
            UnitPrice = 0;
            RowTotal = 0;
        }
    }
}
