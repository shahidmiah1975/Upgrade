﻿using Dapper.Contrib.Extensions;

namespace EZMenu.Core.Models
{
    [Table("OrdersDiscCharges")]
    public class OrdersDiscChargesModel
    {
        [Key]
        public int ID { get; set; }
        public int OrderID { get; set; }
        public decimal ChargeAmount { get; set; }
        public string ChargeLabelText { get; set; }
        public decimal DiscountAmount { get; set; }
        public string DiscountLabelText { get; set; }
        public decimal GlobalChargeAmount { get; set; }
        public string GlobalChargeLabelText { get; set; }
        public decimal GlobalDiscountAmount { get; set; }
        public string GlobalDiscountLabelText { get; set; }
        public string Discount2AorP { get; set; }
        public string Charge2AorP { get; set; }
        public string Discount2Rate { get; set; }
        public string Charge2Rate { get; set; }
        public decimal Charge2 { get; set; }
        public decimal Discount2 { get; set; }
    }
}
