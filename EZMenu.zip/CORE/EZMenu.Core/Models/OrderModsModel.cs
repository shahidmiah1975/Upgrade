﻿namespace EZMenu.Core.Models
{
    public class OrderModsModel
    {
        public int OrderID { get; set; }
        public string DishName { get; set; }
        public string ModName { get; set; }
        public decimal ModCost { get; set; }

        public OrderModsModel()
        {
            OrderID = 0;
            DishName = string.Empty;
            ModName = string.Empty;
            ModCost = 0;
        }
    }
}