﻿using EZMenu.Core.Enums;

namespace EZMenu.Core.Models
{
    public partial class PriceAdjustmentsModel
    {        
        public string Name { get; set; }
        
        public DiscountOrChargeEnum? DiscountOrCharge { get; set; }
        
        public string Value { get; set; }

        public AmountOrPercentageEnum AmountOrPercentage { get; set; }
        
        public AppliesToTableEnum MealDrinksBoth;

        public bool Cancelled;
        
        public bool Reset;
        
        public decimal CalculatedTotal;
        
        public bool GlobalIsOff;
        
        public PriceAdjustmentsModel()
        {
            Name = "";
            DiscountOrCharge = null;
            Value = "0";
            AmountOrPercentage = new AmountOrPercentageEnum();
            MealDrinksBoth = new AppliesToTableEnum();
            Cancelled = false;
            Reset = false;
            CalculatedTotal = 0;
            GlobalIsOff = false;
        }
    }
}