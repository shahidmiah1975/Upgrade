﻿using Dapper.Contrib.Extensions;

namespace EZMenu.Core.Models
{
    [Table("Orders")]
    public partial class CustomerOrderModel
    {
        [Key]
        public int OrderID { get; set; } = 0;
        public int CustomerID { get; set; } = 0;
        public decimal BillTotal { get; set; } = 0;
        public decimal Subtotal { get; set; } = 0;
        public decimal DrinksTotal { get; set; } = 0;
        public int OrdersDiscChargesID { get; set; } = 0;
        public int OrdersCardDetailsID { get; set; } = 0;
        public string CollectionOrDeliveryTime { get; set; } = string.Empty;    
        public int CustomerIsWaiting { get; set; } = 0;
        public int OrderIsPaid { get; set; } = 0;
        public string PaymentMethod { get; set; } = string.Empty;
        public string CustomerName { get; set; } = string.Empty;
        public string DeliveryAddress1 { get; set; } = string.Empty;
        public string DeliveryAddress2 { get; set; } = string.Empty;
        public string DeliveryAddress3 { get; set; } = string.Empty;
        public string DeliveryPostcode { get; set; } = string.Empty;
        public string Telephone { get; set; } = string.Empty;
        public int IsDeleted { get; set; } = 0;
        public string KitchenNote { get; set; } = string.Empty;
        public string OrderMethod { get; set; } = string.Empty;
        public string CuisineName { get; set; } = string.Empty;
        public int ButtonStatus { get; set; } = 0;
        public string OrderTime { get; set; } = string.Empty;
        public string OrderDate { get; set; } = string.Empty;
        public int BizId { get; set; } = 0;           
    }
}