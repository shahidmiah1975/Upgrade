﻿namespace EZMenu.Core.Models
{
    public class OrdersCardDetailsModel
    {
        public int ID { get; set; }
        public int OrderID { get; set; }
        public string CardNumber { get; set; }
        public string CardExpiry { get; set; }
        public string CardIssueNum { get; set; }
        public string CardValid { get; set; }
        public string CardSecurity { get; set; }
    }
}