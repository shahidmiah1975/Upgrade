﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EZMenu.Core.Models
{
    public class CuisineModel
    {
        public int ID { get; set; }
        public string Name { get; set; }
    }
}