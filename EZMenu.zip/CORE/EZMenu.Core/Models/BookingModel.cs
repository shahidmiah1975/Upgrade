﻿using System;

namespace EZMenu.Core.Models
{
    public  class BookingModel
    {
        public int ID { get; set; }
        public string Date { get; set; }
        public string Time { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public int Covers { get; set; }
        public int Table { get; set; }
        public string Message { get; set; }
        public string Status { get; set; }
        public int OnlineID { get; set; }
    }
}
