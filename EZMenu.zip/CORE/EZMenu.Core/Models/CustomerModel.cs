﻿using System;

namespace EZMenu.Core.Models
{
    public partial class CustomerModel
    {
        public int CustomerId { get; set; }

        public string Name { get; set; }

        public string Address1 { get; set; }

        public string Address2 { get; set; }

        public string Address3 { get; set; }

        public string Postcode { get; set; }

        public string Phone { get; set; }
        
        public string Mobile { get; set; }
        
        public string Email { get; set; }
        
        public DateTime? LastOrder { get; set; }

        public DateTime? FirstOrdered { get; set; }
        
        public int NumberOfOrders {  get; set; }

        public CustomerModel()
        {
            CustomerId = 0;
            Name = string.Empty;
            Address1 = string.Empty;
            Address2 = string.Empty;
            Address3 = string.Empty;
            Postcode = string.Empty;
            Phone = string.Empty;
            Mobile = string.Empty;
            Email = string.Empty;
            LastOrder = null;
            FirstOrdered = null;
            NumberOfOrders = 0;
        }
    }
}