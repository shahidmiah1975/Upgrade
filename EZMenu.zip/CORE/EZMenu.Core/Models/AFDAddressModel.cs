﻿namespace EZMenu.Core.Models
{
    public class AFDAddressModel
    {
        public string Organisation { get; set; }
        public string Property { get; set; }
        public string Street { get; set; }
        public string Locality { get; set; }
        public string Town { get; set; }
        public string Postcode { get; set; }
    }
}