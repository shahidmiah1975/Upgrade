﻿namespace EZMenu.Core.Models
{
    public class GroupModel
    {
        public int GroupIndex { get; set; }
        public string GroupName { get; set; }

        public GroupModel()
        {
            GroupIndex = 0;
            GroupName = "";
        }

    }
}