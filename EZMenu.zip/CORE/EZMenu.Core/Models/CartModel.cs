﻿namespace EZMenu.Core.Models
{
    public class CartModel
    {
        public int UniqueID { get; set; }
        public int Code { get; set; }
        public int Qty { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }
        public decimal Total { get; set; }
        public int GroupIndex { get; set; }

        public CartModel()
        {
            Code = 0;
            Qty = 0;
            Name = "";
            Price = 0;
            Total = 0;
            GroupIndex = 0;
        }
    }
}