﻿namespace EZMenu.Core.Models
{
    public class OLBookingModelx
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Date { get; set; }
        public string Time { get; set; }
        public string Phone { get; set; }
        public string Cover { get; set; }
        public string Message { get; set; }
    }
}