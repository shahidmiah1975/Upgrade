﻿using System;
using EZMenu.Core.Enums;

namespace EZMenu.Core.Models
{
    public class OLOrderModel
    {
        public int OrderID { get; set; }
        public string CustomerName { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string Postcode { get; set; }
        public string FullAddress { get; set; }
        public string EmailAddress { get; set; }
        public string Phone { get; set; }
        public decimal BillTotal { get; set; }
        public DateTime OrderDate { get; set; }
        public OrderTypeEnum OrderType { get; set; }
        public string PaymentMethod { get; set; }
        public string OrderNote { get; set; }
    }
}