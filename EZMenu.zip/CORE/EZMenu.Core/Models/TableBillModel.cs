﻿namespace EZMenu.Core.Models
{
    public class TableBillModel
    {
        public int TabUniqueID { get; set; }
        
        public int NumCust { get; set; }
        
        public decimal BillTotal { get; set; }
        
        public decimal MealTotal { get; set; }
        
        public decimal DrinksTotal { get; set; }
        
        public decimal Tips { get; set; }
        
        public string PayMethod { get; set; }
        
        public int TableNumber { get; set; }
        
        public int TableStatus { get; set; }
        
        public string PrintedTime { get; set; }
        
        public string TableNote { get; set; }
        
        public int CAPValue { get; set; }
        
        public string EntryTime { get; set; }
        
        public decimal DiscountAmount { get; set; }
        
        public decimal ChargeAmount { get; set; }
        
        public string DiscountLabelText { get; set; }
        
        public string ChargeLabelText { get; set; }
        
        public decimal GDiscountAmount { get; set; }
        
        public string GDiscountLabelText { get; set; }
        
        public decimal GChargeAmount { get; set; }
        
        public string GChargeLabelText { get; set; }
        
        public string OrderDate { get; set; }
        
        public string UserName { get; set; }
        
        public decimal PCash { get; set; }
        
        public decimal PCard { get; set; }
        
        public decimal POther { get; set; }
        
        public decimal TCash { get; set; }
        
        public decimal TCard { get; set; }
        
        public decimal TOther { get; set; }
        
        public int BizId { get; set; }
        
        public int Lights { get; set; }
        
        public string DorCSelected { get; set; }
        
        public decimal DorCInputValue { get; set; }
        
        public string DorCAmtPcent { get; set; }
        
        public string DorCMealDrinkBoth { get; set; }
    }
}