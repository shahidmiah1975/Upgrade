﻿namespace EZMenu.Core.Models
{
    public class ModifierModel
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public decimal Cost { get; set; }
    }
}