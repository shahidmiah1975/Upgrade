﻿namespace EZMenu.Core.Models
{
    public class CollectionDrinksModel
    {
        public string Name { get; set; }
        public int Qty { get; set; }
        public decimal Price { get; set; }
    }
}