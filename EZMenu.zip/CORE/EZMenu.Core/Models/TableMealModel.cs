﻿using Dapper.Contrib.Extensions;

namespace EZMenu.Core.Models
{
    [Table("Table_Meal")]
    public class TableMealModel
    {
        public string Code { get; set; }                      

        public string DishName { get; set; }
        
        public decimal DishPrice { get; set; }
        
        public short DishQty { get; set; }
        
        public short IsStarter { get; set; }
        
        public short GroupIndex { get; set; }
        
        public short TabUniqueID { get; set; }
        
        public short Discountable { get; set; }        

    }
}