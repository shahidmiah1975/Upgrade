﻿namespace EZMenu.Core.Models
{
    public partial class DiscountsAndChargesModel
    {
        public decimal ChargeAmount { get; set; }

        public string ChargeLabelText { get; set; }

        public decimal DiscountAmount { get; set; }

        public string DiscountLabelText { get; set; }

        public decimal GlobalChargeAmount { get; set; }

        public string GlobalChargeLabelText { get; set; }

        public decimal GlobalDiscountAmount { get; set; }

        public string GlobalDiscountLabelText { get; set; }
    }
}