﻿using System.Collections.Generic;

namespace EZMenu.Core.Models
{
    public class DishModel
    {
        public short UniqueID { get; set; } = 0;
        public short Code { get; set; } = 0;    
        public string DishName { get; set; } = string.Empty;
        public short Qty { get; set; } = 0;
        public decimal PriceIn { get; set; } = 0;
        public decimal PriceOut { get; set; } = 0;
        public decimal UnitPrice { get; set; } = 0;
        public short Discountable { get; set; } = 0;
        public short IsStarter { get; set; } = 0;
        public string Mods { get; set; } = string.Empty;    
        public string GroupName { get; set; } = string.Empty;
        public short GroupIndex { get; set; } = 0;
        public string ShortName { get; set; } = string.Empty;
        public List<OrderModsModel> ModifiersList { get; set; } = null;
    }
}