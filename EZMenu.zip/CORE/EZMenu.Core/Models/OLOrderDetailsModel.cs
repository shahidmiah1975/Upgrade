﻿namespace EZMenu.Core.Models
{
    public class OLOrderDetailsModel
    {
        public int Qty { get; set; }
        public string Name { get; set; }
        public string Price { get; set; }
    }
}