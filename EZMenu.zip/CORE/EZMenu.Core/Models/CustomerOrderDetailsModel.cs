﻿namespace EZMenu.Core.Models
{
    public partial class CustOrderItems
    {
        public short CustomerID { get; set; }
        public int Code { get; set; }
        public string Dish { get; set; }
        public int Qty { get; set; }
        public decimal UnitPrice { get; set; }
        public int Discountable { get; set; }
        public int GroupIndex { get; set; }
        public string Mods { get; set; }
    }
}