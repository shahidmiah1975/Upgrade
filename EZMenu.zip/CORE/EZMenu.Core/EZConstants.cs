﻿namespace EZMenu.Core
{
    public static class EZConstants
    {
        public const string EZDatabaseConnectionString = "EZConnectionString";
        public const string WebserverConnectionString = "WebserverConnectionString";
        public const string EZWebserverConnectionString = "EZWebserverConnectionString";
        public const string AFDConnectionString = "AFDConnectionString";
    }
}